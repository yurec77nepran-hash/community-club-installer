#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_NAME="${APP_NAME:-community-club}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"
ENV_FILE="${ENV_FILE:-.env}"
CADDY_SNIPPET_PATH="${CADDY_SNIPPET_PATH:-/etc/caddy/conf.d/${APP_NAME}.caddy}"
CADDYFILE_PATH="${CADDYFILE_PATH:-/etc/caddy/Caddyfile}"
DOMAIN="${DOMAIN:-}"
INSTALL_SYSTEM_DEPS="${INSTALL_SYSTEM_DEPS:-1}"
UPDATE_EXISTING_PACKAGES="${UPDATE_EXISTING_PACKAGES:-0}"
ENABLE_FIREWALL="${ENABLE_FIREWALL:-0}"
SKIP_GARAGE_INIT="${SKIP_GARAGE_INIT:-0}"
SKIP_APP_BUILD="${SKIP_APP_BUILD:-0}"
DRIZZLE_PUSH_FORCE="${DRIZZLE_PUSH_FORCE:-1}"
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-$APP_NAME}"
ADMIN_EMAIL="${ADMIN_EMAIL:-}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-}"
AUTO_SWAP="${AUTO_SWAP:-1}"
SWAP_FILE="${SWAP_FILE:-/swapfile-community-club}"
SWAP_SIZE_MB="${SWAP_SIZE_MB:-4096}"
SWAP_MIN_RAM_MB="${SWAP_MIN_RAM_MB:-4096}"
SWAP_MIN_EXISTING_MB="${SWAP_MIN_EXISTING_MB:-1024}"

export COMPOSE_PROJECT_NAME

log() {
	printf '\n==> %s\n' "$*"
}

ok() {
	printf '[OK] %s\n' "$*"
}

warn() {
	printf '[WARN] %s\n' "$*" >&2
}

fail() {
	printf '[ERROR] %s\n' "$*" >&2
	exit 1
}

run_root() {
	if [[ "$(id -u)" == "0" ]]; then
		"$@"
	elif command -v sudo >/dev/null 2>&1; then
		sudo "$@"
	else
		fail "Нужны root-права или sudo для установки системных пакетов"
	fi
}

detect_os() {
	if [[ ! -f /etc/os-release ]]; then
		fail "Не удалось определить ОС. Автоустановка поддерживает Ubuntu/Debian-like Linux"
	fi
	# shellcheck disable=SC1091
	. /etc/os-release
	case "${ID:-}" in
		ubuntu | debian) ;;
		*)
			case "${ID_LIKE:-}" in
				*debian* | *ubuntu*) ;;
				*) fail "Автоустановка зависимостей поддерживает Ubuntu/Debian-like Linux. Текущая ОС: ${PRETTY_NAME:-unknown}" ;;
			esac
			;;
	esac
}

ensure_apt_packages() {
	local packages=("$@")
	if [[ "${#packages[@]}" == "0" ]]; then
		return
	fi
	run_root apt-get update
	if [[ "$UPDATE_EXISTING_PACKAGES" == "1" ]]; then
		run_root apt-get install -y --only-upgrade "${packages[@]}" || true
	fi
	run_root apt-get install -y "${packages[@]}"
}

install_base_dependencies() {
	log "Проверяю базовые зависимости"
	local missing=()
	for bin in curl gpg openssl git rsync python3 ip timeout; do
		if ! command -v "$bin" >/dev/null 2>&1; then
			missing+=("$bin")
		fi
	done
	if ! dpkg -s ca-certificates >/dev/null 2>&1; then
		missing+=(ca-certificates)
	fi

	if [[ "${#missing[@]}" == "0" ]]; then
		ok "Базовые зависимости уже есть"
		return
	fi

	[[ "$INSTALL_SYSTEM_DEPS" == "1" ]] || fail "Нет зависимостей: ${missing[*]}"
	ensure_apt_packages ca-certificates curl gnupg openssl git rsync python3 iproute2 coreutils
}

install_docker() {
	log "Проверяю Docker"
	if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
		ok "Docker и compose plugin уже установлены"
		return
	fi

	[[ "$INSTALL_SYSTEM_DEPS" == "1" ]] || fail "Docker не установлен"

	if ! command -v docker >/dev/null 2>&1; then
		run_root install -m 0755 -d /etc/apt/keyrings
		# shellcheck disable=SC1091
		. /etc/os-release
		local repo_id="ubuntu"
		if [[ "${ID:-}" == "debian" || "${ID_LIKE:-}" == *debian* ]]; then
			repo_id="debian"
		fi
		if [[ "${ID:-}" == "ubuntu" || "${ID_LIKE:-}" == *ubuntu* ]]; then
			repo_id="ubuntu"
		fi
		local codename="${VERSION_CODENAME:-}"
		if [[ -z "$codename" && -r /etc/debian_version ]]; then
			codename="$(. /etc/os-release && printf '%s' "${VERSION_CODENAME:-bookworm}")"
		fi
		[[ -n "$codename" ]] || fail "Не удалось определить codename ОС для Docker apt repo"
		if [[ ! -f /etc/apt/keyrings/docker.gpg ]]; then
			curl -fsSL "https://download.docker.com/linux/${repo_id}/gpg" |
				run_root gpg --dearmor -o /etc/apt/keyrings/docker.gpg
			run_root chmod a+r /etc/apt/keyrings/docker.gpg
		fi
		echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/${repo_id} ${codename} stable" |
			run_root tee /etc/apt/sources.list.d/docker.list >/dev/null
		run_root apt-get update
		run_root apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
	elif ! docker compose version >/dev/null 2>&1; then
		ensure_apt_packages docker-compose-plugin
	fi

	run_root systemctl enable --now docker
	ok "Docker готов"
}

install_caddy() {
	log "Проверяю Caddy"
	if command -v caddy >/dev/null 2>&1; then
		ok "Caddy уже установлен"
		run_root systemctl enable --now caddy || true
		return
	fi

	[[ "$INSTALL_SYSTEM_DEPS" == "1" ]] || fail "Caddy не установлен"
	ensure_apt_packages debian-keyring debian-archive-keyring apt-transport-https
	run_root mkdir -p /usr/share/keyrings /etc/apt/sources.list.d
	local key_source_temp keyring_temp source_list_temp
	key_source_temp="$(run_root mktemp /usr/share/keyrings/caddy-stable-archive-keyring.gpg.source.XXXXXX)"
	keyring_temp="$(run_root mktemp /usr/share/keyrings/caddy-stable-archive-keyring.gpg.XXXXXX)"
	source_list_temp="$(run_root mktemp /etc/apt/sources.list.d/caddy-stable.list.XXXXXX)"
	trap 'run_root rm -f "$key_source_temp" "$keyring_temp" "$source_list_temp"' EXIT
	run_root curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/gpg.key -o "$key_source_temp"
	run_root gpg --batch --yes --dearmor -o "$keyring_temp" "$key_source_temp"
	run_root chmod 0644 "$keyring_temp"
	run_root curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt -o "$source_list_temp"
	run_root grep -Fq 'signed-by=/usr/share/keyrings/caddy-stable-archive-keyring.gpg' "$source_list_temp"
	run_root chmod 0644 "$source_list_temp"
	run_root mv -f "$keyring_temp" /usr/share/keyrings/caddy-stable-archive-keyring.gpg
	run_root mv -f "$source_list_temp" /etc/apt/sources.list.d/caddy-stable.list
	run_root apt-get update
	run_root apt-get install -y caddy
	run_root systemctl enable --now caddy
	run_root rm -f "$key_source_temp"
	ok "Caddy установлен"
	trap - EXIT
}

ensure_build_swap() {
	if [[ "$AUTO_SWAP" != "1" ]]; then
		warn "Автонастройка swap отключена"
		return
	fi
	if ! command -v swapon >/dev/null 2>&1 || ! command -v mkswap >/dev/null 2>&1; then
		warn "swapon/mkswap не найдены, пропускаю настройку swap"
		return
	fi

	local mem_total_mb swap_total_mb
	mem_total_mb="$(awk '/MemTotal/ { print int($2 / 1024) }' /proc/meminfo 2>/dev/null || printf '0')"
	swap_total_mb="$(awk '/SwapTotal/ { print int($2 / 1024) }' /proc/meminfo 2>/dev/null || printf '0')"
	if ((mem_total_mb >= SWAP_MIN_RAM_MB || swap_total_mb >= SWAP_MIN_EXISTING_MB)); then
		ok "Памяти для сборки достаточно"
		return
	fi

	log "Добавляю swap для сборки на малом VPS"
	if [[ ! -f "$SWAP_FILE" ]]; then
		run_root fallocate -l "${SWAP_SIZE_MB}M" "$SWAP_FILE" 2>/dev/null ||
			run_root dd if=/dev/zero of="$SWAP_FILE" bs=1M count="$SWAP_SIZE_MB"
		run_root chmod 600 "$SWAP_FILE"
		run_root mkswap "$SWAP_FILE"
	fi
	if ! swapon --show=NAME --noheadings | grep -qx "$SWAP_FILE"; then
		run_root swapon "$SWAP_FILE"
	fi
	if ! grep -q "^${SWAP_FILE}[[:space:]]" /etc/fstab 2>/dev/null; then
		printf '%s none swap sw 0 0\n' "$SWAP_FILE" | run_root tee -a /etc/fstab >/dev/null
	fi
	ok "Swap готов: ${SWAP_FILE}"
}

detect_public_host() {
	if [[ -n "$DOMAIN" ]]; then
		printf '%s' "$DOMAIN"
		return
	fi

	local ip
	ip="$(curl -fsS --max-time 3 https://api.ipify.org 2>/dev/null || true)"
	if [[ -z "$ip" ]]; then
		ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
	fi
	[[ -n "$ip" ]] || fail "Не удалось определить домен/IP. Запусти так: DOMAIN=example.com ./scripts/server-bootstrap.sh"
	printf '%s' "$ip"
}

is_ip_address() {
	[[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]
}

is_port_free() {
	local port="$1"
	if command -v ss >/dev/null 2>&1; then
		! ss -ltn "sport = :${port}" | awk 'NR > 1 { found = 1 } END { exit found ? 0 : 1 }'
		return
	fi
	if command -v lsof >/dev/null 2>&1; then
		! lsof -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1
		return
	fi
	! timeout 1 bash -c ":</dev/tcp/127.0.0.1/${port}" >/dev/null 2>&1
}

choose_port() {
	local preferred="$1"
	local start="$2"
	local current

	if is_port_free "$preferred"; then
		printf '%s' "$preferred"
		return
	fi

	for current in $(seq "$start" "$((start + 200))"); do
		if is_port_free "$current"; then
			printf '%s' "$current"
			return
		fi
	done

	fail "Не нашёл свободный порт рядом с ${start}"
}

random_hex() {
	openssl rand -hex "$1"
}

backup_file_once() {
	local file="$1"
	if [[ -f "$file" && ! -f "${file}.bootstrap.bak" ]]; then
		run_root cp "$file" "${file}.bootstrap.bak"
	fi
}

set_env_value() {
	local key="$1"
	local value="$2"
	local file="$ROOT_DIR/$ENV_FILE"
	if grep -q "^${key}=" "$file" 2>/dev/null; then
		local escaped
		escaped="$(printf '%s' "$value" | sed -e 's/[\/&]/\\&/g')"
		sed -i "s/^${key}=.*/${key}=${escaped}/" "$file"
	else
		printf '%s=%s\n' "$key" "$value" >>"$file"
	fi
}

set_env_if_missing() {
	local key="$1"
	local value="$2"
	local current=""
	if [[ -f "$ROOT_DIR/$ENV_FILE" ]]; then
		current="$(awk -F= -v key="$key" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$ROOT_DIR/$ENV_FILE")"
	fi
	if [[ -z "$current" || "$current" == your-secret-key-* ]]; then
		set_env_value "$key" "$value"
	fi
}

is_placeholder_env_value() {
	local value="$1"
	[[ -z "$value" ||
		"$value" == your-secret-key-* ||
		"$value" == *example.com* ||
		"$value" == *localhost* ||
		"$value" == *community.local* ||
		"$value" == "ИП [ФИО или юрлицо]" ||
		"$value" == "ИНН 000000000000" ||
		"$value" == "город регистрации" ]]
}

set_env_if_placeholder() {
	local key="$1"
	local value="$2"
	local current=""
	if [[ -f "$ROOT_DIR/$ENV_FILE" ]]; then
		current="$(awk -F= -v key="$key" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$ROOT_DIR/$ENV_FILE")"
	fi
	if is_placeholder_env_value "$current"; then
		set_env_value "$key" "$value"
	fi
}

detect_docker_gateway() {
	local gateway
	gateway="$(ip -4 addr show docker0 2>/dev/null | awk '/inet / { sub(/\/.*/, "", $2); print $2; exit }')"
	if [[ -n "$gateway" ]]; then
		printf '%s' "$gateway"
		return
	fi
	gateway="$(docker network inspect bridge --format '{{(index .IPAM.Config 0).Gateway}}' 2>/dev/null || true)"
	if [[ -n "$gateway" && "$gateway" != "<no value>" ]]; then
		printf '%s' "$gateway"
		return
	fi
	fail "Не удалось определить Docker gateway для domain helper"
}

get_env_value() {
	local key="$1"
	local file="$ROOT_DIR/$ENV_FILE"
	if [[ -f "$file" ]]; then
		awk -F= -v key="$key" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$file"
	fi
}

shell_quote() {
	local value="$1"
	printf "'%s'" "$(printf '%s' "$value" | sed "s/'/'\\\\''/g")"
}

existing_public_host_from_env() {
	local app_url host
	app_url="$(get_env_value APP_URL)"
	[[ -n "$app_url" ]] || return 0
	host="$(
		python3 - "$app_url" <<'PY' 2>/dev/null || true
from urllib.parse import urlparse
import sys

parsed = urlparse(sys.argv[1])
host = (parsed.hostname or "").lower()
if host in {"", "localhost", "0.0.0.0"} or host.startswith("127."):
    raise SystemExit(0)
print(host)
PY
	)"
	printf '%s' "$host"
}

install_club_cli() {
	local cli_source="$ROOT_DIR/scripts/club-cli.sh"
	local config_dir="/etc/community-club"
	local config_file="${config_dir}/club.conf"
	local temp_config

	if [[ ! -f "$cli_source" ]]; then
		warn "CLI club не найден в ${cli_source}, пропускаю установку команды"
		return
	fi

	log "Устанавливаю CLI club"
	run_root install -m 0755 "$cli_source" /usr/local/bin/club
	run_root mkdir -p "$config_dir"

	temp_config="$(mktemp)"
	{
		printf 'APP_DIR=%s\n' "$(shell_quote "$ROOT_DIR")"
		printf 'APP_NAME=%s\n' "$(shell_quote "$APP_NAME")"
		printf 'COMPOSE_PROJECT_NAME=%s\n' "$(shell_quote "$COMPOSE_PROJECT_NAME")"
		printf 'CONFIG_VERSION=1\n'
	} >"$temp_config"
	run_root install -m 0644 "$temp_config" "$config_file"
	rm -f "$temp_config"
	ok "CLI готов: club status"
}

choose_env_port() {
	local key="$1"
	local preferred="$2"
	local start="$3"
	local existing
	existing="$(get_env_value "$key")"
	if [[ -n "$existing" ]]; then
		printf '%s' "$existing"
		return
	fi
	choose_port "$preferred" "$start"
}

prepare_env() {
	local public_host="$1"
	local public_origin="$2"
	local web_port="$3"
	local api_port="$4"
	local admin_port="$5"
	local media_port="$6"
	local mail_smtp_port="$7"
	local mail_submission_port="$8"
	local mail_admin_port="$9"
	local admin_url="${public_origin}/admin"
	local media_url="${public_origin}/media"

	log "Готовлю .env проекта"
	cd "$ROOT_DIR"
	if [[ ! -f "$ENV_FILE" ]]; then
		cp .env.example "$ENV_FILE"
		ok "Создан $ENV_FILE из .env.example"
	else
		cp "$ENV_FILE" "${ENV_FILE}.bootstrap.bak.$(date +%Y%m%d%H%M%S)"
		ok "Сделан backup текущего $ENV_FILE"
	fi

	set_env_if_missing DB_USER "${APP_NAME//-/_}"
	local db_user
	db_user="$(awk -F= '$1=="DB_USER"{print $2; exit}' "$ENV_FILE")"
	db_user="${db_user:-community_club}"

	set_env_if_missing DB_PASSWORD "$(random_hex 24)"
	set_env_if_missing REDIS_PASSWORD "$(random_hex 24)"
	set_env_if_missing JWT_SECRET "$(random_hex 48)"

	local db_password redis_password
	db_password="$(awk -F= '$1=="DB_PASSWORD"{print $2; exit}' "$ENV_FILE")"
	redis_password="$(awk -F= '$1=="REDIS_PASSWORD"{print $2; exit}' "$ENV_FILE")"

	set_env_value DATABASE_URL "postgresql://${db_user}:${db_password}@postgres:5432/community_club"
	set_env_value REDIS_URL "redis://:${redis_password}@redis:6379"
	set_env_value APP_URL "$public_origin"
	set_env_value API_URL "$public_origin"
	set_env_value ADMIN_URL "$admin_url"
	set_env_value S3_ENDPOINT "http://garage:3900"
	set_env_value S3_REGION "garage"
	set_env_value S3_BUCKET_MEDIA "media"
	set_env_value S3_BUCKET_CHAT "chat-attachments"
	set_env_value S3_BUCKET_AVATARS "avatars"
	set_env_value S3_PUBLIC_URL "$media_url"
	local mail_domain mail_hostname
	if is_ip_address "$public_host"; then
		mail_domain="community.local"
		mail_hostname="mail.community.local"
	else
		mail_domain="$public_host"
		mail_hostname="mail.${public_host}"
	fi
	set_env_if_placeholder VAPID_EMAIL "mailto:support@${mail_domain}"
	set_env_if_missing MAIL_PROVIDER "log"
	set_env_if_placeholder MAIL_FROM_EMAIL "noreply@${mail_domain}"
	set_env_if_placeholder MAIL_REPLY_TO "support@${mail_domain}"
	set_env_if_placeholder MAIL_HOSTNAME "$mail_hostname"
	set_env_if_placeholder MAIL_CERTS_PATH "$ROOT_DIR/runtime/mail-certs"
	set_env_value WEB_HOST_PORT "$web_port"
	set_env_value API_HOST_PORT "$api_port"
	set_env_value ADMIN_HOST_PORT "$admin_port"
	set_env_value MEDIA_HOST_PORT "$media_port"
	set_env_value MAIL_SMTP_HOST_PORT "$mail_smtp_port"
	set_env_value MAIL_SUBMISSION_HOST_PORT "$mail_submission_port"
	set_env_value MAIL_ADMIN_HOST_PORT "$mail_admin_port"
	set_env_value DOMAIN_PROVISION_ENABLED "true"
	set_env_value DOMAIN_PROVISION_CONFIG_PATH "/etc/caddy/conf.d/${APP_NAME}-domains.caddy"
	set_env_value DOMAIN_PROVISION_VALIDATE_COMMAND "caddy validate --config /etc/caddy/Caddyfile"
	set_env_value DOMAIN_PROVISION_RELOAD_COMMAND "systemctl reload caddy"
	set_env_value DOMAIN_PROVISION_WEB_PORT "$web_port"
	set_env_value DOMAIN_PROVISION_API_PORT "$api_port"
	set_env_value DOMAIN_PROVISION_ADMIN_PORT "$admin_port"
	set_env_value DOMAIN_PROVISION_MEDIA_PORT "$media_port"
	set_env_value DOMAIN_PROVISION_HELPER_BIND "${DOMAIN_PROVISION_HELPER_BIND:-$(detect_docker_gateway)}"
	set_env_value DOMAIN_PROVISION_HELPER_PORT "${DOMAIN_PROVISION_HELPER_PORT:-7823}"
	set_env_if_missing DOMAIN_PROVISION_HELPER_TOKEN "$(random_hex 32)"
	local helper_port
	helper_port="$(get_env_value DOMAIN_PROVISION_HELPER_PORT)"
	set_env_value DOMAIN_PROVISION_HELPER_URL "http://host.docker.internal:${helper_port:-7823}/provision"

	mkdir -p "$ROOT_DIR/runtime/mail-certs" "$ROOT_DIR/secrets"
	ok ".env готов"
}

ensure_caddy_import() {
	log "Готовлю Caddy"
	run_root mkdir -p /etc/caddy/conf.d
	if [[ ! -f "$CADDYFILE_PATH" ]]; then
		printf '{\n\tservers {\n\t\ttimeouts {\n\t\t\tread_body 60m\n\t\t\tidle 60m\n\t\t}\n\t}\n}\n\nimport /etc/caddy/conf.d/*.caddy\n' |
			run_root tee "$CADDYFILE_PATH" >/dev/null
		ok "Создан $CADDYFILE_PATH"
		return
	fi

	if ! run_root grep -q 'import /etc/caddy/conf.d/\*.caddy' "$CADDYFILE_PATH"; then
		backup_file_once "$CADDYFILE_PATH"
		printf '\nimport /etc/caddy/conf.d/*.caddy\n' | run_root tee -a "$CADDYFILE_PATH" >/dev/null
		ok "В Caddyfile добавлен import /etc/caddy/conf.d/*.caddy"
	else
		ok "Caddyfile уже импортирует conf.d"
	fi
}

write_caddy_snippet() {
	local public_host="$1"
	local web_port="$2"
	local api_port="$3"
	local admin_port="$4"
	local media_port="$5"
	local site_label="$public_host"
	if is_ip_address "$public_host"; then
		site_label="http://${public_host}"
	fi

	cat <<CADDY | run_root tee "$CADDY_SNIPPET_PATH" >/dev/null
${site_label} {
	encode zstd gzip

	request_body {
		max_size 3GB
	}

	handle /api/* {
		reverse_proxy 127.0.0.1:${api_port} {
			header_up X-Real-IP {remote_host}
			header_up X-Forwarded-For {remote_host}
			header_up X-Forwarded-Proto {scheme}
		}
	}

	handle /health {
		reverse_proxy 127.0.0.1:${api_port}
	}

	handle /admin* {
		reverse_proxy 127.0.0.1:${admin_port}
	}

	handle /media/* {
		uri strip_prefix /media
		reverse_proxy 127.0.0.1:${media_port} {
			header_up Host media
			flush_interval -1
		}
	}

	handle /avatars/* {
		uri strip_prefix /avatars
		reverse_proxy 127.0.0.1:${media_port} {
			header_up Host avatars
			flush_interval -1
		}
	}

	handle /chat-media/* {
		uri strip_prefix /chat-media
		reverse_proxy 127.0.0.1:${media_port} {
			header_up Host chat-attachments
			flush_interval -1
		}
	}

	handle {
		reverse_proxy 127.0.0.1:${web_port}
	}
}
CADDY

	run_root caddy validate --config "$CADDYFILE_PATH"
	run_root systemctl reload caddy
	ok "Caddy snippet записан: $CADDY_SNIPPET_PATH"
}

install_caddy_domain_helper() {
	log "Готовлю helper для подключения домена из админки"
	local helper_bind helper_port unit_path
	helper_bind="${DOMAIN_PROVISION_HELPER_BIND:-$(detect_docker_gateway)}"
	helper_port="${DOMAIN_PROVISION_HELPER_PORT:-7823}"
	if [[ "$helper_bind" == "127.0.0.1" || "$helper_bind" == "::1" ]]; then
		fail "DOMAIN_PROVISION_HELPER_BIND не должен быть loopback: контейнер API не достучится до helper"
	fi
	unit_path="/etc/systemd/system/${APP_NAME}-domain-helper.service"

	run_root tee "$unit_path" >/dev/null <<UNIT
[Unit]
Description=Community Club Caddy domain helper
After=network-online.target caddy.service docker.service
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${ROOT_DIR}
EnvironmentFile=${ROOT_DIR}/${ENV_FILE}
Environment=CADDYFILE_PATH=${CADDYFILE_PATH}
Environment=DOMAIN_PROVISION_HELPER_BIND=${helper_bind}
Environment=DOMAIN_PROVISION_HELPER_PORT=${helper_port}
ExecStart=/usr/bin/python3 ${ROOT_DIR}/scripts/caddy-domain-helper.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

	run_root systemctl daemon-reload
	run_root systemctl enable --now "${APP_NAME}-domain-helper.service"
	for _ in $(seq 1 10); do
		if curl -fsS "http://${helper_bind}:${helper_port}/health" >/dev/null 2>&1; then
			ok "Domain helper слушает ${helper_bind}:${helper_port}"
			return
		fi
		sleep 1
	done
	run_root systemctl status "${APP_NAME}-domain-helper.service" --no-pager || true
	fail "Domain helper не ответил на health-check"
}

configure_firewall() {
	if [[ "$ENABLE_FIREWALL" != "1" ]]; then
		return
	fi
	if ! command -v ufw >/dev/null 2>&1; then
		ensure_apt_packages ufw
	fi
	run_root ufw allow OpenSSH || true
	run_root ufw allow 80/tcp || true
	run_root ufw allow 443/tcp || true
	run_root ufw --force enable || true
}

compose_up_base() {
	log "Поднимаю базовые контейнеры"
	cd "$ROOT_DIR"
	docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" up -d postgres redis
	ok "Postgres и Redis запущены"
}

apply_database_schema() {
	log "Создаю схемы и таблицы БД"
	cd "$ROOT_DIR"
	if [[ "$SKIP_APP_BUILD" != "1" ]]; then
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" build api
	fi
	docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" run --rm \
		-e DRIZZLE_PUSH_FORCE \
		api sh -lc '
cd /app/packages/api
status=0
if [ "${DRIZZLE_PUSH_FORCE:-1}" = "1" ]; then
	output="$(bunx drizzle-kit push --config drizzle.config.ts --force 2>&1)" || status=$?
else
	output="$(bunx drizzle-kit push --config drizzle.config.ts 2>&1)" || status=$?
fi
printf "%s\n" "$output"
if printf "%s\n" "$output" | grep -E '\''(^|[[:space:]])error:'\'' >/dev/null; then
	exit 1
fi
exit "$status"
'
	ok "Схема БД применена"
}

ensure_vapid_keys() {
	local current_public current_private
	current_public="$(get_env_value VAPID_PUBLIC_KEY)"
	current_private="$(get_env_value VAPID_PRIVATE_KEY)"
	if [[ -n "$current_public" && -n "$current_private" ]]; then
		ok "VAPID ключи для push уже есть"
		return
	fi

	log "Генерирую VAPID ключи для push-уведомлений"
	cd "$ROOT_DIR"
	local key_json public_key private_key
	key_json="$(
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" run --rm api \
			bun -e 'import webPush from "web-push"; console.log(JSON.stringify(webPush.generateVAPIDKeys()))' |
			tail -n 1
	)"
	public_key="$(printf '%s' "$key_json" | python3 -c 'import json,sys; print(json.load(sys.stdin)["publicKey"])')"
	private_key="$(printf '%s' "$key_json" | python3 -c 'import json,sys; print(json.load(sys.stdin)["privateKey"])')"
	[[ -n "$public_key" && -n "$private_key" ]] || fail "Не удалось сгенерировать VAPID ключи"
	set_env_value VAPID_PUBLIC_KEY "$public_key"
	set_env_value VAPID_PRIVATE_KEY "$private_key"
	ok "VAPID ключи записаны в $ENV_FILE"
}

init_garage() {
	if [[ "$SKIP_GARAGE_INIT" == "1" ]]; then
		warn "Garage init пропущен"
		return
	fi
	log "Инициализирую Garage"
	cd "$ROOT_DIR"
	bash scripts/garage-init.sh "$COMPOSE_FILE"
	local public_origin="$1"
	set_env_value S3_PUBLIC_URL "${public_origin}/media"
	ok "Garage готов"
}

build_and_start_app() {
	log "Собираю и запускаю приложение"
	cd "$ROOT_DIR"
	if [[ "$SKIP_APP_BUILD" == "1" ]]; then
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" up -d
	else
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" build api
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" build web
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" build admin
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" up -d
	fi
	ok "Контейнеры приложения запущены"
}

default_admin_email() {
	local public_host="$1"
	if is_ip_address "$public_host"; then
		printf 'admin@community.local'
	else
		printf 'admin@%s' "$public_host"
	fi
}

ensure_initial_admin() {
	local public_host="$1"
	local public_origin="$2"
	local credentials_file="$ROOT_DIR/secrets/initial_admin_credentials"
	local admin_email="${ADMIN_EMAIL:-$(default_admin_email "$public_host")}"
	local admin_password="$ADMIN_PASSWORD"

	log "Готовлю первый доступ в админку"
	cd "$ROOT_DIR"
	if [[ -z "$admin_password" && -f "$credentials_file" ]]; then
		admin_password="$(awk -F': ' '$1=="password"{print $2; exit}' "$credentials_file")"
	fi
	if [[ -z "$admin_password" ]]; then
		admin_password="$(openssl rand -base64 24 | tr -d '\n' | cut -c1-24)"
	fi

	ADMIN_EMAIL_VALUE="$admin_email" ADMIN_PASSWORD_VALUE="$admin_password" \
		docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" run --rm \
			-e ADMIN_EMAIL_VALUE \
			-e ADMIN_PASSWORD_VALUE \
			api bun -e '
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "@community-club/shared/db/schema";
import { users } from "@community-club/shared/db/schema";

const email = process.env.ADMIN_EMAIL_VALUE?.trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD_VALUE;
if (!email || !password) throw new Error("ADMIN_EMAIL_VALUE and ADMIN_PASSWORD_VALUE are required");

const sql = postgres(process.env.DATABASE_URL, { max: 1 });
const db = drizzle(sql, { schema });
const passwordHash = await Bun.password.hash(password, { algorithm: "bcrypt", cost: 12 });
const existing = await db.query.users.findFirst({ where: eq(users.email, email) });

if (existing) {
	await db.update(users).set({
		role: "superadmin",
		authType: "email",
		passwordHash,
		fullName: existing.fullName ?? "Владелец",
		chatAdminBadge: true,
	}).where(eq(users.email, email));
} else {
	await db.insert(users).values({
		email,
		fullName: "Владелец",
		role: "superadmin",
		authType: "email",
		passwordHash,
		chatAdminBadge: true,
	});
}

await sql.end();
'

	{
		printf 'url: %s\n' "${public_origin}/admin"
		printf 'email: %s\n' "$admin_email"
		printf 'password: %s\n' "$admin_password"
	} >"$credentials_file"
	chmod 600 "$credentials_file"
	ok "Первый администратор готов"
}

wait_for_http() {
	local url="$1"
	local label="$2"
	for _ in $(seq 1 30); do
		if curl -fsS -o /dev/null "$url" 2>/dev/null; then
			ok "$label отвечает"
			return
		fi
		sleep 2
	done
	fail "$label не ответил: $url"
}

verify_public_app() {
	local public_origin="$1"
	local temp_dir health_file page_file asset_path asset_url asset_file asset_headers manifest_file manifest_headers
	temp_dir="$(mktemp -d)"
	health_file="${temp_dir}/health.json"
	page_file="${temp_dir}/index.html"
	asset_file="${temp_dir}/asset.js"
	asset_headers="${temp_dir}/asset.headers"
	manifest_file="${temp_dir}/manifest.json"
	manifest_headers="${temp_dir}/manifest.headers"

	local health_ok=0
	for _ in $(seq 1 30); do
		if curl -fsS "${public_origin}/health" -o "$health_file" 2>/dev/null &&
			python3 - "$health_file" <<'PY' 2>/dev/null
import json
import sys

with open(sys.argv[1], encoding="utf-8") as file:
    payload = json.load(file)
raise SystemExit(0 if payload.get("status") == "ok" else 1)
PY
		then
			health_ok=1
			break
		fi
		sleep 2
	done
	if [[ "$health_ok" != "1" ]]; then
		rm -rf "$temp_dir"
		fail "Публичный /health не вернул ожидаемый JSON: ${public_origin}/health"
	fi

	if ! curl -fsS "${public_origin}/" -o "$page_file"; then
		rm -rf "$temp_dir"
		fail "Главная страница недоступна: ${public_origin}/"
	fi
	asset_path="$(python3 - "$page_file" <<'PY'
import re
import sys

with open(sys.argv[1], encoding="utf-8") as file:
    html = file.read()
match = re.search(r'["\']([^"\']*/_nuxt/[^"\']+\.js(?:\?[^"\']*)?)["\']', html)
if match:
    print(match.group(1))
PY
)"
	if [[ -z "$asset_path" ]]; then
		rm -rf "$temp_dir"
		fail "Главная страница не содержит /_nuxt/ JavaScript"
	fi
	asset_url="$(python3 - "$public_origin" "$asset_path" <<'PY'
import sys
from urllib.parse import urljoin

print(urljoin(sys.argv[1] + "/", sys.argv[2]))
PY
)"
	if ! curl -fsS -D "$asset_headers" "$asset_url" -o "$asset_file" ||
		[[ ! -s "$asset_file" ]] ||
		! grep -Eiq '^content-type:[[:space:]]*[^[:space:]]*javascript' "$asset_headers"; then
		rm -rf "$temp_dir"
		fail "Nuxt JavaScript не загрузился корректно: $asset_url"
	fi

	if ! curl -fsS -D "$manifest_headers" "${public_origin}/pwa-manifest" -o "$manifest_file" ||
		[[ ! -s "$manifest_file" ]] ||
		! grep -Eiq '^content-type:[[:space:]]*application/manifest\+json' "$manifest_headers" ||
		! python3 - "$manifest_file" <<'PY' 2>/dev/null
import json
import sys

with open(sys.argv[1], encoding="utf-8") as file:
    payload = json.load(file)
valid = isinstance(payload.get("name"), str) and isinstance(payload.get("start_url"), str)
raise SystemExit(0 if valid else 1)
PY
	then
		rm -rf "$temp_dir"
		fail "PWA manifest не загрузился корректно: ${public_origin}/pwa-manifest"
	fi

	rm -rf "$temp_dir"
	ok "Публичные health, Nuxt JavaScript и PWA manifest работают"
}

smoke_check() {
	local public_origin="$1"
	log "Проверяю запуск"
	cd "$ROOT_DIR"
	docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" ps

	local health
	local api_ok=0
	for _ in $(seq 1 30); do
		health="$(curl -fsS "http://127.0.0.1:${API_HOST_PORT:-3001}/health" 2>/dev/null || true)"
		if [[ "$health" == *'"status":"ok"'* ]]; then
			ok "API health ok"
			api_ok=1
			break
		fi
		sleep 2
	done
	[[ "$api_ok" == "1" ]] || fail "API не ответил на health-check"

	wait_for_http "http://127.0.0.1:${WEB_HOST_PORT:-3000}/" "Web"
	wait_for_http "http://127.0.0.1:${ADMIN_HOST_PORT:-3002}/admin/" "Admin"
	curl -fsS -o /dev/null "http://127.0.0.1:${API_HOST_PORT:-3001}/api/payments/tariffs?pricingContext=active" || warn "Тарифы пока не ответили"
	curl -fsS -o /dev/null "http://127.0.0.1:${API_HOST_PORT:-3001}/api/payments/settings" || warn "Настройки оплаты пока не ответили"
	verify_public_app "$public_origin"
}

print_result() {
	local public_origin="$1"
	local public_host="$2"
	local credentials_file="$ROOT_DIR/secrets/initial_admin_credentials"
	local admin_email=""
	local admin_password=""
	if [[ -f "$credentials_file" ]]; then
		admin_email="$(awk -F': ' '$1=="email"{print $2; exit}' "$credentials_file")"
		admin_password="$(awk -F': ' '$1=="password"{print $2; exit}' "$credentials_file")"
	fi
	cat <<OUT

Готово.

Приложение: ${public_origin}
Админка:    ${public_origin}/admin
API:        ${public_origin}/health
Медиа:      ${public_origin}/media

Первый вход в админку:
- email:  ${admin_email:-$(default_admin_email "$public_host")}
- пароль: ${admin_password:-смотри ${credentials_file}}

Файлы:
- env:          ${ROOT_DIR}/${ENV_FILE}
- compose:      ${ROOT_DIR}/${COMPOSE_FILE}
- caddy:        ${CADDY_SNIPPET_PATH}
- admin creds:  ${credentials_file}
- caddy backup: ${CADDYFILE_PATH}.bootstrap.bak, если Caddyfile менялся

CLI:
- статус установки: club status
- контекст проекта: club context
- управление настройками: club admin --help

Повторный запуск этой команды безопасен: существующие секреты и данные не удаляются.
OUT
}

main() {
	cd "$ROOT_DIR"
	[[ -f "$COMPOSE_FILE" ]] || fail "Запусти скрипт из проекта или проверь COMPOSE_FILE"

	detect_os
	install_base_dependencies
	install_docker
	install_caddy
	ensure_build_swap

	local public_host public_origin existing_public_host
	existing_public_host=""
	if [[ -z "$DOMAIN" ]]; then
		existing_public_host="$(existing_public_host_from_env)"
	fi
	if [[ -n "$existing_public_host" ]]; then
		public_host="$existing_public_host"
		ok "Использую текущий APP_URL из .env: ${public_host}"
	else
		public_host="$(detect_public_host)"
	fi
	if is_ip_address "$public_host"; then
		public_origin="http://${public_host}"
	else
		public_origin="https://${public_host}"
	fi
	local web_port api_port admin_port media_port mail_smtp_port mail_submission_port mail_admin_port
	web_port="$(choose_env_port WEB_HOST_PORT "${WEB_HOST_PORT:-3000}" 3100)"
	api_port="$(choose_env_port API_HOST_PORT "${API_HOST_PORT:-3001}" 3101)"
	admin_port="$(choose_env_port ADMIN_HOST_PORT "${ADMIN_HOST_PORT:-3002}" 3102)"
	media_port="$(choose_env_port MEDIA_HOST_PORT "${MEDIA_HOST_PORT:-3902}" 3912)"
	mail_smtp_port="$(choose_env_port MAIL_SMTP_HOST_PORT "${MAIL_SMTP_HOST_PORT:-25}" 2525)"
	mail_submission_port="$(choose_env_port MAIL_SUBMISSION_HOST_PORT "${MAIL_SUBMISSION_HOST_PORT:-587}" 2587)"
	mail_admin_port="$(choose_env_port MAIL_ADMIN_HOST_PORT "${MAIL_ADMIN_HOST_PORT:-8080}" 8180)"

	export WEB_HOST_PORT="$web_port"
	export API_HOST_PORT="$api_port"
	export ADMIN_HOST_PORT="$admin_port"
	export MEDIA_HOST_PORT="$media_port"
	export MAIL_SMTP_HOST_PORT="$mail_smtp_port"
	export MAIL_SUBMISSION_HOST_PORT="$mail_submission_port"
	export MAIL_ADMIN_HOST_PORT="$mail_admin_port"

	prepare_env "$public_host" "$public_origin" "$web_port" "$api_port" "$admin_port" "$media_port" "$mail_smtp_port" "$mail_submission_port" "$mail_admin_port"
	ensure_caddy_import
	write_caddy_snippet "$public_host" "$web_port" "$api_port" "$admin_port" "$media_port"
	install_caddy_domain_helper
	configure_firewall
	init_garage "$public_origin"
	compose_up_base
	apply_database_schema
	ensure_vapid_keys
	ensure_initial_admin "$public_host" "$public_origin"
	build_and_start_app
	smoke_check "$public_origin"
	install_club_cli
	print_result "$public_origin" "$public_host"
}

main "$@"
