import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const scriptPath = new URL('./server-bootstrap.sh', import.meta.url)

describe('server bootstrap', () => {
	test('applies database schema non-interactively during install', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('DRIZZLE_PUSH_FORCE')
		expect(script).toContain('drizzle-kit push --config drizzle.config.ts --force')
		expect(script).toContain('grep -E')
		expect(script).toContain('(^|[[:space:]])error:')
	})

	test('installs retained CLI config without obsolete distribution metadata', async () => {
		const script = await readFile(scriptPath, 'utf8')
		const installCli = script.slice(
			script.indexOf('install_club_cli()'),
			script.indexOf('choose_env_port()'),
		)

		expect(installCli).toContain("printf 'APP_DIR=%s\\n'")
		expect(installCli).toContain("printf 'APP_NAME=%s\\n'")
		expect(installCli).toContain("printf 'COMPOSE_PROJECT_NAME=%s\\n'")
		expect(installCli).not.toContain('SOURCE_ORIGIN')
		expect(installCli).not.toContain('INSTALL_EMAIL')
		expect(installCli).not.toContain('read_source_marker_value')
	})

	test('replaces example mail and push placeholders during bootstrap', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('set_env_if_placeholder VAPID_EMAIL')
		expect(script).toContain('set_env_if_placeholder MAIL_FROM_EMAIL')
		expect(script).toContain('set_env_if_placeholder MAIL_HOSTNAME')
		expect(script).toContain('mail.community.local')
		expect(script).toContain('coreutils')
	})

	test('proxies every unmatched path to web instead of only the root path', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toMatch(/handle \{\s+reverse_proxy 127\.0\.0\.1:\$\{web_port\}\s+\}/)
		expect(script).not.toContain('reverse_proxy / 127.0.0.1:${web_port}')
	})

	test('fails installation unless public health, Nuxt asset, and manifest are valid', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('verify_public_app')
		expect(script).toContain('/pwa-manifest')
		expect(script).toContain('/_nuxt/')
		expect(script).toContain('application/manifest\\+json')
		expect(script).toContain('javascript')
		expect(script).not.toContain('Публичная ссылка пока не ответила')
	})
})
