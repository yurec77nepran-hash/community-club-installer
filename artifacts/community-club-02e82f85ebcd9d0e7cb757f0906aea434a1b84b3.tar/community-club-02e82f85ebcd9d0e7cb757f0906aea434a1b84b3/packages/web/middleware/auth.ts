export default defineNuxtRouteMiddleware(async (to) => {
	// Только на клиенте — на сервере нет localStorage
	if (!import.meta.client) return

	const auth = useAuthStore()
	const isMaterialRoute = /^\/app\/content(?:\/[^/]+){1,2}$/.test(to.path)
	const publicAppRoutes = new Set([
		'/app',
		'/app/materials',
		'/app/payment',
		'/app/payment-off',
		'/app/legal/requisites',
		'/app/legal/privacy-policy',
		'/app/legal/oferta',
	])
	const isPublicAppRoute = publicAppRoutes.has(to.path)

	if (!auth.user) {
		await auth.restoreSession()
	}

	if (!auth.user && to.path.startsWith('/app') && !isPublicAppRoute && !isMaterialRoute) {
		return navigateTo({
			path: '/app',
			query: { access: 'required', redirect: to.fullPath },
		})
	}
})
