const isTelegramBindingRequired = false

export default defineNuxtRouteMiddleware(async (to) => {
	if (!import.meta.client) {
		return
	}

	const auth = useAuthStore()
	if (!auth.user) {
		await auth.restoreSession()
	}

	if (!auth.isAuthenticated) {
		const isMaterialRoute = /^\/app\/content\/[^/]+(?:\/[^/]+)?$/.test(to.path)
		const isMaterialDetailRoute = /^\/app\/content\/[^/]+\/[^/]+$/.test(to.path)
		if (isMaterialRoute) {
			const guestAccess = await useApi().get<{ level: 'sections' | 'cards' | 'preview' }>(
				'/api/site-settings/guest-content-access',
				{ authRedirect: false },
			)
			if (
				guestAccess.success &&
				(guestAccess.data.level === 'preview' ||
					(!isMaterialDetailRoute && guestAccess.data.level !== 'sections'))
			)
				return
		}

		return navigateTo({
			path: '/app',
			query: { access: 'required', redirect: to.fullPath },
		})
	}

	// Админы и суперадмины — всегда доступ
	if (auth.isAdmin) return

	// Страница ручной оплаты доступна без подписки
	if (to.path === '/app/payment-off') return

	const subscriptionStore = useSubscriptionStore()
	subscriptionStore.hydrateSnapshot()
	const subscription =
		subscriptionStore.loadedAt > 0
			? subscriptionStore.subscription
			: await subscriptionStore.fetchSubscription()
	if (!subscription) {
		return navigateTo({
			path: '/app',
			query: { access: 'required', redirect: to.fullPath },
		})
	}

	if (!subscription.dateFinish) {
		return navigateTo({
			path: '/app',
			query: { access: 'required', redirect: to.fullPath },
		})
	}

	if (!subscriptionStore.hasActiveSubscription) {
		return navigateTo({
			path: '/app',
			query: { access: 'required', redirect: to.fullPath },
		})
	}

	// Требование привязки временно отключено, пока авторизация через Telegram не используется
	if (isTelegramBindingRequired && !auth.user?.telegramChatId && to.path !== '/app/telegram-bind') {
		return navigateTo({
			path: '/app/telegram-bind',
			query: { redirect: to.fullPath },
		})
	}
})
