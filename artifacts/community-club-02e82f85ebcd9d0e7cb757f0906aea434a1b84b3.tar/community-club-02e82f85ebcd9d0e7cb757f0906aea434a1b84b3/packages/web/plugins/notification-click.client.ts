import { normalizeNotificationClickUrl } from '~/utils/notification-routing'

export default defineNuxtPlugin(() => {
	if (!('serviceWorker' in navigator)) return

	const router = useRouter()

	navigator.serviceWorker.addEventListener('message', (event) => {
		const data = event.data
		if (!data || data.type !== 'COMMUNITY_NOTIFICATION_CLICK') return

		const url = normalizeNotificationClickUrl(data.url, window.location.origin)
		if (!url) return

		router.push(url).catch(() => {})
	})
})
