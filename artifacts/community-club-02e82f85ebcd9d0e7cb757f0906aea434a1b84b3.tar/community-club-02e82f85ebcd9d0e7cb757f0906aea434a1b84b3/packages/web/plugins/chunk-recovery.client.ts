function handleServiceWorkerUpdateError(error: unknown): void {
	if (error instanceof TypeError) return
	if (error instanceof DOMException) {
		switch (error.name) {
			case 'AbortError':
			case 'InvalidStateError':
			case 'NetworkError':
				return
		}
	}
	throw error
}

export default defineNuxtPlugin(() => {
	if (!import.meta.client) return

	const reloadGuardKey = 'pwa-recovery-reloaded'

	async function hardReloadOnce() {
		if (sessionStorage.getItem(reloadGuardKey) === '1') {
			return
		}

		sessionStorage.setItem(reloadGuardKey, '1')

		try {
			if ('serviceWorker' in navigator) {
				const registrations = await navigator.serviceWorker.getRegistrations()
				await Promise.all(
					registrations.map((registration) =>
						registration.update().then(() => undefined, handleServiceWorkerUpdateError),
					),
				)
			}
		} finally {
			window.location.reload()
		}
	}

	window.addEventListener('vite:preloadError', async (event) => {
		event.preventDefault()
		await hardReloadOnce()
	})

	window.addEventListener('error', async (event) => {
		const target = event.target
		if (!(target instanceof HTMLScriptElement)) return
		await hardReloadOnce()
	})

	window.addEventListener('unhandledrejection', async (event) => {
		const reason =
			typeof event.reason === 'string'
				? event.reason
				: event.reason instanceof Error
					? event.reason.message
					: ''

		if (
			reason.includes('Failed to fetch dynamically imported module') ||
			reason.includes('Importing a module script failed') ||
			reason.includes('Unable to preload CSS')
		) {
			await hardReloadOnce()
		}
	})
})
