import { registerSW } from 'virtual:pwa-register'
import { createPwaUpdateManager } from '~/utils/pwa-update'

const RELOAD_GUARD_KEY = 'pwa-update-reload-source-build'

function handleServiceWorkerUpdateError(error: unknown): void {
	if (error instanceof TypeError) return
	if (error instanceof DOMException) {
		switch (error.name) {
			case 'AbortError':
			case 'InvalidStateError':
			case 'NetworkError':
				return
		}
	}
	throw error
}

export default defineNuxtPlugin(() => {
	if (!('serviceWorker' in navigator)) return

	let isControlled = navigator.serviceWorker.controller !== null
	const manager = createPwaUpdateManager({
		environment: {
			deleteCache: () => Promise.resolve(false),
			getReloadGuard: () => sessionStorage.getItem(RELOAD_GUARD_KEY),
			reload: () => window.location.reload(),
			retiredCacheNames: [],
			setReloadGuard: (sourceBuildId) => sessionStorage.setItem(RELOAD_GUARD_KEY, sourceBuildId),
		},
		sourceBuildId: useRuntimeConfig().app.buildId,
		startedControlled: isControlled,
	})

	navigator.serviceWorker.addEventListener('controllerchange', () => {
		void manager.onControllerChange()
		isControlled = true
	})

	registerSW({
		immediate: true,
		onNeedRefresh: () => {
			void manager.onNeedReload()
		},
		onRegisteredSW: (_scriptUrl, registration) => {
			if (!registration) return

			let updateInFlight: Promise<void> | null = null
			const checkForUpdate = (): Promise<void> => {
				if (updateInFlight) return updateInFlight

				updateInFlight = registration
					.update()
					.then(() => undefined, handleServiceWorkerUpdateError)
					.finally(() => {
						updateInFlight = null
					})
				return updateInFlight
			}

			let wasHidden = document.visibilityState === 'hidden'
			document.addEventListener('visibilitychange', () => {
				const isHidden = document.visibilityState === 'hidden'
				if (isControlled && wasHidden && !isHidden) void checkForUpdate()
				wasHidden = isHidden
			})

			if (isControlled) void checkForUpdate()
		},
	})
})
