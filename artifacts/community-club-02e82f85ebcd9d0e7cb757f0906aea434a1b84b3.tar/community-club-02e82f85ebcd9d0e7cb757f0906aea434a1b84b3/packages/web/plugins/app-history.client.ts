import { peekPreviousAppRoute, recordAppRoute, trimAppHistoryTo } from '~/composables/useAppBack'

export default defineNuxtPlugin((nuxtApp) => {
	const router = useRouter()

	const rememberCurrentRoute = (fullPath: string, path: string) => {
		if (!path.startsWith('/app')) return
		recordAppRoute({ fullPath, path })
	}

	nuxtApp.hook('app:mounted', () => {
		rememberCurrentRoute(router.currentRoute.value.fullPath, router.currentRoute.value.path)

		let touchStartX = 0
		let touchStartY = 0
		let trackingEdgeSwipe = false

		const isInteractiveTarget = (target: EventTarget | null) => {
			if (!(target instanceof HTMLElement)) return false
			return Boolean(
				target.closest(
					'input, textarea, select, button, a, video, audio, [data-no-app-swipe-back]',
				),
			)
		}

		const onTouchStart = (event: TouchEvent) => {
			if (event.touches.length !== 1) return
			if (isInteractiveTarget(event.target)) return

			const touch = event.touches[0]
			touchStartX = touch.clientX
			touchStartY = touch.clientY
			trackingEdgeSwipe = touchStartX <= 24
		}

		const onTouchEnd = async (event: TouchEvent) => {
			if (!trackingEdgeSwipe) return

			const touch = event.changedTouches[0]
			const deltaX = touch.clientX - touchStartX
			const deltaY = Math.abs(touch.clientY - touchStartY)
			trackingEdgeSwipe = false

			if (deltaX < 90 || deltaY > 72) return

			const currentRoute = router.currentRoute.value
			const previous = peekPreviousAppRoute(currentRoute.fullPath)
			if (!previous) return

			trimAppHistoryTo(previous.fullPath)
			await navigateTo(previous.fullPath, { replace: true })
		}

		document.addEventListener('touchstart', onTouchStart, { passive: true })
		document.addEventListener('touchend', onTouchEnd, { passive: true })

		nuxtApp.hook('app:unmounted', () => {
			document.removeEventListener('touchstart', onTouchStart)
			document.removeEventListener('touchend', onTouchEnd)
		})
	})

	router.afterEach((to) => {
		rememberCurrentRoute(to.fullPath, to.path)
	})
})
