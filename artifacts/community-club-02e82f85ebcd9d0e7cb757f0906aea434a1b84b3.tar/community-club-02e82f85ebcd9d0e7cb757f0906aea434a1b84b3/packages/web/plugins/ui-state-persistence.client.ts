type StoreSnapshot = Record<string, unknown>
const pendingSnapshotWrites = new Map<string, string>()
const pendingSnapshotJobs = new Map<string, number>()

function flushSnapshotWrite(key: string) {
	const payload = pendingSnapshotWrites.get(key)
	if (!payload) return

	pendingSnapshotWrites.delete(key)
	pendingSnapshotJobs.delete(key)

	try {
		sessionStorage.setItem(key, payload)
	} catch {}
}

function scheduleSnapshotWrite(key: string, value: StoreSnapshot) {
	try {
		pendingSnapshotWrites.set(key, JSON.stringify(value))
	} catch {
		return
	}

	const existingJob = pendingSnapshotJobs.get(key)
	if (existingJob !== undefined) {
		if ('cancelIdleCallback' in window) {
			window.cancelIdleCallback(existingJob)
		} else {
			window.clearTimeout(existingJob)
		}
	}

	if ('requestIdleCallback' in window) {
		const job = window.requestIdleCallback(() => flushSnapshotWrite(key), {
			timeout: 400,
		})
		pendingSnapshotJobs.set(key, job)
		return
	}

	const job = window.setTimeout(() => flushSnapshotWrite(key), 120)
	pendingSnapshotJobs.set(key, job)
}

function flushAllSnapshotWrites() {
	for (const key of pendingSnapshotWrites.keys()) {
		flushSnapshotWrite(key)
	}
}

function readSnapshot<T extends StoreSnapshot>(key: string): T | null {
	try {
		const raw = sessionStorage.getItem(key)
		if (!raw) return null
		return JSON.parse(raw) as T
	} catch {
		return null
	}
}

function takeNewestEntries<T extends { loadedAt: number }>(
	record: Record<string, T>,
	limit: number,
): Record<string, T> {
	return Object.fromEntries(
		Object.entries(record)
			.sort(([, left], [, right]) => right.loadedAt - left.loadedAt)
			.slice(0, limit),
	)
}

async function setupStatePersistence(routePath: string) {
	const [
		{ useHomeStore },
		{ useEventsStore },
		{ useChannelStore },
		{ useMaterialsStore },
		{ useChatStore },
	] = await Promise.all([
		import('~/stores/home'),
		import('~/stores/events'),
		import('~/stores/channel'),
		import('~/stores/materials'),
		import('~/stores/chat'),
	])

	const homeStore = useHomeStore()
	const eventsStore = useEventsStore()
	const channelStore = useChannelStore()
	const materialsStore = useMaterialsStore()
	const chatStore = useChatStore()

	const homeSnapshot = readSnapshot<{ snapshot: typeof homeStore.snapshot; loadedAt: number }>(
		'ui-persist:home',
	)
	if (homeSnapshot && routePath.startsWith('/app')) {
		homeStore.$patch(homeSnapshot)
	}

	const eventsSnapshot = readSnapshot<{
		byMonth: typeof eventsStore.byMonth
		loadedAt: typeof eventsStore.loadedAt
	}>('ui-persist:events')
	if (
		eventsSnapshot &&
		(routePath.startsWith('/app/events') || routePath.startsWith('/app/calendar'))
	) {
		eventsStore.$patch({
			byMonth: eventsSnapshot.byMonth,
			loadedAt: eventsSnapshot.loadedAt,
		})
	}

	const channelSnapshot = readSnapshot<{
		posts: typeof channelStore.posts
		nextCursor: typeof channelStore.nextCursor
		loadedAt: number
	}>('ui-persist:channel')
	if (channelSnapshot && routePath.startsWith('/app/channel')) {
		channelStore.$patch(channelSnapshot)
	}

	const materialsSnapshot = readSnapshot<{
		subsections: typeof materialsStore.subsections
		details: typeof materialsStore.details
		media: typeof materialsStore.media
	}>('ui-persist:materials')
	if (materialsSnapshot && routePath.startsWith('/app/content')) {
		materialsStore.$patch({
			subsections: materialsSnapshot.subsections,
			details: materialsSnapshot.details,
			media: materialsSnapshot.media,
		})
	}

	const chatSnapshot = readSnapshot<{
		chats: typeof chatStore.chats
		chatsLoadedAt: number
		mentionCandidates: typeof chatStore.mentionCandidates
		mentionCandidatesLoadedAt: typeof chatStore.mentionCandidatesLoadedAt
	}>('ui-persist:chat')
	if (chatSnapshot && routePath.startsWith('/app')) {
		const hasNewerRuntimeChats =
			chatStore.chats.length > 0 && chatStore.chatsLoadedAt > chatSnapshot.chatsLoadedAt
		if (!hasNewerRuntimeChats) {
			chatStore.setChats(chatSnapshot.chats, { preserveUnreadCounts: true })
		}
		chatStore.$patch({
			chatsLoadedAt: Math.max(chatStore.chatsLoadedAt, chatSnapshot.chatsLoadedAt),
			mentionCandidates: chatSnapshot.mentionCandidates,
			mentionCandidatesLoadedAt: chatSnapshot.mentionCandidatesLoadedAt,
		})
	}

	watch(
		() => ({
			snapshot: homeStore.snapshot,
			loadedAt: homeStore.loadedAt,
		}),
		(value) => scheduleSnapshotWrite('ui-persist:home', value),
		{ deep: true },
	)

	watch(
		() => ({
			byMonth: eventsStore.byMonth,
			loadedAt: eventsStore.loadedAt,
		}),
		(value) => scheduleSnapshotWrite('ui-persist:events', value),
		{ deep: true },
	)

	watch(
		() => ({
			posts: channelStore.posts,
			nextCursor: channelStore.nextCursor,
			loadedAt: channelStore.loadedAt,
		}),
		(value) => scheduleSnapshotWrite('ui-persist:channel', value),
		{ deep: true },
	)

	watch(
		() => ({
			subsections: takeNewestEntries(materialsStore.subsections, 16),
			details: takeNewestEntries(materialsStore.details, 24),
			media: takeNewestEntries(materialsStore.media, 12),
		}),
		(value) => scheduleSnapshotWrite('ui-persist:materials', value),
		{ deep: true },
	)

	watch(
		() => ({
			chats: chatStore.chats,
			chatsLoadedAt: chatStore.chatsLoadedAt,
			mentionCandidates: takeNewestEntries(
				Object.fromEntries(
					Object.entries(chatStore.mentionCandidates).map(([key, value]) => [
						key,
						{
							data: value,
							loadedAt: chatStore.mentionCandidatesLoadedAt[key] ?? 0,
						},
					]),
				),
				8,
			),
		}),
		(value) =>
			scheduleSnapshotWrite('ui-persist:chat', {
				chats: value.chats,
				chatsLoadedAt: value.chatsLoadedAt,
				mentionCandidates: Object.fromEntries(
					Object.entries(value.mentionCandidates).map(([key, item]) => [key, item.data]),
				),
				mentionCandidatesLoadedAt: Object.fromEntries(
					Object.entries(value.mentionCandidates).map(([key, item]) => [key, item.loadedAt]),
				),
			}),
		{ deep: true },
	)
}

export default defineNuxtPlugin(() => {
	const route = useRoute()

	const flushPendingWrites = () => flushAllSnapshotWrites()

	const run = () => {
		void setupStatePersistence(route.path)
	}

	window.addEventListener('pagehide', flushPendingWrites)
	document.addEventListener('visibilitychange', () => {
		if (document.visibilityState === 'hidden') {
			flushPendingWrites()
		}
	})

	if ('requestIdleCallback' in window) {
		window.requestIdleCallback(run, { timeout: 700 })
		return
	}

	setTimeout(run, 0)
})
