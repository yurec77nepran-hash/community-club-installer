import type { ApiResponse, SiteBrandingSettings } from '@community-club/shared/types'
import {
	getReadableForeground,
	getStrongAccent,
	normalizeHexColor,
} from '~/utils/site-branding-colors'

const defaultButtonBackgroundColor = '#D4A62A'
const brandingFetchTimeoutMs = 2500
const defaultTheme = {
	clubName: 'Club App',
	appAccentColor: '#D4A62A',
}

function applyButtonColor(color: string) {
	const buttonBackgroundColor = normalizeHexColor(color)
	document.documentElement.style.setProperty('--app-button-bg', buttonBackgroundColor)
	document.documentElement.style.setProperty(
		'--app-button-fg',
		getReadableForeground(buttonBackgroundColor),
	)
}

function applyAccentColor(settings: Partial<SiteBrandingSettings>) {
	const accent = normalizeHexColor(settings.appAccentColor, defaultTheme.appAccentColor)

	document.documentElement.style.setProperty('--app-accent', accent)
	document.documentElement.style.setProperty('--app-accent-strong', getStrongAccent(accent))
}

export default defineNuxtPlugin(async () => {
	const config = useRuntimeConfig()
	const abortController = new AbortController()
	const timeout = setTimeout(() => abortController.abort(), brandingFetchTimeoutMs)

	try {
		const response = await fetch(`${config.public.apiUrl}/api/site-settings/branding`, {
			credentials: 'include',
			signal: abortController.signal,
		})
		const data = (await response.json()) as ApiResponse<SiteBrandingSettings>
		if (data.success) {
			useHead({ title: data.data.clubName.trim() || defaultTheme.clubName })
			applyButtonColor(data.data.buttonBackgroundColor)
			applyAccentColor(data.data)
			return
		}
	} catch {
		// Network and parsing failures use the existing branding fallback below.
	} finally {
		clearTimeout(timeout)
	}

	applyButtonColor(defaultButtonBackgroundColor)
	applyAccentColor(defaultTheme)
	useHead({ title: defaultTheme.clubName })
})
