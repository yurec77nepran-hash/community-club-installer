export default definePayloadPlugin(() => {
	// В проекте не используется skipHydrate, а штатный reducer Pinia падает
	// на null-prototype объектах в nuxt error payload.
	definePayloadReducer('skipHydrate', () => 0)
})
