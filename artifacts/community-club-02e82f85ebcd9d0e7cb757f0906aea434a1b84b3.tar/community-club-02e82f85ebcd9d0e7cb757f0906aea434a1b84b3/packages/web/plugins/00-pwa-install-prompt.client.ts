import { captureInstallPrompt, handlePwaInstalled } from '~/utils/pwa-install-prompt'

export default defineNuxtPlugin({
	name: 'pwa-install-prompt-capture',
	enforce: 'pre',
	setup() {
		window.addEventListener('beforeinstallprompt', captureInstallPrompt)
		window.addEventListener('appinstalled', handlePwaInstalled)
	},
})
