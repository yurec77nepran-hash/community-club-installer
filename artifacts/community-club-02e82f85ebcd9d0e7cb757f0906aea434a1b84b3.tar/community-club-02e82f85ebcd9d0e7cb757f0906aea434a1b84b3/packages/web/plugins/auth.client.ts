export default defineNuxtPlugin(() => {
	const auth = useAuthStore()
	const subscriptionStore = useSubscriptionStore()
	auth.initFromStorage()
	auth.hydrateUserSnapshot()
	subscriptionStore.hydrateSnapshot()
	if (auth.user || auth.hasSessionHint()) {
		void auth.restoreSession()
	}
})
