<template>
	<div class="app-shell-bg min-h-screen text-[var(--app-text)]">
		<slot />
	</div>
</template>
