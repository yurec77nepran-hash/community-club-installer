<script setup lang="ts">
import { storeToRefs } from 'pinia'
import AppOnboardingModal from '~/components/onboarding/AppOnboardingModal.vue'
import PwaLaunchBanner from '~/components/pwa/PwaLaunchBanner.vue'
import { shouldRenderPwaBanner } from '~/utils/pwa-runtime'

const route = useRoute()
const auth = useAuthStore()
const { user: authUser } = storeToRefs(auth)
const subscriptionStore = useSubscriptionStore()
const accessModalOpen = ref(false)
const accessModalRedirect = ref('/app')
const accessModalVariant = ref<'join' | 'material' | 'section'>('join')
const onboardingDismissed = ref(false)
const onboardingSaving = ref(false)
const authRestored = ref(false)
const pwaLaunch = usePwaLaunch()

type AuthUserWithOnboarding = { onboardingSeen?: boolean }

const shouldShowOnboarding = computed(() => {
	const user = authUser.value as AuthUserWithOnboarding | null
	return (
		!onboardingDismissed.value && route.path.startsWith('/app') && user?.onboardingSeen === false
	)
})

function openAccess(intent: 'login' | 'pay') {
	accessModalOpen.value = false

	if (intent === 'login') {
		void navigateTo({
			path: '/login',
			query: { redirect: accessModalRedirect.value },
		})
		return
	}

	void navigateTo('/app/payment')
}

async function completeOnboarding() {
	onboardingSaving.value = true
	onboardingDismissed.value = true
	try {
		const api = useApi()
		const res = await api.patch<typeof auth.user>('/api/users/me/onboarding', {})
		if (res.success) {
			auth.setUser(res.data)
		}
	} finally {
		onboardingSaving.value = false
	}
}

function resolveAccessVariant(redirect: string): 'join' | 'material' | 'section' {
	// Главная — общий вход; /app/content/* — закрытые материалы (шаблоны, курсы,
	// инструменты, эфиры, эксперты); остальные разделы (чат, профиль, лента) — «раздел закрыт».
	if (redirect.startsWith('/app/content/')) return 'material'
	if (redirect === '/app' || redirect === '/') return 'join'
	return 'section'
}

function openAccessModal(
	redirect = route.fullPath,
	variant: 'join' | 'material' | 'section' | null = null,
) {
	accessModalRedirect.value = redirect || '/app'
	accessModalVariant.value = variant ?? resolveAccessVariant(redirect || route.fullPath)
	accessModalOpen.value = true
}

function handleAccessRequired(event: Event) {
	const detail =
		event instanceof CustomEvent
			? (event.detail as
					| { redirect?: string; intent?: 'login' | 'pay'; variant?: 'join' }
					| undefined)
			: undefined

	openAccessModal(detail?.redirect, detail?.variant ?? null)
}

onMounted(async () => {
	await auth.restoreSession()
	authRestored.value = true
	if (authUser.value) {
		await pwaLaunch.initialize(authUser.value.authUuid)
	}
	if (authUser.value && !auth.isAdmin) {
		subscriptionStore.hydrateSnapshot()
		void subscriptionStore.fetchSubscription()
	}

	window.addEventListener('club-access-required', handleAccessRequired)
})

watch(authUser, (user) => {
	if (!authRestored.value || !user) return
	void pwaLaunch.initialize(user.authUuid)
})

watch(
	() => route.fullPath,
	() => {
		if (route.query.access === 'required') {
			const redirect = typeof route.query.redirect === 'string' ? route.query.redirect : '/app'
			openAccessModal(redirect)
			void navigateTo({ path: route.path, query: {} }, { replace: true })
		}
	},
	{ immediate: true },
)

onUnmounted(() => {
	window.removeEventListener('club-access-required', handleAccessRequired)
})
</script>

<template>
	<div class="app-shell-bg min-h-screen flex flex-col">
		<main class="app-main flex-1">
			<AppHeader v-if="route.meta.appHeader !== false" />
			<PwaLaunchBanner
				v-if="
					route.path.startsWith('/app') &&
					shouldRenderPwaBanner(pwaLaunch.bannerKind.value, shouldShowOnboarding)
				"
				:kind="pwaLaunch.bannerKind.value"
				@install="pwaLaunch.install"
				@open-app="pwaLaunch.openInstalledApp"
			/>
			<slot />
		</main>

		<AppMenu />

		<AccessRequiredModal
			v-model:open="accessModalOpen"
			:redirect="accessModalRedirect"
			:variant="accessModalVariant"
			@login="openAccess('login')"
			@pay="openAccess('pay')"
		/>
		<AppOnboardingModal
			:open="shouldShowOnboarding"
			:loading="onboardingSaving"
			@complete="completeOnboarding"
		/>
	</div>
</template>

<style scoped>
.app-main {
	--bottom-dock-reserve: 7.75rem;
	padding-bottom: var(--bottom-dock-reserve);
}
</style>
