<template>
	<div class="club-auth-layout">
		<div class="club-auth-layout__halo" aria-hidden="true" />
		<div class="club-auth-layout__grid" aria-hidden="true" />
		<div class="club-auth-layout__content">
			<div class="club-auth-layout__brand">
				<HomeLogo class="mx-auto w-44" />
			</div>
			<div class="club-auth-layout__card">
				<slot />
			</div>
		</div>
	</div>
</template>

<style scoped>
.club-auth-layout { position: relative; display: grid; min-height: 100vh; place-items: center; overflow: hidden; padding: 1.25rem; background: linear-gradient(180deg, var(--app-bg), var(--app-bg-deep)); color: var(--app-text); }
.club-auth-layout__halo { position: absolute; width: min(82vw, 38rem); aspect-ratio: 1; border: 1px solid color-mix(in srgb, var(--app-accent) 18%, transparent); border-radius: 50%; background: radial-gradient(circle, color-mix(in srgb, var(--app-accent) 14%, transparent), transparent 62%); box-shadow: 0 0 7rem color-mix(in srgb, var(--app-accent) 10%, transparent); }
.club-auth-layout__grid { position: absolute; inset: 0; opacity: 0.23; background-image: linear-gradient(color-mix(in srgb, var(--app-border) 54%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, var(--app-border) 54%, transparent) 1px, transparent 1px); background-size: 2.5rem 2.5rem; mask-image: linear-gradient(to bottom, transparent, var(--app-text) 22%, var(--app-text) 78%, transparent); }
.club-auth-layout__content { position: relative; z-index: 1; width: min(100%, 25rem); }
.club-auth-layout__brand { margin-bottom: 1.7rem; }
.club-auth-layout__card { border: 1px solid var(--app-border-strong); border-radius: 1.2rem; background: radial-gradient(circle at 90% 0, color-mix(in srgb, var(--app-accent) 14%, transparent), transparent 30%), linear-gradient(145deg, var(--app-surface), var(--app-bg)); padding: 1.5rem; box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-floating); }
.club-auth-layout__card :deep(.text-white) { color: var(--app-text-strong); }
.club-auth-layout__card :deep([class*='text-white/']) { color: var(--app-muted); }
.club-auth-layout__card :deep(.text-slate-300) { color: var(--app-accent-strong); }
.club-auth-layout__card :deep(.text-red-400) { color: var(--app-danger); }
.club-auth-layout__card :deep(.text-emerald-400) { color: var(--app-success); }
.club-auth-layout__card :deep(.club-login__close) { border-color: var(--app-border-strong); color: var(--app-muted); }
.club-auth-layout__card :deep(.club-login__close:hover) { border-color: var(--app-accent); background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface)); color: var(--app-text); }
.club-auth-layout__card :deep(.club-login__kicker),
.club-auth-layout__card :deep(.club-login__owner:hover) { color: var(--app-accent-strong); }
.club-auth-layout__card :deep(.club-login__title) { color: var(--app-text-strong); }
.club-auth-layout__card :deep(.club-login__lead),
.club-auth-layout__card :deep(.club-login__bot-hint),
.club-auth-layout__card :deep(.club-login__owner) { color: var(--app-muted); }
.club-auth-layout__card :deep(.club-login__note) { color: var(--app-muted-soft); }
.club-auth-layout__card :deep(.club-login .glass-input) { border-color: var(--app-border); background: var(--app-surface); color: var(--app-text); }
.club-auth-layout__card :deep(.club-login__primary) { background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent)); color: var(--app-button-fg); box-shadow: var(--app-shadow-soft); }
.club-auth-layout__card :deep(.club-login__secondary) { border-color: var(--app-border-strong); background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface)); color: var(--app-accent-strong); }
.club-auth-layout__card :deep(.club-login__error) { color: var(--app-danger); }
.club-auth-layout__card :deep(.club-login__success) { color: var(--app-success); }
</style>
