declare module 'virtual:pwa-register' {
	interface RegisterSWOptions {
		readonly immediate?: boolean
		readonly onNeedRefresh?: () => void
		readonly onRegisteredSW?: (
			swScriptUrl: string,
			registration: ServiceWorkerRegistration | undefined,
		) => void
	}

	export function registerSW(options?: RegisterSWOptions): (reloadPage?: boolean) => Promise<void>
}
