interface BeforeInstallPromptChoice {
	readonly outcome: 'accepted' | 'dismissed'
	readonly platform: string
}

interface BeforeInstallPromptEvent extends Event {
	readonly userChoice: Promise<BeforeInstallPromptChoice>
	prompt(): Promise<void>
}

interface WindowEventMap {
	beforeinstallprompt: BeforeInstallPromptEvent
}

interface Navigator {
	readonly standalone?: boolean
}
