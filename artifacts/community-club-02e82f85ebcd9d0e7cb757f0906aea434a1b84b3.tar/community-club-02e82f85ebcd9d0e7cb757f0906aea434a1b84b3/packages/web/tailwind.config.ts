import type { Config } from 'tailwindcss'

export default {
	content: [
		'./components/**/*.{vue,ts}',
		'./layouts/**/*.vue',
		'./pages/**/*.vue',
		'./composables/**/*.ts',
		'./app.vue',
	],
	theme: {
		extend: {
			colors: {
				primary: {
					50: '#F7F5F0',
					100: '#F1EEE7',
					200: '#E6DDCC',
					300: '#D4A62A',
					400: '#D4A62A',
					500: '#D4A62A',
					600: '#A97800',
					700: '#A97800',
					800: '#1F1F1F',
					900: '#1F1F1F',
				},
			},
		},
	},
} satisfies Config
