import type { AppNavigationSettings } from '@community-club/shared/types'

const navigationTheme = {
	backgroundColor: '#FFFFFF',
	borderColor: '#E6DDCC',
	iconStrokeColor: null,
	activeIconColor: '#A97800',
	inactiveIconColor: '#5C5C5C',
} as const

export const defaultAppNavigation: AppNavigationSettings = {
	header: {
		enabled: true,
		showOnAllPages: false,
		order: ['logo', 'name', 'notifications', 'avatar'],
	},
	menu: {
		items: [
			{
				id: 'materials',
				label: 'Шаблоны',
				icon: 'cube',
				path: '/app/content/checklists',
				requiresAuth: false,
				requiresAccess: true,
			},
			{
				id: 'calendar',
				label: 'Уроки',
				icon: 'book',
				path: '/app/content/courses',
				requiresAuth: false,
				requiresAccess: true,
			},
			{
				id: 'feed',
				label: 'Инструменты',
				icon: 'wrench',
				path: '/app/content/other',
				requiresAuth: false,
				requiresAccess: true,
			},
			{
				id: 'profile',
				label: 'Профиль',
				icon: 'user',
				path: '/app/profile',
				requiresAuth: true,
				requiresAccess: false,
			},
		],
		centerButton: {
			enabled: true,
			icon: 'spark',
			imageKey: null,
			imageUrl: null,
			glowEnabled: true,
			pressEffectEnabled: true,
			actionPath: '/app',
			requiresAuth: false,
		},
		backgroundColor: navigationTheme.backgroundColor,
		borderColor: navigationTheme.borderColor,
		borderRadius: 40,
		marginBottom: 7,
		marginSide: 6,
		iconStrokeColor: navigationTheme.iconStrokeColor,
		iconGlowEnabled: true,
		iconHighlightEnabled: true,
		activeIconColor: navigationTheme.activeIconColor,
		inactiveIconColor: navigationTheme.inactiveIconColor,
		startActivePath: '/app',
	},
}

export function useAppNavigation() {
	const settings = useState<AppNavigationSettings>('app-navigation-settings', () =>
		JSON.parse(JSON.stringify(defaultAppNavigation)),
	)
	const loaded = useState<boolean>('app-navigation-loaded', () => false)

	async function loadAppNavigation() {
		if (!import.meta.client) return settings.value
		if (loaded.value) return settings.value
		const api = useApi()
		const res = await api.get<AppNavigationSettings>('/api/site-settings/app-navigation', {
			skipCache: true,
		})
		if (res.success) {
			settings.value = {
				...res.data,
				menu: {
					...res.data.menu,
					...navigationTheme,
				},
			}
		}
		loaded.value = true
		return settings.value
	}

	return { settings, loadAppNavigation }
}
