import type { ApiResponse } from '@community-club/shared/types'
import {
	shouldLogoutAfterApiRefreshFailure,
	shouldRetryRequestAfterUnauthorized,
} from '~/utils/auth-session'

type CachedSuccessResponse = {
	expiresAt: number
	value: ApiResponse<unknown>
}

type ApiRequestOptions = RequestInit & {
	skipCache?: boolean
	authRedirect?: boolean
	retryOnUnauthorized?: boolean
}

type ApiMutationOptions = Pick<ApiRequestOptions, 'retryOnUnauthorized'>

const inflightGetRequests = new Map<string, Promise<ApiResponse<unknown>>>()
const cachedGetResponses = new Map<string, CachedSuccessResponse>()

function isRussianText(value: string) {
	return /[А-Яа-яЁё]/.test(value)
}

function normalizeErrorMessage(params: { status: number; code?: string; message?: string }) {
	const codeMap: Record<string, string> = {
		AUTH_ERROR: 'Проверьте данные для входа и попробуйте ещё раз.',
		UNAUTHORIZED: 'Сессия истекла. Войдите снова.',
		FORBIDDEN: 'Недостаточно прав для этого действия.',
		NOT_FOUND: 'Ничего не найдено.',
		BAD_REQUEST: 'Проверьте введённые данные и попробуйте ещё раз.',
		VALIDATION_ERROR: 'Проверьте заполненные поля и попробуйте ещё раз.',
		CONFIG_ERROR: 'Оплата пока недоступна.',
		PAYMENT_PENDING: 'Платёж обрабатывается. Подождите немного.',
		FILE_TOO_LARGE: 'Файл слишком большой. Уменьшите размер и попробуйте ещё раз.',
		UPLOAD_ERROR: 'Не удалось загрузить файл. Попробуйте ещё раз.',
		RATE_LIMIT: 'Слишком много запросов. Попробуйте чуть позже.',
		RATE_LIMITED: 'Слишком много запросов. Попробуйте чуть позже.',
	}

	// Конкретное сообщение сервера на русском — важнее шаблонной фразы по коду
	if (params.message && isRussianText(params.message)) {
		return params.message
	}

	if (params.code && codeMap[params.code]) {
		return codeMap[params.code]
	}

	if (params.status >= 500) {
		return 'Системная ошибка. Обратитесь в поддержку.'
	}

	if (params.status >= 400) {
		return 'Не удалось выполнить действие. Попробуйте ещё раз.'
	}

	return params.message || 'Произошла ошибка. Попробуйте ещё раз.'
}

export function useApi() {
	const config = useRuntimeConfig()
	const auth = useAuthStore()
	const baseUrl = config.public.apiUrl
	const requestBaseUrl =
		import.meta.client && !['localhost', '127.0.0.1'].includes(window.location.hostname)
			? ''
			: baseUrl

	function buildRequestKey(path: string) {
		return `${auth.user?.authUuid ?? 'anon'}:${path}`
	}

	function getCookie(name: string) {
		if (!import.meta.client) return null
		const match = document.cookie
			.split('; ')
			.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
		return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
	}

	function getCachedGet<T>(key: string) {
		const cached = cachedGetResponses.get(key)
		if (!cached) return null
		if (cached.expiresAt < Date.now()) {
			cachedGetResponses.delete(key)
			return null
		}
		return cached.value as ApiResponse<T>
	}

	function clearGetCaches() {
		inflightGetRequests.clear()
		cachedGetResponses.clear()
	}

	async function request<T>(
		path: string,
		options: ApiRequestOptions = {},
	): Promise<ApiResponse<T>> {
		const method = options.method ?? 'GET'
		const isGetRequest = method === 'GET'
		const skipCache = options.skipCache === true || options.cache === 'no-store'
		const requestKey = isGetRequest ? buildRequestKey(path) : null
		if (isGetRequest && requestKey && !skipCache) {
			const cached = getCachedGet<T>(requestKey)
			if (cached) {
				return cached
			}
			const inflight = inflightGetRequests.get(requestKey) as Promise<ApiResponse<T>> | undefined
			if (inflight) {
				return inflight
			}
		}

		const executeRequest = async (): Promise<ApiResponse<T>> => {
			const headers: Record<string, string> = {
				'Content-Type': 'application/json',
				...(options.headers as Record<string, string>),
			}

			if (method !== 'GET' && method !== 'HEAD') {
				const csrfToken = getCookie('csrf_token')
				if (csrfToken) headers['X-CSRF-Token'] = csrfToken
			}

			let response: Response
			try {
				response = await fetch(`${requestBaseUrl}${path}`, {
					...options,
					headers,
					credentials: 'include',
				})
			} catch {
				return {
					success: false,
					error: {
						code: 'NETWORK_ERROR',
						message: 'Ошибка сети. Проверьте подключение и попробуйте ещё раз.',
					},
				} as ApiResponse<T>
			}

			// Быстрый одноразовый retry только для idempotent-запросов.
			if (response.status === 503 && (options.method == null || options.method === 'GET')) {
				await new Promise((r) => setTimeout(r, 250))
				try {
					response = await fetch(`${requestBaseUrl}${path}`, {
						...options,
						headers,
						credentials: 'include',
					})
				} catch {
					return {
						success: false,
						error: {
							code: 'NETWORK_ERROR',
							message: 'Ошибка сети. Проверьте подключение и попробуйте ещё раз.',
						},
					} as ApiResponse<T>
				}
			}

			let data: ApiResponse<T>
			try {
				data = await response.json()
			} catch {
				return {
					success: false,
					error: { code: 'SYSTEM_ERROR', message: 'Системная ошибка. Обратитесь в поддержку.' },
				} as ApiResponse<T>
			}

			// Auto refresh token on 401, even when localStorage tokens are lost.
			if (
				response.status === 401 &&
				shouldRetryRequestAfterUnauthorized({
					retryOnUnauthorized: options.retryOnUnauthorized,
					isAuthenticated: auth.isAuthenticated,
					hasSessionHint: auth.hasSessionHint(),
				})
			) {
				const refreshed = await auth.refresh()
				if (refreshed === 'success') {
					try {
						const retryResponse = await fetch(`${requestBaseUrl}${path}`, {
							...options,
							headers,
							credentials: 'include',
						})
						const retryData = (await retryResponse.json()) as ApiResponse<T>
						if (!retryData.success) {
							retryData.error.message = normalizeErrorMessage({
								status: retryResponse.status,
								code: retryData.error.code,
								message: retryData.error.message,
							})
						}
						return retryData
					} catch {
						return {
							success: false,
							error: {
								code: 'NETWORK_ERROR',
								message: 'Ошибка сети. Проверьте подключение и попробуйте ещё раз.',
							},
						} as ApiResponse<T>
					}
				}
				if (shouldLogoutAfterApiRefreshFailure(refreshed)) {
					auth.logout()
					if (options.authRedirect !== false) {
						const redirectPath =
							import.meta.client && window.location.pathname.startsWith('/app')
								? `/app?access=required&redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`
								: '/'
						if (import.meta.client) {
							window.location.replace(redirectPath)
						} else {
							await navigateTo(redirectPath)
						}
					}
				}
			}

			if (!data.success) {
				data.error.message = normalizeErrorMessage({
					status: response.status,
					code: data.error.code,
					message: data.error.message,
				})
			}

			return data
		}

		if (!isGetRequest || !requestKey || skipCache) {
			const result = await executeRequest()
			if (result.success && method !== 'GET') {
				clearGetCaches()
			}
			return result
		}

		const promise = executeRequest()
		inflightGetRequests.set(requestKey, promise as Promise<ApiResponse<unknown>>)

		try {
			const result = await promise
			if (result.success) {
				cachedGetResponses.set(requestKey, {
					expiresAt: Date.now() + 1_500,
					value: result as ApiResponse<unknown>,
				})
			}
			return result
		} finally {
			inflightGetRequests.delete(requestKey)
		}
	}

	return {
		get: <T>(path: string, options?: ApiRequestOptions) => request<T>(path, options),
		post: <T>(path: string, body?: unknown, options: ApiMutationOptions = {}) =>
			request<T>(path, {
				...options,
				method: 'POST',
				body: body ? JSON.stringify(body) : undefined,
			}),
		patch: <T>(path: string, body?: unknown) =>
			request<T>(path, { method: 'PATCH', body: body ? JSON.stringify(body) : undefined }),
		delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
	}
}
