type AppHistoryEntry = {
	fullPath: string
	path: string
}

const APP_HISTORY_KEY = 'app-route-history-v1'
const APP_HISTORY_MAX = 80

function readHistoryStack(): AppHistoryEntry[] {
	if (!import.meta.client) return []

	try {
		const raw = sessionStorage.getItem(APP_HISTORY_KEY)
		if (!raw) return []
		const parsed = JSON.parse(raw) as AppHistoryEntry[]
		if (!Array.isArray(parsed)) return []
		return parsed.filter(
			(item): item is AppHistoryEntry =>
				typeof item?.fullPath === 'string' && typeof item?.path === 'string',
		)
	} catch {
		return []
	}
}

function writeHistoryStack(stack: AppHistoryEntry[]) {
	if (!import.meta.client) return

	try {
		sessionStorage.setItem(APP_HISTORY_KEY, JSON.stringify(stack.slice(-APP_HISTORY_MAX)))
	} catch {}
}

export function recordAppRoute(entry: AppHistoryEntry) {
	if (!import.meta.client) return

	const stack = readHistoryStack()
	const last = stack.at(-1)
	if (last?.fullPath === entry.fullPath) return
	stack.push(entry)
	writeHistoryStack(stack)
}

export function peekPreviousAppRoute(currentFullPath: string): AppHistoryEntry | null {
	const stack = readHistoryStack()
	let index = stack.length - 1

	while (index >= 0 && stack[index]?.fullPath === currentFullPath) {
		index -= 1
	}

	return index >= 0 ? (stack[index] ?? null) : null
}

export function trimAppHistoryTo(fullPath: string) {
	const stack = readHistoryStack()
	const targetIndex = stack.findIndex((item) => item.fullPath === fullPath)
	if (targetIndex === -1) return
	writeHistoryStack(stack.slice(0, targetIndex + 1))
}

export function removeAppHistoryEntry(fullPath: string) {
	const stack = readHistoryStack()
	writeHistoryStack(stack.filter((item) => item.fullPath !== fullPath))
}

export function useAppBack(defaultFallback = '/app') {
	const route = useRoute()
	const router = useRouter()

	async function goBack(fallback = defaultFallback) {
		const previous = peekPreviousAppRoute(route.fullPath)

		if (previous) {
			trimAppHistoryTo(previous.fullPath)
			await navigateTo(previous.fullPath, { replace: true })
			return
		}

		if (import.meta.client && window.history.length > 1) {
			router.back()
			return
		}

		await navigateTo(fallback, { replace: true })
	}

	return { goBack }
}
