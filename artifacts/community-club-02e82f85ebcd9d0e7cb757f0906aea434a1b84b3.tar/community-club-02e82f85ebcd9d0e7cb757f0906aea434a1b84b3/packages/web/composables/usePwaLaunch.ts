import type { PwaLaunchMetadata, PwaLaunchStatusResponse } from '@community-club/shared'
import {
	installPromptAvailable,
	pwaInstallState,
	requestPwaInstall,
} from '~/utils/pwa-install-prompt'
import {
	type PwaBannerKind,
	type PwaRuntime,
	claimStandaloneLaunch,
	detectPwaRuntime,
	openInstalledPwa,
	selectPwaBanner,
} from '~/utils/pwa-runtime'

const USER_AGENT_LIMIT = 1000
const PLATFORM_LIMIT = 120
const DEVICE_LABEL_LIMIT = 160

export function usePwaLaunch() {
	const api = useApi()
	const runtime = ref<PwaRuntime | null>(null)
	const status = ref<PwaLaunchStatusResponse | null>(null)
	const initializedUserId = ref<string | null>(null)

	const bannerKind = computed<PwaBannerKind>(() => {
		if (runtime.value === null || status.value === null) return 'hidden'
		if (runtime.value.isStandalone || (!runtime.value.isIos && !runtime.value.isAndroid)) {
			return 'hidden'
		}
		if (pwaInstallState.value === 'installed') return 'installed'
		if (pwaInstallState.value === 'installing') return 'installing'
		return selectPwaBanner({
			isStandalone: runtime.value.isStandalone,
			isIos: runtime.value.isIos,
			isAndroid: runtime.value.isAndroid,
			hasInstallPrompt: installPromptAvailable.value,
			hasStandaloneLaunch: status.value.hasStandaloneLaunch,
		})
	})

	function readRuntime(): PwaRuntime {
		return detectPwaRuntime({
			displayModeStandalone: window.matchMedia('(display-mode: standalone)').matches,
			navigatorStandalone: navigator.standalone === true,
			userAgent: navigator.userAgent,
			platform: navigator.platform,
			maxTouchPoints: navigator.maxTouchPoints,
		})
	}

	async function loadStatus(): Promise<void> {
		const response = await api.get<PwaLaunchStatusResponse>('/api/pwa/status', {
			skipCache: true,
		})
		status.value = response.success ? response.data : null
	}

	async function initialize(userId: string): Promise<void> {
		if (!import.meta.client || initializedUserId.value === userId) return
		initializedUserId.value = userId
		runtime.value = readRuntime()

		if (runtime.value.isStandalone) {
			status.value = null
			if (!claimStandaloneLaunch(document, userId)) return
			const platform = navigator.platform.slice(0, PLATFORM_LIMIT)
			const metadata: PwaLaunchMetadata = {
				userAgent: navigator.userAgent.slice(0, USER_AGENT_LIMIT),
				...(platform ? { platform } : {}),
				deviceLabel: runtime.value.deviceLabel.slice(0, DEVICE_LABEL_LIMIT),
			}
			await api.post<PwaLaunchStatusResponse>('/api/pwa/launch', metadata, {
				retryOnUnauthorized: false,
			})
			return
		}

		await loadStatus()
	}

	async function install(): Promise<void> {
		await requestPwaInstall()
	}

	function openInstalledApp(): void {
		openInstalledPwa((url, target, features) => window.open(url, target, features))
	}

	return { bannerKind, installState: pwaInstallState, initialize, install, openInstalledApp }
}
