import type { ApiResponse } from '@community-club/shared/types'
import {
	CHAT_ATTACHMENT_MAX_BYTES,
	formatChatUploadLimit,
	getChatAttachmentMessageType,
	getChatUploadProgressPercent,
	shouldUseChunkedChatUpload,
} from '~/utils/chat-upload'

type ChatAttachmentUploadResult = {
	url: string
	name: string
	size: number
	messageType: 'image' | 'video' | 'audio' | 'voice' | 'document'
}

type MediaUploadResult = {
	path: string
	bucket: string
	size: number | null
	contentType: string
	mediaType: 'image' | 'video' | 'audio' | 'document'
	url: string
}

type ChatAttachmentUploadProgress = {
	loaded: number
	total: number | null
	percent: number
}

type ChatAttachmentUploadOptions = {
	onProgress?: (progress: ChatAttachmentUploadProgress) => void
}

type ParsedUploadResponse<T> = {
	result: ApiResponse<T>
	status: number
}

type ChunkedUploadInitResult = {
	uploadId: string
	chunkSize: number
	totalChunks: number
	receivedChunks: number[]
}

const CHUNKED_UPLOAD_CHUNK_BYTES = 8 * 1024 * 1024
const CHUNKED_UPLOAD_CONCURRENCY = 4
const CHUNKED_UPLOAD_MAX_ATTEMPTS = 8

function normalizeUploadError(params: { status: number; code?: string; message?: string }) {
	if (params.code === 'UNAUTHORIZED' || params.status === 401) {
		return 'Сессия истекла. Войдите снова.'
	}
	if (
		params.status === 413 ||
		params.code === 'UPLOAD_TOO_LARGE' ||
		params.code === 'FILE_TOO_LARGE'
	) {
		return (
			params.message ??
			`Файл слишком большой. Максимум ${formatChatUploadLimit(CHAT_ATTACHMENT_MAX_BYTES)}.`
		)
	}
	if (params.status === 408 || params.status === 502 || params.status === 504) {
		return 'Загрузка прервалась. Попробуйте ещё раз.'
	}
	if (params.status >= 500) {
		return 'Системная ошибка. Обратитесь в поддержку.'
	}
	return params.message ?? 'Не удалось загрузить файл. Попробуйте ещё раз.'
}

function parseUploadResponseText<T>(status: number, text: string): ParsedUploadResponse<T> {
	if (!text.trim()) {
		return {
			status,
			result: {
				success: false,
				error: {
					code: status === 413 ? 'UPLOAD_TOO_LARGE' : 'UPLOAD_ERROR',
					message: normalizeUploadError({ status }),
				},
			},
		}
	}

	try {
		const result = JSON.parse(text) as ApiResponse<T>
		if (!result.success) {
			result.error.message = normalizeUploadError({
				status,
				code: result.error.code,
				message: result.error.message,
			})
		}
		return { status, result }
	} catch {
		return {
			status,
			result: {
				success: false,
				error: {
					code: 'UPLOAD_ERROR',
					message: normalizeUploadError({ status }),
				},
			},
		}
	}
}

async function parseUploadResponse<T>(response: Response) {
	return parseUploadResponseText<T>(response.status, await response.text())
}

function createUploadTraceId() {
	if (import.meta.client && typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
		return crypto.randomUUID()
	}
	return `${Date.now()}-${Math.random().toString(16).slice(2)}`
}

function sleep(ms: number) {
	return new Promise<void>((resolve) => window.setTimeout(resolve, ms))
}

export function useChatAttachmentUpload() {
	const config = useRuntimeConfig()
	const baseUrl = config.public.apiUrl

	function getCookie(name: string) {
		if (!import.meta.client) return null
		const match = document.cookie
			.split('; ')
			.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
		return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
	}

	function getAuthHeaders() {
		const csrfToken = getCookie('csrf_token')
		return csrfToken ? { 'X-CSRF-Token': csrfToken } : undefined
	}

	async function waitForOnline() {
		if (!import.meta.client || typeof navigator === 'undefined' || navigator.onLine !== false)
			return

		await new Promise<void>((resolve) => {
			window.addEventListener('online', () => resolve(), { once: true })
		})
	}

	async function sendUploadRequest<T>(params: {
		url: string
		headers?: Record<string, string>
		body: XMLHttpRequestBodyInit
		onProgress?: (progress: ChatAttachmentUploadProgress) => void
	}) {
		if (!import.meta.client || typeof XMLHttpRequest === 'undefined') {
			const response = await fetch(params.url, {
				method: 'POST',
				headers: params.headers,
				body: params.body,
				credentials: 'include',
			})
			return parseUploadResponse<T>(response)
		}

		return new Promise<ParsedUploadResponse<T>>((resolve, reject) => {
			const xhr = new XMLHttpRequest()
			xhr.open('POST', params.url, true)
			xhr.withCredentials = true

			for (const [name, value] of Object.entries(params.headers ?? {})) {
				xhr.setRequestHeader(name, value)
			}

			xhr.upload.onprogress = (event) => {
				params.onProgress?.({
					loaded: event.loaded,
					total: event.lengthComputable ? event.total : null,
					percent: getChatUploadProgressPercent(
						event.loaded,
						event.lengthComputable ? event.total : null,
					),
				})
			}

			xhr.onload = () => {
				resolve(parseUploadResponseText<T>(xhr.status, String(xhr.responseText ?? '')))
			}
			xhr.onerror = () => reject(new Error('Network upload error'))
			xhr.onabort = () => reject(new Error('Upload aborted'))
			xhr.ontimeout = () => reject(new Error('Upload timeout'))
			xhr.send(params.body)
		})
	}

	async function sendJsonUploadRequest<T>(url: string, payload: Record<string, unknown>) {
		const response = await fetch(url, {
			method: 'POST',
			headers: {
				...(getAuthHeaders() ?? {}),
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(payload),
			credentials: 'include',
		})
		return parseUploadResponse<T>(response)
	}

	function mapDirectUploadResult(file: File, data: ChatAttachmentUploadResult) {
		return {
			url: data.url,
			name: data.name || file.name,
			size: data.size ?? file.size,
			messageType:
				data.messageType ??
				getChatAttachmentMessageType({ fileName: file.name, contentType: file.type }),
		}
	}

	function mapMediaUploadResult(file: File, data: MediaUploadResult): ChatAttachmentUploadResult {
		return {
			url: data.url,
			name: file.name,
			size: data.size ?? file.size,
			messageType: getChatAttachmentMessageType({
				fileName: file.name,
				contentType: data.contentType,
			}),
		}
	}

	async function uploadDirectFile(
		chatId: number,
		file: File,
		options: ChatAttachmentUploadOptions,
	) {
		const formData = new FormData()
		formData.append('file', file)

		const upload = await sendUploadRequest<ChatAttachmentUploadResult>({
			url: `${baseUrl}/api/chats/${chatId}/upload`,
			headers: getAuthHeaders(),
			body: formData,
			onProgress: options.onProgress,
		})

		return upload.result.success
			? ({ success: true, data: mapDirectUploadResult(file, upload.result.data) } as const)
			: upload.result
	}

	async function abortChunkedUpload(uploadId: string) {
		await fetch(`${baseUrl}/api/media/upload/chunk/${encodeURIComponent(uploadId)}`, {
			method: 'DELETE',
			headers: getAuthHeaders(),
			credentials: 'include',
		}).catch(() => undefined)
	}

	function isRetriableUploadFailure(upload: ParsedUploadResponse<unknown>) {
		if (upload.status === 0) return true
		if ([408, 429, 500, 502, 503, 504].includes(upload.status)) return true
		return !upload.result.success && upload.result.error.code === 'UPLOAD_READ_ERROR'
	}

	async function uploadChunkWithRetry(params: {
		uploadId: string
		index: number
		chunk: Blob
		onChunkProgress: (loaded: number) => void
	}) {
		let lastError: Error | null = null

		for (let attempt = 1; attempt <= CHUNKED_UPLOAD_MAX_ATTEMPTS; attempt++) {
			await waitForOnline()
			let canRetry = true

			try {
				const upload = await sendUploadRequest({
					url: `${baseUrl}/api/media/upload/chunk/${encodeURIComponent(params.uploadId)}/part/${
						params.index
					}`,
					headers: {
						...(getAuthHeaders() ?? {}),
						'Content-Type': 'application/octet-stream',
					},
					body: params.chunk,
					onProgress: (progress) => params.onChunkProgress(progress.loaded),
				})

				if (upload.result.success) {
					params.onChunkProgress(params.chunk.size)
					return
				}

				lastError = new Error(upload.result.error.message)
				if (!isRetriableUploadFailure(upload)) {
					canRetry = false
					throw lastError
				}
			} catch (error) {
				lastError = error instanceof Error ? error : new Error('Chunk upload failed')
				if (!canRetry || attempt >= CHUNKED_UPLOAD_MAX_ATTEMPTS) {
					throw lastError
				}
			}

			params.onChunkProgress(0)
			await waitForOnline()
			await sleep(Math.min(1000 * 2 ** (attempt - 1), 10000))
		}

		throw lastError ?? new Error('Chunk upload failed')
	}

	async function uploadChunkedFile(
		chatId: number,
		file: File,
		options: ChatAttachmentUploadOptions,
	) {
		options.onProgress?.({ loaded: 0, total: file.size, percent: 0 })
		const traceId = createUploadTraceId()
		const init = await sendJsonUploadRequest<ChunkedUploadInitResult>(
			`${baseUrl}/api/media/upload/chunk/init`,
			{
				fileName: file.name,
				fileSize: file.size,
				contentType: file.type || 'application/octet-stream',
				bucket: 'chat',
				chatId,
				chunkSize: CHUNKED_UPLOAD_CHUNK_BYTES,
				traceId,
			},
		)

		if (!init.result.success) {
			return init.result as ApiResponse<ChatAttachmentUploadResult>
		}

		const { uploadId, chunkSize, totalChunks } = init.result.data
		const committedBytes = Array.from({ length: totalChunks }, () => 0)
		const activeBytes = Array.from({ length: totalChunks }, () => 0)

		const reportProgress = () => {
			const loaded =
				committedBytes.reduce((sum, value) => sum + value, 0) +
				activeBytes.reduce((sum, value) => sum + value, 0)
			options.onProgress?.({
				loaded,
				total: file.size,
				percent: getChatUploadProgressPercent(loaded, file.size),
			})
		}

		let nextIndex = 0
		const uploadNextChunk = async () => {
			while (nextIndex < totalChunks) {
				const index = nextIndex
				nextIndex += 1
				const start = index * chunkSize
				const end = Math.min(start + chunkSize, file.size)
				const chunk = file.slice(start, end)

				await uploadChunkWithRetry({
					uploadId,
					index,
					chunk,
					onChunkProgress: (loaded) => {
						activeBytes[index] = Math.min(loaded, chunk.size)
						reportProgress()
					},
				})

				activeBytes[index] = 0
				committedBytes[index] = chunk.size
				reportProgress()
			}
		}

		try {
			await Promise.all(
				Array.from({ length: Math.min(CHUNKED_UPLOAD_CONCURRENCY, totalChunks) }, () =>
					uploadNextChunk(),
				),
			)
		} catch {
			await abortChunkedUpload(uploadId)
			return {
				success: false,
				error: {
					code: 'NETWORK_ERROR',
					message: 'Загрузка прервалась. Попробуйте ещё раз.',
				},
			}
		}

		const complete = await sendJsonUploadRequest<MediaUploadResult>(
			`${baseUrl}/api/media/upload/chunk/${encodeURIComponent(uploadId)}/complete`,
			{ traceId },
		)

		if (!complete.result.success) {
			return complete.result as ApiResponse<ChatAttachmentUploadResult>
		}

		options.onProgress?.({ loaded: file.size, total: file.size, percent: 100 })
		return {
			success: true,
			data: mapMediaUploadResult(file, complete.result.data),
		} as const
	}

	async function uploadChatAttachment(
		chatId: number,
		file: File,
		options: ChatAttachmentUploadOptions = {},
	): Promise<ApiResponse<ChatAttachmentUploadResult>> {
		if (file.size > CHAT_ATTACHMENT_MAX_BYTES) {
			return {
				success: false,
				error: {
					code: 'FILE_TOO_LARGE',
					message: `Файл слишком большой. Максимум ${formatChatUploadLimit(CHAT_ATTACHMENT_MAX_BYTES)}.`,
				},
			}
		}

		if (!shouldUseChunkedChatUpload(file.size)) {
			return uploadDirectFile(chatId, file, options)
		}

		return uploadChunkedFile(chatId, file, options)
	}

	return { uploadChatAttachment }
}
