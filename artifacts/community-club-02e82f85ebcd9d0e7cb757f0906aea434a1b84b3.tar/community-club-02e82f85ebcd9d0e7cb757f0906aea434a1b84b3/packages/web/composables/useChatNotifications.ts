type ChatNotificationSettings = {
	enabled: boolean
}

export function useChatNotifications() {
	const api = useApi()
	const chatNotificationsEnabled = ref(true)
	const chatNotificationsLoading = ref(false)
	const chatNotificationsToast = ref('')
	let toastTimer: ReturnType<typeof setTimeout> | null = null

	function showChatNotificationsToast(message: string) {
		chatNotificationsToast.value = message
		if (toastTimer) {
			clearTimeout(toastTimer)
		}
		toastTimer = setTimeout(() => {
			chatNotificationsToast.value = ''
			toastTimer = null
		}, 1800)
	}

	async function loadChatNotificationSettings(chatId: number | null | undefined) {
		if (!chatId) return

		const res = await api.get<ChatNotificationSettings>(`/api/chats/${chatId}/notifications`)
		if (res.success) {
			chatNotificationsEnabled.value = res.data.enabled
		}
	}

	async function toggleChatNotifications(chatId: number | null | undefined) {
		if (!chatId || chatNotificationsLoading.value) return

		const nextEnabled = !chatNotificationsEnabled.value
		chatNotificationsLoading.value = true
		try {
			const res = await api.patch<ChatNotificationSettings>(`/api/chats/${chatId}/notifications`, {
				enabled: nextEnabled,
			})
			if (res.success) {
				chatNotificationsEnabled.value = res.data.enabled
				showChatNotificationsToast(
					res.data.enabled ? 'Уведомления чата включены' : 'Уведомления чата отключены',
				)
				return
			}

			showChatNotificationsToast('Не удалось изменить уведомления')
		} finally {
			chatNotificationsLoading.value = false
		}
	}

	onScopeDispose(() => {
		if (toastTimer) {
			clearTimeout(toastTimer)
			toastTimer = null
		}
	})

	return {
		chatNotificationsEnabled,
		chatNotificationsLoading,
		chatNotificationsToast,
		loadChatNotificationSettings,
		toggleChatNotifications,
	}
}
