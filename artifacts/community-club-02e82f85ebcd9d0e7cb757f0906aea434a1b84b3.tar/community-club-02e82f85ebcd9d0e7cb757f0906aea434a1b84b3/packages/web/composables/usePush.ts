export function usePush() {
	const api = useApi()
	const auth = useAuthStore()
	const isSupported = ref(false)
	const isSubscribed = ref(false)
	const permission = ref<NotificationPermission>('default')
	const serviceWorkerRegistration = ref<ServiceWorkerRegistration | null>(null)
	const serverSubscriptions = ref<Array<{ endpoint: string; lastSeenAt: string | Date }>>([])
	const unreadCount = ref(0)
	const supportReason = ref<
		'supported' | 'ios_install_required' | 'ios_update_required' | 'unsupported'
	>('unsupported')
	const deviceGuidance = ref<string | null>(null)

	function detectSupport() {
		if (!import.meta.client) {
			isSupported.value = false
			supportReason.value = 'unsupported'
			return
		}

		const nav = window.navigator as Navigator & { standalone?: boolean }
		const userAgent = nav.userAgent.toLowerCase()
		const isHuaweiOrHonor =
			userAgent.includes('huawei') || userAgent.includes('honor') || userAgent.includes('harmonyos')
		const isIos =
			/iphone|ipad|ipod/.test(userAgent) ||
			(userAgent.includes('macintosh') &&
				typeof nav.maxTouchPoints === 'number' &&
				nav.maxTouchPoints > 1)
		const isStandalone =
			window.matchMedia?.('(display-mode: standalone)').matches || nav.standalone === true
		const hasCoreApis = 'serviceWorker' in navigator && 'Notification' in window
		const hasPushApis = hasCoreApis && 'PushManager' in window

		isSupported.value = hasPushApis

		if (hasPushApis) {
			supportReason.value = 'supported'
			deviceGuidance.value = isHuaweiOrHonor
				? 'На Huawei и Honor уведомления зависят от браузера и энергосбережения. Если они не приходят, закрепите приложение в фоне и разрешите автозапуск/уведомления для браузера или PWA.'
				: null
			return
		}

		if (isIos && !isStandalone) {
			supportReason.value = 'ios_install_required'
			return
		}

		if (isIos && isStandalone) {
			supportReason.value = 'ios_update_required'
			return
		}

		supportReason.value = 'unsupported'
		deviceGuidance.value = isHuaweiOrHonor
			? 'На этом браузере Huawei/Honor Web Push может быть недоступен. Попробуйте Chrome/Edge или установку PWA, если браузер предлагает её.'
			: null
	}

	async function ensureRegistration() {
		if (!import.meta.client) return null
		if (!('serviceWorker' in navigator)) return null
		if (serviceWorkerRegistration.value) return serviceWorkerRegistration.value

		const existingRegistration = await navigator.serviceWorker.getRegistration('/')
		if (existingRegistration) {
			serviceWorkerRegistration.value = existingRegistration
			return existingRegistration
		}

		const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/' })
		serviceWorkerRegistration.value = registration
		return registration
	}

	function getDeviceLabel() {
		if (!import.meta.client) return null
		const nav = window.navigator
		const ua = nav.userAgent.toLowerCase()
		if (ua.includes('huawei')) return 'Huawei'
		if (ua.includes('honor')) return 'Honor'
		if (ua.includes('harmonyos')) return 'HarmonyOS'
		if (/android/.test(ua)) return 'Android'
		if (/iphone|ipad|ipod/.test(ua)) return 'iOS'
		return nav.platform || 'Web'
	}

	function serializeSubscription(subscription: PushSubscription) {
		const json = subscription.toJSON()
		return {
			endpoint: json.endpoint,
			keys: json.keys,
			expirationTime: subscription.expirationTime ?? null,
			permission: Notification.permission,
			userAgent: navigator.userAgent,
			platform: navigator.platform,
			deviceLabel: getDeviceLabel(),
		}
	}

	async function syncSubscriptionWithServer(subscription: PushSubscription | null) {
		if (!subscription) return false
		const payload = serializeSubscription(subscription)
		if (!payload.endpoint || !payload.keys?.p256dh || !payload.keys?.auth) return false
		const res = await api.post('/api/push/subscribe', payload)
		return res.success
	}

	async function loadServerStatus() {
		if (!import.meta.client) return
		const res = await api.get<{
			subscriptions: Array<{ endpoint: string; lastSeenAt: string | Date }>
			unreadCount: number
		}>('/api/push/status')
		if (res.success) {
			serverSubscriptions.value = res.data.subscriptions
			unreadCount.value = res.data.unreadCount
		}
	}

	async function refreshStatus() {
		if (!import.meta.client) return
		if (!auth.isAuthenticated) return

		detectSupport()
		if (!isSupported.value) {
			isSubscribed.value = false
			return
		}

		permission.value = Notification.permission
		isSubscribed.value = false
		if (permission.value !== 'granted') return

		try {
			const registration = await ensureRegistration()
			if (!registration) {
				isSubscribed.value = false
				return
			}
			const subscription = await registration.pushManager.getSubscription()
			if (!subscription) {
				await subscribe()
				return
			}
			isSubscribed.value = Boolean(subscription && Notification.permission === 'granted')
			if (isSubscribed.value && subscription) await syncSubscriptionWithServer(subscription)
			await loadServerStatus()
		} catch {
			isSubscribed.value = false
		}
	}

	onMounted(() => {
		detectSupport()
		void refreshStatus()
	})

	async function subscribe() {
		if (!isSupported.value) return false

		const perm = await Notification.requestPermission()
		permission.value = perm
		if (perm !== 'granted') {
			isSubscribed.value = false
			return false
		}

		// Получаем VAPID key с API
		const keyRes = await api.get<{ key: string }>('/api/push/vapid-key')
		if (!keyRes.success) return false

		const registration = await ensureRegistration()
		if (!registration) return false

		const existingSubscription = await registration.pushManager.getSubscription()
		let subscription = existingSubscription
		if (!subscription) {
			subscription = await registration.pushManager.subscribe({
				userVisibleOnly: true,
				applicationServerKey: urlBase64ToUint8Array(keyRes.data.key),
			})
		}

		const ok = await syncSubscriptionWithServer(subscription)
		if (!ok && existingSubscription) {
			await existingSubscription.unsubscribe()
			subscription = await registration.pushManager.subscribe({
				userVisibleOnly: true,
				applicationServerKey: urlBase64ToUint8Array(keyRes.data.key),
			})
		}

		const synced = ok || (await syncSubscriptionWithServer(subscription))
		isSubscribed.value = synced
		permission.value = Notification.permission
		await loadServerStatus()
		return synced
	}

	async function unsubscribe() {
		if (!isSupported.value) return

		const registration = await ensureRegistration()
		if (!registration) return
		const subscription = await registration.pushManager.getSubscription()
		if (subscription) {
			const endpoint = subscription.endpoint
			await subscription.unsubscribe()
			await api.post('/api/push/unsubscribe', { endpoint })
		}
		isSubscribed.value = false
		permission.value = Notification.permission
		await loadServerStatus()
	}

	return {
		isSupported,
		isSubscribed,
		permission,
		supportReason,
		deviceGuidance,
		serverSubscriptions,
		unreadCount,
		subscribe,
		unsubscribe,
		refreshStatus,
		loadServerStatus,
	}
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
	const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
	const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
	const rawData = atob(base64)
	const outputArray = new Uint8Array(rawData.length)
	for (let i = 0; i < rawData.length; ++i) {
		outputArray[i] = rawData.charCodeAt(i)
	}
	return outputArray
}
