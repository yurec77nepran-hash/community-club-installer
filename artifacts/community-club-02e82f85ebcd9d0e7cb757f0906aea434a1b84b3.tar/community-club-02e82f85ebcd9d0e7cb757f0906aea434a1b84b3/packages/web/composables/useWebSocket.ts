import type { WSServerMessage } from '@community-club/shared/types'

export function useWebSocket() {
	const config = useRuntimeConfig()
	const auth = useAuthStore()
	const ws = ref<WebSocket | null>(null)
	const isConnected = ref(false)
	const handlers = new Map<string, Set<(data: WSServerMessage) => void>>()
	const queuedMessages: Array<Record<string, unknown>> = []
	const joinedRooms = new Map<string, Record<string, unknown>>()
	let reconnectTimer: ReturnType<typeof setTimeout> | null = null
	let heartbeatTimer: ReturnType<typeof setInterval> | null = null
	let heartbeatWatchdog: ReturnType<typeof setTimeout> | null = null
	let shouldReconnect = true
	let reconnectAttempts = 0
	let lastPongAt = 0
	const maxQueuedMessages = 100
	const heartbeatIntervalMs = 20_000
	const heartbeatTimeoutMs = 45_000

	function clearHeartbeatTimers() {
		if (heartbeatTimer) {
			clearInterval(heartbeatTimer)
			heartbeatTimer = null
		}
		if (heartbeatWatchdog) {
			clearTimeout(heartbeatWatchdog)
			heartbeatWatchdog = null
		}
	}

	function scheduleHeartbeat() {
		clearHeartbeatTimers()
		lastPongAt = Date.now()
		heartbeatTimer = setInterval(() => {
			if (ws.value?.readyState !== WebSocket.OPEN) return
			if (Date.now() - lastPongAt > heartbeatTimeoutMs) {
				ws.value.close()
				return
			}
			ws.value.send(JSON.stringify({ type: 'ping' }))
		}, heartbeatIntervalMs)
	}

	function flushMessages() {
		if (ws.value?.readyState !== WebSocket.OPEN) return

		for (const payload of joinedRooms.values()) {
			ws.value.send(JSON.stringify(payload))
		}

		while (queuedMessages.length > 0) {
			const payload = queuedMessages.shift()
			if (payload) {
				ws.value.send(JSON.stringify(payload))
			}
		}
	}

	async function connect() {
		if (!auth.user) {
			await auth.restoreSession()
		}
		if (!auth.user) return
		if (ws.value?.readyState === WebSocket.OPEN || ws.value?.readyState === WebSocket.CONNECTING)
			return
		shouldReconnect = true

		const wsUrl = config.public.apiUrl.replace(/^http/, 'ws')
		ws.value = new WebSocket(`${wsUrl}/ws`)

		ws.value.onopen = () => {
			isConnected.value = true
			reconnectAttempts = 0
			if (reconnectTimer) {
				clearTimeout(reconnectTimer)
				reconnectTimer = null
			}
			scheduleHeartbeat()
			flushMessages()
		}

		ws.value.onclose = () => {
			isConnected.value = false
			clearHeartbeatTimers()
			ws.value = null
			if (!shouldReconnect) return
			const delay = Math.min(1000 * 2 ** reconnectAttempts, 10_000)
			reconnectAttempts += 1
			reconnectTimer = setTimeout(() => {
				void connect()
			}, delay)
		}

		ws.value.onmessage = (event) => {
			try {
				const msg = JSON.parse(event.data) as WSServerMessage
				if (msg.type === 'pong') {
					lastPongAt = Date.now()
					return
				}
				lastPongAt = Date.now()
				const typeHandlers = handlers.get(msg.type)
				if (typeHandlers) {
					for (const handler of typeHandlers) {
						handler(msg)
					}
				}
			} catch {}
		}
	}

	function send(data: Record<string, unknown>) {
		if (data.type === 'join_room' && data.chatId != null) {
			joinedRooms.set(String(data.chatId), data)
		}
		if (data.type === 'leave_room' && data.chatId != null) {
			joinedRooms.delete(String(data.chatId))
		}

		if (ws.value?.readyState === WebSocket.OPEN) {
			ws.value.send(JSON.stringify(data))
			return
		}

		if (data.type !== 'join_room' && data.type !== 'leave_room') {
			if (queuedMessages.length >= maxQueuedMessages) {
				queuedMessages.shift()
			}
			queuedMessages.push(data)
		}

		if (!ws.value || ws.value.readyState === WebSocket.CLOSED) {
			void connect()
		}
	}

	function on(type: string, handler: (data: WSServerMessage) => void) {
		if (!handlers.has(type)) handlers.set(type, new Set())
		handlers.get(type)?.add(handler)

		// Cleanup
		return () => handlers.get(type)?.delete(handler)
	}

	function disconnect() {
		shouldReconnect = false
		if (reconnectTimer) {
			clearTimeout(reconnectTimer)
			reconnectTimer = null
		}
		clearHeartbeatTimers()
		ws.value?.close()
		ws.value = null
	}

	return { connect, disconnect, send, on, isConnected }
}
