import type { HomeSnapshot } from '@community-club/shared/types'
import { defineStore } from 'pinia'

interface HomeState {
	snapshot: HomeSnapshot | null
	loadedAt: number
	loading: boolean
}

let snapshotPromise: Promise<HomeSnapshot | null> | null = null

export const useHomeStore = defineStore('home', {
	state: (): HomeState => ({
		snapshot: null,
		loadedAt: 0,
		loading: false,
	}),

	actions: {
		getSnapshot() {
			const cacheTtlMs = 15_000
			if (this.snapshot && Date.now() - this.loadedAt < cacheTtlMs) {
				return this.snapshot
			}
			return null
		},

		invalidate() {
			this.loadedAt = 0
		},

		async fetchSnapshot(force = false) {
			const cached = this.getSnapshot()
			if (!force && cached) {
				return cached
			}

			if (snapshotPromise) {
				return snapshotPromise
			}

			snapshotPromise = (async () => {
				this.loading = true
				try {
					const api = useApi()
					const res = await api.get<HomeSnapshot>('/api/home/snapshot', {
						cache: force ? 'no-store' : 'default',
						skipCache: force,
					})
					if (res.success) {
						this.snapshot = res.data
						this.loadedAt = Date.now()
					}
					return this.snapshot
				} finally {
					this.loading = false
				}
			})()

			try {
				return await snapshotPromise
			} finally {
				snapshotPromise = null
			}
		},
	},
})
