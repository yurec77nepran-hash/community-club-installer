import type { User } from '@community-club/shared/db/schema'
import { defineStore } from 'pinia'
import { type SessionRefreshResult, shouldLogoutAfterRestoreFailure } from '../utils/auth-session'
import { useSubscriptionStore } from './subscription'

interface AuthState {
	user: User | null
	accessToken: string | null
	refreshToken: string | null
	userLoadedAt: number
}

type AuthSyncEvent = {
	type: 'session-updated' | 'logout'
	timestamp: number
}

type UserLoadResult = 'success' | 'unauthorized' | 'network_error'

let loadUserPromise: Promise<UserLoadResult> | null = null
let refreshPromise: Promise<SessionRefreshResult> | null = null
let restorePromise: Promise<void> | null = null
let authSyncInitialized = false
let authSyncChannel: BroadcastChannel | null = null
let lastAuthSyncTimestamp = 0

const USER_SNAPSHOT_KEY = 'auth_user_snapshot'
const USER_SNAPSHOT_TTL_MS = 10 * 365 * 24 * 60 * 60_000
const AUTH_SYNC_CHANNEL = 'club_auth_sync_v1'
const AUTH_SYNC_STORAGE_KEY = 'club_auth_sync_event_v1'

function getCookie(name: string) {
	if (!import.meta.client) return null
	const match = document.cookie
		.split('; ')
		.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
	return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
}

export const useAuthStore = defineStore('auth', {
	state: (): AuthState => ({
		user: null,
		accessToken: null,
		refreshToken: null,
		userLoadedAt: 0,
	}),

	getters: {
		isAuthenticated: (state) => !!state.user,
		userRole: (state) => state.user?.role ?? 'user',
		isAdmin: (state) => state.user?.role === 'admin' || state.user?.role === 'superadmin',
	},

	actions: {
		initCrossTabSync() {
			if (!import.meta.client || authSyncInitialized) return

			authSyncInitialized = true
			const handleEvent = (event: AuthSyncEvent) => {
				if (
					!event ||
					(event.type !== 'session-updated' && event.type !== 'logout') ||
					typeof event.timestamp !== 'number' ||
					event.timestamp <= lastAuthSyncTimestamp
				) {
					return
				}

				lastAuthSyncTimestamp = event.timestamp
				if (event.type === 'logout') {
					this.clearLocalSessionState()
					return
				}

				this.invalidateUser()
				void this.loadUser(true)
			}

			if ('BroadcastChannel' in window) {
				authSyncChannel = new BroadcastChannel(AUTH_SYNC_CHANNEL)
				authSyncChannel.addEventListener('message', (event) => {
					handleEvent(event.data as AuthSyncEvent)
				})
			}

			window.addEventListener('storage', (event) => {
				if (event.key !== AUTH_SYNC_STORAGE_KEY || !event.newValue) return
				try {
					handleEvent(JSON.parse(event.newValue) as AuthSyncEvent)
				} catch {}
			})
		},

		publishAuthSync(type: AuthSyncEvent['type']) {
			if (!import.meta.client) return
			this.initCrossTabSync()

			const event: AuthSyncEvent = { type, timestamp: Date.now() }
			lastAuthSyncTimestamp = event.timestamp
			authSyncChannel?.postMessage(event)
			localStorage.setItem(AUTH_SYNC_STORAGE_KEY, JSON.stringify(event))
		},

		persistUserSnapshot() {
			if (!import.meta.client) return

			if (!this.user) {
				localStorage.removeItem(USER_SNAPSHOT_KEY)
				return
			}

			localStorage.setItem(
				USER_SNAPSHOT_KEY,
				JSON.stringify({
					user: this.user,
					timestamp: Date.now(),
				}),
			)
		},

		hydrateUserSnapshot() {
			if (!import.meta.client || this.user) return false

			const raw = localStorage.getItem(USER_SNAPSHOT_KEY)
			if (!raw) return false

			try {
				const parsed = JSON.parse(raw) as { user?: User; timestamp?: number }
				if (!parsed.user || !parsed.timestamp) {
					localStorage.removeItem(USER_SNAPSHOT_KEY)
					return false
				}

				if (Date.now() - parsed.timestamp > USER_SNAPSHOT_TTL_MS) {
					localStorage.removeItem(USER_SNAPSHOT_KEY)
					return false
				}

				this.user = parsed.user
				this.userLoadedAt = parsed.timestamp
				return true
			} catch {
				localStorage.removeItem(USER_SNAPSHOT_KEY)
				return false
			}
		},

		setTokens(accessToken: string, refreshToken: string) {
			void accessToken
			void refreshToken
			this.accessToken = null
			this.refreshToken = null
			if (import.meta.client) {
				localStorage.removeItem('access_token')
				localStorage.removeItem('refresh_token')
			}
			this.publishAuthSync('session-updated')
		},

		setUser(user: User | null) {
			this.user = user
			this.userLoadedAt = user ? Date.now() : 0
			this.persistUserSnapshot()
		},

		invalidateUser() {
			this.userLoadedAt = 0
		},

		async loadUser(force = false): Promise<UserLoadResult> {
			const cacheTtlMs = 30_000
			if (!force && this.user && Date.now() - this.userLoadedAt < cacheTtlMs) {
				return 'success'
			}

			if (loadUserPromise) {
				return await loadUserPromise
			}

			loadUserPromise = (async () => {
				const api = useApi()
				const res = await api.get<User>('/api/users/me', { authRedirect: false })
				if (res.success) {
					this.setUser(res.data)
					return 'success'
				}
				if (res.error.code === 'UNAUTHORIZED') {
					this.setUser(null)
					return 'unauthorized'
				}
				return 'network_error'
			})()

			try {
				return await loadUserPromise
			} finally {
				loadUserPromise = null
			}
		},

		async refresh(): Promise<SessionRefreshResult> {
			if (refreshPromise) {
				return refreshPromise
			}

			refreshPromise = (async () => {
				try {
					const config = useRuntimeConfig()
					const csrfToken = getCookie('csrf_token')
					const response = await fetch(`${config.public.apiUrl}/api/auth/refresh`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
							...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
						},
						body: JSON.stringify({}),
						credentials: 'include',
					})
					const data = await response.json().catch(() => null)
					if (response.ok && data?.success) {
						this.setTokens('', '')
						return 'success'
					}

					if (response.status === 400 || response.status === 401) {
						return 'unauthorized'
					}
				} catch {}

				return 'network_error'
			})()

			try {
				return await refreshPromise
			} finally {
				refreshPromise = null
			}
		},

		logout() {
			this.clearLocalSessionState()
			this.publishAuthSync('logout')
		},

		clearLocalSessionState() {
			this.user = null
			this.accessToken = null
			this.refreshToken = null
			this.userLoadedAt = 0
			useSubscriptionStore().resetState()
			if (import.meta.client) {
				localStorage.removeItem('access_token')
				localStorage.removeItem('refresh_token')
				localStorage.removeItem(USER_SNAPSHOT_KEY)
			}
		},

		initFromStorage() {
			this.initCrossTabSync()
			if (import.meta.client) {
				localStorage.removeItem('access_token')
				localStorage.removeItem('refresh_token')
				this.accessToken = null
				this.refreshToken = null
			}
		},

		hasSessionHint() {
			if (!import.meta.client) return false
			return Boolean(localStorage.getItem(USER_SNAPSHOT_KEY))
		},

		async restoreSession() {
			if (restorePromise) {
				await restorePromise
				return
			}

			restorePromise = (async () => {
				this.initCrossTabSync()
				this.initFromStorage()
				const hydratedFromSnapshot = this.hydrateUserSnapshot()
				const hadRecoverableState = Boolean(
					this.hasSessionHint() || hydratedFromSnapshot || this.user,
				)
				if (!hadRecoverableState) return

				const userLoadResult = await this.loadUser()
				if (userLoadResult === 'success') {
					return
				}

				if (
					shouldLogoutAfterRestoreFailure({
						refreshResult: userLoadResult,
						hasUser: Boolean(this.user),
						hadRecoverableState,
					})
				) {
					this.logout()
				}
			})()

			try {
				await restorePromise
			} finally {
				restorePromise = null
			}
		},
	},
})
