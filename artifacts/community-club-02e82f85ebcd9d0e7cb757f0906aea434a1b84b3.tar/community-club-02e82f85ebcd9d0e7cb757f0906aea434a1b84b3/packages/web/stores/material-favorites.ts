import type { Material } from '@community-club/shared/db/schema'
import { defineStore } from 'pinia'

export type FavoriteMaterial = Pick<
	Material,
	| 'id'
	| 'type'
	| 'title'
	| 'imageUrl'
	| 'videoCoverUrl'
	| 'shortDescription'
	| 'subsection'
	| 'mediaType'
	| 'createdAt'
> & { favoritedAt: string }

type FavoritesState = {
	items: FavoriteMaterial[]
	statuses: Record<number, boolean>
	loaded: boolean
	loading: boolean
}

export const useMaterialFavoritesStore = defineStore('material-favorites', {
	state: (): FavoritesState => ({ items: [], statuses: {}, loaded: false, loading: false }),

	actions: {
		async fetchFavorites(force = false) {
			if (this.loaded && !force) return this.items
			this.loading = true
			try {
				const res = await useApi().get<FavoriteMaterial[]>('/api/materials/favorites', {
					cache: 'no-store',
					skipCache: true,
				})
				if (!res.success) throw new Error(res.error.message)
				this.items = res.data
				this.statuses = Object.fromEntries(res.data.map((item) => [item.id, true]))
				this.loaded = true
				return this.items
			} finally {
				this.loading = false
			}
		},

		async loadStatus(materialId: number) {
			const res = await useApi().get<{ isFavorite: boolean }>(
				`/api/materials/${materialId}/favorite`,
				{ cache: 'no-store', skipCache: true },
			)
			if (res.success) this.statuses = { ...this.statuses, [materialId]: res.data.isFavorite }
			return res
		},

		async toggle(materialId: number) {
			const wasFavorite = Boolean(this.statuses[materialId])
			this.statuses = { ...this.statuses, [materialId]: !wasFavorite }
			const api = useApi()
			const res = wasFavorite
				? await api.delete<{ isFavorite: boolean }>(`/api/materials/${materialId}/favorite`)
				: await api.post<{ isFavorite: boolean }>(`/api/materials/${materialId}/favorite`)

			if (!res.success) {
				this.statuses = { ...this.statuses, [materialId]: wasFavorite }
				return res
			}

			this.statuses = { ...this.statuses, [materialId]: res.data.isFavorite }
			if (!res.data.isFavorite) this.items = this.items.filter((item) => item.id !== materialId)
			return res
		},
	},
})
