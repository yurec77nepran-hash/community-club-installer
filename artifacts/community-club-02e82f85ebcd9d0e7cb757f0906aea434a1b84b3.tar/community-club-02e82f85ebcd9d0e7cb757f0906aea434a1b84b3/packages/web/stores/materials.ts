import type { Material } from '@community-club/shared/db/schema'
import type { CursorPaginatedResponse, MaterialVideoChapters } from '@community-club/shared/types'
import { defineStore } from 'pinia'

export type MaterialPreview = Pick<
	Material,
	| 'id'
	| 'type'
	| 'title'
	| 'imageUrl'
	| 'videoCoverUrl'
	| 'shortDescription'
	| 'fullDescription'
	| 'subsection'
	| 'active'
	| 'mediaType'
	| 'durationSeconds'
	| 'fileSizeBytes'
	| 'createdAt'
> & {
	accessible?: boolean
	accessMessage?: string | null
}

export interface MaterialDownloadFile {
	index: number
	name: string
	type: string
	url?: string | null
	downloadUrl: string | null
	downloadable?: boolean
	chapters?: MaterialVideoChapters
}

export interface MaterialMediaPayload {
	url: string | null
	mediaType: string | null
	downloadUrl?: string | null
	downloadable?: boolean
	expiresIn: number
	files: MaterialDownloadFile[]
}

type CachedValue<T> = {
	data: T
	loadedAt: number
	ttlMs: number
}

type MaterialListParams = {
	type: string
	limit?: number
	cursor?: string | null
	search?: string
	subsection?: string
	dateFrom?: string
	dateTo?: string
	sort?: 'oldest' | 'newest'
}

interface MaterialsState {
	lists: Record<string, CachedValue<CursorPaginatedResponse<MaterialPreview>>>
	subsections: Record<string, CachedValue<string[]>>
	details: Record<number, CachedValue<Material>>
	media: Record<number, CachedValue<MaterialMediaPayload>>
}

const inflightSubsections = new Map<string, Promise<string[]>>()
const inflightLists = new Map<string, Promise<CursorPaginatedResponse<MaterialPreview>>>()
const inflightDetails = new Map<number, Promise<Material>>()
const inflightMedia = new Map<number, Promise<MaterialMediaPayload>>()

function isFresh<T>(value?: CachedValue<T>) {
	return Boolean(value && Date.now() - value.loadedAt < value.ttlMs)
}

function buildListKey(params: MaterialListParams) {
	return JSON.stringify({
		type: params.type,
		limit: params.limit ?? 24,
		cursor: params.cursor ?? null,
		search: params.search?.trim() ?? '',
		subsection: params.subsection ?? '',
		dateFrom: params.dateFrom ?? '',
		dateTo: params.dateTo ?? '',
		sort: params.sort ?? 'newest',
	})
}

function normalizeStoreError(code: string | undefined, fallback: string) {
	const error = new Error(fallback) as Error & { code?: string }
	error.code = code
	return error
}

export const useMaterialsStore = defineStore('materials', {
	state: (): MaterialsState => ({
		lists: {},
		subsections: {},
		details: {},
		media: {},
	}),

	actions: {
		getSubsectionsSnapshot(type: string) {
			return isFresh(this.subsections[type]) ? (this.subsections[type]?.data ?? null) : null
		},

		getListSnapshot(params: MaterialListParams) {
			const key = buildListKey(params)
			return isFresh(this.lists[key]) ? (this.lists[key]?.data ?? null) : null
		},

		getDetailSnapshot(id: number) {
			return isFresh(this.details[id]) ? (this.details[id]?.data ?? null) : null
		},

		getMediaSnapshot(id: number) {
			return isFresh(this.media[id]) ? (this.media[id]?.data ?? null) : null
		},

		async fetchSubsections(type: string, force = false) {
			const cached = this.getSubsectionsSnapshot(type)
			if (!force && cached) {
				return cached
			}

			const inflight = inflightSubsections.get(type)
			if (inflight) {
				return inflight
			}

			const promise = (async () => {
				const api = useApi()
				const res = await api.get<string[]>(
					`/api/materials/subsections?type=${encodeURIComponent(type)}`,
					force ? { cache: 'no-store', skipCache: true } : undefined,
				)
				if (!res.success) {
					throw normalizeStoreError(
						res.error.code,
						res.error.message || 'Не удалось загрузить разделы материалов.',
					)
				}

				this.subsections = {
					...this.subsections,
					[type]: {
						data: res.data,
						loadedAt: Date.now(),
						ttlMs: 300_000,
					},
				}
				return res.data
			})()

			inflightSubsections.set(type, promise)
			try {
				return await promise
			} finally {
				inflightSubsections.delete(type)
			}
		},

		async fetchList(params: MaterialListParams, force = false) {
			const key = buildListKey(params)
			const cached = this.getListSnapshot(params)
			if (!force && cached) {
				return cached
			}

			const inflight = inflightLists.get(key)
			if (inflight) {
				return inflight
			}

			const promise = (async () => {
				const api = useApi()
				const query = new URLSearchParams()
				query.set('type', params.type)
				query.set('limit', String(params.limit ?? 24))
				if (params.cursor) query.set('cursor', params.cursor)
				if (params.search?.trim()) query.set('search', params.search.trim())
				if (params.subsection) query.set('subsection', params.subsection)
				if (params.dateFrom) query.set('dateFrom', params.dateFrom)
				if (params.dateTo) query.set('dateTo', params.dateTo)
				if (params.sort) query.set('sort', params.sort)

				const res = await api.get<CursorPaginatedResponse<MaterialPreview>>(
					`/api/materials?${query.toString()}`,
					force ? { cache: 'no-store', skipCache: true } : undefined,
				)
				if (!res.success) {
					throw normalizeStoreError(
						res.error.code,
						res.error.message || 'Не удалось загрузить материалы.',
					)
				}

				this.lists = {
					...this.lists,
					[key]: {
						data: res.data,
						loadedAt: Date.now(),
						ttlMs: params.search?.trim() ? 15_000 : 30_000,
					},
				}
				return res.data
			})()

			inflightLists.set(key, promise)
			try {
				return await promise
			} finally {
				inflightLists.delete(key)
			}
		},

		async fetchDetail(id: number, force = false) {
			const cached = this.getDetailSnapshot(id)
			if (!force && cached) {
				return cached
			}

			const inflight = inflightDetails.get(id)
			if (inflight) {
				return inflight
			}

			const promise = (async () => {
				const api = useApi()
				const res = await api.get<Material>(
					`/api/materials/${id}`,
					force ? { cache: 'no-store', skipCache: true } : undefined,
				)
				if (!res.success) {
					throw normalizeStoreError(
						res.error.code,
						res.error.message || 'Не удалось загрузить материал.',
					)
				}

				this.details = {
					...this.details,
					[id]: {
						data: res.data,
						loadedAt: Date.now(),
						ttlMs: 120_000,
					},
				}
				return res.data
			})()

			inflightDetails.set(id, promise)
			try {
				return await promise
			} finally {
				inflightDetails.delete(id)
			}
		},

		async fetchMedia(id: number, force = false) {
			const cached = this.getMediaSnapshot(id)
			if (!force && cached) {
				return cached
			}

			const inflight = inflightMedia.get(id)
			if (inflight) {
				return inflight
			}

			const promise = (async () => {
				const api = useApi()
				const res = await api.get<MaterialMediaPayload>(
					`/api/media/${id}/url`,
					force ? { cache: 'no-store', skipCache: true } : undefined,
				)
				if (!res.success) {
					throw normalizeStoreError(
						res.error.code,
						res.error.message || 'Не удалось загрузить материал.',
					)
				}

				const ttlMs = Math.max(60, (res.data.expiresIn || 60) - 60) * 1000
				this.media = {
					...this.media,
					[id]: {
						data: res.data,
						loadedAt: Date.now(),
						ttlMs,
					},
				}
				return res.data
			})()

			inflightMedia.set(id, promise)
			try {
				return await promise
			} finally {
				inflightMedia.delete(id)
			}
		},

		async warmMaterial(id: number) {
			try {
				const detail = await this.fetchDetail(id)
				if (detail.storagePath) {
					void this.fetchMedia(id)
				}
			} catch {}
		},
	},
})
