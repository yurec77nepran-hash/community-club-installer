import type { Message, MessageMention, User } from '@community-club/shared/db/schema'
import type { ChatListItem, MentionCandidate } from '@community-club/shared/types'
import { defineStore } from 'pinia'

type MessageReaction = {
	id: number
	messageId: number
	userAuthUuid: string
	emoji: string
	createdAt: string | Date
}

type ChatAuthor = Pick<User, 'authUuid' | 'fullName' | 'username' | 'avatarUrl' | 'chatAdminBadge'>
type ChatReplyPreview = Pick<
	Message,
	'id' | 'userAuthUuid' | 'content' | 'messageType' | 'attachmentName'
> & {
	author?: Pick<User, 'fullName' | 'username'> | null
}

export type ChatMessage = Message & {
	author?: Omit<ChatAuthor, 'authUuid'>
	replyTo?: ChatReplyPreview | null
	mentions?: MessageMention[]
	reactions?: MessageReaction[]
	deliveryStatus?: 'sending' | 'sent' | 'failed'
}

interface ChatState {
	chats: ChatListItem[]
	messages: Record<string, ChatMessage[]>
	activeChat: number | null
	typingUsers: Record<string, string[]>
	typingExpiry: Record<string, Record<string, number>>
	presenceByChat: Record<string, number>
	mentionCandidates: Record<string, MentionCandidate[]>
	mentionCandidatesLoadedAt: Record<string, number>
	chatsLoadedAt: number
	chatsLoading: boolean
}

let fetchChatsPromise: Promise<ChatListItem[]> | null = null
const mentionCandidatesPromises = new Map<number, Promise<MentionCandidate[]>>()

function getMessageTimestamp(message: ChatMessage) {
	return new Date(message.createdAt).getTime()
}

function sortMessages(messages: ChatMessage[]) {
	messages.sort((left, right) => {
		const delta = getMessageTimestamp(left) - getMessageTimestamp(right)
		if (delta !== 0) return delta
		return left.id - right.id
	})
}

function normalizeComparableValue(value: unknown): unknown {
	if (value instanceof Date) return value.toISOString()
	if (Array.isArray(value)) return value.map((item) => normalizeComparableValue(item))
	if (value && typeof value === 'object') {
		return Object.fromEntries(
			Object.entries(value)
				.sort(([left], [right]) => left.localeCompare(right))
				.map(([key, item]) => [key, normalizeComparableValue(item)]),
		)
	}
	return value ?? null
}

function areMessagesEqual(left: ChatMessage, right: ChatMessage) {
	return (
		JSON.stringify(normalizeComparableValue(left)) ===
		JSON.stringify(normalizeComparableValue(right))
	)
}

function mergeMessage(existing: ChatMessage, incoming: ChatMessage): ChatMessage {
	const merged = {
		...existing,
		...incoming,
		clientMessageId: incoming.clientMessageId ?? existing.clientMessageId ?? null,
		author: incoming.author ?? existing.author,
		replyTo: incoming.replyTo ?? existing.replyTo ?? null,
		mentions: incoming.mentions ?? existing.mentions ?? [],
		reactions: incoming.reactions ?? existing.reactions ?? [],
		deliveryStatus: incoming.deliveryStatus ?? existing.deliveryStatus ?? 'sent',
	}

	return areMessagesEqual(existing, merged) ? existing : merged
}

function getMessageKey(message: Pick<ChatMessage, 'id' | 'clientMessageId'>) {
	return message.id > 0 ? `id:${message.id}` : `client:${message.clientMessageId ?? message.id}`
}

function mergeChatList(
	currentChats: ChatListItem[],
	incomingChats: ChatListItem[],
	options?: { preserveUnreadCounts?: boolean },
) {
	if (!options?.preserveUnreadCounts) return incomingChats

	const currentById = new Map(currentChats.map((chat) => [chat.id, chat]))
	return incomingChats.map((incoming) => {
		const current = currentById.get(incoming.id)
		if (!current) return incoming

		return {
			...incoming,
			unreadMessageCount: Math.max(
				incoming.unreadMessageCount ?? 0,
				current.unreadMessageCount ?? 0,
			),
			unreadMentionCount: Math.max(
				incoming.unreadMentionCount ?? 0,
				current.unreadMentionCount ?? 0,
			),
		}
	})
}

export const useChatStore = defineStore('chat', {
	state: (): ChatState => ({
		chats: [],
		messages: {},
		activeChat: null,
		typingUsers: {},
		typingExpiry: {},
		presenceByChat: {},
		mentionCandidates: {},
		mentionCandidatesLoadedAt: {},
		chatsLoadedAt: 0,
		chatsLoading: false,
	}),

	actions: {
		getMessages(chatId: number) {
			return this.messages[String(chatId)] ?? []
		},

		getTypingUsers(chatId: number) {
			return this.typingUsers[String(chatId)] ?? []
		},

		getPresence(chatId: number) {
			return this.presenceByChat[String(chatId)] ?? 0
		},

		getMentionCandidates(chatId: number) {
			return this.mentionCandidates[String(chatId)] ?? []
		},

		setChats(chats: ChatListItem[], options?: { preserveUnreadCounts?: boolean }) {
			this.chats = mergeChatList(this.chats, chats, options)
			this.chatsLoadedAt = Date.now()
		},

		markChatReadLocal(chatId: number) {
			this.chats = this.chats.map((chat) =>
				chat.id === chatId
					? {
							...chat,
							unreadMessageCount: 0,
							unreadMentionCount: 0,
						}
					: chat,
			)
		},

		applyChatReadState(
			chatId: number,
			readState: {
				lastReadMessageId: number
				unreadMessageCount: number
				unreadMentionCount: number
			},
		) {
			this.chats = this.chats.map((chat) =>
				chat.id === chatId
					? {
							...chat,
							lastReadMessageId: readState.lastReadMessageId,
							unreadMessageCount: readState.unreadMessageCount,
							unreadMentionCount: readState.unreadMentionCount,
						}
					: chat,
			)
		},

		async fetchChats(force = false) {
			const cacheTtlMs = 30_000
			if (!force && this.chats.length > 0 && Date.now() - this.chatsLoadedAt < cacheTtlMs) {
				return this.chats
			}
			if (fetchChatsPromise) {
				return fetchChatsPromise
			}

			fetchChatsPromise = (async () => {
				this.chatsLoading = true
				try {
					const api = useApi()
					const res = await api.get<ChatListItem[]>('/api/chats', {
						cache: force ? 'no-store' : 'default',
						skipCache: force,
					})
					if (res.success) {
						this.setChats(res.data)
					}
					return this.chats
				} finally {
					this.chatsLoading = false
				}
			})()

			try {
				return await fetchChatsPromise
			} finally {
				fetchChatsPromise = null
			}
		},

		async fetchMentionCandidates(chatId: number, force = false) {
			const chatKey = String(chatId)
			const cacheTtlMs = 60_000
			const loadedAt = this.mentionCandidatesLoadedAt[chatKey] ?? 0
			if (!force && this.mentionCandidates[chatKey]?.length && Date.now() - loadedAt < cacheTtlMs) {
				return this.getMentionCandidates(chatId)
			}

			const inflight = mentionCandidatesPromises.get(chatId)
			if (inflight) {
				return inflight
			}

			const promise = (async () => {
				const api = useApi()
				const res = await api.get<MentionCandidate[]>(`/api/chats/${chatId}/mention-candidates`)
				if (res.success) {
					this.mentionCandidates = {
						...this.mentionCandidates,
						[chatKey]: res.data,
					}
					this.mentionCandidatesLoadedAt = {
						...this.mentionCandidatesLoadedAt,
						[chatKey]: Date.now(),
					}
				}
				return this.getMentionCandidates(chatId)
			})()

			mentionCandidatesPromises.set(chatId, promise)
			try {
				return await promise
			} finally {
				mentionCandidatesPromises.delete(chatId)
			}
		},

		bulkUpsertMessages(chatId: number, incomingMessages: ChatMessage[]) {
			if (!incomingMessages.length) return

			const chatKey = String(chatId)
			const merged = new Map<string, ChatMessage>()

			for (const message of this.messages[chatKey] ?? []) {
				merged.set(getMessageKey(message), message)
			}

			for (const incoming of incomingMessages) {
				const directKey = getMessageKey(incoming)
				const clientKey =
					incoming.clientMessageId == null ? null : `client:${incoming.clientMessageId}`
				const existing =
					merged.get(directKey) ?? (clientKey ? merged.get(clientKey) : undefined) ?? null
				const nextMessage = existing
					? mergeMessage(existing, incoming)
					: {
							...incoming,
							replyTo: incoming.replyTo ?? null,
							mentions: incoming.mentions ?? [],
							reactions: incoming.reactions ?? [],
							deliveryStatus: incoming.deliveryStatus ?? 'sent',
						}

				if (clientKey && clientKey !== directKey) {
					merged.delete(clientKey)
				}
				merged.set(directKey, nextMessage)
			}

			const nextMessages = Array.from(merged.values())
			sortMessages(nextMessages)
			const currentMessages = this.messages[chatKey] ?? []
			if (
				currentMessages.length === nextMessages.length &&
				currentMessages.every((message, index) => message === nextMessages[index])
			) {
				return
			}
			this.messages[chatKey] = nextMessages
		},

		upsertMessage(chatId: number, message: ChatMessage) {
			this.bulkUpsertMessages(chatId, [message])
		},

		updateMessage(
			chatId: number,
			messageId: number,
			updater: (message: ChatMessage) => ChatMessage,
		) {
			const chatKey = String(chatId)
			const currentMessages = this.messages[chatKey]
			if (!currentMessages?.length) return

			this.messages[chatKey] = currentMessages.map((message) =>
				message.id === messageId ? updater(message) : message,
			)
		},

		addOptimisticMessage(chatId: number, message: ChatMessage) {
			this.upsertMessage(chatId, { ...message, deliveryStatus: 'sending' })
		},

		ackMessage(chatId: number, clientMessageId: string | null, message: ChatMessage) {
			this.upsertMessage(chatId, {
				...message,
				clientMessageId: clientMessageId ?? message.clientMessageId ?? null,
				deliveryStatus: 'sent',
			})
		},

		markMessageFailed(chatId: number, clientMessageId: string) {
			const chatKey = String(chatId)
			const currentMessages = this.messages[chatKey]
			if (!currentMessages?.length) return

			const index = currentMessages.findIndex((item) => item.clientMessageId === clientMessageId)
			if (index === -1) return

			this.messages[chatKey] = currentMessages.map((message, messageIndex) =>
				messageIndex === index
					? {
							...message,
							deliveryStatus: 'failed',
						}
					: message,
			)
		},

		prependMessages(chatId: number, msgs: ChatMessage[]) {
			this.bulkUpsertMessages(
				chatId,
				msgs.map((message) => ({
					...message,
					deliveryStatus: 'sent',
				})),
			)
		},

		removeMessage(messageId: number) {
			for (const [chatId, msgs] of Object.entries(this.messages)) {
				const next = msgs.filter((message) => message.id !== messageId)
				if (next.length !== msgs.length) {
					this.messages[chatId] = next
					break
				}
			}
		},

		updateReaction(messageId: number, userId: string, emoji: string, action: 'added' | 'removed') {
			for (const [chatId, msgs] of Object.entries(this.messages)) {
				const messageIndex = msgs.findIndex((item) => item.id === messageId)
				if (messageIndex === -1) continue

				const currentMessage = msgs[messageIndex]
				const reactions = [...(currentMessage.reactions ?? [])]
				if (action === 'added') {
					const exists = reactions.some(
						(reaction) => reaction.userAuthUuid === userId && reaction.emoji === emoji,
					)
					if (!exists) {
						reactions.push({
							id: Date.now(),
							messageId,
							userAuthUuid: userId,
							emoji,
							createdAt: new Date().toISOString(),
						})
					}
				} else {
					const idx = reactions.findIndex(
						(reaction) => reaction.userAuthUuid === userId && reaction.emoji === emoji,
					)
					if (idx !== -1) reactions.splice(idx, 1)
				}
				this.messages[chatId] = msgs.map((message, index) =>
					index === messageIndex ? { ...message, reactions } : message,
				)
				break
			}
		},

		setTyping(chatId: number, userId: string, expiresAt?: number) {
			const chatKey = String(chatId)
			const currentUsers = this.typingUsers[chatKey] ?? []
			this.typingUsers[chatKey] = currentUsers.includes(userId)
				? currentUsers
				: [...currentUsers, userId]

			const nextExpiry = expiresAt ?? Date.now() + 3_000
			this.typingExpiry[chatKey] = {
				...(this.typingExpiry[chatKey] ?? {}),
				[userId]: nextExpiry,
			}

			setTimeout(
				() => {
					const currentExpiry = this.typingExpiry[chatKey]?.[userId] ?? 0
					if (currentExpiry > Date.now()) {
						return
					}

					const nextUsers = (this.typingUsers[chatKey] ?? []).filter(
						(currentUser) => currentUser !== userId,
					)
					if (this.typingExpiry[chatKey]) {
						delete this.typingExpiry[chatKey][userId]
						if (Object.keys(this.typingExpiry[chatKey]).length === 0) {
							delete this.typingExpiry[chatKey]
						}
					}
					if (nextUsers.length === 0) {
						delete this.typingUsers[chatKey]
						return
					}
					this.typingUsers[chatKey] = nextUsers
				},
				Math.max(250, nextExpiry - Date.now()),
			)
		},

		setPresence(chatId: number, onlineCount: number) {
			this.presenceByChat[String(chatId)] = Math.max(0, onlineCount)
		},

		setActiveChat(chatId: number | null) {
			this.activeChat = chatId
		},
	},
})
