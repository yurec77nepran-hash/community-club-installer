import type { Payment } from '@community-club/shared/db/schema'
import { defineStore } from 'pinia'

interface SubscriptionState {
	subscription: Payment | null
	loadedAt: number
	lastErrorCode: string | null
}

let fetchSubscriptionPromise: Promise<Payment | null> | null = null
const SUBSCRIPTION_SNAPSHOT_KEY = 'subscription_snapshot'
const SUBSCRIPTION_SNAPSHOT_TTL_MS = 5 * 60_000

export const useSubscriptionStore = defineStore('subscription', {
	state: (): SubscriptionState => ({
		subscription: null,
		loadedAt: 0,
		lastErrorCode: null,
	}),

	getters: {
		hasActiveSubscription: (state) => {
			if (!state.subscription?.dateFinish) return false

			const finish = new Date(state.subscription.dateFinish)
			if (Number.isNaN(finish.getTime())) return false

			finish.setHours(23, 59, 59, 999)
			return finish >= new Date()
		},
	},

	actions: {
		persistSnapshot() {
			if (!import.meta.client) return

			if (!this.subscription || !this.loadedAt) {
				localStorage.removeItem(SUBSCRIPTION_SNAPSHOT_KEY)
				return
			}

			localStorage.setItem(
				SUBSCRIPTION_SNAPSHOT_KEY,
				JSON.stringify({
					subscription: this.subscription,
					loadedAt: this.loadedAt,
					lastErrorCode: this.lastErrorCode,
				}),
			)
		},

		hydrateSnapshot() {
			if (!import.meta.client || this.loadedAt > 0) return

			const raw = localStorage.getItem(SUBSCRIPTION_SNAPSHOT_KEY)
			if (!raw) return

			try {
				const parsed = JSON.parse(raw) as {
					subscription?: Payment | null
					loadedAt?: number
					lastErrorCode?: string | null
				}

				if (!parsed.loadedAt || Date.now() - parsed.loadedAt > SUBSCRIPTION_SNAPSHOT_TTL_MS) {
					localStorage.removeItem(SUBSCRIPTION_SNAPSHOT_KEY)
					return
				}

				this.subscription = parsed.subscription ?? null
				this.loadedAt = parsed.loadedAt
				this.lastErrorCode = parsed.lastErrorCode ?? null
			} catch {
				localStorage.removeItem(SUBSCRIPTION_SNAPSHOT_KEY)
			}
		},

		setSubscription(subscription: Payment | null, errorCode: string | null = null) {
			this.subscription = subscription
			this.lastErrorCode = errorCode
			this.loadedAt = Date.now()
			this.persistSnapshot()
		},

		invalidate() {
			this.loadedAt = 0
			this.lastErrorCode = null
		},

		resetState() {
			this.subscription = null
			this.loadedAt = 0
			this.lastErrorCode = null
			if (import.meta.client) {
				localStorage.removeItem(SUBSCRIPTION_SNAPSHOT_KEY)
			}
		},

		async fetchSubscription(force = false) {
			const cacheTtlMs = 5 * 60_000
			if (!force && this.loadedAt > 0 && Date.now() - this.loadedAt < cacheTtlMs) {
				return this.subscription
			}

			if (fetchSubscriptionPromise) {
				return fetchSubscriptionPromise
			}

			fetchSubscriptionPromise = (async () => {
				const api = useApi()
				const res = await api.get<Payment>('/api/payments/subscription')
				if (res.success) {
					this.setSubscription(res.data)
					return res.data
				}

				if (res.error.code === 'NOT_FOUND') {
					this.setSubscription(null, res.error.code)
					return null
				}

				this.lastErrorCode = res.error.code
				return this.subscription
			})()

			try {
				return await fetchSubscriptionPromise
			} finally {
				fetchSubscriptionPromise = null
			}
		},
	},
})
