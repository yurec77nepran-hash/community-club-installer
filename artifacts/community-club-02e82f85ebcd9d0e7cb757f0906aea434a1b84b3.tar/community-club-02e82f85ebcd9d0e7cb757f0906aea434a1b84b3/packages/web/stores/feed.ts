import type { CursorPaginatedResponse, FeedPostItem } from '@community-club/shared/types'
import { defineStore } from 'pinia'

type FeedSection = 'all'

interface FeedSectionState {
	items: FeedPostItem[]
	nextCursor: string | null
	loadedAt: number
	loading: boolean
	loadingMore: boolean
}

interface FeedState {
	sections: Record<FeedSection, FeedSectionState>
}

const SECTION_KEYS: FeedSection[] = ['all']

function createSectionState(): FeedSectionState {
	return {
		items: [],
		nextCursor: null,
		loadedAt: 0,
		loading: false,
		loadingMore: false,
	}
}

export const useFeedStore = defineStore('feed', {
	state: (): FeedState => ({
		sections: {
			all: createSectionState(),
		},
	}),

	actions: {
		reset(section?: FeedSection) {
			if (section) {
				this.sections[section] = createSectionState()
				return
			}
			for (const key of SECTION_KEYS) {
				this.sections[key] = createSectionState()
			}
		},

		invalidate(section?: FeedSection) {
			if (section) {
				this.sections[section].loadedAt = 0
				return
			}
			for (const key of SECTION_KEYS) {
				this.sections[key].loadedAt = 0
			}
		},

		async fetchInitial(section: FeedSection, force = false) {
			const state = this.sections[section]
			const cacheTtlMs = 30_000
			if (!force && state.items.length > 0 && Date.now() - state.loadedAt < cacheTtlMs) {
				return state.items
			}

			state.loading = true
			try {
				const api = useApi()
				const res = await api.get<CursorPaginatedResponse<FeedPostItem>>('/api/feed?limit=12')
				if (res.success) {
					state.items = res.data.items
					state.nextCursor = res.data.nextCursor
					state.loadedAt = Date.now()
				}
				return state.items
			} finally {
				state.loading = false
			}
		},

		async loadMore(section: FeedSection) {
			const state = this.sections[section]
			if (!state.nextCursor || state.loadingMore) return state.items

			state.loadingMore = true
			try {
				const api = useApi()
				const res = await api.get<CursorPaginatedResponse<FeedPostItem>>(
					`/api/feed?limit=12&cursor=${encodeURIComponent(state.nextCursor)}`,
				)
				if (res.success) {
					state.items = [
						...state.items,
						...res.data.items.filter(
							(item) => !state.items.some((existing) => existing.id === item.id),
						),
					]
					state.nextCursor = res.data.nextCursor
					state.loadedAt = Date.now()
				}
				return state.items
			} finally {
				state.loadingMore = false
			}
		},

		replaceItem(item: FeedPostItem) {
			for (const key of SECTION_KEYS) {
				const list = this.sections[key].items
				const index = list.findIndex((existing) => existing.id === item.id)
				if (index !== -1) {
					list[index] = item
				}
			}
		},
	},
})
