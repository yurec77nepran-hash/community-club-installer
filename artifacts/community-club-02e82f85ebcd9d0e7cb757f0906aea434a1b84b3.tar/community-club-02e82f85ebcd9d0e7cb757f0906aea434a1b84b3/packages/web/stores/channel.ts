import type { ChannelPost } from '@community-club/shared/db/schema'
import type { CursorPaginatedResponse } from '@community-club/shared/types'
import { defineStore } from 'pinia'

interface ChannelState {
	posts: ChannelPost[]
	nextCursor: string | null
	loadedAt: number
	loading: boolean
	loadingMore: boolean
}

let initialLoadPromise: Promise<ChannelPost[]> | null = null
let loadMorePromise: Promise<ChannelPost[]> | null = null

export const useChannelStore = defineStore('channel', {
	state: (): ChannelState => ({
		posts: [],
		nextCursor: null,
		loadedAt: 0,
		loading: false,
		loadingMore: false,
	}),

	actions: {
		reset() {
			this.posts = []
			this.nextCursor = null
			this.loadedAt = 0
			this.loading = false
			this.loadingMore = false
		},

		invalidate() {
			this.loadedAt = 0
		},

		async fetchInitial(force = false) {
			const cacheTtlMs = 30_000
			if (!force && this.posts.length > 0 && Date.now() - this.loadedAt < cacheTtlMs) {
				return this.posts
			}

			if (initialLoadPromise) {
				return initialLoadPromise
			}

			initialLoadPromise = (async () => {
				this.loading = true
				try {
					const api = useApi()
					const res = await api.get<CursorPaginatedResponse<ChannelPost>>('/api/channels?limit=20')
					if (res.success) {
						this.posts = res.data.items
						this.nextCursor = res.data.nextCursor
						this.loadedAt = Date.now()
					}
					return this.posts
				} finally {
					this.loading = false
				}
			})()

			try {
				return await initialLoadPromise
			} finally {
				initialLoadPromise = null
			}
		},

		async loadMore() {
			if (!this.nextCursor) return this.posts
			if (loadMorePromise) {
				return loadMorePromise
			}

			loadMorePromise = (async () => {
				this.loadingMore = true
				try {
					const api = useApi()
					const res = await api.get<CursorPaginatedResponse<ChannelPost>>(
						`/api/channels?limit=20&cursor=${encodeURIComponent(this.nextCursor ?? '')}`,
					)
					if (res.success) {
						this.posts = [
							...this.posts,
							...res.data.items.filter(
								(item) => !this.posts.some((existing) => existing.id === item.id),
							),
						]
						this.nextCursor = res.data.nextCursor
						this.loadedAt = Date.now()
					}
					return this.posts
				} finally {
					this.loadingMore = false
				}
			})()

			try {
				return await loadMorePromise
			} finally {
				loadMorePromise = null
			}
		},
	},
})
