import type { Event } from '@community-club/shared/db/schema'
import { defineStore } from 'pinia'

interface EventsState {
	byMonth: Record<string, Event[]>
	loadedAt: Record<string, number>
	loadingByMonth: Record<string, boolean>
}

const inflightLoads = new Map<string, Promise<Event[]>>()

export const useEventsStore = defineStore('events', {
	state: (): EventsState => ({
		byMonth: {},
		loadedAt: {},
		loadingByMonth: {},
	}),

	actions: {
		getMonthEvents(month: string) {
			return this.byMonth[month] ?? []
		},

		getMonthSnapshot(month: string) {
			const cacheTtlMs = 60_000
			const loadedAt = this.loadedAt[month] ?? 0
			if (loadedAt > 0 && Date.now() - loadedAt < cacheTtlMs) {
				return this.getMonthEvents(month)
			}
			return null
		},

		invalidateMonth(month: string) {
			delete this.loadedAt[month]
		},

		invalidateAll() {
			this.byMonth = {}
			this.loadedAt = {}
			this.loadingByMonth = {}
		},

		async fetchMonth(month: string, force = false) {
			const cached = this.getMonthSnapshot(month)
			if (!force && cached) {
				return cached
			}

			const existing = inflightLoads.get(month)
			if (existing) {
				return existing
			}

			const promise = (async () => {
				this.loadingByMonth = {
					...this.loadingByMonth,
					[month]: true,
				}
				try {
					const api = useApi()
					const res = await api.get<Event[]>(`/api/events?month=${month}`)
					if (res.success) {
						this.byMonth = {
							...this.byMonth,
							[month]: res.data,
						}
						this.loadedAt = {
							...this.loadedAt,
							[month]: Date.now(),
						}
					}
					return this.getMonthEvents(month)
				} finally {
					this.loadingByMonth = {
						...this.loadingByMonth,
						[month]: false,
					}
				}
			})()

			inflightLoads.set(month, promise)
			try {
				return await promise
			} finally {
				inflightLoads.delete(month)
			}
		},
	},
})
