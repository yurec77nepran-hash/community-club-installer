import { describe, expect, test } from 'bun:test'
import type { ChatListItem } from '@community-club/shared/types'
import { createPinia, setActivePinia } from 'pinia'
import type { ChatMessage } from './chat'
import { useChatStore } from './chat'

function makeChat(overrides: Partial<ChatListItem> = {}): ChatListItem {
	return {
		id: 1,
		slug: 'main',
		name: 'Главный чат',
		type: 'chat',
		accessRole: 'all',
		isEnabled: true,
		avatarUrl: null,
		description: null,
		settings: {
			allowMemberMessages: true,
			allowAttachments: true,
			allowReactions: true,
			slowModeSeconds: 0,
			welcomeText: null,
		},
		createdAt: '2026-05-24T10:00:00.000Z',
		updatedAt: '2026-05-24T10:00:00.000Z',
		lastReadMessageId: 10,
		unreadMessageCount: 0,
		unreadMentionCount: 0,
		...overrides,
	}
}

function makeMessage(overrides: Partial<ChatMessage> = {}): ChatMessage {
	return {
		id: 1,
		chatId: 10,
		userAuthUuid: 'user-1',
		content: 'Привет',
		replyToId: null,
		clientMessageId: null,
		messageType: 'text',
		attachmentUrl: null,
		attachmentName: null,
		attachmentSize: null,
		linkPreview: null,
		isDeleted: false,
		createdAt: '2026-05-24T10:00:00.000Z',
		updatedAt: '2026-05-24T10:00:00.000Z',
		author: {
			fullName: 'User',
			username: null,
			avatarUrl: null,
			chatAdminBadge: false,
		},
		replyTo: null,
		mentions: [],
		reactions: [],
		deliveryStatus: 'sent',
		...overrides,
	}
}

describe('chat store message merge', () => {
	test('keeps message array stable when incoming data has no changes', () => {
		setActivePinia(createPinia())
		const store = useChatStore()
		const message = makeMessage()

		store.prependMessages(10, [message])
		const firstArray = store.getMessages(10)
		const firstMessage = firstArray[0]

		store.prependMessages(10, [makeMessage()])

		expect(store.getMessages(10)).toBe(firstArray)
		expect(store.getMessages(10)[0]).toBe(firstMessage)
	})

	test('keeps client message id stable after a server refresh', () => {
		setActivePinia(createPinia())
		const store = useChatStore()

		store.ackMessage(10, 'client-1', makeMessage({ id: 22, clientMessageId: 'client-1' }))
		store.upsertMessage(10, makeMessage({ id: 22, clientMessageId: null, content: 'Привет' }))

		expect(store.getMessages(10)[0]?.clientMessageId).toBe('client-1')
	})

	test('keeps newer unread badges when applying a stale chat snapshot', () => {
		setActivePinia(createPinia())
		const store = useChatStore()

		store.setChats([makeChat({ unreadMessageCount: 4, unreadMentionCount: 2 })])
		store.setChats([makeChat({ unreadMessageCount: 0, unreadMentionCount: 0 })], {
			preserveUnreadCounts: true,
		})

		expect(store.chats[0]?.unreadMessageCount).toBe(4)
		expect(store.chats[0]?.unreadMentionCount).toBe(2)
	})

	test('allows fresh server chat data to clear unread badges', () => {
		setActivePinia(createPinia())
		const store = useChatStore()

		store.setChats([makeChat({ unreadMessageCount: 4, unreadMentionCount: 2 })])
		store.setChats([makeChat({ unreadMessageCount: 0, unreadMentionCount: 0 })])

		expect(store.chats[0]?.unreadMessageCount).toBe(0)
		expect(store.chats[0]?.unreadMentionCount).toBe(0)
	})
})
