import { loadPwaBrandingSettings } from '../utils/pwa-branding'
import { isExpectedPwaIconError, loadOptimizedPwaIcon } from '../utils/pwa-icon-service'

async function prewarmPwaIcons(): Promise<void> {
	const branding = await loadPwaBrandingSettings()
	if (!branding.homeLogoEnabled || !branding.homeLogoUrl) return

	const config = useRuntimeConfig()
	const baseUrl = config.public.apiUrl?.trim() || 'http://localhost:3001'
	await Promise.all([
		loadOptimizedPwaIcon({
			baseUrl,
			branding,
			outputFormat: 'webp',
			size: 512,
		}),
		loadOptimizedPwaIcon({
			baseUrl,
			branding,
			outputFormat: 'source',
			size: 192,
		}),
	])
}

export default defineNitroPlugin(() => {
	void prewarmPwaIcons().catch((error) => {
		if (!isExpectedPwaIconError(error)) throw error
	})
})
