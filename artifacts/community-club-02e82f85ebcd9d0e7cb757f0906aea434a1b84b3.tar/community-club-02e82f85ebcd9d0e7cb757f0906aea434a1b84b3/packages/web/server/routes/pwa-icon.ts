import {
	buildPwaIconVersion,
	isCurrentPwaIconVersion,
	loadPwaBrandingSettings,
	normalizePwaIconSize,
} from '../utils/pwa-branding'
import type { PwaIconOutputFormat } from '../utils/pwa-icon-image'
import { isExpectedPwaIconError, loadOptimizedPwaIcon } from '../utils/pwa-icon-service'

function getFallbackIconPath(size: number) {
	return `/icons/icon-${size === 512 ? 512 : 192}x${size === 512 ? 512 : 192}.png`
}

export default defineEventHandler(async (event) => {
	const query = getQuery(event)
	const size = normalizePwaIconSize(query.size)
	const outputFormat: PwaIconOutputFormat = query.format === 'webp' ? 'webp' : 'source'
	const branding = await loadPwaBrandingSettings(query.v)
	const iconVersion = buildPwaIconVersion(branding)
	const cacheControl = isCurrentPwaIconVersion(query.v, iconVersion)
		? 'public, max-age=31536000, immutable'
		: 'public, max-age=300'

	setHeader(event, 'Cache-Control', cacheControl)

	try {
		const optimized = await loadOptimizedPwaIcon({
			baseUrl: getRequestURL(event).origin,
			branding,
			outputFormat,
			size,
		})
		if (optimized) {
			return new Response(Uint8Array.from(optimized.bytes).buffer, {
				headers: {
					'Cache-Control': cacheControl,
					'Content-Type': optimized.contentType,
				},
			})
		}
	} catch (error) {
		if (!isExpectedPwaIconError(error)) throw error
	}

	const version = typeof query.v === 'string' ? `?v=${encodeURIComponent(query.v)}` : ''
	return sendRedirect(event, `${getFallbackIconPath(size)}${version}`, 302)
})
