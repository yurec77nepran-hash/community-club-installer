import {
	PWA_THEME_COLOR,
	buildPwaIconVersion,
	buildPwaShortName,
	loadPwaBrandingSettings,
} from '../utils/pwa-branding'

export default defineEventHandler(async (event) => {
	const branding = await loadPwaBrandingSettings()
	const clubName = branding.clubName.trim() || 'Community Club'
	const iconVersion = buildPwaIconVersion(branding)

	setHeader(event, 'Content-Type', 'application/manifest+json; charset=utf-8')
	setHeader(event, 'Cache-Control', 'no-store, max-age=0, must-revalidate')

	return {
		id: '/',
		name: clubName,
		short_name: buildPwaShortName(clubName),
		description: `Закрытый клуб ${clubName}`,
		start_url: '/',
		scope: '/',
		display: 'standalone',
		orientation: 'portrait',
		background_color: PWA_THEME_COLOR,
		theme_color: PWA_THEME_COLOR,
		lang: 'ru',
		icons: [
			{
				src: `/pwa-icon?size=192&v=${iconVersion}`,
				sizes: '192x192',
			},
			{
				src: `/pwa-icon?size=512&v=${iconVersion}`,
				sizes: '512x512',
			},
			{
				src: `/pwa-icon?size=512&purpose=maskable&v=${iconVersion}`,
				sizes: '512x512',
				purpose: 'maskable',
			},
		],
	}
})
