import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'
import type { SiteBrandingSettings } from '@community-club/shared/types'
import sharp from 'sharp'
import { optimizeLogoBytes } from './pwa-icon-image'
import { loadOptimizedPwaIcon } from './pwa-icon-service'

const sourceLogoUrl = new URL('../../public/icons/logo_234_gold.png', import.meta.url)

async function loadFixture() {
	const bytes = await readFile(sourceLogoUrl)
	return { bytes, contentType: 'image/png' }
}

describe('PWA icon image optimization', () => {
	test.each([192, 512] as const)(
		'preserves PNG while fitting the real logo inside %ipx',
		async (size) => {
			// Given
			const source = await loadFixture()

			// When
			const optimized = await optimizeLogoBytes({
				loadSource: async () => source,
				outputFormat: 'source',
				size,
				sourceUrl: `${sourceLogoUrl.href}?source-size=${size}`,
				version: 'source-fixture-v1',
			})
			const metadata = await sharp(optimized.bytes).metadata()

			// Then
			expect(metadata.width).toBeLessThanOrEqual(size)
			expect(metadata.height).toBeLessThanOrEqual(size)
			expect(optimized.bytes.byteLength).toBeLessThan(source.bytes.byteLength * 0.5)
			expect(optimized.contentType).toBe('image/png')
		},
	)

	test('produces a materially smaller 512px WebP at the selected quality', async () => {
		// Given
		const source = await loadFixture()

		// When
		const optimized = await optimizeLogoBytes({
			loadSource: async () => source,
			outputFormat: 'webp',
			size: 512,
			sourceUrl: `${sourceLogoUrl.href}?webp`,
			version: 'webp-fixture-v1',
		})
		const metadata = await sharp(optimized.bytes).metadata()

		// Then
		expect(metadata.width).toBeLessThanOrEqual(512)
		expect(metadata.height).toBeLessThanOrEqual(512)
		expect(optimized.bytes.byteLength).toBeLessThan(source.bytes.byteLength * 0.15)
		expect(optimized.contentType).toBe('image/webp')
	})

	test('loads one shared source for concurrent 512 WebP and 192 source warmup variants', async () => {
		// Given
		const source = await loadFixture()
		let loadCalls = 0
		const loadSource = async () => {
			loadCalls += 1
			await Promise.resolve()
			return source
		}
		const common = {
			loadSource,
			sourceUrl: `${sourceLogoUrl.href}?dedupe`,
			version: 'dedupe-v1',
		} as const

		// When
		await Promise.all([
			optimizeLogoBytes({ ...common, outputFormat: 'source', size: 192 }),
			optimizeLogoBytes({ ...common, outputFormat: 'webp', size: 512 }),
			optimizeLogoBytes({ ...common, outputFormat: 'webp', size: 512 }),
		])
		await optimizeLogoBytes({ ...common, outputFormat: 'source', size: 192 })

		// Then
		expect(loadCalls).toBe(1)
	})

	test('shares one upstream service fetch across concurrent warmup variants', async () => {
		// Given
		const source = await loadFixture()
		let fetchCalls = 0
		const branding: SiteBrandingSettings = {
			clubName: 'Warmup Club',
			homeLogoEnabled: true,
			homeLogoMediaKey: 'logos/warmup-service.png',
			homeLogoUrl: '/media/warmup-service.png?test=shared',
			buttonBackgroundColor: '#D4A62A',
			appBackgroundColor: '#F7F5F0',
			appSurfaceColor: '#FFFFFF',
			appTextColor: '#1F1F1F',
			appAccentColor: '#D4A62A',
		}
		const fetchSource = async () => {
			fetchCalls += 1
			await Promise.resolve()
			return source
		}

		// When
		await Promise.all([
			loadOptimizedPwaIcon(
				{ baseUrl: 'https://club.example', branding, outputFormat: 'webp', size: 512 },
				fetchSource,
			),
			loadOptimizedPwaIcon(
				{ baseUrl: 'https://club.example', branding, outputFormat: 'source', size: 192 },
				fetchSource,
			),
		])

		// Then
		expect(fetchCalls).toBe(1)
	})

	test('does not cache a failed source load', async () => {
		// Given
		const source = await loadFixture()
		const loadError = new Error('fixture source failed')
		let loadCalls = 0
		const loadSource = async () => {
			loadCalls += 1
			if (loadCalls === 1) throw loadError
			return source
		}
		const input = {
			loadSource,
			outputFormat: 'webp',
			size: 512,
			sourceUrl: `${sourceLogoUrl.href}?retry`,
			version: 'retry-v1',
		} as const

		// When
		let caughtError: unknown
		try {
			await optimizeLogoBytes(input)
		} catch (error) {
			caughtError = error
		}
		const retried = await optimizeLogoBytes(input)

		// Then
		expect(caughtError).toBe(loadError)
		expect(retried.contentType).toBe('image/webp')
		expect(loadCalls).toBe(2)
	})
})
