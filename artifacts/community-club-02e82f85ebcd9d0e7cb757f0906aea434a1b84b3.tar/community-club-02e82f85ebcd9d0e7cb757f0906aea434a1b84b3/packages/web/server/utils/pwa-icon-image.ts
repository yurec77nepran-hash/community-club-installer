import sharp from 'sharp'

export type PwaIconSize = 192 | 512
export type PwaIconOutputFormat = 'source' | 'webp'

export type LogoSource = {
	readonly bytes: Uint8Array
	readonly contentType: string
}

export type LogoSourceLoader = () => Promise<LogoSource>

type OptimizeLogoInput = {
	readonly loadSource: LogoSourceLoader
	readonly outputFormat: PwaIconOutputFormat
	readonly size: PwaIconSize
	readonly sourceUrl: string
	readonly version: string
}

export type OptimizedLogo = {
	readonly bytes: Uint8Array
	readonly contentType: string
}

const MAX_CACHE_ENTRIES = 8
const contentTypesByFormat: Readonly<Record<string, string>> = {
	avif: 'image/avif',
	gif: 'image/gif',
	heif: 'image/heif',
	jp2: 'image/jp2',
	jpeg: 'image/jpeg',
	jxl: 'image/jxl',
	png: 'image/png',
	tiff: 'image/tiff',
	webp: 'image/webp',
}

export class LogoOptimizationError extends Error {
	constructor() {
		super('Logo optimization failed')
		this.name = 'LogoOptimizationError'
	}
}

class BoundedAsyncCache<Value> {
	private readonly values = new Map<string, Value>()
	private readonly inFlight = new Map<string, Promise<Value>>()

	async getOrLoad(key: string, loader: () => Promise<Value>): Promise<Value> {
		const cached = this.values.get(key)
		if (cached) {
			this.values.delete(key)
			this.values.set(key, cached)
			return cached
		}

		const active = this.inFlight.get(key)
		if (active) return active
		if (this.inFlight.size >= MAX_CACHE_ENTRIES) {
			const oldest = this.inFlight.values().next().value
			if (oldest)
				await oldest.then(
					() => undefined,
					() => undefined,
				)
			return this.getOrLoad(key, loader)
		}

		const pending = loader().then((value) => {
			if (this.values.size >= MAX_CACHE_ENTRIES) {
				const oldestKey = this.values.keys().next().value
				if (typeof oldestKey === 'string') this.values.delete(oldestKey)
			}
			this.values.set(key, value)
			return value
		})
		this.inFlight.set(key, pending)
		try {
			return await pending
		} finally {
			this.inFlight.delete(key)
		}
	}
}

const sourceCache = new BoundedAsyncCache<LogoSource>()
const optimizedCache = new BoundedAsyncCache<OptimizedLogo>()

async function resizeLogo(
	source: LogoSource,
	size: PwaIconSize,
	outputFormat: PwaIconOutputFormat,
): Promise<OptimizedLogo> {
	try {
		let pipeline = sharp(source.bytes).autoOrient().resize(size, size, {
			fit: 'inside',
			withoutEnlargement: true,
		})
		switch (outputFormat) {
			case 'source':
				break
			case 'webp':
				pipeline = pipeline.webp({ quality: 88, effort: 4, smartSubsample: true })
				break
			default:
				throw new LogoOptimizationError()
		}

		const { data, info } = await pipeline.toBuffer({ resolveWithObject: true })
		const contentType = contentTypesByFormat[info.format]
		if (!contentType) throw new LogoOptimizationError()
		return { bytes: data, contentType }
	} catch (error) {
		if (error instanceof LogoOptimizationError) throw error
		throw new LogoOptimizationError()
	}
}

export async function optimizeLogoBytes(input: OptimizeLogoInput): Promise<OptimizedLogo> {
	const sourceKey = `${input.version}\u0000${input.sourceUrl}`
	const optimizedKey = `${sourceKey}\u0000${input.size}\u0000${input.outputFormat}`
	return optimizedCache.getOrLoad(optimizedKey, async () => {
		const source = await sourceCache.getOrLoad(sourceKey, input.loadSource)
		return resizeLogo(source, input.size, input.outputFormat)
	})
}
