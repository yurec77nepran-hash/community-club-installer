import type { ApiResponse, SiteBrandingSettings } from '@community-club/shared/types'

const defaultBranding: SiteBrandingSettings = {
	clubName: 'Community Club',
	homeLogoEnabled: true,
	homeLogoMediaKey: null,
	buttonBackgroundColor: '#D4A62A',
	appBackgroundColor: '#F7F5F0',
	appSurfaceColor: '#FFFFFF',
	appTextColor: '#1F1F1F',
	appAccentColor: '#D4A62A',
	homeLogoUrl: null,
}

const DEFAULT_PWA_ICON_VERSION = 'community-club-default-icon-v3'
const BRANDING_CACHE_TTL_MS = 5 * 60 * 1000
export const PWA_THEME_COLOR = '#F7F5F0'

type TtlLoadResult<Value> = {
	readonly cacheable: boolean
	readonly value: Value
}

type TtlCacheEntry<Value> = {
	readonly expiresAt: number
	readonly value: Value
}

export class SuccessfulTtlLoader<Value> {
	private cached: TtlCacheEntry<Value> | null = null
	private inFlight: Promise<TtlLoadResult<Value>> | null = null

	constructor(
		private readonly ttlMs: number,
		private readonly now: () => number,
	) {}

	async load(
		loader: () => Promise<TtlLoadResult<Value>>,
		acceptCached?: (value: Value) => boolean,
	): Promise<Value> {
		if (
			this.cached &&
			this.cached.expiresAt > this.now() &&
			(!acceptCached || acceptCached(this.cached.value))
		) {
			return this.cached.value
		}
		this.cached = null

		if (this.inFlight) {
			const active = this.inFlight
			const result = await active
			if (!result.cacheable || !acceptCached || acceptCached(result.value)) return result.value
			if (this.inFlight === active) this.inFlight = null
			return this.load(loader, acceptCached)
		}

		const pending = loader()
		this.inFlight = pending
		try {
			const result = await pending
			if (result.cacheable) {
				this.cached = { expiresAt: this.now() + this.ttlMs, value: result.value }
			}
			return result.value
		} finally {
			if (this.inFlight === pending) this.inFlight = null
		}
	}
}

const brandingLoader = new SuccessfulTtlLoader<SiteBrandingSettings>(BRANDING_CACHE_TTL_MS, () =>
	Date.now(),
)

function normalizeApiUrl(value: string | undefined) {
	const trimmed = value?.trim()
	return trimmed || 'http://localhost:3001'
}

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs = 2500) {
	const controller = new AbortController()
	const timeout = setTimeout(() => controller.abort(), timeoutMs)
	try {
		return await fetch(url, { ...init, signal: controller.signal })
	} finally {
		clearTimeout(timeout)
	}
}

export async function loadPwaBrandingSettings(
	requestedVersion?: unknown,
): Promise<SiteBrandingSettings> {
	const acceptCached =
		typeof requestedVersion === 'string'
			? (cached: SiteBrandingSettings) =>
					isCurrentPwaIconVersion(requestedVersion, buildPwaIconVersion(cached))
			: undefined
	return brandingLoader.load(async () => {
		const config = useRuntimeConfig()
		const apiUrl = normalizeApiUrl(config.public.apiUrl)

		try {
			const response = await fetchWithTimeout(`${apiUrl}/api/site-settings/branding`, {
				cache: 'no-store',
				headers: { accept: 'application/json' },
			})
			if (!response.ok) return { cacheable: false, value: defaultBranding }

			const payload = (await response.json()) as ApiResponse<SiteBrandingSettings>
			if (!payload.success) return { cacheable: false, value: defaultBranding }

			return {
				cacheable: true,
				value: {
					...defaultBranding,
					...payload.data,
					clubName: payload.data.clubName?.trim() || defaultBranding.clubName,
				},
			}
		} catch {
			return { cacheable: false, value: defaultBranding }
		}
	}, acceptCached)
}

export function buildPwaShortName(clubName: string) {
	const normalized = clubName.trim().replace(/\s+/g, ' ')
	if (normalized.length <= 18) return normalized
	return normalized.slice(0, 18).trim()
}

export function buildPwaIconVersion(settings: SiteBrandingSettings) {
	return encodeURIComponent(
		settings.homeLogoEnabled && settings.homeLogoMediaKey
			? settings.homeLogoMediaKey
			: DEFAULT_PWA_ICON_VERSION,
	)
}

export function isCurrentPwaIconVersion(value: unknown, currentVersion: string): boolean {
	return typeof value === 'string' && encodeURIComponent(value) === currentVersion
}

export function normalizePwaIconSize(value: unknown): 192 | 512 {
	const parsed = Number.parseInt(String(value ?? ''), 10)
	return parsed >= 384 ? 512 : 192
}
