import { describe, expect, test } from 'bun:test'
import { existsSync, readFileSync } from 'node:fs'
import type { SiteBrandingSettings } from '@community-club/shared/types'
import {
	PWA_THEME_COLOR,
	SuccessfulTtlLoader,
	buildPwaIconVersion,
	buildPwaShortName,
	isCurrentPwaIconVersion,
} from './pwa-branding'

const baseBranding: SiteBrandingSettings = {
	clubName: 'Community Club',
	homeLogoEnabled: true,
	homeLogoMediaKey: null,
	buttonBackgroundColor: '#D4A62A',
	appBackgroundColor: '#F7F5F0',
	appSurfaceColor: '#FFFFFF',
	appTextColor: '#1F1F1F',
	appAccentColor: '#D4A62A',
	homeLogoUrl: null,
}

const pwaIconRouteSource = readFileSync(new URL('../routes/pwa-icon.ts', import.meta.url), 'utf8')
const pwaManifestRouteSource = readFileSync(
	new URL('../routes/pwa-manifest.ts', import.meta.url),
	'utf8',
)
const pwaBrandingSource = readFileSync(new URL('./pwa-branding.ts', import.meta.url), 'utf8')
const nuxtConfigSource = readFileSync(new URL('../../nuxt.config.ts', import.meta.url), 'utf8')
const prewarmPluginUrl = new URL('../plugins/pwa-icon-prewarm.ts', import.meta.url)
const prewarmPluginSource = existsSync(prewarmPluginUrl)
	? readFileSync(prewarmPluginUrl, 'utf8')
	: ''

describe('PWA branding helpers', () => {
	test('keeps the install surface on the fixed light theme', () => {
		expect(PWA_THEME_COLOR).toBe('#F7F5F0')
	})

	test('uses a stable template icon version when no custom logo is selected', () => {
		expect(buildPwaIconVersion(baseBranding)).toBe('community-club-default-icon-v3')
	})

	test('versions the PWA icon by the selected project logo key', () => {
		expect(
			buildPwaIconVersion({
				...baseBranding,
				homeLogoMediaKey: 'logos/demo-club-logo.png',
				homeLogoUrl: 'https://media.example.com/logos/demo-club-logo.png',
			}),
		).toBe('logos%2Fdemo-club-logo.png')
	})

	test('matches the decoded query value to the canonical encoded custom-logo version', () => {
		expect(isCurrentPwaIconVersion('logos/demo-club-logo.png', 'logos%2Fdemo-club-logo.png')).toBe(
			true,
		)
		expect(isCurrentPwaIconVersion('logos/stale-logo.png', 'logos%2Fdemo-club-logo.png')).toBe(
			false,
		)
		expect(isCurrentPwaIconVersion(undefined, 'logos%2Fdemo-club-logo.png')).toBe(false)
	})

	test('uses immutable caching only for the current icon version and short caching otherwise', () => {
		expect(pwaIconRouteSource).toContain('isCurrentPwaIconVersion(query.v, iconVersion)')
		expect(pwaIconRouteSource).toContain(`'public, max-age=31536000, immutable'`)
		expect(pwaIconRouteSource).toContain(`'public, max-age=300'`)
		expect(nuxtConfigSource).not.toMatch(/['"]\/pwa-icon['"]\s*:\s*\{[\s\S]*?no-store/)
	})

	test('selects WebP explicitly while keeping manifest icon URLs source-compatible', () => {
		expect(pwaIconRouteSource).toContain(`query.format === 'webp'`)
		expect(pwaManifestRouteSource).not.toContain('format=webp')
	})

	test('keeps static head icons unversioned while the dynamic manifest remains versioned', () => {
		expect(nuxtConfigSource).toContain(`href: '/pwa-icon?size=192&purpose=favicon'`)
		expect(nuxtConfigSource).toContain(`href: '/pwa-icon?size=192&purpose=apple'`)
		expect(nuxtConfigSource).not.toContain('v=community-club-default-icon-v3')
		expect(pwaManifestRouteSource).toContain('v=${iconVersion}')
	})

	test('routes requested versions through branding cache freshness validation', () => {
		expect(pwaIconRouteSource).toContain('loadPwaBrandingSettings(query.v)')
		expect(pwaBrandingSource).toContain('buildPwaIconVersion(cached)')
		expect(pwaBrandingSource).toContain('5 * 60 * 1000')
	})

	test('prewarms both icon variants through the shared icon service at Nitro startup', () => {
		expect(prewarmPluginSource).toContain('defineNitroPlugin')
		expect(prewarmPluginSource).toContain('Promise.all')
		expect(prewarmPluginSource).toMatch(
			/loadOptimizedPwaIcon\([\s\S]*?outputFormat: 'webp'[\s\S]*?size: 512/,
		)
		expect(prewarmPluginSource).toMatch(
			/loadOptimizedPwaIcon\([\s\S]*?outputFormat: 'source'[\s\S]*?size: 192/,
		)
		expect(pwaIconRouteSource).toContain('loadOptimizedPwaIcon')
		expect(pwaIconRouteSource).not.toContain('fetchIconWithTimeout')
	})

	test('keeps short names compact for install prompts', () => {
		expect(buildPwaShortName('Long Project Club Name')).toBe('Long Project Club')
	})

	test('coalesces concurrent loads and reloads only after the five-minute TTL expires', async () => {
		// Given
		let now = 1_000
		let loadCalls = 0
		const cache = new SuccessfulTtlLoader(5 * 60 * 1000, () => now)
		const loader = async () => {
			loadCalls += 1
			await Promise.resolve()
			return { cacheable: true, value: `branding-${loadCalls}` } as const
		}

		// When
		const concurrent = await Promise.all([cache.load(loader), cache.load(loader)])
		now = 300_999
		const beforeExpiry = await cache.load(loader)
		now = 301_000
		const afterExpiry = await cache.load(loader)

		// Then
		expect(concurrent).toEqual(['branding-1', 'branding-1'])
		expect(beforeExpiry).toBe('branding-1')
		expect(afterExpiry).toBe('branding-2')
		expect(loadCalls).toBe(2)
	})

	test('reloads within TTL when the caller rejects the cached value', async () => {
		// Given
		let loadCalls = 0
		const cache = new SuccessfulTtlLoader(5 * 60 * 1000, () => 1_000)
		const loader = async () => {
			loadCalls += 1
			return { cacheable: true, value: `branding-v${loadCalls}` } as const
		}
		await cache.load(loader)

		// When
		const refreshed = await cache.load(loader, (cached) => cached === 'branding-v2')

		// Then
		expect(refreshed).toBe('branding-v2')
		expect(loadCalls).toBe(2)
	})

	test('refreshes after a shared in-flight load returns an unacceptable version', async () => {
		// Given
		let releaseFirstLoad: (() => void) | undefined
		const firstLoadGate = new Promise<void>((resolve) => {
			releaseFirstLoad = resolve
		})
		let loadCalls = 0
		const cache = new SuccessfulTtlLoader(5 * 60 * 1000, () => 1_000)
		const loader = async () => {
			loadCalls += 1
			if (loadCalls === 1) await firstLoadGate
			return { cacheable: true, value: `branding-v${loadCalls}` } as const
		}

		// When
		const startupLoad = cache.load(loader)
		const versionedLoad = cache.load(loader, (cached) => cached === 'branding-v2')
		if (releaseFirstLoad) releaseFirstLoad()
		const [startupBranding, versionedBranding] = await Promise.all([startupLoad, versionedLoad])

		// Then
		expect(startupBranding).toBe('branding-v1')
		expect(versionedBranding).toBe('branding-v2')
		expect(loadCalls).toBe(2)
	})

	test('does not cache rejected or explicitly non-cacheable loads', async () => {
		// Given
		let loadCalls = 0
		const loadError = new Error('branding unavailable')
		const cache = new SuccessfulTtlLoader(5 * 60 * 1000, () => 1_000)

		// When
		let caughtError: unknown
		try {
			await cache.load(async () => {
				loadCalls += 1
				throw loadError
			})
		} catch (error) {
			caughtError = error
		}
		const fallback = await cache.load(async () => {
			loadCalls += 1
			return { cacheable: false, value: 'fallback' } as const
		})
		const recovered = await cache.load(async () => {
			loadCalls += 1
			return { cacheable: true, value: 'branding' } as const
		})

		// Then
		expect(caughtError).toBe(loadError)
		expect(fallback).toBe('fallback')
		expect(recovered).toBe('branding')
		expect(loadCalls).toBe(3)
	})
})
