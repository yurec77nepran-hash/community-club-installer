import type { SiteBrandingSettings } from '@community-club/shared/types'
import { buildPwaIconVersion } from './pwa-branding'
import {
	LogoOptimizationError,
	type LogoSource,
	type PwaIconOutputFormat,
	type PwaIconSize,
	optimizeLogoBytes,
} from './pwa-icon-image'

type LoadPwaIconInput = {
	readonly baseUrl: string
	readonly branding: SiteBrandingSettings
	readonly outputFormat: PwaIconOutputFormat
	readonly size: PwaIconSize
}

type PwaIconSourceFetcher = (url: string) => Promise<LogoSource>

const SOURCE_FETCH_TIMEOUT_MS = 2_500

export class PwaIconSourceError extends Error {
	constructor() {
		super('PWA icon source is unavailable')
		this.name = 'PwaIconSourceError'
	}
}

export function isExpectedPwaIconError(error: unknown): boolean {
	return error instanceof LogoOptimizationError || error instanceof PwaIconSourceError
}

function resolveLogoUrl(value: string, baseUrl: string): string | null {
	try {
		return new URL(value, baseUrl).toString()
	} catch (error) {
		if (error instanceof TypeError) return null
		throw error
	}
}

async function fetchPwaIconSource(url: string): Promise<LogoSource> {
	const controller = new AbortController()
	const timeout = setTimeout(() => controller.abort(), SOURCE_FETCH_TIMEOUT_MS)
	try {
		const response = await fetch(url, {
			cache: 'no-store',
			headers: { accept: 'image/*' },
			signal: controller.signal,
		})
		const contentType = response.headers.get('content-type') ?? ''
		if (!response.ok || !contentType.startsWith('image/')) throw new PwaIconSourceError()
		return {
			bytes: new Uint8Array(await response.arrayBuffer()),
			contentType,
		}
	} catch (error) {
		if (error instanceof PwaIconSourceError) throw error
		if (error instanceof TypeError || (error instanceof Error && error.name === 'AbortError')) {
			throw new PwaIconSourceError()
		}
		throw error
	} finally {
		clearTimeout(timeout)
	}
}

export async function loadOptimizedPwaIcon(
	input: LoadPwaIconInput,
	fetchSource: PwaIconSourceFetcher = fetchPwaIconSource,
) {
	if (!input.branding.homeLogoEnabled || !input.branding.homeLogoUrl) return null
	const sourceUrl = resolveLogoUrl(input.branding.homeLogoUrl, input.baseUrl)
	if (!sourceUrl) return null

	return optimizeLogoBytes({
		loadSource: () => fetchSource(sourceUrl),
		outputFormat: input.outputFormat,
		size: input.size,
		sourceUrl,
		version: buildPwaIconVersion(input.branding),
	})
}
