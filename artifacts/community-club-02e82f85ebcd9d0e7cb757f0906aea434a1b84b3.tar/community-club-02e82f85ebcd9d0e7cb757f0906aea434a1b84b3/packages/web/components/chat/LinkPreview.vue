<script setup lang="ts">
interface Props {
	url: string
}

const props = defineProps<Props>()
const api = useApi()

const preview = ref<{
	title: string | null
	description: string | null
	image: string | null
	siteName: string | null
} | null>(null)

const loaded = ref(false)

onMounted(async () => {
	const res = await api.get<typeof preview.value>(
		`/api/chats/link-preview?url=${encodeURIComponent(props.url)}`,
	)
	if (res.success && res.data?.title) {
		preview.value = res.data
	}
	loaded.value = true
})
</script>

<template>
	<a
		v-if="preview && loaded"
		:href="url"
		target="_blank"
		rel="noopener noreferrer"
		class="block mt-2 rounded-lg overflow-hidden border border-[var(--app-border)] bg-[var(--app-bg)] hover:bg-[var(--app-bg-deep)] transition no-underline shadow-[var(--app-shadow-soft)]"
	>
		<img
			v-if="preview.image"
			:src="preview.image"
			class="w-full h-32 object-cover"
			loading="lazy"
		/>
		<div class="p-2.5">
			<p v-if="preview.siteName" class="text-[10px] text-[var(--app-accent-slate)] uppercase">
				{{ preview.siteName }}
			</p>
			<p class="text-xs font-medium text-[var(--app-text-strong)] line-clamp-2">
				{{ preview.title }}
			</p>
			<p v-if="preview.description" class="text-[10px] text-[var(--app-muted)] line-clamp-2 mt-0.5">
				{{ preview.description }}
			</p>
		</div>
	</a>
</template>
