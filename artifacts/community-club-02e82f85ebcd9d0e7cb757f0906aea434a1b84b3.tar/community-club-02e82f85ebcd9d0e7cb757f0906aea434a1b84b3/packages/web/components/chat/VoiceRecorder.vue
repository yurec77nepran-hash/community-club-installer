<script setup lang="ts">
const emit = defineEmits<{
	recorded: [blob: Blob, duration: number]
	cancel: []
}>()

const recording = ref(false)
const duration = ref(0)
const waveformBars = ref<number[]>(new Array(32).fill(4))
const recordingError = ref('')
let mediaRecorder: MediaRecorder | null = null
let audioContext: AudioContext | null = null
let analyser: AnalyserNode | null = null
let animationFrame: number | null = null
let chunks: Blob[] = []
let timer: ReturnType<typeof setInterval>
let stream: MediaStream | null = null

function pickSupportedMimeType(): string | undefined {
	if (typeof MediaRecorder === 'undefined') return undefined
	const candidates = [
		'audio/ogg;codecs=opus',
		'audio/webm;codecs=opus',
		'audio/mp4;codecs=mp4a.40.2',
		'audio/mp4',
	]
	return candidates.find((type) => MediaRecorder.isTypeSupported(type))
}

async function startRecording() {
	try {
		if (typeof MediaRecorder === 'undefined') {
			throw new Error('MediaRecorder not supported')
		}
		stream = await navigator.mediaDevices.getUserMedia({ audio: true })
		const mimeType = pickSupportedMimeType()
		mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream)
		chunks = []

		// Анализатор для визуализации
		audioContext = new AudioContext()
		const source = audioContext.createMediaStreamSource(stream)
		analyser = audioContext.createAnalyser()
		analyser.fftSize = 128
		source.connect(analyser)

		mediaRecorder.ondataavailable = (e) => {
			if (e.data.size > 0) chunks.push(e.data)
		}

		mediaRecorder.onstop = () => {
			const kind = mediaRecorder?.mimeType.includes('ogg')
				? 'ogg'
				: mediaRecorder?.mimeType.includes('mp4') || mediaRecorder?.mimeType.includes('m4a')
					? 'mp4'
					: 'webm'
			const blob = new Blob(chunks, {
				type: kind === 'ogg' ? 'audio/ogg' : kind === 'mp4' ? 'audio/mp4' : 'audio/webm',
			})
			emit('recorded', blob, duration.value)
			cleanup()
		}

		mediaRecorder.start()
		recording.value = true
		timer = setInterval(() => {
			duration.value++
		}, 1000)
		visualize()
	} catch (error) {
		recordingError.value =
			error instanceof DOMException && error.name === 'NotAllowedError'
				? 'Доступ к микрофону запрещён. Разрешите микрофон в браузере и попробуйте снова.'
				: 'Не удалось начать запись. Проверьте микрофон и разрешения для сайта.'
	}
}

function visualize() {
	if (!analyser) return
	const data = new Uint8Array(analyser.frequencyBinCount)

	function draw() {
		if (!analyser) return
		analyser.getByteFrequencyData(data)
		const bars: number[] = []
		const step = Math.floor(data.length / 32)
		for (let i = 0; i < 32; i++) {
			const val = data[i * step] / 255
			bars.push(Math.max(3, val * 24))
		}
		waveformBars.value = bars
		animationFrame = requestAnimationFrame(draw)
	}
	draw()
}

function cleanup() {
	clearInterval(timer)
	if (animationFrame) cancelAnimationFrame(animationFrame)
	if (audioContext) audioContext.close()
	stream?.getTracks().forEach((t) => t.stop())
	audioContext = null
	analyser = null
	animationFrame = null
	stream = null
	recording.value = false
	duration.value = 0
	recordingError.value = ''
	waveformBars.value = new Array(32).fill(4)
}

function stopRecording() {
	clearInterval(timer)
	if (animationFrame) cancelAnimationFrame(animationFrame)
	mediaRecorder?.stop()
}

function cancelRecording() {
	clearInterval(timer)
	if (animationFrame) cancelAnimationFrame(animationFrame)
	stream?.getTracks().forEach((t) => t.stop())
	if (audioContext) audioContext.close()
	mediaRecorder = null
	audioContext = null
	analyser = null
	animationFrame = null
	stream = null
	recording.value = false
	duration.value = 0
	recordingError.value = ''
	emit('cancel')
}

function formatDuration(s: number): string {
	const m = Math.floor(s / 60)
	const sec = s % 60
	return `${m}:${sec.toString().padStart(2, '0')}`
}

// Автоматически начинаем запись при монтировании
onMounted(() => startRecording())
onUnmounted(() => cleanup())
</script>

<template>
	<div class="flex items-center gap-2 px-2 py-2">
		<!-- Cancel (slide left / tap) -->
		<button
			class="w-9 h-9 flex items-center justify-center flex-shrink-0 text-[var(--app-muted-soft)] hover:text-[var(--app-accent-wine)] transition"
			@click="cancelRecording"
		>
			<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
			</svg>
		</button>

		<!-- Recording waveform / error -->
		<div v-if="recordingError" class="flex-1 text-xs leading-snug text-[var(--app-accent-wine)]">
			{{ recordingError }}
		</div>
		<div v-else class="flex-1 flex items-center gap-1.5">
			<!-- Red dot pulsing -->
			<div class="w-2.5 h-2.5 bg-[var(--app-accent-wine)] rounded-full animate-recording-pulse flex-shrink-0" />

			<!-- Timer -->
			<span class="text-sm text-[var(--app-accent-wine)] tabular-nums w-10 flex-shrink-0">{{ formatDuration(duration) }}</span>

			<!-- Waveform bars -->
			<div class="flex-1 flex items-center justify-center gap-[2px] h-8 overflow-hidden">
				<div
					v-for="(h, i) in waveformBars"
					:key="i"
					class="w-[3px] rounded-full bg-[var(--app-accent-slate)] transition-all duration-75"
					:style="{ height: h + 'px' }"
				/>
			</div>
		</div>

		<!-- Send voice -->
		<button
			class="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-[var(--app-accent)] text-[var(--app-text-strong)] shadow-[0_10px_24px_color-mix(in_srgb,var(--app-accent-strong)_24%,transparent)] transition hover:bg-[color-mix(in_srgb,var(--app-accent)_82%,white)]"
			@click="stopRecording"
		>
			<svg class="w-[18px] h-[18px] ml-0.5" fill="currentColor" viewBox="0 0 24 24">
				<path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
			</svg>
		</button>
	</div>
</template>

<style scoped>
@keyframes recording-pulse {
	0%, 100% { opacity: 1; transform: scale(1); }
	50% { opacity: 0.4; transform: scale(0.75); }
}
.animate-recording-pulse {
	animation: recording-pulse 1.2s ease-in-out infinite;
}
</style>
