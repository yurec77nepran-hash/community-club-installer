<script setup lang="ts">
import { REACTIONS } from '@community-club/shared/constants'

defineEmits<{ pick: [emoji: string] }>()
</script>

<template>
	<div class="bg-[var(--app-surface)] rounded-full shadow-[var(--app-shadow-floating)] px-2 py-1.5 flex gap-1 border border-[var(--app-border)]">
		<button
			v-for="emoji in REACTIONS"
			:key="emoji"
			class="text-xl hover:scale-125 transition-transform p-0.5 rounded-full hover:bg-[var(--app-bg-deep)]"
			@click="$emit('pick', emoji)"
		>
			{{ emoji }}
		</button>
	</div>
</template>
