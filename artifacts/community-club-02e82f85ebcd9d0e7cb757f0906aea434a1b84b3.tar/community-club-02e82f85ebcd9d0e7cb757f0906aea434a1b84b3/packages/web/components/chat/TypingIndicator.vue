<script setup lang="ts">
interface Props {
	users: string[]
}

defineProps<Props>()
</script>

<template>
	<div v-if="users.length > 0" class="flex items-center gap-2 px-4 py-1.5">
		<div class="flex gap-0.5">
			<span class="w-1.5 h-1.5 bg-[var(--app-accent-slate)] rounded-full animate-bounce" style="animation-delay: 0ms" />
			<span class="w-1.5 h-1.5 bg-[var(--app-accent-slate)] rounded-full animate-bounce" style="animation-delay: 200ms" />
			<span class="w-1.5 h-1.5 bg-[var(--app-accent-slate)] rounded-full animate-bounce" style="animation-delay: 400ms" />
		</div>
		<span class="text-xs text-[var(--app-muted-soft)]">
			{{ users.length === 1 ? 'печатает...' : `${users.length} печатают...` }}
		</span>
	</div>
</template>
