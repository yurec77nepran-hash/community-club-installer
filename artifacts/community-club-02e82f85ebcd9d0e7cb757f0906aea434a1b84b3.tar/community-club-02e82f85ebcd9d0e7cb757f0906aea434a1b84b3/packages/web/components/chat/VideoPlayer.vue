<script setup lang="ts">
const props = defineProps<{ src: string }>()
const emit = defineEmits<{ close: [] }>()

const video = ref<HTMLVideoElement | null>(null)
const playing = ref(false)
const currentTime = ref(0)
const duration = ref(0)
const progress = ref(0)
const showControls = ref(true)
const isFullscreen = ref(false)
let controlsTimer: ReturnType<typeof setTimeout> | null = null
const speeds = [1, 1.5, 2, 0.5]
const speedIndex = ref(0)
const playbackRate = computed(() => speeds[speedIndex.value])

type OrientationScreen = Screen & {
	orientation?: {
		lock?: (orientation: 'landscape' | 'portrait') => Promise<void>
		unlock?: () => void
	}
}

type FullscreenVideoElement = HTMLVideoElement & {
	webkitEnterFullscreen?: () => void
	webkitSupportsFullscreen?: boolean
}

function cycleSpeed() {
	speedIndex.value = (speedIndex.value + 1) % speeds.length
	if (video.value) video.value.playbackRate = playbackRate.value
	flashControls()
}

// Swipe-to-close
let touchStartY = 0
const translateY = ref(0)
const opacity = ref(1)
const isDragging = ref(false)

function togglePlay() {
	if (!video.value) return
	if (playing.value) video.value.pause()
	else video.value.play()
	flashControls()
}

function flashControls() {
	showControls.value = true
	if (controlsTimer) clearTimeout(controlsTimer)
	controlsTimer = setTimeout(() => {
		if (playing.value) showControls.value = false
	}, 3000)
}

function onPlay() {
	playing.value = true
	if (video.value) video.value.playbackRate = playbackRate.value
	flashControls()
}
function onPause() {
	playing.value = false
	showControls.value = true
}
function onEnded() {
	playing.value = false
	showControls.value = true
	progress.value = 0
}

function onTimeUpdate() {
	if (!video.value) return
	currentTime.value = video.value.currentTime
	if (video.value.duration && Number.isFinite(video.value.duration)) {
		progress.value = video.value.currentTime / video.value.duration
	}
}

function onLoadedMetadata() {
	if (video.value && Number.isFinite(video.value.duration)) {
		duration.value = video.value.duration
	}
}

function seek(e: MouseEvent | TouchEvent) {
	if (!video.value || !duration.value) return
	const bar = e.currentTarget as HTMLElement
	const rect = bar.getBoundingClientRect()
	const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX
	const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width))
	video.value.currentTime = pct * duration.value
}

function formatTime(s: number): string {
	const m = Math.floor(s / 60)
	const sec = Math.floor(s % 60)
	return `${m}:${sec.toString().padStart(2, '0')}`
}

// Swipe down to close
function onTouchStart(e: TouchEvent) {
	touchStartY = e.touches[0].clientY
	isDragging.value = true
}

function onTouchMove(e: TouchEvent) {
	if (!isDragging.value) return
	const dy = e.touches[0].clientY - touchStartY
	if (dy > 0) {
		translateY.value = dy
		opacity.value = Math.max(0.3, 1 - dy / 400)
	}
}

function onTouchEnd() {
	isDragging.value = false
	if (translateY.value > 120) {
		emit('close')
	} else {
		translateY.value = 0
		opacity.value = 1
	}
}

async function lockLandscapeOrientation() {
	const orientationApi = (window.screen as OrientationScreen).orientation
	if (!orientationApi?.lock) return
	try {
		await orientationApi.lock('landscape')
	} catch {}
}

async function unlockOrientation() {
	const orientationApi = (window.screen as OrientationScreen).orientation
	if (!orientationApi?.unlock) return
	try {
		orientationApi.unlock()
	} catch {}
}

async function requestNativeFullscreen() {
	const player = video.value as FullscreenVideoElement | null
	if (!player) return

	try {
		if (player.webkitEnterFullscreen) {
			player.webkitEnterFullscreen()
			isFullscreen.value = true
			await lockLandscapeOrientation()
			return
		}
	} catch {}

	if (!document.fullscreenElement && player.requestFullscreen) {
		try {
			await player.requestFullscreen()
			isFullscreen.value = true
			await lockLandscapeOrientation()
		} catch {}
	}
}

async function onFullscreenChange() {
	isFullscreen.value = Boolean(document.fullscreenElement)
	if (!isFullscreen.value) {
		await unlockOrientation()
	}
}

onMounted(() => {
	if (video.value) video.value.play()
	document.addEventListener('fullscreenchange', onFullscreenChange)
})

onUnmounted(() => {
	if (controlsTimer) clearTimeout(controlsTimer)
	document.removeEventListener('fullscreenchange', onFullscreenChange)
	void unlockOrientation()
})
</script>

<template>
	<div
		class="fixed inset-0 z-[100] bg-black flex items-center justify-center"
		:style="{ opacity }"
		@touchstart.passive="onTouchStart"
		@touchmove.passive="onTouchMove"
		@touchend.passive="onTouchEnd"
	>
		<div
			class="w-full h-full flex items-center justify-center"
			:style="{ transform: `translateY(${translateY}px)`, transition: isDragging ? 'none' : 'transform 0.25s ease, opacity 0.25s ease' }"
			@click="togglePlay"
		>
			<video
				ref="video"
				:src="src"
				class="max-w-full max-h-full object-contain"
				playsinline
				preload="auto"
				@play="onPlay"
				@pause="onPause"
				@ended="onEnded"
				@timeupdate="onTimeUpdate"
				@loadedmetadata="onLoadedMetadata"
				@click.stop="togglePlay"
			/>
		</div>

		<!-- Top bar: close button -->
		<div
			class="absolute top-0 left-0 right-0 p-4 flex justify-between items-center transition-opacity duration-200 z-10"
			:class="showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'"
		>
			<button class="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center" @click.stop="emit('close')">
				<svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
			</button>
			<button
				class="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center"
				@pointerdown.stop.prevent="requestNativeFullscreen"
				@click.stop.prevent
				aria-label="Открыть видео на весь экран"
			>
				<svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 3H5a2 2 0 00-2 2v3m16-5h-3a2 2 0 012 2v3M8 21H5a2 2 0 01-2-2v-3m16 5h-3a2 2 0 002-2v-3" />
				</svg>
			</button>
		</div>

		<!-- Bottom controls -->
		<div
			class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-4 pb-6 pt-10 transition-opacity duration-200 z-10"
			:class="showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'"
			@click.stop
		>
			<!-- Play/pause + time -->
			<div class="flex items-center gap-3 mb-2">
				<button class="flex-shrink-0" @click.stop="togglePlay">
					<svg v-if="!playing" class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
					<svg v-else class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
				</button>
				<span class="text-xs text-white/70 tabular-nums">{{ formatTime(currentTime) }} / {{ formatTime(duration) }}</span>
				<button
					class="ml-auto px-2 py-1 rounded-lg text-xs font-bold text-white/80 bg-white/15 active:bg-white/25 transition"
					@click.stop="cycleSpeed"
				>{{ playbackRate }}x</button>
			</div>

			<!-- Progress bar -->
			<div class="h-6 flex items-center cursor-pointer" @click.stop="seek" @touchstart.stop="seek">
				<div class="w-full h-[3px] bg-white/20 rounded-full relative">
					<div class="absolute left-0 top-0 h-full bg-white rounded-full" :style="{ width: (progress * 100) + '%' }" />
					<div class="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg" :style="{ left: (progress * 100) + '%', marginLeft: '-6px' }" />
				</div>
			</div>
		</div>

		<!-- Big play button in center when paused -->
		<div
			v-if="!playing && showControls"
			class="absolute inset-0 flex items-center justify-center pointer-events-none z-5"
		>
			<div class="w-16 h-16 rounded-full bg-black/50 flex items-center justify-center">
				<svg class="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
			</div>
		</div>
	</div>
</template>
