<script setup lang="ts">
import type { Message } from '@community-club/shared/db/schema'
import type {
	MentionCandidate,
	MentionPayload,
	ScheduledChatMessageItem,
} from '@community-club/shared/types'
import { CHAT_ATTACHMENT_MAX_BYTES, formatChatUploadLimit } from '~/utils/chat-upload'

interface Props {
	replyTo?: Message | null
	editingMessage?: Message | null
	mentionCandidates?: MentionCandidate[]
	prefilledText?: string
	canSchedule?: boolean
	scheduledMessages?: ScheduledChatMessageItem[]
	scheduledLoading?: boolean
	disabled?: boolean
	attachmentsEnabled?: boolean
	disabledText?: string
}

const props = withDefaults(defineProps<Props>(), {
	replyTo: null,
	editingMessage: null,
	mentionCandidates: () => [],
	prefilledText: '',
	canSchedule: false,
	scheduledMessages: () => [],
	scheduledLoading: false,
	disabled: false,
	attachmentsEnabled: true,
	disabledText: 'Сообщения закрыты',
})

const emit = defineEmits<{
	send: [
		data: { content: string; messageType: string; replyToId?: number; mentions?: MentionPayload[] },
	]
	saveEdit: [data: { messageId: number; content: string; mentions?: MentionPayload[] }]
	typing: []
	cancelReply: []
	cancelEdit: []
	attachment: [file: File]
	voiceStart: []
	schedule: [data: { content: string; scheduledAt: string; mentions?: MentionPayload[] }]
	deleteScheduled: [id: number]
}>()

const text = ref('')
const fileInput = ref<HTMLInputElement>()
const textareaRef = ref<HTMLTextAreaElement>()
const mentionQuery = ref('')
const mentionTokenRange = ref<{ start: number; end: number } | null>(null)
const highlightedMentionIndex = ref(0)
const selectedMentions = ref<Array<{ userAuthUuid: string; displayName: string }>>([])
const showSchedulePanel = ref(false)
const scheduledAtInput = ref('')
const scheduleError = ref('')

function getAvatarEmoji(value: string | null | undefined) {
	if (!value?.startsWith('emoji:')) return null
	return value.slice('emoji:'.length) || null
}

function getAvatarImageUrl(value: string | null | undefined) {
	if (!value || value.startsWith('emoji:')) return null
	return value
}

const filteredMentionCandidates = computed(() => {
	const query = mentionQuery.value.trim().toLocaleLowerCase('ru')
	const candidates = props.mentionCandidates ?? []

	if (!mentionTokenRange.value) {
		return []
	}

	const filtered = candidates.filter((candidate) => {
		const haystack = [candidate.displayName, candidate.fullName ?? '', candidate.username ?? '']
			.join(' ')
			.toLocaleLowerCase('ru')

		return !query || haystack.includes(query)
	})

	return filtered.slice(0, 8)
})

function getDisplayNameFromReply(message: Message) {
	return message.userAuthUuid?.slice(0, 8) || 'Пользователь'
}

function resetMentions() {
	mentionQuery.value = ''
	mentionTokenRange.value = null
	highlightedMentionIndex.value = 0
}

function syncMentionQuery() {
	const textarea = textareaRef.value
	if (!textarea) return

	const caretIndex = textarea.selectionStart ?? text.value.length
	const beforeCaret = text.value.slice(0, caretIndex)
	const mentionStart = beforeCaret.lastIndexOf('@')
	if (mentionStart === -1) {
		resetMentions()
		return
	}

	const charBeforeMention = mentionStart === 0 ? ' ' : beforeCaret[mentionStart - 1]
	if (charBeforeMention && !/\s/.test(charBeforeMention)) {
		resetMentions()
		return
	}

	const query = beforeCaret.slice(mentionStart + 1)
	if (/[\n\r\s]/.test(query)) {
		resetMentions()
		return
	}

	mentionQuery.value = query
	mentionTokenRange.value = { start: mentionStart, end: caretIndex }
	highlightedMentionIndex.value = 0
}

function onInput() {
	emit('typing')
	syncMentionQuery()
}

function insertMention(candidate: MentionCandidate) {
	if (!mentionTokenRange.value) return

	const insertion = `@${candidate.displayName}`
	const nextText = `${text.value.slice(0, mentionTokenRange.value.start)}${insertion} ${text.value.slice(mentionTokenRange.value.end)}`

	text.value = nextText
	selectedMentions.value.push({
		userAuthUuid: candidate.userAuthUuid,
		displayName: candidate.displayName,
	})
	resetMentions()

	nextTick(() => {
		const textarea = textareaRef.value
		if (!textarea) return
		const nextCaret = mentionTokenRange.value
			? mentionTokenRange.value.start + insertion.length + 1
			: nextText.length
		textarea.focus()
		textarea.setSelectionRange(nextCaret, nextCaret)
	})
}

function buildMentionsPayload(content: string) {
	const mentions: MentionPayload[] = []
	let searchCursor = 0

	for (const mention of selectedMentions.value) {
		const token = `@${mention.displayName}`
		const start = content.indexOf(token, searchCursor)
		if (start === -1) continue
		const end = start + token.length
		mentions.push({
			userAuthUuid: mention.userAuthUuid,
			displayName: mention.displayName,
			start,
			end,
		})
		searchCursor = end
	}

	return mentions
}

function onSend() {
	if (props.disabled) return
	const content = text.value.trimEnd()
	if (!content.trim()) return

	const mentions = buildMentionsPayload(content)
	if (props.editingMessage) {
		emit('saveEdit', {
			messageId: props.editingMessage.id,
			content,
			mentions: mentions.length > 0 ? mentions : undefined,
		})
	} else {
		emit('send', {
			content,
			messageType: 'text',
			mentions: mentions.length > 0 ? mentions : undefined,
		})
	}
	text.value = ''
	selectedMentions.value = []
	resetMentions()
}

function resetScheduleState() {
	scheduledAtInput.value = ''
	scheduleError.value = ''
}

function toggleSchedulePanel() {
	if (props.disabled) return
	showSchedulePanel.value = !showSchedulePanel.value
	if (!showSchedulePanel.value) {
		resetScheduleState()
	}
}

function formatScheduledAt(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function onSchedule() {
	const content = text.value.trimEnd()
	if (!content.trim()) {
		scheduleError.value = 'Сначала введите текст сообщения'
		return
	}

	if (!scheduledAtInput.value) {
		scheduleError.value = 'Выберите дату и время'
		return
	}

	const scheduledDate = new Date(scheduledAtInput.value)
	if (Number.isNaN(scheduledDate.getTime())) {
		scheduleError.value = 'Некорректная дата отправки'
		return
	}

	if (scheduledDate.getTime() <= Date.now()) {
		scheduleError.value = 'Дата отправки уже прошла'
		return
	}

	const mentions = buildMentionsPayload(content)
	emit('schedule', {
		content,
		scheduledAt: scheduledDate.toISOString(),
		mentions: mentions.length > 0 ? mentions : undefined,
	})

	text.value = ''
	selectedMentions.value = []
	resetMentions()
	showSchedulePanel.value = false
	resetScheduleState()
}

function onKeydown(event: KeyboardEvent) {
	if (mentionTokenRange.value && filteredMentionCandidates.value.length > 0) {
		if (event.key === 'ArrowDown') {
			event.preventDefault()
			highlightedMentionIndex.value =
				(highlightedMentionIndex.value + 1) % filteredMentionCandidates.value.length
			return
		}

		if (event.key === 'ArrowUp') {
			event.preventDefault()
			highlightedMentionIndex.value =
				(highlightedMentionIndex.value - 1 + filteredMentionCandidates.value.length) %
				filteredMentionCandidates.value.length
			return
		}

		if (event.key === 'Enter' && !event.shiftKey) {
			event.preventDefault()
			insertMention(filteredMentionCandidates.value[highlightedMentionIndex.value])
			return
		}

		if (event.key === 'Escape') {
			event.preventDefault()
			resetMentions()
			return
		}
	}

	if (event.key === 'Enter' && !event.shiftKey) {
		event.preventDefault()
		onSend()
	}
}

const fileSizeError = ref('')

function onFileSelect(e: Event) {
	if (props.disabled || !props.attachmentsEnabled) return
	const input = e.target as HTMLInputElement
	const file = input.files?.[0]
	if (!file) return
	if (file.size > CHAT_ATTACHMENT_MAX_BYTES) {
		fileSizeError.value = `Файл слишком большой. Максимум ${formatChatUploadLimit(CHAT_ATTACHMENT_MAX_BYTES)}.`
		setTimeout(() => {
			fileSizeError.value = ''
		}, 4000)
		input.value = ''
		return
	}
	fileSizeError.value = ''
	emit('attachment', file)
	input.value = ''
}

function syncSelectedMentionsFromText(value: string) {
	const mentions = new Map<string, { userAuthUuid: string; displayName: string }>()
	for (const candidate of props.mentionCandidates ?? []) {
		const token = `@${candidate.displayName}`
		if (value.includes(token)) {
			mentions.set(candidate.userAuthUuid, {
				userAuthUuid: candidate.userAuthUuid,
				displayName: candidate.displayName,
			})
		}
	}
	selectedMentions.value = Array.from(mentions.values())
}

watch(
	() => props.editingMessage,
	(message) => {
		if (!message) {
			text.value = ''
			selectedMentions.value = []
			resetMentions()
			return
		}
		text.value = message.content ?? ''
		syncSelectedMentionsFromText(text.value)
		nextTick(() => {
			textareaRef.value?.focus()
			const end = text.value.length
			textareaRef.value?.setSelectionRange(end, end)
		})
	},
)

watch(
	() => props.prefilledText,
	(value) => {
		if (!value || props.editingMessage) return
		text.value = value
		syncSelectedMentionsFromText(text.value)
		nextTick(() => {
			textareaRef.value?.focus()
			const end = text.value.length
			textareaRef.value?.setSelectionRange(end, end)
		})
	},
	{ immediate: true },
)
</script>

<template>
	<div class="club-chat-input-shell safe-area-pb glass-header">
		<div v-if="disabled" class="px-4 py-3 text-center text-xs font-medium text-[var(--app-muted-soft)]">
			{{ disabledText }}
		</div>
		<div
			v-if="!disabled && editingMessage"
			class="flex items-center gap-2 border-b border-[var(--app-border)] px-4 py-2"
		>
			<div class="h-8 w-0.5 flex-shrink-0 rounded-full bg-[var(--app-accent)]" />
			<div class="min-w-0 flex-1">
				<p class="text-xs font-medium text-[var(--app-accent-strong)]">Редактирование сообщения</p>
				<p class="truncate text-xs text-[var(--app-muted)]">{{ editingMessage.content || 'Без текста' }}</p>
			</div>
			<button
				class="flex-shrink-0 text-[var(--app-muted-soft)] transition hover:text-[var(--app-text)]"
				@click="$emit('cancelEdit')"
			>
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>
		</div>

		<div v-if="!disabled && replyTo" class="flex items-center gap-2 px-4 py-2 border-b border-[var(--app-border)]">
			<div class="h-8 w-0.5 flex-shrink-0 rounded-full bg-[var(--app-accent-slate)]" />
			<div class="flex-1 min-w-0">
				<p class="text-xs font-medium text-[var(--app-accent-slate)]">{{ getDisplayNameFromReply(replyTo) }}</p>
				<p class="text-xs text-[var(--app-muted)] truncate">{{ replyTo.content || (replyTo.messageType === 'image' ? '📷 Фото' : replyTo.messageType === 'voice' ? '🎤 Голосовое' : '📎 Файл') }}</p>
			</div>
			<button class="text-[var(--app-muted-soft)] hover:text-[var(--app-text)] transition flex-shrink-0" @click="$emit('cancelReply')">
				<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>
		</div>

		<div v-if="fileSizeError" class="px-4 py-1.5 text-xs text-[var(--app-accent-wine)]">
			{{ fileSizeError }}
		</div>

		<div
			v-if="!disabled && showSchedulePanel && canSchedule && !editingMessage"
			class="mx-2 mt-2 rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] px-3 py-3 shadow-[var(--app-shadow-raised)]"
		>
			<p class="text-xs font-medium text-[var(--app-accent-strong)]">Отложенная отправка</p>
			<p class="mt-1 text-[11px] text-[var(--app-muted)]">
				Сообщение отправится автоматически в выбранное время.
			</p>

			<input
				v-model="scheduledAtInput"
				type="datetime-local"
				class="mt-3 w-full rounded-2xl border border-[var(--app-border)] bg-[var(--app-bg)] px-3 py-2.5 text-sm text-[var(--app-text)] outline-none [color-scheme:light] focus:border-[var(--app-accent)]"
			/>

			<p v-if="scheduleError" class="mt-2 text-xs text-[var(--app-accent-wine)]">
				{{ scheduleError }}
			</p>

			<div class="mt-3 flex items-center justify-end gap-2">
				<button
					type="button"
					class="rounded-2xl px-3 py-2 text-xs text-[var(--app-muted)] transition hover:text-[var(--app-text)]"
					@click="toggleSchedulePanel"
				>
					Отмена
				</button>
				<button
					type="button"
					class="rounded-2xl bg-[var(--app-accent)] px-3 py-2 text-xs font-medium text-[var(--app-text-strong)] transition hover:bg-[color-mix(in_srgb,var(--app-accent)_82%,white)]"
					@click="onSchedule"
				>
					Запланировать
				</button>
			</div>

			<div class="mt-4 border-t border-[var(--app-border)] pt-3">
				<div class="flex items-center justify-between gap-2">
					<p class="text-xs font-medium text-[var(--app-text)]">Отложенные сообщения</p>
					<p v-if="scheduledLoading" class="text-[11px] text-[var(--app-muted-soft)]">Обновляю...</p>
				</div>

				<div v-if="scheduledMessages.length === 0" class="mt-2 text-xs text-[var(--app-muted-soft)]">
					Пока пусто
				</div>

				<div v-else class="mt-2 space-y-2">
					<div
						v-for="item in scheduledMessages"
						:key="item.id"
						class="rounded-2xl border border-[var(--app-border)] bg-[var(--app-bg)] px-3 py-2.5"
					>
						<div class="flex items-start justify-between gap-3">
							<div class="min-w-0 flex-1">
								<p class="line-clamp-3 text-sm text-[var(--app-text)]">
									{{ item.content }}
								</p>
								<p class="mt-1 text-[11px] text-[var(--app-muted-soft)]">
									{{ formatScheduledAt(item.scheduledAt) }}
								</p>
							</div>
							<button
								type="button"
								class="flex-shrink-0 text-[var(--app-muted-soft)] transition hover:text-[var(--app-accent-wine)]"
								@click="$emit('deleteScheduled', item.id)"
							>
								<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 18 6M6 6l12 12" />
								</svg>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div
			v-if="!disabled && mentionTokenRange && filteredMentionCandidates.length > 0"
			class="mx-2 mt-2 max-h-60 overflow-y-auto rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] shadow-[var(--app-shadow-floating)]"
		>
			<button
				v-for="(candidate, index) in filteredMentionCandidates"
				:key="candidate.userAuthUuid"
				class="w-full flex items-center gap-3 px-3 py-2.5 text-left transition"
				:class="index === highlightedMentionIndex ? 'bg-[color-mix(in_srgb,var(--app-accent)_12%,var(--app-surface))]' : 'hover:bg-[var(--app-bg)]'"
				@click="insertMention(candidate)"
			>
				<UiAvatar
					:src="getAvatarImageUrl(candidate.avatarUrl) ?? (getAvatarEmoji(candidate.avatarUrl) ? `emoji:${getAvatarEmoji(candidate.avatarUrl)}` : null)"
					:name="candidate.displayName"
					size="sm"
					class="bg-[var(--app-bg-deep)] text-[var(--app-muted)]"
				/>
				<div class="min-w-0">
					<p class="text-sm font-medium text-[var(--app-text)] truncate">{{ candidate.displayName }}</p>
					<p class="text-[11px] text-[var(--app-muted)] truncate">
						{{ candidate.username ? `@${candidate.username}` : candidate.role }}
					</p>
				</div>
			</button>
		</div>

		<div v-if="!disabled" class="club-chat-composer-row flex items-center gap-1.5 px-2 py-2">
			<button
				v-if="canSchedule && !editingMessage"
				type="button"
				class="club-chat-composer-action flex h-9 w-9 flex-shrink-0 items-center justify-center text-[var(--app-muted-soft)] transition hover:text-[var(--app-accent-strong)]"
				@click="toggleSchedulePanel"
			>
				<svg class="h-[20px] w-[20px]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M12 8v4l3 2m6-2a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM7 3v2m10-2v2" />
				</svg>
			</button>

			<button
				class="club-chat-composer-action flex h-9 w-9 flex-shrink-0 items-center justify-center text-[var(--app-muted-soft)] transition hover:text-[var(--app-text)]"
				:class="editingMessage || !attachmentsEnabled ? 'hidden' : 'flex'"
				@click="fileInput?.click()"
			>
				<svg class="w-[22px] h-[22px]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
				</svg>
			</button>
			<input ref="fileInput" type="file" class="hidden" @change="onFileSelect" />

			<textarea
				ref="textareaRef"
				v-model="text"
				placeholder="Сообщение..."
				class="club-chat-composer-textarea flex-1 px-3.5 py-2 rounded-2xl glass-input text-sm resize-none max-h-32 min-h-[36px]"
				rows="1"
				@input="onInput"
				@click="syncMentionQuery"
				@keyup="syncMentionQuery"
				@keydown="onKeydown"
			/>

			<button
				v-if="!text.trim() && !editingMessage"
				class="club-chat-composer-action club-chat-composer-voice flex h-9 w-9 flex-shrink-0 items-center justify-center text-[var(--app-accent-slate)] transition hover:text-[var(--app-text)]"
				@click="$emit('voiceStart')"
			>
				<svg class="w-[20px] h-[20px]" fill="currentColor" viewBox="0 0 24 24">
					<path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" />
				</svg>
			</button>

			<button
				v-else
				class="club-chat-composer-send flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-[var(--app-accent)] text-[var(--app-text-strong)] shadow-[0_10px_24px_color-mix(in_srgb,var(--app-accent-strong)_24%,transparent)] transition hover:bg-[color-mix(in_srgb,var(--app-accent)_82%,white)]"
				@click="onSend"
			>
				<svg v-if="editingMessage" class="h-[18px] w-[18px]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="m5 13 4 4L19 7" />
				</svg>
				<svg v-else class="ml-0.5 h-[18px] w-[18px]" fill="currentColor" viewBox="0 0 24 24">
					<path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
				</svg>
			</button>
		</div>
	</div>
</template>

<style scoped>
.safe-area-pb { padding-bottom: env(safe-area-inset-bottom); }
</style>
