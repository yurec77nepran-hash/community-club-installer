<script setup lang="ts">
import type { Message, MessageMention } from '@community-club/shared/db/schema'
import type { ChatMessage } from '../../stores/chat'

interface Props {
	message: ChatMessage
	isOwn: boolean
	showAuthor?: boolean
	canReact?: boolean
}

const props = defineProps<Props>()
const emit = defineEmits<{
	reply: [message: Message]
	edit: [message: Message]
	react: [messageId: number, emoji: string]
	delete: [messageId: number]
	jumpToReply: [messageId: number]
}>()

const showImageModal = ref(false)
const showVideoPlayer = ref(false)
const showContextMenu = ref(false)
const menuPos = ref({ x: 0, y: 0 })
const quickEmojis = ['👍', '❤️', '😂', '🔥', '😢', '👏', '🎉', '😮', '🥰', '💯']
const auth = useAuthStore()
const chatStore = useChatStore()
const message = computed(() => props.message)

// Swipe-to-reply
const swipeX = ref(0)
const isSwiping = ref(false)
let touchStartX = 0
let touchStartY = 0
let touchStartTime = 0
let swipeTriggered = false
let longPressTimer: ReturnType<typeof setTimeout> | null = null
let longPressFired = false
let menuOpenedAt = 0

const authorName = computed(() => {
	const msg = message.value
	if (msg.author?.fullName) return msg.author.fullName
	if (msg.author?.username) return msg.author.username
	return msg.userAuthUuid?.slice(0, 8) ?? 'Аноним'
})

function getAvatarEmoji(value: string | null | undefined) {
	if (!value?.startsWith('emoji:')) return null
	return value.slice('emoji:'.length) || null
}

function getAvatarImageUrl(value: string | null | undefined) {
	if (!value || value.startsWith('emoji:')) return null
	return value
}

const authorAvatarEmoji = computed(() => getAvatarEmoji(message.value.author?.avatarUrl))
const authorAvatarImageUrl = computed(() => getAvatarImageUrl(message.value.author?.avatarUrl))
const authorInitial = computed(() => authorName.value.trim().charAt(0).toUpperCase())
const showAdminBadge = computed(() => Boolean(message.value.author?.chatAdminBadge))

const groupedReactions = computed(() => {
	const reactions = message.value.reactions ?? []
	const map = new Map<string, { count: number; users: string[] }>()
	for (const r of reactions) {
		if (!map.has(r.emoji)) map.set(r.emoji, { count: 0, users: [] })
		const grouped = map.get(r.emoji)
		if (!grouped) continue
		grouped.count++
		grouped.users.push(r.userAuthUuid)
	}
	return Array.from(map.entries()).map(([emoji, data]) => ({
		emoji,
		count: data.count,
		hasMyReaction: data.users.includes(auth.user?.authUuid ?? ''),
	}))
})

function formatTime(date: string | Date): string {
	const value = new Date(date)
	const now = new Date()
	const isSameDay =
		value.getFullYear() === now.getFullYear() &&
		value.getMonth() === now.getMonth() &&
		value.getDate() === now.getDate()

	if (isSameDay) {
		return value.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
	}

	return value.toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function openMenu(x: number, y: number) {
	const menuW = 220
	const menuH = 160
	const vw = window.innerWidth
	const vh = window.innerHeight
	menuPos.value = {
		x: Math.min(Math.max(8, x), vw - menuW - 8),
		y: Math.min(Math.max(8, y), vh - menuH - 8),
	}
	showContextMenu.value = true
	menuOpenedAt = Date.now()
}

function onContextMenu(e: MouseEvent) {
	e.preventDefault()
	openMenu(e.clientX, e.clientY)
}

function onTouchStart(e: TouchEvent) {
	const touch = e.touches[0]
	touchStartX = touch.clientX
	touchStartY = touch.clientY
	touchStartTime = Date.now()
	swipeTriggered = false
	longPressFired = false
	isSwiping.value = false
	swipeX.value = 0

	longPressTimer = setTimeout(() => {
		longPressFired = true
		// Вибрация для тактильной обратной связи
		if (navigator.vibrate) navigator.vibrate(30)
		openMenu(touch.clientX, touch.clientY)
	}, 400)
}

function onTouchMove(e: TouchEvent) {
	const touch = e.touches[0]
	const dx = touch.clientX - touchStartX
	const dy = touch.clientY - touchStartY

	// Если двигаемся больше по вертикали — это скролл, отменяем всё
	if (Math.abs(dy) > 10 && !isSwiping.value) {
		cancelLongPress()
		return
	}

	// Горизонтальный свайп влево — для ответа
	if (dx < -15 && !longPressFired) {
		cancelLongPress()
		isSwiping.value = true
		// Ограничиваем свайп -80px
		swipeX.value = Math.max(-80, dx)

		if (dx < -60 && !swipeTriggered) {
			swipeTriggered = true
			if (navigator.vibrate) navigator.vibrate(20)
		}
	}

	// Любое существенное движение — отмена long press
	if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
		cancelLongPress()
	}
}

function onTouchEnd() {
	cancelLongPress()

	if (swipeTriggered) {
		emit('reply', props.message)
	}

	// Плавный возврат
	isSwiping.value = false
	swipeX.value = 0
}

function cancelLongPress() {
	if (longPressTimer) {
		clearTimeout(longPressTimer)
		longPressTimer = null
	}
}

function closeMenu() {
	// Защита от закрытия синтетическим click/touchend сразу после открытия
	if (Date.now() - menuOpenedAt < 500) return
	showContextMenu.value = false
}

function onReact(emoji: string) {
	if (props.canReact === false) {
		closeMenu()
		return
	}
	emit('react', props.message.id, emoji)
	closeMenu()
}

function onReply() {
	emit('reply', props.message)
	closeMenu()
}

function onEdit() {
	emit('edit', props.message)
	closeMenu()
}

function onDelete() {
	emit('delete', props.message.id)
	closeMenu()
}

function onCopy() {
	if (props.message.content) {
		navigator.clipboard.writeText(props.message.content)
	}
	closeMenu()
}

function onJumpToReply() {
	if (props.message.replyToId) {
		emit('jumpToReply', props.message.replyToId)
	}
}

const isMediaOnly = computed(() => {
	const t = props.message.messageType
	return (t === 'image' || t === 'video') && props.message.attachmentUrl && !props.message.content
})

const bubbleStyle = computed(() => {
	if (swipeX.value === 0) return { transition: 'transform 0.2s ease' }
	return { transform: `translateX(${swipeX.value}px)` }
})

const deliveryLabel = computed(() => {
	if (!props.isOwn) return null
	if (message.value.deliveryStatus === 'sending') return 'Отправка...'
	if (message.value.deliveryStatus === 'failed') return 'Не отправлено'
	return null
})

const replyTarget = computed(() => {
	if (!message.value.replyToId) return null
	if (message.value.replyTo) return message.value.replyTo
	return (
		chatStore
			.getMessages(message.value.chatId)
			.find((item) => item.id === message.value.replyToId) ?? null
	)
})

function getReplyAuthorName(target: ChatMessage['replyTo'] | ChatMessage | null) {
	if (!target) return 'Сообщение'
	if (target.userAuthUuid === auth.user?.authUuid) return 'Вы'
	return target.author?.fullName || target.author?.username || 'Участница'
}

function getReplyPreviewText(target: ChatMessage['replyTo'] | ChatMessage | null) {
	const content = target?.content?.replace(/\s+/g, ' ').trim()
	if (content) return content

	switch (target?.messageType) {
		case 'image':
			return 'Фото'
		case 'video':
			return 'Видео'
		case 'voice':
			return 'Голосовое'
		case 'audio':
			return 'Аудио'
		case 'document':
			return target.attachmentName || 'Файл'
		default:
			return 'Сообщение'
	}
}

const replyPreview = computed(() => {
	if (!message.value.replyToId) return null
	const target = replyTarget.value
	return {
		author: getReplyAuthorName(target),
		text: getReplyPreviewText(target),
	}
})

const messageContentSegments = computed(() => {
	const content = message.value.content ?? ''
	const mentions = [...(message.value.mentions ?? [])].sort(
		(left, right) => left.startOffset - right.startOffset,
	)

	if (!content || mentions.length === 0) {
		return content ? [{ type: 'text' as const, value: content }] : []
	}

	const segments = [] as Array<
		| { type: 'text'; value: string }
		| { type: 'mention'; value: string; mention: MessageMention; isCurrentUser: boolean }
	>
	let cursor = 0

	for (const mention of mentions) {
		if (mention.startOffset > cursor) {
			segments.push({ type: 'text', value: content.slice(cursor, mention.startOffset) })
		}

		const displayName =
			mention.displayName.trim() || content.slice(mention.startOffset, mention.endOffset)
		segments.push({
			type: 'mention',
			value: displayName,
			mention,
			isCurrentUser: mention.mentionedUserAuthUuid === auth.user?.authUuid,
		})
		cursor = mention.endOffset
	}

	if (cursor < content.length) {
		segments.push({ type: 'text', value: content.slice(cursor) })
	}

	return segments.filter((segment) => segment.value.length > 0)
})
</script>

<template>
	<div
		class="chat-message-bubble flex mb-2 relative"
		:data-message-id="message.id"
		:class="[
			isOwn ? 'justify-end is-own' : 'justify-start items-end gap-2 is-guest',
			showAdminBadge ? 'is-admin' : '',
		]"
	>
		<div
			v-if="!isOwn"
			class="self-end rounded-full"
		>
			<UiAvatar
				:src="authorAvatarImageUrl ?? (authorAvatarEmoji ? `emoji:${authorAvatarEmoji}` : null)"
				:name="authorName"
				size="sm"
				class="bg-[var(--app-bg-deep)] text-[var(--app-muted)]"
			/>
		</div>

		<!-- Reply arrow indicator -->
		<div
			v-if="swipeX < -20"
			class="absolute top-1/2 -translate-y-1/2 transition-opacity"
			:class="isOwn ? 'right-0' : 'left-0'"
			:style="{ opacity: Math.min(1, Math.abs(swipeX) / 60) }"
		>
			<svg class="h-5 w-5 text-[var(--app-accent-slate)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a5 5 0 015 5v3M3 10l6 6M3 10l6-6" />
			</svg>
		</div>

		<div class="max-w-[80%] relative" :style="bubbleStyle">
			<!-- Author name -->
			<span
				v-if="showAuthor && !isOwn"
				class="mb-0.5 ml-3 inline-flex max-w-full items-center gap-1.5 text-[11px] font-medium text-[var(--app-muted)]"
			>
				<span class="min-w-0 truncate">{{ authorName }}</span>
				<span v-if="showAdminBadge" class="chat-admin-badge">
					<svg class="chat-admin-badge-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 3 5.5 5.5v5.4c0 4.1 2.6 7.8 6.5 9.1 3.9-1.3 6.5-5 6.5-9.1V5.5L12 3Z" />
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="m9 12 2 2 4-4" />
					</svg>
					Админ
				</span>
			</span>

			<!-- Reply reference -->
			<div
				v-if="replyPreview"
				class="chat-reply-preview mb-1 ml-3"
				@click.stop="onJumpToReply"
			>
				<span class="chat-reply-author">{{ replyPreview.author }}</span>
				<span class="chat-reply-text">{{ replyPreview.text }}</span>
			</div>

			<!-- Media-only bubble (image/video without text) -->
			<div
				v-if="isMediaOnly"
				class="chat-message-card chat-message-media relative overflow-hidden select-none border shadow-[0_12px_30px_rgba(0,0,0,0.28)]"
				:class="
					isOwn
						? 'rounded-2xl rounded-br-sm border-slate-300/30 bg-[linear-gradient(180deg,rgba(71,85,105,0.34),rgba(30,41,59,0.28))]'
						: 'rounded-2xl rounded-bl-sm border-white/10 bg-[linear-gradient(180deg,rgba(17,19,24,0.98),rgba(8,10,15,0.98))]'
				"
				@contextmenu="onContextMenu"
				@touchstart.passive="onTouchStart"
				@touchend.passive="onTouchEnd"
				@touchmove.passive="onTouchMove"
			>
				<img
					v-if="message.messageType === 'image'"
					:src="message.attachmentUrl"
					:alt="message.attachmentName || 'Изображение'"
					class="max-w-[260px] max-h-[300px] object-cover cursor-pointer block"
					loading="lazy"
					@click.stop="showImageModal = true"
				/>
				<div v-else-if="message.messageType === 'video'" class="relative max-w-[260px] max-h-[300px] cursor-pointer" @click.stop="showVideoPlayer = true">
					<video :src="message.attachmentUrl" class="max-w-[260px] max-h-[300px] block" preload="metadata" playsinline />
					<div class="absolute inset-0 flex items-center justify-center">
						<div class="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center"><svg class="w-6 h-6 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg></div>
					</div>
				</div>
				<div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent px-2.5 pb-1.5 pt-5 pointer-events-none">
					<div class="flex items-center gap-1.5" :class="isOwn ? 'justify-end' : ''">
						<span
							v-if="isOwn && showAuthor"
							class="inline-flex items-center gap-1 text-[10px] text-white/70 media-text-shadow"
						>
							<span class="min-w-0 truncate">{{ authorName }}</span>
							<span v-if="showAdminBadge" class="chat-admin-badge is-compact">
								<svg class="chat-admin-badge-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 3 5.5 5.5v5.4c0 4.1 2.6 7.8 6.5 9.1 3.9-1.3 6.5-5 6.5-9.1V5.5L12 3Z" />
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="m9 12 2 2 4-4" />
								</svg>
								Админ
							</span>
						</span>
						<span
							v-if="!isOwn && showAuthor"
							class="inline-flex items-center gap-1 text-[10px] font-medium text-white/90 media-text-shadow"
						>
							<span class="min-w-0 truncate">{{ authorName }}</span>
							<span v-if="showAdminBadge" class="chat-admin-badge is-compact">
								<svg class="chat-admin-badge-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 3 5.5 5.5v5.4c0 4.1 2.6 7.8 6.5 9.1 3.9-1.3 6.5-5 6.5-9.1V5.5L12 3Z" />
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="m9 12 2 2 4-4" />
								</svg>
								Админ
							</span>
						</span>
						<span class="text-[10px] text-white/80 select-none media-text-shadow">{{ formatTime(message.createdAt) }}</span>
					</div>
				</div>
			</div>

			<!-- Regular bubble -->
			<div
				v-else
				class="chat-message-card rounded-2xl border px-3.5 py-2 select-none"
				:class="[
					isOwn ? 'rounded-br-sm' : 'rounded-bl-sm',
				]"
				@contextmenu="onContextMenu"
				@touchstart.passive="onTouchStart"
				@touchend.passive="onTouchEnd"
				@touchmove.passive="onTouchMove"
			>
				<div v-if="message.messageType === 'image' && message.attachmentUrl" class="mb-1 -mx-3.5 -mt-2">
					<img :src="message.attachmentUrl" :alt="message.attachmentName || 'Изображение'" class="w-full max-h-[300px] object-cover cursor-pointer rounded-t-2xl" loading="lazy" @click.stop="showImageModal = true" />
				</div>
				<div v-if="message.messageType === 'video' && message.attachmentUrl" class="mb-1 -mx-3.5 -mt-2 relative cursor-pointer" @click.stop="showVideoPlayer = true">
					<video :src="message.attachmentUrl" class="w-full max-h-[300px] rounded-t-2xl" preload="metadata" playsinline />
					<div class="absolute inset-0 flex items-center justify-center">
						<div class="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center"><svg class="w-6 h-6 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg></div>
					</div>
				</div>
				<div v-if="message.messageType === 'audio' && message.attachmentUrl" class="mb-1 min-w-[200px]">
					<audio :src="message.attachmentUrl" controls class="w-full h-10" preload="metadata" @click.stop />
				</div>
				<div v-if="message.messageType === 'voice' && message.attachmentUrl" class="min-w-[200px]" @click.stop>
					<ChatVoicePlayer :src="message.attachmentUrl" :is-own="isOwn" />
				</div>
				<a v-if="message.messageType === 'document' && message.attachmentUrl" :href="message.attachmentUrl" target="_blank" class="flex items-center gap-2 mb-1 hover:opacity-80" @click.stop>
					<svg class="w-5 h-5 flex-shrink-0 text-[var(--app-accent-slate)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
					<span class="text-xs truncate underline">{{ message.attachmentName || 'Документ' }}</span>
				</a>
				<p v-if="messageContentSegments.length" class="text-sm whitespace-pre-wrap break-words">
					<template v-for="(segment, index) in messageContentSegments" :key="`${message.id}-${index}`">
						<span v-if="segment.type === 'text'">{{ segment.value }}</span>
						<span
							v-else
							class="inline font-medium"
							:class="segment.isCurrentUser ? 'text-[var(--app-accent-wine)]' : 'text-[var(--app-accent-strong)]'"
						>
							{{ segment.value }}
						</span>
					</template>
				</p>
				<div class="flex items-center gap-1.5 mt-0.5" :class="isOwn ? 'justify-end' : ''">
						<span
							v-if="isOwn && showAuthor"
							class="inline-flex items-center gap-1 text-[10px] text-[var(--app-muted-soft)]"
						>
							<span class="min-w-0 truncate">{{ authorName }}</span>
							<span v-if="showAdminBadge" class="chat-admin-badge is-compact">
								<svg class="chat-admin-badge-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 3 5.5 5.5v5.4c0 4.1 2.6 7.8 6.5 9.1 3.9-1.3 6.5-5 6.5-9.1V5.5L12 3Z" />
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="m9 12 2 2 4-4" />
								</svg>
								Админ
							</span>
						</span>
					<span v-if="deliveryLabel" class="text-[10px]" :class="message.deliveryStatus === 'failed' ? 'text-[var(--app-accent-wine)]' : 'text-[var(--app-muted-soft)]'">
						{{ deliveryLabel }}
					</span>
					<span class="text-[10px] select-none text-[var(--app-muted-soft)]">{{ formatTime(message.createdAt) }}</span>
				</div>
			</div>

			<!-- Reactions -->
			<div v-if="groupedReactions.length" class="mt-1 ml-1 flex flex-wrap gap-1">
				<button
					v-for="r in groupedReactions"
					:key="r.emoji"
					class="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-xs transition"
					:class="r.hasMyReaction ? 'border border-[color-mix(in_srgb,var(--app-accent)_46%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_14%,var(--app-surface))]' : 'border border-[var(--app-border)] bg-[var(--app-surface)]'"
					:disabled="canReact === false"
					@click="emit('react', message.id, r.emoji)"
				>
					<span>{{ r.emoji }}</span>
					<span class="text-[var(--app-muted)]">{{ r.count }}</span>
				</button>
			</div>
		</div>

		<div
			v-if="isOwn"
			class="self-end rounded-full"
		>
			<UiAvatar
				:src="authorAvatarImageUrl ?? (authorAvatarEmoji ? `emoji:${authorAvatarEmoji}` : null)"
				:name="authorName"
				size="sm"
				class="bg-[var(--app-bg-deep)] text-[var(--app-muted)]"
			/>
		</div>
	</div>

	<!-- Context menu overlay -->
	<Teleport to="body">
		<div
			v-if="showContextMenu"
			class="fixed inset-0 z-[90]"
			@click.self="closeMenu"
			@contextmenu.prevent="closeMenu"
		>
			<div
				class="fixed z-[91] w-[220px] context-menu-appear"
				:style="{ left: menuPos.x + 'px', top: menuPos.y + 'px' }"
				@click.stop
			>
				<div v-if="canReact !== false" class="bg-[color-mix(in_srgb,var(--app-surface)_94%,transparent)] backdrop-blur-2xl border border-[var(--app-border)] rounded-2xl mb-1.5 px-1.5 py-1.5 overflow-x-auto flex gap-0.5 shadow-[var(--app-shadow-floating)] scrollbar-hide">
					<button v-for="e in quickEmojis" :key="e" class="w-9 h-9 text-[20px] flex items-center justify-center flex-shrink-0 rounded-xl hover:bg-[var(--app-bg-deep)] active:scale-110 transition-transform" @click="onReact(e)">{{ e }}</button>
				</div>
				<div class="bg-[color-mix(in_srgb,var(--app-surface)_96%,transparent)] backdrop-blur-2xl border border-[var(--app-border)] rounded-2xl overflow-hidden shadow-[var(--app-shadow-floating)]">
					<button class="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[var(--app-text)] hover:bg-[var(--app-bg)] active:bg-[var(--app-bg-deep)] transition" @click="onReply">
						<svg class="w-[18px] h-[18px] text-[var(--app-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a5 5 0 015 5v3M3 10l6 6M3 10l6-6" /></svg>
						Ответить
					</button>
					<button
						v-if="isOwn && message.content"
						class="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[var(--app-text)] hover:bg-[var(--app-bg)] active:bg-[var(--app-bg-deep)] transition"
						@click="onEdit"
					>
						<svg class="h-[18px] w-[18px] text-[var(--app-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2v-5m-1.414-9.414a2 2 0 1 1 2.828 2.828L12 15l-4 1 1-4 8.586-8.586Z" />
						</svg>
						Редактировать
					</button>
					<button v-if="message.content" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[var(--app-text)] hover:bg-[var(--app-bg)] active:bg-[var(--app-bg-deep)] transition" @click="onCopy">
						<svg class="w-[18px] h-[18px] text-[var(--app-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
						Скопировать
					</button>
					<button v-if="isOwn" class="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[var(--app-accent-wine)] hover:bg-[color-mix(in_srgb,var(--app-accent-wine)_8%,var(--app-surface))] active:bg-[color-mix(in_srgb,var(--app-accent-wine)_12%,var(--app-surface))] transition" @click="onDelete">
						<svg class="w-[18px] h-[18px]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
						Удалить
					</button>
				</div>
			</div>
		</div>
	</Teleport>

	<!-- Fullscreen video player -->
	<Teleport to="body">
		<ChatVideoPlayer
			v-if="showVideoPlayer && message.attachmentUrl"
			:src="message.attachmentUrl!"
			@close="showVideoPlayer = false"
		/>
	</Teleport>

	<!-- Fullscreen image modal -->
	<Teleport to="body">
		<div v-if="showImageModal && message.attachmentUrl" class="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-4" @click="showImageModal = false">
			<button class="absolute right-4 top-4 z-10 text-white/60 hover:text-white" @click="showImageModal = false">
				<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
			</button>
			<MediaImageViewer :src="message.attachmentUrl" :alt="message.attachmentName || 'Изображение'" @click.stop />
		</div>
	</Teleport>
</template>

<style scoped>
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
.media-text-shadow { text-shadow: 0 1px 3px rgba(0,0,0,0.8); }
.context-menu-appear { animation: ctx-pop 0.15s ease-out; }
.chat-message-bubble .chat-message-card:not(.chat-message-media) {
	border-color: var(--app-border);
	background: linear-gradient(145deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px 0 rgb(255 255 255 / 0.96), var(--app-shadow-soft);
	color: var(--app-text);
}
.chat-message-bubble.is-own .chat-message-card:not(.chat-message-media) {
	border-color: color-mix(in srgb, var(--app-accent) 46%, var(--app-border));
	background: linear-gradient(145deg, color-mix(in srgb, var(--app-accent) 16%, var(--app-surface)), var(--app-bg));
}
.chat-message-bubble.is-admin .chat-message-card:not(.chat-message-media) {
	border-color: color-mix(in srgb, var(--app-accent-wine) 38%, var(--app-border));
	background: linear-gradient(145deg, color-mix(in srgb, var(--app-accent-wine) 9%, var(--app-surface)), var(--app-surface));
	box-shadow: inset 2px 0 0 var(--app-accent-wine), inset 0 1px 0 rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}
.chat-admin-badge {
	display: inline-flex;
	flex-shrink: 0;
	align-items: center;
	gap: 0.2rem;
	border: 1px solid color-mix(in srgb, var(--app-accent-slate) 38%, var(--app-border));
	border-radius: 999px;
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent-slate) 14%, var(--app-surface)), var(--app-surface));
	box-shadow: 0 0.35rem 0.9rem color-mix(in srgb, var(--app-accent-slate) 14%, transparent);
	color: var(--app-accent-slate);
	font-size: 0.58rem;
	font-weight: 800;
	letter-spacing: 0.055em;
	line-height: 1;
	padding: 0.14rem 0.36rem 0.15rem;
	text-transform: uppercase;
	text-shadow: none;
}
.chat-admin-badge.is-compact {
	font-size: 0.52rem;
	padding: 0.1rem 0.28rem 0.12rem;
}
.chat-admin-badge-icon {
	height: 0.62rem;
	width: 0.62rem;
}
.chat-reply-preview {
	display: flex;
	max-width: min(18rem, 74vw);
	cursor: pointer;
	align-items: center;
	gap: 0.4rem;
	overflow: hidden;
	border-left: 2px solid var(--app-accent-slate);
	border-radius: 0.65rem;
	background: linear-gradient(90deg, color-mix(in srgb, var(--app-accent-slate) 10%, var(--app-surface)), var(--app-surface));
	padding: 0.42rem 0.55rem;
	transition:
		background 0.18s ease,
		border-color 0.18s ease;
}
.chat-reply-preview:hover {
	border-color: var(--app-accent);
	background: linear-gradient(90deg, color-mix(in srgb, var(--app-accent) 12%, var(--app-surface)), var(--app-surface));
}
.chat-reply-author {
	min-width: 0;
	max-width: 7.5rem;
	flex-shrink: 0;
	overflow: hidden;
	color: var(--app-text-strong);
	font-size: 0.72rem;
	font-weight: 800;
	line-height: 1.1;
	text-overflow: ellipsis;
	white-space: nowrap;
}
.chat-reply-text {
	min-width: 0;
	overflow: hidden;
	color: var(--app-muted);
	font-size: 0.72rem;
	line-height: 1.1;
	text-overflow: ellipsis;
	white-space: nowrap;
}
@keyframes ctx-pop {
	from { opacity: 0; transform: scale(0.92); }
	to { opacity: 1; transform: scale(1); }
}
</style>
