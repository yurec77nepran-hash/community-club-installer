<script setup lang="ts">
interface Props {
	src: string
	isOwn: boolean
}

const props = defineProps<Props>()

const audio = ref<HTMLAudioElement | null>(null)
const playing = ref(false)
const currentTime = ref(0)
const totalDuration = ref(0)
const progress = ref(0)
const bars = ref<number[]>(Array(40).fill(3))
const barsLoaded = ref(false)
const speeds = [1, 1.5, 2, 0.5]
const speedIndex = ref(0)
const playbackRate = computed(() => speeds[speedIndex.value])

function cycleSpeed() {
	speedIndex.value = (speedIndex.value + 1) % speeds.length
	if (audio.value) audio.value.playbackRate = playbackRate.value
}

// Декодируем реальный аудио-файл и строим waveform
async function loadWaveform() {
	if (barsLoaded.value) return
	try {
		const response = await fetch(props.src)
		const arrayBuffer = await response.arrayBuffer()
		const audioCtx = new AudioContext()
		const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer)
		const channelData = audioBuffer.getChannelData(0)
		audioCtx.close()

		const numBars = 40
		const blockSize = Math.floor(channelData.length / numBars)
		const result: number[] = []

		for (let i = 0; i < numBars; i++) {
			let sum = 0
			const start = i * blockSize
			for (let j = start; j < start + blockSize && j < channelData.length; j++) {
				sum += Math.abs(channelData[j])
			}
			result.push(sum / blockSize)
		}

		// Нормализуем к высоте 2-14px
		const max = Math.max(...result, 0.001)
		bars.value = result.map((v) => Math.max(2, Math.round((v / max) * 14)))
		barsLoaded.value = true
	} catch {
		// Fallback — оставляем дефолтные
	}
}

onMounted(loadWaveform)

function togglePlay() {
	if (!audio.value) return
	if (playing.value) audio.value.pause()
	else audio.value.play()
}

function onPlay() {
	playing.value = true
	if (audio.value) audio.value.playbackRate = playbackRate.value
}
function onPause() {
	playing.value = false
}
function onEnded() {
	playing.value = false
	progress.value = 0
	currentTime.value = 0
}

function onTimeUpdate() {
	if (!audio.value) return
	currentTime.value = audio.value.currentTime
	if (audio.value.duration && Number.isFinite(audio.value.duration)) {
		progress.value = audio.value.currentTime / audio.value.duration
	}
}

function onLoadedMetadata() {
	if (audio.value && Number.isFinite(audio.value.duration)) {
		totalDuration.value = audio.value.duration
	}
}

function formatTime(s: number): string {
	const m = Math.floor(s / 60)
	const sec = Math.floor(s % 60)
	return `${m}:${sec.toString().padStart(2, '0')}`
}

const displayTime = computed(() => {
	if (playing.value || currentTime.value > 0) return formatTime(currentTime.value)
	if (totalDuration.value > 0) return formatTime(totalDuration.value)
	return '0:00'
})

const filledBars = computed(() => Math.round(progress.value * bars.value.length))
</script>

<template>
	<div class="flex items-center gap-2">
		<audio ref="audio" :src="src" preload="metadata" @play="onPlay" @pause="onPause" @ended="onEnded" @timeupdate="onTimeUpdate" @loadedmetadata="onLoadedMetadata" />
		<button class="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full" :class="isOwn ? 'bg-[color-mix(in_srgb,var(--app-accent)_20%,var(--app-surface))]' : 'bg-[color-mix(in_srgb,var(--app-accent-slate)_14%,var(--app-surface))]'" @click="togglePlay">
			<svg v-if="!playing" class="w-3.5 h-3.5 text-[var(--app-accent-strong)] ml-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
			<svg v-else class="w-3.5 h-3.5 text-[var(--app-accent-strong)]" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
		</button>
		<div class="flex-1 flex items-center gap-2 min-w-0">
			<div class="flex items-center gap-[1.5px] h-[16px] flex-1">
				<div
					v-for="(h, i) in bars"
					:key="i"
					class="w-[2px] rounded-sm transition-colors duration-100"
					:class="i < filledBars ? (isOwn ? 'bg-[var(--app-accent-strong)]' : 'bg-[var(--app-accent-slate)]') : 'bg-[var(--app-border)]'"
					:style="{ height: h + 'px' }"
				/>
			</div>
			<button
				v-if="playing || speedIndex !== 0"
				class="text-[10px] tabular-nums flex-shrink-0 px-1 py-0.5 rounded font-bold"
				:class="isOwn ? 'bg-[color-mix(in_srgb,var(--app-accent)_12%,var(--app-surface))] text-[var(--app-accent-strong)]' : 'bg-[color-mix(in_srgb,var(--app-accent-slate)_12%,var(--app-surface))] text-[var(--app-accent-slate)]'"
				@click.stop="cycleSpeed"
			>{{ playbackRate }}x</button>
			<span class="text-[10px] tabular-nums flex-shrink-0 text-[var(--app-muted-soft)]">{{ displayTime }}</span>
		</div>
	</div>
</template>
