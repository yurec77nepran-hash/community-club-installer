<script setup lang="ts">
import type { SiteBrandingSettings } from '@community-club/shared/types'

const api = useApi()

const defaultBranding: SiteBrandingSettings = {
	clubName: 'Community Club',
	homeLogoEnabled: true,
	homeLogoMediaKey: null,
	buttonBackgroundColor: '#d4a62a',
	appBackgroundColor: '#f7f5f0',
	appSurfaceColor: '#ffffff',
	appTextColor: '#1f1f1f',
	appAccentColor: '#d4a62a',
	homeLogoUrl: null,
}

const { data: branding } = await useAsyncData(
	'site-branding-settings',
	async () => {
		const res = await api.get<SiteBrandingSettings>('/api/site-settings/branding')
		return res.success ? res.data : defaultBranding
	},
	{ default: () => defaultBranding },
)

const logoVisible = computed(() => branding.value?.homeLogoEnabled ?? true)
const logoUrl = computed(() => branding.value?.homeLogoUrl ?? null)
</script>

<template>
	<div v-if="logoVisible" class="club-home-logo">
		<img
			v-if="logoUrl"
			:src="'/pwa-icon?size=512&format=webp'"
			alt="Логотип клуба"
			width="512"
			height="512"
			loading="eager"
			fetchpriority="high"
			decoding="async"
			class="club-home-logo-image"
		/>
		<div v-else class="club-home-logo-placeholder" role="img" aria-label="Логотип клуба">
			<span class="club-home-logo-mark" aria-hidden="true">
				<span />
				<span />
				<span />
				<span />
			</span>
			<span class="club-home-logo-text">Логотип клуба</span>
		</div>
	</div>
</template>

<style scoped>
.club-home-logo {
	display: flex;
	justify-content: center;
}

.club-home-logo-image {
	width: 100%;
	max-height: 96px;
	object-fit: contain;
	filter: drop-shadow(0 18px 42px color-mix(in srgb, var(--app-text) 14%, transparent));
}

.club-home-logo-placeholder {
	display: flex;
	min-height: 86px;
	width: 100%;
	align-items: center;
	justify-content: center;
	gap: 14px;
	border: 1px solid var(--app-border);
	border-radius: 24px;
	background:
		linear-gradient(135deg, rgb(255 255 255 / 0.96), color-mix(in srgb, var(--app-bg) 88%, transparent)),
		var(--app-surface);
	box-shadow: inset 0 1px 0 rgb(255 255 255 / 0.96), var(--app-shadow-raised);
	color: var(--app-muted);
}

.club-home-logo-mark {
	display: grid;
	width: 38px;
	height: 38px;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 5px;
	transform: rotate(45deg);
}

.club-home-logo-mark span {
	border: 1px solid var(--app-border-strong);
	border-radius: 8px;
	background: color-mix(in srgb, var(--app-accent) 12%, var(--app-surface));
}

.club-home-logo-mark span:nth-child(2),
.club-home-logo-mark span:nth-child(3) {
	background: color-mix(in srgb, var(--app-accent) 24%, var(--app-surface));
}

.club-home-logo-text {
	font-size: 11px;
	font-weight: 700;
	letter-spacing: 0.16em;
	line-height: 1.1;
	text-transform: uppercase;
}
</style>
