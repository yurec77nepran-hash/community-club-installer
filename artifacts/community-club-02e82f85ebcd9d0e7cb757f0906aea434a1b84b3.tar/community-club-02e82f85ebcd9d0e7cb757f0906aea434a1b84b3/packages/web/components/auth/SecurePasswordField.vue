<script setup lang="ts">
import { computed, nextTick, ref, useAttrs } from 'vue'

defineOptions({ inheritAttrs: false })

const props = withDefaults(
	defineProps<{
		modelValue: string
		placeholder?: string
		autocomplete?: string
		required?: boolean
		disabled?: boolean
		minlength?: number | string
		invalid?: boolean
	}>(),
	{
		placeholder: 'Пароль',
		autocomplete: 'current-password',
		required: false,
		disabled: false,
		minlength: undefined,
		invalid: false,
	},
)

const emit = defineEmits<(e: 'update:modelValue', value: string) => void>()

const attrs = useAttrs()
const visible = ref(false)
const inputEl = ref<HTMLInputElement | null>(null)

const inputAttrs = computed(() => {
	const { class: _class, ...rest } = attrs
	return rest
})

const inputClass = computed(() => [
	'w-full rounded-xl glass-input px-4 py-3 pr-12',
	props.invalid ? 'border border-[var(--app-danger)] text-[var(--app-danger)]' : '',
	attrs.class,
])

const inputStyle = computed(() => ({
	color: 'var(--app-text)',
	caretColor: 'var(--app-text)',
	backgroundColor: 'var(--app-surface)',
	WebkitTextFillColor: 'var(--app-text)',
	WebkitBoxShadow: '0 0 0 1000px var(--app-surface) inset',
	boxShadow: '0 0 0 1000px var(--app-surface) inset',
	backgroundClip: 'padding-box',
	WebkitBackgroundClip: 'padding-box',
}))

function updateValue(event: Event) {
	const target = event.target as HTMLInputElement
	emit('update:modelValue', target.value)
}

async function toggleVisibility() {
	visible.value = !visible.value
	await nextTick()
	if (inputEl.value) {
		const caret = props.modelValue.length
		inputEl.value.focus({ preventScroll: true })
		inputEl.value.setSelectionRange(caret, caret)
	}
}

function handlePaste(event: ClipboardEvent) {
	const plainText = event.clipboardData?.getData('text/plain')
	if (typeof plainText !== 'string') return
	event.preventDefault()
	emit('update:modelValue', plainText)
	nextTick(() => {
		if (inputEl.value) {
			const caret = plainText.length
			inputEl.value.focus({ preventScroll: true })
			inputEl.value.setSelectionRange(caret, caret)
		}
	})
}
</script>

<template>
	<div class="relative">
		<input
			ref="inputEl"
			:value="modelValue"
			:type="visible ? 'text' : 'password'"
			:placeholder="placeholder"
			:autocomplete="autocomplete"
			:required="required"
			:disabled="disabled"
			:minlength="minlength"
			autocapitalize="off"
			autocorrect="off"
			spellcheck="false"
			inputmode="text"
			data-1p-ignore="true"
			data-lpignore="true"
			data-secure-input="true"
			v-bind="inputAttrs"
			:class="inputClass"
			:style="inputStyle"
			@input="updateValue"
			@paste="handlePaste"
		/>
		<button
			type="button"
			tabindex="-1"
			class="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--app-muted-soft)] transition hover:text-[var(--app-accent-strong)]"
			aria-label="Показать или скрыть пароль"
			@pointerdown.prevent
			@mousedown.prevent
			@click="toggleVisibility"
		>
			<svg v-if="!visible" class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
			</svg>
			<svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
			</svg>
		</button>
	</div>
</template>
