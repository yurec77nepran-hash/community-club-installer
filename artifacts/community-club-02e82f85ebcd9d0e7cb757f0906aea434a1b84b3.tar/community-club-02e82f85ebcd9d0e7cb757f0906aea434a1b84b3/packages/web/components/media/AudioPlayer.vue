<script setup lang="ts">
interface AudioTrack {
	fileIndex: number
	src: string
	title?: string
	downloadUrl?: string | null
	downloadable?: boolean
}

interface Props {
	src?: string
	title?: string
	downloadUrl?: string | null
	downloadable?: boolean
	mediaFileIndex?: number | null
	initialTime?: number | null
	initialTrackIndex?: number | null
	playlist?: AudioTrack[]
	showPlaylistList?: boolean
	activeMediaFileIndex?: number | null
	autoplaySignal?: number
	canGoPrevious?: boolean
	canGoNext?: boolean
	crossCardNavigation?: boolean
}

const props = defineProps<Props>()
const emit = defineEmits<{
	progress: [
		payload: {
			mediaFileIndex: number
			positionSeconds: number
			durationSeconds: number | null
			completed: boolean
		},
	]
	activated: [mediaFileIndex: number]
	requestPrevious: []
	requestNext: []
}>()

const audioRef = ref<HTMLAudioElement>()
const playing = ref(false)
const currentTime = ref(0)
const duration = ref(0)
const playbackRate = ref(1)
const downloading = ref(false)
const downloadError = ref('')
const trackIndex = ref(0)
const playbackRates = [0.75, 1, 1.25, 1.5, 2]
let objectUrl: string | null = null
let initialTimeApplied = false
let pointerSeeking = false

const tracks = computed<AudioTrack[]>(() => {
	if (props.playlist?.length) return props.playlist
	if (!props.src) return []
	return [
		{
			fileIndex: Math.max(0, Math.round(props.mediaFileIndex ?? 0)),
			src: props.src,
			title: props.title,
			downloadUrl: props.downloadUrl ?? null,
			downloadable: props.downloadable,
		},
	]
})

const activeTrack = computed(() => tracks.value[trackIndex.value] ?? null)
const hasPlaylist = computed(() => tracks.value.length > 1)
const showPlaylistList = computed(() => props.showPlaylistList !== false && hasPlaylist.value)
const canSeek = computed(() => duration.value > 0)

function normalizeTrackIndex(index: number | null | undefined) {
	if (!tracks.value.length) return 0
	if (typeof index !== 'number' || !Number.isInteger(index)) return 0
	const foundIndex = tracks.value.findIndex((track) => track.fileIndex === index)
	return foundIndex >= 0 ? foundIndex : 0
}

function cleanupObjectUrl() {
	if (!objectUrl) return
	URL.revokeObjectURL(objectUrl)
	objectUrl = null
}

function applyInitialTime() {
	const audio = audioRef.value
	const track = activeTrack.value
	if (!audio || !track || initialTimeApplied) return
	if (track.fileIndex !== Math.max(0, Math.round(props.initialTrackIndex ?? 0))) {
		initialTimeApplied = true
		return
	}
	const target = Math.max(0, Math.floor(props.initialTime ?? 0))
	if (target < 2) {
		initialTimeApplied = true
		return
	}
	if (Number.isFinite(audio.duration) && audio.duration > 0) {
		audio.currentTime = Math.min(target, Math.max(0, audio.duration - 1))
		currentTime.value = audio.currentTime
		initialTimeApplied = true
		return
	}
	audio.currentTime = target
	currentTime.value = audio.currentTime
	initialTimeApplied = true
}

function emitPlaybackProgress(forceCompleted = false) {
	const audio = audioRef.value
	const track = activeTrack.value
	if (!audio || !track) return
	const durationValue =
		Number.isFinite(audio.duration) && audio.duration > 0 ? Math.round(audio.duration) : null
	const position = Math.max(0, Math.round(audio.currentTime || 0))
	const completed =
		forceCompleted || (durationValue != null && durationValue > 0 && position >= durationValue - 3)

	emit('progress', {
		mediaFileIndex: track.fileIndex,
		positionSeconds: completed ? 0 : position,
		durationSeconds: durationValue,
		completed,
	})
}

async function loadCurrentTrack(autoplay = false) {
	const audio = audioRef.value
	const track = activeTrack.value
	if (!audio || !track) return

	cleanupObjectUrl()
	initialTimeApplied = false
	currentTime.value = 0
	duration.value = 0
	downloadError.value = ''
	audio.pause()
	audio.removeAttribute('src')
	audio.load()

	audio.src = track.src
	audio.currentTime = 0
	if (autoplay) {
		try {
			await audio.play()
		} catch {}
	}
}

function setTrack(nextIndex: number) {
	if (!tracks.value.length) return
	emitPlaybackProgress()
	const wrappedIndex =
		((nextIndex % tracks.value.length) + tracks.value.length) % tracks.value.length
	const shouldAutoplay = playing.value
	trackIndex.value = wrappedIndex
	void loadCurrentTrack(shouldAutoplay)
}

function selectTrack(index: number) {
	if (index === trackIndex.value) return
	setTrack(index)
}

function playPrevious() {
	if (props.crossCardNavigation) {
		emitPlaybackProgress()
		emit('requestPrevious')
		return
	}
	if (hasPlaylist.value) {
		setTrack(trackIndex.value - 1)
		return
	}
	skipBy(-15)
}

function playNext() {
	if (props.crossCardNavigation) {
		emitPlaybackProgress()
		emit('requestNext')
		return
	}
	if (hasPlaylist.value) {
		setTrack(trackIndex.value + 1)
		return
	}
	skipBy(15)
}

function skipBy(seconds: number) {
	if (!audioRef.value) return
	audioRef.value.currentTime = Math.max(
		0,
		Math.min(duration.value, audioRef.value.currentTime + seconds),
	)
	emitPlaybackProgress()
}

function seekTo(value: number) {
	if (!audioRef.value || !canSeek.value) return
	audioRef.value.currentTime = Math.max(0, Math.min(duration.value, value))
	currentTime.value = audioRef.value.currentTime
}

function handleSeekInput(event: Event) {
	const target = event.target as HTMLInputElement
	const value = Number(target.value)
	if (!Number.isFinite(value)) return
	seekTo(value)
}

function handleSeekChange(event: Event) {
	handleSeekInput(event)
	pointerSeeking = false
	emitPlaybackProgress()
}

function togglePlay() {
	const audio = audioRef.value
	if (!audio) return
	if (audio.paused) void audio.play()
	else audio.pause()
}

function cycleRate() {
	if (!audioRef.value) return
	const idx = playbackRates.indexOf(playbackRate.value)
	playbackRate.value = playbackRates[(idx + 1) % playbackRates.length]
	audioRef.value.playbackRate = playbackRate.value
}

async function downloadAudio() {
	const track = activeTrack.value
	if (!import.meta.client || !track?.downloadable || !track.downloadUrl || downloading.value) return

	const config = useRuntimeConfig()
	downloading.value = true
	downloadError.value = ''

	try {
		const response = await fetch(`${config.public.apiUrl}${track.downloadUrl}`, {
			credentials: 'include',
		})
		if (!response.ok) {
			throw new Error('DOWNLOAD_FAILED')
		}

		const blob = await response.blob()
		const localObjectUrl = URL.createObjectURL(blob)
		const link = document.createElement('a')
		link.href = localObjectUrl
		link.download = track.title?.trim() ? `${track.title.trim()}.ogg` : 'audio.ogg'
		link.rel = 'noopener'
		document.body.appendChild(link)
		link.click()
		link.remove()
		setTimeout(() => URL.revokeObjectURL(localObjectUrl), 1000)
	} catch {
		downloadError.value = 'Не удалось скачать аудио. Попробуйте ещё раз.'
	} finally {
		downloading.value = false
	}
}

function formatTime(s: number): string {
	const safeValue = Number.isFinite(s) ? s : 0
	const m = Math.floor(safeValue / 60)
	const sec = Math.floor(safeValue % 60)
	return `${m}:${sec.toString().padStart(2, '0')}`
}

const progress = computed(() =>
	duration.value > 0 ? (currentTime.value / duration.value) * 100 : 0,
)

watch(
	() => [props.initialTrackIndex, tracks.value.length] as const,
	() => {
		trackIndex.value = normalizeTrackIndex(props.initialTrackIndex)
	},
	{ immediate: true },
)

watch(
	() => props.initialTime,
	() => {
		initialTimeApplied = false
		applyInitialTime()
	},
)

watch(
	tracks,
	() => {
		const nextIndex = normalizeTrackIndex(props.initialTrackIndex)
		const changed = nextIndex !== trackIndex.value
		trackIndex.value = nextIndex
		void loadCurrentTrack(playing.value && changed)
	},
	{ deep: true },
)

watch(
	() => props.activeMediaFileIndex,
	(nextFileIndex) => {
		const audio = audioRef.value
		const track = activeTrack.value
		if (!audio || !track) return
		if (nextFileIndex == null || nextFileIndex === track.fileIndex) return
		if (!audio.paused) {
			audio.pause()
		}
	},
)

watch(
	() => props.autoplaySignal,
	async () => {
		const audio = audioRef.value
		const track = activeTrack.value
		if (!audio || !track) return
		if (props.activeMediaFileIndex !== track.fileIndex) return
		try {
			await audio.play()
		} catch {}
	},
)

onMounted(() => {
	const audio = audioRef.value
	if (!audio) return

	audio.preload = 'metadata'
	audio.addEventListener('loadedmetadata', () => {
		duration.value = Number.isFinite(audio.duration) ? audio.duration : 0
		audio.playbackRate = playbackRate.value
		applyInitialTime()
	})
	audio.addEventListener('timeupdate', () => {
		if (!pointerSeeking) {
			currentTime.value = audio.currentTime
		}
	})
	audio.addEventListener('play', () => {
		playing.value = true
		audio.playbackRate = playbackRate.value
		applyInitialTime()
		if (activeTrack.value) {
			emit('activated', activeTrack.value.fileIndex)
		}
	})
	audio.addEventListener('pause', () => {
		playing.value = false
		emitPlaybackProgress()
	})
	audio.addEventListener('ended', () => {
		playing.value = false
		emitPlaybackProgress(true)
		if (hasPlaylist.value) {
			setTrack(trackIndex.value + 1)
		}
	})

	void loadCurrentTrack()
})

onBeforeUnmount(() => {
	emitPlaybackProgress()
	cleanupObjectUrl()
})
</script>

<template>
	<div class="rounded-[22px] border border-[var(--app-border)] bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] p-3 text-[var(--app-text)] shadow-[var(--app-shadow-soft)] backdrop-blur-sm">
		<audio ref="audioRef" />

		<div v-if="activeTrack && (activeTrack.title || activeTrack.downloadable)" class="mb-2 flex items-start justify-between gap-3">
			<div class="min-w-0">
				<p v-if="activeTrack.title" class="truncate text-sm font-medium text-[var(--app-text-strong)]">
					{{ activeTrack.title }}
				</p>
				<p v-if="hasPlaylist" class="mt-1 text-xs text-[var(--app-muted-soft)]">
					{{ trackIndex + 1 }} из {{ tracks.length }}
				</p>
			</div>
			<button
				v-if="activeTrack.downloadable && activeTrack.downloadUrl"
				type="button"
				class="shrink-0 rounded-lg border border-[var(--app-border)] bg-[var(--app-surface)] px-2.5 py-1.5 text-xs text-[var(--app-muted)] transition hover:bg-[var(--app-bg)] disabled:opacity-50"
				:disabled="downloading"
				@click="downloadAudio"
			>
				{{ downloading ? 'Загрузка…' : 'Скачать' }}
			</button>
		</div>

		<div class="mb-2">
			<div class="mb-1.5 flex items-center justify-between text-[11px] text-[var(--app-muted-soft)]">
				<span class="tabular-nums">{{ formatTime(currentTime) }}</span>
				<span class="tabular-nums">{{ formatTime(duration) }}</span>
			</div>
			<div class="relative">
				<div class="pointer-events-none absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-[var(--app-bg-deep)]">
					<div
						class="absolute left-0 top-0 h-full rounded-full bg-[var(--app-accent)] transition-all"
						:style="{ width: `${progress}%` }"
					/>
				</div>
				<input
					class="audio-range relative z-10 h-5 w-full cursor-pointer appearance-none bg-transparent"
					type="range"
					min="0"
					:max="Math.max(duration, 0)"
					step="0.1"
					:value="currentTime"
					@pointerdown="pointerSeeking = true"
					@pointerup="pointerSeeking = false"
					@input="handleSeekInput"
					@change="handleSeekChange"
				/>
			</div>
		</div>

		<div class="flex items-center justify-between gap-2">
			<button
				class="text-[var(--app-muted)] transition hover:text-[var(--app-text)] disabled:cursor-default disabled:opacity-30"
				:disabled="!hasPlaylist && !props.crossCardNavigation && !props.canGoPrevious"
				@click="playPrevious"
			>
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 19L2 12l9-7v14zm11 0l-9-7 9-7v14z" />
				</svg>
			</button>

			<button
				class="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--app-button-bg)] text-[var(--app-button-fg)] shadow-[var(--app-shadow-soft)] transition hover:brightness-105"
				@click="togglePlay"
			>
				<svg v-if="playing" class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
					<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
				</svg>
				<svg v-else class="ml-0.5 h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
					<path d="M8 5v14l11-7z" />
				</svg>
			</button>

			<button
				class="text-[var(--app-muted)] transition hover:text-[var(--app-text)] disabled:cursor-default disabled:opacity-30"
				:disabled="!hasPlaylist && !props.crossCardNavigation && !props.canGoNext"
				@click="playNext"
			>
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 5l9 7-9 7V5zM2 5l9 7-9 7V5z" />
				</svg>
			</button>

			<button
				class="rounded-lg border border-[var(--app-border)] bg-[var(--app-surface)] px-2 py-1 text-[11px] text-[var(--app-muted)] transition hover:bg-[var(--app-bg)]"
				@click="cycleRate"
			>
				{{ playbackRate }}x
			</button>
		</div>

		<div v-if="showPlaylistList" class="mt-4 space-y-2">
			<button
				v-for="(track, index) in tracks"
				:key="`${track.fileIndex}-${track.title ?? index}`"
				type="button"
				class="flex w-full items-center gap-3 rounded-2xl border px-3 py-3 text-left transition"
				:class="
					index === trackIndex
						? 'border-[var(--app-border-strong)] bg-[color-mix(in_srgb,var(--app-accent)_10%,var(--app-surface))] text-[var(--app-text)]'
						: 'border-[var(--app-border)] bg-[var(--app-surface)] text-[var(--app-muted)] hover:bg-[var(--app-bg)]'
				"
				@click="selectTrack(index)"
			>
				<div
					class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
					:class="index === trackIndex ? 'bg-[var(--app-button-bg)] text-[var(--app-button-fg)]' : 'bg-[var(--app-bg-deep)] text-[var(--app-muted)]'"
				>
					<span class="text-xs font-semibold">{{ index + 1 }}</span>
				</div>
				<div class="min-w-0 flex-1">
					<p class="truncate text-sm font-medium">
						{{ track.title || `Аудио ${index + 1}` }}
					</p>
					<p class="mt-0.5 text-xs" :class="index === trackIndex ? 'text-[var(--app-accent-strong)]' : 'text-[var(--app-muted-soft)]'">
						{{ index === trackIndex ? 'Сейчас выбрано' : 'Нажмите, чтобы открыть' }}
					</p>
				</div>
			</button>
		</div>
	</div>
	<p v-if="downloadError" class="mt-2 text-xs text-[var(--app-danger)]">{{ downloadError }}</p>
</template>

<style scoped>
.audio-range::-webkit-slider-thumb {
	-webkit-appearance: none;
	appearance: none;
	height: 16px;
	width: 16px;
	border-radius: 9999px;
	background: var(--app-accent);
	box-shadow: 0 0 0 2px var(--app-surface);
}

.audio-range::-moz-range-thumb {
	height: 16px;
	width: 16px;
	border: 0;
	border-radius: 9999px;
	background: var(--app-accent);
	box-shadow: 0 0 0 2px var(--app-surface);
}

.audio-range::-webkit-slider-runnable-track {
	height: 8px;
	background: transparent;
}

.audio-range::-moz-range-track {
	height: 8px;
	background: transparent;
}
</style>
