<script setup lang="ts">
import {
	type DocumentPreviewKind,
	buildOfficeDocumentViewerUrl,
	getDocumentPreviewKind,
	getDocumentTypeLabel,
	isPreviewableDocument,
} from '~/utils/document-preview'

interface DownloadableFile {
	index: number
	name: string
	type: string
	url?: string | null
	downloadUrl: string | null
	downloadable?: boolean
}

interface Props {
	files: DownloadableFile[]
}

const props = defineProps<Props>()

const auth = useAuthStore()
const config = useRuntimeConfig()
const downloadingIndex = ref<number | null>(null)
const previewingIndex = ref<number | null>(null)
const previewKind = ref<Exclude<DocumentPreviewKind, 'none'> | null>(null)
const previewLoading = ref(false)
const officePreviewUrl = ref<string | null>(null)
const previewPages = ref<
	Array<{
		pageNumber: number
		imageUrl: string
		width: number
		height: number
	}>
>([])
const previewPageCount = ref(0)
const error = ref('')
let previewRenderToken = 0
const PDFJS_VERSION = '5.7.284'
const PDFJS_CDN_BASE = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${PDFJS_VERSION}`
let lockedScrollY = 0

const isAppleMobile = computed(() => {
	if (!import.meta.client) return false
	const nav = window.navigator as Navigator & { maxTouchPoints?: number }
	const userAgent = nav.userAgent.toLowerCase()
	return (
		/iphone|ipad|ipod/.test(userAgent) ||
		(userAgent.includes('macintosh') &&
			typeof nav.maxTouchPoints === 'number' &&
			nav.maxTouchPoints > 1)
	)
})

function getFileTypeLabel(type: string) {
	if (type === 'document') return 'ФАЙЛ'
	if (type === 'video') return 'Видео'
	if (type === 'audio') return 'Аудио'
	if (type === 'image') return 'Изображение'
	return 'Вложение'
}

function canPreviewFile(file: DownloadableFile) {
	return Boolean(file.url && isPreviewableDocument(file))
}

function getPreviewButtonLabel(file: DownloadableFile) {
	return previewingIndex.value === file.index ? 'Скрыть' : 'Открыть'
}

function getPreviewLoadingText() {
	if (previewKind.value === 'office') return 'Открываем файл...'
	return 'Подготавливаем PDF...'
}

function getPreviewErrorText() {
	if (previewKind.value === 'office') {
		return 'Не удалось открыть файл. Скачайте его и откройте на устройстве.'
	}
	return 'Не удалось отрисовать PDF.'
}

function revokePreviewPages() {
	for (const page of previewPages.value) {
		if (page.imageUrl.startsWith('blob:')) {
			URL.revokeObjectURL(page.imageUrl)
		}
	}
}

function closePreview() {
	previewRenderToken += 1
	revokePreviewPages()
	previewingIndex.value = null
	previewKind.value = null
	officePreviewUrl.value = null
	previewPages.value = []
	previewPageCount.value = 0
	previewLoading.value = false
}

function lockPageScroll() {
	if (!import.meta.client) return
	lockedScrollY = window.scrollY || window.pageYOffset || 0
	document.documentElement.style.overflow = 'hidden'
	document.body.style.overflow = 'hidden'
	document.body.style.position = 'fixed'
	document.body.style.top = `-${lockedScrollY}px`
	document.body.style.left = '0'
	document.body.style.right = '0'
	document.body.style.width = '100%'
}

function unlockPageScroll() {
	if (!import.meta.client) return
	document.documentElement.style.overflow = ''
	document.body.style.overflow = ''
	document.body.style.position = ''
	document.body.style.top = ''
	document.body.style.left = ''
	document.body.style.right = ''
	document.body.style.width = ''
	window.scrollTo(0, lockedScrollY)
}

async function openPreview(file: DownloadableFile) {
	if (!import.meta.client || !file.url) return
	const nextPreviewKind = getDocumentPreviewKind(file)
	if (nextPreviewKind === 'none') return

	if (previewingIndex.value === file.index) {
		closePreview()
		return
	}

	closePreview()
	previewingIndex.value = file.index
	previewKind.value = nextPreviewKind
	previewLoading.value = true
	error.value = ''
	const renderToken = ++previewRenderToken

	try {
		if (nextPreviewKind === 'office') {
			officePreviewUrl.value = buildOfficeDocumentViewerUrl(file.url)
			return
		}

		const response = await fetch(file.url, { credentials: 'include' })
		if (!response.ok) {
			throw new Error('PREVIEW_FAILED')
		}

		const pdfBuffer = await response.arrayBuffer()
		const pdfjsModule = await import(
			/* @vite-ignore */
			`${PDFJS_CDN_BASE}/build/pdf.min.mjs`
		)
		const { getDocument, GlobalWorkerOptions } = pdfjsModule
		GlobalWorkerOptions.workerSrc = `${PDFJS_CDN_BASE}/build/pdf.worker.min.mjs`

		const loadingTask = getDocument({ data: pdfBuffer })
		const pdf = await loadingTask.promise
		if (renderToken !== previewRenderToken) {
			void loadingTask.destroy()
			return
		}

		previewPageCount.value = pdf.numPages
		const renderedPages: Array<{
			pageNumber: number
			imageUrl: string
			width: number
			height: number
		}> = []
		const baseScale = window.innerWidth < 768 ? 1.3 : 1.55
		const pixelRatio = Math.min(window.devicePixelRatio || 1, 2)

		for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
			if (renderToken !== previewRenderToken) break

			const page = await pdf.getPage(pageNumber)
			const viewport = page.getViewport({ scale: baseScale })
			const canvas = document.createElement('canvas')
			const context = canvas.getContext('2d')
			if (!context) continue

			canvas.width = Math.floor(viewport.width * pixelRatio)
			canvas.height = Math.floor(viewport.height * pixelRatio)
			context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0)

			await page.render({
				canvasContext: context,
				viewport,
			}).promise

			const blob = await new Promise<Blob | null>((resolve) =>
				canvas.toBlob((value) => resolve(value), 'image/jpeg', 0.92),
			)
			if (!blob) continue

			renderedPages.push({
				pageNumber,
				imageUrl: URL.createObjectURL(blob),
				width: viewport.width,
				height: viewport.height,
			})
		}

		if (renderToken !== previewRenderToken) {
			for (const page of renderedPages) {
				URL.revokeObjectURL(page.imageUrl)
			}
			void loadingTask.destroy()
			return
		}

		previewPages.value = renderedPages
		pdf.cleanup()
		void loadingTask.destroy()
	} catch {
		error.value =
			nextPreviewKind === 'office'
				? 'Не удалось открыть файл. Попробуйте скачать его.'
				: 'Не удалось открыть PDF. Попробуйте ещё раз.'
		closePreview()
		return
	} finally {
		if (renderToken === previewRenderToken) {
			previewLoading.value = false
		}
	}
}

async function downloadFile(file: DownloadableFile) {
	if (!import.meta.client || downloadingIndex.value !== null || !file.downloadUrl) return

	downloadingIndex.value = file.index
	error.value = ''

	try {
		const response = await fetch(`${config.public.apiUrl}${file.downloadUrl}`, {
			credentials: 'include',
		})

		if (!response.ok) {
			throw new Error('DOWNLOAD_FAILED')
		}

		const blob = await response.blob()
		const objectUrl = URL.createObjectURL(blob)
		if (isAppleMobile.value) {
			const opened = window.open(objectUrl, '_blank', 'noopener,noreferrer')
			if (!opened) {
				window.location.href = objectUrl
			}
			setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000)
			return
		}

		const link = document.createElement('a')
		link.href = objectUrl
		link.download = file.name
		link.rel = 'noopener'
		document.body.appendChild(link)
		link.click()
		link.remove()
		setTimeout(() => URL.revokeObjectURL(objectUrl), 1000)
	} catch {
		error.value = isAppleMobile.value
			? 'Не удалось открыть файл на iPhone. Попробуйте ещё раз.'
			: 'Не удалось скачать файл. Попробуйте ещё раз.'
	} finally {
		downloadingIndex.value = null
	}
}

onBeforeUnmount(() => {
	revokePreviewPages()
	unlockPageScroll()
})

watch(previewingIndex, (value) => {
	if (!import.meta.client) return
	if (value !== null) {
		lockPageScroll()
		return
	}
	unlockPageScroll()
})
</script>

<template>
	<div class="rounded-3xl border border-[var(--app-border)] bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] p-5 text-[var(--app-text)] shadow-[var(--app-shadow-soft)] md:p-6" @contextmenu.prevent>
		<div class="mb-4 flex items-center justify-between gap-3">
			<h3 class="text-lg font-semibold text-[var(--app-text-strong)]">Файлы</h3>
			<span class="rounded-full border border-[var(--app-border)] bg-[var(--app-bg)] px-3 py-1 text-xs text-[var(--app-muted-soft)]">
				{{ props.files.length }}
			</span>
		</div>

		<div class="space-y-3">
			<div
				v-for="file in props.files"
				:key="`${file.index}-${file.name}`"
				class="overflow-hidden rounded-[24px] border border-[var(--app-border)] bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] px-4 py-4 shadow-[var(--app-shadow-soft)]"
			>
				<div class="min-w-0">
					<p class="text-[15px] font-semibold leading-6 text-[var(--app-text-strong)]">{{ file.name }}</p>
					<div class="mt-3 flex flex-wrap items-end justify-between gap-3">
						<div class="flex items-center gap-2">
							<span class="inline-flex items-center rounded-full border border-[var(--app-border)] bg-[var(--app-bg-deep)] px-2.5 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-[var(--app-muted)]">
								{{ file.type === 'document' ? getDocumentTypeLabel(file) : getFileTypeLabel(file.type) }}
							</span>
						</div>
						<div class="flex w-full items-center gap-2 sm:w-auto">
							<button
								v-if="canPreviewFile(file)"
								class="flex h-11 flex-1 items-center justify-center rounded-[18px] border border-[var(--app-border-strong)] bg-[var(--app-surface)] px-4 text-sm font-medium text-[var(--app-accent-strong)] transition hover:bg-[var(--app-bg)] sm:flex-none sm:min-w-[124px]"
								@click="openPreview(file)"
							>
								{{ getPreviewButtonLabel(file) }}
							</button>

							<button
								class="flex h-11 w-11 shrink-0 items-center justify-center rounded-[18px] border border-[var(--app-border)] bg-[var(--app-surface)] text-[var(--app-text)] transition hover:bg-[var(--app-bg)] disabled:opacity-50"
								:disabled="downloadingIndex === file.index || !file.downloadable || !file.downloadUrl"
								@click="downloadFile(file)"
							>
								<div
									v-if="downloadingIndex === file.index"
									class="h-4 w-4 animate-spin rounded-full border-2 border-[var(--app-border)] border-t-[var(--app-accent)]"
								/>
								<svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path
										stroke-linecap="round"
										stroke-linejoin="round"
										stroke-width="1.8"
										d="M12 3v12m0 0l-4-4m4 4l4-4m5 8H3"
									/>
								</svg>
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<p v-if="error" class="mt-3 text-xs text-[var(--app-danger)]">{{ error }}</p>
	</div>

	<Teleport to="body">
		<div
			v-if="previewingIndex !== null"
			class="fixed inset-0 z-[300] flex items-center justify-center overflow-hidden bg-black/90 p-3 overscroll-none touch-pan-y md:p-6"
			@click.self="closePreview"
		>
			<div class="relative flex h-[min(92vh,980px)] min-h-0 w-full max-w-5xl flex-col overflow-hidden rounded-[28px] border border-[var(--app-border)] bg-[var(--app-surface)] shadow-[var(--app-shadow-floating)]">
				<button
					class="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] text-[var(--app-muted)] shadow-[var(--app-shadow-soft)] transition hover:text-[var(--app-text)]"
					@click="closePreview"
				>
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 6l12 12M18 6L6 18" />
					</svg>
				</button>

				<div class="border-b border-[var(--app-border)] px-4 py-4 pr-16">
					<p class="truncate text-sm font-medium text-[var(--app-text-strong)]">
						{{ props.files.find((file) => file.index === previewingIndex)?.name }}
					</p>
				</div>

				<div class="min-h-0 flex-1 bg-[#1a1a1a]">
					<div v-if="previewLoading" class="flex h-full items-center justify-center">
						<div class="flex flex-col items-center gap-3 text-white/70">
							<div class="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-white" />
							<p class="text-sm">{{ getPreviewLoadingText() }}</p>
						</div>
					</div>

					<iframe
						v-else-if="previewKind === 'office' && officePreviewUrl"
						:src="officePreviewUrl"
						title="Просмотр файла"
						class="h-full w-full border-0 bg-[#202124]"
						referrerpolicy="no-referrer"
						allowfullscreen
					/>

					<div
						v-else-if="previewKind === 'pdf' && previewPages.length"
						class="h-full overflow-y-auto overscroll-contain px-3 py-4 touch-auto [-webkit-overflow-scrolling:touch] md:px-5"
					>
						<div class="mx-auto flex w-full max-w-4xl flex-col gap-4">
							<div
								v-for="page in previewPages"
								:key="page.pageNumber"
								class="overflow-hidden rounded-2xl bg-white shadow-[0_16px_48px_rgba(0,0,0,0.35)]"
							>
								<img
									:src="page.imageUrl"
									:alt="`Страница ${page.pageNumber}`"
									class="block h-auto w-full"
									:width="page.width"
									:height="page.height"
								/>
							</div>
						</div>
					</div>

					<div v-else class="flex h-full items-center justify-center px-6 text-center text-sm text-white/55">
						{{ getPreviewErrorText() }}
					</div>
				</div>
			</div>
		</div>
	</Teleport>
</template>
