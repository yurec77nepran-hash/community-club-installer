<script setup lang="ts">
type HlsType = import('hls.js').default

interface Props {
	src: string
	poster?: string
	downloadUrl?: string | null
	downloadable?: boolean
	initialTime?: number | null
}

const props = defineProps<Props>()
const emit = defineEmits<{
	progress: [
		payload: {
			positionSeconds: number
			durationSeconds: number | null
			completed: boolean
		},
	]
}>()

const videoRef = ref<HTMLVideoElement>()
const containerRef = ref<HTMLElement>()
const playing = ref(false)
const currentTime = ref(0)
const duration = ref(0)
const buffered = ref(0)
const loading = ref(true)
const showControls = ref(true)
const isExpanded = ref(false)
const isFullscreen = ref(false)
const playbackRate = ref(1)
const playbackRates = [1, 1.5, 2]
const downloading = ref(false)
const downloadError = ref('')
let controlsTimer: ReturnType<typeof setTimeout> | null = null
let hls: HlsType | null = null
let lastEmittedProgressSecond = -1
let initialTimeApplied = false

type OrientationScreen = Screen & {
	orientation?: {
		lock?: (orientation: 'landscape' | 'portrait') => Promise<void>
		unlock?: () => void
	}
}

type FullscreenVideoElement = HTMLVideoElement & {
	webkitEnterFullscreen?: () => void
	webkitSupportsFullscreen?: boolean
}

const expandedPlayerStyle = computed(() => ({
	width: 'min(96vw, calc(88vh * 16 / 9), 1600px)',
}))

const videoClass = 'block w-full h-full object-contain bg-black'

function emitPlaybackProgress(force = false) {
	const video = videoRef.value
	if (!video) return
	const durationValue =
		Number.isFinite(video.duration) && video.duration > 0 ? video.duration : null
	const position = Math.max(0, Math.round(video.currentTime || 0))
	const durationSeconds = durationValue != null ? Math.round(durationValue) : null
	const completed =
		durationSeconds != null && durationSeconds > 0 ? position >= durationSeconds - 3 : false

	if (
		!force &&
		lastEmittedProgressSecond >= 0 &&
		Math.abs(position - lastEmittedProgressSecond) < 10
	) {
		return
	}

	lastEmittedProgressSecond = position
	emit('progress', {
		positionSeconds: position,
		durationSeconds,
		completed,
	})
}

function applyInitialTime() {
	const video = videoRef.value
	if (!video || initialTimeApplied) return
	const target = Math.max(0, Math.floor(props.initialTime ?? 0))
	if (target < 2) {
		initialTimeApplied = true
		return
	}
	if (Number.isFinite(video.duration) && video.duration > 0) {
		video.currentTime = Math.min(target, Math.max(0, video.duration - 1))
		currentTime.value = video.currentTime
		initialTimeApplied = true
		return
	}
	video.currentTime = target
	currentTime.value = video.currentTime
	initialTimeApplied = true
}

onMounted(async () => {
	const video = videoRef.value
	if (!video || !props.src) return

	if (props.src.endsWith('.m3u8')) {
		const { default: Hls } = await import('hls.js')
		if (Hls.isSupported()) {
			hls = new Hls({
				enableWorker: true,
				maxBufferLength: 30,
			})
			hls.loadSource(props.src)
			hls.attachMedia(video)
			hls.on(Hls.Events.MANIFEST_PARSED, () => {
				loading.value = false
			})
		} else {
			video.src = props.src
		}
	} else {
		video.src = props.src
	}

	video.addEventListener('loadedmetadata', () => {
		duration.value = video.duration
		loading.value = false
		video.playbackRate = playbackRate.value
		applyInitialTime()
	})
	video.addEventListener('timeupdate', () => {
		currentTime.value = video.currentTime
		if (video.buffered.length > 0) {
			buffered.value = video.buffered.end(video.buffered.length - 1)
		}
		emitPlaybackProgress()
	})
	video.addEventListener('play', () => {
		playing.value = true
		video.playbackRate = playbackRate.value
		applyInitialTime()
	})
	video.addEventListener('pause', () => {
		playing.value = false
		showControls.value = true
		emitPlaybackProgress(true)
	})
	video.addEventListener('ended', () => {
		playing.value = false
		showControls.value = true
		emitPlaybackProgress(true)
	})
})

onUnmounted(() => {
	emitPlaybackProgress(true)
	hls?.destroy()
	clearControlsTimer()
	void unlockOrientation()
})

function togglePlay() {
	const video = videoRef.value
	if (!video) return
	if (video.paused) {
		isExpanded.value = true
		void video.play()
		onMouseMove()
	} else {
		video.pause()
	}
}

function collapsePlayer() {
	isExpanded.value = false
	showControls.value = true
	clearControlsTimer()
	void exitNativeFullscreen()
}

function seek(e: MouseEvent | PointerEvent) {
	const video = videoRef.value
	if (!video || duration.value <= 0) return
	const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
	const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
	seekTo(ratio * duration.value)
}

const seeking = ref(false)
function seekPointerDown(e: PointerEvent) {
	seeking.value = true
	seek(e)
}
function seekPointerMove(e: PointerEvent) {
	if (!seeking.value) return
	seek(e)
}
function seekPointerUp() {
	seeking.value = false
}

function seekTo(seconds: number) {
	const video = videoRef.value
	if (!video || !Number.isFinite(seconds)) return
	const maxTime =
		Number.isFinite(video.duration) && video.duration > 0 ? video.duration - 1 : seconds
	video.currentTime = Math.max(0, Math.min(seconds, maxTime))
	currentTime.value = video.currentTime
	emitPlaybackProgress(true)
	void video.play().catch(() => {})
}

function formatTime(s: number): string {
	const safeValue = Number.isFinite(s) ? s : 0
	const m = Math.floor(safeValue / 60)
	const sec = Math.floor(safeValue % 60)
	return `${m}:${sec.toString().padStart(2, '0')}`
}

function clearControlsTimer() {
	if (!controlsTimer) return
	clearTimeout(controlsTimer)
	controlsTimer = null
}

function onMouseMove() {
	showControls.value = true
	clearControlsTimer()
	controlsTimer = setTimeout(() => {
		if (playing.value) showControls.value = false
	}, 3000)
}

function cyclePlaybackRate() {
	const video = videoRef.value
	if (!video) return
	const currentIndex = playbackRates.indexOf(playbackRate.value)
	playbackRate.value = playbackRates[(currentIndex + 1) % playbackRates.length]
	video.playbackRate = playbackRate.value
	onMouseMove()
}

async function lockLandscapeOrientation() {
	const orientationApi = (window.screen as OrientationScreen).orientation
	if (!orientationApi?.lock) return
	try {
		await orientationApi.lock('landscape')
	} catch {}
}

async function unlockOrientation() {
	const orientationApi = (window.screen as OrientationScreen).orientation
	if (!orientationApi?.unlock) return
	try {
		orientationApi.unlock()
	} catch {}
}

async function requestNativeFullscreen() {
	const container = containerRef.value
	const video = videoRef.value as FullscreenVideoElement | undefined
	if (!video) return

	try {
		if (video.webkitEnterFullscreen) {
			video.webkitEnterFullscreen()
			isFullscreen.value = true
			await lockLandscapeOrientation()
			return
		}
	} catch {}

	const fullscreenTarget = container ?? video
	if (!document.fullscreenElement && fullscreenTarget?.requestFullscreen) {
		try {
			await fullscreenTarget.requestFullscreen()
			isFullscreen.value = true
			await lockLandscapeOrientation()
		} catch {}
	}
}

async function exitNativeFullscreen() {
	if (document.fullscreenElement) {
		try {
			await document.exitFullscreen()
		} catch {}
	}
	isFullscreen.value = false
	await unlockOrientation()
}

function onFullscreenChange() {
	isFullscreen.value = Boolean(document.fullscreenElement)
	if (!isFullscreen.value) {
		void unlockOrientation()
	}
}

onMounted(() => {
	document.addEventListener('fullscreenchange', onFullscreenChange)
})

onUnmounted(() => {
	document.removeEventListener('fullscreenchange', onFullscreenChange)
})

async function downloadVideo() {
	if (!import.meta.client || !props.downloadable || !props.downloadUrl || downloading.value) return

	const config = useRuntimeConfig()
	downloading.value = true
	downloadError.value = ''

	try {
		const response = await fetch(`${config.public.apiUrl}${props.downloadUrl}`, {
			credentials: 'include',
		})
		if (!response.ok) {
			throw new Error('DOWNLOAD_FAILED')
		}

		const blob = await response.blob()
		const objectUrl = URL.createObjectURL(blob)
		const link = document.createElement('a')
		link.href = objectUrl
		link.download = 'video.mp4'
		link.rel = 'noopener'
		document.body.appendChild(link)
		link.click()
		link.remove()
		setTimeout(() => URL.revokeObjectURL(objectUrl), 1000)
	} catch {
		downloadError.value = 'Не удалось скачать видео. Попробуйте ещё раз.'
	} finally {
		downloading.value = false
	}
}

watch(
	() => props.src,
	() => {
		initialTimeApplied = false
		lastEmittedProgressSecond = -1
	},
)

watch(
	() => props.initialTime,
	() => {
		if ((props.initialTime ?? 0) < 2) return
		initialTimeApplied = false
		applyInitialTime()
	},
)

defineExpose({ seekTo })
</script>

<template>
	<Teleport to="body" :disabled="!isExpanded">
		<div
			ref="containerRef"
			class="select-none"
			:class="
				isExpanded
					? 'fixed inset-0 z-[100] bg-black/95 p-3 sm:p-6 flex items-center justify-center'
					: 'relative w-full'
			"
			@mousemove="onMouseMove"
			@contextmenu.prevent
		>
			<div
				class="relative bg-black overflow-hidden shadow-2xl"
				:class="isExpanded ? 'aspect-video rounded-2xl max-h-[88vh]' : 'w-full aspect-video rounded-xl'"
				:style="isExpanded ? expandedPlayerStyle : undefined"
				@click="togglePlay"
			>
				<button
					v-if="downloadable && downloadUrl"
					type="button"
					class="absolute right-3 top-3 z-20 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-xs text-white/85 backdrop-blur transition hover:bg-black/65 disabled:opacity-50"
					:disabled="downloading"
					@click.stop="downloadVideo"
				>
					{{ downloading ? 'Загрузка…' : 'Скачать' }}
				</button>
				<video
					ref="videoRef"
					:class="videoClass"
					:poster="poster"
					playsinline
					controlsList="nodownload nofullscreen noremoteplayback"
					disablePictureInPicture
				/>

				<div v-if="loading" class="absolute inset-0 flex items-center justify-center bg-black/50">
					<div class="w-10 h-10 border-4 border-white/30 border-t-white rounded-full animate-spin" />
				</div>

				<div
					v-if="!playing && !loading"
					class="absolute inset-0 flex items-center justify-center bg-gradient-to-t from-black/40 to-black/10"
				>
					<button
						class="w-16 h-16 bg-white/20 backdrop-blur rounded-full flex items-center justify-center border border-white/15"
						@click.stop="togglePlay"
					>
						<svg class="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
							<path d="M8 5v14l11-7z" />
						</svg>
					</button>
				</div>

				<Transition
					enter-from-class="opacity-0 translate-y-2"
					enter-active-class="transition duration-200"
					leave-to-class="opacity-0 translate-y-2"
					leave-active-class="transition duration-200"
				>
					<div
						v-show="showControls"
						class="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-3 pt-8"
						@click.stop
					>
						<div
							class="video-seek"
							@pointerdown="seekPointerDown"
							@pointermove="seekPointerMove"
							@pointerup="seekPointerUp"
							@pointercancel="seekPointerUp"
							@pointerleave="seekPointerUp"
						>
							<div class="relative h-1 bg-white/30 rounded-full">
								<div
									class="absolute h-full bg-white/20 rounded-full"
									:style="{ width: `${duration ? (buffered / duration) * 100 : 0}%` }"
								/>
								<div
									class="absolute h-full bg-primary-500 rounded-full"
									:style="{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }"
								/>
							</div>
						</div>

						<div class="flex items-center justify-between gap-3 text-white text-xs">
							<div class="flex items-center gap-3 min-w-0">
								<button @click="togglePlay">
									<svg v-if="playing" class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
										<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
									</svg>
									<svg v-else class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
										<path d="M8 5v14l11-7z" />
									</svg>
								</button>
								<span class="tabular-nums">{{ formatTime(currentTime) }} / {{ formatTime(duration) }}</span>
							</div>

							<div class="flex items-center gap-2">
								<button
									class="px-2 py-1 rounded-lg bg-white/10 border border-white/10"
									@click="cyclePlaybackRate"
								>
									{{ playbackRate }}x
								</button>
								<button
									class="w-8 h-8 rounded-full bg-white/10 border border-white/10 flex items-center justify-center"
									@pointerdown.stop.prevent="requestNativeFullscreen"
									@click.stop.prevent
									aria-label="Открыть видео на весь экран"
								>
									<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 3H5a2 2 0 00-2 2v3m16-5h-3a2 2 0 012 2v3M8 21H5a2 2 0 01-2-2v-3m16 5h-3a2 2 0 002-2v-3" />
									</svg>
								</button>
								<button
									v-if="isExpanded"
									class="w-8 h-8 rounded-full bg-white/10 border border-white/10 flex items-center justify-center"
									@click="collapsePlayer"
									aria-label="Свернуть видео"
								>
									<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
									</svg>
								</button>
							</div>
						</div>
					</div>
				</Transition>
			</div>
		</div>
	</Teleport>
	<p v-if="downloadError" class="mt-2 text-xs text-[var(--app-danger)]">{{ downloadError }}</p>
</template>

<style scoped>
/* Зона перемотки: большой хит-ареа, клик/перетаскивание в любую точку полосы */
.video-seek {
	padding: 0.6rem 0;
	margin: -0.6rem 0 0.35rem;
	cursor: pointer;
	touch-action: none;
}
</style>
