<script setup lang="ts">
import { canOfferImageSave, getImageDownloadFileName } from '~/utils/image-download'

interface Props {
	src: string
	alt?: string
	downloadUrl?: string | null
	downloadable?: boolean
}

const props = defineProps<Props>()
const downloading = ref(false)
const downloadError = ref('')
const previewOpen = ref(false)
let lockedScrollY = 0
let scrollLocked = false

const canSaveImage = computed(() =>
	canOfferImageSave({
		src: props.src,
		downloadUrl: props.downloadUrl,
		downloadable: props.downloadable,
	}),
)

const isAppleMobile = computed(() => {
	if (!import.meta.client) return false
	const nav = window.navigator as Navigator & { maxTouchPoints?: number }
	const userAgent = nav.userAgent.toLowerCase()
	return (
		/iphone|ipad|ipod/.test(userAgent) ||
		(userAgent.includes('macintosh') &&
			typeof nav.maxTouchPoints === 'number' &&
			nav.maxTouchPoints > 1)
	)
})

function openImage() {
	if (!import.meta.client || !props.src) return
	previewOpen.value = true
}

function closeImage() {
	previewOpen.value = false
}

function lockPageScroll() {
	if (!import.meta.client) return
	if (scrollLocked) return
	lockedScrollY = window.scrollY || window.pageYOffset || 0
	scrollLocked = true
	document.documentElement.style.overflow = 'hidden'
	document.body.style.overflow = 'hidden'
	document.body.style.position = 'fixed'
	document.body.style.top = `-${lockedScrollY}px`
	document.body.style.left = '0'
	document.body.style.right = '0'
	document.body.style.width = '100%'
}

function unlockPageScroll() {
	if (!import.meta.client) return
	if (!scrollLocked) return
	scrollLocked = false
	document.documentElement.style.overflow = ''
	document.body.style.overflow = ''
	document.body.style.position = ''
	document.body.style.top = ''
	document.body.style.left = ''
	document.body.style.right = ''
	document.body.style.width = ''
	window.scrollTo(0, lockedScrollY)
}

function canShareImageFile(file: File) {
	const nav = window.navigator as Navigator & {
		canShare?: (data: ShareData) => boolean
		share?: (data: ShareData) => Promise<void>
	}
	return Boolean(nav.share && (!nav.canShare || nav.canShare({ files: [file] })))
}

async function shareImageFile(file: File) {
	const nav = window.navigator as Navigator & {
		share?: (data: ShareData) => Promise<void>
	}
	await nav.share?.({
		files: [file],
		title: props.alt?.trim() || 'Изображение',
	})
}

async function downloadImage() {
	if (!import.meta.client || !canSaveImage.value || downloading.value) return

	const config = useRuntimeConfig()
	downloading.value = true
	downloadError.value = ''

	try {
		const sourceUrl = props.downloadUrl ? `${config.public.apiUrl}${props.downloadUrl}` : props.src
		const response = await fetch(sourceUrl, {
			credentials: props.downloadUrl ? 'include' : 'same-origin',
		})
		if (!response.ok) {
			throw new Error('DOWNLOAD_FAILED')
		}

		const blob = await response.blob()
		const fileName = getImageDownloadFileName({
			title: props.alt,
			contentType: response.headers.get('Content-Type') ?? blob.type,
		})
		const file = new File([blob], fileName, {
			type: blob.type || response.headers.get('Content-Type') || 'image/jpeg',
		})

		if (isAppleMobile.value && canShareImageFile(file)) {
			await shareImageFile(file)
			return
		}

		const objectUrl = URL.createObjectURL(blob)
		if (isAppleMobile.value) {
			const opened = window.open(objectUrl, '_blank', 'noopener,noreferrer')
			if (!opened) window.location.href = objectUrl
			setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000)
			return
		}

		const link = document.createElement('a')
		link.href = objectUrl
		link.download = fileName
		link.rel = 'noopener'
		document.body.appendChild(link)
		link.click()
		link.remove()
		setTimeout(() => URL.revokeObjectURL(objectUrl), 1000)
	} catch (error) {
		if (error instanceof DOMException && error.name === 'AbortError') return
		downloadError.value = 'Не удалось сохранить изображение. Попробуйте ещё раз.'
	} finally {
		downloading.value = false
	}
}

onBeforeUnmount(() => {
	unlockPageScroll()
})

watch(previewOpen, (value) => {
	if (!import.meta.client) return
	if (value) {
		lockPageScroll()
		return
	}
	unlockPageScroll()
})
</script>

<template>
	<div
		class="relative mx-auto w-full max-w-5xl overflow-hidden rounded-2xl bg-white/5"
		@contextmenu.prevent
	>
		<button
			v-if="canSaveImage"
			type="button"
			class="absolute right-3 top-3 z-10 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-xs text-white/85 backdrop-blur transition hover:bg-black/65 disabled:opacity-50"
			:disabled="downloading"
			@click.stop="downloadImage"
		>
			{{ downloading ? 'Загрузка…' : 'Скачать' }}
		</button>
		<button
			type="button"
			class="flex min-h-[320px] max-h-[78vh] w-full items-center justify-center bg-black/30 p-3 md:p-4"
			@click="openImage"
		>
			<img
				:src="src"
				:alt="alt"
				class="h-auto max-h-[calc(78vh-24px)] w-auto max-w-full object-contain md:max-h-[calc(78vh-32px)]"
				draggable="false"
			/>
		</button>
	</div>
	<p v-if="downloadError" class="mt-2 text-xs text-[var(--app-danger)]">{{ downloadError }}</p>

	<Teleport to="body">
		<div
			v-if="previewOpen"
			class="fixed inset-0 z-[300] flex items-center justify-center overflow-hidden bg-black/90 p-3 overscroll-none md:p-6"
			@click.self="closeImage"
		>
			<div class="relative flex h-full min-h-0 w-full max-w-6xl flex-col overflow-hidden rounded-[28px] border border-white/10 bg-[#111111] shadow-2xl">
				<div class="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
					<p class="truncate text-sm font-medium text-white">{{ alt || 'Изображение' }}</p>
					<div class="flex items-center gap-2">
						<button
							v-if="canSaveImage"
							type="button"
							class="rounded-2xl border border-white/10 bg-white/[0.08] px-4 py-2 text-sm font-medium text-white transition hover:bg-white/[0.14] disabled:opacity-50"
							:disabled="downloading"
							@click.stop="downloadImage"
						>
							{{ downloading ? 'Загрузка…' : 'Скачать' }}
						</button>
						<button
							type="button"
							class="flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.08] text-white/70 transition hover:text-white"
							@click="closeImage"
						>
							<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 6l12 12M18 6L6 18" />
							</svg>
						</button>
					</div>
				</div>

				<div class="flex min-h-0 flex-1 items-center justify-center overflow-auto bg-black/35 p-3">
					<img
						:src="src"
						:alt="alt"
						class="image-viewer-safe-image block h-auto max-h-full w-auto max-w-full object-contain"
						draggable="false"
					/>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<style scoped>
.image-viewer-safe-image {
	-webkit-touch-callout: none;
	user-select: none;
}
</style>
