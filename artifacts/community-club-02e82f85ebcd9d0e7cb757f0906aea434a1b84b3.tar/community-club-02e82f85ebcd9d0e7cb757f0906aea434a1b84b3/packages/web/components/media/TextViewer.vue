<script setup lang="ts">
interface Props {
	content: string
	compact?: boolean
}

const props = withDefaults(defineProps<Props>(), {
	compact: false,
})

function escapeHtml(value: string) {
	return value
		.replaceAll('&', '&amp;')
		.replaceAll('<', '&lt;')
		.replaceAll('>', '&gt;')
		.replaceAll('"', '&quot;')
		.replaceAll("'", '&#39;')
}

function restoreAllowedTags(value: string) {
	return value.replace(/&lt;(\/?)(strong|b|em|i|u|s)&gt;/g, '<$1$2>')
}

function autolinkText(value: string) {
	return value.replace(
		/(https?:\/\/[^\s<]+)/g,
		(url) =>
			`<a href="${url}" target="_blank" rel="noopener noreferrer" class="feed-inline-link">${url}</a>`,
	)
}

function renderMaterialContentHtml(content: string) {
	const escaped = escapeHtml(content)
	const restored = restoreAllowedTags(escaped)
	const withBreaks = restored.replace(/\r\n|\r|\n/g, '<br>')
	return withBreaks
		.split(/(<[^>]+>)/g)
		.map((chunk) => (chunk.startsWith('<') ? chunk : autolinkText(chunk)))
		.join('')
}

const html = computed(() => renderMaterialContentHtml(props.content || ''))
</script>

<template>
	<article
		class="max-w-none select-text text-[var(--app-text)] [--tw-prose-body:var(--app-text)] [--tw-prose-bold:var(--app-text-strong)] [--tw-prose-links:var(--app-accent-strong)] [overflow-wrap:anywhere] [&_*]:max-w-full [&_*]:break-words [&_a]:break-all [&_a]:text-[var(--app-accent-strong)] [&_a]:underline [&_a]:decoration-[color-mix(in_srgb,var(--app-accent)_42%,transparent)] [&_a]:underline-offset-4 [&_a]:transition [&_a]:hover:text-[var(--app-text)] [&_pre]:overflow-x-auto"
		:class="
			compact
				? 'text-sm leading-6 text-[var(--app-muted)]'
				: 'prose prose-sm rounded-3xl border border-[var(--app-border)] bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] p-6 text-[var(--app-text)] shadow-[var(--app-shadow-soft)]'
		"
		v-html="html"
	/>
</template>
