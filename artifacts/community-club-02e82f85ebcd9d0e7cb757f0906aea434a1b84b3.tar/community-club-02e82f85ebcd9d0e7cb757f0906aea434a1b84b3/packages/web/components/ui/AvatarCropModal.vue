<script setup lang="ts">
import 'cropperjs/dist/cropper.css'
import { nextTick, onUnmounted, ref, watch } from 'vue'

type CropperInstance = InstanceType<typeof import('cropperjs')['default']>
let CropperClass: typeof import('cropperjs')['default'] | null = null

const props = defineProps<{ open: boolean; file: File | null }>()
const emit = defineEmits<{
	(e: 'update:open', v: boolean): void
	(e: 'crop', blob: Blob): void
	(e: 'error', message: string): void
}>()

const cropImageRef = ref<HTMLImageElement | null>(null)
let cropper: CropperInstance | null = null
const previewUrl = ref('')
const zoom = ref(1)
const cropping = ref(false)
const MIN_ZOOM = 0.1
const MAX_ZOOM = 5

async function initCropper() {
	if (!cropImageRef.value || !props.open || !props.file) return
	destroyCropper()
	try {
		if (!CropperClass) {
			const mod = await import('cropperjs')
			CropperClass = mod.default || mod
		}
		if (!cropImageRef.value || !props.open) return
		cropper = new CropperClass(cropImageRef.value, {
			aspectRatio: 1,
			viewMode: 1,
			dragMode: 'move',
			zoomOnTouch: true,
			zoomOnWheel: true,
			responsive: true,
			restore: false,
			movable: true,
			rotatable: true,
			scalable: false,
			zoomable: true,
			minCropBoxWidth: 64,
			minCropBoxHeight: 64,
			ready: () => {
				zoom.value = 1
			},
			zoom: (event) => {
				zoom.value = Math.round((event.detail?.ratio ?? 1) * 100) / 100
			},
		})
	} catch {
		fail('Не удалось открыть редактор фото. Выберите другое изображение и попробуйте снова.')
	}
}

function destroyCropper() {
	if (cropper) {
		cropper.destroy()
		cropper = null
	}
}

function clearPreview() {
	destroyCropper()
	if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
	previewUrl.value = ''
}

function fail(message: string) {
	emit('error', message)
	close()
}

function zoomIn() {
	cropper?.zoom(0.1)
}

function zoomOut() {
	cropper?.zoom(-0.1)
}

function rotateLeft() {
	cropper?.rotate(-90)
}

function rotateRight() {
	cropper?.rotate(90)
}

function onSliderInput(event: Event) {
	const value = Number((event.target as HTMLInputElement).value)
	cropper?.zoomTo(value)
}

function confirm() {
	if (!cropper || cropping.value) return
	const canvas = cropper.getCroppedCanvas({
		width: 1024,
		height: 1024,
		imageSmoothingEnabled: true,
		imageSmoothingQuality: 'high',
	})
	if (!canvas) {
		fail('Не удалось подготовить фото. Выберите другое изображение и попробуйте снова.')
		return
	}
	cropping.value = true
	canvas.toBlob(
		(blob) => {
			cropping.value = false
			if (!blob) {
				fail('Не удалось подготовить фото. Выберите другое изображение и попробуйте снова.')
				return
			}
			emit('crop', blob)
			close()
		},
		'image/jpeg',
		0.92,
	)
}

function close() {
	cropping.value = false
	clearPreview()
	emit('update:open', false)
}

function onImageError() {
	fail('Не удалось открыть это фото. Выберите изображение в другом формате.')
}

watch(
	() => props.open,
	async (open) => {
		if (open && props.file) {
			clearPreview()
			previewUrl.value = URL.createObjectURL(props.file)
			await nextTick()
		} else {
			clearPreview()
		}
	},
)

onUnmounted(clearPreview)
</script>

<template>
	<Teleport to="body">
		<Transition name="crop-fade">
			<div v-if="open && file" class="crop-overlay" @click.self="close">
				<div class="crop-card">
					<div class="crop-preview">
						<img
							ref="cropImageRef"
							:src="previewUrl"
							alt="crop"
							class="crop-image"
							@load="initCropper"
							@error="onImageError"
						/>
					</div>

					<div class="crop-controls">
						<div class="crop-slider-row">
							<button type="button" class="crop-btn" @click="zoomOut" title="Уменьшить">−</button>
							<input
								type="range"
								:min="MIN_ZOOM"
								:max="MAX_ZOOM"
								:step="0.01"
								:value="zoom"
								class="crop-slider"
								@input="onSliderInput"
							/>
							<button type="button" class="crop-btn" @click="zoomIn" title="Увеличить">+</button>
						</div>
						<div class="crop-rotate-row">
							<button type="button" class="crop-btn" @click="rotateLeft" title="Повернуть влево">↺</button>
							<button type="button" class="crop-btn" @click="rotateRight" title="Повернуть вправо">↻</button>
						</div>
					</div>

					<div class="crop-actions">
						<button type="button" class="crop-btn crop-btn-cancel" @click="close">Отмена</button>
						<button type="button" class="crop-btn crop-btn-confirm" :disabled="cropping" @click="confirm">{{ cropping ? 'Готовим…' : 'Готово' }}</button>
					</div>
				</div>
			</div>
		</Transition>
	</Teleport>
</template>

<style scoped>
.crop-fade-enter-active,
.crop-fade-leave-active {
	transition: opacity 0.18s ease;
}
.crop-fade-enter-from,
.crop-fade-leave-to {
	opacity: 0;
}

.crop-overlay {
	position: fixed;
	inset: 0;
	z-index: 120;
	display: flex;
	align-items: center;
	justify-content: center;
	background: color-mix(in srgb, var(--app-text) 82%, transparent);
	backdrop-filter: blur(8px);
	padding: 1rem;
}

.crop-card {
	width: 100%;
	max-width: 32rem;
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	border: 1px solid var(--app-border);
	border-radius: 1.7rem;
	overflow: hidden;
	display: flex;
	flex-direction: column;
}

.crop-preview {
	position: relative;
	width: 100%;
	aspect-ratio: 1;
	overflow: hidden;
	background: color-mix(in srgb, var(--app-text) 92%, var(--app-surface));
}

.crop-image {
	display: block;
	max-width: 100%;
}

.crop-controls {
	padding: 0.75rem 1rem 0.5rem;
	display: flex;
	flex-direction: column;
	gap: 0.5rem;
}

.crop-slider-row {
	display: flex;
	align-items: center;
	gap: 0.6rem;
}

.crop-rotate-row {
	display: flex;
	justify-content: center;
	gap: 0.6rem;
}

.crop-slider {
	flex: 1;
	accent-color: var(--app-accent);
	height: 0.3rem;
}

.crop-btn {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	height: 2.4rem;
	min-width: 2.4rem;
	border-radius: 0.8rem;
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	color: var(--app-text);
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
	font-size: 1rem;
	cursor: pointer;
	user-select: none;
	touch-action: manipulation;
}
.crop-btn:active {
	transform: scale(0.96);
}

.crop-actions {
	display: flex;
	gap: 0.6rem;
	padding: 0.5rem 1rem 1rem;
}
.crop-btn-cancel {
	flex: 1;
	background: var(--app-surface);
	color: var(--app-muted);
}
.crop-btn-confirm {
	flex: 1;
	border-color: var(--app-accent);
	background: var(--app-button-bg);
	color: var(--app-button-fg);
	font-weight: 700;
}
</style>
