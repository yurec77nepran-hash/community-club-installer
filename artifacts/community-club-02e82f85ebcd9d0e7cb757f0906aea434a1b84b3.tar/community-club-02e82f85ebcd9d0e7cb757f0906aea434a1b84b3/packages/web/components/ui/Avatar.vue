<script setup lang="ts">
interface Props {
	src?: string | null
	name?: string
	size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
}

const props = withDefaults(defineProps<Props>(), { size: 'md' })
const imageBroken = ref(false)
watch(
	() => props.src,
	() => {
		imageBroken.value = false
	},
)

const initial = computed(() => (props.name ?? '?').charAt(0).toUpperCase())
const emoji = computed(() =>
	props.src?.startsWith('emoji:') ? props.src.slice('emoji:'.length) : null,
)
const imageSrc = computed(() =>
	!imageBroken.value && props.src && !props.src.startsWith('emoji:') ? props.src : null,
)

const sizeClasses = computed(
	() =>
		({
			xs: 'w-6 h-6 text-xs',
			sm: 'w-8 h-8 text-sm',
			md: 'w-10 h-10 text-base',
			lg: 'w-14 h-14 text-lg',
			xl: 'w-20 h-20 text-2xl',
		})[props.size],
)
</script>

<template>
	<div
		class="rounded-full border border-[var(--app-border-strong)] bg-[var(--app-surface)] shadow-[var(--app-shadow-soft)] flex items-center justify-center overflow-hidden flex-shrink-0"
		:class="sizeClasses"
	>
		<img v-if="imageSrc" :src="imageSrc" :alt="name" class="w-full h-full object-cover" @error="imageBroken = true" />
		<span v-else-if="emoji" class="leading-none">{{ emoji }}</span>
		<span v-else class="text-[var(--app-accent-strong)] font-semibold">{{ initial }}</span>
	</div>
</template>
