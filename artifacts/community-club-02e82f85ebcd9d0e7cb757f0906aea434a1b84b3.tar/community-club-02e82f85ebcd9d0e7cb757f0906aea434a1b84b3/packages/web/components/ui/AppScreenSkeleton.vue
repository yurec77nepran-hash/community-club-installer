<script setup lang="ts">
const props = withDefaults(
	defineProps<{
		variant?: 'cards' | 'feed' | 'detail' | 'calendar' | 'chat'
		count?: number
	}>(),
	{
		variant: 'cards',
		count: 6,
	},
)
</script>

<template>
	<div class="app-skeleton-shell">
		<div v-if="props.variant === 'cards'" class="grid grid-cols-2 gap-3 max-w-5xl mx-auto lg:grid-cols-3">
			<div v-for="item in props.count" :key="item" class="club-card overflow-hidden rounded-3xl">
				<div class="app-skeleton-box aspect-video" />
				<div class="space-y-3 p-3">
					<div class="flex items-center justify-between gap-3">
						<div class="app-skeleton-line h-2.5 w-20" />
						<div class="app-skeleton-line h-2.5 w-12" />
					</div>
					<div class="app-skeleton-line h-3.5 w-[88%]" />
					<div class="app-skeleton-line h-3.5 w-[68%]" />
				</div>
			</div>
		</div>

		<div v-else-if="props.variant === 'feed'" class="mx-auto max-w-5xl space-y-5">
			<div v-for="item in Math.max(3, props.count)" :key="item" class="club-card overflow-hidden rounded-3xl p-4">
				<div class="mb-4 flex items-center gap-3">
					<div class="app-skeleton-dot h-11 w-11 rounded-2xl" />
					<div class="min-w-0 flex-1 space-y-2">
						<div class="app-skeleton-line h-3 w-36" />
						<div class="app-skeleton-line h-2.5 w-24" />
					</div>
				</div>
				<div class="mb-4 space-y-2">
					<div class="app-skeleton-line h-3 w-full" />
					<div class="app-skeleton-line h-3 w-[92%]" />
					<div class="app-skeleton-line h-3 w-[60%]" />
				</div>
				<div class="app-skeleton-box aspect-[16/10] rounded-[1.4rem]" />
			</div>
		</div>

		<div v-else-if="props.variant === 'detail'" class="mx-auto max-w-4xl space-y-5 px-4 pt-4 md:px-6">
			<div class="club-card overflow-hidden rounded-3xl">
				<div class="app-skeleton-box aspect-video" />
			</div>
			<div class="club-card rounded-3xl p-5">
				<div class="mb-3 flex items-center gap-3">
					<div class="app-skeleton-line h-3 w-24" />
					<div class="app-skeleton-line h-3 w-16" />
				</div>
				<div class="space-y-3">
					<div class="app-skeleton-line h-5 w-[76%]" />
					<div class="app-skeleton-line h-4 w-full" />
					<div class="app-skeleton-line h-4 w-[94%]" />
					<div class="app-skeleton-line h-4 w-[84%]" />
				</div>
			</div>
			<div class="club-card rounded-3xl p-5">
				<div class="app-skeleton-line mb-4 h-4 w-28" />
				<div class="space-y-3">
					<div v-for="item in 3" :key="item" class="rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] p-4">
						<div class="mb-2 flex items-center gap-3">
							<div class="app-skeleton-dot h-9 w-9 rounded-xl" />
							<div class="space-y-2">
								<div class="app-skeleton-line h-3 w-28" />
								<div class="app-skeleton-line h-2.5 w-20" />
							</div>
						</div>
						<div class="space-y-2">
							<div class="app-skeleton-line h-3 w-full" />
							<div class="app-skeleton-line h-3 w-[82%]" />
						</div>
					</div>
				</div>
			</div>
		</div>

		<div v-else-if="props.variant === 'calendar'" class="space-y-4">
			<div class="club-card rounded-3xl p-4">
				<div class="mb-4 flex items-center justify-between">
					<div class="app-skeleton-line h-5 w-40" />
					<div class="app-skeleton-line h-8 w-24 rounded-full" />
				</div>
				<div class="grid grid-cols-7 gap-2">
					<div
						v-for="item in 35"
						:key="item"
						class="rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] p-2"
					>
						<div class="app-skeleton-line mb-6 h-3 w-5" />
						<div class="app-skeleton-line h-4 w-8 rounded-full" />
					</div>
				</div>
			</div>
			<div class="club-card rounded-3xl p-4">
				<div class="mb-4 space-y-2">
					<div class="app-skeleton-line h-4 w-28" />
					<div class="app-skeleton-line h-3 w-40" />
				</div>
				<div class="space-y-3">
					<div v-for="item in 2" :key="item" class="rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] p-4">
						<div class="app-skeleton-box mb-3 aspect-[16/9] rounded-2xl" />
						<div class="space-y-2">
							<div class="app-skeleton-line h-4 w-[62%]" />
							<div class="app-skeleton-line h-3 w-24" />
							<div class="app-skeleton-line h-3 w-full" />
							<div class="app-skeleton-line h-3 w-[88%]" />
						</div>
					</div>
				</div>
			</div>
		</div>

		<div v-else class="space-y-3 py-1" aria-label="Загружаем сообщения">
			<div
				v-for="item in 6"
				:key="item"
				class="flex items-end gap-2"
				:class="item === 2 || item === 5 ? 'justify-end' : 'justify-start'"
			>
				<div v-if="item !== 2 && item !== 5" class="app-skeleton-dot h-8 w-8 shrink-0 rounded-full" />
				<div
					class="w-[72%] max-w-[20rem] space-y-2 border px-3.5 py-2.5"
					:class="item === 2 || item === 5 ? 'rounded-2xl rounded-br-sm border-[var(--app-border-strong)] bg-[color-mix(in_srgb,var(--app-accent)_8%,var(--app-surface))]' : 'rounded-2xl rounded-bl-sm border-[var(--app-border)] bg-[var(--app-surface)]'"
				>
					<div v-if="item !== 2 && item !== 5" class="app-skeleton-line h-2.5 w-20" />
					<div class="space-y-2">
						<div class="app-skeleton-line h-3 w-full" />
						<div class="app-skeleton-line h-3" :class="item === 3 || item === 5 ? 'w-[58%]' : 'w-[82%]'" />
					</div>
					<div class="flex justify-end"><div class="app-skeleton-line h-2 w-9" /></div>
				</div>
				<div v-if="item === 2 || item === 5" class="app-skeleton-dot h-8 w-8 shrink-0 rounded-full" />
			</div>
		</div>
	</div>
</template>
