<script setup lang="ts">
interface Props {
	padding?: boolean
}

withDefaults(defineProps<Props>(), { padding: true })
</script>

<template>
	<div class="rounded-2xl border border-[var(--app-border)] bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] text-[var(--app-text)] shadow-[var(--app-shadow-soft)]" :class="padding ? 'p-4' : ''">
		<slot />
	</div>
</template>
