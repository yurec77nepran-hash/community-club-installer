<script setup lang="ts">
interface Props {
	modelValue?: string
	type?: string
	placeholder?: string
	label?: string
	error?: string
	disabled?: boolean
}

defineProps<Props>()
defineEmits<{ 'update:modelValue': [value: string] }>()
</script>

<template>
	<div class="w-full">
		<label v-if="label" class="block text-sm font-medium text-[var(--app-text)] mb-1">{{ label }}</label>
		<input
			:type="type ?? 'text'"
			:value="modelValue"
			:placeholder="placeholder"
			:disabled="disabled"
			class="glass-input w-full px-4 py-2.5 rounded-xl border transition-colors duration-200 outline-none text-sm"
			:class="[
				error
					? 'border-[var(--app-danger)] focus:border-[var(--app-danger)] focus:ring-2 focus:ring-[color-mix(in_srgb,var(--app-danger)_18%,transparent)]'
					: 'border-[var(--app-border)] focus:border-[var(--app-accent)] focus:ring-2 focus:ring-[color-mix(in_srgb,var(--app-accent)_20%,transparent)]',
				disabled ? 'bg-[var(--app-bg-deep)] cursor-not-allowed' : 'bg-[var(--app-surface)]',
			]"
			@input="$emit('update:modelValue', ($event.target as HTMLInputElement).value)"
		/>
		<p v-if="error" class="mt-1 text-xs text-[var(--app-danger)]">{{ error }}</p>
	</div>
</template>
