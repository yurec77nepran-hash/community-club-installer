<script setup lang="ts">
import {
	DialogClose,
	DialogContent,
	DialogOverlay,
	DialogPortal,
	DialogRoot,
	DialogTitle,
} from 'radix-vue'

interface Props {
	open: boolean
	title?: string
}

defineProps<Props>()
defineEmits<{ 'update:open': [value: boolean] }>()
</script>

<template>
	<DialogRoot :open="open" @update:open="$emit('update:open', $event)">
		<DialogPortal>
			<DialogOverlay class="fixed inset-0 z-50 bg-[color-mix(in_srgb,var(--app-text)_50%,transparent)] backdrop-blur-sm animate-fade-in" />
			<DialogContent
				class="fixed left-1/2 top-1/2 z-50 -translate-x-1/2 -translate-y-1/2 w-[calc(100%-2rem)] max-w-md border border-[var(--app-border-strong)] bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] text-[var(--app-text)] rounded-3xl shadow-[var(--app-shadow-floating)] p-6 animate-scale-in"
			>
				<div v-if="title" class="flex items-center justify-between mb-4">
					<DialogTitle class="text-lg font-semibold">{{ title }}</DialogTitle>
					<DialogClose aria-label="Закрыть" class="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-[var(--app-muted-soft)] transition hover:bg-[var(--app-bg)] hover:text-[var(--app-accent-strong)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--app-accent)]">
						<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
						</svg>
					</DialogClose>
				</div>
				<slot />
			</DialogContent>
		</DialogPortal>
	</DialogRoot>
</template>

<style>
@keyframes fade-in {
	from { opacity: 0; }
	to { opacity: 1; }
}
@keyframes scale-in {
	from { opacity: 0; transform: translate(-50%, -50%) scale(0.95); }
	to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
}
.animate-fade-in { animation: fade-in 200ms ease; }
.animate-scale-in { animation: scale-in 200ms ease; }
@media (prefers-reduced-motion: reduce) {
	.animate-fade-in,
	.animate-scale-in { animation: none; }
}
</style>
