<script setup lang="ts">
interface Props {
	size?: 'sm' | 'md' | 'lg'
}

const props = withDefaults(defineProps<Props>(), { size: 'md' })

const sizeClasses = computed(
	() =>
		({
			sm: 'w-4 h-4 border-2',
			md: 'w-8 h-8 border-4',
			lg: 'w-12 h-12 border-4',
		})[props.size],
)
</script>

<template>
	<div
		class="animate-spin rounded-full border-[var(--app-border)] border-t-[var(--app-accent)]"
		:class="sizeClasses"
	/>
</template>
