<script setup lang="ts">
interface Props {
	message: string
	type?: 'success' | 'error' | 'info'
	visible: boolean
}

const props = withDefaults(defineProps<Props>(), { type: 'info' })
defineEmits<{ close: [] }>()

const bgClass = computed(
	() =>
		({
			success:
				'border-[color-mix(in_srgb,var(--app-success)_36%,var(--app-border))] text-[var(--app-success)]',
			error:
				'border-[color-mix(in_srgb,var(--app-danger)_36%,var(--app-border))] text-[var(--app-danger)]',
			info: 'border-[var(--app-border-strong)] text-[var(--app-text)]',
		})[props.type],
)
</script>

<template>
	<Transition
		enter-from-class="translate-y-4 opacity-0"
		enter-active-class="transition duration-300"
		leave-to-class="translate-y-4 opacity-0"
		leave-active-class="transition duration-200"
	>
		<div
			v-if="visible"
			class="app-toast z-50 mx-auto rounded-xl border bg-gradient-to-b from-[var(--app-surface)] to-[var(--app-bg)] px-4 py-3 text-sm shadow-[var(--app-shadow-floating)] flex items-center justify-between"
			:class="bgClass"
		>
			<span>{{ message }}</span>
			<button class="ml-2 opacity-70 hover:opacity-100" @click="$emit('close')">
				<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>
		</div>
	</Transition>
</template>
