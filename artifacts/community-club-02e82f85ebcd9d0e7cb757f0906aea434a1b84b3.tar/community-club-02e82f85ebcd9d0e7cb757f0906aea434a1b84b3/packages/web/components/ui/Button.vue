<script setup lang="ts">
interface Props {
	variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger'
	size?: 'sm' | 'md' | 'lg'
	loading?: boolean
	disabled?: boolean
	type?: 'button' | 'submit' | 'reset'
	block?: boolean
}

const props = withDefaults(defineProps<Props>(), {
	variant: 'primary',
	size: 'md',
	type: 'button',
})

const classes = computed(() => {
	const base =
		'inline-flex items-center justify-center font-medium rounded-xl border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[color-mix(in_srgb,var(--app-accent)_24%,transparent)] focus:ring-offset-2 focus:ring-offset-[var(--app-bg)]'

	const variants = {
		primary:
			'border-[var(--app-border-strong)] bg-[var(--app-button-bg)] text-[var(--app-button-fg)] shadow-[var(--app-shadow-soft)] hover:brightness-105 disabled:opacity-50',
		secondary:
			'border-[var(--app-border)] bg-[var(--app-surface)] text-[var(--app-text)] shadow-[var(--app-shadow-soft)] hover:bg-[var(--app-bg)]',
		outline:
			'border-2 border-[var(--app-accent)] bg-[var(--app-surface)] text-[var(--app-accent-strong)] hover:bg-[color-mix(in_srgb,var(--app-accent)_8%,var(--app-surface))]',
		ghost:
			'border-transparent text-[var(--app-muted)] hover:bg-[var(--app-bg)] hover:text-[var(--app-text)]',
		danger:
			'border-[var(--app-danger)] bg-[var(--app-danger)] text-[var(--app-surface)] shadow-[var(--app-shadow-soft)] hover:brightness-95',
	}

	const sizes = {
		sm: 'px-3 py-1.5 text-sm',
		md: 'px-4 py-2.5 text-sm',
		lg: 'px-6 py-3 text-base',
	}

	return [
		base,
		variants[props.variant],
		sizes[props.size],
		props.block ? 'w-full' : '',
		props.disabled || props.loading ? 'opacity-50 cursor-not-allowed' : '',
	].join(' ')
})
</script>

<template>
	<button
		:type="type"
		:class="classes"
		:disabled="disabled || loading"
	>
		<svg v-if="loading" class="animate-spin -ml-1 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24">
			<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" />
			<path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
		</svg>
		<slot />
	</button>
</template>
