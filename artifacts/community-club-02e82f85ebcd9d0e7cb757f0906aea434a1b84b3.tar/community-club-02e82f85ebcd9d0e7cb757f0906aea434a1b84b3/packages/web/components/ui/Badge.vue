<script setup lang="ts">
interface Props {
	variant?: 'default' | 'success' | 'warning' | 'danger' | 'info'
}

const props = withDefaults(defineProps<Props>(), { variant: 'default' })

const classes = computed(
	() =>
		({
			default: 'border-[var(--app-border)] bg-[var(--app-bg)] text-[var(--app-muted)]',
			success:
				'border-[color-mix(in_srgb,var(--app-success)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-success)_10%,var(--app-surface))] text-[var(--app-success)]',
			warning:
				'border-[color-mix(in_srgb,var(--app-accent-amber)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent-amber)_10%,var(--app-surface))] text-[var(--app-accent-strong)]',
			danger:
				'border-[color-mix(in_srgb,var(--app-danger)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-danger)_10%,var(--app-surface))] text-[var(--app-danger)]',
			info: 'border-[color-mix(in_srgb,var(--app-accent-blue)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent-blue)_10%,var(--app-surface))] text-[var(--app-text)]',
		})[props.variant],
)
</script>

<template>
	<span class="inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium" :class="classes">
		<slot />
	</span>
</template>
