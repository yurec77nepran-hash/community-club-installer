<script setup lang="ts">
type AppNotification = {
	id: number
	title: string
	body: string
	url: string | null
	context: string
	deliveredAt: string | Date | null
	readAt: string | Date | null
	createdAt: string | Date
}

type NotificationListResponse = {
	items: AppNotification[]
	nextCursor: string | null
	unreadCount: number
}

const props = defineProps<{ open: boolean }>()
const emit = defineEmits<{
	'update:open': [value: boolean]
	'update:unreadCount': [value: number]
}>()

const api = useApi()
const router = useRouter()
const items = ref<AppNotification[]>([])
const nextCursor = ref<string | null>(null)
const unreadCount = ref(0)
const loading = ref(false)
const loadingMore = ref(false)
const errorMessage = ref('')

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'short',
		hour: '2-digit',
		minute: '2-digit',
	})
}

async function loadNotifications(options?: { append?: boolean }) {
	const append = options?.append ?? false
	if (append) {
		if (!nextCursor.value || loadingMore.value) return
		loadingMore.value = true
	} else {
		loading.value = true
	}
	errorMessage.value = ''

	const query = new URLSearchParams({ limit: '30' })
	if (append && nextCursor.value) query.set('cursor', nextCursor.value)
	const res = await api.get<NotificationListResponse>(`/api/push/notifications?${query}`)

	if (res.success) {
		items.value = append ? [...items.value, ...res.data.items] : res.data.items
		nextCursor.value = res.data.nextCursor
		unreadCount.value = res.data.unreadCount
	} else {
		errorMessage.value = res.error.message
	}

	loading.value = false
	loadingMore.value = false
}

async function openNotification(item: AppNotification) {
	if (!item.readAt) {
		const res = await api.patch(`/api/push/notifications/${item.id}/read`, {})
		if (res.success) {
			item.readAt = new Date().toISOString()
			unreadCount.value = Math.max(0, unreadCount.value - 1)
			emit('update:unreadCount', unreadCount.value)
		}
	}
	if (item.url) {
		emit('update:open', false)
		await router.push(item.url)
	}
}

async function markAllRead() {
	const res = await api.post<{ read: number }>('/api/push/notifications/read-all', {})
	if (!res.success) return
	const now = new Date().toISOString()
	items.value = items.value.map((item) => ({ ...item, readAt: item.readAt ?? now }))
	unreadCount.value = 0
	emit('update:unreadCount', unreadCount.value)
}

watch(
	() => props.open,
	(open) => {
		if (open && items.value.length === 0) {
			void loadNotifications()
		}
	},
)
</script>

<template>
	<Teleport to="body">
		<Transition name="notif-fade">
			<div v-if="open" class="notif-overlay" @click.self="emit('update:open', false)">
				<div class="notif-sheet">
					<header class="notif-header">
						<div>
							<p class="notif-kicker">События</p>
							<h2 class="notif-title">Уведомления</h2>
						</div>
						<button
							type="button"
							class="notif-icon-btn"
							aria-label="Закрыть"
							@click="emit('update:open', false)"
						>
							✕
						</button>
					</header>

					<div class="notif-tools">
						<button type="button" class="notif-read-all" :disabled="unreadCount === 0" @click="markAllRead">
							Прочитать все
						</button>
					</div>

					<div class="notif-body">
						<p v-if="errorMessage" class="notif-state">{{ errorMessage }}</p>
						<p v-else-if="loading && items.length === 0" class="notif-state">Загрузка...</p>
						<p v-else-if="items.length === 0" class="notif-state">Новых событий нет.</p>
						<div v-else class="notif-list">
							<button
								v-for="item in items"
								:key="item.id"
								type="button"
								class="notif-item"
								:class="{ 'notif-item-unread': !item.readAt }"
								@click="openNotification(item)"
							>
								<span class="notif-dot" />
								<span class="notif-content">
									<span class="notif-item-title">{{ item.title }}</span>
									<span v-if="item.body" class="notif-item-body">{{ item.body }}</span>
									<span class="notif-date">{{ formatDate(item.createdAt) }}</span>
								</span>
							</button>
							<button
								v-if="nextCursor"
								type="button"
								class="notif-more"
								:disabled="loadingMore"
								@click="loadNotifications({ append: true })"
							>
								{{ loadingMore ? 'Загрузка...' : 'Показать ещё' }}
							</button>
						</div>
					</div>
				</div>
			</div>
		</Transition>
	</Teleport>
</template>

<style scoped>
.notif-fade-enter-active,
.notif-fade-leave-active {
	transition: opacity 0.18s ease;
}
.notif-fade-enter-from,
.notif-fade-leave-to {
	opacity: 0;
}

.notif-overlay {
	position: fixed;
	inset: 0;
	z-index: 100;
	display: flex;
	align-items: flex-end;
	justify-content: center;
	background: color-mix(in srgb, var(--app-text) 66%, transparent);
	backdrop-filter: blur(8px);
	padding: 0;
}

.notif-sheet {
	width: 100%;
	max-width: 34rem;
	max-height: min(78vh, 40rem);
	display: flex;
	flex-direction: column;
	border-radius: 1.5rem 1.5rem 0 0;
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	border: 1px solid var(--app-border);
	border-bottom: none;
	box-shadow: var(--app-shadow-floating), inset 0 1px rgb(255 255 255 / 0.96);
	overflow: hidden;
	color: var(--app-text);
}

.notif-header {
	display: flex;
	align-items: flex-start;
	justify-content: space-between;
	gap: 1rem;
	padding: 1.1rem 1.1rem 0.6rem;
}
.notif-kicker {
	margin: 0;
	font-size: 0.62rem;
	font-weight: 650;
	letter-spacing: 0.17em;
	text-transform: uppercase;
	color: var(--app-muted-soft);
}
.notif-title {
	margin: 0.2rem 0 0;
	font-size: 1.25rem;
	font-weight: 700;
}
.notif-icon-btn {
	width: 2.4rem;
	height: 2.4rem;
	border-radius: 999px;
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	color: inherit;
	font-size: 0.85rem;
	cursor: pointer;
}

.notif-tools {
	padding: 0.3rem 1.1rem 0.5rem;
}
.notif-read-all {
	border: none;
	background: transparent;
	color: var(--app-accent-strong);
	font-size: 0.8rem;
	font-weight: 600;
	cursor: pointer;
}
.notif-read-all:disabled {
	opacity: 0.35;
	cursor: not-allowed;
}

.notif-body {
	flex: 1;
	overflow-y: auto;
	padding: 0.4rem 1.1rem 1.1rem;
}
.notif-state {
	margin: 2rem 0;
	text-align: center;
	font-size: 0.85rem;
	color: var(--app-muted-soft);
}
.notif-list {
	display: grid;
	gap: 0.6rem;
}
.notif-item {
	display: grid;
	grid-template-columns: 0.5rem 1fr;
	gap: 0.55rem;
	text-align: left;
	border: 1px solid var(--app-border);
	border-radius: 1.1rem;
	background: var(--app-surface);
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
	padding: 0.8rem 0.9rem;
	cursor: pointer;
}
.notif-item-unread {
	border-color: var(--app-border-strong);
	background: color-mix(in srgb, var(--app-accent) 9%, var(--app-surface));
}
.notif-dot {
	width: 0.45rem;
	height: 0.45rem;
	margin-top: 0.3rem;
	border-radius: 999px;
	background: var(--app-muted-soft);
}
.notif-item-unread .notif-dot {
	background: var(--app-accent);
	box-shadow: 0 0 8px color-mix(in srgb, var(--app-accent) 50%, transparent);
}
.notif-content {
	display: grid;
	gap: 0.25rem;
	min-width: 0;
}
.notif-item-title {
	font-size: 0.92rem;
	font-weight: 800;
	color: inherit;
}
.notif-item-body {
	font-size: 0.82rem;
	line-height: 1.4;
	color: var(--app-muted);
	white-space: pre-line;
}
.notif-date {
	font-size: 0.72rem;
	color: var(--app-muted-soft);
}
.notif-more {
	margin-top: 0.4rem;
	width: 100%;
	border: 1px solid var(--app-border);
	border-radius: 0.9rem;
	background: var(--app-surface);
	color: inherit;
	font-size: 0.82rem;
	font-weight: 600;
	padding: 0.6rem;
	cursor: pointer;
}
.notif-more:disabled {
	opacity: 0.5;
}
</style>
