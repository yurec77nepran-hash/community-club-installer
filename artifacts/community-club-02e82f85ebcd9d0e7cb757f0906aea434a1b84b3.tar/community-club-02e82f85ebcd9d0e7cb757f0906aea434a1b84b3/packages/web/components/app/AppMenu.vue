<script setup lang="ts">
import type { AppMenuItem, GuestContentAccessSettings } from '@community-club/shared/types'
import { storeToRefs } from 'pinia'

const route = useRoute()
const auth = useAuthStore()
const subscriptionStore = useSubscriptionStore()
const { user: authUser } = storeToRefs(auth)
const { settings, loadAppNavigation } = useAppNavigation()
const guestContentAccess = ref<GuestContentAccessSettings['level']>('cards')

const hasClubAccess = computed(() => auth.isAdmin || subscriptionStore.hasActiveSubscription)

function isActive(path: string) {
	if (path === '/app') return route.path === '/app'
	return route.path.startsWith(path)
}

function isLocked(item: AppMenuItem) {
	if (item.requiresAccess && item.path.startsWith('/app/content/') && !hasClubAccess.value) {
		return guestContentAccess.value === 'sections'
	}
	if (item.requiresAccess) return !hasClubAccess.value
	if (item.requiresAuth) return !authUser.value
	return false
}

const activePath = computed(() => {
	const matched = settings.value.menu.items.find((item) => isActive(item.path))
	return matched?.path ?? settings.value.menu.startActivePath
})

const slots = computed(() => {
	type MenuSlot = { kind: 'item'; item: AppMenuItem } | { kind: 'center' }
	const items = settings.value.menu.items
	const result: MenuSlot[] = items.map((item) => ({ kind: 'item', item }))
	if (settings.value.menu.centerButton.enabled) {
		const centerIndex = Math.ceil(items.length / 2)
		result.splice(centerIndex, 0, { kind: 'center' })
	}
	return result
})

const gridStyle = computed(() => ({
	gridTemplateColumns: `repeat(${slots.value.length}, minmax(0, 1fr))`,
}))

const menuStyle = computed(() => ({
	'--menu-bg': 'var(--app-surface)',
	'--menu-border': 'var(--app-border)',
	'--menu-radius': `${settings.value.menu.borderRadius}px`,
	'--menu-margin-bottom': `${settings.value.menu.marginBottom}px`,
	'--menu-margin-side': `${settings.value.menu.marginSide}px`,
	'--menu-icon-stroke': 'var(--app-border)',
	'--menu-active': 'var(--app-accent-strong)',
	'--menu-inactive': 'var(--app-muted)',
}))

function handleItemClick(event: MouseEvent, item: AppMenuItem) {
	if (!isLocked(item)) return
	event.preventDefault()
	if (!import.meta.client) return
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: { redirect: item.path },
		}),
	)
}

function handleCenterClick(event: MouseEvent) {
	const centerButton = settings.value.menu.centerButton
	if (!centerButton.requiresAuth || authUser.value) return
	event.preventDefault()
	if (!import.meta.client) return
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: { redirect: centerButton.actionPath, intent: 'login' },
		}),
	)
}

onMounted(() => {
	void loadAppNavigation()
	void useApi()
		.get<GuestContentAccessSettings>('/api/site-settings/guest-content-access', {
			authRedirect: false,
		})
		.then((response) => {
			if (response.success) guestContentAccess.value = response.data.level
		})
})
</script>

<template>
	<nav v-if="settings.menu.items.length > 0" class="app-menu" :style="menuStyle">
		<div class="app-menu-inner" :style="gridStyle">
			<template v-for="slot in slots" :key="slot.kind === 'center' ? 'menu-center' : slot.item.id">
				<NuxtLink
					v-if="slot.kind === 'item'"
					:to="slot.item.path"
					class="app-menu-tab"
					:class="{
						'app-menu-tab-active': slot.item.path === activePath,
						'app-menu-tab-locked': isLocked(slot.item),
					}"
					@click="handleItemClick($event, slot.item)"
					>
						<span
							class="app-menu-icon-wrap"
							:class="{
								'app-menu-icon-glow': settings.menu.iconGlowEnabled && slot.item.path === activePath,
							}"
						>
							<AppNavIcon :name="slot.item.icon" :size="18" />
							<span v-if="isLocked(slot.item)" class="app-menu-lock" aria-hidden="true">
								<svg class="h-2.5 w-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path
										stroke-linecap="round"
										stroke-linejoin="round"
										stroke-width="2.4"
										d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
									/>
								</svg>
							</span>
						</span>
						<span class="app-menu-label">{{ slot.item.label }}</span>
					</NuxtLink>

				<NuxtLink
					v-else
					:to="settings.menu.centerButton.actionPath"
					class="app-menu-center"
					:class="{
						'app-menu-center-press': settings.menu.centerButton.pressEffectEnabled,
					}"
					@click="handleCenterClick($event)"
				>
					<span v-if="settings.menu.centerButton.glowEnabled" class="app-menu-center-ring" aria-hidden="true" />
						<span v-if="settings.menu.centerButton.glowEnabled" class="app-menu-center-ring app-menu-center-ring--late" aria-hidden="true" />
						<span
							class="app-menu-center-inner"
							:class="{
								'app-menu-center-glow': settings.menu.centerButton.glowEnabled,
							}"
							>
								<img
									:src="settings.menu.centerButton.imageUrl || '/pwa-icon?size=512&format=webp'"
									alt="Главная"
									width="512"
									height="512"
									loading="eager"
									fetchpriority="high"
									decoding="async"
									class="app-menu-center-image"
								/>
							</span>
				</NuxtLink>
			</template>
		</div>
	</nav>
</template>

<style scoped>
.app-menu {
	position: fixed;
	left: 50%;
	bottom: 0;
	z-index: 40;
	width: var(--app-viewport-width);
	max-width: var(--app-viewport-max);
	padding: 0 var(--menu-margin-side) max(var(--menu-margin-bottom), env(safe-area-inset-bottom));
	transform: translateX(-50%);
	pointer-events: none;
}

.app-menu-inner {
	position: relative;
	display: grid;
	min-height: 4.1rem;
	align-items: end;
	gap: 0;
	padding: 0.35rem 0.3rem 0.42rem;
	border: 1px solid var(--menu-border);
	border-radius: min(var(--menu-radius), 999px);
	background:
		radial-gradient(circle at 50% 0%, color-mix(in srgb, var(--app-accent) 10%, transparent), transparent 34%),
		linear-gradient(180deg, rgb(255 255 255 / 0.96), color-mix(in srgb, var(--menu-bg) 92%, var(--app-bg)) 100%);
	box-shadow:
		inset 0 1px rgb(255 255 255 / 0.96),
		var(--app-shadow-raised);
	backdrop-filter: blur(18px);
	pointer-events: auto;
}

.app-menu-tab {
	position: relative;
	display: flex;
	min-width: 0;
	flex-direction: column;
	align-items: center;
	gap: 0.22rem;
	padding: 0.25rem 0.08rem 0.12rem;
	color: var(--menu-inactive);
	transition:
		transform 0.2s ease,
		color 0.2s ease;
}

.app-menu-tab-active {
	color: var(--menu-active);
}

.app-menu-tab-locked {
	opacity: 1;
}

.app-menu-tab:active {
	transform: scale(0.97);
}

.app-menu-tab:focus-visible,
.app-menu-center:focus-visible {
	outline: 2px solid var(--app-accent);
	outline-offset: 2px;
}

.app-menu-icon-wrap {
	position: relative;
	display: flex;
	width: 2rem;
	height: 2rem;
	align-items: center;
	justify-content: center;
	border: 0;
	color: inherit;
}

.app-menu-icon-wrap :deep(svg) {
	filter: drop-shadow(0 2px 3px color-mix(in srgb, var(--app-text) 12%, transparent));
}

.app-menu-icon-wrap :deep(svg path) {
	stroke-width: 1.5;
}

.app-menu-icon-glow {
	filter: drop-shadow(0 0 8px color-mix(in srgb, var(--menu-active) 48%, transparent));
}

.app-menu-lock {
	display: none;
}

.app-menu-label {
	overflow: hidden;
	max-width: 100%;
	font-size: clamp(0.56rem, 2.4vw, 0.66rem);
	font-weight: 400;
	line-height: 1;
	letter-spacing: 0;
	text-overflow: ellipsis;
	white-space: nowrap;
	color: inherit;
	text-shadow: none;
}

.app-menu-center {
	position: relative;
	display: flex;
	align-self: stretch;
	align-items: center;
	justify-content: center;
	border-radius: 999px;
}

.app-menu-center-inner {
	position: absolute;
	top: 50%;
	left: 50%;
	display: flex;
	width: 3.5rem;
	height: 3.5rem;
	align-items: center;
	justify-content: center;
	border: 1.5px solid var(--app-accent);
	border-radius: 999px;
	background: radial-gradient(circle at 35% 18%, var(--app-surface), transparent 44%), linear-gradient(145deg, var(--app-surface), var(--app-bg-deep));
	color: var(--menu-active);
	box-shadow:
		inset 0 0 0 0.21rem var(--app-surface),
		inset 0 0 0 0.27rem color-mix(in srgb, var(--app-accent) 28%, transparent),
		var(--app-shadow-raised);
	transform: translate(-50%, -54%);
	transition: transform 0.16s ease;
}

.app-menu-center-glow {
	box-shadow:
		inset 0 0 0 0.21rem var(--app-surface),
		inset 0 0 0 0.27rem color-mix(in srgb, var(--app-accent) 34%, transparent),
		0 0 8px 1px color-mix(in srgb, var(--app-accent) 48%, transparent),
		0 0 26px 4px color-mix(in srgb, var(--app-accent) 28%, transparent),
		var(--app-shadow-raised);
}

.app-menu-center-inner::after {
	position: absolute;
	inset: 0.35rem;
	border: 1px solid color-mix(in srgb, var(--app-accent) 26%, transparent);
	border-radius: inherit;
	content: '';
	pointer-events: none;
}

.app-menu-center-press:active .app-menu-center-inner {
	transform: translate(-50%, -54%) scale(0.94);
}

.app-menu-center-image {
	position: relative;
	z-index: 1;
	width: 2.25rem;
	height: 2.25rem;
	border-radius: 999px;
	object-fit: cover;
}

/* Медленные «волны» света, расходящиеся от круглой подложки (не от лого) */
.app-menu-center-ring {
		position: absolute;
		top: 50%;
		left: 50%;
		width: 3.5rem;
		height: 3.5rem;
		z-index: 0;
		border: 2px solid color-mix(in srgb, var(--app-accent) 50%, transparent);
		border-radius: 999px;
		opacity: 0;
		transform: translate(-50%, -54%);
		pointer-events: none;
		animation: app-menu-center-wave 3.4s ease-out infinite;
	}

.app-menu-center-ring--late {
	animation-delay: 1.7s;
}

@keyframes app-menu-center-wave {
	0% {
		opacity: 0;
		transform: translate(-50%, -54%);
	}
	10% {
		opacity: 0.9;
	}
	100% {
		opacity: 0;
		transform: translate(-50%, -54%) scale(1.6);
	}
}

@media (max-width: 390px) {
	.app-menu-inner {
		min-height: 4rem;
		padding-inline: 0.18rem;
	}
}
</style>
