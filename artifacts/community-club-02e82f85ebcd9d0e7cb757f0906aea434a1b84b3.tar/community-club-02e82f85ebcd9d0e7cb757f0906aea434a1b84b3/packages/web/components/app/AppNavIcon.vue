<script setup lang="ts">
import type { AppMenuIcon } from '@community-club/shared/types'

withDefaults(defineProps<{ name: AppMenuIcon; size?: number }>(), { size: 20 })
</script>

<template>
	<svg
		:width="size"
		:height="size"
		fill="none"
		stroke="currentColor"
		viewBox="0 0 24 24"
		aria-hidden="true"
	>
		<path
			v-if="name === 'home'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
		/>
		<path
			v-else-if="name === 'feed'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h9l5 5v11a2 2 0 01-2 2zM14 3v5h5M8 13h8M8 17h5M8 9h3"
		/>
		<path
			v-else-if="name === 'calendar'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M8 7V3m8 4V3M5 11h14M7 21h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v12a2 2 0 002 2z"
		/>
		<template v-if="name === 'cube'">
			<path
				stroke-linecap="round"
				stroke-linejoin="round"
				stroke-width="1.5"
				d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"
			/>
			<path
				stroke-linecap="round"
				stroke-linejoin="round"
				stroke-width="1.5"
				d="m3.3 7 8.7 5 8.7-5"
			/>
			<path
				stroke-linecap="round"
				stroke-linejoin="round"
				stroke-width="1.5"
				d="M12 22V12"
			/>
		</template>
		<template v-else-if="name === 'book'">
			<path
				stroke-linecap="round"
				stroke-linejoin="round"
				stroke-width="1.5"
				d="M12 5v16"
			/>
			<path
				stroke-linecap="round"
				stroke-linejoin="round"
				stroke-width="1.5"
				d="M20.001 19A2 2 0 0 0 22 17V5a2 2 0 0 0-1.999-2L16 3.002A5 5 0 0 0 12 5a5 5 0 0 0-4-2H4a2 2 0 0 0-2 2v12a2 2 0 0 0 1.999 2H8a5 5 0 0 1 4 2 5 5 0 0 1 4-2Z"
			/>
		</template>
		<path
			v-else-if="name === 'wrench'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="1.5"
			d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984Z"
		/>
		<path
			v-else-if="name === 'user'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
		/>
		<path
			v-else-if="name === 'bell'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M15 17h5l-1.4-1.4A2 2 0 0118 14.2V11a6 6 0 10-12 0v3.2a2 2 0 01-.6 1.4L4 17h11zM9 17a3 3 0 006 0"
		/>
		<path
			v-else-if="name === 'support'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
		/>
		<path
			v-else-if="name === 'info'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
		/>
		<path
			v-else-if="name === 'chats'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M17 9h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a2 2 0 01-2-2v-1m5-5h2a2 2 0 012 2v4m-6 0H6a2 2 0 01-2-2V7a2 2 0 012-2h8a2 2 0 012 2v2"
		/>
		<path
			v-else-if="name === 'materials'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
		/>
		<path
			v-else-if="name === 'spark'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M12 3l1.9 5.8L19.7 10.7l-5.8 1.9L12 18.4l-1.9-5.8L4.3 10.7l5.8-1.9L12 3z"
		/>
		<path
			v-else-if="name === 'play'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M8 5.5v13l11-6.5-11-6.5z"
		/>
		<path
			v-else-if="name === 'check'"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M5 13l4 4L19 7"
		/>
		<path
			v-else
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
		/>
	</svg>
</template>
