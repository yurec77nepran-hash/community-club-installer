<template>
	<div class="app-intro-splash" role="status" aria-label="Загрузка приложения CLUB APP">
		<div class="app-intro-splash__mark">
			<img
				:src="'/pwa-icon?size=512&format=webp'"
				alt=""
				width="512"
				height="512"
				loading="eager"
				fetchpriority="high"
				decoding="async"
			/>
			<p>CLUB APP</p>
		</div>
	</div>
</template>

<style scoped>
.app-intro-splash { position: fixed; z-index: 100; inset: 0; display: grid; place-items: center; overflow: hidden; background: radial-gradient(circle at 50% 45%, color-mix(in srgb, var(--app-accent) 18%, transparent), transparent 28%), linear-gradient(180deg, var(--app-bg), var(--app-bg-deep)); }
.app-intro-splash__mark { display: grid; justify-items: center; gap: 1.15rem; }
.app-intro-splash img { width: clamp(11rem, 46vw, 18rem); height: auto; filter: drop-shadow(0 0 2rem color-mix(in srgb, var(--app-accent) 25%, transparent)); }
.app-intro-splash p { margin: 0; color: var(--app-text-strong); font-size: clamp(1.1rem, 4.5vw, 1.65rem); font-weight: 750; letter-spacing: 0.3em; line-height: 1; }

</style>
