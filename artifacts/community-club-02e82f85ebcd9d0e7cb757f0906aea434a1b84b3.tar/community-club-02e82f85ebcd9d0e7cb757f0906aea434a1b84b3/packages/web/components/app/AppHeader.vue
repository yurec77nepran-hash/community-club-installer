<script setup lang="ts">
import type { SiteBrandingSettings } from '@community-club/shared/types'
import { storeToRefs } from 'pinia'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const { user: authUser } = storeToRefs(auth)
const { settings, loadAppNavigation } = useAppNavigation()
const api = useApi()
const unreadCount = ref(0)
const notificationsOpen = ref(false)

const defaultBranding: SiteBrandingSettings = {
	clubName: 'Club App',
	homeLogoEnabled: true,
	homeLogoMediaKey: null,
	buttonBackgroundColor: '#d4a62a',
	appBackgroundColor: '#f7f5f0',
	appSurfaceColor: '#ffffff',
	appTextColor: '#1f1f1f',
	appAccentColor: '#d4a62a',
	homeLogoUrl: null,
}

const { data: branding } = await useAsyncData(
	'site-branding-settings',
	async () => {
		const res = await api.get<SiteBrandingSettings>('/api/site-settings/branding')
		return res.success ? res.data : defaultBranding
	},
	{ default: () => defaultBranding },
)

const headerVisible = computed(() => {
	const header = settings.value.header
	if (!header.enabled) return false
	if (!route.path.startsWith('/app')) return false
	if (route.path === '/app') return true
	return header.showOnAllPages
})

const headerOrder = computed(() => settings.value.header.order)
const hasUser = computed(() => Boolean(authUser.value))
const clubLogoUrl = computed(() =>
	branding.value.homeLogoEnabled ? branding.value.homeLogoUrl : null,
)
const clubName = computed(() => branding.value.clubName.trim() || defaultBranding.clubName)
const profileName = computed(() => {
	const user = authUser.value
	if (!user) return clubName.value
	return user.fullName?.trim() || user.username?.trim() || user.email?.split('@')[0] || 'Профиль'
})
const logoShowsImage = computed(
	() => settings.value.header.logoMode === 'image' && Boolean(clubLogoUrl.value),
)
const nameVisible = computed(
	() => settings.value.header.nameMode === 'club' || Boolean(authUser.value),
)
const headerName = computed(() =>
	settings.value.header.nameMode === 'club' ? clubName.value : profileName.value,
)
const avatarImageUrl = computed(() =>
	authUser.value?.avatarUrl && !authUser.value.avatarUrl.startsWith('emoji:')
		? authUser.value.avatarUrl
		: null,
)
const avatarEmoji = computed(() => {
	const value = authUser.value?.avatarUrl
	if (!value?.startsWith('emoji:')) return null
	return value.slice('emoji:'.length) || null
})

function requestAccess(intent: 'login' | 'pay', redirect: string) {
	if (!import.meta.client) return
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: { redirect, intent },
		}),
	)
}

function handleAvatarClick() {
	if (hasUser.value) {
		void navigateTo('/app/profile')
		return
	}
	requestAccess('login', '/app/profile')
}

function openNotifications() {
	if (hasUser.value) {
		notificationsOpen.value = true
		void loadUnreadCount()
		return
	}
	requestAccess('login', '/app')
}

async function loadUnreadCount() {
	if (!authUser.value) return
	const res = await api.get<{ unreadCount: number }>('/api/push/status')
	if (res.success) unreadCount.value = res.data.unreadCount
}

onMounted(() => {
	void loadAppNavigation()
	void loadUnreadCount()
})

watch(
	[() => route.query.notifications, hasUser],
	() => {
		if (!import.meta.client || route.query.notifications !== '1' || !hasUser.value) return
		openNotifications()
		const query = { ...route.query }
		query.notifications = undefined
		void router.replace({ query })
	},
	{ immediate: true },
)
</script>

<template>
	<header v-if="headerVisible" class="app-header">
		<div class="app-header-blocks">
			<template v-for="block in headerOrder" :key="block">
				<NuxtLink
					v-if="block === 'logo'"
					to="/app"
					class="app-header-block app-header-logo"
					aria-label="На главную"
				>
					<img
						v-if="logoShowsImage"
						:src="'/pwa-icon?size=512&format=webp'"
						:alt="clubName"
						width="512"
						height="512"
						loading="eager"
						fetchpriority="high"
						decoding="async"
						class="app-header-logo-image"
					/>
					<img
						v-else
						:src="'/pwa-icon?size=512&format=webp'"
						:alt="clubName"
						width="512"
						height="512"
						loading="eager"
						fetchpriority="high"
						decoding="async"
						class="app-header-logo-image app-header-logo-fallback"
					/>
				</NuxtLink>

				<button
					v-else-if="block === 'name' && nameVisible"
					type="button"
					class="app-header-block app-header-name"
					@click="handleAvatarClick"
				>
					<span class="app-header-name-title">{{ headerName }}</span>
					<span v-if="settings.header.nameMode === 'club'" class="app-header-name-subtitle"
						>Клуб</span
					>
				</button>

				<button
					v-else-if="block === 'avatar'"
					type="button"
					class="app-header-block app-header-avatar"
					aria-label="Профиль"
					@click="handleAvatarClick"
				>
					<img
						v-if="avatarImageUrl"
						:src="avatarImageUrl"
						:alt="profileName"
						class="app-header-avatar-image"
					/>
					<span v-else-if="avatarEmoji" class="app-header-avatar-emoji">{{ avatarEmoji }}</span>
					<span v-else class="app-header-avatar-fallback" aria-hidden="true">
						<AppNavIcon name="user" :size="18" />
					</span>
				</button>

				<button
					v-else-if="block === 'notifications'"
					type="button"
					class="app-header-block app-header-bell"
					aria-label="Уведомления"
					@click="openNotifications"
				>
					<AppNavIcon name="bell" :size="20" />
					<span v-if="hasUser && unreadCount > 0" class="app-header-badge">
						{{ unreadCount > 99 ? '99+' : unreadCount }}
					</span>
				</button>
			</template>
			</div>
		</header>

		<AppNotificationsModal
			v-model:open="notificationsOpen"
			@update:unread-count="unreadCount = $event"
		/>
	</template>

<style scoped>
.app-header {
	position: sticky;
	top: 0;
	z-index: 30;
	width: 100%;
	border-bottom: 1px solid var(--app-border);
	background:
		radial-gradient(circle at 24% -110%, color-mix(in srgb, var(--app-accent) 14%, transparent), transparent 42%),
		rgb(255 255 255 / 0.92);
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-raised);
	backdrop-filter: blur(40px);
}

.app-header-blocks {
	display: flex;
	min-height: 4.75rem;
	align-items: center;
	gap: 0.7rem;
	padding: 0.6rem 1rem;
}

.app-header-block {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	margin: 0;
	padding: 0;
	border: 0;
	border-radius: 999px;
	background: none;
	color: var(--app-text);
	font: inherit;
	line-height: 1.2;
	text-align: left;
	text-decoration: none;
	white-space: nowrap;
	cursor: pointer;
}

.app-header-block:focus-visible {
	outline: 2px solid var(--app-accent);
	outline-offset: 3px;
}

.app-header-logo {
	flex: 0 1 auto;
	min-width: 0;
}

.app-header-logo-image {
	width: 3.25rem;
	height: 3.25rem;
	max-width: none;
	object-fit: contain;
}

.app-header-logo-fallback {
	filter: drop-shadow(0 0 8px color-mix(in srgb, var(--app-accent) 28%, transparent));
}

.app-header-name {
	flex: 0 0 auto;
	min-width: 0;
	margin-right: auto;
	flex-direction: column;
	align-items: flex-start;
	gap: 0.16rem;
}

.app-header-name-title {
	overflow: visible;
	max-width: none;
	color: var(--app-text-strong);
	font-size: clamp(0.92rem, 4.2vw, 1.2rem);
	font-weight: 700;
	letter-spacing: 0.18em;
	line-height: 1;
	text-transform: uppercase;
	white-space: nowrap;
}

.app-header-name-subtitle {
	color: var(--app-accent-strong);
	font-size: 0.62rem;
	font-weight: 700;
	letter-spacing: 0.38em;
	line-height: 1;
	text-transform: uppercase;
}

.app-header-avatar {
	flex: 0 0 auto;
	width: 3rem;
	height: 3rem;
	overflow: hidden;
	border: 1.5px solid var(--app-accent);
	background: linear-gradient(145deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), 0 0 12px color-mix(in srgb, var(--app-accent) 16%, transparent);
}

.app-header-avatar-image {
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.app-header-avatar-emoji {
	display: flex;
	height: 100%;
	align-items: center;
	justify-content: center;
	font-size: 1.15rem;
}

.app-header-avatar-fallback {
	display: flex;
	height: 100%;
	align-items: center;
	justify-content: center;
	color: var(--app-muted);
}

.app-header-bell {
	position: relative;
	flex: 0 0 auto;
	width: 2.55rem;
	height: 2.55rem;
	align-items: center;
	justify-content: center;
	border-radius: 999px;
	background: transparent;
	color: var(--app-muted);
}

.app-header-badge {
	position: absolute;
	top: -0.16rem;
	right: -0.18rem;
	display: flex;
	min-width: 1.35rem;
	height: 1.35rem;
	align-items: center;
	justify-content: center;
	border: 2px solid var(--app-surface);
	border-radius: 999px;
	background: var(--app-accent);
	color: var(--app-button-fg);
	font-size: 0.72rem;
	font-weight: 800;
	line-height: 1;
	padding: 0 0.22rem;
}

@media (max-width: 359px) {
	.app-header-blocks {
		gap: 0.45rem;
		padding-inline: 0.7rem;
	}

	.app-header-logo-image {
		width: 2.8rem;
		height: 2.8rem;
	}

	.app-header-name-title {
		font-size: 0.82rem;
	}

	.app-header-avatar {
		width: 2.7rem;
		height: 2.7rem;
	}
}
</style>
