<script setup lang="ts">
import Button from '~/components/ui/Button.vue'
import Modal from '~/components/ui/Modal.vue'
import type { PwaBannerKind } from '~/utils/pwa-runtime'

const props = defineProps<{
	kind: Exclude<PwaBannerKind, 'hidden'>
}>()

const emit = defineEmits<{
	install: []
	openApp: []
}>()

const modalOpen = ref(true)
const showingIosInstructions = computed(() => props.kind === 'ios_instructions')

const titles = {
	install_prompt: 'Приложение всегда под рукой',
	installing: 'Установка',
	installed: 'Установлено',
	ios_instructions: 'Приложение всегда под рукой',
	open_app: 'Перейдите в приложение',
} satisfies Record<Exclude<PwaBannerKind, 'hidden'>, string>

const supportingText = {
	install_prompt: 'Установите приложение на смартфон, чтобы пользоваться всеми возможностями.',
	installing:
		'Подтвердите установку в системном окне. После завершения мы сообщим, что приложение готово.',
	installed:
		'Успешная установка! Закройте браузер и запустите приложение из списка приложений, чтобы пользоваться всеми возможностями.',
	ios_instructions:
		'На iPhone и iPad установка выполняется через меню браузера. Покажем короткую инструкцию.',
	open_app:
		'Попробуем открыть установленное приложение. Если вы останетесь в браузере, откройте приложение с иконки на смартфоне.',
} satisfies Record<Exclude<PwaBannerKind, 'hidden'>, string>

const title = computed(() =>
	showingIosInstructions.value ? 'Установка на iPhone и iPad' : titles[props.kind],
)

watch(
	() => props.kind,
	(kind) => {
		if (kind === 'installed') modalOpen.value = true
	},
)

function handleAction(): void {
	if (props.kind === 'install_prompt') {
		emit('install')
		return
	}
	emit('openApp')
}
</script>

<template>
	<Modal v-model:open="modalOpen" :title="title">
		<div v-if="showingIosInstructions">
			<div
				data-pwa-video-placeholder
				class="relative mb-5 aspect-video overflow-hidden rounded-2xl border border-[var(--app-border-strong)] bg-[var(--app-text)] shadow-[var(--app-shadow-raised)]"
			>
				<div class="absolute inset-0 bg-gradient-to-br from-[color-mix(in_srgb,var(--app-accent)_28%,var(--app-text))] via-[var(--app-text)] to-[color-mix(in_srgb,var(--app-muted)_48%,var(--app-text))]" />
				<div class="absolute inset-0 flex flex-col items-center justify-center gap-3 p-4 text-center text-[var(--app-surface)]">
					<span class="grid h-14 w-14 place-items-center rounded-full border border-[color-mix(in_srgb,var(--app-surface)_48%,transparent)] bg-[color-mix(in_srgb,var(--app-surface)_12%,transparent)] shadow-[var(--app-shadow-soft)]" aria-hidden="true">
						<svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M15 10.5 19.5 8v8L15 13.5m-9 4h7a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2Zm3-8 3 2-3 2v-4Z" />
						</svg>
					</span>
					<span>
						<span class="block text-sm font-semibold">Видео-инструкция</span>
						<span class="mt-1 block text-xs text-[color-mix(in_srgb,var(--app-surface)_72%,transparent)]">Будет доступна здесь</span>
					</span>
				</div>
			</div>

			<ol class="space-y-3 text-sm leading-5 text-[var(--app-muted)]">
				<li class="flex gap-3">
					<span class="club-number-badge" aria-hidden="true">1</span>
					<span>Нажмите кнопку «Поделиться» в панели Safari.</span>
				</li>
				<li class="flex gap-3">
					<span class="club-number-badge" aria-hidden="true">2</span>
					<span>Выберите «На экран Домой».</span>
				</li>
				<li class="flex gap-3">
					<span class="club-number-badge" aria-hidden="true">3</span>
					<span>Нажмите «Добавить», затем запускайте клуб с новой иконки.</span>
				</li>
			</ol>
			<Button class="mt-5 min-h-11" variant="secondary" block @click="modalOpen = false">
				Понятно
			</Button>
		</div>

		<section v-else class="flex items-start gap-3" aria-live="polite">
			<span
				class="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-[var(--app-border-strong)] bg-[var(--app-bg)]"
				:class="kind === 'installed' ? 'text-[var(--app-success)]' : 'text-[var(--app-accent-strong)]'"
				aria-hidden="true"
			>
				<svg v-if="kind === 'installed'" class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m5 12 4 4L19 6" />
				</svg>
				<svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v12m0 0 4-4m-4 4-4-4M5 19h14" />
				</svg>
			</span>
			<div class="min-w-0 flex-1">
				<p class="text-pretty text-sm leading-5 text-[var(--app-muted)]">{{ supportingText[kind] }}</p>
				<Button
					v-if="kind === 'install_prompt' || kind === 'open_app'"
					class="mt-4 min-h-11"
					size="md"
					block
					@click="handleAction"
				>
					{{ kind === 'open_app' ? 'ПЕРЕЙТИ В ПРИЛОЖЕНИЕ' : 'УСТАНОВИТЬ' }}
				</Button>
				<Button v-if="kind === 'installing'" class="mt-4 min-h-11" size="md" block loading>
					УСТАНАВЛИВАЕМ
				</Button>
			</div>
		</section>
	</Modal>
</template>
