<script setup lang="ts">
const props = withDefaults(
	defineProps<{
		open: boolean
		redirect: string
		variant?: 'join' | 'material' | 'section'
	}>(),
	{ variant: 'join' },
)

const emit = defineEmits<{
	'update:open': [value: boolean]
	login: []
	pay: []
}>()
function close() {
	emit('update:open', false)
}

const title = computed(() => {
	switch (props.variant) {
		case 'material':
			return 'Материал закрыт'
		case 'section':
			return 'Раздел доступен только для участников'
		default:
			return 'Вход в клуб'
	}
})
const text = computed(() =>
	props.variant === 'section'
		? 'Войдите в приложение или оформите доступ, чтобы открыть раздел.'
		: 'Войдите в приложение или оформите доступ, чтобы открыть материалы клуба.',
)
</script>

<template>
	<Transition name="access-modal">
		<div v-if="open" class="access-modal-layer" @click.self="close">
			<section class="access-modal-card" role="dialog" aria-modal="true" aria-labelledby="access-modal-title">
				<button type="button" class="access-modal-close" aria-label="Закрыть" @click="close">
					<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 6l12 12M18 6L6 18" />
					</svg>
				</button>
				<div class="access-modal-emblem" aria-hidden="true">
					<svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
					</svg>
				</div>
				<p class="access-modal-kicker">Club App · клуб</p>
				<h2 id="access-modal-title" class="access-modal-title">{{ title }}</h2>
				<p class="access-modal-text">{{ text }}</p>
				<div class="access-modal-actions">
					<button type="button" class="access-modal-button access-modal-button-primary" @click="emit('login')">
						Войти
					</button>
					<button type="button" class="access-modal-button access-modal-button-secondary" @click="emit('pay')">
						Оформить
					</button>
				</div>
			</section>
		</div>
	</Transition>
</template>

<style scoped>
.access-modal-layer {
	position: fixed;
	top: 0;
	bottom: 0;
	left: 50%;
	right: auto;
	z-index: 70;
	display: flex;
	width: var(--app-viewport-width);
	max-width: var(--app-viewport-max);
	align-items: center;
	justify-content: center;
	padding: 1.25rem;
	background: color-mix(in srgb, var(--app-text) 72%, transparent);
	backdrop-filter: blur(14px);
	transform: translateX(-50%);
}

.access-modal-card {
	position: relative;
	width: min(100%, 25rem);
	overflow: hidden;
	border: 1px solid var(--app-border-strong);
	border-radius: 1.25rem;
	background:
		radial-gradient(circle at 84% -8%, color-mix(in srgb, var(--app-accent) 16%, transparent), transparent 34%),
		linear-gradient(145deg, var(--app-surface), var(--app-bg));
	padding: 1.5rem;
	color: var(--app-text);
	box-shadow:
		inset 0 1px 0 rgb(255 255 255 / 0.96),
		var(--app-shadow-floating),
		0 0 2.25rem color-mix(in srgb, var(--app-accent) 12%, transparent);
}

.access-modal-close {
	position: absolute;
	top: 0.95rem;
	right: 0.95rem;
	display: flex;
	width: 2rem;
	height: 2rem;
	align-items: center;
	justify-content: center;
	border-radius: 999px;
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	color: var(--app-muted);
	transition: background 0.16s ease, color 0.16s ease;
}

.access-modal-close:active {
	background: color-mix(in srgb, var(--app-accent) 12%, var(--app-surface));
	color: var(--app-text);
}

.access-modal-emblem {
	display: flex;
	width: 3rem;
	height: 3rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-accent);
	border-radius: 999px;
	background: radial-gradient(circle, color-mix(in srgb, var(--app-accent) 16%, var(--app-surface)), var(--app-bg) 68%);
	color: var(--app-accent-strong);
	box-shadow: 0 0 1.35rem color-mix(in srgb, var(--app-accent) 22%, transparent), inset 0 0 1rem color-mix(in srgb, var(--app-accent) 9%, transparent);
}

.access-modal-kicker {
	margin: 1.15rem 2.4rem 0 0;
	color: var(--app-accent-strong);
	font-size: 0.63rem;
	font-weight: 650;
	letter-spacing: 0.17em;
}

.access-modal-title {
	margin: 0.42rem 2.2rem 0 0;
	color: var(--app-text-strong);
	font-size: 1.38rem;
	font-weight: 650;
	line-height: 1.1;
	letter-spacing: 0;
}


.access-modal-text {
	margin: 0.5rem 0 0;
	max-width: 20rem;
	color: var(--app-muted);
	font-size: 0.94rem;
	line-height: 1.45;
}

.access-modal-actions {
	display: grid;
	grid-template-columns: 1fr;
	gap: 0.7rem;
	margin-top: 1.15rem;
}

.access-modal-button {
	display: inline-flex;
	min-height: 3rem;
	align-items: center;
	justify-content: center;
	border-radius: 0.82rem;
	padding: 0.75rem 1rem;
	font-size: 0.94rem;
	font-weight: 650;
	line-height: 1;
	transition: transform 0.16s ease, opacity 0.16s ease;
}

.access-modal-button:active {
	transform: scale(0.98);
}

.access-modal-button:disabled {
	cursor: not-allowed;
	opacity: 0.55;
}

.access-modal-button-secondary {
	border: 1px solid var(--app-border-strong);
	background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface));
	color: var(--app-accent-strong);
}

.access-modal-button-primary {
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 78%, white), var(--app-accent));
	color: var(--app-button-fg);
	box-shadow: 0 0.8rem 1.75rem color-mix(in srgb, var(--app-accent) 20%, transparent);
}

.access-modal-enter-active,
.access-modal-leave-active {
	transition: opacity 0.18s ease;
}

.access-modal-enter-active .access-modal-card,
.access-modal-leave-active .access-modal-card {
	transition: transform 0.2s ease, opacity 0.2s ease;
}

.access-modal-enter-from,
.access-modal-leave-to {
	opacity: 0;
}

.access-modal-enter-from .access-modal-card,
.access-modal-leave-to .access-modal-card {
	opacity: 0;
	transform: translateY(0.35rem) scale(0.98);
}

@media (min-width: 768px) {
	.access-modal-layer {
		align-items: center;
		padding: 1.5rem;
	}
}
</style>
