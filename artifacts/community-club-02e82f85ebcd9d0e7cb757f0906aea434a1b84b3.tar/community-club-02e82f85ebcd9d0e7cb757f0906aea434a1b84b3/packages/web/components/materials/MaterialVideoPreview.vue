<script setup lang="ts">
import MediaVideoPlayer from '~/components/media/VideoPlayer.vue'

withDefaults(
	defineProps<{
		src: string
		poster?: string
		title: string
		downloadUrl?: string | null
		downloadable?: boolean
		initialTime?: number | null
	}>(),
	{ poster: undefined, downloadUrl: null, downloadable: false, initialTime: null },
)

const emit = defineEmits<{
	progress: [payload: VideoProgress]
}>()

type Player = { seekTo: (seconds: number) => void }
type VideoProgress = {
	positionSeconds: number
	durationSeconds: number | null
	completed: boolean
}
const player = ref<Player>()

function handleProgress(payload: VideoProgress) {
	emit('progress', payload)
}

defineExpose({ seekTo: (seconds: number) => player.value?.seekTo(seconds) })
</script>

<template>
	<section class="material-video-preview">
		<MediaVideoPlayer
			ref="player"
			:src="src"
			:poster="poster"
			:download-url="downloadUrl"
			:downloadable="downloadable"
			:initial-time="initialTime"
			@progress="handleProgress"
		/>
	</section>
</template>

<style scoped>
.material-video-preview {
	overflow: hidden;
	border: 1px solid color-mix(in srgb, var(--section-accent) 25%, var(--app-border));
	border-radius: 1.3rem;
	background: #050708;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.08), var(--app-shadow-soft);
}
</style>
