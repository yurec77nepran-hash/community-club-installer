<script setup lang="ts">
import type { GuestContentBlockAccess } from '@community-club/shared/types'
import { useSlots } from 'vue'

withDefaults(defineProps<{ access: GuestContentBlockAccess; variant?: 'default' | 'media' }>(), {
	variant: 'default',
})

const emit = defineEmits<(event: 'request-access') => void>()

const slots = useSlots()
const hasPreview = () => Boolean(slots.preview)
</script>

<template>
	<slot v-if="access === 'visible'" />
	<button
		v-else
		type="button"
		class="guest-content-block"
		:class="[`is-${access}`, `is-${variant}`]"
		aria-label="Открыть форму входа и оплаты"
		@click="emit('request-access')"
	>
		<div class="guest-content-block__inner" aria-hidden="true">
			<!-- Закрыто: показываем лёгкое превью, если передали, иначе реальный контент блока -->
			<slot v-if="hasPreview()" name="preview" />
			<slot v-else>
				<div class="guest-content-block__bars"><span /><span /><span /></div>
			</slot>
		</div>
		<div class="guest-content-block__glass" aria-hidden="true" />
		<div class="guest-content-block__overlay">
			<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2" stroke-width="1.7" /><path stroke-linecap="round" stroke-width="1.7" d="M8 10V7a4 4 0 0 1 8 0v3" /></svg>
			<span>Контент доступен участникам клуба</span>
		</div>
	</button>
</template>

<style scoped>
.guest-content-block {
	position: relative;
	display: block;
	width: 100%;
	min-height: 11rem;
	overflow: hidden;
	border: 1px solid color-mix(in srgb, var(--app-accent) 24%, var(--app-border));
	border-radius: 1.5rem;
	background: linear-gradient(145deg, var(--app-surface), var(--app-bg) 62%, var(--app-bg-deep));
	cursor: pointer;
}
.guest-content-block.is-media { background: linear-gradient(145deg, #24222a, #111218 62%, #0a0b0e); }
.guest-content-block:focus-visible { outline: 2px solid var(--app-accent); outline-offset: 3px; }
.guest-content-block__inner { min-height: 11rem; }
.guest-content-block.is-media .guest-content-block__inner { min-height: 0; }
.guest-content-block__bars { display: grid; width: 68%; gap: 0.7rem; padding: 4.5rem 0; margin: 0 auto; }
.guest-content-block__bars span { display: block; height: 0.85rem; border-radius: 999px; background: linear-gradient(90deg, color-mix(in srgb, var(--app-accent) 18%, var(--app-surface)), color-mix(in srgb, var(--app-border) 42%, var(--app-surface))); }
.guest-content-block.is-media .guest-content-block__bars span { background: linear-gradient(90deg, rgb(255 255 255 / 0.22), rgb(255 255 255 / 0.04)); }
.guest-content-block__bars span:nth-child(2) { width: 78%; }
.guest-content-block__bars span:nth-child(3) { width: 48%; }
/* Стекло поверх закрываемого блока: блюрит реальный контент по размеру блока */
.guest-content-block__glass {
	position: absolute;
	inset: 0;
	z-index: 1;
	background: color-mix(in srgb, var(--app-surface) 72%, transparent);
	backdrop-filter: blur(10px) saturate(1.35);
	-webkit-backdrop-filter: blur(10px) saturate(1.35);
}
.is-locked .guest-content-block__glass { background: color-mix(in srgb, var(--app-surface) 80%, transparent); }
.guest-content-block.is-media .guest-content-block__glass { background: rgb(13 15 20 / 0.52); }
.guest-content-block.is-media.is-locked .guest-content-block__glass { background: rgb(13 15 20 / 0.6); }
.guest-content-block__overlay {
	position: absolute;
	inset: 0;
	z-index: 2;
	display: grid;
	place-content: center;
	gap: 0.55rem;
	padding: 1rem;
	background: color-mix(in srgb, var(--app-surface) 18%, transparent);
	color: var(--app-text-strong);
	text-align: center;
	font-size: 0.78rem;
	font-weight: 600;
}
.guest-content-block.is-media .guest-content-block__overlay { background: rgb(4 5 7 / 0.14); color: rgb(247 241 232 / 0.9); text-shadow: 0 1px 6px rgb(0 0 0 / 0.5); }
.guest-content-block__overlay svg { width: 1.65rem; height: 1.65rem; margin: 0 auto; color: var(--app-accent); }
</style>
