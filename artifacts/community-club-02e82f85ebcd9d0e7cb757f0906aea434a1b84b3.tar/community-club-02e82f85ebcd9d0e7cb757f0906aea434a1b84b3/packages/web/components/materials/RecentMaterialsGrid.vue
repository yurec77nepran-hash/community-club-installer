<script setup lang="ts">
import type {
	CursorPaginatedResponse,
	GuestContentAccessLevel,
	GuestContentAccessSettings,
	HomeSnapshotMaterial,
} from '@community-club/shared/types'

type SectionIcon = 'case' | 'book' | 'wrench' | 'microphone' | 'star'

const props = defineProps<{
	type: string
	section: {
		id: string
		title: string
		subtitle: string
		motto: string
		image: string
		accent: string
		accentSoft: string
		icon: SectionIcon
	}
}>()

const api = useApi()
const auth = useAuthStore()
const subscription = useSubscriptionStore()
const items = ref<HomeSnapshotMaterial[]>([])
const subsections = ref<string[]>([])
const search = ref('')
const activeSubsection = ref('')
const loading = ref(true)
const error = ref('')
const guestMode = ref(true)
const guestAccessLevel = ref<GuestContentAccessLevel>('cards')
let searchTimeout: ReturnType<typeof setTimeout> | null = null

const endpoint = computed(() =>
	guestMode.value ? '/api/materials/public-preview' : '/api/materials',
)
const sectionStyle = computed(() => ({
	'--section-accent': props.section.accent,
	'--section-accent-soft': props.section.accentSoft,
}))
const itemCount = computed(() => items.value.length)
const countLabel = computed(() => {
	const count = itemCount.value
	const suffix = count % 10 === 1 && count % 100 !== 11 ? 'материал' : 'материалов'
	return `${count} ${suffix}`
})

function getDescription(item: HomeSnapshotMaterial) {
	return (
		item.shortDescription ||
		item.fullDescription ||
		'Откройте материал для участников клуба.'
	)
		.replace(/\s+/g, ' ')
		.trim()
}

function requestMaterialAccess(event: MouseEvent, item: HomeSnapshotMaterial) {
	if (item.accessible !== false || guestAccessLevel.value === 'preview') return
	event.preventDefault()
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: { redirect: `/app/content/${item.type}/${item.id}`, intent: 'login' },
		}),
	)
}

function requestSectionAccess() {
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: {
				redirect: `/app/content/${encodeURIComponent(props.type)}`,
				intent: 'login',
			},
		}),
	)
}

async function resolveGuestMode() {
	if (!auth.user) await auth.restoreSession()
	if (!auth.user) {
		guestMode.value = true
		return
	}
	if (auth.isAdmin) {
		guestMode.value = false
		return
	}
	subscription.hydrateSnapshot()
	if (!subscription.loadedAt) await subscription.fetchSubscription()
	guestMode.value = !subscription.hasActiveSubscription
}

async function loadGuestAccessSettings() {
	if (!guestMode.value) return
	const response = await api.get<GuestContentAccessSettings>(
		'/api/site-settings/guest-content-access',
		{
			authRedirect: false,
		},
	)
	if (response.success) guestAccessLevel.value = response.data.level
}

async function loadSubsections() {
	const response = await api.get<string[]>(
		`${endpoint.value}/subsections?type=${encodeURIComponent(props.type)}`,
		{ authRedirect: false },
	)
	if (response.success) subsections.value = response.data
}

async function loadItems() {
	loading.value = true
	error.value = ''
	const query = new URLSearchParams({ type: props.type, limit: '24' })
	if (search.value.trim()) query.set('search', search.value.trim())
	if (activeSubsection.value) query.set('subsection', activeSubsection.value)

	const response = await api.get<CursorPaginatedResponse<HomeSnapshotMaterial>>(
		`${endpoint.value}?${query.toString()}`,
		{ authRedirect: false, cache: 'no-store', skipCache: true },
	)
	if (response.success) {
		items.value = response.data.items
	} else {
		error.value = response.error.message || 'Не удалось загрузить материалы.'
	}
	loading.value = false
}

function selectSubsection(value: string) {
	activeSubsection.value = value
	void loadItems()
}

// «Уроки»: пока нет выбранного курса — показываем плашки курсов (подразделы), внутри — уроки
const showCourseGroups = computed(
	() =>
		props.type === 'courses' &&
		!activeSubsection.value &&
		!search.value &&
		subsections.value.length > 0 &&
		items.value.length > 0,
)
const courseGroups = computed(() =>
	subsections.value.map((sub) => ({
		subsection: sub,
		count: items.value.filter((item) => item.subsection === sub).length,
	})),
)

function onSearch() {
	if (searchTimeout) clearTimeout(searchTimeout)
	searchTimeout = setTimeout(() => void loadItems(), 250)
}

function pluralLessons(count: number) {
	const abs = count % 100
	const last = count % 10
	if (last === 1 && abs !== 11) return `${count} урок`
	if (last >= 2 && last <= 4 && (abs < 12 || abs > 14)) return `${count} урока`
	return `${count} уроков`
}

onMounted(async () => {
	await resolveGuestMode()
	await loadGuestAccessSettings()
	if (guestMode.value && guestAccessLevel.value === 'sections') {
		loading.value = false
		return
	}
	await Promise.all([loadSubsections(), loadItems()])
})

onUnmounted(() => {
	if (searchTimeout) clearTimeout(searchTimeout)
})
</script>

<template>
	<section class="section-catalogue" :style="sectionStyle">
		<div class="section-hero">
			<img :src="section.image" :alt="section.title" class="section-hero__image" />
			<div class="section-hero__shade" />
			<div class="section-hero__content">
				<div class="section-icon" aria-hidden="true">
					<svg v-if="section.icon === 'case'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M8 7V5.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V7m-12 3h16v8.5A1.5 1.5 0 0 1 18.5 20h-13A1.5 1.5 0 0 1 4 18.5V10Zm0 0V8.5A1.5 1.5 0 0 1 5.5 7h13A1.5 1.5 0 0 1 20 8.5V10m-9 3h2" /></svg>
					<svg v-else-if="section.icon === 'book'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M12 6v14m0-14C10.4 5 8.9 4.5 7.2 4.5S4 5 3 6v13.5c1-.7 2.5-1.1 4.2-1.1s3.2.5 4.8 1.6c1.6-1.1 3.1-1.6 4.8-1.6S20 18.8 21 19.5V6c-1-.7-2.5-1.5-4.2-1.5S13.6 5 12 6Z" /></svg>
					<svg v-else-if="section.icon === 'wrench'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="m14.5 6.2 3.3 3.3 2.4-2.4a5.6 5.6 0 0 1-7.1 7.1l-7.6 7.6a1.9 1.9 0 1 1-2.7-2.7l7.6-7.6a5.6 5.6 0 0 1 7.1-7.1l-2.4 2.4Z" /></svg>
					<svg v-else-if="section.icon === 'microphone'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect width="6.5" height="11" x="8.75" y="3" rx="3.25" stroke-width="1.75" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7" /></svg>
					<svg v-else fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" /></svg>
				</div>
				<p class="section-hero__eyebrow">{{ section.motto }}</p>
				<h1>{{ section.title }}</h1>
				<p class="section-hero__subtitle">{{ section.subtitle }}</p>
				<p class="section-hero__count">{{ countLabel }}</p>
			</div>
		</div>

		<label class="section-search">
			<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m21 21-4.35-4.35m1.35-5.65a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" /></svg>
			<input v-model="search" type="search" :placeholder="`Найти в разделе «${section.title}»`" @input="onSearch" />
		</label>

		<div class="section-filters" role="tablist" :aria-label="`Подразделы: ${section.title}`">
			<button type="button" :class="{ 'is-active': !activeSubsection }" @click="selectSubsection('')">Все</button>
			<button v-for="subsection in subsections" :key="subsection" type="button" :class="{ 'is-active': activeSubsection === subsection }" @click="selectSubsection(subsection)">{{ subsection }}</button>
		</div>

		<template v-if="showCourseGroups">
			<div class="section-courses">
				<button
					v-for="group in courseGroups"
					:key="group.subsection"
					type="button"
					class="section-course"
					@click="selectSubsection(group.subsection)"
				>
					<div class="section-icon section-course__icon" aria-hidden="true">
						<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M12 6v14m0-14C10.4 5 8.9 4.5 7.2 4.5S4 5 3 6v13.5c1-.7 2.5-1.1 4.2-1.1s3.2.5 4.8 1.6c1.6-1.1 3.1-1.6 4.8-1.6S20 18.8 21 19.5V6c-1-.7-2.5-1.5-4.2-1.5S13.6 5 12 6Z" /></svg>
					</div>
					<div class="section-course__copy">
						<h2>{{ group.subsection }}</h2>
						<p>Курс клуба</p>
						<span>{{ pluralLessons(group.count) }}</span>
					</div>
					<svg class="section-course__arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M5 12h14m-6-6 6 6-6 6" /></svg>
				</button>
			</div>
		</template>
		<div v-else-if="guestMode && guestAccessLevel === 'sections'" class="section-guest-gate">
			<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2" stroke-width="1.7" /><path stroke-linecap="round" stroke-width="1.7" d="M8 10V7a4 4 0 0 1 8 0v3" /></svg>
			<div><h2>Раздел доступен участникам клуба</h2><p>Войдите или оформите доступ, чтобы открыть материалы.</p></div>
			<button type="button" @click="requestSectionAccess">Открыть доступ</button>
		</div>
		<p v-else-if="loading" class="section-state">Загружаем материалы…</p>
		<p v-else-if="error" class="section-state is-error">{{ error }}</p>
		<p v-else-if="items.length === 0" class="section-state">В этом подразделе пока нет материалов.</p>
		<div v-else class="section-materials">
			<NuxtLink v-for="item in items" :key="item.id" :to="`/app/content/${item.type}/${item.id}`" class="section-material" @click="requestMaterialAccess($event, item)">
				<div class="section-icon section-material__icon" aria-hidden="true">
					<svg v-if="section.icon === 'case'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M8 7V5.5A1.5 1.5 0 0 1 9.5 4h5A1.5 1.5 0 0 1 16 5.5V7m-12 3h16v8.5A1.5 1.5 0 0 1 18.5 20h-13A1.5 1.5 0 0 1 4 18.5V10Zm0 0V8.5A1.5 1.5 0 0 1 5.5 7h13A1.5 1.5 0 0 1 20 8.5V10m-9 3h2" /></svg>
					<svg v-else-if="section.icon === 'book'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M12 6v14m0-14C10.4 5 8.9 4.5 7.2 4.5S4 5 3 6v13.5c1-.7 2.5-1.1 4.2-1.1s3.2.5 4.8 1.6c1.6-1.1 3.1-1.6 4.8-1.6S20 18.8 21 19.5V6c-1-.7-2.5-1.5-4.2-1.5S13.6 5 12 6Z" /></svg>
					<svg v-else-if="section.icon === 'wrench'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="m14.5 6.2 3.3 3.3 2.4-2.4a5.6 5.6 0 0 1-7.1 7.1l-7.6 7.6a1.9 1.9 0 1 1-2.7-2.7l7.6-7.6a5.6 5.6 0 0 1 7.1-7.1l-2.4 2.4Z" /></svg>
					<svg v-else-if="section.icon === 'microphone'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect width="6.5" height="11" x="8.75" y="3" rx="3.25" stroke-width="1.75" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7" /></svg>
					<svg v-else fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" /></svg>
				</div>
				<div class="section-material__copy"><h2>{{ item.title }}</h2><p>{{ getDescription(item) }}</p><span>{{ item.subsection || section.title }}</span></div>
				<svg class="section-material__arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M5 12h14m-6-6 6 6-6 6" /></svg>
			</NuxtLink>
		</div>
	</section>
</template>

<style scoped>
.section-catalogue { --section-accent: var(--app-accent-violet); --section-accent-soft: color-mix(in srgb, var(--app-accent-violet) 14%, transparent); max-width: 42rem; margin: 0 auto; padding: 0.35rem 0.75rem 1.5rem; color: var(--app-text); }
.section-hero { position: relative; min-height: 13.5rem; overflow: hidden; border: 1px solid color-mix(in srgb, var(--section-accent) 42%, var(--app-border)); border-radius: 1.25rem; background: var(--app-surface); box-shadow: var(--app-shadow-raised), inset 0 0 3rem var(--section-accent-soft); }
.section-hero__image { position: absolute; top: 0; right: 0; width: 70%; height: 100%; object-fit: cover; object-position: right center; mask-image: linear-gradient(90deg, transparent, #000 32%); }
.section-hero__shade { position: absolute; inset: 0; background: linear-gradient(90deg, #0a0a0d 0 36%, rgb(10 10 13 / 0.7) 54%, transparent 100%); }
.section-hero__content { position: relative; z-index: 1; display: flex; min-height: 13.5rem; max-width: 62%; flex-direction: column; align-items: flex-start; justify-content: center; padding: 1.15rem; color: var(--app-surface); }
.section-icon { display: grid; width: 2.9rem; height: 2.9rem; place-items: center; border: 1px solid color-mix(in srgb, var(--section-accent) 58%, var(--app-border)); border-radius: 50%; background: radial-gradient(circle at 40% 30%, rgb(255 255 255 / 0.96), var(--section-accent-soft) 72%); color: var(--section-accent); box-shadow: 0 0 1.25rem var(--section-accent-soft), inset 0 1px rgb(255 255 255 / 0.96); }
.section-icon svg { width: 52%; height: 52%; filter: drop-shadow(0 0 0.35rem var(--section-accent)); }
.section-hero__eyebrow, .section-hero__count { margin: 0.65rem 0 0; color: color-mix(in srgb, var(--app-surface) 86%, transparent); font-size: 0.7rem; font-weight: 650; letter-spacing: 0.05em; text-transform: uppercase; }
.section-hero h1 { margin: 0.45rem 0 0; color: var(--app-surface); font-size: clamp(1.65rem, 8vw, 2.5rem); font-weight: 650; line-height: 0.98; letter-spacing: -0.04em; text-transform: uppercase; }
.section-hero__subtitle { margin: 0.48rem 0 0; color: color-mix(in srgb, var(--app-surface) 78%, transparent); font-size: 0.8rem; line-height: 1.35; }
.section-search { display: flex; align-items: center; gap: 0.65rem; margin-top: 0.9rem; padding: 0 0.9rem; border: 1px solid var(--app-border); border-radius: 0.9rem; background: var(--app-surface); color: var(--app-muted-soft); box-shadow: inset 0 1px 2px rgb(31 31 31 / 0.04); }
.section-search svg { width: 1.1rem; height: 1.1rem; flex: 0 0 auto; }
.section-search input { width: 100%; border: 0; outline: 0; background: transparent; padding: 0.78rem 0; color: var(--app-text); font-size: 0.84rem; }
.section-search input::placeholder { color: var(--app-muted-soft); }
.section-filters { display: flex; gap: 0.48rem; overflow-x: auto; margin: 0.9rem 0 1rem; padding-bottom: 0.1rem; scrollbar-width: none; }
.section-filters::-webkit-scrollbar { display: none; }
.section-filters button { flex: 0 0 auto; border: 1px solid var(--app-border); border-radius: 0.7rem; background: var(--app-surface); padding: 0.56rem 0.8rem; color: var(--app-muted); font-size: 0.68rem; font-weight: 600; text-transform: uppercase; transition: border-color 0.18s ease, color 0.18s ease, background 0.18s ease; }
.section-filters button.is-active { border-color: color-mix(in srgb, var(--section-accent) 76%, var(--app-border)); background: color-mix(in srgb, var(--section-accent) 10%, var(--app-surface)); color: var(--app-text); }
.section-materials { display: grid; gap: 0.65rem; }
.section-material { display: grid; grid-template-columns: 3.4rem minmax(0, 1fr) 1.35rem; gap: 0.78rem; align-items: center; min-height: 5.6rem; padding: 0.72rem; border: 1px solid color-mix(in srgb, var(--section-accent) 20%, var(--app-border)); border-radius: 1rem; background: linear-gradient(105deg, var(--app-surface), var(--app-bg)); color: inherit; text-decoration: none; box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft); }
.section-material:active { transform: scale(0.985); }
.section-material__icon { width: 3.4rem; height: 3.4rem; }
.section-material__copy { min-width: 0; }
.section-material__copy h2 { overflow: hidden; margin: 0; color: var(--app-text-strong); font-size: 0.88rem; font-weight: 620; line-height: 1.2; text-overflow: ellipsis; white-space: nowrap; }
.section-material__copy p { display: -webkit-box; overflow: hidden; margin: 0.24rem 0 0; color: var(--app-muted); font-size: 0.7rem; line-height: 1.35; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
.section-material__copy span { display: inline-flex; margin-top: 0.4rem; border: 1px solid color-mix(in srgb, var(--section-accent) 54%, transparent); border-radius: 0.28rem; padding: 0.14rem 0.35rem; color: var(--section-accent); font-size: 0.56rem; font-weight: 650; letter-spacing: 0.04em; text-transform: uppercase; }
.section-material__arrow { width: 1.25rem; height: 1.25rem; color: var(--section-accent); }
.section-courses { display: grid; gap: 0.65rem; }
.section-course { display: grid; grid-template-columns: 3.4rem minmax(0, 1fr) 1.35rem; gap: 0.78rem; align-items: center; width: 100%; min-height: 5.6rem; padding: 0.72rem; border: 1px solid color-mix(in srgb, var(--section-accent) 20%, var(--app-border)); border-radius: 1rem; background: linear-gradient(105deg, var(--app-surface), var(--app-bg)); color: inherit; text-align: left; box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft); cursor: pointer; }
.section-course:active { transform: scale(0.985); }
.section-course__icon { width: 3.4rem; height: 3.4rem; }
.section-course__copy { min-width: 0; }
.section-course__copy h2 { overflow: hidden; margin: 0; color: var(--app-text-strong); font-size: 0.88rem; font-weight: 620; line-height: 1.2; text-overflow: ellipsis; white-space: nowrap; }
.section-course__copy p { margin: 0.24rem 0 0; color: var(--app-muted); font-size: 0.7rem; line-height: 1.35; }
.section-course__copy span { display: inline-flex; margin-top: 0.4rem; border: 1px solid color-mix(in srgb, var(--section-accent) 54%, transparent); border-radius: 0.28rem; padding: 0.14rem 0.35rem; color: var(--section-accent); font-size: 0.56rem; font-weight: 650; letter-spacing: 0.04em; text-transform: uppercase; }
.section-course__arrow { width: 1.25rem; height: 1.25rem; color: var(--section-accent); }
.section-state { margin: 2.5rem 0; color: var(--app-muted-soft); text-align: center; font-size: 0.82rem; }.section-state.is-error { color: var(--app-danger); }
.section-guest-gate { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 0.85rem; align-items: center; margin-top: 1rem; padding: 1.1rem; border: 1px solid color-mix(in srgb, var(--section-accent) 40%, var(--app-border)); border-radius: 1rem; background: linear-gradient(135deg, var(--section-accent-soft), var(--app-surface)); box-shadow: var(--app-shadow-soft); }.section-guest-gate svg { width: 2rem; height: 2rem; color: var(--section-accent); }.section-guest-gate h2 { margin: 0; font-size: 0.88rem; }.section-guest-gate p { margin: 0.3rem 0 0; color: var(--app-muted); font-size: 0.75rem; line-height: 1.35; }.section-guest-gate button { grid-column: 1 / -1; border: 1px solid color-mix(in srgb, var(--section-accent) 70%, var(--app-border)); border-radius: 0.7rem; background: var(--section-accent-soft); padding: 0.65rem 0.85rem; color: var(--app-text); font-size: 0.72rem; font-weight: 700; }
@media (min-width: 640px) { .section-catalogue { padding-right: 1rem; padding-left: 1rem; }.section-hero { min-height: 16rem; }.section-hero__content { min-height: 16rem; padding: 1.5rem; }.section-material { min-height: 6.15rem; padding: 0.9rem; } }
</style>
