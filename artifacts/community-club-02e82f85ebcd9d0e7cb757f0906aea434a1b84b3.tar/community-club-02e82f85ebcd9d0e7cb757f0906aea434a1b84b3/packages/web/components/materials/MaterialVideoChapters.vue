<script setup lang="ts">
import { formatVideoChapterTime } from '@community-club/shared'
import type { MaterialVideoChapters } from '@community-club/shared/types'

const props = defineProps<{
	chapters: MaterialVideoChapters
}>()

const emit = defineEmits<{
	seek: [seconds: number]
}>()

const open = ref(true)
const hasItems = computed(() => props.chapters.items.length > 0)

function toggle() {
	if (props.chapters.collapsible) open.value = !open.value
}
</script>

<template>
	<section v-if="hasItems" class="video-chapters">
		<button
			v-if="chapters.collapsible"
			type="button"
			class="video-chapters__heading video-chapters__toggle"
			:aria-expanded="open"
			@click="toggle"
		>
			<span>Таймкоды</span>
			<svg class="video-chapters__chevron" :class="{ 'is-open': open }" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m6 9 6 6 6-6" /></svg>
		</button>
		<p v-else class="video-chapters__heading">Таймкоды</p>

		<div v-show="!chapters.collapsible || open" class="video-chapters__list">
			<button v-for="chapter in chapters.items" :key="`${chapter.time}-${chapter.description}`" type="button" class="video-chapters__item" @click="emit('seek', chapter.time)">
				<span class="video-chapters__marker" aria-hidden="true" />
				<span class="video-chapters__time">{{ formatVideoChapterTime(chapter.time) }}</span>
				<span class="video-chapters__copy"><strong>{{ chapter.description }}</strong><small>Перейти к этому фрагменту</small></span>
				<svg class="video-chapters__arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M5 12h14m-6-6 6 6-6 6" /></svg>
			</button>
		</div>
	</section>
</template>

<style scoped>
.video-chapters { overflow: hidden; border: 1px solid color-mix(in srgb, var(--section-accent, var(--app-accent)) 26%, var(--app-border)); border-radius: 1.3rem; background: linear-gradient(180deg, var(--app-surface), var(--app-bg)); box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft); }
.video-chapters__heading { display: flex; width: 100%; align-items: center; justify-content: space-between; margin: 0; padding: 0.9rem 1rem 0.68rem; color: var(--app-text-strong); font-size: 0.67rem; font-weight: 750; letter-spacing: 0.1em; text-align: left; text-transform: uppercase; }
.video-chapters__toggle { cursor: pointer; transition: background 0.18s ease; }
.video-chapters__toggle:hover { background: var(--app-bg); }
.video-chapters__chevron { width: 1.1rem; height: 1.1rem; transition: transform 0.18s ease; }
.video-chapters__chevron.is-open { transform: rotate(180deg); }
.video-chapters__list { position: relative; padding: 0 0.55rem 0.65rem 1rem; }
.video-chapters__list::before { position: absolute; top: 0.25rem; bottom: 1rem; left: 1.35rem; width: 1px; content: ''; background: color-mix(in srgb, var(--section-accent, var(--app-accent)) 54%, transparent); }
.video-chapters__item { position: relative; display: grid; grid-template-columns: 0.45rem auto minmax(0, 1fr) auto; width: 100%; gap: 0.64rem; align-items: center; border-radius: 0.78rem; padding: 0.66rem 0.42rem 0.66rem 0; color: var(--app-text); text-align: left; transition: background 0.18s ease, transform 0.18s ease; }
.video-chapters__item:hover { background: var(--app-bg); }
.video-chapters__item:active { transform: scale(0.985); }
.video-chapters__marker { z-index: 1; width: 0.44rem; height: 0.44rem; border: 1px solid var(--section-accent, var(--app-accent)); border-radius: 50%; background: var(--app-surface); box-shadow: 0 0 0.55rem var(--section-accent-soft, color-mix(in srgb, var(--app-accent) 22%, transparent)); }
.video-chapters__time { border: 1px solid color-mix(in srgb, var(--section-accent, var(--app-accent)) 55%, transparent); border-radius: 0.38rem; padding: 0.22rem 0.34rem; color: var(--app-text-strong); font-size: 0.66rem; font-weight: 750; font-variant-numeric: tabular-nums; }
.video-chapters__copy { display: grid; min-width: 0; gap: 0.16rem; }
.video-chapters__copy strong { overflow: hidden; color: var(--app-text-strong); font-size: 0.79rem; font-weight: 650; line-height: 1.2; text-overflow: ellipsis; white-space: nowrap; }
.video-chapters__copy small { overflow: hidden; color: var(--app-muted-soft); font-size: 0.64rem; line-height: 1.15; text-overflow: ellipsis; white-space: nowrap; }
.video-chapters__arrow { width: 1rem; height: 1rem; color: var(--section-accent, var(--app-accent-strong)); }
</style>
