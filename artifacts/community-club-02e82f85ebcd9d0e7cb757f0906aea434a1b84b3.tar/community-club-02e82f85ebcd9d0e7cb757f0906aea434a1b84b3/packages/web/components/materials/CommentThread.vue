<script setup lang="ts">
import type { MaterialCommentItem } from '@community-club/shared/types'
import UiAvatar from '~/components/ui/Avatar.vue'

defineOptions({ name: 'MaterialCommentThread' })

const props = defineProps<{
	comment: MaterialCommentItem
	currentUserId?: string | null
	depth?: number
}>()

const emit = defineEmits<{
	reply: [comment: MaterialCommentItem]
	react: [commentId: number, emoji: string]
	edit: [comment: MaterialCommentItem]
	remove: [comment: MaterialCommentItem]
}>()

const quickEmojis = ['👍', '❤️', '🔥', '👏']
const showContextMenu = ref(false)
const menuPos = ref({ x: 0, y: 0 })
let longPressTimer: ReturnType<typeof setTimeout> | null = null
let menuOpenedAt = 0

const depth = computed(() => props.depth ?? 0)
const groupedReactions = computed(() => {
	const map = new Map<string, { count: number; reactedByMe: boolean }>()
	for (const reaction of props.comment.reactions ?? []) {
		const current = map.get(reaction.emoji) ?? { count: 0, reactedByMe: false }
		current.count += 1
		if (reaction.userAuthUuid === props.currentUserId) {
			current.reactedByMe = true
		}
		map.set(reaction.emoji, current)
	}

	return Array.from(map.entries()).map(([emoji, value]) => ({
		emoji,
		count: value.count,
		reactedByMe: value.reactedByMe,
	}))
})

const authorName = computed(() => {
	return (
		props.comment.author.fullName ||
		props.comment.author.username ||
		`Участник ${props.comment.author.authUuid.slice(0, 6)}`
	)
})

const isOwnComment = computed(
	() => Boolean(props.currentUserId) && props.comment.author.authUuid === props.currentUserId,
)

const isDeleted = computed(() => props.comment.isDeleted)

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'short',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function openMenu(x: number, y: number) {
	const menuW = 220
	const menuH = 170
	const vw = window.innerWidth
	const vh = window.innerHeight
	menuPos.value = {
		x: Math.min(Math.max(8, x), vw - menuW - 8),
		y: Math.min(Math.max(8, y), vh - menuH - 8),
	}
	showContextMenu.value = true
	menuOpenedAt = Date.now()
}

function closeMenu() {
	if (Date.now() - menuOpenedAt < 250) return
	showContextMenu.value = false
}

function cancelLongPress() {
	if (longPressTimer) {
		clearTimeout(longPressTimer)
		longPressTimer = null
	}
}

function onContextMenu(event: MouseEvent) {
	event.preventDefault()
	openMenu(event.clientX, event.clientY)
}

function onTouchStart(event: TouchEvent) {
	const touch = event.touches[0]
	cancelLongPress()
	longPressTimer = setTimeout(() => {
		if (navigator.vibrate) navigator.vibrate(30)
		openMenu(touch.clientX, touch.clientY)
	}, 400)
}

function onTouchMove() {
	cancelLongPress()
}

function onTouchEnd() {
	cancelLongPress()
}

function onReply() {
	emit('reply', props.comment)
	closeMenu()
}

function onEdit() {
	emit('edit', props.comment)
	closeMenu()
}

function onRemove() {
	emit('remove', props.comment)
	closeMenu()
}

function onReact(emoji: string) {
	emit('react', props.comment.id, emoji)
	closeMenu()
}
</script>

<template>
	<div class="space-y-3">
		<div
			class="border-[var(--app-border)]"
			:class="depth > 0 ? 'ml-5 border-l pl-4' : ''"
			@contextmenu="onContextMenu"
			@touchstart.passive="onTouchStart"
			@touchmove.passive="onTouchMove"
			@touchend.passive="onTouchEnd"
		>
			<div class="rounded-[24px] border border-[var(--app-border)] bg-[var(--app-surface)] px-4 py-4 shadow-[var(--app-shadow-soft)]">
				<div class="flex items-start gap-3">
				<UiAvatar
					:src="comment.author.avatarUrl"
					:name="authorName"
					size="sm"
				/>
				<div class="min-w-0 flex-1">
					<div class="flex flex-wrap items-center gap-x-2 gap-y-1">
						<p class="text-sm font-semibold text-[var(--app-text-strong)]">{{ authorName }}</p>
						<span class="rounded-full border border-[var(--app-border)] bg-[var(--app-bg)] px-2 py-0.5 text-[11px] text-[var(--app-muted-soft)]">
							{{ formatDate(comment.createdAt) }}
						</span>
					</div>
					<p
						v-if="!isDeleted"
						class="mt-2.5 whitespace-pre-wrap text-sm leading-6 text-[var(--app-text)] [overflow-wrap:anywhere] break-words"
					>
						{{ comment.content }}
					</p>
					<p v-else class="mt-2 text-sm italic text-[var(--app-muted-soft)]">
						Комментарий удалён
					</p>

					<div class="mt-3.5 flex flex-wrap items-center gap-2">
						<button
							v-for="reaction in groupedReactions"
							:key="`${comment.id}-${reaction.emoji}`"
							type="button"
							class="rounded-full border border-[var(--app-border)] px-2.5 py-1 text-[11px] transition"
							:class="
								reaction.reactedByMe
									? 'border-[color-mix(in_srgb,var(--app-accent)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_12%,var(--app-surface))] text-[var(--app-accent-strong)]'
									: 'bg-[var(--app-bg)] text-[var(--app-muted)]'
							"
							@click="emit('react', comment.id, reaction.emoji)"
						>
							{{ reaction.emoji }} {{ reaction.count }}
						</button>
					</div>
					<div v-if="!isDeleted" class="mt-3 flex items-center gap-2">
						<button
							class="rounded-full px-3 py-1.5 text-xs font-medium text-[var(--app-muted)] transition hover:bg-[var(--app-bg)] hover:text-[var(--app-text)]"
							@click="emit('reply', comment)"
						>
							Ответить
						</button>
						<button
							v-if="isOwnComment"
							class="rounded-full px-3 py-1.5 text-xs font-medium text-[var(--app-muted-soft)] transition hover:bg-[var(--app-bg)] hover:text-[var(--app-text)]"
							@click="emit('edit', comment)"
						>
							Изменить
						</button>
					</div>
				</div>
				</div>
			</div>
		</div>

		<div v-if="comment.replies.length" class="space-y-3">
			<MaterialCommentThread
				v-for="reply in comment.replies"
				:key="reply.id"
				:comment="reply"
				:current-user-id="currentUserId"
				:depth="depth + 1"
				@reply="emit('reply', $event)"
				@edit="emit('edit', $event)"
				@remove="emit('remove', $event)"
				@react="(commentId, emoji) => emit('react', commentId, emoji)"
			/>
		</div>
	</div>

	<Teleport to="body">
		<div
			v-if="showContextMenu"
			class="fixed inset-0 z-[90]"
			@click.self="closeMenu"
			@contextmenu.prevent="closeMenu"
		>
			<div
				class="fixed z-[91] w-[220px] context-menu-appear"
				:style="{ left: `${menuPos.x}px`, top: `${menuPos.y}px` }"
				@click.stop
			>
				<div
					v-if="!isDeleted"
					class="mb-1.5 flex gap-0.5 overflow-x-auto rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] px-1.5 py-1.5 shadow-[var(--app-shadow-floating)] backdrop-blur-2xl scrollbar-hide"
				>
					<button
						v-for="emoji in quickEmojis"
						:key="emoji"
						class="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl text-[20px] transition-transform hover:bg-[var(--app-bg)] active:scale-110"
						@click="onReact(emoji)"
					>
						{{ emoji }}
					</button>
				</div>
				<div class="overflow-hidden rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] shadow-[var(--app-shadow-floating)] backdrop-blur-2xl">
					<button
						v-if="!isDeleted"
						class="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm text-[var(--app-text)] transition hover:bg-[var(--app-bg)]"
						@click="onReply"
					>
						Ответить
					</button>
					<button
						v-if="isOwnComment && !isDeleted"
						class="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm text-[var(--app-text)] transition hover:bg-[var(--app-bg)]"
						@click="onEdit"
					>
						Редактировать
					</button>
					<button
						v-if="isOwnComment && !isDeleted"
						class="flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm text-[var(--app-danger)] transition hover:bg-[var(--app-bg)]"
						@click="onRemove"
					>
						Удалить
					</button>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<style scoped>
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
.context-menu-appear { animation: ctx-pop 0.15s ease-out; }
@keyframes ctx-pop {
	from { opacity: 0; transform: scale(0.92); }
	to { opacity: 1; transform: scale(1); }
}
</style>
