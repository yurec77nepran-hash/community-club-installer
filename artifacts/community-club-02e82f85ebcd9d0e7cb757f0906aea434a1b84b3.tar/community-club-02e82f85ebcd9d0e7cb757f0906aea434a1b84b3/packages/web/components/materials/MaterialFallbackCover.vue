<script setup lang="ts">
withDefaults(
	defineProps<{
		type?: string
		size?: 'card' | 'hero'
	}>(),
	{ type: 'other', size: 'card' },
)
</script>

<template>
	<div class="material-cover" :class="[`material-cover--${type}`, `material-cover--${size}`]" aria-hidden="true">
		<div class="material-cover__grid" />
		<div class="material-cover__halo" />
		<div class="material-cover__artifact"><i /><b /><em /></div>
		<div class="material-cover__beam" />
	</div>
</template>

<style scoped>
.material-cover { position: relative; height: 100%; overflow: hidden; background: linear-gradient(145deg, var(--app-surface), color-mix(in srgb, var(--cover-accent) 8%, var(--app-bg-deep))); isolation: isolate; }
.material-cover__grid { position: absolute; inset: 0; opacity: 0.42; background-image: linear-gradient(color-mix(in srgb, var(--cover-accent) 10%, transparent) 1px, transparent 1px), linear-gradient(90deg, color-mix(in srgb, var(--cover-accent) 10%, transparent) 1px, transparent 1px); background-size: 18px 18px; mask-image: linear-gradient(90deg, transparent, black 48%, black); }
.material-cover__halo { position: absolute; right: -15%; top: -30%; width: 82%; aspect-ratio: 1; border-radius: 50%; background: radial-gradient(circle, var(--cover-light) 0 4%, var(--cover-glow) 24%, transparent 67%); filter: blur(2px); }
.material-cover__artifact { position: absolute; right: 8%; bottom: -17%; width: 48%; aspect-ratio: 1; border: 1px solid var(--cover-line); border-radius: 28% 38% 30% 42%; background: linear-gradient(135deg, var(--app-surface), var(--cover-edge) 55%, var(--app-bg-deep)); box-shadow: inset 0 0 0 9px rgb(255 255 255 / 0.42), inset 0 0 0 10px var(--cover-line), 0 0 2.4rem var(--cover-glow), var(--app-shadow-raised); transform: rotate(-13deg); }
.material-cover__artifact::before, .material-cover__artifact::after { position: absolute; content: ''; border: 1px solid var(--cover-line); border-radius: 50%; }
.material-cover__artifact::before { inset: 21%; background: radial-gradient(circle, var(--cover-light) 0 7%, transparent 8% 24%, var(--cover-glow) 25% 27%, transparent 28%); }
.material-cover__artifact::after { inset: 36%; border-radius: 24%; background: var(--cover-edge); box-shadow: 0 0 1.2rem var(--cover-glow); }
.material-cover__artifact i, .material-cover__artifact b, .material-cover__artifact em { position: absolute; display: block; background: var(--cover-line); box-shadow: 0 0 0.65rem var(--cover-glow); }
.material-cover__artifact i { top: 9%; left: 45%; width: 9%; height: 22%; border-radius: 99px; }
.material-cover__artifact b { right: 10%; bottom: 43%; width: 22%; height: 8%; border-radius: 99px; }
.material-cover__artifact em { bottom: 11%; left: 19%; width: 10%; height: 19%; border-radius: 99px; }
.material-cover__beam { position: absolute; right: -15%; bottom: 4%; width: 85%; height: 1px; background: linear-gradient(90deg, transparent, var(--cover-light), transparent); box-shadow: 0 0 1rem var(--cover-glow); transform: rotate(-17deg); }
.material-cover--card .material-cover__artifact { right: -2%; width: 60%; }
.material-cover--card .material-cover__grid { background-size: 12px 12px; }
.material-cover--checklists { --cover-accent: var(--app-accent-violet); --cover-line: color-mix(in srgb, var(--app-accent-violet) 62%, transparent); --cover-light: var(--app-accent-violet); --cover-glow: color-mix(in srgb, var(--app-accent-violet) 22%, transparent); --cover-edge: color-mix(in srgb, var(--app-accent-violet) 18%, var(--app-surface)); }
.material-cover--courses { --cover-accent: var(--app-accent-blue); --cover-line: color-mix(in srgb, var(--app-accent-blue) 62%, transparent); --cover-light: var(--app-accent-blue); --cover-glow: color-mix(in srgb, var(--app-accent-blue) 22%, transparent); --cover-edge: color-mix(in srgb, var(--app-accent-blue) 18%, var(--app-surface)); }
.material-cover--experts { --cover-accent: var(--app-accent-slate); --cover-line: color-mix(in srgb, var(--app-accent-slate) 62%, transparent); --cover-light: var(--app-accent-slate); --cover-glow: color-mix(in srgb, var(--app-accent-slate) 22%, transparent); --cover-edge: color-mix(in srgb, var(--app-accent-slate) 18%, var(--app-surface)); }
.material-cover--streams { --cover-accent: var(--app-accent-wine); --cover-line: color-mix(in srgb, var(--app-accent-wine) 62%, transparent); --cover-light: var(--app-accent-wine); --cover-glow: color-mix(in srgb, var(--app-accent-wine) 22%, transparent); --cover-edge: color-mix(in srgb, var(--app-accent-wine) 18%, var(--app-surface)); }
.material-cover--other { --cover-accent: var(--app-accent-amber); --cover-line: color-mix(in srgb, var(--app-accent-amber) 62%, transparent); --cover-light: var(--app-accent-amber); --cover-glow: color-mix(in srgb, var(--app-accent-amber) 22%, transparent); --cover-edge: color-mix(in srgb, var(--app-accent-amber) 18%, var(--app-surface)); }
</style>
