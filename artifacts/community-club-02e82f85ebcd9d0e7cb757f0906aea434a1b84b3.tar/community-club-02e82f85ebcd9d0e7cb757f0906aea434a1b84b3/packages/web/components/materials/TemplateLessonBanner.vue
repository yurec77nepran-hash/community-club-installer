<script setup lang="ts">
// Плашка «Как дорабатывать шаблон с помощью AI» — только в разделе «Шаблоны»;
// ведёт на урок «Как работать с шаблонами?» (3-й урок по вайбкодингу, «Курсы»).
const LESSON_URL = '/app/content/courses/26'
</script>

<template>
	<div class="px-4 pt-4 md:px-6">
		<NuxtLink :to="LESSON_URL" class="template-lesson-banner">
			<span class="template-lesson-banner__icon" aria-hidden="true">
				<svg class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
					<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm-2 6.2 6.2 3.8L10 15.8V8.2Z" />
				</svg>
			</span>
			<span class="min-w-0 flex-1 text-left">
				<span class="template-lesson-banner__title">Как дорабатывать шаблон с помощью AI</span>
				<span class="template-lesson-banner__subtitle">Смотри урок</span>
			</span>
			<svg class="h-4 w-4 shrink-0 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" />
			</svg>
		</NuxtLink>
	</div>
</template>

<style scoped>
.template-lesson-banner {
	display: flex;
	width: 100%;
	align-items: center;
	gap: 0.8rem;
	border: 1px solid color-mix(in srgb, var(--section-accent) 32%, var(--app-border));
	border-radius: 1.05rem;
	background: radial-gradient(circle at 0% 100%, var(--section-accent-soft, color-mix(in srgb, var(--app-accent-slate) 10%, transparent)), transparent 45%), linear-gradient(180deg, var(--app-surface), var(--app-bg));
	padding: 0.8rem 0.9rem;
	color: inherit;
	transition: transform 0.18s ease, border-color 0.18s ease;
}

.template-lesson-banner:active {
	transform: scale(0.98);
}

.template-lesson-banner__icon {
	display: inline-grid;
	width: 2.3rem;
	height: 2.3rem;
	flex-shrink: 0;
	place-items: center;
	border-radius: 0.75rem;
	background: var(--section-accent-soft, color-mix(in srgb, var(--app-accent-slate) 10%, var(--app-surface)));
	color: var(--section-accent, var(--app-accent-slate));
}

.template-lesson-banner__title {
	display: block;
	color: var(--app-text-strong);
	font-size: 0.84rem;
	font-weight: 500;
	line-height: 1.25;
}

.template-lesson-banner__subtitle {
	display: block;
	margin-top: 0.2rem;
	color: var(--app-muted);
	font-size: 0.75rem;
}
</style>
