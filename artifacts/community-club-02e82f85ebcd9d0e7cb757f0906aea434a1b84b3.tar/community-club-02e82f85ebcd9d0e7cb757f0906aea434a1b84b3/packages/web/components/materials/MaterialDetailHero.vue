<script setup lang="ts">
import type { GuestContentBlockAccess } from '@community-club/shared/types'
import { withBuildVersion } from '~/utils/pwa-update'
import GuestContentBlock from './GuestContentBlock.vue'

const props = withDefaults(
	defineProps<{
		title: string
		type?: string
		typeLabel?: string
		access?: GuestContentBlockAccess | null
	}>(),
	{ type: 'other', access: null, typeLabel: '' },
)

const buildId = useRuntimeConfig().app.buildId
const coverImages: Record<string, string> = {
	checklists: withBuildVersion('/images/home/section-templates.webp', buildId),
	courses: withBuildVersion('/images/home/section-lessons.webp', buildId),
	experts: withBuildVersion('/images/home/section-experts.webp', buildId),
	streams: withBuildVersion('/images/home/section-streams.webp', buildId),
	other: withBuildVersion('/images/home/section-tools.webp', buildId),
}
const coverImage = computed(() => coverImages[props.type] ?? coverImages.other)

const emit = defineEmits<{
	requestAccess: []
}>()
</script>

<template>
	<div class="club-card material-detail-hero overflow-hidden rounded-3xl">
		<GuestContentBlock v-if="access" :access="access" variant="media" @request-access="emit('requestAccess')">
			<template #preview>
				<img :src="coverImage" alt="" class="material-detail-hero__image" />
			</template>
			<img :src="coverImage" :alt="title" class="material-detail-hero__image" />
		</GuestContentBlock>
		<template v-else>
			<img :src="coverImage" :alt="title" class="material-detail-hero__image" />
		</template>
		<div class="material-detail-hero__shade" />
		<div class="material-detail-hero__content">
			<p v-if="typeLabel" class="material-detail-hero__eyebrow">{{ typeLabel }}</p>
			<h2>{{ title }}</h2>
		</div>
	</div>
</template>

<style scoped>
.material-detail-hero { position: relative; min-height: 10.5rem; border-color: color-mix(in srgb, var(--section-accent) 36%, var(--app-border)); background: var(--app-surface); box-shadow: inset 0 1px rgb(255 255 255 / 0.18), var(--app-shadow-raised); }
.material-detail-hero :deep(.guest-content-block.is-media) { min-height: 0; aspect-ratio: 21 / 9; border: 0; border-radius: 0; background: transparent; }
.material-detail-hero__image { display: block; width: 100%; aspect-ratio: 21 / 9; object-fit: cover; object-position: center; }
.material-detail-hero__shade { position: absolute; inset: 0; background: linear-gradient(90deg, rgb(7 9 13 / 0.95) 0%, rgb(7 9 13 / 0.6) 47%, rgb(7 9 13 / 0.12) 100%), linear-gradient(0deg, rgb(7 9 13 / 0.5), transparent 50%); pointer-events: none; }
.material-detail-hero__content { position: absolute; z-index: 1; inset: auto auto 0 0; width: min(84%, 34rem); padding: 0.95rem 1rem 1rem; }
.material-detail-hero__eyebrow { margin: 0 0 0.45rem; color: var(--section-accent); font-size: 0.6rem; font-weight: 750; letter-spacing: 0.1em; text-transform: uppercase; }
.material-detail-hero h2 {
	margin: 0;
	color: #fffaf2;
	font-size: clamp(1.02rem, 2.6vw, 1.42rem);
	font-weight: 700;
	line-height: 1.22;
	letter-spacing: -0.01em;
	text-wrap: balance;
	display: -webkit-box;
	-webkit-box-orient: vertical;
	-webkit-line-clamp: 3;
	line-clamp: 3;
	overflow: hidden;
}
</style>
