<script setup lang="ts">
import type { FeedMediaItem } from '@community-club/shared/types'

const props = defineProps<{
	items: FeedMediaItem[]
	index: number
}>()

const emit = defineEmits<{
	close: []
}>()

const currentIndex = ref(props.index)

watch(
	() => props.index,
	(value) => {
		currentIndex.value = value
	},
)

const currentItem = computed(() => props.items[currentIndex.value] ?? null)
const onKeyDown = (event: KeyboardEvent) => {
	if (event.key === 'Escape') close()
	if (props.items.length > 1 && event.key === 'ArrowLeft') prev()
	if (props.items.length > 1 && event.key === 'ArrowRight') next()
}

function close() {
	emit('close')
}

function prev() {
	currentIndex.value = currentIndex.value === 0 ? props.items.length - 1 : currentIndex.value - 1
}

function next() {
	currentIndex.value = currentIndex.value === props.items.length - 1 ? 0 : currentIndex.value + 1
}

onMounted(() => {
	window.addEventListener('keydown', onKeyDown)
})

onUnmounted(() => window.removeEventListener('keydown', onKeyDown))
</script>

<template>
	<Teleport to="body">
		<div class="fixed inset-0 z-[120] bg-black/95 backdrop-blur-md" @click.self="close">
			<div class="absolute inset-x-0 top-0 flex items-center justify-between px-4 py-4">
				<p class="text-xs uppercase tracking-[0.28em] text-white/45">Лента</p>
				<button
					type="button"
					class="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white"
					@click="close"
				>
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
					</svg>
				</button>
			</div>

			<div class="flex h-full items-center justify-center px-3 pb-6 pt-20" @contextmenu.prevent>
				<div class="w-full max-w-6xl">
					<MediaVideoPlayer
						v-if="currentItem?.type === 'video' && currentItem.url"
						:src="currentItem.url"
					/>
					<div
						v-else-if="currentItem?.url"
						class="flex max-h-[78vh] min-h-[320px] items-center justify-center overflow-hidden rounded-[28px] border border-white/10 bg-[#0b0911]"
					>
						<img
							:src="currentItem.url"
							:alt="currentItem.name ?? 'Изображение'"
							class="max-h-[78vh] max-w-full object-contain"
							draggable="false"
						/>
					</div>
				</div>
			</div>

			<div
				v-if="items.length > 1"
				class="pointer-events-none absolute inset-y-0 left-0 right-0 flex items-center justify-between px-2 md:px-4"
			>
				<button
					type="button"
					class="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-black/40 text-white"
					@click.stop="prev"
				>
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</button>
				<button
					type="button"
					class="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-black/40 text-white"
					@click.stop="next"
				>
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
					</svg>
				</button>
			</div>
		</div>
	</Teleport>
</template>
