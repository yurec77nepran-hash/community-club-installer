<script setup lang="ts">
defineProps<{
	html: string
}>()
</script>

<template>
	<div
		class="feed-rich-text text-[15px] leading-7 text-[var(--app-text)] [overflow-wrap:anywhere] break-words"
		v-html="html"
	/>
</template>

<style scoped>
.feed-rich-text :deep(strong),
.feed-rich-text :deep(b) {
	font-weight: 700;
	color: var(--app-text-strong);
}

.feed-rich-text :deep(em),
.feed-rich-text :deep(i) {
	font-style: italic;
}

.feed-rich-text :deep(u) {
	text-decoration: underline;
	text-underline-offset: 0.16em;
}

.feed-rich-text :deep(s) {
	text-decoration: line-through;
}

.feed-rich-text :deep(.feed-inline-link) {
	color: var(--app-accent-strong);
	text-decoration: underline;
	text-underline-offset: 0.18em;
	word-break: break-word;
}
</style>
