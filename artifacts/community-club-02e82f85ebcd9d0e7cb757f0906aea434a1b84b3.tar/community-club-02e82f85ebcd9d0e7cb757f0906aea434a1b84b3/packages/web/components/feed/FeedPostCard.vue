<script setup lang="ts">
import { FEED_AUDIENCES, REACTIONS } from '@community-club/shared'
import type { FeedPostItem } from '@community-club/shared/types'

const props = defineProps<{
	item: FeedPostItem
	showAudience?: boolean
}>()

const emit = defineEmits<{
	react: [postId: number, emoji: string]
}>()

const showContextMenu = ref(false)
const menuPos = ref({ x: 0, y: 0 })
let longPressTimer: ReturnType<typeof setTimeout> | null = null
let menuOpenedAt = 0

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'long',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function openMenu(x: number, y: number) {
	const menuW = 220
	const menuH = 82
	const vw = window.innerWidth
	const vh = window.innerHeight
	menuPos.value = {
		x: Math.min(Math.max(8, x), vw - menuW - 8),
		y: Math.min(Math.max(8, y), vh - menuH - 8),
	}
	showContextMenu.value = true
	menuOpenedAt = Date.now()
}

function closeMenu() {
	if (Date.now() - menuOpenedAt < 250) return
	showContextMenu.value = false
}

function cancelLongPress() {
	if (longPressTimer) {
		clearTimeout(longPressTimer)
		longPressTimer = null
	}
}

function onContextMenu(event: MouseEvent) {
	event.preventDefault()
	openMenu(event.clientX, event.clientY)
}

function onTouchStart(event: TouchEvent) {
	const touch = event.touches[0]
	cancelLongPress()
	longPressTimer = setTimeout(() => {
		if (navigator.vibrate) navigator.vibrate(30)
		openMenu(touch.clientX, touch.clientY)
	}, 400)
}

function onTouchMove() {
	cancelLongPress()
}

function onTouchEnd() {
	cancelLongPress()
}

function onReact(emoji: string) {
	emit('react', props.item.id, emoji)
	closeMenu()
}
</script>

<template>
	<article
		class="feed-post-card club-card"
		@contextmenu="onContextMenu"
		@touchstart.passive="onTouchStart"
		@touchmove.passive="onTouchMove"
		@touchend.passive="onTouchEnd"
	>
		<div class="px-5 pb-3 pt-4">
			<div class="flex items-start justify-between gap-3">
				<div class="min-w-0">
					<div class="flex flex-wrap items-center gap-2">
						<p class="feed-post-source">Club App · канал</p>
						<span
							v-if="showAudience"
							class="rounded-full border border-[color-mix(in_srgb,var(--app-accent)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_10%,var(--app-surface))] px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.16em] text-[var(--app-accent-strong)]"
						>
							{{ FEED_AUDIENCES[item.audience] }}
						</span>
					</div>
					<p class="feed-post-date">
						{{ formatDate(item.createdAt) }}
					</p>
				</div>
			</div>
		</div>

		<div class="space-y-4 p-4 md:p-5">
			<FeedMediaGrid v-if="item.media.length" :items="item.media" />

			<FeedRichText :html="item.contentHtml" />

			<a
				v-if="item.buttonLabel && item.buttonUrl"
				:href="item.buttonUrl"
				target="_blank"
				rel="noopener noreferrer"
				class="feed-post-action"
			>
				<span>{{ item.buttonLabel }}</span>
				<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5h5m0 0v5m0-5L10 14" />
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 9v10h10" />
				</svg>
			</a>

			<div v-if="item.reactions.length" class="flex flex-wrap items-center gap-2 pt-1">
				<button
					v-for="reaction in item.reactions"
					:key="reaction.emoji"
					type="button"
					class="rounded-full border px-3 py-1.5 text-sm transition"
					:class="
							reaction.reactedByMe
								? 'border-[color-mix(in_srgb,var(--app-accent)_42%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_14%,var(--app-surface))] text-[var(--app-accent-strong)]'
								: 'border-[var(--app-border)] bg-[var(--app-bg)] text-[var(--app-muted)] hover:border-[var(--app-border-strong)] hover:bg-[var(--app-surface)] hover:text-[var(--app-text)]'
					"
					@click="emit('react', item.id, reaction.emoji)"
				>
					{{ reaction.emoji }}
					<span class="ml-1 text-xs">{{ reaction.count }}</span>
				</button>
			</div>
		</div>
	</article>

	<Teleport to="body">
		<div
			v-if="showContextMenu"
			class="fixed inset-0 z-[90]"
			@click.self="closeMenu"
			@contextmenu.prevent="closeMenu"
		>
			<div
				class="fixed z-[91] w-[220px] context-menu-appear"
				:style="{ left: `${menuPos.x}px`, top: `${menuPos.y}px` }"
				@click.stop
			>
				<div class="flex gap-0.5 overflow-x-auto rounded-2xl border border-[var(--app-border)] bg-[color-mix(in_srgb,var(--app-surface)_94%,transparent)] px-1.5 py-1.5 shadow-[var(--app-shadow-floating)] backdrop-blur-2xl scrollbar-hide">
					<button
						v-for="emoji in REACTIONS"
						:key="emoji"
						class="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl text-[20px] transition-transform hover:bg-[var(--app-bg-deep)] active:scale-110"
						@click="onReact(emoji)"
					>
						{{ emoji }}
					</button>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<style scoped>
.feed-post-card {
	border: 1px solid var(--app-border);
	border-radius: 1.35rem;
	background:
		radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 11%, transparent), transparent 30%),
		linear-gradient(155deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px 0 rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}

.feed-post-card::before {
	left: 1rem;
	right: 1rem;
	background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--app-accent) 42%, transparent), transparent);
}

.feed-post-source {
	color: var(--app-text-strong);
	font-size: 0.72rem;
	font-weight: 700;
	letter-spacing: 0.12em;
	text-transform: uppercase;
}

.feed-post-date {
	margin-top: 0.42rem;
	color: var(--app-muted-soft);
	font-size: 0.67rem;
	font-weight: 600;
	letter-spacing: 0.13em;
	text-transform: uppercase;
}

.feed-post-action {
	display: flex;
	width: 100%;
	align-items: center;
	justify-content: center;
	gap: 0.5rem;
	border: 1px solid color-mix(in srgb, var(--app-accent) 62%, var(--app-border));
	border-radius: 0.9rem;
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 82%, white), var(--app-accent));
	padding: 0.8rem 1rem;
	color: var(--app-text-strong);
	font-size: 0.88rem;
	font-weight: 750;
	box-shadow: 0 12px 24px color-mix(in srgb, var(--app-accent-strong) 18%, transparent);
	transition: transform 0.18s ease, filter 0.18s ease;
}

.feed-post-action:hover { filter: brightness(1.06); }
.feed-post-action:active { transform: scale(0.985); }

@media (prefers-reduced-motion: no-preference) {
	.feed-post-card { animation: post-reveal 0.32s ease-out both; }
}

@keyframes post-reveal {
	from { opacity: 0; transform: translateY(8px); }
	to { opacity: 1; transform: translateY(0); }
}

.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
.context-menu-appear { animation: ctx-pop 0.15s ease-out; }
@keyframes ctx-pop {
	from { opacity: 0; transform: scale(0.92); }
	to { opacity: 1; transform: scale(1); }
}
</style>
