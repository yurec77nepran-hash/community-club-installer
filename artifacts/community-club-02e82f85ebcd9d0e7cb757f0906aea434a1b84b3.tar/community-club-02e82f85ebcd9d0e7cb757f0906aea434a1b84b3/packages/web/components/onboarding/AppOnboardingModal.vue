<script setup lang="ts">
const props = defineProps<{
	open: boolean
	loading?: boolean
}>()

const emit = defineEmits<{
	complete: []
}>()

const step = ref(0)
const steps = [
	{
		title: 'Добро пожаловать в клуб',
		text: 'Здесь собраны материалы, эфиры и обсуждения для участников.',
	},
	{
		title: 'Начните с главной',
		text: 'На главной видны свежие анонсы, быстрые переходы и важные обновления.',
	},
	{
		title: 'Читайте ленту',
		text: 'В ленте появляются посты клуба, заметки и полезные подборки.',
	},
	{
		title: 'Следите за календарём',
		text: 'Встречи и события собраны в одном разделе.',
	},
	{
		title: 'Общайтесь в чатах',
		text: 'Задавайте вопросы, отвечайте участникам и пишите в службу заботы.',
	},
]

watch(
	() => props.open,
	(open) => {
		if (open) step.value = 0
	},
)

const currentStep = computed(() => steps[step.value])
const isLastStep = computed(() => step.value === steps.length - 1)

function next() {
	if (!isLastStep.value) {
		step.value += 1
		return
	}
	emit('complete')
}
</script>

<template>
	<Transition name="onboarding-modal">
		<div v-if="open" class="onboarding-layer">
			<section class="onboarding-card" role="dialog" aria-modal="true" aria-labelledby="onboarding-title">
				<div class="onboarding-step-count">{{ step + 1 }} / {{ steps.length }}</div>
				<div class="onboarding-visual" aria-hidden="true">
					<span v-for="index in steps.length" :key="index" :class="{ active: index - 1 <= step }" />
				</div>
				<h2 id="onboarding-title" class="onboarding-title">{{ currentStep.title }}</h2>
				<p class="onboarding-text">{{ currentStep.text }}</p>
				<div class="onboarding-dots" aria-hidden="true">
					<span v-for="index in steps.length" :key="index" :class="{ active: index - 1 === step }" />
				</div>
				<div class="onboarding-actions">
					<button type="button" class="onboarding-button-secondary" :disabled="loading" @click="emit('complete')">
						Пропустить
					</button>
					<button type="button" class="onboarding-button-primary" :disabled="loading" @click="next">
						{{ loading ? 'Сохраняем...' : isLastStep ? 'Начать' : 'Далее' }}
					</button>
				</div>
			</section>
		</div>
	</Transition>
</template>

<style scoped>
.onboarding-layer {
	position: fixed;
	inset: 0;
	left: 50%;
	z-index: 80;
	display: flex;
	width: var(--app-viewport-width);
	max-width: var(--app-viewport-max);
	align-items: center;
	justify-content: center;
	padding: 1.25rem;
	background: color-mix(in srgb, var(--app-text) 62%, transparent);
	backdrop-filter: blur(16px);
	transform: translateX(-50%);
}

.onboarding-card {
	width: min(100%, 25rem);
	border: 1px solid var(--app-border-strong);
	border-radius: 1.5rem;
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	padding: 1.4rem;
	color: var(--app-text);
	box-shadow:
		inset 0 1px 0 rgb(255 255 255 / 0.96),
		var(--app-shadow-floating);
}

.onboarding-step-count {
	color: var(--app-muted-soft);
	font-size: 0.78rem;
	font-weight: 700;
}

.onboarding-visual {
	display: grid;
	grid-template-columns: repeat(5, 1fr);
	gap: 0.4rem;
	margin-top: 1rem;
}

.onboarding-visual span {
	height: 4.2rem;
	border-radius: 0.95rem;
	background: var(--app-bg-deep);
	transform: translateY(0.35rem);
	transition: background 0.2s ease, transform 0.2s ease;
}

.onboarding-visual span.active {
	background: var(--app-button-bg);
	transform: translateY(0);
}

.onboarding-title {
	margin-top: 1.25rem;
	font-size: 1.35rem;
	font-weight: 780;
	line-height: 1.12;
	letter-spacing: 0;
}

.onboarding-text {
	margin-top: 0.55rem;
	color: var(--app-muted);
	font-size: 0.95rem;
	line-height: 1.48;
}

.onboarding-dots {
	display: flex;
	gap: 0.35rem;
	margin-top: 1.1rem;
}

.onboarding-dots span {
	width: 0.45rem;
	height: 0.45rem;
	border-radius: 999px;
	background: var(--app-border);
}

.onboarding-dots span.active {
	width: 1.45rem;
	background: var(--app-button-bg);
}

.onboarding-actions {
	display: grid;
	grid-template-columns: 0.8fr 1fr;
	gap: 0.7rem;
	margin-top: 1.3rem;
}

.onboarding-button-primary,
.onboarding-button-secondary {
	min-height: 3rem;
	border-radius: 1rem;
	font-size: 0.94rem;
	font-weight: 700;
	transition: transform 0.16s ease, opacity 0.16s ease;
}

.onboarding-button-primary:active,
.onboarding-button-secondary:active {
	transform: scale(0.98);
}

.onboarding-button-primary:disabled,
.onboarding-button-secondary:disabled {
	cursor: not-allowed;
	opacity: 0.55;
}

.onboarding-button-primary {
	background: var(--app-button-bg);
	color: var(--app-button-fg);
	box-shadow: var(--app-shadow-soft);
}

.onboarding-button-secondary {
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	color: var(--app-muted);
}

.onboarding-modal-enter-active,
.onboarding-modal-leave-active {
	transition: opacity 0.18s ease;
}

.onboarding-modal-enter-active .onboarding-card,
.onboarding-modal-leave-active .onboarding-card {
	transition: transform 0.2s ease, opacity 0.2s ease;
}

.onboarding-modal-enter-from,
.onboarding-modal-leave-to {
	opacity: 0;
}

.onboarding-modal-enter-from .onboarding-card,
.onboarding-modal-leave-to .onboarding-card {
	opacity: 0;
	transform: translateY(0.35rem) scale(0.98);
}
</style>
