<script setup lang="ts">
import type { LegalDocumentKey, LegalDocumentsSettings } from '@community-club/shared/types'

const props = defineProps<{ scope: 'auth' | 'payment' }>()
const accepted = defineModel<boolean>({ default: false })
const api = useApi()

const { data, pending } = await useAsyncData(
	'legal-documents-settings',
	async () => {
		const res = await api.get<LegalDocumentsSettings>('/api/site-settings/legal-documents')
		return res.success ? res.data : { documents: [] }
	},
	{
		server: false,
	},
)

const keys = computed<LegalDocumentKey[]>(() =>
	props.scope === 'payment' ? ['privacy', 'personalData', 'oferta'] : ['privacy', 'personalData'],
)

const documents = computed(() =>
	(data.value?.documents ?? []).filter(
		(document) => document.enabled && keys.value.includes(document.key),
	),
)

function documentPath(key: LegalDocumentKey) {
	if (key === 'privacy') return '/app/legal/privacy-policy'
	if (key === 'personalData') return '/app/legal/personal-data'
	if (key === 'oferta') return '/app/legal/oferta'
	if (key === 'requisites') return '/app/legal/requisites'
	return '/app/legal/cookie-policy'
}

watchEffect(() => {
	if (!pending.value && documents.value.length === 0) {
		accepted.value = true
	}
})
</script>

<template>
	<label v-if="documents.length" class="legal-consent">
		<input v-model="accepted" type="checkbox" />
		<span>
			<span>Согласен с </span>
			<template v-for="(document, index) in documents" :key="document.key">
				<span v-if="index > 0">{{ index === documents.length - 1 ? ' и ' : ', ' }}</span>
				<NuxtLink :to="documentPath(document.key)" target="_blank">
					{{ document.linkLabel }}
				</NuxtLink>
			</template>
		</span>
	</label>
</template>

<style scoped>
.legal-consent {
	display: flex;
	gap: 0.65rem;
	align-items: flex-start;
	color: var(--app-muted);
	font-size: 0.78rem;
	line-height: 1.45;
}

.legal-consent input {
	appearance: none;
	display: grid;
	width: 1.1rem;
	height: 1.1rem;
	margin-top: 0.08rem;
	place-content: center;
	border: 1px solid var(--app-border-strong);
	border-radius: 0.32rem;
	background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface));
	box-shadow: inset 0 1px 0 rgb(255 255 255 / 0.96);
	transition: border-color 160ms ease, background-color 160ms ease, box-shadow 160ms ease;
	flex: 0 0 auto;
	cursor: pointer;
}

.legal-consent input::before {
	width: 0.38rem;
	height: 0.65rem;
	border: solid var(--app-button-fg);
	border-width: 0 0.12rem 0.12rem 0;
	content: '';
	transform: rotate(45deg) scale(0);
	transition: transform 120ms ease;
}

.legal-consent input:checked {
	border-color: var(--app-accent);
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent));
	box-shadow: 0 0 0 3px color-mix(in srgb, var(--app-accent) 12%, transparent), inset 0 1px 0 rgb(255 255 255 / 0.4);
}

.legal-consent input:checked::before {
	transform: rotate(45deg) scale(1);
}

.legal-consent input:focus-visible {
	outline: 2px solid var(--app-accent);
	outline-offset: 2px;
}

.legal-consent a {
	color: var(--app-accent-strong);
	text-decoration: underline;
	text-decoration-color: color-mix(in srgb, var(--app-accent) 35%, transparent);
	text-underline-offset: 0.18em;
}
</style>
