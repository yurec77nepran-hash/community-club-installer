<script setup lang="ts">
import type { LegalDocumentsSettings } from '@community-club/shared/types'

const api = useApi()
const accepted = ref(true)
const storageKey = 'club_cookie_notice_accepted_v1'

const { data } = await useAsyncData(
	'legal-documents-settings',
	async () => {
		const res = await api.get<LegalDocumentsSettings>('/api/site-settings/legal-documents')
		return res.success ? res.data : { documents: [] }
	},
	{
		server: false,
	},
)

const cookieDocument = computed(() =>
	data.value?.documents.find((document) => document.key === 'cookie' && document.enabled),
)
const cookieNoticeText = computed(
	() =>
		cookieDocument.value?.noticeText?.trim() ||
		'Сохраняем cookie для входа и стабильной работы клуба. Подробнее —',
)

onMounted(() => {
	accepted.value = localStorage.getItem(storageKey) === '1'
})

function accept() {
	accepted.value = true
	localStorage.setItem(storageKey, '1')
}
</script>

<template>
	<Teleport to="body">
		<div v-if="cookieDocument && !accepted" class="cookie-banner" role="dialog" aria-label="Согласие на cookie">
			<div class="cookie-banner-mark" aria-hidden="true">O</div>
			<p>
				{{ cookieNoticeText }}
				<NuxtLink to="/legal/cookie-policy">{{ cookieDocument.linkLabel }}</NuxtLink>.
			</p>
			<button type="button" @click="accept">Принять</button>
		</div>
	</Teleport>
</template>

<style scoped>
.cookie-banner {
	position: fixed;
	right: max(0.75rem, env(safe-area-inset-right));
	bottom: max(0.75rem, env(safe-area-inset-bottom));
	left: max(0.75rem, env(safe-area-inset-left));
	z-index: 80;
	display: flex;
	gap: 1rem;
	align-items: center;
	justify-content: space-between;
	max-width: 42rem;
	margin: 0 auto;
	border: 1px solid var(--app-border-strong);
	border-radius: 1.1rem;
	background: radial-gradient(circle at 8% 0, color-mix(in srgb, var(--app-accent) 12%, transparent), transparent 28%), linear-gradient(135deg, var(--app-surface), var(--app-bg));
	padding: 0.95rem 1rem;
	color: var(--app-text);
	box-shadow: var(--app-shadow-floating), 0 0 1.6rem color-mix(in srgb, var(--app-accent) 8%, transparent);
	backdrop-filter: blur(22px);
}


.cookie-banner-mark {
	display: grid;
	width: 2rem;
	height: 2rem;
	flex: 0 0 auto;
	place-items: center;
	border: 1px solid var(--app-accent);
	border-radius: 50%;
	color: var(--app-accent-strong);
	font-size: 0.72rem;
	font-weight: 700;
	box-shadow: 0 0 1rem color-mix(in srgb, var(--app-accent) 16%, transparent);
}

.cookie-banner p {
	margin: 0;
	font-size: 0.84rem;
	line-height: 1.45;
}

.cookie-banner a {
	color: var(--app-accent-strong);
	text-decoration: underline;
	text-underline-offset: 0.16em;
}

.cookie-banner button {
	flex: 0 0 auto;
	border: 0;
	border: 1px solid var(--app-border-strong);
	border-radius: 0.7rem;
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent));
	padding: 0.7rem 1rem;
	color: var(--app-button-fg);
	font-size: 0.82rem;
	font-weight: 700;
}

@media (max-width: 520px) {
	.cookie-banner {
		gap: 0.75rem;
		align-items: flex-start;
		flex-wrap: wrap;
		border-radius: 1rem;
	}

	.cookie-banner p {
		flex: 1 1 13rem;
	}

	.cookie-banner button {
		width: 100%;
	}
}
</style>
