<script setup lang="ts">
import type { LegalDocumentKey, LegalDocumentsSettings } from '@community-club/shared/types'

const props = defineProps<{ docKey: LegalDocumentKey; backFallback?: string }>()
const route = useRoute()
const api = useApi()
const backTarget = computed(() =>
	typeof route.query.back === 'string' && route.query.back
		? route.query.back
		: (props.backFallback ?? '/'),
)

const { data } = await useAsyncData(
	'legal-documents-settings',
	async () => {
		const res = await api.get<LegalDocumentsSettings>('/api/site-settings/legal-documents')
		return res.success ? res.data : { documents: [] }
	},
	{
		server: false,
	},
)

const documentItem = computed(() =>
	data.value?.documents.find((document) => document.key === props.docKey),
)

function escapeHtml(value: string) {
	return value
		.replaceAll('&', '&amp;')
		.replaceAll('<', '&lt;')
		.replaceAll('>', '&gt;')
		.replaceAll('"', '&quot;')
}

function linkifyText(value: string) {
	return escapeHtml(value)
		.replace(
			/(https?:\/\/[^\s<]+)/g,
			'<a href="$1" target="_blank" rel="noopener noreferrer" class="club-text-link">$1</a>',
		)
		.replace(
			/([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/gi,
			'<a href="mailto:$1" class="club-text-link">$1</a>',
		)
		.replace(/(\+?\d[\d\s()-]{8,}\d)/g, '<a href="tel:$1" class="club-text-link">$1</a>')
}

const renderedBody = computed(() => linkifyText(documentItem.value?.body ?? ''))
</script>

<template>
	<div class="club-page legal-document-page min-h-screen text-[var(--app-text)]">
		<div class="mx-auto max-w-3xl">
			<header class="club-topbar">
				<NuxtLink :to="backTarget" class="club-back-button" aria-label="Назад">
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</NuxtLink>
				<div class="min-w-0">
					<div class="club-section-head mb-2">
						<span class="club-section-line" />
						<p class="club-section-kicker">Документы</p>
					</div>
					<h1 class="club-section-title text-xl font-bold">
						{{ documentItem?.title ?? 'Документ' }}
					</h1>
				</div>
			</header>

			<section v-if="documentItem?.enabled" class="club-card legal-document-card p-5 md:p-6">
				<div
					class="whitespace-pre-wrap text-sm leading-7 text-[var(--app-muted)] selection:bg-[color-mix(in_srgb,var(--app-accent)_18%,transparent)] [&_a]:font-medium"
					v-html="renderedBody"
				/>
			</section>
			<section v-else class="club-card legal-document-card p-5 text-sm text-[var(--app-muted)]">
				Документ отключён.
			</section>
		</div>
	</div>
</template>

<style scoped>
.legal-document-page {
	background: radial-gradient(circle at 88% 0, color-mix(in srgb, var(--app-accent) 10%, transparent), transparent 28%);
}

.legal-document-card {
	border-color: var(--app-border-strong);
	background:
		radial-gradient(circle at 100% 0, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 32%),
		linear-gradient(145deg, var(--app-surface), var(--app-bg));
}
</style>
