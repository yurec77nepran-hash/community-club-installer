<script setup lang="ts">
import type { PaymentTariffOffer } from '@community-club/shared/types'

const props = defineProps<{
	tariffs: PaymentTariffOffer[]
	selectedSlug: string | null
	trialDays: number | null
	trialSelected: boolean
	priceFor: (tariff: PaymentTariffOffer) => string | number
	formatPrice: (value: string | number) => string
}>()

const emit = defineEmits<{
	select: [tariff: PaymentTariffOffer]
	selectTrial: []
	continue: []
}>()

const selectedTariff = computed(() =>
	props.trialSelected
		? null
		: (props.tariffs.find((tariff) => String(tariff.slug) === props.selectedSlug) ?? null),
)
const monthlyTariff = computed(
	() => props.tariffs.find((tariff) => tariff.durationDays === 30) ?? null,
)

function period(tariff: PaymentTariffOffer) {
	if (tariff.durationDays === 30) return '1 месяц'
	if (tariff.durationDays === 90) return '3 месяца'
	if (tariff.durationDays === 365) return '1 год'
	return `${tariff.durationDays} дней`
}

function duration(tariff: PaymentTariffOffer) {
	return `${tariff.durationDays} дней доступа`
}

function months(tariff: PaymentTariffOffer) {
	if (tariff.durationDays === 365) return 12
	return Math.max(1, Math.round(tariff.durationDays / 30))
}

function monthlyCost(tariff: PaymentTariffOffer) {
	return Math.round(Number(props.priceFor(tariff)) / months(tariff))
}

function savings(tariff: PaymentTariffOffer) {
	if (!monthlyTariff.value || tariff.durationDays <= 30) return 0
	return Math.max(
		0,
		Number(props.priceFor(monthlyTariff.value)) * months(tariff) - Number(props.priceFor(tariff)),
	)
}

function badge(tariff: PaymentTariffOffer) {
	if (tariff.durationDays === 90) return 'Оптимально'
	if (tariff.durationDays >= 365) return 'Максимальная выгода'
	return ''
}

function isTariffSelected(tariff: PaymentTariffOffer) {
	return !props.trialSelected && props.selectedSlug === String(tariff.slug)
}
</script>

<template>
	<section class="tariff-screen" aria-labelledby="payment-tariffs-title">
		<div class="tariff-hero">
			<div class="tariff-hero__content">
				<p class="tariff-hero__eyebrow">Club App · клубный доступ</p>
				<h1 id="payment-tariffs-title">Подписка</h1>
				<p class="tariff-hero__lead">Выберите срок доступа и получите полный доступ к материалам и сообществу клуба.</p>
				<div class="tariff-hero__features" aria-label="Что входит в доступ">
					<span><i aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z M4 7.5 12 12l8-4.5M12 12v9" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" /></svg></i><b>Все материалы</b><small>Шаблоны, уроки, эфиры</small></span>
					<span><i aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm-3.5-7.3 2.2 2.1 4.8-5" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" /></svg></i><b>Сообщество</b><small>Поддержка и нетворкинг</small></span>
				</div>
			</div>
			<img src="/images/payment/club-access-pass.png" alt="Клубный доступ Club App" class="tariff-hero__image" />
		</div>

		<h2 class="tariff-screen__title">Доступные варианты</h2>
		<div class="tariff-list">
			<button
				v-if="trialDays"
				type="button"
				class="tariff-option tariff-option--trial"
				:class="{ 'is-selected': trialSelected }"
				@click="emit('selectTrial')"
			>
				<span class="tariff-option__badge">Попробовать клуб</span>
				<span class="tariff-option__top">
					<span>
						<strong>{{ trialDays }} дней</strong>
						<small>Полный доступ без карты и автоматических списаний.</small>
					</span>
					<span class="tariff-option__price">
						<b>Бесплатно</b>
						<small>{{ trialDays }} дней доступа</small>
					</span>
				</span>
				<span class="tariff-option__bottom">
					<span class="tariff-option__saving">Оплата не требуется</span>
					<span class="tariff-option__action">
						<svg v-if="trialSelected" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="m5 12 4 4L19 6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.3" /></svg>
						{{ trialSelected ? 'Выбрано' : 'Выбрать' }}
					</span>
				</span>
			</button>
			<button
				v-for="tariff in tariffs"
				:key="String(tariff.id)"
				type="button"
				class="tariff-option"
				:class="{
					'is-selected': isTariffSelected(tariff),
				}"
				@click="emit('select', tariff)"
			>
				<span v-if="badge(tariff)" class="tariff-option__badge">{{ badge(tariff) }}</span>
				<span class="tariff-option__top">
					<span>
						<strong>{{ period(tariff) }}</strong>
						<small>Полный доступ к материалам и сообществу клуба.</small>
					</span>
					<span class="tariff-option__price">
						<b>{{ formatPrice(priceFor(tariff)) }} ₽</b>
						<small v-if="tariff.durationDays > 30">≈ {{ formatPrice(monthlyCost(tariff)) }} ₽ / месяц</small>
						<small>{{ duration(tariff) }}</small>
					</span>
				</span>
				<span class="tariff-option__bottom">
					<span v-if="savings(tariff)" class="tariff-option__saving">Выгода {{ formatPrice(savings(tariff)) }} ₽</span>
					<span v-else aria-hidden="true" />
					<span class="tariff-option__action">
						<svg v-if="isTariffSelected(tariff)" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="m5 12 4 4L19 6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.3" /></svg>
						{{ isTariffSelected(tariff) ? 'Выбрано' : 'Выбрать' }}
					</span>
				</span>
			</button>
		</div>

		<button type="button" class="tariff-continue" :disabled="!selectedTariff && !trialSelected" @click="emit('continue')">
			<span>Продолжить</span>
			<b v-if="trialSelected">· Бесплатно</b>
			<b v-else-if="selectedTariff">· {{ formatPrice(priceFor(selectedTariff)) }} ₽</b>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" /></svg>
		</button>
	</section>
</template>

<style scoped>
.tariff-screen { display: grid; gap: 0.85rem; padding-bottom: 6rem; }
.tariff-hero { position: relative; min-height: 16.25rem; overflow: hidden; border: 1px solid color-mix(in srgb, var(--app-accent) 44%, transparent); border-radius: 1.2rem; background: #12110d; box-shadow: inset 0 1px color-mix(in srgb, var(--app-accent) 8%, transparent), 0 1.1rem 2.6rem rgb(0 0 0 / 0.24); isolation: isolate; }
.tariff-hero::after { position: absolute; inset: 0; z-index: -1; background: linear-gradient(90deg, rgb(10 10 10 / 0.98) 0%, rgb(11 10 8 / 0.91) 48%, rgb(11 10 8 / 0.18) 100%); content: ''; }
.tariff-hero__content { position: relative; z-index: 1; display: grid; width: min(68%, 21rem); align-content: start; gap: 0.48rem; padding: 1.25rem 1.2rem; }
.tariff-hero__eyebrow, .tariff-screen__title { margin: 0; color: color-mix(in srgb, var(--app-accent) 84%, var(--app-surface)); font-size: 0.66rem; font-weight: 800; letter-spacing: 0.15em; text-transform: uppercase; }
.tariff-hero h1 { margin: 0.12rem 0 0; color: color-mix(in srgb, var(--app-surface) 96%, var(--app-accent)); font-size: clamp(2rem, 8.7vw, 3rem); font-weight: 850; letter-spacing: 0.02em; line-height: 0.92; text-transform: uppercase; }
.tariff-hero__lead { margin: 0; max-width: 15rem; color: color-mix(in srgb, var(--app-surface) 76%, transparent); font-size: 0.8rem; line-height: 1.4; }
.tariff-hero__image { position: absolute; right: -6.8rem; bottom: 0; width: 29rem; max-width: none; height: 100%; object-fit: cover; object-position: 100% center; }
.tariff-hero__features { display: flex; gap: 0.55rem; margin-top: 0.38rem; }
.tariff-hero__features span { display: grid; grid-template-columns: 1.65rem minmax(0, 1fr); gap: 0.06rem 0.38rem; min-width: 0; color: color-mix(in srgb, var(--app-surface) 82%, var(--app-accent)); }
.tariff-hero__features i { display: grid; grid-row: span 2; width: 1.55rem; height: 1.55rem; place-items: center; border: 1px solid color-mix(in srgb, var(--app-accent) 40%, transparent); border-radius: 50%; color: color-mix(in srgb, var(--app-accent) 74%, var(--app-surface)); }
.tariff-hero__features svg { width: 0.84rem; height: 0.84rem; }
.tariff-hero__features b { font-size: 0.54rem; font-weight: 750; line-height: 1.15; text-transform: uppercase; }
.tariff-hero__features small { color: color-mix(in srgb, var(--app-surface) 55%, transparent); font-size: 0.5rem; line-height: 1.25; }
.tariff-screen__title { margin-top: 0.38rem; color: var(--app-text-strong); font-size: 0.76rem; }
.tariff-list { display: grid; gap: 0.68rem; }
.tariff-option { position: relative; display: grid; gap: 0.7rem; width: 100%; overflow: hidden; border: 1px solid var(--app-border); border-radius: 1.1rem; padding: 0.95rem; background: linear-gradient(155deg, var(--app-surface), var(--app-bg)); color: var(--app-text); text-align: left; box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft); transition: transform 0.18s ease, border-color 0.18s ease, background 0.18s ease, box-shadow 0.18s ease; }
.tariff-option:hover { border-color: var(--app-border-strong); }
.tariff-option:focus-visible, .tariff-continue:focus-visible { outline: 2px solid var(--app-accent); outline-offset: 3px; }
.tariff-option:active { transform: scale(0.985); }
.tariff-option.is-selected { border-color: var(--app-accent); background: radial-gradient(circle at 88% 12%, color-mix(in srgb, var(--app-accent) 16%, transparent), transparent 38%), linear-gradient(145deg, var(--app-surface), var(--app-bg)); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--app-accent) 22%, transparent), var(--app-shadow-raised); }
.tariff-option__badge { position: absolute; top: 0.68rem; left: 0.95rem; z-index: 1; color: var(--app-accent-strong); font-size: 0.54rem; font-weight: 850; letter-spacing: 0.1em; text-transform: uppercase; }
.tariff-option:has(.tariff-option__badge) { padding-top: 1.8rem; }
.tariff-option__top, .tariff-option__bottom { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 0.7rem; align-items: start; }
.tariff-option__top > span:first-child { display: grid; gap: 0.35rem; }
.tariff-option strong { font-size: 1.2rem; font-weight: 800; letter-spacing: 0.01em; line-height: 1; text-transform: uppercase; }
.tariff-option small { color: var(--app-muted); font-size: 0.7rem; line-height: 1.32; }
.tariff-option__price { display: grid; gap: 0.2rem; min-width: 7.25rem; text-align: right; }
.tariff-option__price b { color: var(--app-text-strong); font-size: 1.3rem; font-weight: 850; line-height: 1; }
.is-selected .tariff-option__price b { color: var(--app-accent-strong); text-shadow: none; }
.tariff-option__price small:last-child { color: var(--app-muted-soft); font-size: 0.6rem; font-weight: 700; letter-spacing: 0.07em; text-transform: uppercase; }
.tariff-option__saving { align-self: center; color: var(--app-accent-strong); font-size: 0.72rem; font-weight: 750; }
.tariff-option__action { position: relative; z-index: 1; display: inline-flex; min-width: 8.55rem; align-items: center; justify-content: center; gap: 0.42rem; border: 1px solid var(--app-border-strong); border-radius: 0.68rem; padding: 0.58rem 0.72rem; color: var(--app-accent-strong); font-size: 0.74rem; font-weight: 800; }
.tariff-option__action svg { width: 0.9rem; height: 0.9rem; }
.is-selected .tariff-option__action { border-color: var(--app-accent); background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent)); color: var(--app-button-fg); }
.tariff-continue { display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 0.65rem; width: 100%; min-height: 3.85rem; margin-top: 0.22rem; border: 1px solid var(--app-border-strong); border-radius: 0.9rem; padding: 0.75rem 1rem; background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent)); box-shadow: var(--app-shadow-raised); color: var(--app-button-fg); font-size: 0.82rem; font-weight: 850; letter-spacing: 0.1em; text-transform: uppercase; transition: transform 0.18s ease, opacity 0.18s ease; }
.tariff-continue b { font-size: 0.86rem; letter-spacing: 0.06em; }
.tariff-continue svg { justify-self: end; width: 1.2rem; height: 1.2rem; }
.tariff-continue:disabled { cursor: not-allowed; opacity: 0.45; }
.tariff-continue:not(:disabled):active { transform: scale(0.985); }
@media (max-width: 370px) { .tariff-hero__content { width: 70%; padding: 1.2rem 1rem; } .tariff-hero__features { gap: 0.4rem; } .tariff-option__action { min-width: 7.2rem; } }
@media (prefers-reduced-motion: no-preference) { .tariff-hero, .tariff-option { animation: tariff-reveal 0.32s ease-out both; } .tariff-option:nth-child(2) { animation-delay: 0.05s; } .tariff-option:nth-child(3) { animation-delay: 0.1s; } }
@keyframes tariff-reveal { from { opacity: 0; transform: translateY(0.55rem); } to { opacity: 1; transform: translateY(0); } }
</style>
