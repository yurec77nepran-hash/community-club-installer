<script setup lang="ts">
import SecurePasswordField from '~/components/auth/SecurePasswordField.vue'
import LegalConsent from '~/components/legal/LegalConsent.vue'
import { buildDemoAccessRequest } from '~/utils/demo-access'

const props = defineProps<{
	days: number
	authenticated: boolean
	accountEmail: string
}>()
const emit = defineEmits<{ back: [] }>()
const email = defineModel<string>('email', { required: true })
const password = defineModel<string>('password', { required: true })
const confirmPassword = defineModel<string>('confirmPassword', { required: true })
const consentAccepted = defineModel<boolean>('consentAccepted', { required: true })

const api = useApi()
const auth = useAuthStore()
const subscriptionStore = useSubscriptionStore()
const activating = ref(false)
const trialError = ref('')

const normalizedEmail = computed(() => email.value.trim().toLowerCase())
const emailValid = computed(() => /^\S+@\S+\.\S+$/.test(normalizedEmail.value))
const passwordValid = computed(() => password.value.length >= 6)
const passwordsMatch = computed(() => password.value === confirmPassword.value)
const canActivate = computed(
	() =>
		consentAccepted.value &&
		(props.authenticated || (emailValid.value && passwordValid.value && passwordsMatch.value)),
)

watchEffect(() => {
	if (props.authenticated && !email.value) {
		email.value = props.accountEmail
	}
})

function messageForError(code: string) {
	switch (code) {
		case 'DEMO_ALREADY_ACTIVE':
			return 'Пробный доступ для этого аккаунта уже активен.'
		case 'DEMO_DISABLED':
			return 'Пробный доступ сейчас недоступен.'
		case 'ACTIVE_SUBSCRIPTION':
			return 'У вас уже есть активный доступ. Пробный период не требуется.'
		case 'AUTH_ERROR':
		case 'UNAUTHORIZED':
			return 'Не удалось подтвердить аккаунт. Проверьте email и пароль.'
		default:
			return 'Не удалось активировать пробный доступ. Попробуйте ещё раз.'
	}
}

async function activateTrial() {
	if (activating.value) return
	trialError.value = ''

	if (!props.authenticated && !emailValid.value) {
		trialError.value = 'Введите корректный email для пробного доступа.'
		return
	}
	if (!props.authenticated && !passwordValid.value) {
		trialError.value = 'Пароль должен быть не короче 6 символов.'
		return
	}
	if (!props.authenticated && !passwordsMatch.value) {
		trialError.value = 'Пароли не совпадают.'
		return
	}
	if (!consentAccepted.value) {
		trialError.value = 'Подтвердите согласие с документами.'
		return
	}

	activating.value = true
	try {
		const request = buildDemoAccessRequest({
			authenticated: props.authenticated,
			email: normalizedEmail.value,
			password: password.value,
		})
		const response =
			'body' in request
				? await api.post<{ redirectTo: string }>(request.endpoint, request.body)
				: await api.post<{ redirectTo: string }>(request.endpoint)

		if (!response.success) {
			trialError.value = messageForError(response.error.code)
			return
		}

		auth.invalidateUser()
		await auth.loadUser(true)
		subscriptionStore.invalidate()
		await subscriptionStore.fetchSubscription(true)
		await navigateTo(response.data.redirectTo || '/app')
	} finally {
		activating.value = false
	}
}
</script>

<template>
	<section class="trial-panel" aria-labelledby="trial-title" :aria-busy="activating">
		<div class="trial-summary">
			<div>
				<p class="trial-kicker">Пробный доступ</p>
				<h2 id="trial-title">{{ days }} дней бесплатно</h2>
				<p>Без карты и автоматических списаний.</p>
			</div>
			<button type="button" class="trial-back" :disabled="activating" @click="emit('back')">Изменить</button>
		</div>

		<fieldset class="trial-fields" :disabled="activating">
			<div class="trial-form-block">
				<div class="trial-section-head">
					<span />
					<h3>Данные для доступа</h3>
				</div>
				<div class="trial-form-grid">
					<label class="trial-field">
						<span>Email</span>
						<input
							v-model="email"
							type="email"
							autocomplete="email"
							placeholder="name@example.com"
							:disabled="authenticated"
							required
						/>
					</label>
					<template v-if="!authenticated">
						<label class="trial-field">
							<span>Пароль для входа</span>
							<SecurePasswordField
								v-model="password"
								placeholder="Не менее 6 символов"
								autocomplete="new-password"
								:minlength="6"
								:invalid="Boolean(password) && (!passwordValid || !passwordsMatch)"
							/>
						</label>
						<label class="trial-field">
							<span>Повторите пароль</span>
							<SecurePasswordField
								v-model="confirmPassword"
								placeholder="Повторите пароль"
								autocomplete="new-password"
								:minlength="6"
								:invalid="Boolean(confirmPassword) && !passwordsMatch"
							/>
						</label>
						<p class="trial-password-note">Этот пароль будет использоваться для входа в клуб.</p>
					</template>
				</div>
			</div>

			<div class="trial-form-block">
				<LegalConsent v-model="consentAccepted" scope="payment" />
			</div>
		</fieldset>

		<p v-if="trialError" class="trial-error" role="alert">{{ trialError }}</p>
		<button type="button" class="trial-activate" :disabled="activating || !canActivate" @click="activateTrial">
			<span>{{ activating ? 'Активируем доступ...' : `Активировать на ${days} дней` }}</span>
			<svg v-if="!activating" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
				<path d="M5 12h14m-6-6 6 6-6 6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
			</svg>
		</button>
	</section>
</template>

<style scoped>
.trial-panel { display: grid; gap: 0.9rem; margin-top: 0.25rem; border: 1px solid var(--app-border); border-radius: 1.45rem; background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 34%), linear-gradient(155deg, var(--app-surface), var(--app-bg)); padding: 1rem; box-shadow: inset 0 1px color-mix(in srgb, var(--app-surface) 96%, transparent), var(--app-shadow-soft); }
.trial-fields { display: grid; gap: 0.9rem; min-width: 0; margin: 0; border: 0; padding: 0; }
.trial-summary { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 1rem; align-items: center; border: 1px solid var(--app-border); border-radius: 1.15rem; background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface)); padding: 0.9rem; }
.trial-kicker { color: var(--app-accent-strong); font-size: 0.68rem; font-weight: 750; letter-spacing: 0.14em; text-transform: uppercase; }
.trial-summary h2 { margin-top: 0.2rem; color: var(--app-text-strong); font-size: 1rem; font-weight: 800; }
.trial-summary p:last-child { margin-top: 0.18rem; color: var(--app-muted); font-size: 0.78rem; font-weight: 650; }
.trial-back { border: 1px solid var(--app-border-strong); border-radius: 999px; background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface)); padding: 0.46rem 0.7rem; color: var(--app-accent-strong); font-size: 0.74rem; font-weight: 700; }
.trial-form-block { border: 1px solid var(--app-border); border-radius: 1.15rem; background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface)); padding: 0.9rem; }
.trial-form-block:empty { display: none; }
.trial-section-head { display: flex; gap: 0.65rem; align-items: center; margin-bottom: 0.75rem; }
.trial-section-head span { width: 1.75rem; height: 1px; background: var(--app-accent); }
.trial-section-head h3, .trial-field > span { color: var(--app-accent-strong); font-size: 0.74rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; }
.trial-form-grid { display: grid; gap: 0.75rem; }
.trial-field { display: grid; gap: 0.38rem; }
.trial-field > span { color: var(--app-muted); letter-spacing: 0.08em; }
.trial-field input { width: 100%; border: 1px solid var(--app-border); border-radius: 1rem; background: var(--app-surface); padding: 0.82rem 0.9rem; color: var(--app-text); font-size: 0.92rem; outline: none; transition: border-color 0.18s ease, background 0.18s ease, box-shadow 0.18s ease; }
.trial-field input:focus { border-color: var(--app-accent); background: color-mix(in srgb, var(--app-accent) 7%, var(--app-surface)); box-shadow: 0 0 0 3px color-mix(in srgb, var(--app-accent) 12%, transparent); }
.trial-field input:disabled { cursor: not-allowed; opacity: 0.7; background: var(--app-bg-deep); color: var(--app-muted); }
.trial-password-note { color: var(--app-muted); font-size: 0.76rem; line-height: 1.45; }
.trial-error { border: 1px solid color-mix(in srgb, var(--app-danger) 28%, var(--app-border)); border-radius: 1rem; background: color-mix(in srgb, var(--app-danger) 7%, var(--app-surface)); padding: 0.85rem 1rem; color: var(--app-danger); font-size: 0.86rem; }
.trial-activate { display: flex; width: 100%; min-height: 3.2rem; align-items: center; justify-content: center; gap: 0.45rem; border: 1px solid var(--app-border-strong); border-radius: 1rem; background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent)); padding: 0.86rem 1rem; color: var(--app-button-fg); font-size: 0.9rem; font-weight: 750; box-shadow: var(--app-shadow-raised); transition: transform 0.18s ease, opacity 0.18s ease; }
.trial-activate svg { width: 1rem; height: 1rem; }
.trial-activate:focus-visible, .trial-back:focus-visible { outline: 2px solid var(--app-accent); outline-offset: 3px; }
.trial-activate:not(:disabled):active, .trial-back:not(:disabled):active { transform: scale(0.98); }
.trial-activate:disabled, .trial-back:disabled { cursor: not-allowed; opacity: 0.62; }
@media (max-width: 560px) { .trial-summary { grid-template-columns: 1fr; } .trial-back { justify-self: start; } }
</style>
