<script setup lang="ts">
definePageMeta({ layout: 'auth' })

const route = useRoute()
const code = computed(() =>
	String(route.params.code ?? '')
		.trim()
		.toLowerCase(),
)

onMounted(async () => {
	if (!/^[a-f0-9]{10}$/.test(code.value)) {
		await navigateTo('/app', { replace: true })
		return
	}
	localStorage.setItem('referral_code', code.value)
	await navigateTo({ path: '/app/payment', query: { ref: code.value } }, { replace: true })
})
</script>

<template>
	<div class="text-center text-sm text-[var(--app-muted)]">Открываем приглашение...</div>
</template>
