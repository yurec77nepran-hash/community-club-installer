<script setup lang="ts">
definePageMeta({ layout: false })

const route = useRoute()
const hasCheckoutReturn = route.query.checkout === 'success' || route.query.checkout === 'fail'

onMounted(() => {
	void navigateTo(
		hasCheckoutReturn
			? {
					path: '/app',
					query: route.query,
				}
			: '/app',
		{ replace: true },
	)
})
</script>

<template>
	<div class="min-h-screen bg-[var(--app-bg)]" />
</template>
