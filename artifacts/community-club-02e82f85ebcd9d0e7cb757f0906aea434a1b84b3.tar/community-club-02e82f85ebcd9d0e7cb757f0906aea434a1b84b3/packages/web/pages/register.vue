<script setup lang="ts">
import SecurePasswordField from '~/components/auth/SecurePasswordField.vue'
import LegalConsent from '~/components/legal/LegalConsent.vue'

definePageMeta({ layout: 'auth' })

const route = useRoute()
const password = ref('')
const confirmPassword = ref('')
const fullName = ref('')
const email = ref('')
const loading = ref(false)
const error = ref('')
const legalConsentAccepted = ref(false)

const api = useApi()
const auth = useAuthStore()

function clearEntryFlowState() {
	if (!import.meta.client) return
	localStorage.removeItem('club_entry_state_v1')
}

const passwordsMismatch = computed(
	() => confirmPassword.value.length > 0 && password.value !== confirmPassword.value,
)
const emailValid = computed(() => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim()))

async function register() {
	if (!legalConsentAccepted.value) {
		error.value = 'Подтвердите согласие с документами'
		return
	}
	if (passwordsMismatch.value) {
		error.value = 'Пароль должен совпадать'
		return
	}

	loading.value = true
	error.value = ''
	try {
		const res = await api.post<{ expiresAt: number }>('/api/auth/register', {
			password: password.value,
			fullName: fullName.value.trim(),
			email: email.value.trim(),
		})
		if (res.success) {
			auth.setTokens('', '')
			await auth.loadUser(true)
			clearEntryFlowState()
			const tariff = typeof route.query.tariff === 'string' ? route.query.tariff : null
			if (tariff) {
				navigateTo({ path: '/app/payment', query: { tariff } })
			} else {
				navigateTo('/app')
			}
		} else {
			error.value = res.error?.message ?? 'Ошибка регистрации'
		}
	} finally {
		loading.value = false
	}
}
</script>

<template>
	<div>
		<h2 class="text-xl font-semibold text-center mb-6 text-[var(--app-text-strong)]">Регистрация</h2>

		<form @submit.prevent="register" class="space-y-4">
			<input
				v-model="fullName"
				type="text"
				placeholder="Имя"
				class="w-full px-4 py-3 rounded-xl glass-input"
				required
			/>
			<input
				v-model="email"
				type="email"
				placeholder="Email"
				autocomplete="email"
				class="w-full px-4 py-3 rounded-xl glass-input"
				required
			/>
			<SecurePasswordField
				v-model="password"
				placeholder="Пароль (мин. 6 символов)"
				autocomplete="new-password"
				:minlength="6"
				:invalid="passwordsMismatch"
				required
			/>
			<SecurePasswordField
				v-model="confirmPassword"
				placeholder="Подтвердите пароль"
				autocomplete="new-password"
				:minlength="6"
				:invalid="passwordsMismatch"
				required
			/>
			<LegalConsent v-model="legalConsentAccepted" scope="auth" />
			<button
				type="submit"
				:disabled="loading || !legalConsentAccepted || fullName.trim().length < 2 || !emailValid || password.length < 6 || confirmPassword.length < 6 || passwordsMismatch"
				class="w-full py-3 btn-primary disabled:opacity-50"
			>
				{{ loading ? 'Регистрация...' : 'Зарегистрироваться' }}
			</button>
		</form>

		<p v-if="passwordsMismatch" class="mt-4 text-center text-sm text-[var(--app-danger)]">
			Пароль должен совпадать
		</p>
		<p v-if="error" class="mt-4 text-sm text-[var(--app-danger)] text-center">{{ error }}</p>

		<p class="mt-6 text-center text-sm text-[var(--app-muted)]">
			Уже есть аккаунт?
			<NuxtLink
				:to="{
					path: '/login',
					query: {
						email: email.trim() || undefined,
						tariff: typeof route.query.tariff === 'string' ? route.query.tariff : undefined,
					},
				}"
				class="text-[var(--app-accent-strong)] hover:underline"
			>
				Войти
			</NuxtLink>
		</p>
	</div>
</template>
