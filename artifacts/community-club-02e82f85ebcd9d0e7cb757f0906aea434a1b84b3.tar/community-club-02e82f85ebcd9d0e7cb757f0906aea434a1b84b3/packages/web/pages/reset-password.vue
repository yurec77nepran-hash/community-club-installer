<script setup lang="ts">
import SecurePasswordField from '~/components/auth/SecurePasswordField.vue'

definePageMeta({ layout: 'auth' })

const route = useRoute()
const api = useApi()

const email = ref('')
const newPassword = ref('')
const confirmPassword = ref('')
const loading = ref(false)
const error = ref('')
const success = ref('')

const token = computed(() =>
	typeof route.query.token === 'string' && route.query.token.length > 0 ? route.query.token : '',
)
const isResetMode = computed(() => token.value.length > 0)
const passwordsMismatch = computed(
	() => confirmPassword.value.length > 0 && newPassword.value !== confirmPassword.value,
)

onMounted(() => {
	const queryEmail = route.query.email
	if (typeof queryEmail === 'string' && queryEmail) {
		email.value = queryEmail
	}
})

async function requestReset() {
	loading.value = true
	error.value = ''
	success.value = ''

	try {
		const res = await api.post<{ message: string }>('/api/auth/forgot-password', {
			email: email.value,
		})

		if (res.success) {
			success.value =
				res.data.message ||
				'Если аккаунт с таким email существует, письмо со ссылкой уже отправлено'
		} else {
			error.value = res.error?.message ?? 'Не удалось отправить письмо'
		}
	} catch {
		error.value = 'Не удалось отправить письмо'
	} finally {
		loading.value = false
	}
}

async function resetPassword() {
	if (passwordsMismatch.value) {
		error.value = 'Пароль должен совпадать'
		return
	}

	loading.value = true
	error.value = ''
	success.value = ''

	try {
		const res = await api.post<{ message: string }>('/api/auth/reset-password', {
			token: token.value,
			newPassword: newPassword.value,
		})

		if (res.success) {
			success.value = res.data.message || 'Пароль успешно обновлён'
			setTimeout(() => {
				navigateTo({
					path: '/',
					query: { email: email.value || undefined },
				})
			}, 1200)
		} else {
			error.value = res.error?.message ?? 'Не удалось обновить пароль'
		}
	} catch {
		error.value = 'Не удалось обновить пароль'
	} finally {
		loading.value = false
	}
}
</script>

<template>
	<div>
		<h2 class="text-xl font-semibold text-center mb-3 text-[var(--app-text-strong)]">
			{{ isResetMode ? 'Новый пароль' : 'Сброс пароля' }}
		</h2>

		<p class="text-sm text-center text-[var(--app-muted)] mb-6">
			{{
				isResetMode
					? 'Введите новый пароль для входа в Community Club.'
					: 'Укажите email, и мы отправим ссылку для сброса пароля.'
			}}
		</p>

		<form
			v-if="!isResetMode"
			@submit.prevent="requestReset"
			class="space-y-4"
		>
			<input
				v-model="email"
				type="email"
				placeholder="Email"
				autocomplete="email"
				class="w-full px-4 py-3 rounded-xl glass-input"
				required
			/>
			<button
				type="submit"
				:disabled="loading || !email"
				class="w-full py-3 btn-primary disabled:opacity-50"
			>
				{{ loading ? 'Отправка...' : 'Отправить письмо' }}
			</button>
		</form>

		<form
			v-else
			@submit.prevent="resetPassword"
			class="space-y-4"
		>
			<SecurePasswordField
				v-model="newPassword"
				placeholder="Новый пароль"
				autocomplete="new-password"
				:minlength="6"
				:invalid="passwordsMismatch"
				required
			/>
			<SecurePasswordField
				v-model="confirmPassword"
				placeholder="Повторите пароль"
				autocomplete="new-password"
				:minlength="6"
				:invalid="passwordsMismatch"
				required
			/>
			<p v-if="passwordsMismatch" class="text-center text-sm text-[var(--app-danger)]">
				Пароль должен совпадать
			</p>
			<button
				type="submit"
				:disabled="loading || newPassword.length < 6 || confirmPassword.length < 6 || passwordsMismatch"
				class="w-full py-3 btn-primary disabled:opacity-50"
			>
				{{ loading ? 'Сохраняем...' : 'Сохранить пароль' }}
			</button>
		</form>

		<p v-if="error" class="mt-4 text-sm text-[var(--app-danger)] text-center">{{ error }}</p>
		<p v-if="success" class="mt-4 text-sm text-[var(--app-success)] text-center">{{ success }}</p>

		<p class="mt-6 text-center text-sm text-[var(--app-muted)]">
			<NuxtLink
				:to="{ path: '/', query: { email: email || undefined } }"
				class="text-[var(--app-accent-strong)] hover:underline"
			>
				Вернуться ко входу
			</NuxtLink>
		</p>
	</div>
</template>
