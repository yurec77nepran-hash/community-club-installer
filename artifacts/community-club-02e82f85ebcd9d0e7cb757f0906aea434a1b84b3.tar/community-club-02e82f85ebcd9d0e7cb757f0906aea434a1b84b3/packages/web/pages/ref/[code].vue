<script setup lang="ts">
definePageMeta({ layout: 'auth' })

const route = useRoute()
const referralCode = computed(() => route.params.code as string)

onMounted(async () => {
	if (import.meta.client && referralCode.value) {
		localStorage.setItem('referral_code', referralCode.value)
	}
	await navigateTo(
		{ path: '/app/payment', query: { ref: referralCode.value || undefined } },
		{ replace: true },
	)
})
</script>

<template>
	<div class="text-center text-sm text-[var(--app-muted)]">Открываем приглашение...</div>
</template>
