<script setup lang="ts">
definePageMeta({ layout: 'auth' })

const route = useRoute()
const code = computed(() => String(route.params.code ?? '').trim())

onMounted(async () => {
	if (import.meta.client && code.value) {
		localStorage.setItem('referral_code', code.value)
	}
	await navigateTo(
		{ path: '/app/payment', query: { ref: code.value || undefined } },
		{ replace: true },
	)
})
</script>

<template>
	<div class="text-center text-sm text-[var(--app-muted)]">Открываем приглашение...</div>
</template>
