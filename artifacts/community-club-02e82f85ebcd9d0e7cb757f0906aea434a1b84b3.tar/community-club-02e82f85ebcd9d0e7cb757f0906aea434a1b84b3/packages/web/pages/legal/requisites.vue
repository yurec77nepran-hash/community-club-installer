<script setup lang="ts">
const route = useRoute()
const backTarget = computed(() =>
	typeof route.query.back === 'string' && route.query.back ? route.query.back : '/',
)
</script>

<template>
	<div class="min-h-screen bg-[var(--app-bg)] p-4 text-[var(--app-text)]">
		<div class="mx-auto max-w-3xl">
			<div class="mb-6 flex items-center gap-3">
				<NuxtLink :to="backTarget" class="text-[var(--app-muted-soft)] transition hover:text-[var(--app-text)]">
					<svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</NuxtLink>
				<h1 class="text-xl font-bold text-[var(--app-text-strong)]">Реквизиты и контактные данные</h1>
			</div>

			<div class="glass-card p-5 md:p-6">
				<div class="space-y-6 text-sm leading-7 text-[var(--app-muted)]">
					<section>
						<h2 class="mb-3 text-lg font-semibold text-[var(--app-text-strong)]">Индивидуальный предприниматель</h2>
						<p class="text-base font-medium text-[var(--app-text)]">[ФИО или юрлицо]</p>
					</section>

					<section>
						<p>ИНН: 000000000000</p>
						<p>ОГРН: 000000000000000</p>
						<p>Расчётный счёт: 00000000000000000000</p>
						<p class="mt-3">Банк: Название банка</p>
						<p>БИК: 000000000</p>
						<p>Кор. счёт: 00000000000000000000</p>
					</section>

					<section>
						<h2 class="mb-2 text-lg font-semibold text-[var(--app-text-strong)]">Адрес для корреспонденции</h2>
						<p>000000, Россия, город, улица, дом, офис</p>
					</section>

					<section>
						<h2 class="mb-2 text-lg font-semibold text-[var(--app-text-strong)]">Электронная почта</h2>
						<p>
							<a
								href="mailto:info@example.com"
								class="text-[var(--app-accent-strong)] underline decoration-[color-mix(in_srgb,var(--app-accent)_42%,transparent)] underline-offset-4 transition hover:text-[var(--app-text)]"
							>
								info@example.com
							</a>
						</p>
						<p>
							<a
								href="mailto:legal@example.com"
								class="text-[var(--app-accent-strong)] underline decoration-[color-mix(in_srgb,var(--app-accent)_42%,transparent)] underline-offset-4 transition hover:text-[var(--app-text)]"
							>
								legal@example.com
							</a>
						</p>
					</section>

					<section>
						<h2 class="mb-2 text-lg font-semibold text-[var(--app-text-strong)]">Контактный телефон</h2>
						<p>
							<a
								href="tel:+70000000000"
								class="text-[var(--app-accent-strong)] underline decoration-[color-mix(in_srgb,var(--app-accent)_42%,transparent)] underline-offset-4 transition hover:text-[var(--app-text)]"
							>
								+7 000 000-00-00
							</a>
						</p>
					</section>
				</div>
			</div>
		</div>
	</div>
</template>
