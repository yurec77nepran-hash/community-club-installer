<script setup lang="ts">
const route = useRoute()

onMounted(() => {
	const query =
		typeof route.query.email === 'string' && route.query.email
			? { email: route.query.email }
			: undefined

	navigateTo({ path: '/', query, replace: true })
})
</script>

<template>
	<div class="min-h-screen bg-[var(--app-bg)]" />
</template>
