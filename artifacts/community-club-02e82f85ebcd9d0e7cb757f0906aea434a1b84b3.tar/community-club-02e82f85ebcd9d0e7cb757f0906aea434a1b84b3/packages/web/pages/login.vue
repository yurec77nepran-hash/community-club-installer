<script setup lang="ts">
import type { AuthLoginSettings, TelegramBotAuthSettings } from '@community-club/shared/types'
import SecurePasswordField from '~/components/auth/SecurePasswordField.vue'

definePageMeta({ layout: 'auth' })

const route = useRoute()
const email = ref(typeof route.query.email === 'string' ? route.query.email : '')
const password = ref('')
const loading = ref(false)
const error = ref('')
const success = ref('')
const loginSettings = ref<AuthLoginSettings>({
	passwordEnabled: true,
	telegramCodeEnabled: false,
	maxCodeEnabled: false,
	defaultMethod: 'password',
	botAuthEnabled: false,
})
const botAuthSettings = ref<TelegramBotAuthSettings | null>(null)
const botFlowOpen = ref(false)
const botCode = ref('')
const verifyingBot = ref(false)

const api = useApi()
const auth = useAuthStore()

const botLink = computed(() => {
	const handle = botAuthSettings.value?.botHandle?.trim().replace(/^@/, '')
	return handle ? `https://t.me/${handle}` : ''
})
const ownerLink = computed(() => {
	const handle = botAuthSettings.value?.ownerHandle?.trim().replace(/^@/, '')
	return handle ? `https://t.me/${handle}` : ''
})
const botLoginAvailable = computed(
	() => loginSettings.value.botAuthEnabled && Boolean(botLink.value),
)

function clearEntryFlowState() {
	if (!import.meta.client) return
	localStorage.removeItem('club_entry_state_v1')
}

function closeLogin() {
	return navigateTo('/app', { replace: true })
}

onMounted(async () => {
	const settingsRes = await api.get<AuthLoginSettings>('/api/site-settings/auth-login')
	if (settingsRes.success) {
		loginSettings.value = settingsRes.data
	}

	const botSettingsRes = await api.get<TelegramBotAuthSettings>(
		'/api/site-settings/telegram-bot-auth',
	)
	if (botSettingsRes.success) {
		botAuthSettings.value = botSettingsRes.data
	}

	if (auth.user) {
		void navigateTo('/app')
	}
})

watch(
	() => auth.user,
	(user) => {
		if (user) {
			void navigateTo('/app')
		}
	},
)

async function login() {
	loading.value = true
	error.value = ''
	try {
		const res = await api.post<{ expiresAt: number }>('/api/auth/login', {
			email: email.value.trim(),
			password: password.value,
		})
		if (res.success) {
			auth.setTokens('', '')
			await auth.loadUser(true)
			clearEntryFlowState()
			const tariff = typeof route.query.tariff === 'string' ? route.query.tariff : null
			if (tariff) {
				navigateTo({ path: '/app/payment', query: { tariff } })
			} else {
				navigateTo('/app')
			}
		} else {
			error.value = res.error?.message ?? 'Ошибка входа'
		}
	} finally {
		loading.value = false
	}
}

function openBotFlow() {
	botFlowOpen.value = true
	error.value = ''
	success.value = ''
}

function openBotLink() {
	if (botLink.value) {
		window.open(botLink.value, '_blank', 'noopener,noreferrer')
	}
}

async function verifyBotLogin() {
	if (!botCode.value) return
	verifyingBot.value = true
	error.value = ''
	try {
		const res = await api.post<{ redirectTo?: string }>('/api/auth/telegram/verify', {
			code: botCode.value,
		})
		if (res.success) {
			auth.setTokens('', '')
			await auth.loadUser(true)
			clearEntryFlowState()
			const tariff = typeof route.query.tariff === 'string' ? route.query.tariff : null
			navigateTo(tariff ? { path: '/app/payment', query: { tariff } } : '/app')
		} else {
			error.value = res.error?.message ?? 'Не удалось войти'
		}
	} finally {
		verifyingBot.value = false
	}
}
</script>

<template>
	<div class="club-login">
		<button type="button" class="club-login__close" aria-label="Закрыть вход" @click="closeLogin">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m6 6 12 12M18 6 6 18" />
			</svg>
		</button>
		<p class="club-login__kicker">Club App · клуб</p>
		<h2 class="club-login__title">Вход в клуб</h2>
		<p class="club-login__lead">Материалы и возможности участника — в одном месте.</p>

		<form @submit.prevent="login" class="space-y-4">
			<input
				v-model="email"
				type="email"
				placeholder="Email"
				autocomplete="email"
				class="w-full px-4 py-3 rounded-xl glass-input"
				required
			/>
			<SecurePasswordField
				v-model="password"
				placeholder="Пароль"
				autocomplete="current-password"
				required
			/>
			<button type="submit" :disabled="loading" class="club-login__primary disabled:opacity-50">
				{{ loading ? 'Вход...' : 'Войти' }}
			</button>
		</form>

		<div v-if="botLoginAvailable" class="club-login__bot">
			<button v-if="!botFlowOpen" type="button" class="club-login__secondary" @click="openBotFlow">
				Войти через Telegram
			</button>
			<div v-else class="space-y-4">
				<p class="club-login__bot-hint">
					Зайдите в телеграм-бот и запустите его — система вас проверит и выдаст код для входа.
				</p>
				<button type="button" class="club-login__secondary" @click="openBotLink">Перейти в бот</button>
				<input
					v-model="botCode"
					type="text"
					inputmode="numeric"
					placeholder="Код из Telegram"
					autocomplete="one-time-code"
					class="w-full rounded-xl glass-input px-4 py-3"
				/>
				<button
					type="button"
					:disabled="verifyingBot || !botCode"
					class="club-login__primary disabled:opacity-50"
					@click="verifyBotLogin"
				>
					{{ verifyingBot ? 'Проверяю...' : 'Войти' }}
				</button>
			</div>
		</div>

		<p v-if="error" class="club-login__error">{{ error }}</p>
		<p v-else-if="success" class="club-login__success">{{ success }}</p>

		<p class="club-login__note">Вход доступен после оформления участия.</p>
		<a
			v-if="ownerLink"
			:href="ownerLink"
			target="_blank"
			rel="noopener noreferrer"
			class="club-login__owner"
		>
			Написать Олегу Горскому
		</a>
	</div>
</template>

<style scoped>
.club-login { position: relative; }
.club-login__close { position: absolute; top: -0.25rem; right: -0.25rem; display: grid; width: 2.15rem; height: 2.15rem; place-items: center; border: 1px solid var(--app-border-strong); border-radius: 999px; background: var(--app-surface); color: var(--app-muted); transition: color 0.16s ease, border-color 0.16s ease, background 0.16s ease; }
.club-login__close:hover { border-color: var(--app-accent); background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface)); color: var(--app-text); }
.club-login__close svg { width: 1rem; height: 1rem; }
.club-login__kicker { margin: 0; color: var(--app-accent-strong); font-size: 0.62rem; font-weight: 650; letter-spacing: 0.17em; text-align: center; }
.club-login__title { margin: 0.48rem 0 0; color: var(--app-text-strong); font-size: 1.45rem; font-weight: 650; line-height: 1.15; text-align: center; }
.club-login__lead { margin: 0.55rem auto 1.5rem; max-width: 18rem; color: var(--app-muted); font-size: 0.86rem; line-height: 1.45; text-align: center; }
.club-login :deep(.glass-input) { border: 1px solid var(--app-border); border-radius: 0.78rem; background: var(--app-surface); color: var(--app-text); }
.club-login__primary, .club-login__secondary { width: 100%; border-radius: 0.78rem; padding: 0.8rem 1rem; font-size: 0.9rem; font-weight: 700; transition: transform 0.16s ease; }
.club-login__bot { margin-top: 1.15rem; }
.club-login__primary { background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent)); color: var(--app-button-fg); box-shadow: var(--app-shadow-soft); }
.club-login__secondary { border: 1px solid var(--app-border-strong); background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface)); color: var(--app-accent-strong); }
.club-login__primary:active, .club-login__secondary:active { transform: scale(0.98); }
.club-login__error, .club-login__success { margin-top: 1rem; text-align: center; font-size: 0.82rem; }.club-login__error { color: var(--app-danger); }.club-login__success { color: var(--app-success); }
.club-login__bot-hint { margin: 0; color: var(--app-muted); font-size: 0.8rem; line-height: 1.45; text-align: center; }
.club-login__note { margin: 1.45rem 0 0; color: var(--app-muted-soft); font-size: 0.76rem; text-align: center; }
.club-login__owner { display: block; margin: 0.7rem 0 0; color: var(--app-muted); font-size: 0.8rem; text-align: center; text-decoration: underline; text-underline-offset: 0.18em; transition: color 0.16s ease; }
.club-login__owner:hover { color: var(--app-accent-strong); }
</style>
