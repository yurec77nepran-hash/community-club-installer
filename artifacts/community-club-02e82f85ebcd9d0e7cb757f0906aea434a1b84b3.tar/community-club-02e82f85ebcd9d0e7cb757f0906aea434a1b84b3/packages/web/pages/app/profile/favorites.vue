<script setup lang="ts">
import { MATERIAL_TYPES } from '@community-club/shared/constants'
import { getMaterialTheme } from '~/utils/material-theme'

definePageMeta({ middleware: 'auth' })

const favoritesStore = useMaterialFavoritesStore()
const { goBack } = useAppBack('/app/profile')
const loadError = ref('')

function sectionLabel(type: string) {
	return MATERIAL_TYPES[type as keyof typeof MATERIAL_TYPES] ?? type
}

function itemStyle(type: string) {
	const theme = getMaterialTheme(type)
	return { '--favorite-accent': theme.accent, '--favorite-accent-soft': theme.soft }
}

onMounted(async () => {
	try {
		await favoritesStore.fetchFavorites(true)
	} catch (error) {
		loadError.value = error instanceof Error ? error.message : 'Не удалось загрузить избранное'
	}
})
</script>

<template>
	<div class="club-page favorites-page">
		<header class="favorites-page__header">
			<button type="button" class="club-back-button" aria-label="Назад в профиль" @click="goBack('/app/profile')">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m15 19-7-7 7-7" /></svg>
			</button>
			<div><p class="favorites-page__eyebrow">Профиль</p><h1>Избранное</h1></div>
		</header>

		<p class="favorites-page__lead">Материалы, которые вы сохранили. Сначала — добавленные последними.</p>

		<div v-if="favoritesStore.loading" class="favorites-page__state">Загружаю избранное...</div>
		<div v-else-if="loadError" class="favorites-page__state is-error">{{ loadError }}</div>
		<div v-else-if="favoritesStore.items.length === 0" class="favorites-page__empty">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m12 3 2.78 5.64 6.22.9-4.5 4.39 1.06 6.2L12 17.2l-5.56 2.93 1.06-6.2L3 9.54l6.22-.9L12 3Z" /></svg>
			<p>Здесь появятся сохранённые материалы.</p>
		</div>
		<div v-else class="favorites-page__list">
			<NuxtLink v-for="item in favoritesStore.items" :key="item.id" :to="`/app/content/${item.type}/${item.id}`" class="favorite-item" :style="itemStyle(item.type)">
				<div class="favorite-item__visual"><img v-if="item.imageUrl || item.videoCoverUrl" :src="item.imageUrl || item.videoCoverUrl || ''" :alt="item.title" /><span v-else>{{ sectionLabel(item.type).slice(0, 1) }}</span></div>
				<div class="favorite-item__copy"><p>{{ sectionLabel(item.type) }}</p><h2>{{ item.title }}</h2><span v-if="item.subsection">{{ item.subsection }}</span></div>
				<svg class="favorite-item__arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m9 18 6-6-6-6" /></svg>
			</NuxtLink>
		</div>
	</div>
</template>

<style scoped>
.favorites-page { max-width: 42rem; margin: 0 auto; padding: 1rem 1rem 2rem; }
.favorites-page__header { display: flex; gap: 0.85rem; align-items: center; }
.favorites-page__header h1 { margin: 0.12rem 0 0; color: var(--app-text-strong); font-size: 1.25rem; font-weight: 720; }
.favorites-page__eyebrow { margin: 0; color: var(--app-accent-strong); font-size: 0.65rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; }
.favorites-page__lead { max-width: 29rem; margin: 1.1rem 0 1.25rem; color: var(--app-muted); font-size: 0.84rem; line-height: 1.45; }
.favorites-page__list { display: grid; gap: 0.7rem; }
.favorite-item { display: grid; grid-template-columns: 3.8rem minmax(0, 1fr) auto; gap: 0.8rem; align-items: center; min-height: 5.5rem; padding: 0.7rem; border: 1px solid color-mix(in srgb, var(--favorite-accent) 28%, var(--app-border)); border-radius: 1rem; background: linear-gradient(115deg, var(--favorite-accent-soft), var(--app-surface) 62%); color: inherit; text-decoration: none; box-shadow: var(--app-shadow-soft); transition: transform 0.18s ease, border-color 0.18s ease; }
.favorite-item:hover { border-color: color-mix(in srgb, var(--favorite-accent) 58%, var(--app-border)); }
.favorite-item:active { transform: scale(0.985); }
.favorite-item__visual { display: grid; width: 3.8rem; height: 3.8rem; overflow: hidden; place-items: center; border-radius: 0.78rem; background: color-mix(in srgb, var(--favorite-accent) 16%, var(--app-surface)); color: var(--favorite-accent); font-size: 1.35rem; font-weight: 750; }
.favorite-item__visual img { width: 100%; height: 100%; object-fit: cover; }
.favorite-item__copy { min-width: 0; }
.favorite-item__copy p,
.favorite-item__copy span { overflow: hidden; margin: 0; color: var(--favorite-accent); font-size: 0.62rem; font-weight: 700; letter-spacing: 0.06em; text-overflow: ellipsis; text-transform: uppercase; white-space: nowrap; }
.favorite-item__copy h2 { overflow: hidden; margin: 0.25rem 0; color: var(--app-text-strong); font-size: 0.88rem; font-weight: 650; line-height: 1.2; text-overflow: ellipsis; white-space: nowrap; }
.favorite-item__copy span { color: var(--app-muted); }
.favorite-item__arrow { width: 1rem; height: 1rem; color: var(--app-muted-soft); }
.favorites-page__state,
.favorites-page__empty { border: 1px solid var(--app-border); border-radius: 1rem; background: var(--app-surface); padding: 1.25rem; color: var(--app-muted); font-size: 0.84rem; text-align: center; box-shadow: var(--app-shadow-soft); }
.favorites-page__state.is-error { color: var(--app-danger); }
.favorites-page__empty svg { width: 2rem; height: 2rem; margin: 0 auto 0.7rem; color: var(--app-accent-strong); }
</style>
