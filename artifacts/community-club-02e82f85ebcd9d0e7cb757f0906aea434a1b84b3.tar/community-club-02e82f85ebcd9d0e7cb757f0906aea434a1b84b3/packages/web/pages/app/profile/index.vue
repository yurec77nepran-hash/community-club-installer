<script setup lang="ts">
import type { ReferralProgramMyResponse } from '@community-club/shared/types'
import SecurePasswordField from '~/components/auth/SecurePasswordField.vue'
import { AVATAR_FILE_ACCEPT, getAvatarFileError } from '~/utils/avatar-upload'
import { getPasswordChangeFormState } from '~/utils/password-change'

definePageMeta({ middleware: 'auth', keepalive: true })

type AuthUserWithPassword = { hasPassword?: boolean }

const auth = useAuthStore()
const api = useApi()
const route = useRoute()
const push = usePush()
const {
	isSupported: pushSupported,
	isSubscribed: pushSubscribed,
	permission: pushPermission,
	supportReason: pushSupportReason,
} = push
const chatStore = useChatStore()
const subscriptionStore = useSubscriptionStore()
const { subscription, hasActiveSubscription } = storeToRefs(subscriptionStore)

const editing = ref(false)
const fullName = ref('')
const saving = ref(false)
const referralData = ref<ReferralProgramMyResponse | null>(null)
const referralInfoOpen = ref(false)
const uploadingAvatar = ref(false)
const avatarImageBroken = ref(false)
const cropFile = ref<File | null>(null)
const cropOpen = ref(false)
const avatarError = ref('')
const passwordForm = reactive({
	currentPassword: '',
	newPassword: '',
	confirmPassword: '',
})
const passwordError = ref('')
const profileChatsReady = ref(false)

function getCookie(name: string) {
	if (!import.meta.client) return null
	const match = document.cookie
		.split('; ')
		.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
	return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
}
const subscriptionActionLoading = ref(false)
const subscriptionActionError = ref('')
const clubChat = computed(() =>
	profileChatsReady.value
		? (chatStore.chats.find((chat) => chat.slug === 'club-chat') ?? chatStore.chats[0] ?? null)
		: null,
)
const clubChatUnreadCount = computed(() => clubChat.value?.unreadMessageCount ?? 0)
const pushActionLoading = ref(false)
const pushActionError = ref('')
const leaveConfirmStep = ref<0 | 1 | 2>(0)
const logoutConfirmOpen = ref(false)
const hasPassword = computed(
	() => (auth.user as AuthUserWithPassword | null)?.hasPassword !== false,
)

function initForm() {
	fullName.value = auth.user?.fullName ?? ''
	avatarImageBroken.value = false
	tgNotifications.value = Boolean(auth.user?.telegramNotificationsEnabled)
}

const tgNotifications = ref(false)

async function toggleTelegramNotifications() {
	const next = !tgNotifications.value
	const res = await api.patch('/api/users/me', { telegramNotificationsEnabled: next })
	if (res.success) {
		auth.setUser(res.data)
		tgNotifications.value = Boolean(res.data.telegramNotificationsEnabled)
	} else {
		tgNotifications.value = Boolean(auth.user?.telegramNotificationsEnabled)
	}
}

async function saveProfile() {
	if (saving.value) return
	passwordError.value = ''
	const passwordRequested = Boolean(
		passwordForm.currentPassword || passwordForm.newPassword || passwordForm.confirmPassword,
	)

	if (passwordRequested && !passwordFormState.value.canSubmit) {
		passwordError.value = passwordFormState.value.passwordsMismatch
			? 'Пароли не совпадают'
			: hasPassword.value
				? 'Введите текущий пароль и новый пароль не короче 6 символов.'
				: 'Новый пароль должен быть не короче 6 символов.'
		return
	}

	saving.value = true
	try {
		const res = await api.patch('/api/users/me', {
			fullName: fullName.value || undefined,
		})
		if (!res.success) {
			passwordError.value = res.error?.message ?? 'Не удалось сохранить изменения'
			return
		}
		auth.setUser(res.data)

		if (passwordRequested) {
			const response = await api.post<{ message: string }>('/api/auth/change-password', {
				currentPassword: hasPassword.value ? passwordForm.currentPassword : undefined,
				newPassword: passwordForm.newPassword,
			})
			if (!response.success) {
				passwordError.value = response.error?.message ?? 'Не удалось изменить пароль'
				return
			}
			await auth.loadUser(true)
		}

		editing.value = false
		resetPasswordForm()
	} catch {
		passwordError.value = 'Не удалось сохранить изменения'
	} finally {
		saving.value = false
	}
}

async function loadSubscription() {
	await subscriptionStore.fetchSubscription()
}

async function loadReferrals() {
	const res = await api.get<ReferralProgramMyResponse>('/api/referrals/my')
	if (res.success) referralData.value = res.data
}

async function loadChatUnreadCounts() {
	chatStore.setChats([])
	await chatStore.fetchChats(true)
	profileChatsReady.value = true
}

const passwordFormState = computed(() =>
	getPasswordChangeFormState(passwordForm, { currentPasswordRequired: hasPassword.value }),
)

function resetPasswordForm() {
	passwordForm.currentPassword = ''
	passwordForm.newPassword = ''
	passwordForm.confirmPassword = ''
	passwordError.value = ''
}

function openProfileEditor() {
	initForm()
	resetPasswordForm()
	avatarError.value = ''
	editing.value = true
}

function closeProfileEditor() {
	if (saving.value) return
	editing.value = false
	resetPasswordForm()
}

async function enablePushNotifications() {
	if (pushActionLoading.value) return

	if (push.supportReason.value === 'ios_install_required') {
		pushActionError.value =
			'На iPhone откройте клуб через Safari, нажмите Поделиться и выберите «На экран Домой». Затем откройте приложение с иконки и включите уведомления снова.'
		return
	}

	if (push.supportReason.value === 'ios_update_required') {
		pushActionError.value =
			'Для push-уведомлений нужен установленный Home Screen app и актуальная версия iOS с поддержкой Web Push.'
		return
	}

	if (!push.isSupported.value) return

	pushActionLoading.value = true
	pushActionError.value = ''

	try {
		if (!push.isSubscribed.value) {
			const ok = await push.subscribe()
			if (!ok && push.permission.value === 'denied') {
				pushActionError.value = 'Браузер заблокировал уведомления. Разрешите их в настройках сайта.'
			} else if (!ok) {
				pushActionError.value = 'Не удалось включить уведомления. Попробуйте ещё раз.'
			}
		}
		await push.refreshStatus()
	} catch {
		pushActionError.value = 'Не удалось обновить настройки уведомлений.'
	} finally {
		pushActionLoading.value = false
	}
}

async function copyReferralLink() {
	if (!referralData.value?.referralLink) return
	await navigator.clipboard.writeText(referralData.value.referralLink)
	showReferralToast('Ссылка скопирована')
}

const referralToast = ref('')
let referralToastTimer: ReturnType<typeof setTimeout> | null = null

function showReferralToast(message: string) {
	referralToast.value = message
	if (referralToastTimer) clearTimeout(referralToastTimer)
	referralToastTimer = setTimeout(() => {
		referralToast.value = ''
		referralToastTimer = null
	}, 2500)
}

async function shareReferralLink() {
	if (!referralData.value?.referralLink) return
	if (navigator.share) {
		await navigator.share({
			title: 'Community Club',
			text: referralData.value.description || 'Присоединяйся к клубу!',
			url: referralData.value.referralLink,
		})
	} else {
		copyReferralLink()
	}
}

function formatDate(d: string | null) {
	if (!d) return '—'
	return new Date(d).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })
}

const autoPaymentStatusLabel = computed(() =>
	subscription.value?.autoPayment ? 'Автосписание включено' : 'Автосписание отключено',
)

const autoPaymentStatusClass = computed(() =>
	subscription.value?.autoPayment ? 'text-[var(--app-success)]' : 'text-[var(--app-danger)]',
)

function openTariffChange() {
	navigateTo('/app/payment?mode=change')
}

function openProfileRoute(path: string) {
	navigateTo(path)
}

function startLeaveClub() {
	if (!subscriptionActionLoading.value) leaveConfirmStep.value = 1
}

function closeLeaveClub() {
	if (!subscriptionActionLoading.value) leaveConfirmStep.value = 0
}

async function confirmLeaveClub() {
	if (subscriptionActionLoading.value) return
	if (leaveConfirmStep.value === 1) {
		leaveConfirmStep.value = 2
		return
	}

	subscriptionActionLoading.value = true
	subscriptionActionError.value = ''

	const res = await api.post('/api/payments/subscription/leave')
	if (!res.success) {
		subscriptionActionError.value = res.error?.message ?? 'Не удалось выйти из клуба'
		subscriptionActionLoading.value = false
		return
	}

	subscriptionStore.invalidate()
	await Promise.all([auth.loadUser(true), subscriptionStore.fetchSubscription(true)])
	subscriptionActionLoading.value = false
	leaveConfirmStep.value = 0
	await navigateTo('/app/profile')
}

function getAvatarEmoji(value: string | null | undefined) {
	if (!value?.startsWith('emoji:')) return null
	return value.slice('emoji:'.length) || null
}

const avatarEmoji = computed(() => getAvatarEmoji(auth.user?.avatarUrl))
const avatarImageUrl = computed(() =>
	!avatarImageBroken.value && auth.user?.avatarUrl && !auth.user.avatarUrl.startsWith('emoji:')
		? auth.user.avatarUrl
		: null,
)
const userInitial = computed(() => (auth.user?.fullName ?? 'U').trim().charAt(0).toUpperCase())

async function saveAvatarValue(avatarUrl: string) {
	avatarImageBroken.value = false
	const res = await api.patch('/api/users/me', { avatarUrl })
	if (res.success) {
		auth.setUser(res.data)
		return true
	}
	avatarError.value = res.error?.message ?? 'Не удалось сохранить фото. Попробуйте ещё раз.'
	return false
}

function onAvatarSelect(e: Event) {
	const input = e.target as HTMLInputElement
	const file = input.files?.[0]
	input.value = ''
	if (!file) return
	avatarError.value = ''
	const fileError = getAvatarFileError(file)
	if (fileError) {
		avatarError.value = fileError
		return
	}
	cropFile.value = file
	cropOpen.value = true
}

async function onAvatarCrop(blob: Blob) {
	uploadingAvatar.value = true
	avatarError.value = ''
	try {
		const formData = new FormData()
		formData.append('file', blob, 'avatar.jpg')
		formData.append('bucket', 'avatars')
		const csrfToken = getCookie('csrf_token')
		const response = await fetch(`${useRuntimeConfig().public.apiUrl}/api/media/upload`, {
			method: 'POST',
			headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : undefined,
			credentials: 'include',
			body: formData,
		})
		const result = await response.json().catch(() => null)
		if (!response.ok || !result?.success) {
			avatarError.value = result?.error?.message ?? 'Не удалось загрузить фото. Попробуйте ещё раз.'
			return
		}
		await saveAvatarValue(result.data.path)
	} catch {
		avatarError.value = 'Не удалось загрузить фото. Проверьте подключение и попробуйте ещё раз.'
	} finally {
		cropFile.value = null
		uploadingAvatar.value = false
	}
}

function onAvatarCropError(message: string) {
	cropFile.value = null
	avatarError.value = message
}

function openLogoutConfirmation() {
	logoutConfirmOpen.value = true
}

async function logout() {
	logoutConfirmOpen.value = false
	try {
		await api.post('/api/auth/logout')
	} finally {
		auth.logout()
		await navigateTo('/login')
	}
}

function onAvatarImageError() {
	avatarImageBroken.value = true
}

onMounted(() => {
	initForm()
	subscriptionStore.fetchSubscription()
	loadReferrals()
	loadChatUnreadCounts()
	push.refreshStatus()
	if (route.query.setupPassword === '1' && !hasPassword.value) {
		openProfileEditor()
	}
})

onActivated(() => {
	void push.refreshStatus()
})
</script>

<template>
	<div class="club-page profile-page">
		<section class="profile-account-card mb-4">
			<div class="profile-account-main">
				<div class="profile-avatar h-20 w-20 shrink-0 rounded-full flex items-center justify-center" :aria-busy="uploadingAvatar">
					<img
						v-if="avatarImageUrl"
						:src="avatarImageUrl"
						class="w-full h-full rounded-full object-cover"
						@error="onAvatarImageError"
					/>
						<span v-else-if="avatarEmoji" class="text-3xl leading-none">{{ avatarEmoji }}</span>
						<span v-else class="text-2xl text-[var(--app-text-strong)] font-bold">{{ userInitial }}</span>
					</div>
					<div class="min-w-0 flex-1">
					<div class="flex items-center gap-2">
						<h1 class="truncate text-lg font-bold text-[var(--app-text-strong)]">{{ auth.user?.fullName ?? 'Пользователь' }}</h1>
						<button type="button" class="profile-name-edit-button" aria-label="Редактировать профиль" @click="openProfileEditor">
							<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m13.5 5.5 5 5M4 20l4.1-.9L19 8.2a2.12 2.12 0 0 0-3-3L5.1 16.1 4 20Z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m14.5 6.5 3 3" /></svg>
						</button>
					</div>
					<p class="mt-1 truncate text-sm text-[var(--app-muted)]">{{ auth.user?.email }}</p>
				</div>
			</div>
			<div class="profile-account-divider" />
			<button
				type="button"
				class="profile-account-action profile-push-row disabled:opacity-50 disabled:cursor-not-allowed"
				:class="{ 'profile-push-row-active': pushSubscribed && pushPermission === 'granted' }"
				:disabled="(pushSupportReason === 'unsupported' && !pushSupported) || pushActionLoading"
				@click="enablePushNotifications"
			>
				<span class="profile-push-icon" aria-hidden="true">
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 17h5l-1.4-1.6V11a6.6 6.6 0 0 0-5-6.4V4a1.6 1.6 0 1 0-3.2 0v.6a6.6 6.6 0 0 0-5 6.4v4.4L4 17h5m6 0a3 3 0 0 1-6 0" /></svg>
				</span>
				<span class="min-w-0">
					<span class="profile-push-title">Уведомления</span>
					<span class="profile-push-subtitle">Новости и обновления клуба</span>
				</span>
				<span class="profile-push-status">{{ pushPermission === 'denied' ? 'Заблокированы' : !pushSupported ? 'Недоступны' : pushSubscribed && pushPermission === 'granted' ? 'Включены' : 'Включить' }}</span>
				<svg class="h-4 w-4 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" /></svg>
			</button>
			<label
				v-if="auth.user?.telegramChatId"
				class="mt-3 flex items-center gap-2 text-sm text-[var(--app-muted)]"
			>
				<input
					type="checkbox"
					class="h-4 w-4 accent-[var(--app-accent)]"
					:checked="tgNotifications"
					@change="toggleTelegramNotifications"
				/>
				<span>Уведомлять в Telegram</span>
			</label>
			<p v-if="pushActionError" class="mt-3 text-xs leading-5 text-[var(--app-danger)]">{{ pushActionError }}</p>
		</section>

		<section id="referrals" v-if="referralData?.enabled" class="club-card profile-spotlight-card profile-referral-card p-4 mb-4">
			<div class="profile-spotlight-summary">
				<div class="min-w-0">
					<div class="flex items-start justify-between gap-2">
						<h2 class="profile-section-title">Приглашайте друзей</h2>
						<button type="button" class="profile-referral-help" aria-label="Как работают начисления" @click="referralInfoOpen = !referralInfoOpen">?</button>
					</div>
					<p class="mt-2 text-sm leading-6 text-[var(--app-muted)]">Получайте 10% от их оплат на свой счёт пожизненно, пока партнёр находится в клубе.</p>
				</div>
				<div class="profile-spotlight-visual profile-referral-visual" aria-hidden="true">
					<img class="profile-spotlight-art" src="/images/profile/referral-portal-detail.webp" alt="" />
				</div>
			</div>
			<p v-if="referralInfoOpen" class="profile-referral-tip">Все заработанные деньги можно потратить на продление клуба или покупку других продуктов Олега Горского.</p>
			<div class="profile-referral-link mt-4">{{ referralData.referralLink }}</div>
			<div class="grid grid-cols-2 gap-2 mt-3">
				<div class="profile-referral-stat"><span>Приглашено</span><strong>{{ referralData.totalReferred }}</strong></div>
				<div class="profile-referral-stat"><span>Заработано</span><strong>{{ Number(referralData.totalBonus || 0).toLocaleString('ru-RU') }} ₽</strong></div>
			</div>
			<div class="mt-3">
				<button type="button" class="profile-referral-copy" @click="copyReferralLink">
					<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7Z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M5 20h14" /></svg>
					Скопировать реферальную ссылку
				</button>
			</div>
			<div v-if="referralToast" class="profile-referral-toast">{{ referralToast }}</div>
		</section>

		<!-- Subscription -->
		<div class="club-card profile-spotlight-card profile-tariff-card p-4 mb-4">
			<div class="profile-spotlight-summary profile-tariff-summary">
				<div class="min-w-0">
					<h4 class="profile-section-title">Мой тариф</h4>
					<template v-if="subscription && hasActiveSubscription">
						<p class="text-sm text-[var(--app-muted)]">Тариф: <span class="text-[var(--app-text-strong)] font-medium">{{ subscription.tarrif ?? 'Не определён' }}</span></p>
						<p class="text-sm text-[var(--app-muted)]">Активна до: <span class="text-[var(--app-text-strong)] font-medium">{{ formatDate(subscription.dateFinish) }}</span></p>
						<p class="mt-1 text-sm" :class="autoPaymentStatusClass">{{ autoPaymentStatusLabel }}</p>
					</template>
					<p v-else class="text-sm text-[var(--app-muted-soft)]">Нет активной подписки</p>
				</div>
				<div class="profile-spotlight-visual profile-tariff-visual" aria-hidden="true">
					<img class="profile-spotlight-art" src="/images/profile/tariff-case-detail.webp" alt="" />
				</div>
			</div>
			<div class="mt-2 space-y-2">
				<button
					class="profile-tariff-action w-full py-2 text-sm disabled:opacity-50"
					:disabled="subscriptionActionLoading"
					@click="openTariffChange"
				>
					Изменить тариф
				</button>
				<button
					class="w-full py-2 text-[var(--app-danger)] border border-[color-mix(in_srgb,var(--app-danger)_24%,var(--app-border))] rounded-xl text-sm glass disabled:opacity-50"
					:disabled="subscriptionActionLoading"
					@click="startLeaveClub"
				>
					{{ subscriptionActionLoading && !subscription?.autoPayment ? 'Закрываем доступ...' : 'Выйти из клуба' }}
				</button>
			</div>
			<p v-if="subscriptionActionError" class="mt-3 text-sm text-[var(--app-danger)]">
				{{ subscriptionActionError }}
			</p>
		</div>

		<!-- Chats -->
		<div class="club-card p-4 mb-4">
			<div class="profile-account-menu">
				<button type="button" class="profile-bottom-row w-full text-left transition" @click="openProfileRoute('/app/chats')">
					<span class="profile-bottom-icon" aria-hidden="true"><svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M8 10h8m-8 4h5m-6.5 6L4 20V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9.5l-2.4 2.4a1 1 0 0 1-.6.6Z" /></svg></span>
					<span class="min-w-0 flex-1">
						<span class="profile-link-title">Чаты профиля</span>
						<span v-if="clubChatUnreadCount > 0" class="profile-chat-unread">{{ clubChatUnreadCount > 99 ? '99+' : clubChatUnreadCount }}</span>
					</span>
					<svg class="h-4 w-4 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" /></svg>
				</button>
				<div class="profile-account-menu-divider" />
				<button type="button" class="profile-bottom-row w-full text-left transition" @click="openProfileRoute('/app/feed')">
					<span class="profile-bottom-icon" aria-hidden="true"><svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M4 6h16M4 12h16M4 18h10" /></svg></span>
					<span class="min-w-0 flex-1"><span class="profile-link-title">Лента новостей</span></span>
					<svg class="h-4 w-4 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" /></svg>
				</button>
			</div>
		</div>

		<div class="club-card p-4 mb-4">
			<div class="profile-account-menu">
				<button type="button" class="profile-bottom-row profile-favorites-row w-full text-left transition" @click="openProfileRoute('/app/profile/favorites')">
					<span class="profile-bottom-icon profile-favorites-icon" aria-hidden="true"><svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m12 3 2.78 5.64 6.22.9-4.5 4.39 1.06 6.2L12 17.2l-5.56 2.93 1.06-6.2L3 9.54l6.22-.9L12 3Z" /></svg></span>
					<span class="min-w-0 flex-1"><span class="profile-link-title">Избранное</span></span>
					<svg class="h-4 w-4 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" /></svg>
				</button>
				<div class="profile-account-menu-divider" />
				<button type="button" class="profile-bottom-row profile-support-row w-full text-left transition" @click="openProfileRoute('/app/support')">
					<span class="profile-bottom-icon profile-support-icon" aria-hidden="true"><svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M4 13a8 8 0 0 1 16 0v4a2 2 0 0 1-2 2h-2v-5h3M4 14h3v5H6a2 2 0 0 1-2-2v-4Zm7 5h2" /></svg></span>
					<span class="min-w-0 flex-1"><span class="profile-link-title">Чат поддержки</span></span>
					<svg class="h-4 w-4 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" /></svg>
				</button>
				<div class="profile-account-menu-divider profile-account-menu-divider-danger" />
				<button type="button" class="profile-bottom-row profile-logout-row w-full text-left transition" @click="openLogoutConfirmation">
					<span class="profile-bottom-icon profile-logout-icon" aria-hidden="true"><svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M10 17l5-5-5-5m5 5H3m9-8h5a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5" /></svg></span>
					<span class="min-w-0 flex-1"><span class="profile-link-title profile-logout-title">Выйти из аккаунта</span></span>
					<svg class="h-4 w-4 text-[color-mix(in_srgb,var(--app-danger)_70%,transparent)]" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 18 6-6-6-6" /></svg>
				</button>
			</div>
		</div>

		<Teleport to="body">
			<div
				v-if="editing"
				class="profile-modal-shell"
				role="dialog"
				aria-modal="true"
				aria-labelledby="profile-editor-title"
				@click.self="closeProfileEditor"
			>
				<div class="profile-modal">
					<button
						type="button"
						class="profile-modal-close"
						aria-label="Закрыть"
						@click="closeProfileEditor"
					>
						<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
						</svg>
					</button>
					<h3 id="profile-editor-title" class="profile-modal-title">Изменить профиль</h3>
					<form class="mt-5 space-y-4" @submit.prevent="saveProfile">
						<div>
							<label class="profile-password-label" for="profile-full-name">Имя</label>
							<input id="profile-full-name" v-model="fullName" type="text" class="w-full px-4 py-2.5 rounded-xl glass-input text-sm" autocomplete="name" />
						</div>
						<label class="profile-upload-link" :class="{ 'profile-file-control-disabled': uploadingAvatar }">
							<input type="file" :accept="AVATAR_FILE_ACCEPT" class="profile-file-input" :disabled="uploadingAvatar" aria-label="Загрузить фото" @change="onAvatarSelect" />
							{{ uploadingAvatar ? 'Загружаем фото…' : 'Загрузить фото' }}
						</label>
					<p v-if="avatarError" class="text-sm text-[var(--app-danger)]" role="alert">{{ avatarError }}</p>
						<div class="profile-modal-divider" />
						<p class="profile-modal-section-title">Пароль</p>
						<div v-if="hasPassword">
							<label class="profile-password-label" for="profile-current-password">Текущий пароль</label>
							<SecurePasswordField
								id="profile-current-password"
								v-model="passwordForm.currentPassword"
								placeholder="Введите текущий пароль"
								autocomplete="current-password"
							/>
						</div>
						<div>
							<label class="profile-password-label" for="profile-new-password">Новый пароль</label>
							<SecurePasswordField
								id="profile-new-password"
								v-model="passwordForm.newPassword"
								placeholder="Введите новый пароль"
								autocomplete="new-password"
								:minlength="6"
								:invalid="passwordFormState.passwordsMismatch"
							/>
						</div>
						<div>
							<label class="profile-password-label" for="profile-confirm-password">Повторить пароль</label>
							<SecurePasswordField
								id="profile-confirm-password"
								v-model="passwordForm.confirmPassword"
								placeholder="Повторите новый пароль"
								autocomplete="new-password"
								:minlength="6"
								:invalid="passwordFormState.passwordsMismatch"
							/>
						</div>
						<p v-if="passwordFormState.passwordsMismatch" class="text-sm text-[var(--app-danger)]">
							Пароли не совпадают
						</p>
						<button type="submit" class="w-full py-3 btn-primary text-sm disabled:cursor-not-allowed disabled:opacity-50" :disabled="saving">
							{{ saving ? 'Сохраняем...' : 'Сохранить' }}
						</button>
						<p v-if="passwordError" class="text-sm text-[var(--app-danger)]">{{ passwordError }}</p>
					</form>
				</div>
			</div>

			<div v-if="leaveConfirmStep" class="profile-modal-shell" role="dialog" aria-modal="true" aria-labelledby="profile-leave-title" @click.self="closeLeaveClub">
				<div class="profile-confirm-modal">
					<h3 id="profile-leave-title" class="profile-modal-title">Выйти из клуба?</h3>
					<p v-if="leaveConfirmStep === 1" class="profile-confirm-copy">Ваше участие будет аннулировано, и для нового входа потребуется заново оплатить доступ.</p>
					<p v-else class="profile-confirm-copy">Вы на 100% уверены? Это необратимое действие.</p>
					<div class="profile-confirm-actions">
						<button type="button" class="btn-glass" :disabled="subscriptionActionLoading" @click="closeLeaveClub">Нет</button>
						<button type="button" class="profile-confirm-danger" :disabled="subscriptionActionLoading" @click="confirmLeaveClub">{{ subscriptionActionLoading ? 'Выходим...' : 'Да' }}</button>
					</div>
				</div>
			</div>

			<div v-if="logoutConfirmOpen" class="profile-modal-shell" role="dialog" aria-modal="true" aria-labelledby="profile-logout-title" @click.self="logoutConfirmOpen = false">
				<div class="profile-confirm-modal">
					<h3 id="profile-logout-title" class="profile-modal-title">Выйти из аккаунта?</h3>
					<p class="profile-confirm-copy">Вы точно хотите выйти из аккаунта?</p>
					<div class="profile-confirm-actions">
						<button type="button" class="btn-glass" @click="logoutConfirmOpen = false">Нет</button>
						<button type="button" class="profile-confirm-danger" @click="logout">Да</button>
					</div>
				</div>
			</div>
		</Teleport>
	</div>
	<UiAvatarCropModal v-model:open="cropOpen" :file="cropFile" @crop="onAvatarCrop" @error="onAvatarCropError" />
</template>

<style scoped>
	.profile-page {
	max-width: 46rem;
	margin: 0 auto;
}

.profile-account-card {
	position: relative;
	padding: 1.1rem;
	border: 1px solid var(--app-border);
	border-radius: 1.35rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 8%, transparent), transparent 32%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}

.profile-account-main { display: flex; align-items: center; gap: 1rem; }

.profile-account-divider {
	height: 1px;
	margin: 1rem 0 0.55rem;
	background: var(--app-border);
}

.profile-upload-link {
	position: relative;
	display: flex;
	min-height: 2.75rem;
	align-items: center;
	justify-content: center;
	border: 1px dashed var(--app-border-strong);
	border-radius: 0.9rem;
	background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface));
	padding: 0 1rem;
	color: var(--app-accent-strong);
	font-size: 0.77rem;
	font-weight: 600;
}

.profile-file-input {
	position: absolute;
	inset: 0;
	z-index: 2;
	width: 100%;
	height: 100%;
	opacity: 0;
	cursor: pointer;
}

.profile-file-control-disabled {
	opacity: 0.6;
}

.profile-file-control-disabled .profile-file-input {
	cursor: default;
}

.profile-account-action {
	display: grid;
	width: 100%;
	min-height: 4rem;
	align-items: center;
	border-radius: 1rem;
	font-size: 0.78rem;
	font-weight: 700;
}

.profile-push-row {
	grid-template-columns: 2.35rem minmax(0, 1fr) auto 0.8rem;
	gap: 0.65rem;
	border: 1px solid var(--app-border);
	background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface));
	padding: 0.65rem 0.7rem;
	text-align: left;
	color: var(--app-text);
}

.profile-push-row-active { border-color: color-mix(in srgb, var(--app-success) 35%, var(--app-border)); background: color-mix(in srgb, var(--app-success) 7%, var(--app-surface)); }

.profile-push-icon,
.profile-bottom-icon {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	border-radius: 0.8rem;
}

.profile-push-icon {
	width: 2.35rem;
	height: 2.35rem;
	border: 1px solid var(--app-border-strong);
	background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface));
	color: var(--app-accent-strong);
}

.profile-push-title,
.profile-push-subtitle,
.profile-bottom-subtitle { display: block; }
.profile-push-title { color: var(--app-text-strong); font-size: 0.84rem; }
.profile-push-subtitle,
.profile-bottom-subtitle { margin-top: 0.13rem; color: var(--app-muted); font-size: 0.69rem; font-weight: 500; line-height: 1.25; }
.profile-push-status { border-radius: 999px; background: color-mix(in srgb, var(--app-accent) 10%, var(--app-surface)); padding: 0.34rem 0.5rem; color: var(--app-accent-strong); font-size: 0.64rem; white-space: nowrap; }
.profile-push-row-active .profile-push-status { background: color-mix(in srgb, var(--app-success) 12%, var(--app-surface)); color: var(--app-success); }

.profile-referral-card {
	border-color: var(--app-border) !important;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 8%, transparent), transparent 32%), linear-gradient(155deg, var(--app-surface), var(--app-bg)) !important;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft) !important;
}

.profile-spotlight-card {
	overflow: hidden;
}

.profile-spotlight-summary {
	display: grid;
	grid-template-columns: minmax(0, 1fr) 8.25rem;
	gap: 0.5rem;
	align-items: center;
}

.profile-spotlight-visual {
	min-height: 8.25rem;
	display: flex;
	align-items: center;
	justify-content: center;
	pointer-events: none;
}

.profile-spotlight-art {
	display: block;
	width: 100%;
	max-height: 9.25rem;
	object-fit: contain;
	filter: drop-shadow(0 0.65rem 1rem rgba(0, 0, 0, 0.38));
}

.profile-referral-visual {
	margin-right: -0.35rem;
}

.profile-referral-help {
	display: inline-flex;
	width: 1.55rem;
	height: 1.55rem;
	flex: 0 0 auto;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border-strong);
	border-radius: 50%;
	background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface));
	color: var(--app-accent-strong);
	font-size: 0.77rem;
	font-weight: 800;
}

.profile-referral-tip {
		margin-top: 0.7rem;
		border: 1px solid var(--app-border);
		border-radius: 0.8rem;
		background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface));
		padding: 0.65rem 0.75rem;
		color: var(--app-muted);
		font-size: 0.75rem;
		line-height: 1.45;
	}
	.profile-referral-toast {
		margin-top: 0.5rem;
		border-radius: 0.75rem;
		background: color-mix(in srgb, var(--app-accent) 12%, var(--app-surface));
		padding: 0.5rem 0.75rem;
		text-align: center;
		font-size: 0.8rem;
		color: var(--app-accent-strong);
		animation: profile-toast-fade 0.2s ease;
	}
	@keyframes profile-toast-fade {
		from { opacity: 0; transform: translateY(0.3rem); }
		to { opacity: 1; transform: translateY(0); }
	}

.profile-referral-link {
	overflow: hidden;
	border: 1px solid var(--app-border);
	border-radius: 0.8rem;
	background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface));
	padding: 0.7rem 0.75rem;
	color: var(--app-muted);
	font-size: 0.75rem;
	overflow-wrap: anywhere;
}

.profile-referral-copy {
	display: inline-flex;
	min-height: 2.8rem;
	width: 100%;
	align-items: center;
	justify-content: center;
	gap: 0.55rem;
	border: 1px solid var(--app-border-strong);
	border-radius: 0.8rem;
	background: color-mix(in srgb, var(--app-accent) 7%, var(--app-surface));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96);
	color: var(--app-accent-strong);
	font-size: 0.78rem;
	font-weight: 700;
	transition: transform 0.18s ease, border-color 0.18s ease, background 0.18s ease;
}

.profile-referral-copy:active { transform: scale(0.98); background: color-mix(in srgb, var(--app-accent) 14%, var(--app-surface)); }

.profile-referral-stat { border: 1px solid var(--app-border); border-radius: 0.8rem; background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface)); padding: 0.7rem; }
.profile-referral-stat span { display: block; color: var(--app-muted); font-size: 0.64rem; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; }
.profile-referral-stat strong { display: block; margin-top: 0.2rem; color: var(--app-accent-strong); font-size: 1.1rem; }

.profile-tariff-card {
	border-color: var(--app-border) !important;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 8%, transparent), transparent 32%), linear-gradient(155deg, var(--app-surface), var(--app-bg)) !important;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft) !important;
}

.profile-tariff-card :deep(.club-section-line) {
	background: linear-gradient(90deg, color-mix(in srgb, var(--app-success) 76%, transparent), transparent);
}

.profile-tariff-card .profile-section-title {
	color: var(--app-text-strong);
}

.profile-tariff-summary {
	grid-template-columns: minmax(0, 1fr) 6.4rem;
	min-height: 5rem;
	align-items: start;
}

.profile-tariff-visual {
	min-height: 5rem;
	height: 5rem;
	margin-top: -0.35rem;
	overflow: hidden;
	align-items: flex-start;
}

.profile-tariff-visual .profile-spotlight-art {
	width: 135%;
	max-height: none;
	transform: translate(7%, -10%);
}

.profile-tariff-action {
	display: inline-flex;
	width: 100%;
	min-height: 2.45rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border-strong);
	border-radius: 0.75rem;
	background: color-mix(in srgb, var(--app-accent) 7%, var(--app-surface));
	color: var(--app-accent-strong);
	font-weight: 700;
	transition: transform 0.18s ease, background 0.18s ease;
}

.profile-tariff-action:active {
	transform: scale(0.98);
	background: color-mix(in srgb, var(--app-accent) 14%, var(--app-surface));
}

@media (max-width: 360px) {
	.profile-spotlight-summary { grid-template-columns: minmax(0, 1fr) 7.25rem; }
	.profile-tariff-summary { grid-template-columns: minmax(0, 1fr) 5.75rem; }
	.profile-spotlight-visual { min-height: 7.25rem; }
	.profile-tariff-visual { min-height: 4.75rem; height: 4.75rem; }
}

.profile-page :deep(.club-card) {
	border: 1px solid var(--app-border);
	border-radius: 1.2rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 8%, transparent), transparent 32%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}

.profile-page :deep(.club-card::before) {
	background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--app-accent) 34%, transparent), transparent);
}

.profile-page :deep(.club-section-line) {
	background: linear-gradient(90deg, color-mix(in srgb, var(--app-accent) 70%, transparent), transparent);
}

.profile-page :deep(.btn-primary) {
	border: 1px solid var(--app-border-strong);
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent));
	color: var(--app-button-fg);
	box-shadow: var(--app-shadow-soft);
}

.profile-page :deep(.btn-glass) {
	border-color: var(--app-border);
	background: var(--app-surface);
	color: var(--app-text);
}

.profile-avatar {
	border: 1px solid var(--app-border-strong);
	background: radial-gradient(circle at 35% 22%, color-mix(in srgb, var(--app-accent) 18%, transparent), transparent 33%), linear-gradient(145deg, var(--app-surface), var(--app-bg)) !important;
	box-shadow: 0 0 0 0.35rem color-mix(in srgb, var(--app-accent) 7%, transparent), var(--app-shadow-raised) !important;
}

.profile-name-edit-button {
	display: inline-flex;
	width: 2.55rem;
	height: 2.55rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border-strong);
	border-radius: 0.9rem;
	background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface));
	color: var(--app-accent-strong);
	transition: transform 0.18s ease, border-color 0.18s ease, background 0.18s ease;
}

.profile-name-edit-button:active {
	transform: scale(0.94);
}

.profile-section-title {
	color: var(--app-text-strong);
	font-family: inherit;
	font-size: 0.82rem;
	font-weight: 700;
	letter-spacing: 0.16em;
	text-transform: uppercase;
	text-shadow: none;
}

.profile-link-title {
	color: var(--app-text-strong);
	font-size: 0.9rem;
	font-weight: 500;
	letter-spacing: 0.015em;
}

.profile-password-card {
	overflow: hidden;
}

.profile-password-label {
	display: block;
	margin-bottom: 0.45rem;
	color: var(--app-muted);
	font-size: 0.78rem;
	font-weight: 700;
	letter-spacing: 0.13em;
	text-transform: uppercase;
}

.profile-chat-row {
	appearance: none;
	display: flex;
	align-items: center;
	gap: 0.85rem;
	color: inherit;
	font: inherit;
	padding: 0.7rem 0.5rem;
	border-radius: 1rem;
}

.profile-chat-row:active { background: var(--app-bg-deep); }

.profile-account-menu { display: grid; }
.profile-account-menu-divider { height: 1px; margin: 0 0.35rem; background: var(--app-border); }
.profile-account-menu-divider-danger { background: color-mix(in srgb, var(--app-danger) 22%, var(--app-border)); }
.profile-bottom-row {
	display: flex;
	align-items: center;
	gap: 0.8rem;
	min-height: 4.2rem;
	padding: 0.75rem 0.5rem;
	border-radius: 0.9rem;
}

.profile-bottom-icon { width: 2.45rem; height: 2.45rem; flex: 0 0 auto; }
.profile-favorites-icon { border: 1px solid var(--app-border-strong); background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface)); color: var(--app-accent-strong); }
.profile-support-icon { border: 1px solid var(--app-border-strong); background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface)); color: var(--app-accent-strong); }
.profile-logout-icon { border: 1px solid color-mix(in srgb, var(--app-danger) 25%, var(--app-border)); background: color-mix(in srgb, var(--app-danger) 7%, var(--app-surface)); color: var(--app-danger); }
.profile-logout-title { color: var(--app-danger); }
.profile-bottom-row:active { background: var(--app-bg-deep); }
.profile-logout-row:active { background: color-mix(in srgb, var(--app-danger) 10%, var(--app-surface)); }

.profile-growth-row {
	appearance: none;
	display: flex;
	align-items: center;
	gap: 0.85rem;
	color: inherit;
	font: inherit;
	padding: 0.95rem;
	border-radius: 1rem;
	border: 1px solid var(--app-border);
	background: radial-gradient(circle at 94% 30%, color-mix(in srgb, var(--app-accent-slate) 10%, transparent), transparent 32%), linear-gradient(180deg, var(--app-surface), var(--app-bg));
	box-shadow: var(--app-shadow-soft);
}

.profile-growth-row:active {
	transform: scale(0.985);
}

.profile-growth-icon {
	display: flex;
	width: 2.55rem;
	height: 2.55rem;
	flex-shrink: 0;
	align-items: center;
	justify-content: center;
	border-radius: 1rem;
	border: 1px solid var(--app-border);
}

.profile-growth-icon-muted {
	background: color-mix(in srgb, var(--app-accent-slate) 10%, var(--app-surface));
	color: var(--app-accent-slate);
}

.profile-growth-icon-slate {
	background: color-mix(in srgb, var(--app-accent-slate) 14%, var(--app-surface));
	color: var(--app-accent-slate);
}

.profile-growth-icon-deep {
	background: color-mix(in srgb, var(--app-accent-slate) 18%, var(--app-surface));
	color: var(--app-accent-slate);
}

.profile-modal-shell {
	position: fixed;
	top: 0;
	bottom: 0;
	left: 50%;
	right: auto;
		z-index: 110;
	display: flex;
	width: var(--app-viewport-width);
	max-width: var(--app-viewport-max);
	align-items: center;
	justify-content: center;
	padding: 1rem;
	background: color-mix(in srgb, var(--app-text) 24%, transparent);
	backdrop-filter: blur(14px);
	transform: translateX(-50%);
}

.profile-modal,
.profile-confirm-modal {
	position: relative;
	width: min(100%, 25rem);
	overflow: hidden;
	border: 1px solid var(--app-border-strong);
	border-radius: 1.6rem;
	background: radial-gradient(circle at 82% 0%, color-mix(in srgb, var(--app-accent) 12%, transparent), transparent 36%), linear-gradient(180deg, var(--app-surface), var(--app-bg));
	padding: 2rem 1.25rem 1.25rem;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-floating);
}

.profile-modal {
	max-height: calc(100dvh - 2rem);
	overflow-y: auto;
	padding-top: 3.1rem;
}

.profile-modal-close {
	position: absolute;
	top: 0.8rem;
	right: 0.8rem;
	display: inline-flex;
	width: 2.35rem;
	height: 2.35rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border);
	border-radius: 999px;
	background: var(--app-surface);
	color: var(--app-muted);
}

.profile-modal-title {
	margin: 0;
	color: var(--app-text-strong);
	font-size: 1.15rem;
	font-weight: 750;
	line-height: 1.2;
	text-align: center;
}

.profile-modal-section-title {
	margin: 0;
	color: var(--app-accent-strong);
	font-size: 0.72rem;
	font-weight: 800;
	letter-spacing: 0.14em;
	text-transform: uppercase;
}

.profile-modal-divider {
	height: 1px;
	background: var(--app-border);
}

.profile-confirm-copy {
	margin: 0.85rem 0 0;
	color: var(--app-muted);
	font-size: 0.9rem;
	line-height: 1.55;
	text-align: center;
}

.profile-confirm-actions {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 0.65rem;
	margin-top: 1.35rem;
}

.profile-confirm-actions button {
	min-height: 2.8rem;
	border-radius: 0.9rem;
	font-size: 0.82rem;
	font-weight: 750;
}

	.profile-confirm-danger {
		border: 1px solid color-mix(in srgb, var(--app-danger) 35%, var(--app-border));
		background: var(--app-danger);
		color: var(--app-surface);
	}

	.profile-modal .btn-primary,
	.profile-confirm-actions .btn-primary {
		border: 1px solid var(--app-border-strong);
		background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent));
		color: var(--app-button-fg);
	}

	.profile-confirm-actions .btn-glass {
		border-color: var(--app-border);
		background: var(--app-surface);
		color: var(--app-text);
	}

</style>
