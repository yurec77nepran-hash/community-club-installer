<script setup lang="ts">
import { REACTIONS } from '@community-club/shared/constants'
import type { ChannelPost } from '@community-club/shared/db/schema'

definePageMeta({ middleware: 'auth', keepalive: true })

const api = useApi()
const channelStore = useChannelStore()
const posts = computed<ChannelPost[]>(() => channelStore.posts)
const loading = computed(() => channelStore.loading)
const loadingMore = computed(() => channelStore.loadingMore)
const hasMore = computed(() => Boolean(channelStore.nextCursor))
const loadMoreSentinel = ref<HTMLElement | null>(null)
let observer: IntersectionObserver | null = null

onMounted(async () => {
	observer = new IntersectionObserver(
		(entries) => {
			if (entries.some((entry) => entry.isIntersecting) && hasMore.value) {
				void channelStore.loadMore()
			}
		},
		{ threshold: 0.2 },
	)

	watch(
		loadMoreSentinel,
		(current, previous) => {
			if (previous) {
				observer?.unobserve(previous)
			}
			if (current) {
				observer?.observe(current)
			}
		},
		{ immediate: true },
	)

	await channelStore.fetchInitial()
})

async function toggleReaction(postId: number, emoji: string) {
	await api.post(`/api/channels/${postId}/reactions`, { emoji })
	channelStore.invalidate()
	await channelStore.fetchInitial(true)
}

onUnmounted(() => {
	if (observer) {
		observer.disconnect()
		observer = null
	}
})
</script>

<template>
	<div class="club-page">
		<div class="club-section-head mb-2">
			<span class="club-section-line" />
			<p class="club-section-kicker">Клуб</p>
		</div>
		<h1 class="club-section-title mb-5 text-2xl font-bold">Канал</h1>

		<div v-if="loading" class="flex justify-center py-12">
			<div class="club-spinner" />
		</div>

		<div v-else class="space-y-4">
			<article v-for="post in posts" :key="post.id" class="club-card p-4">
				<div class="text-sm text-[var(--app-text)] whitespace-pre-wrap">{{ post.content }}</div>
				<div v-if="post.createdAt" class="text-xs text-[var(--app-muted-soft)] mt-3">
					{{ new Date(post.createdAt).toLocaleDateString('ru', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) }}
				</div>
				<div class="flex gap-1 mt-3 flex-wrap">
					<button v-for="emoji in REACTIONS" :key="emoji"
						class="rounded-full border border-[var(--app-border)] bg-[var(--app-bg)] px-2 py-1 text-sm text-[var(--app-text)] transition hover:border-[var(--app-border-strong)] hover:bg-[var(--app-surface)]"
						@click="toggleReaction(post.id, emoji)">{{ emoji }}</button>
				</div>
			</article>
			<div v-if="loadingMore" class="flex justify-center py-4">
				<div class="club-spinner !h-6 !w-6 !border-2" />
			</div>
			<div v-if="hasMore" ref="loadMoreSentinel" class="h-4" />
		</div>
	</div>
</template>
