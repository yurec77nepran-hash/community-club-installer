<script setup lang="ts">
import { MATERIAL_TYPES } from '@community-club/shared/constants'

const route = useRoute()
const requestedType = typeof route.query.type === 'string' ? route.query.type : ''
const type = requestedType in MATERIAL_TYPES ? requestedType : 'checklists'

await navigateTo(`/app/content/${type}`, { replace: true })
</script>
