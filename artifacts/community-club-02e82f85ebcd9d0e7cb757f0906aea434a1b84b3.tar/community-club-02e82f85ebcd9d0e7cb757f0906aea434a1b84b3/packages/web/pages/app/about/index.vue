<script setup lang="ts">
definePageMeta({ middleware: 'auth' })
const { goBack } = useAppBack('/app/profile')

const links = [
	{
		to: '/app/about/rules',
		label: 'Правила сообщества',
		icon: 'document',
		description: 'Основные правила поведения в клубе',
	},
	{
		to: '/app/about/faq',
		label: 'Частые вопросы',
		icon: 'question',
		description: 'Ответы на популярные вопросы',
	},
	{
		to: '/app/support',
		label: 'Служба заботы',
		icon: 'envelope',
		description: 'Связаться с поддержкой',
	},
]
</script>

<template>
	<div class="club-page">
		<header class="club-topbar">
			<button type="button" class="club-back-button" aria-label="Назад" @click="goBack('/app/profile')">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<div class="min-w-0">
				<div class="club-section-head mb-2">
					<span class="club-section-line" />
					<p class="club-section-kicker">Community</p>
				</div>
				<h1 class="club-section-title text-2xl font-bold">О клубе</h1>
			</div>
		</header>

		<section class="club-card mb-6 p-5">
			<div class="club-section-head mb-3">
				<span class="club-section-line" />
				<h2 class="club-section-kicker">Миссия клуба</h2>
			</div>
			<div class="space-y-3 text-sm leading-relaxed text-[var(--app-muted)]">
				<p>Клуб создан для того, чтобы сформировать новое профессиональное сообщество — осознанное, грамотное и уверенное в себе.</p>
				<p>Мы объединяем экспертов, практиков и будущих лидеров индустрии.</p>
				<p>Через знания, комьюнити и системную поддержку мы перестраиваем рынок изнутри, создавая новую нейл-культуру, основанную на этике, экспертизе и эстетике.</p>
			</div>
		</section>

		<div class="space-y-3">
			<NuxtLink v-for="link in links" :key="link.to" :to="link.to" class="club-list-row transition-transform">
				<div class="club-icon-badge">
					<svg v-if="link.icon === 'document'" class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
					<svg v-else-if="link.icon === 'question'" class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
					<svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 002 2v10a2 2 0 002 2z" /></svg>
				</div>
				<div class="min-w-0 flex-1">
					<p class="text-sm font-bold text-[var(--app-text-strong)]">{{ link.label }}</p>
					<p class="mt-1 text-xs text-[var(--app-muted)]">{{ link.description }}</p>
				</div>
				<svg class="h-5 w-5 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 5 7 7-7 7" />
				</svg>
			</NuxtLink>
		</div>
	</div>
</template>
