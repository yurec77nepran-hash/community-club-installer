<script setup lang="ts">
definePageMeta({ middleware: 'auth' })
const { goBack } = useAppBack('/app/about')

const faqs = [
	{
		q: 'Что входит в клуб?',
		a: 'Клуб объединяет материалы, эфиры, разборы работ и общение с экспертами.',
	},
	{
		q: 'Как получить доступ к закрытому контенту?',
		a: 'Доступ к закрытому контенту предоставляется после оплаты подписки. Детали можно узнать в разделе курсов или связавшись со службой заботы.',
	},
	{
		q: 'Как работает реферальная программа?',
		a: 'Приглашайте друзей по реферальной ссылке и получайте 100₽ за каждого участника, который оформит подписку. Подробности в разделе «Профиль».',
	},
	{
		q: 'Можно ли отменить подписку?',
		a: 'Да, подписку можно отменить в любое время. Доступ к контенту сохранится до окончания оплаченного периода.',
	},
	{
		q: 'Какой контент доступен в клубе?',
		a: 'В клубе доступны эфиры, разборы работ, обучающие материалы, чек-листы, рекомендации книг и фильмов, а также эксклюзивные курсы от экспертов.',
	},
	{ q: 'Хочешь развиваться дальше?', a: '', rich: true },
]

const open = ref<number | null>(null)
function toggle(i: number) {
	open.value = open.value === i ? null : i
}
</script>

<template>
	<div class="club-page">
		<header class="club-topbar">
			<button type="button" class="club-back-button" aria-label="Назад" @click="goBack('/app/about')">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<div class="min-w-0">
				<div class="club-section-head mb-2">
					<span class="club-section-line" />
					<p class="club-section-kicker">Помощь</p>
				</div>
				<h1 class="club-section-title text-2xl font-bold">Частые вопросы</h1>
			</div>
		</header>

		<div class="space-y-3">
			<div v-for="(faq, i) in faqs" :key="i" class="club-card overflow-hidden">
				<button class="flex w-full items-center gap-3 p-4 text-left" @click="toggle(i)">
					<span class="flex-1 text-sm font-bold text-[var(--app-text-strong)]">{{ faq.q }}</span>
					<svg class="h-5 w-5 flex-shrink-0 text-[var(--app-muted)] transition-transform duration-200" :class="open === i ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
					</svg>
				</button>
				<div v-if="open === i" class="px-4 pb-4 -mt-1">
					<p v-if="faq.a" class="text-sm leading-relaxed text-[var(--app-muted)]">{{ faq.a }}</p>

					<div v-else-if="faq.rich" class="space-y-3 text-sm leading-relaxed text-[var(--app-muted)]">
						<p>Если ты:</p>
						<ul class="list-disc list-inside space-y-1 ml-2">
							<li>чувствуешь, что готова расти,</li>
							<li>хочешь делиться опытом с другими участниками,</li>
							<li>уверена в себе и своём опыте,</li>
						</ul>
						<p>то следующий шаг — это расширенная программа клуба.</p>
						<p class="font-medium text-[var(--app-text)]">📌 Это базовый курс для тех, кто:</p>
						<ul class="list-disc list-inside space-y-1 ml-2">
							<li>готов делиться опытом,</li>
							<li>хочет развиваться в рамках клубной программы.</li>
						</ul>
						<p class="font-medium text-[var(--app-text)]">Что дальше?</p>
						<ul class="space-y-1">
							<li>🔹 Ознакомься с программой курса</li>
							<li>🔹 Узнай стоимость и условия участия</li>
							<li>🔹 Подавай заявку через форму на сайте</li>
						</ul>
						<a href="https://courses.example.com/club" target="_blank" class="club-primary-action mt-2 w-full text-sm sm:w-auto">
							Подробнее
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
