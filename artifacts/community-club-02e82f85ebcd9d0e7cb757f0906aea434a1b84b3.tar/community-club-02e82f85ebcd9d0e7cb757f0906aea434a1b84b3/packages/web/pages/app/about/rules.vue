<script setup lang="ts">
definePageMeta({ middleware: 'auth' })
const { goBack } = useAppBack('/app/about')
</script>

<template>
	<div class="club-page">
		<header class="club-topbar">
			<button type="button" class="club-back-button" aria-label="Назад" @click="goBack('/app/about')">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<div class="min-w-0">
				<div class="club-section-head mb-2">
					<span class="club-section-line" />
					<p class="club-section-kicker">Сообщество</p>
				</div>
				<h1 class="club-section-title text-2xl font-bold">Правила</h1>
			</div>
		</header>

		<div class="space-y-4">
			<div class="club-card p-4">
				<h2 class="mb-2 flex items-center gap-2 font-semibold text-[var(--app-text-strong)]">
					<span class="club-number-badge">1</span>
					Уважение и корректность
				</h2>
				<p class="text-sm leading-relaxed text-[var(--app-muted)]">Мы создаем пространство для обучения и развития. Относитесь друг к другу с уважением, избегайте оскорблений и негативных комментариев.</p>
			</div>

			<div class="club-card p-4">
				<h2 class="mb-2 flex items-center gap-2 font-semibold text-[var(--app-text-strong)]">
					<span class="club-number-badge">2</span>
					Конструктивность общения
				</h2>
				<p class="text-sm leading-relaxed text-[var(--app-muted)]">Делитесь опытом, задавайте вопросы, помогайте коллегам. Критика должна быть конструктивной и направленной на улучшение навыков.</p>
			</div>

			<div class="club-card p-4">
				<h2 class="mb-2 flex items-center gap-2 font-semibold text-[var(--app-text-strong)]">
					<span class="club-number-badge">3</span>
					Запрещённый контент
				</h2>
				<ul class="ml-8 space-y-1.5 text-sm leading-relaxed text-[var(--app-muted)]">
					<li class="flex items-start gap-2"><span class="text-[var(--app-danger)] mt-0.5">&#x2022;</span> Спам и реклама без согласования</li>
					<li class="flex items-start gap-2"><span class="text-[var(--app-danger)] mt-0.5">&#x2022;</span> Политические дискуссии</li>
					<li class="flex items-start gap-2"><span class="text-[var(--app-danger)] mt-0.5">&#x2022;</span> Оскорбления и дискриминация</li>
					<li class="flex items-start gap-2"><span class="text-[var(--app-danger)] mt-0.5">&#x2022;</span> Нарушение авторских прав</li>
				</ul>
			</div>

			<div class="club-card p-4">
				<h2 class="mb-2 flex items-center gap-2 font-semibold text-[var(--app-text-strong)]">
					<span class="club-number-badge">4</span>
					Обучение и развитие
				</h2>
				<p class="text-sm leading-relaxed text-[var(--app-muted)]">Активно участвуйте в обучающих мероприятиях, делитесь знаниями, помогайте новичкам адаптироваться в сообществе.</p>
			</div>
		</div>
	</div>
</template>
