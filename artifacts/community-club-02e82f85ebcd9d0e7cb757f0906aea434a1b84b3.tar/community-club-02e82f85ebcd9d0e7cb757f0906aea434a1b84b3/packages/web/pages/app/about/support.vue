<script setup lang="ts">
definePageMeta({ middleware: 'auth' })
const { goBack } = useAppBack('/app/about')

const categories = [
	{ label: 'Технические проблемы', icon: '🔧' },
	{ label: 'Вопросы по оплате', icon: '💳' },
	{ label: 'Проблемы с доступом', icon: '🔑' },
	{ label: 'Предложения улучшений', icon: '💡' },
]
</script>

<template>
	<div class="club-page">
		<header class="club-topbar">
			<button type="button" class="club-back-button" aria-label="Назад" @click="goBack('/app/about')">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<div class="min-w-0">
				<div class="club-section-head mb-2">
					<span class="club-section-line" />
					<p class="club-section-kicker">Помощь</p>
				</div>
				<h1 class="club-section-title text-2xl font-bold">Служба заботы</h1>
			</div>
		</header>

		<section class="club-card mb-5 p-5">
			<h2 class="mb-2 text-lg font-bold text-[var(--app-text-strong)]">Нужна помощь?</h2>
			<p class="mb-4 text-sm leading-relaxed text-[var(--app-muted)]">Служба заботы поможет с вопросами по клубу, подписке и доступу.</p>
			<NuxtLink to="/app/support" class="club-primary-action w-full">Открыть чат</NuxtLink>
			<p class="mt-3 text-center text-xs text-[var(--app-muted-soft)]">Обычно отвечаем в течение 24 часов</p>
		</section>

		<div class="club-section-head mb-3">
			<span class="club-section-line" />
			<h2 class="club-section-kicker">Темы обращений</h2>
		</div>
		<div class="grid grid-cols-2 gap-3 mb-5">
			<div v-for="cat in categories" :key="cat.label" class="club-card flex items-center gap-2 p-3">
				<span class="text-lg">{{ cat.icon }}</span>
				<span class="text-xs text-[var(--app-muted)]">{{ cat.label }}</span>
			</div>
		</div>

		<section class="club-card border-[color-mix(in_srgb,var(--app-danger)_28%,var(--app-border))] p-5">
			<h2 class="mb-2 flex items-center gap-2 font-bold text-[var(--app-text-strong)]">
				<span class="text-lg">🚨</span> Сообщить о нарушении
			</h2>
			<p class="mb-4 text-sm leading-relaxed text-[var(--app-muted)]">Если заметили спам, рекламу или некорректное общение, напишите в Службу заботы.</p>
			<NuxtLink to="/app/support" class="club-danger-action w-full">
				Сообщить о нарушении
			</NuxtLink>
		</section>
	</div>
</template>
