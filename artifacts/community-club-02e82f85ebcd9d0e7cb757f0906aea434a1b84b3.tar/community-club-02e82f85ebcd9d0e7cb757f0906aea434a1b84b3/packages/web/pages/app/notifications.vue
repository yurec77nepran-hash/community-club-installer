<script setup lang="ts">
definePageMeta({ middleware: ['auth'] })

await navigateTo({ path: '/app', query: { notifications: '1' } }, { replace: true })
</script>
