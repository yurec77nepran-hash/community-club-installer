<script setup lang="ts">
import type { HomeCustomPage, HomeExperienceSettings } from '@community-club/shared/types'

definePageMeta({ middleware: ['auth'] })

const route = useRoute()
const api = useApi()
const { goBack } = useAppBack('/app')
const slug = computed(() => String(route.params.slug || ''))

const { data: page } = await useAsyncData(
	() => `custom-page-${slug.value}`,
	async () => {
		const res = await api.get<HomeExperienceSettings>('/api/site-settings/home-experience')
		if (!res.success) return null
		return res.data.customPages.find((item) => item.slug === slug.value) ?? null
	},
	{ default: () => null, watch: [slug] },
)

const currentPage = computed<HomeCustomPage | null>(() => page.value)

function blockClass(size: 'sm' | 'md' | 'lg') {
	return {
		'custom-page-block-sm': size === 'sm',
		'custom-page-block-lg': size === 'lg',
	}
}
</script>

<template>
	<div
		class="custom-page-shell"
		:style="{
			backgroundColor: 'var(--app-bg)',
			color: 'var(--app-text)',
		}"
	>
		<div class="mb-5 flex items-center gap-3">
			<button type="button" class="club-back-button" aria-label="Назад" @click="goBack('/app')">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<h1 class="club-section-title text-2xl font-bold">{{ currentPage?.title || 'Страница' }}</h1>
		</div>

		<div v-if="!currentPage" class="rounded-3xl border border-[var(--app-border)] bg-[var(--app-surface)] p-5 text-sm text-[var(--app-muted)] shadow-[var(--app-shadow-soft)]">
			Страница не найдена.
		</div>

		<div v-else class="custom-page-blocks">
			<section
				v-for="block in currentPage.blocks"
				:key="block.id"
				class="custom-page-block"
				:class="blockClass(block.size)"
				:style="{
					backgroundColor: 'var(--app-surface)',
					color: 'var(--app-text)',
					borderRadius: `${block.borderRadius}px`,
				}"
			>
				<h2 v-if="block.kind === 'heading'" class="custom-page-heading">{{ block.title }}</h2>
				<p v-else-if="block.kind === 'text'" class="custom-page-text">{{ block.text }}</p>
				<img
					v-else-if="block.kind === 'image' && block.mediaUrl"
					:src="block.mediaUrl"
					:alt="block.title || currentPage.title"
					class="custom-page-media"
				/>
				<video
					v-else-if="block.kind === 'video' && block.mediaUrl"
					:src="block.mediaUrl"
					class="custom-page-media"
					controls
					playsinline
				/>
				<a
					v-else-if="block.kind === 'button'"
					:href="block.buttonUrl || '#'"
					class="custom-page-button"
					target="_blank"
					rel="noopener noreferrer"
				>
					{{ block.buttonLabel || block.title || 'Открыть' }}
				</a>
			</section>
		</div>
	</div>
</template>

<style scoped>
.custom-page-shell {
	min-height: calc(100vh - 2rem);
	padding: 1rem;
	padding-bottom: 7rem;
}

.custom-page-blocks {
	display: grid;
	gap: 0.9rem;
	max-width: 48rem;
}

.custom-page-block {
	overflow: hidden;
	border: 1px solid var(--app-border);
	padding: 1rem;
	box-shadow: var(--app-shadow-soft), inset 0 1px rgb(255 255 255 / 0.96);
}

.custom-page-block-sm {
	padding: 0.75rem;
}

.custom-page-block-lg {
	padding: 1.35rem;
}

.custom-page-heading {
	margin: 0;
	font-size: 2rem;
	font-weight: 800;
	line-height: 1;
	letter-spacing: 0;
}

.custom-page-block-sm .custom-page-heading {
	font-size: 1.5rem;
}

.custom-page-block-lg .custom-page-heading {
	font-size: 2.5rem;
}

.custom-page-text {
	margin: 0;
	font-size: 1rem;
	line-height: 1.55;
	white-space: pre-wrap;
}

.custom-page-media {
	display: block;
	width: 100%;
	max-height: 70vh;
	object-fit: cover;
}

.custom-page-button {
	display: inline-flex;
	min-height: 3rem;
	align-items: center;
	justify-content: center;
	border-radius: 1rem;
	background: var(--app-button-bg);
	padding: 0 1.2rem;
	color: var(--app-button-fg);
	font-weight: 700;
	text-decoration: none;
}
</style>
