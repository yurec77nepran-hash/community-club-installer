<script setup lang="ts">
import type { Event } from '@community-club/shared/db/schema'

definePageMeta({ middleware: 'auth', keepalive: true })

const eventsStore = useEventsStore()
const monthKey = new Date().toISOString().slice(0, 7)
const events = computed<Event[]>(() => eventsStore.getMonthEvents(monthKey))
const loading = ref(!eventsStore.getMonthSnapshot(monthKey))

onMounted(async () => {
	const snapshot = eventsStore.getMonthSnapshot(monthKey)
	if (snapshot) {
		loading.value = false
	}
	await eventsStore.fetchMonth(monthKey)
	loading.value = false
})

function formatDate(dateStr: string) {
	return new Date(dateStr).toLocaleDateString('ru-RU', {
		day: 'numeric',
		month: 'long',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}
</script>

<template>
	<div class="club-page">
		<div class="club-section-head mb-2">
			<span class="club-section-line" />
			<p class="club-section-kicker">Календарь</p>
		</div>
		<h1 class="club-section-title mb-5 text-2xl font-bold">События</h1>

		<div v-if="loading" class="flex justify-center py-12">
			<div class="club-spinner" />
		</div>

		<div v-else-if="events.length === 0" class="club-empty text-sm">Нет предстоящих событий</div>

		<div v-else class="space-y-3">
			<div v-for="event in events" :key="event.id" class="club-list-row">
				<div class="flex items-start gap-3">
					<div class="club-icon-badge">
						<svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
						</svg>
					</div>
					<div class="min-w-0 flex-1">
						<h2 class="text-sm font-bold text-[var(--app-text-strong)]">{{ event.title }}</h2>
						<p v-if="event.description" class="text-xs text-[var(--app-muted)] mt-1 line-clamp-2">{{ event.description }}</p>
						<p class="mt-2 text-xs font-medium text-[var(--app-accent-strong)]">{{ formatDate(event.eventDate) }}</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
