<script setup lang="ts">
import { MATERIAL_TYPES } from '@community-club/shared/constants'
import type { Material } from '@community-club/shared/db/schema'
import type {
	GuestContentBlockAccess,
	MaterialCommentItem,
	MaterialPlaybackProgressPayload,
} from '@community-club/shared/types'
import MaterialCommentThread from '~/components/materials/CommentThread.vue'
import GuestContentBlock from '~/components/materials/GuestContentBlock.vue'
import MaterialDetailHero from '~/components/materials/MaterialDetailHero.vue'
import MaterialFallbackCover from '~/components/materials/MaterialFallbackCover.vue'
import MaterialVideoChapters from '~/components/materials/MaterialVideoChapters.vue'
import MaterialVideoPreview from '~/components/materials/MaterialVideoPreview.vue'
import TemplateLessonBanner from '~/components/materials/TemplateLessonBanner.vue'
import AppScreenSkeleton from '~/components/ui/AppScreenSkeleton.vue'
import type { MaterialDownloadFile, MaterialMediaPayload } from '~/stores/materials'
import { getMaterialTheme } from '~/utils/material-theme'

definePageMeta({ layout: 'default', appHeader: false })

const route = useRoute()
const auth = useAuthStore()
const materialsStore = useMaterialsStore()
const favoritesStore = useMaterialFavoritesStore()

function getCookie(name: string) {
	if (!import.meta.client) return null
	const match = document.cookie
		.split('; ')
		.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
	return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
}

const materialId = computed(() => Number(route.params.id))
const type = computed(() => route.params.type as string)
const contentType = computed(() => material.value?.type || type.value)
const backFallback = computed(() => {
	return `/app/content/${contentType.value}`
})
const { goBack } = useAppBack()

function returnToSection() {
	return goBack(backFallback.value)
}

const material = ref<Material | null>(null)
const mediaUrl = ref<string | null>(null)
const mediaDownloadUrl = ref<string | null>(null)
const mediaDownloadable = ref(false)
const materialFiles = ref<MaterialDownloadFile[]>([])
type VideoPlayerInstance = { seekTo: (seconds: number) => void }
const videoPlayers = new Map<number, VideoPlayerInstance>()
const guestVideoPlayers = new Map<number, VideoPlayerInstance>()
type GuestMaterialFile = {
	index: number
	name: string
	type: string
	access: GuestContentBlockAccess
	url: string | null
	chapters?: import('@community-club/shared/types').MaterialVideoChapters
}
const guestPreview = ref<{
	blockAccess: Record<'cover' | 'description' | 'link', GuestContentBlockAccess>
	files: GuestMaterialFile[]
} | null>(null)
const accessModalOpen = ref(false)
const favoriteSaving = ref(false)
const comments = ref<MaterialCommentItem[]>([])
const commentsLoading = ref(false)
const commentDraft = ref('')
const submittingComment = ref(false)
const reactingKey = ref('')
const replyTo = ref<MaterialCommentItem | null>(null)
const editingComment = ref<MaterialCommentItem | null>(null)
const loading = ref(true)
const error = ref('')
const accessDenied = ref(false)
const videoResumeSeconds = ref(0)
const audioResumeSeconds = ref(0)
const audioResumeFileIndex = ref(0)
const activeAudioCardFileIndex = ref<number | null>(null)
const audioAutoplaySignal = ref(0)
const lastVideoProgress = ref<MaterialPlaybackProgressPayload | null>(null)
const lastAudioProgress = ref<MaterialPlaybackProgressPayload | null>(null)
const lastSavedVideoProgressSeconds = ref(0)
const lastSavedAudioProgressSeconds = ref(0)
const videoProgressSaveTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const audioProgressSaveTimer = ref<ReturnType<typeof setTimeout> | null>(null)
const savingVideoProgress = ref(false)
const savingAudioProgress = ref(false)
function getMaterialCacheKey() {
	return `material:${materialId.value}`
}

function getMediaUrlCacheKey() {
	return `material-media-url:${materialId.value}`
}

function restoreMaterialFromCache() {
	if (!import.meta.client) return false

	try {
		const raw = sessionStorage.getItem(getMaterialCacheKey())
		if (!raw) return false

		const cached = JSON.parse(raw) as { item: Material; timestamp: number }
		if (Date.now() - cached.timestamp > 120_000) return false
		material.value = cached.item
		return true
	} catch {
		return false
	}
}

function persistMaterialCache(item: Material) {
	if (!import.meta.client) return

	try {
		sessionStorage.setItem(getMaterialCacheKey(), JSON.stringify({ item, timestamp: Date.now() }))
	} catch {}
}

function restoreMediaUrlFromCache() {
	if (!import.meta.client) return false

	try {
		const raw = sessionStorage.getItem(getMediaUrlCacheKey())
		if (!raw) return false

		const cached = JSON.parse(raw) as { url: string; expiresAt: number }
		if (Date.now() >= cached.expiresAt) return false
		mediaUrl.value = cached.url
		return true
	} catch {
		return false
	}
}

function persistMediaUrlCache(url: string, expiresIn: number) {
	if (!import.meta.client) return

	try {
		sessionStorage.setItem(
			getMediaUrlCacheKey(),
			JSON.stringify({
				url,
				expiresAt: Date.now() + Math.max(60, expiresIn - 60) * 1000,
			}),
		)
	} catch {}
}

function hasStoredMediaFiles(storagePath: string | null) {
	if (!storagePath) return false
	try {
		const parsed = JSON.parse(storagePath) as unknown
		return Array.isArray(parsed)
			? parsed.length > 0
			: typeof parsed === 'object' && parsed !== null && Array.isArray(parsed.files)
				? parsed.files.length > 0
				: false
	} catch {
		return true
	}
}

function getCommentAuthorName(comment: MaterialCommentItem) {
	return (
		comment.author.fullName ||
		comment.author.username ||
		`Участник ${comment.author.authUuid.slice(0, 6)}`
	)
}

const resolvedMediaType = computed(() => {
	const explicitType = material.value?.mediaType
	if (explicitType && explicitType !== 'document') return explicitType

	const inferredFile = materialFiles.value.find((file) => file.type && file.type !== 'document')
	return inferredFile?.type ?? explicitType ?? null
})

const materialTheme = computed(() => {
	const theme = getMaterialTheme(contentType.value)
	return { '--section-accent': theme.accent, '--section-accent-soft': theme.soft }
})

const materialTypeLabel = computed(
	() => MATERIAL_TYPES[contentType.value as keyof typeof MATERIAL_TYPES] ?? contentType.value,
)
const isFavorite = computed(() => Boolean(favoritesStore.statuses[materialId.value]))

async function toggleFavorite() {
	if (!auth.isAuthenticated) {
		requestGuestAccess()
		return
	}
	if (favoriteSaving.value) return
	favoriteSaving.value = true
	try {
		await favoritesStore.toggle(materialId.value)
	} finally {
		favoriteSaving.value = false
	}
}

const totalComments = computed(() => {
	const walk = (items: MaterialCommentItem[]) =>
		items.reduce((sum, item) => sum + 1 + walk(item.replies ?? []), 0)
	return walk(comments.value)
})

const playableAudioFiles = computed(() =>
	materialFiles.value.filter(
		(file) => file.type === 'audio' && typeof file.url === 'string' && file.url,
	),
)

const audioPlaylist = computed(() => {
	if (resolvedMediaType.value === 'audio' && playableAudioFiles.value.length) {
		return playableAudioFiles.value
			.filter(
				(file): file is MaterialDownloadFile & { url: string } => typeof file.url === 'string',
			)
			.map((file) => ({
				fileIndex: file.index,
				src: file.url,
				title: file.name,
				downloadUrl: file.downloadUrl,
				downloadable: file.downloadable,
			}))
	}

	if (resolvedMediaType.value === 'audio' && mediaUrl.value) {
		const primaryAudioFile = playableAudioFiles.value[0]
		return [
			{
				fileIndex: primaryAudioFile?.index ?? 0,
				src: mediaUrl.value,
				title: material.value?.title,
				downloadUrl: mediaDownloadUrl.value,
				downloadable: mediaDownloadable.value,
			},
		]
	}

	return []
})

const commentPlaceholder = computed(() => {
	if (editingComment.value) return 'Обновить комментарий'
	if (replyTo.value) return `Ответ для ${getCommentAuthorName(replyTo.value)}`
	return 'Написать комментарий'
})

function clearVideoProgressTimer() {
	if (!videoProgressSaveTimer.value) return
	clearTimeout(videoProgressSaveTimer.value)
	videoProgressSaveTimer.value = null
}

function clearAudioProgressTimer() {
	if (!audioProgressSaveTimer.value) return
	clearTimeout(audioProgressSaveTimer.value)
	audioProgressSaveTimer.value = null
}

function normalizeVideoProgress(
	payload: Pick<
		MaterialPlaybackProgressPayload,
		'positionSeconds' | 'durationSeconds' | 'completed'
	>,
) {
	const durationSeconds =
		payload.durationSeconds != null && Number.isFinite(payload.durationSeconds)
			? Math.max(0, Math.round(payload.durationSeconds))
			: null
	const maxPosition = durationSeconds != null ? Math.max(0, durationSeconds) : 60 * 60 * 24
	const positionSeconds = Math.max(
		0,
		Math.min(
			maxPosition,
			Math.round(Number.isFinite(payload.positionSeconds) ? payload.positionSeconds : 0),
		),
	)
	const completed =
		payload.completed ||
		(durationSeconds != null && durationSeconds > 0 && positionSeconds >= durationSeconds - 3)

	return {
		positionSeconds: completed ? 0 : positionSeconds,
		durationSeconds,
		completed,
	}
}

async function saveVideoProgress(
	payload: Pick<
		MaterialPlaybackProgressPayload,
		'positionSeconds' | 'durationSeconds' | 'completed'
	>,
	options?: { force?: boolean; keepalive?: boolean },
) {
	if (!auth.isAuthenticated || resolvedMediaType.value !== 'video') return

	const normalized = normalizeVideoProgress(payload)
	if (!options?.force) {
		if (!normalized.completed && normalized.positionSeconds < 3) return
		if (
			!normalized.completed &&
			Math.abs(normalized.positionSeconds - lastSavedVideoProgressSeconds.value) < 5
		) {
			return
		}
	}

	const apiUrl = useRuntimeConfig().public.apiUrl
	const body = JSON.stringify(normalized)
	const headers: Record<string, string> = {
		'Content-Type': 'application/json',
	}
	const csrfToken = getCookie('csrf_token')
	if (csrfToken) headers['X-CSRF-Token'] = csrfToken

	savingVideoProgress.value = true
	try {
		const response = await fetch(`${apiUrl}/api/materials/${materialId.value}/progress`, {
			method: 'POST',
			headers,
			body,
			credentials: 'include',
			keepalive: options?.keepalive === true,
		})
		if (!response.ok) return
		lastSavedVideoProgressSeconds.value = normalized.positionSeconds
		lastVideoProgress.value = {
			...normalized,
			updatedAt: new Date().toISOString(),
		}
	} catch {
		// no-op: progress saving is best effort
	} finally {
		savingVideoProgress.value = false
	}
}

function queueVideoProgressSave(
	payload: Pick<
		MaterialPlaybackProgressPayload,
		'positionSeconds' | 'durationSeconds' | 'completed'
	>,
	options?: { force?: boolean; keepalive?: boolean },
) {
	lastVideoProgress.value = {
		...normalizeVideoProgress(payload),
		updatedAt: new Date().toISOString(),
	}

	if (options?.force) {
		clearVideoProgressTimer()
		void saveVideoProgress(payload, options)
		return
	}

	clearVideoProgressTimer()
	videoProgressSaveTimer.value = setTimeout(() => {
		void saveVideoProgress(payload)
	}, 1400)
}

function handleVideoProgress(payload: {
	positionSeconds: number
	durationSeconds: number | null
	completed: boolean
}) {
	queueVideoProgressSave(payload)
}

async function loadVideoProgress() {
	if (resolvedMediaType.value !== 'video') {
		videoResumeSeconds.value = 0
		lastVideoProgress.value = null
		lastSavedVideoProgressSeconds.value = 0
		return
	}

	const api = useApi()
	const res = await api.get<MaterialPlaybackProgressPayload>(
		`/api/materials/${materialId.value}/progress`,
	)
	if (!res.success) return
	const normalized = normalizeVideoProgress(res.data)
	videoResumeSeconds.value = normalized.positionSeconds
	lastSavedVideoProgressSeconds.value = normalized.positionSeconds
	lastVideoProgress.value = {
		...normalized,
		updatedAt: res.data.updatedAt,
	}
}

function normalizeAudioProgress(
	payload: Pick<
		MaterialPlaybackProgressPayload,
		'mediaFileIndex' | 'positionSeconds' | 'durationSeconds' | 'completed'
	>,
) {
	const durationSeconds =
		payload.durationSeconds != null && Number.isFinite(payload.durationSeconds)
			? Math.max(0, Math.round(payload.durationSeconds))
			: null
	const maxPosition = durationSeconds != null ? Math.max(0, durationSeconds) : 60 * 60 * 24
	const positionSeconds = Math.max(
		0,
		Math.min(
			maxPosition,
			Math.round(Number.isFinite(payload.positionSeconds) ? payload.positionSeconds : 0),
		),
	)
	const completed =
		payload.completed ||
		(durationSeconds != null && durationSeconds > 0 && positionSeconds >= durationSeconds - 3)

	return {
		mediaFileIndex: Math.max(0, Math.round(payload.mediaFileIndex ?? 0)),
		positionSeconds: completed ? 0 : positionSeconds,
		durationSeconds,
		completed,
	}
}

async function saveAudioProgress(
	payload: Pick<
		MaterialPlaybackProgressPayload,
		'mediaFileIndex' | 'positionSeconds' | 'durationSeconds' | 'completed'
	>,
	options?: { force?: boolean; keepalive?: boolean },
) {
	if (!auth.isAuthenticated || resolvedMediaType.value !== 'audio') return

	const normalized = normalizeAudioProgress(payload)
	if (!options?.force) {
		if (!normalized.completed && normalized.positionSeconds < 3) return
		if (
			!normalized.completed &&
			normalized.mediaFileIndex === audioResumeFileIndex.value &&
			Math.abs(normalized.positionSeconds - lastSavedAudioProgressSeconds.value) < 5
		) {
			return
		}
	}

	const apiUrl = useRuntimeConfig().public.apiUrl
	const body = JSON.stringify(normalized)
	const headers: Record<string, string> = {
		'Content-Type': 'application/json',
	}
	const csrfToken = getCookie('csrf_token')
	if (csrfToken) headers['X-CSRF-Token'] = csrfToken

	savingAudioProgress.value = true
	try {
		const response = await fetch(`${apiUrl}/api/materials/${materialId.value}/progress`, {
			method: 'POST',
			headers,
			body,
			credentials: 'include',
			keepalive: options?.keepalive === true,
		})
		if (!response.ok) return
		lastSavedAudioProgressSeconds.value = normalized.positionSeconds
		audioResumeSeconds.value = normalized.positionSeconds
		audioResumeFileIndex.value = normalized.mediaFileIndex
		lastAudioProgress.value = {
			...normalized,
			updatedAt: new Date().toISOString(),
		}
	} catch {
		// no-op
	} finally {
		savingAudioProgress.value = false
	}
}

function queueAudioProgressSave(
	payload: Pick<
		MaterialPlaybackProgressPayload,
		'mediaFileIndex' | 'positionSeconds' | 'durationSeconds' | 'completed'
	>,
	options?: { force?: boolean; keepalive?: boolean },
) {
	lastAudioProgress.value = {
		...normalizeAudioProgress(payload),
		updatedAt: new Date().toISOString(),
	}

	if (options?.force) {
		clearAudioProgressTimer()
		void saveAudioProgress(payload, options)
		return
	}

	clearAudioProgressTimer()
	audioProgressSaveTimer.value = setTimeout(() => {
		void saveAudioProgress(payload)
	}, 1400)
}

function handleAudioProgress(payload: {
	mediaFileIndex: number
	positionSeconds: number
	durationSeconds: number | null
	completed: boolean
}) {
	queueAudioProgressSave(payload)
}

function handleAudioActivated(mediaFileIndex: number) {
	activeAudioCardFileIndex.value = mediaFileIndex
}

function focusAudioCard(mediaFileIndex: number) {
	if (!import.meta.client) return
	nextTick(() => {
		document
			.getElementById(`material-audio-card-${mediaFileIndex}`)
			?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
	})
}

function activateAudioCard(mediaFileIndex: number) {
	activeAudioCardFileIndex.value = mediaFileIndex
	audioAutoplaySignal.value += 1
	focusAudioCard(mediaFileIndex)
}

function playPreviousAudio(index: number) {
	if (!audioPlaylist.value.length) return
	const nextIndex = (index - 1 + audioPlaylist.value.length) % audioPlaylist.value.length
	activateAudioCard(audioPlaylist.value[nextIndex].fileIndex)
}

function playNextAudio(index: number) {
	if (!audioPlaylist.value.length) return
	const nextIndex = (index + 1) % audioPlaylist.value.length
	activateAudioCard(audioPlaylist.value[nextIndex].fileIndex)
}

async function loadAudioProgress() {
	if (resolvedMediaType.value !== 'audio') {
		audioResumeSeconds.value = 0
		audioResumeFileIndex.value = 0
		lastAudioProgress.value = null
		lastSavedAudioProgressSeconds.value = 0
		return
	}

	const api = useApi()
	const res = await api.get<MaterialPlaybackProgressPayload>(
		`/api/materials/${materialId.value}/progress`,
	)
	if (!res.success) return
	const normalized = normalizeAudioProgress(res.data)
	audioResumeSeconds.value = normalized.positionSeconds
	audioResumeFileIndex.value = normalized.mediaFileIndex
	activeAudioCardFileIndex.value = normalized.mediaFileIndex
	lastSavedAudioProgressSeconds.value = normalized.positionSeconds
	lastAudioProgress.value = {
		...normalized,
		updatedAt: res.data.updatedAt,
	}
}

function resetCommentComposer() {
	commentDraft.value = ''
	replyTo.value = null
	editingComment.value = null
}

async function loadComments() {
	if (!material.value?.commentsEnabled) {
		comments.value = []
		return
	}

	commentsLoading.value = true
	const api = useApi()
	const res = await api.get<MaterialCommentItem[]>(`/api/materials/${materialId.value}/comments`)
	if (res.success) {
		comments.value = res.data
	}
	commentsLoading.value = false
}

async function submitComment() {
	const content = commentDraft.value.trim()
	if (!content || submittingComment.value) return

	submittingComment.value = true
	const api = useApi()
	try {
		const res = editingComment.value
			? await api.patch<MaterialCommentItem[] | { items: MaterialCommentItem[] }>(
					`/api/materials/${materialId.value}/comments/${editingComment.value.id}`,
					{ content },
				)
			: await api.post<MaterialCommentItem[] | { items: MaterialCommentItem[] }>(
					`/api/materials/${materialId.value}/comments`,
					{
						content,
						parentCommentId: replyTo.value?.id ?? null,
					},
				)

		if (res.success) {
			comments.value = Array.isArray(res.data) ? res.data : res.data.items
			resetCommentComposer()
		}
	} finally {
		await loadComments()
		submittingComment.value = false
	}
}

function startReply(comment: MaterialCommentItem) {
	replyTo.value = comment
	editingComment.value = null
	commentDraft.value = ''
}

function startEdit(comment: MaterialCommentItem) {
	editingComment.value = comment
	replyTo.value = null
	commentDraft.value = comment.content
}

async function removeComment(comment: MaterialCommentItem) {
	if (!confirm('Удалить комментарий?')) return

	const api = useApi()
	const res = await api.delete<MaterialCommentItem[] | { items: MaterialCommentItem[] }>(
		`/api/materials/${materialId.value}/comments/${comment.id}`,
	)
	if (res.success) {
		comments.value = Array.isArray(res.data) ? res.data : res.data.items
		if (editingComment.value?.id === comment.id || replyTo.value?.id === comment.id) {
			resetCommentComposer()
		}
	}
	await loadComments()
}

async function toggleReaction(commentId: number, emoji: string) {
	const key = `${commentId}:${emoji}`
	if (reactingKey.value === key) return

	reactingKey.value = key
	const api = useApi()
	const res = await api.post<{ action: string; items: MaterialCommentItem[] }>(
		`/api/materials/${materialId.value}/comments/${commentId}/reactions`,
		{ emoji },
	)
	if (res.success) {
		comments.value = res.data.items
	}
	reactingKey.value = ''
}

async function loadMaterial() {
	error.value = ''
	accessDenied.value = false
	guestPreview.value = null
	mediaDownloadUrl.value = null
	mediaDownloadable.value = false
	videoResumeSeconds.value = 0
	audioResumeSeconds.value = 0
	audioResumeFileIndex.value = 0
	lastVideoProgress.value = null
	lastAudioProgress.value = null
	lastSavedVideoProgressSeconds.value = 0
	lastSavedAudioProgressSeconds.value = 0
	const cachedDetail = materialsStore.getDetailSnapshot(materialId.value)
	const cachedMedia = materialsStore.getMediaSnapshot(materialId.value)

	if (cachedDetail) {
		material.value = cachedDetail
		loading.value = false
	}

	if (cachedMedia) {
		mediaUrl.value = cachedMedia.url
		mediaDownloadUrl.value = cachedMedia.downloadUrl ?? null
		mediaDownloadable.value = cachedMedia.downloadable === true
		materialFiles.value = cachedMedia.files
	}

	if (!cachedDetail) {
		restoreMaterialFromCache()
		if (material.value) {
			loading.value = false
		}
	}

	if (!cachedMedia) {
		restoreMediaUrlFromCache()
	}

	try {
		if (!auth.user) await auth.restoreSession()
		if (!auth.user) {
			await loadGuestPreview()
			return
		}
		const detail = await materialsStore.fetchDetail(materialId.value, true)
		material.value = detail
		persistMaterialCache(detail)
		void favoritesStore.loadStatus(materialId.value)

		if (hasStoredMediaFiles(detail.storagePath)) {
			const mediaPayload = await materialsStore.fetchMedia(materialId.value, true)
			mediaUrl.value = mediaPayload.url
			mediaDownloadUrl.value = mediaPayload.downloadUrl ?? null
			mediaDownloadable.value = mediaPayload.downloadable === true
			materialFiles.value = mediaPayload.files
			if (mediaPayload.url) {
				persistMediaUrlCache(mediaPayload.url, mediaPayload.expiresIn)
			}
		}
		await loadVideoProgress()
		await loadAudioProgress()
		await loadComments()
	} catch (err) {
		const code =
			typeof err === 'object' && err && 'code' in err ? String(err.code ?? '') : undefined
		if (code === 'FORBIDDEN' || code === 'SUBSCRIPTION_EXPIRED' || code === 'UNAUTHORIZED') {
			try {
				await loadGuestPreview()
				return
			} catch (guestError) {
				const guestCode =
					typeof guestError === 'object' && guestError && 'code' in guestError
						? String(guestError.code ?? '')
						: ''
				if (guestCode === 'GUEST_ACCESS_REQUIRED') {
					await navigateTo({
						path: '/app',
						query: { access: 'required', redirect: route.fullPath },
					})
					return
				}
			}
		}
		accessDenied.value = code === 'FORBIDDEN'
		error.value =
			err instanceof Error && err.message
				? err.message
				: 'Не удалось загрузить материал. Попробуйте ещё раз.'
	}

	loading.value = false
}

async function loadGuestPreview() {
	const api = useApi()
	const response = await api.get<{
		material: Material
		blockAccess: Record<'cover' | 'description' | 'link', GuestContentBlockAccess>
		files: GuestMaterialFile[]
	}>(`/api/materials/public-preview/${materialId.value}`, { authRedirect: false })
	if (!response.success) {
		throw Object.assign(new Error(response.error.message), { code: response.error.code })
	}
	material.value = response.data.material
	guestPreview.value = { blockAccess: response.data.blockAccess, files: response.data.files }
	materialFiles.value = response.data.files.map((file) => ({
		index: file.index,
		name: file.name,
		type: file.type,
		url: file.url,
		downloadUrl: null,
		downloadable: false,
	}))
	loading.value = false
}

function requestGuestAccess() {
	accessModalOpen.value = true
}

function openGuestAccess(intent: 'login' | 'pay') {
	accessModalOpen.value = false
	if (intent === 'login') {
		void navigateTo({ path: '/login', query: { redirect: route.fullPath } })
		return
	}
	void navigateTo('/app/payment')
}

onMounted(async () => {
	await loadMaterial()
	if (import.meta.client) {
		window.addEventListener('pagehide', onPageHide)
		document.addEventListener('visibilitychange', onVisibilityChange)
	}
})

function onPageHide() {
	if (lastVideoProgress.value) {
		queueVideoProgressSave(lastVideoProgress.value, { force: true, keepalive: true })
	}
	if (lastAudioProgress.value) {
		queueAudioProgressSave(lastAudioProgress.value, { force: true, keepalive: true })
	}
}

function onVisibilityChange() {
	if (document.visibilityState === 'hidden' && lastVideoProgress.value) {
		queueVideoProgressSave(lastVideoProgress.value, { force: true, keepalive: true })
	}
	if (document.visibilityState === 'hidden' && lastAudioProgress.value) {
		queueAudioProgressSave(lastAudioProgress.value, { force: true, keepalive: true })
	}
}

onBeforeUnmount(() => {
	if (import.meta.client) {
		window.removeEventListener('pagehide', onPageHide)
		document.removeEventListener('visibilitychange', onVisibilityChange)
	}
	clearVideoProgressTimer()
	clearAudioProgressTimer()
	if (lastVideoProgress.value) {
		void saveVideoProgress(lastVideoProgress.value, { force: true, keepalive: true })
	}
	if (lastAudioProgress.value) {
		void saveAudioProgress(lastAudioProgress.value, { force: true, keepalive: true })
	}
})

onBeforeRouteLeave(() => {
	clearVideoProgressTimer()
	clearAudioProgressTimer()
	if (lastVideoProgress.value) {
		void saveVideoProgress(lastVideoProgress.value, { force: true, keepalive: true })
	}
	if (lastAudioProgress.value) {
		void saveAudioProgress(lastAudioProgress.value, { force: true, keepalive: true })
	}
})

const visibleFiles = computed(() => {
	if (!material.value) return []
	if (resolvedMediaType.value === 'audio') {
		return materialFiles.value.filter((file) => file.type !== 'audio')
	}
	if (!resolvedMediaType.value || resolvedMediaType.value === 'document') {
		return materialFiles.value
	}

	let primaryFileSkipped = false
	return materialFiles.value.filter((file) => {
		if (!primaryFileSkipped && file.type === resolvedMediaType.value) {
			primaryFileSkipped = true
			return false
		}
		return true
	})
})

const primaryVideoFile = computed(
	() => materialFiles.value.find((file) => file.type === 'video') ?? null,
)
const additionalVideoFiles = computed(() =>
	resolvedMediaType.value === 'video'
		? visibleFiles.value.filter(
				(file): file is MaterialDownloadFile & { url: string } =>
					file.type === 'video' && typeof file.url === 'string' && file.url.length > 0,
			)
		: [],
)
const documentFiles = computed(() => visibleFiles.value.filter((file) => file.type !== 'video'))

function setVideoPlayer(index: number, instance: unknown) {
	if (instance && typeof (instance as VideoPlayerInstance).seekTo === 'function') {
		videoPlayers.set(index, instance as VideoPlayerInstance)
		return
	}
	videoPlayers.delete(index)
}

function seekVideoChapter(index: number, seconds: number) {
	videoPlayers.get(index)?.seekTo(seconds)
}

function setGuestVideoPlayer(index: number, element: unknown) {
	if (
		typeof element === 'object' &&
		element !== null &&
		'seekTo' in element &&
		typeof element.seekTo === 'function'
	) {
		guestVideoPlayers.set(index, element as VideoPlayerInstance)
		return
	}
	guestVideoPlayers.delete(index)
}

function seekGuestVideoChapter(index: number, seconds: number) {
	guestVideoPlayers.get(index)?.seekTo(seconds)
}

const videoPosterUrl = computed(
	() => material.value?.videoCoverUrl ?? material.value?.imageUrl ?? undefined,
)
const normalizedFullDescription = computed(() =>
	(material.value?.fullDescription ?? material.value?.shortDescription ?? '')
		.replace(/\s+/g, ' ')
		.trim(),
)
const showFullDescription = computed(() => Boolean(normalizedFullDescription.value))
const guestPrimaryFile = computed(
	() => guestPreview.value?.files.find((file) => file.type === resolvedMediaType.value) ?? null,
)
</script>

<template>
	<div class="club-page material-detail min-h-screen text-[var(--app-text)]" :style="materialTheme">
		<header class="material-detail__toolbar">
			<div class="material-detail__toolbar-inner">
				<button type="button" class="material-detail__action" aria-label="Назад к разделу" @click="returnToSection">
					<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</button>
				<div class="flex-1" />
				<button type="button" class="material-detail__action" :class="{ 'is-favorite': isFavorite }" :aria-label="isFavorite ? 'Убрать из избранного' : 'Добавить в избранное'" :aria-pressed="isFavorite" :disabled="favoriteSaving" @click="toggleFavorite">
					<svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m12 3 2.78 5.64 6.22.9-4.5 4.39 1.06 6.2L12 17.2l-5.56 2.93 1.06-6.2L3 9.54l6.22-.9L12 3Z" /></svg>
				</button>
			</div>
		</header>

		<div v-if="loading" class="py-2">
			<AppScreenSkeleton variant="detail" />
		</div>

		<div v-else-if="error" class="flex items-center justify-center h-[60vh]">
			<div
				class="mx-4 max-w-md rounded-3xl border p-6 text-center"
				:class="
					accessDenied
						? 'border-[color-mix(in_srgb,var(--app-accent)_24%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_10%,var(--app-surface))]'
						: 'border-[color-mix(in_srgb,var(--app-danger)_24%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-danger)_8%,var(--app-surface))]'
				"
			>
				<p
					class="mb-4"
					:class="accessDenied ? 'text-[var(--app-accent-strong)]' : 'text-[var(--app-danger)]'"
				>
					{{ error }}
				</p>
				<p v-if="accessDenied" class="mb-4 text-sm text-[var(--app-muted)]">
					Этот материал недоступен для вашего аккаунта.
				</p>
				<button type="button" class="text-primary-400 hover:underline" @click="returnToSection">
					Назад к списку
				</button>
			</div>
		</div>

		<div v-else-if="material && guestPreview" class="pb-8">
			<div class="px-4 pt-4 md:px-6">
				<MaterialDetailHero :title="material.title" :type="contentType" :type-label="materialTypeLabel" :access="guestPreview.blockAccess.cover" @request-access="requestGuestAccess" />
			</div>

			<div v-if="guestPrimaryFile" class="px-4 pt-4 md:px-6">
				<div class="space-y-3">
					<GuestContentBlock :access="guestPrimaryFile.access" variant="media" @request-access="requestGuestAccess">
					<template v-if="guestPrimaryFile.type === 'video'" #preview>
						<div class="w-full aspect-video">
							<img v-if="videoPosterUrl" :src="videoPosterUrl" :alt="material.title" class="h-full w-full object-cover" />
							<MaterialFallbackCover v-else :type="contentType" size="hero" />
						</div>
					</template>
						<MaterialVideoPreview v-if="guestPrimaryFile.type === 'video' && guestPrimaryFile.url" :ref="(instance) => setGuestVideoPlayer(guestPrimaryFile.index, instance)" :src="guestPrimaryFile.url" :poster="videoPosterUrl" :title="guestPrimaryFile.name || material.title" :downloadable="false" />
						<img v-else-if="guestPrimaryFile.type === 'image' && guestPrimaryFile.url" :src="guestPrimaryFile.url" :alt="material.title" class="w-full rounded-3xl" />
						<audio v-else-if="guestPrimaryFile.type === 'audio' && guestPrimaryFile.url" :src="guestPrimaryFile.url" class="w-full" controls />
					</GuestContentBlock>
<MaterialVideoChapters v-if="guestPrimaryFile.type === 'video' && guestPrimaryFile.chapters" :chapters="guestPrimaryFile.chapters" @seek="guestPrimaryFile.access === 'visible' ? seekGuestVideoChapter(guestPrimaryFile.index, $event) : requestGuestAccess()" />
					</div>
				</div>

				<!-- Скрытый контент — на месте основного блока материала (как у участника), а не под описанием.
					Показывается только если есть ссылка на пост либо у шаблонов (закрытый контент = сам шаблон).
					У видео-уроков ссылки нет — второй плашки быть не должно. -->
				<div
					v-if="material.telegramPostUrl || (contentType === 'checklists' && guestPreview.blockAccess.link !== 'visible')"
					class="px-4 pt-4 md:px-6"
				>
					<GuestContentBlock :access="guestPreview.blockAccess.link" @request-access="requestGuestAccess">
						<a v-if="material.telegramPostUrl" :href="material.telegramPostUrl" target="_blank" rel="noopener noreferrer" class="club-card block rounded-3xl p-5 text-sm font-medium text-primary-300">Открыть ссылку</a>
					</GuestContentBlock>
				</div>

				<div class="p-4 md:px-6">
					<GuestContentBlock :access="guestPreview.blockAccess.description" @request-access="requestGuestAccess">
						<div v-if="showFullDescription" class="club-card rounded-3xl p-5 md:p-6"><h2 class="template-detail-section-title">Описание</h2><MediaTextViewer :content="material.fullDescription ?? material.shortDescription ?? ''" compact /></div>
					</GuestContentBlock>
				</div>

				<TemplateLessonBanner v-if="contentType === 'checklists'" />

				<div v-if="guestPreview.files.length > 1" class="space-y-3 p-4 md:px-6">
				<GuestContentBlock v-for="file in guestPreview.files.filter((item) => item.index !== guestPrimaryFile?.index)" :key="file.index" :access="file.access" @request-access="requestGuestAccess">
					<a v-if="file.url" :href="file.url" target="_blank" rel="noopener noreferrer" class="club-card block rounded-3xl p-5 text-sm font-medium text-primary-300">{{ file.name }}</a>
				</GuestContentBlock>
			</div>
		</div>

		<div v-else-if="material" class="pb-8">
			<div class="px-4 pt-4 md:px-6">
				<MaterialDetailHero :title="material.title" :type="contentType" :type-label="materialTypeLabel" />
			</div>

			<div v-if="resolvedMediaType === 'video' && mediaUrl" class="px-4 pt-4 md:px-6">
				<div class="space-y-3">
					<MaterialVideoPreview
						:ref="(instance) => setVideoPlayer(primaryVideoFile?.index ?? 0, instance)"
						:src="mediaUrl"
						:poster="videoPosterUrl"
						:title="primaryVideoFile?.name || material.title"
						:download-url="mediaDownloadUrl"
						:downloadable="mediaDownloadable"
						:initial-time="videoResumeSeconds"
						@progress="handleVideoProgress"
					/>
					<MaterialVideoChapters
						v-if="primaryVideoFile?.chapters"
						:chapters="primaryVideoFile.chapters"
						@seek="seekVideoChapter(primaryVideoFile.index, $event)"
					/>
				</div>
			</div>

			<div v-else-if="resolvedMediaType === 'audio' && audioPlaylist.length" class="space-y-2.5 p-4 md:px-6">
				<MediaAudioPlayer
					v-for="(track, index) in audioPlaylist"
					:key="track.fileIndex"
					:id="`material-audio-card-${track.fileIndex}`"
					class="mx-auto w-[92%] max-w-sm"
					:src="track.src"
					:title="track.title"
					:download-url="track.downloadUrl"
					:downloadable="track.downloadable"
					:media-file-index="track.fileIndex"
					:initial-time="audioResumeFileIndex === track.fileIndex ? audioResumeSeconds : 0"
					:active-media-file-index="activeAudioCardFileIndex"
					:autoplay-signal="audioAutoplaySignal"
					:can-go-previous="audioPlaylist.length > 1"
					:can-go-next="audioPlaylist.length > 1"
					cross-card-navigation
					@progress="handleAudioProgress"
					@activated="handleAudioActivated"
					@request-previous="playPreviousAudio(index)"
					@request-next="playNextAudio(index)"
				/>
			</div>

			<div v-else-if="resolvedMediaType === 'image' && mediaUrl" class="p-4 md:px-6">
				<MediaImageViewer
					:src="mediaUrl"
					:alt="material.title"
					:download-url="mediaDownloadUrl"
					:downloadable="mediaDownloadable"
				/>
			</div>

			<div v-else-if="resolvedMediaType === 'text' && !showFullDescription" class="p-4">
				<MediaTextViewer :content="material.fullDescription ?? material.shortDescription ?? ''" />
			</div>

			<div
				v-else-if="resolvedMediaType === 'document' && documentFiles.length"
				class="p-4 md:px-6"
			>
				<MediaDocumentViewer :files="documentFiles" />
			</div>

			<div v-else-if="!showFullDescription" class="p-4">
				<div class="club-card rounded-2xl p-6">
					<h2 class="text-xl font-semibold mb-4">{{ material.title }}</h2>
					<p class="text-sm text-[var(--app-muted)]">Дополнительный файл для этого материала не прикреплён.</p>
				</div>
			</div>

			<div v-if="additionalVideoFiles.length" class="space-y-4 px-4 pt-4 md:px-6">
				<section v-for="file in additionalVideoFiles" :key="file.index" class="space-y-3">
					<MaterialVideoPreview
						:ref="(instance) => setVideoPlayer(file.index, instance)"
						:src="file.url"
						:poster="videoPosterUrl"
						:title="file.name || material.title"
						:download-url="file.downloadUrl"
						:downloadable="file.downloadable"
					/>
					<MaterialVideoChapters
						v-if="file.chapters"
						:chapters="file.chapters"
						@seek="seekVideoChapter(file.index, $event)"
					/>
				</section>
			</div>

			<div v-if="showFullDescription" class="px-4 pt-4 md:px-6">
				<div class="club-card rounded-3xl p-5 md:p-6">
					<h2 class="template-detail-section-title">Описание</h2>
					<MediaTextViewer :content="material.fullDescription ?? material.shortDescription ?? ''" compact />
				</div>
			</div>

			<TemplateLessonBanner v-if="contentType === 'checklists'" />

			<div
				v-if="resolvedMediaType !== 'document' && documentFiles.length"
				class="p-4 md:px-6"
			>
				<MediaDocumentViewer :files="documentFiles" />
			</div>

			<div v-if="material.commentsEnabled" class="p-4 md:px-6">
				<div class="club-card rounded-3xl p-5 md:p-6">
					<div class="flex items-center justify-between gap-3">
						<div>
							<h2 class="text-lg font-semibold text-[var(--app-text-strong)]">Комментарии</h2>
						</div>
						<span class="rounded-full border border-[var(--app-border)] px-3 py-1 text-xs text-[var(--app-muted)]">
							{{ totalComments }}
						</span>
					</div>

					<div class="mt-5">
						<div
							v-if="replyTo || editingComment"
							class="mb-4 flex items-start justify-between gap-3 rounded-[22px] border border-[color-mix(in_srgb,var(--app-accent)_24%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_10%,var(--app-surface))] px-4 py-3"
						>
							<div class="min-w-0">
								<p class="text-xs font-medium uppercase tracking-[0.16em] text-[var(--app-accent-strong)]">
									{{ editingComment ? 'Редактирование комментария' : `Ответ для ${getCommentAuthorName(replyTo!)}` }}
								</p>
								<p class="mt-1 truncate text-sm text-[var(--app-muted)]">
									{{ editingComment ? editingComment.content : replyTo?.content }}
								</p>
							</div>
							<button class="text-xs font-medium text-[var(--app-accent-strong)] transition hover:text-[var(--app-accent)]" @click="resetCommentComposer">Отмена</button>
						</div>

						<div class="rounded-[26px] border border-[var(--app-border)] bg-[var(--app-bg)] p-3 shadow-[var(--app-shadow-soft)] md:p-4">
							<textarea
								v-model="commentDraft"
								rows="3"
								class="min-h-[112px] w-full resize-none rounded-[22px] border border-[var(--app-border)] bg-[var(--app-surface)] px-4 py-3.5 text-sm leading-6 text-[var(--app-text)] outline-none transition placeholder:text-[var(--app-muted-soft)] focus:border-[var(--app-accent)]"
								:placeholder="commentPlaceholder"
							/>
							<div class="mt-3 flex justify-end">
								<button
									class="inline-flex h-11 min-w-[132px] items-center justify-center rounded-[18px] bg-[var(--app-button-bg)] px-5 text-sm font-medium text-[var(--app-button-fg)] transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-45"
									:disabled="!commentDraft.trim() || submittingComment"
									@click="submitComment"
								>
									<span v-if="submittingComment" class="inline-flex items-center gap-2">
										<span class="h-4 w-4 animate-spin rounded-full border-2 border-[color-mix(in_srgb,var(--app-button-fg)_20%,transparent)] border-t-[var(--app-button-fg)]" />
										Отправка
									</span>
									<span v-else>{{ editingComment ? 'Сохранить' : 'Отправить' }}</span>
								</button>
							</div>
						</div>
					</div>

					<div v-if="commentsLoading" class="mt-5 text-sm text-[var(--app-muted-soft)]">
						Загружаю комментарии...
					</div>
					<div v-else-if="comments.length === 0" class="mt-5 rounded-3xl border border-dashed border-[var(--app-border)] px-4 py-8 text-center text-sm text-[var(--app-muted-soft)]">
						Пока комментариев нет.
					</div>
					<div v-else class="mt-5 space-y-4">
						<MaterialCommentThread
							v-for="comment in comments"
							:key="comment.id"
							:comment="comment"
							:current-user-id="auth.user?.authUuid ?? null"
							@reply="startReply"
							@edit="startEdit"
							@remove="removeComment"
							@react="toggleReaction"
						/>
					</div>
				</div>
			</div>
		</div>

		<AccessRequiredModal
			v-model:open="accessModalOpen"
			:redirect="route.fullPath"
			@login="openGuestAccess('login')"
			@pay="openGuestAccess('pay')"
		/>
	</div>
</template>

<style scoped>
.material-detail { max-width: 42rem; margin: 0 auto; padding: 0; background: transparent; }
.material-detail__toolbar { position: sticky; top: 0; z-index: 32; padding: 0.65rem 1rem; border-bottom: 1px solid var(--app-border); background: rgb(255 255 255 / 0.9); box-shadow: var(--app-shadow-soft); backdrop-filter: blur(18px); }
.material-detail__toolbar-inner { display: flex; align-items: center; max-width: 42rem; margin: 0 auto; }
.material-detail__action { display: inline-grid; width: 2.6rem; height: 2.6rem; place-items: center; border: 1px solid var(--app-border); border-radius: 0.85rem; background: var(--app-surface); color: var(--app-muted); box-shadow: inset 0 1px rgb(255 255 255 / 0.96); transition: transform 0.18s ease, color 0.18s ease, border-color 0.18s ease, background 0.18s ease; }
.material-detail__action:hover { border-color: color-mix(in srgb, var(--section-accent) 52%, var(--app-border)); color: var(--app-text); }
.material-detail__action:active { transform: scale(0.94); }
.material-detail__action.is-favorite { border-color: color-mix(in srgb, var(--section-accent) 68%, transparent); background: var(--section-accent-soft); color: var(--section-accent); }

.template-detail-section-title {
	margin: 0 0 0.75rem;
	color: var(--app-accent-strong);
	font-family: inherit;
	font-size: 0.82rem;
	font-weight: 700;
	letter-spacing: 0.16em;
	text-transform: uppercase;
}
</style>
