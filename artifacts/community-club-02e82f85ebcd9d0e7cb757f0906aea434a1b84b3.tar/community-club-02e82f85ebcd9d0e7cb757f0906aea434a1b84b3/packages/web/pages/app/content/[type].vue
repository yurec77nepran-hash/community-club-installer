<script setup lang="ts">
import { MATERIAL_TYPES } from '@community-club/shared/constants'
import type { CursorPaginatedResponse } from '@community-club/shared/types'
import MaterialFallbackCover from '~/components/materials/MaterialFallbackCover.vue'
import RecentMaterialsGrid from '~/components/materials/RecentMaterialsGrid.vue'
import AppScreenSkeleton from '~/components/ui/AppScreenSkeleton.vue'
import type { MaterialPreview } from '~/stores/materials'
import { getMaterialTheme } from '~/utils/material-theme'
import { withBuildVersion } from '~/utils/pwa-update'

definePageMeta({ middleware: ['auth', 'subscription'] })

const route = useRoute()
const materialsStore = useMaterialsStore()
const auth = useAuthStore()
const api = useApi()
const buildId = useRuntimeConfig().app.buildId
const type = computed(() => String(route.params.type ?? ''))
const isGuest = computed(() => !auth.isAuthenticated)
const isShopSection = computed(() => type.value === 'shop')
const backTarget = computed(() => '/app')

function returnToHome() {
	return navigateTo(backTarget.value, { replace: true })
}
const isDetailRouteActive = computed(() => {
	const id = route.params.id
	return typeof id === 'string' ? id.length > 0 : Array.isArray(id) && id.length > 0
})
const title = computed(
	() => MATERIAL_TYPES[type.value as keyof typeof MATERIAL_TYPES] ?? type.value,
)
const sectionCatalogues = {
	checklists: {
		id: 'templates',
		title: 'Шаблоны',
		subtitle: 'Готовые цифровые решения',
		motto: 'Библиотека клуба',
		image: withBuildVersion('/images/home/section-templates.webp', buildId),
		accent: 'var(--app-accent-violet)',
		accentSoft: 'color-mix(in srgb, var(--app-accent-violet) 14%, transparent)',
		icon: 'case',
	},
	courses: {
		id: 'lessons',
		title: 'Уроки',
		subtitle: 'Вайбкодинг и продажи',
		motto: 'Практика клуба',
		image: withBuildVersion('/images/home/section-lessons.webp', buildId),
		accent: 'var(--app-accent-blue)',
		accentSoft: 'color-mix(in srgb, var(--app-accent-blue) 14%, transparent)',
		icon: 'book',
	},
	other: {
		id: 'tools',
		title: 'Инструменты',
		subtitle: 'Полезные инструменты',
		motto: 'Инструменты клуба',
		image: withBuildVersion('/images/home/section-tools.webp', buildId),
		accent: 'var(--app-accent-amber)',
		accentSoft: 'color-mix(in srgb, var(--app-accent-amber) 14%, transparent)',
		icon: 'wrench',
	},
	streams: {
		id: 'streams',
		title: 'Эфиры',
		subtitle: 'Эфиры клуба',
		motto: 'Встречи клуба',
		image: withBuildVersion('/images/home/section-streams.webp', buildId),
		accent: 'var(--app-accent-wine)',
		accentSoft: 'color-mix(in srgb, var(--app-accent-wine) 14%, transparent)',
		icon: 'microphone',
	},
	experts: {
		id: 'experts',
		title: 'От экспертов',
		subtitle: 'Материалы приглашённых экспертов',
		motto: 'Опыт клуба',
		image: withBuildVersion('/images/home/section-experts.webp', buildId),
		accent: 'var(--app-accent-slate)',
		accentSoft: 'color-mix(in srgb, var(--app-accent-slate) 14%, transparent)',
		icon: 'star',
	},
} as const
const sectionCatalogue = computed(
	() => sectionCatalogues[type.value as keyof typeof sectionCatalogues],
)
const shopShowcase = [
	{
		id: 'site',
		image: '/shop/official-site.jpg',
		text: 'Официальный сайт',
		buttonLabel: 'Открыть сайт',
		href: 'https://shop.example.com',
	},
	{
		id: 'wb',
		image: '/shop/marketplace-official.jpg',
		text: 'Наш официальный магазин',
		buttonLabel: 'Перейти в магазин',
		href: 'https://marketplace.example.com/seller',
	},
	{
		id: 'max',
		image: '/shop/max-channel.jpg',
		text: 'Официальный канал в MAX',
		buttonLabel: 'Перейти в MAX',
		href: 'https://max.ru/exampleclub',
	},
] as const

const shopLinks = [
	{
		icon: '/shop/icons/youtube.svg',
		label: 'YouTube',
		href: 'https://youtube.com/@exampleclub',
	},
	{
		icon: '/shop/icons/telegram.svg',
		label: 'Telegram',
		href: 'https://t.me/exampleclub',
	},
	{
		icon: '/shop/icons/instagram.svg',
		label: 'Instagram',
		href: 'https://www.instagram.com/exampleclub',
	},
	{
		icon: '/shop/icons/instagram.svg',
		label: 'Instagram',
		href: 'https://www.instagram.com/exampleclub',
	},
	{
		icon: '/shop/icons/vk.svg',
		label: 'VK',
		href: 'https://vk.com/exampleclub',
	},
	{
		icon: '/shop/icons/max.png',
		label: 'MAX',
		href: 'https://max.ru/exampleclub',
	},
	{
		icon: '/shop/icons/rutube.svg',
		label: 'RuTube',
		href: 'https://rutube.ru/channel/exampleclub/',
	},
] as const

const materials = ref<MaterialPreview[]>([])
const subsections = ref<string[]>([])
const loading = ref(true)
const error = ref('')
const pageSize = 24
const search = ref('')
const activeSubsection = ref('')
const filterOpen = ref(false)
const dateFrom = ref('')
const dateTo = ref('')
const sortOrder = ref<'oldest' | 'newest'>('newest')
const cursor = ref<string | null>(null)
const hasMore = ref(true)
const loadingMore = ref(false)
const loadMoreSentinel = ref<HTMLElement | null>(null)
const searchTimeout = ref<ReturnType<typeof setTimeout> | null>(null)
let observer: IntersectionObserver | null = null
let listRequestId = 0
function sortMaterials(items: MaterialPreview[]) {
	return [...items].sort((left, right) => {
		const leftTime = new Date(left.createdAt).getTime()
		const rightTime = new Date(right.createdAt).getTime()

		if (sortOrder.value === 'oldest') {
			if (leftTime !== rightTime) return leftTime - rightTime
			return left.id - right.id
		}

		if (leftTime !== rightTime) return rightTime - leftTime
		return right.id - left.id
	})
}

function getScrollStateKey() {
	return `content-scroll:${type.value}`
}

function getListStateKey() {
	return `content-state:${type.value}`
}

function persistListState() {
	if (!import.meta.client || !type.value) return

	try {
		sessionStorage.setItem(
			getListStateKey(),
			JSON.stringify({
				timestamp: Date.now(),
				materials: materials.value,
				cursor: cursor.value,
				hasMore: hasMore.value,
				search: search.value,
				activeSubsection: activeSubsection.value,
				filterOpen: filterOpen.value,
				dateFrom: dateFrom.value,
				dateTo: dateTo.value,
				sortOrder: sortOrder.value,
			}),
		)
	} catch {}
}

function restoreListState() {
	if (!import.meta.client || !type.value) return false

	try {
		const raw = sessionStorage.getItem(getListStateKey())
		if (!raw) return false

		const cached = JSON.parse(raw) as {
			timestamp?: number
			materials?: MaterialPreview[]
			cursor?: string | null
			hasMore?: boolean
			search?: string
			activeSubsection?: string
			filterOpen?: boolean
			dateFrom?: string
			dateTo?: string
			sortOrder?: 'oldest' | 'newest'
		}

		if (!cached.timestamp || Date.now() - cached.timestamp > 30 * 60_000) {
			sessionStorage.removeItem(getListStateKey())
			return false
		}

		filterOpen.value = Boolean(cached.filterOpen)
		dateFrom.value = typeof cached.dateFrom === 'string' ? cached.dateFrom : ''
		dateTo.value = typeof cached.dateTo === 'string' ? cached.dateTo : ''
		sortOrder.value = cached.sortOrder === 'oldest' ? 'oldest' : 'newest'
		materials.value = sortMaterials(Array.isArray(cached.materials) ? cached.materials : [])
		cursor.value = typeof cached.cursor === 'string' ? cached.cursor : null
		hasMore.value = typeof cached.hasMore === 'boolean' ? cached.hasMore : true
		search.value = typeof cached.search === 'string' ? cached.search : ''
		activeSubsection.value =
			typeof cached.activeSubsection === 'string' ? cached.activeSubsection : ''
		loading.value = false
		error.value = ''
		sessionStorage.removeItem(getListStateKey())
		return materials.value.length > 0
	} catch {
		return false
	}
}

function persistScrollPosition() {
	if (!import.meta.client || !type.value) return

	try {
		sessionStorage.setItem(getScrollStateKey(), String(window.scrollY))
	} catch {}
}

async function restoreScrollPosition() {
	if (!import.meta.client || !type.value) return

	try {
		const raw = sessionStorage.getItem(getScrollStateKey())
		if (!raw) return

		const top = Number(raw)
		if (!Number.isFinite(top) || top < 0) return

		await nextTick()
		requestAnimationFrame(() => {
			window.scrollTo({ top, behavior: 'auto' })
		})
	} catch {}
}

async function loadSubsections() {
	if (isGuest.value) {
		const response = await api.get<string[]>(
			`/api/materials/public-preview/subsections?type=${encodeURIComponent(type.value)}`,
			{ authRedirect: false, cache: 'no-store', skipCache: true },
		)
		subsections.value = response.success ? response.data : []
		return
	}

	const cached = materialsStore.getSubsectionsSnapshot(type.value)
	if (cached) {
		subsections.value = cached
	}

	try {
		subsections.value = await materialsStore.fetchSubsections(type.value, true)
	} catch {
		subsections.value = cached ?? []
	}
}

async function loadMaterials(options?: { reset?: boolean }) {
	const reset = options?.reset ?? false
	const requestId = ++listRequestId

	if (reset) {
		loadingMore.value = false
		cursor.value = null
		hasMore.value = true
		loading.value = true
	}

	if ((!reset && !hasMore.value) || loadingMore.value) {
		if (reset) {
			loading.value = false
		}
		return
	}

	if (!reset) {
		loadingMore.value = true
	}

	error.value = ''
	try {
		const params = {
			type: type.value,
			limit: pageSize,
			cursor: cursor.value,
			search: search.value,
			subsection: activeSubsection.value,
			dateFrom: dateFrom.value || undefined,
			dateTo: dateTo.value || undefined,
			sort: sortOrder.value,
		}
		let list: CursorPaginatedResponse<MaterialPreview>
		if (isGuest.value) {
			const query = new URLSearchParams({ type: params.type, limit: String(params.limit) })
			if (params.cursor) query.set('cursor', params.cursor)
			if (params.search) query.set('search', params.search)
			if (params.subsection) query.set('subsection', params.subsection)
			if (params.dateFrom) query.set('dateFrom', params.dateFrom)
			if (params.dateTo) query.set('dateTo', params.dateTo)
			if (params.sort) query.set('sort', params.sort)

			const response = await api.get<CursorPaginatedResponse<MaterialPreview>>(
				`/api/materials/public-preview?${query.toString()}`,
				{ authRedirect: false, cache: 'no-store', skipCache: true },
			)
			if (!response.success) {
				throw new Error(response.error.message || 'Не удалось загрузить материалы.')
			}
			list = response.data
		} else {
			list = await materialsStore.fetchList(params, reset)
		}

		if (requestId !== listRequestId) {
			return
		}

		const incoming = list.items
		materials.value = sortMaterials(
			reset
				? incoming
				: [
						...materials.value,
						...incoming.filter(
							(item) => !materials.value.some((existing) => existing.id === item.id),
						),
					],
		)

		cursor.value = list.nextCursor
		hasMore.value = Boolean(list.nextCursor)
	} catch (err) {
		if (requestId !== listRequestId) {
			return
		}
		error.value =
			err instanceof Error && err.message
				? err.message
				: 'Не удалось загрузить материалы. Попробуйте ещё раз.'
		loading.value = false
		loadingMore.value = false
		return
	}

	if (requestId !== listRequestId) {
		return
	}

	loading.value = false
	loadingMore.value = false
}

function warmMaterial(id: number) {
	if (isGuest.value) return
	void materialsStore.warmMaterial(id)
}

function rememberListStateForReturn() {
	persistListState()
	persistScrollPosition()
}

function onSearch() {
	if (searchTimeout.value) {
		clearTimeout(searchTimeout.value)
	}

	searchTimeout.value = setTimeout(() => {
		void loadMaterials({ reset: true })
	}, 250)
}

function clearSearch() {
	search.value = ''
	void loadMaterials({ reset: true })
}

function toggleFilters() {
	filterOpen.value = !filterOpen.value
}

function applyFilters() {
	void loadMaterials({ reset: true })
}

function clearFilters() {
	dateFrom.value = ''
	dateTo.value = ''
	sortOrder.value = 'newest'
	void loadMaterials({ reset: true })
}

function setSubsection(sub: string) {
	activeSubsection.value = activeSubsection.value === sub ? '' : sub
	void loadMaterials({ reset: true })
}

function formatDuration(seconds: number | null) {
	if (!seconds) return ''
	return `${Math.floor(seconds / 60)} мин`
}

function formatPublishedAt(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: 'numeric',
		month: 'short',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function getPreviewDescription(item: MaterialPreview) {
	return (item.shortDescription || item.fullDescription || '').replace(/\s+/g, ' ').trim()
}

function materialCardStyle(item: MaterialPreview) {
	const theme = getMaterialTheme(item.type)
	return { '--section-accent': theme.accent, '--section-accent-soft': theme.soft }
}

async function loadMore() {
	if (loadingMore.value || loading.value || !hasMore.value) return
	await loadMaterials()
}

watch(type, async () => {
	if (isDetailRouteActive.value) return

	activeSubsection.value = ''
	search.value = ''
	dateFrom.value = ''
	dateTo.value = ''
	sortOrder.value = 'newest'
	filterOpen.value = false
	if (sectionCatalogue.value) {
		materials.value = []
		subsections.value = []
		loading.value = false
		error.value = ''
		return
	}
	if (isShopSection.value) {
		materials.value = []
		subsections.value = []
		loading.value = false
		error.value = ''
		return
	}
	await Promise.all([loadSubsections(), loadMaterials({ reset: true })])
})

onBeforeRouteLeave((to) => {
	const nextType =
		typeof to.params.type === 'string'
			? to.params.type
			: Array.isArray(to.params.type)
				? to.params.type[0]
				: ''
	const nextId =
		typeof to.params.id === 'string'
			? to.params.id
			: Array.isArray(to.params.id)
				? to.params.id[0]
				: ''

	if (nextType === type.value && nextId) {
		rememberListStateForReturn()
	}
})

onMounted(async () => {
	if (sectionCatalogue.value || isShopSection.value || isDetailRouteActive.value) {
		loading.value = false
		return
	}

	observer = new IntersectionObserver(
		(entries) => {
			if (entries.some((entry) => entry.isIntersecting)) {
				void loadMore()
			}
		},
		{ threshold: 0.2 },
	)

	watch(
		loadMoreSentinel,
		(current, previous) => {
			if (previous) {
				observer?.unobserve(previous)
			}
			if (current) {
				observer?.observe(current)
			}
		},
		{ immediate: true },
	)

	const restored = restoreListState()
	await loadSubsections()
	if (restored) {
		await restoreScrollPosition()
		return
	}
	await loadMaterials({ reset: true })
})

watch(isDetailRouteActive, async (active, wasActive) => {
	if (sectionCatalogue.value) return
	if (active) {
		rememberListStateForReturn()
		return
	}

	if (wasActive) {
		await Promise.all([loadSubsections(), loadMaterials({ reset: true })])
		void restoreScrollPosition()
	}
})

onUnmounted(() => {
	if (observer) {
		observer.disconnect()
		observer = null
	}
	if (searchTimeout.value) {
		clearTimeout(searchTimeout.value)
		searchTimeout.value = null
	}
})
</script>

<template>
	<NuxtPage v-if="isDetailRouteActive" />
	<RecentMaterialsGrid
		v-else-if="sectionCatalogue"
		:type="type"
		:section="sectionCatalogue"
	/>

	<div v-else class="p-4">
			<div class="flex items-center gap-3 mb-4">
			<button type="button" class="text-[var(--app-muted-soft)] hover:text-[var(--app-text)]" @click="returnToHome">
				<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<h2 class="text-xl font-bold text-[var(--app-text-strong)]">{{ title }}</h2>
		</div>

		<div v-if="!isShopSection" class="relative mb-3">
			<svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
			</svg>
			<input
				v-model="search"
				type="text"
				placeholder="Поиск..."
				class="w-full pl-9 pr-20 py-2.5 rounded-xl glass-input text-sm"
				@input="onSearch"
			/>
			<div class="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1">
				<button
					type="button"
					class="filter-icon-button"
					:class="filterOpen || dateFrom || dateTo || sortOrder !== 'newest' ? 'is-active' : ''"
					@click="toggleFilters"
				>
					<svg
						v-if="filterOpen"
						class="h-4 w-4"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
					</svg>
					<svg
						v-else
						class="h-4 w-4"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h18M6 12h12m-7 7h2" />
					</svg>
				</button>
				<button v-if="search" type="button" class="filter-icon-button" @click="clearSearch">
					<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
					</svg>
				</button>
			</div>
		</div>

		<div v-if="isShopSection" class="shop-showcase">
			<section
				v-for="block in shopShowcase"
				:key="block.id"
				class="shop-showcase-card"
			>
				<div class="shop-showcase-media">
					<img :src="block.image" :alt="block.text" class="shop-showcase-image" />
				</div>
				<div class="shop-showcase-body">
					<p class="shop-showcase-text">{{ block.text }}</p>
					<a
						:href="block.href"
						target="_blank"
						rel="noopener noreferrer"
						class="shop-showcase-button"
					>
						{{ block.buttonLabel }}
					</a>
				</div>
			</section>

			<section class="shop-showcase-card">
				<div class="shop-showcase-media">
					<img src="/shop/social-links.jpg" alt="Соцсети клуба" class="shop-showcase-image" />
				</div>
				<div class="shop-showcase-body">
					<div class="shop-social-list">
						<a
							v-for="link in shopLinks"
							:key="link.href"
							:href="link.href"
							target="_blank"
							rel="noopener noreferrer"
							class="shop-social-link"
						>
							<span class="shop-social-link__icon-box">
								<img :src="link.icon" :alt="link.label" class="shop-social-link__icon" />
							</span>
							<span class="shop-social-link__text">{{ link.href }}</span>
						</a>
					</div>
				</div>
			</section>
		</div>

		<div v-else>
		<div v-if="filterOpen" class="filter-panel mb-4">
			<div class="filter-panel__header">
				<div>
					<h3 class="filter-panel__title">Фильтр</h3>
				</div>
			</div>

			<div class="filter-grid">
				<label class="filter-field">
					<input v-model="dateFrom" type="date" class="filter-input" />
				</label>
				<label class="filter-field">
					<input v-model="dateTo" type="date" class="filter-input" />
				</label>
			</div>

			<div class="mt-4">
				<div class="filter-segment">
					<button
						type="button"
						class="filter-segment__item"
						:class="sortOrder === 'oldest' ? 'is-selected' : ''"
						@click="sortOrder = 'oldest'"
					>
						Сначала старые
					</button>
					<button
						type="button"
						class="filter-segment__item"
						:class="sortOrder === 'newest' ? 'is-selected' : ''"
						@click="sortOrder = 'newest'"
					>
						Сначала новые
					</button>
				</div>
			</div>

			<div class="filter-actions">
				<button type="button" class="filter-secondary" @click="clearFilters">Сбросить</button>
				<button type="button" class="filter-primary" @click="applyFilters">Применить</button>
			</div>
		</div>

		<div v-if="subsections.length" class="flex gap-2 overflow-x-auto pb-3 mb-3 no-scrollbar">
			<button
				v-for="sub in subsections"
				:key="sub"
				class="flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors"
				:class="activeSubsection === sub ? 'border border-[color-mix(in_srgb,var(--app-accent-slate)_34%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent-slate)_10%,var(--app-surface))] text-[var(--app-text)]' : 'glass text-[var(--app-muted)] hover:text-[var(--app-text)]'"
				@click="setSubsection(sub)"
			>
				{{ sub }}
			</button>
		</div>

		<div v-if="loading" class="py-1">
			<AppScreenSkeleton variant="cards" :count="6" />
		</div>

		<div v-else-if="error" class="glass-card p-5 text-center">
			<p class="text-[var(--app-danger)] text-sm mb-3">{{ error }}</p>
			<button class="px-4 py-2 rounded-xl glass text-[var(--app-text)] text-sm" @click="loadMaterials({ reset: true })">
				Попробовать ещё раз
			</button>
		</div>

		<div v-else-if="materials.length === 0" class="text-center py-12 text-[var(--app-muted-soft)]">
			Пока нет материалов
		</div>

		<div v-else class="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-3xl mx-auto">
			<NuxtLink
				v-for="item in materials"
				:key="item.id"
				:to="{
					path: `/app/content/${item.type}/${item.id}`,
					query: route.query.from ? { from: String(route.query.from) } : {},
				}"
				class="content-material-card flex h-full flex-col overflow-hidden active:scale-[0.98] transition-transform"
				:style="materialCardStyle(item)"
				prefetch-on="interaction"
				@click="rememberListStateForReturn"
				@pointerenter="warmMaterial(item.id)"
				@touchstart.passive="warmMaterial(item.id)"
				@focus="warmMaterial(item.id)"
			>
				<div class="content-material-cover">
					<MaterialFallbackCover :type="item.type" />
				</div>
				<div class="flex min-h-[92px] flex-col p-3">
					<div class="mb-1.5 flex items-center justify-between gap-2">
						<span class="text-[10px] text-[var(--app-muted-soft)]">{{ formatPublishedAt(item.createdAt) }}</span>
						<span v-if="item.durationSeconds" class="text-[10px] text-[var(--app-muted-soft)]">{{ formatDuration(item.durationSeconds) }}</span>
					</div>
					<div v-if="item.accessible === false" class="mb-1.5">
						<span class="rounded-full border border-[color-mix(in_srgb,var(--app-accent)_30%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent)_10%,var(--app-surface))] px-2 py-0.5 text-[10px] text-[var(--app-accent-strong)]">
							Доступно участникам
						</span>
					</div>
					<h3 class="text-[13px] font-medium leading-[1.16] text-[var(--app-text-strong)] whitespace-normal break-normal">
						{{ item.title }}
					</h3>
				</div>
			</NuxtLink>

			<div ref="loadMoreSentinel" class="h-8 flex items-center justify-center col-span-full">
				<div v-if="loadingMore" class="animate-spin w-5 h-5 border-2 border-[var(--app-border)] border-t-[var(--app-accent)] rounded-full" />
				<span v-else-if="!hasMore" class="text-xs text-[var(--app-muted-soft)]">Все материалы загружены</span>
			</div>
		</div>
		</div>
	</div>
</template>

<style scoped>
.no-scrollbar::-webkit-scrollbar { display: none; }
.no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

.content-material-card {
	position: relative;
	border-radius: 1.08rem;
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	border: 1px solid color-mix(in srgb, var(--section-accent) 30%, var(--app-border));
	box-shadow:
		inset 0 1px rgb(255 255 255 / 0.96),
		0 0 18px var(--section-accent-soft),
		var(--app-shadow-soft);
}

.content-material-cover {
	position: relative;
	width: 100%;
	flex-shrink: 0;
	overflow: hidden;
	aspect-ratio: 16 / 9;
	background: var(--app-bg-deep);
}

.content-material-cover-image {
	position: absolute;
	inset: 0;
	display: block;
	width: 100%;
	height: 100%;
	object-fit: cover;
	object-position: center;
}

.shop-showcase {
	display: flex;
	flex-direction: column;
	gap: 1rem;
	max-width: 46rem;
	margin: 0 auto;
}

.shop-showcase-card {
	overflow: hidden;
	border-radius: 1.2rem;
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	border: 1px solid var(--app-border);
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}

.shop-showcase-media {
	aspect-ratio: 16 / 10;
	background: var(--app-bg-deep);
}

.shop-showcase-image {
	width: 100%;
	height: 100%;
	object-fit: cover;
	display: block;
}

.shop-showcase-body {
	padding: 1rem;
}

.shop-showcase-text {
	font-size: 0.98rem;
	line-height: 1.45;
	color: var(--app-text);
}

.shop-showcase-button {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	margin-top: 0.95rem;
	padding: 0.78rem 1.1rem;
	border-radius: 999px;
	border: 1px solid color-mix(in srgb, var(--app-accent-slate) 28%, var(--app-border));
	background: color-mix(in srgb, var(--app-accent-slate) 10%, var(--app-surface));
	color: var(--app-text);
	font-size: 0.9rem;
	font-weight: 600;
	box-shadow: 0 0 16px color-mix(in srgb, var(--app-accent-slate) 12%, transparent);
}

.shop-social-list {
	display: flex;
	flex-direction: column;
	gap: 0.72rem;
}

.shop-social-link {
	display: flex;
	align-items: center;
	gap: 0.72rem;
	padding: 0.78rem 0.85rem;
	border-radius: 0.95rem;
	background: var(--app-bg);
	border: 1px solid var(--app-border);
	color: var(--app-text);
	text-decoration: none;
}

.shop-social-link__icon-box {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	flex: 0 0 auto;
	width: 1.55rem;
	height: 1.55rem;
}

.shop-social-link__icon {
	display: block;
	width: 100%;
	height: 100%;
	object-fit: contain;
}

.shop-social-link__text {
	word-break: break-word;
	line-height: 1.4;
}

.filter-panel {
	border-radius: 1.2rem;
	border: 1px solid var(--app-border);
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
	padding: 1rem;
}

.filter-panel__header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 0.75rem;
}

.filter-panel__eyebrow {
	font-size: 0.68rem;
	letter-spacing: 0.16em;
	text-transform: uppercase;
	color: var(--app-muted-soft);
}

.filter-panel__title {
	margin-top: 0.22rem;
	font-size: 0.98rem;
	font-weight: 600;
	color: var(--app-text-strong);
}

.filter-grid {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 0.75rem;
	margin-top: 1rem;
}

.filter-field {
	display: flex;
	flex-direction: column;
	gap: 0.45rem;
}

.filter-field__label {
	font-size: 0.72rem;
	letter-spacing: 0.08em;
	text-transform: uppercase;
	color: var(--app-muted);
}

.filter-input {
	width: 100%;
	border-radius: 0.95rem;
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	padding: 0.72rem 0.9rem;
	font-size: 0.88rem;
	color: var(--app-text);
	outline: none;
	transition: border-color 0.18s ease, box-shadow 0.18s ease, background 0.18s ease;
}

.filter-input:focus {
	border-color: var(--app-accent);
	box-shadow: 0 0 0 3px color-mix(in srgb, var(--app-accent) 16%, transparent);
	background: var(--app-surface);
}

.filter-segment {
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 0.5rem;
}

.filter-segment__item {
	border-radius: 999px;
	border: 1px solid var(--app-border);
	background: var(--app-bg);
	padding: 0.72rem 0.9rem;
	font-size: 0.83rem;
	font-weight: 500;
	color: var(--app-muted);
	transition: all 0.18s ease;
}

.filter-segment__item.is-selected {
	border-color: color-mix(in srgb, var(--app-accent-slate) 36%, var(--app-border));
	background: color-mix(in srgb, var(--app-accent-slate) 10%, var(--app-surface));
	color: var(--app-text);
	box-shadow: 0 0 12px color-mix(in srgb, var(--app-accent-slate) 12%, transparent);
}

.filter-actions {
	display: flex;
	gap: 0.6rem;
	margin-top: 1rem;
}

.filter-primary,
.filter-secondary,
.filter-icon-button {
	transition: all 0.18s ease;
}

.filter-primary,
.filter-secondary {
	flex: 1;
	border-radius: 999px;
	padding: 0.72rem 1rem;
	font-size: 0.84rem;
	font-weight: 600;
}

.filter-primary {
	border: 1px solid var(--app-border-strong);
	background: var(--app-button-bg);
	color: var(--app-button-fg);
	box-shadow: var(--app-shadow-soft);
}

.filter-secondary {
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	color: var(--app-muted);
}

.filter-icon-button {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	width: 2rem;
	height: 2rem;
	border-radius: 999px;
	border: 1px solid var(--app-border);
	background: var(--app-surface);
	color: var(--app-muted);
}

.filter-icon-button.is-active {
	border-color: color-mix(in srgb, var(--app-accent-slate) 32%, var(--app-border));
	background: color-mix(in srgb, var(--app-accent-slate) 10%, var(--app-surface));
	color: var(--app-text);
	box-shadow: 0 0 12px color-mix(in srgb, var(--app-accent-slate) 12%, transparent);
}

@media (max-width: 640px) {
	.filter-grid,
	.filter-segment {
		grid-template-columns: 1fr;
	}
}
</style>
