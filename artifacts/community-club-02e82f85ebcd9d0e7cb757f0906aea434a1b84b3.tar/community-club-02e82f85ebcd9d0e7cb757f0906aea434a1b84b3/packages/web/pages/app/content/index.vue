<script setup lang="ts">
import { MATERIAL_TYPES } from '@community-club/shared/constants'

definePageMeta({ middleware: ['auth', 'subscription'] })

const auth = useAuthStore()

function hasTypeAccess(type: string) {
	void type
	return true
}

function handleTypeClick(event: MouseEvent, key: string) {
	void event
	void key
}

const availableTypes = computed(() => {
	void auth
	return Object.entries(MATERIAL_TYPES)
})
</script>

<template>
	<div class="club-page">
		<div class="club-section-head">
			<div class="club-section-line" />
			<p class="club-section-kicker">Baza</p>
		</div>
		<h2 class="club-section-title mb-4 text-xl font-bold">Материалы</h2>
		<div class="space-y-2">
			<NuxtLink
				v-for="[key, label] in availableTypes"
				:key="key"
				:to="hasTypeAccess(key) ? `/app/content/${key}` : ''"
				class="club-list-row transition-transform"
				:class="hasTypeAccess(key) ? 'active:scale-[0.98]' : 'cursor-not-allowed'"
				@click="handleTypeClick($event, key)"
			>
				<span class="font-medium text-[var(--app-text-strong)]">{{ label }}</span>
				<svg class="w-5 h-5 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" /></svg>
			</NuxtLink>
		</div>
	</div>
</template>

<style scoped>
.club-access-toast {
	position: fixed;
	z-index: 80;
	display: flex;
	align-items: center;
	gap: 0.55rem;
	max-width: 14.25rem;
	padding: 0.72rem 0.9rem;
	border-radius: 0.95rem;
	border: 1px solid color-mix(in srgb, var(--app-accent-slate) 28%, var(--app-border));
	background: linear-gradient(180deg, var(--app-surface), var(--app-bg));
	box-shadow: var(--app-shadow-floating), 0 0 24px color-mix(in srgb, var(--app-accent-slate) 12%, transparent);
	color: var(--app-text);
	font-size: 0.78rem;
	line-height: 1.3;
	pointer-events: none;
	backdrop-filter: blur(14px);
}

.access-toast-enter-active,
.access-toast-leave-active {
	transition:
		opacity 0.2s ease,
		transform 0.2s ease;
}

.access-toast-enter-from,
.access-toast-leave-to {
	opacity: 0;
	transform: translate3d(0, 8px, 0) scale(0.98);
}
</style>
