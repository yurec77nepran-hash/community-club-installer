<script setup lang="ts">
import type { Payment } from '@community-club/shared/db/schema'
import type {
	LegalDocumentItem,
	LegalDocumentsSettings,
	PaymentCheckoutLinkResponse,
	PaymentCheckoutSettings,
	PaymentTariffOffer,
	PricingContext,
	TestAccessSettings,
} from '@community-club/shared/types'
import SecurePasswordField from '~/components/auth/SecurePasswordField.vue'
import LegalConsent from '~/components/legal/LegalConsent.vue'
import { peekPreviousAppRoute, removeAppHistoryEntry } from '~/composables/useAppBack'
import { resolveTariffFirstAmount } from '~/utils/payment-pricing'

const route = useRoute()
const router = useRouter()
const api = useApi()
const auth = useAuthStore()
const subscriptionStore = useSubscriptionStore()
const { goBack } = useAppBack('/app')
const { subscription } = storeToRefs(subscriptionStore)
const loading = ref(true)
const checkoutLoading = ref(false)
const tariffs = ref<PaymentTariffOffer[]>([])
const legalDocuments = ref<LegalDocumentItem[]>([])
const checkoutSettings = ref<PaymentCheckoutSettings | null>(null)
const manualPaymentEnabled = ref(false)
const selectedTariffSlug = ref<string | null>(null)
const testAccessSettings = ref<TestAccessSettings | null>(null)
const trialSelected = ref(false)
const selectedCardType = ref<'russian' | 'foreign'>('russian')
const paymentPage = ref<'tariffs' | 'details'>('tariffs')
const paymentError = ref('')
const paymentNotice = ref('')
const checkoutUrlFallback = ref('')
const pendingCheckoutAmount = ref<number | null>(null)
const referralCode = ref('')
const checkoutIdentity = reactive({
	email: '',
	fullName: '',
	phone: '',
	password: '',
	confirmPassword: '',
})
const legalConsentAccepted = ref(false)
const useReferralBalance = ref(false)
const checkoutIdentityStorageKey = 'club_checkout_identity_v1'
const isTariffChangeMode = computed(() => route.query.mode === 'change')
const requisitesVisible = computed(() => checkoutSettings.value?.requisitesEnabled !== false)
const pageTitle = computed(() => {
	if (paymentPage.value === 'details') {
		return trialSelected.value ? 'Пробный доступ' : 'Оформление оплаты'
	}
	return isTariffChangeMode.value ? 'Смена тарифа' : 'Подписка'
})
const pageLead = computed(() =>
	paymentPage.value === 'tariffs'
		? 'Выберите срок доступа в клуб.'
		: trialSelected.value
			? 'Активируйте доступ без оплаты.'
			: 'Заполните данные для доступа.',
)
const legalLinks = computed(() =>
	legalDocuments.value
		.filter((document) => document.enabled)
		.map((document) => ({
			label: document.title,
			to: `${legalPath(document.key)}?back=/app/payment`,
		})),
)

type ClaimPaidAccessResponse = {
	expiresAt: number
	redirectTo: string
	requiresPasswordSetup: boolean
}

const checkoutSessionToken = computed(() => {
	const value = route.query.checkoutSession
	return typeof value === 'string' && value.trim() ? value.trim() : ''
})
const isCheckoutReturn = computed(
	() => route.query.checkout === 'success' || route.query.checkout === 'fail',
)
const isCheckoutStepRoute = computed(() => route.query.step === 'checkout')
const isTrialStepRoute = computed(() => route.query.step === 'trial')
const trialAvailable = computed(
	() =>
		testAccessSettings.value?.enabled === true &&
		!auth.isAdmin &&
		!subscriptionStore.hasActiveSubscription,
)

const normalizedCheckoutEmail = computed(() => checkoutIdentity.email.trim().toLowerCase())
const checkoutEmailValid = computed(() => /^\S+@\S+\.\S+$/.test(normalizedCheckoutEmail.value))
const checkoutPasswordValid = computed(
	() => Boolean(auth.user) || checkoutIdentity.password.length >= 6,
)
const checkoutPasswordsMatch = computed(
	() => Boolean(auth.user) || checkoutIdentity.password === checkoutIdentity.confirmPassword,
)

const activeSubscriptionFinish = computed(() => {
	const rawDate = subscription.value?.dateFinish
	if (typeof rawDate !== 'string' || !rawDate) return null

	const parsed = new Date(rawDate)
	if (Number.isNaN(parsed.getTime())) return null

	parsed.setHours(23, 59, 59, 999)
	return parsed
})

const remainingDays = computed(() => {
	const finish = activeSubscriptionFinish.value
	if (!finish) return 0

	const diff = finish.getTime() - Date.now()
	if (diff <= 0) return 0

	return Math.ceil(diff / (24 * 60 * 60 * 1000))
})

const hasPaymentHistory = computed(() =>
	Boolean(
		subscription.value?.tarrif || subscription.value?.dateStart || subscription.value?.dateFinish,
	),
)

const pricingContext = computed<PricingContext>(() => {
	if (!auth.user) return 'active'
	if (remainingDays.value > 0) return 'active'
	if (hasPaymentHistory.value || !auth.user?.firstEntry) return 'former'
	return 'active'
})

async function loadTariffsByRole() {
	const query = `?pricingContext=${pricingContext.value}`
	const tariffRes = await api.get<PaymentTariffOffer[]>(`/api/payments/tariffs${query}`)
	if (tariffRes.success) {
		tariffs.value = tariffRes.data
	}
}

async function loadCheckoutSettings() {
	const settingsRes = await api.get<PaymentCheckoutSettings>('/api/payments/settings')
	if (settingsRes.success) {
		checkoutSettings.value = settingsRes.data
		selectedCardType.value = 'russian'
		manualPaymentEnabled.value = settingsRes.data.manualPaymentEnabled === true
	}
}

async function loadLegalDocuments() {
	const res = await api.get<LegalDocumentsSettings>('/api/site-settings/legal-documents')
	if (res.success) {
		legalDocuments.value = res.data.documents
	}
}

async function loadTestAccessSettings() {
	const res = await api.get<TestAccessSettings>('/api/site-settings/test-access')
	if (res.success) {
		testAccessSettings.value = res.data
	}
}

function legalPath(key: LegalDocumentItem['key']) {
	if (key === 'privacy') return '/app/legal/privacy-policy'
	if (key === 'personalData') return '/app/legal/personal-data'
	if (key === 'oferta') return '/app/legal/oferta'
	if (key === 'requisites') return '/app/legal/requisites'
	return '/app/legal/cookie-policy'
}

async function refreshSubscriptionAfterCheckout() {
	subscriptionStore.invalidate()

	for (let attempt = 0; attempt < 10; attempt += 1) {
		const subRes = await subscriptionStore.fetchSubscription(true)
		if (subRes) {
			subscription.value = subRes as Payment
			await auth.loadUser(true)

			if (import.meta.client) {
				localStorage.removeItem('pending_checkout')
			}

			return true
		}

		await new Promise((resolve) => setTimeout(resolve, 1500))
	}

	return false
}

function restoreCheckoutIdentity() {
	if (auth.user) {
		checkoutIdentity.email = auth.user.email ?? ''
		checkoutIdentity.fullName = auth.user.fullName ?? ''
		checkoutIdentity.phone = auth.user.phone ?? ''
		return
	}

	if (!import.meta.client) return
	const raw = localStorage.getItem(checkoutIdentityStorageKey)
	if (!raw) return

	try {
		const parsed = JSON.parse(raw) as Partial<typeof checkoutIdentity>
		checkoutIdentity.email = String(parsed.email ?? '')
		checkoutIdentity.fullName = String(parsed.fullName ?? '')
		checkoutIdentity.phone = String(parsed.phone ?? '')
		checkoutIdentity.password = ''
		checkoutIdentity.confirmPassword = ''
	} catch {
		localStorage.removeItem(checkoutIdentityStorageKey)
	}
}

function restoreReferralCode() {
	if (!import.meta.client) return
	const queryRef = typeof route.query.ref === 'string' ? route.query.ref.trim() : ''
	const storedRef = localStorage.getItem('referral_code')?.trim() ?? ''
	referralCode.value = queryRef || storedRef
	if (referralCode.value) localStorage.setItem('referral_code', referralCode.value)
}

function rememberCheckoutIdentity() {
	if (!import.meta.client || auth.user) return
	localStorage.setItem(
		checkoutIdentityStorageKey,
		JSON.stringify({
			email: normalizedCheckoutEmail.value,
			fullName: checkoutIdentity.fullName.trim(),
			phone: checkoutIdentity.phone.trim(),
		}),
	)
}

async function claimAccessAfterCheckout(token: string) {
	for (let attempt = 0; attempt < 10; attempt += 1) {
		const res = await api.post<ClaimPaidAccessResponse>('/api/auth/checkout/claim-access', {
			checkoutSession: token,
		})

		if (res.success) {
			auth.setTokens('', '')
			await auth.loadUser(true)
			await refreshSubscriptionAfterCheckout()
			if (import.meta.client) {
				localStorage.removeItem('pending_checkout')
			}
			return res.data.requiresPasswordSetup ? 'setup-password' : 'active'
		}

		if (res.error.code !== 'PAYMENT_PENDING') {
			paymentError.value = res.error.message
			return null
		}

		await new Promise((resolve) => setTimeout(resolve, 1500))
	}

	paymentError.value = 'Платёж получен. Доступ скоро обновится.'
	return null
}

onMounted(async () => {
	await auth.restoreSession()
	restoreCheckoutIdentity()
	restoreReferralCode()

	const queryTariff = route.query.tariff
	if (
		(isCheckoutReturn.value || isCheckoutStepRoute.value) &&
		typeof queryTariff === 'string' &&
		queryTariff
	) {
		selectedTariffSlug.value = queryTariff
	}

	if (import.meta.client) {
		const pendingCheckoutRaw = localStorage.getItem('pending_checkout')
		if (pendingCheckoutRaw) {
			try {
				const pendingCheckout = JSON.parse(pendingCheckoutRaw) as {
					tariff?: string
					cardType?: 'russian' | 'foreign'
					amount?: string | number
					email?: string
				}
				if (isCheckoutReturn.value && !selectedTariffSlug.value) {
					selectedTariffSlug.value = pendingCheckout.tariff ?? null
				}
				if (isCheckoutReturn.value) {
					selectedCardType.value = 'russian'
				}
				const amount = Number(pendingCheckout.amount ?? 0)
				pendingCheckoutAmount.value =
					isCheckoutReturn.value && Number.isFinite(amount) && amount > 0 ? amount : null
				if (!checkoutIdentity.email && pendingCheckout.email) {
					checkoutIdentity.email = pendingCheckout.email
				}
			} catch {
				// ignore malformed local state
			}
		}
	}

	await Promise.all([loadCheckoutSettings(), loadLegalDocuments(), loadTestAccessSettings()])
	if (auth.user) {
		const subRes = await subscriptionStore.fetchSubscription()
		if (subRes) subscription.value = subRes as Payment
	}
	await loadTariffsByRole()
	if (isTrialStepRoute.value) {
		if (trialAvailable.value) {
			trialSelected.value = true
			paymentPage.value = 'details'
		} else {
			trialSelected.value = false
			paymentPage.value = 'tariffs'
			await navigateTo({ path: route.path, query: cleanPaymentQuery() }, { replace: true })
		}
	}
	if (!selectedTariffSlug.value) {
		selectedTariffSlug.value =
			visibleTariffs.value.find((tariff) => tariff.durationDays === 90)?.slug?.toString() ??
			visibleTariffs.value[0]?.slug?.toString() ??
			null
	}
	if (
		(isCheckoutReturn.value || isCheckoutStepRoute.value) &&
		selectedTariffSlug.value &&
		visibleTariffs.value.some((tariff) => String(tariff.slug) === selectedTariffSlug.value)
	) {
		// Ручная оплата: даже при переходе с шагом checkout — сразу заглушка
		if (manualPaymentEnabled.value) {
			await navigateTo('/app/payment-off', { replace: true })
			return
		}
		paymentPage.value = 'details'
	}

	if (route.query.checkout === 'success') {
		paymentNotice.value = 'Платёж получен. Открываем доступ...'
		const activated = checkoutSessionToken.value
			? await claimAccessAfterCheckout(checkoutSessionToken.value)
			: auth.user
				? (await refreshSubscriptionAfterCheckout())
					? 'active'
					: null
				: null
		if (activated === 'setup-password') {
			paymentNotice.value = 'Доступ открыт'
			await navigateTo('/app/profile?setupPassword=1')
			return
		}
		if (activated === 'active') {
			paymentNotice.value = 'Доступ открыт'
		} else {
			paymentNotice.value = paymentError.value ? '' : 'Платёж получен. Доступ скоро обновится.'
		}
	}

	if (route.query.checkout === 'fail') {
		paymentError.value = 'Платёж не был завершён. Попробуйте ещё раз.'
	}

	loading.value = false
})

async function cancelSubscription() {
	if (
		!confirm(
			'Вы точно уверены, что хотите отменить автоподписку?\n\nВ данном случае по истечении срока вашего нахождения в клубе нужно будет вручную продлить подписку.',
		)
	) {
		return
	}
	await api.post('/api/payments/subscription/cancel')
	subscriptionStore.invalidate()
	await subscriptionStore.fetchSubscription(true)
}

const visibleTariffs = computed(() =>
	tariffs.value.filter((tariff) => {
		return tariff.pricingContext === pricingContext.value
	}),
)

const selectedTariff = computed(
	() =>
		visibleTariffs.value.find((tariff) => String(tariff.slug) === selectedTariffSlug.value) ?? null,
)

function cleanPaymentQuery() {
	const hiddenKeys = new Set(['checkout', 'checkoutSession', 'tariff', 'step'])
	return Object.fromEntries(Object.entries(route.query).filter(([key]) => !hiddenKeys.has(key)))
}

function openCheckoutPageInAddressBar(tariffSlug: string) {
	if (!import.meta.client) return
	void navigateTo({
		path: route.path,
		query: {
			...cleanPaymentQuery(),
			step: 'checkout',
			tariff: tariffSlug,
		},
	})
}

function openTariffsPageInAddressBar() {
	if (!import.meta.client || (!route.query.tariff && !route.query.step)) return
	void navigateTo(
		{
			path: route.path,
			query: cleanPaymentQuery(),
		},
		{ replace: true },
	)
}

function isPaymentTariffsRoute(fullPath: string) {
	const [path, query = ''] = fullPath.split('?')
	if (path !== route.path) return false

	const params = new URLSearchParams(query)
	return (
		!params.has('step') &&
		!params.has('tariff') &&
		!params.has('checkout') &&
		!params.has('checkoutSession')
	)
}

function selectTariff(tariff: PaymentTariffOffer) {
	const nextSlug = String(tariff.slug)
	if (selectedTariffSlug.value !== nextSlug) {
		pendingCheckoutAmount.value = null
	}
	selectedTariffSlug.value = nextSlug
	trialSelected.value = false
	paymentError.value = ''
	paymentNotice.value = ''
	checkoutUrlFallback.value = ''
}

function selectTrial() {
	if (!trialAvailable.value) return
	trialSelected.value = true
	paymentError.value = ''
	paymentNotice.value = ''
	checkoutUrlFallback.value = ''
}

function continueToCheckout() {
	if (trialSelected.value && trialAvailable.value) {
		paymentPage.value = 'details'
		void navigateTo({
			path: route.path,
			query: { ...cleanPaymentQuery(), step: 'trial' },
		})
		if (import.meta.client) {
			window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: 'smooth' }))
		}
		return
	}

	if (!selectedTariff.value) {
		paymentError.value = 'Выберите тариф'
		return
	}

	// Ручная оплата: после выбора тарифа — заглушка, без формы
	if (manualPaymentEnabled.value) {
		void navigateTo('/app/payment-off', { replace: true })
		return
	}

	paymentPage.value = 'details'
	openCheckoutPageInAddressBar(String(selectedTariff.value.slug))

	if (import.meta.client) {
		window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: 'smooth' }))
	}
}

function goToTariffPage() {
	paymentError.value = ''
	paymentNotice.value = ''
	checkoutUrlFallback.value = ''
	paymentPage.value = 'tariffs'

	if (import.meta.client) {
		const previous = peekPreviousAppRoute(route.fullPath)
		removeAppHistoryEntry(route.fullPath)

		if (previous && isPaymentTariffsRoute(previous.fullPath)) {
			router.back()
			return
		}
	}

	openTariffsPageInAddressBar()
}

function handleBack() {
	if (paymentPage.value === 'details') {
		goToTariffPage()
		return
	}
	goBack('/app')
}

async function paySelectedTariff() {
	if (!selectedTariff.value) {
		paymentError.value = 'Выберите тариф'
		paymentPage.value = 'tariffs'
		return
	}
	await payForTariff(selectedTariff.value)
}

watch(
	() => [route.query.tariff, route.query.step, route.query.checkout, trialAvailable.value],
	() => {
		if (isTrialStepRoute.value) {
			if (trialAvailable.value) {
				trialSelected.value = true
				paymentPage.value = 'details'
			} else {
				trialSelected.value = false
				paymentPage.value = 'tariffs'
				openTariffsPageInAddressBar()
			}
			return
		}

		const value = route.query.tariff
		const tariffSlug = typeof value === 'string' && value ? value : null
		if (tariffSlug && (isCheckoutReturn.value || isCheckoutStepRoute.value)) {
			selectedTariffSlug.value = tariffSlug
			trialSelected.value = false
			paymentPage.value = 'details'
			return
		}

		if (!loading.value) {
			paymentPage.value = 'tariffs'
		}
	},
)

function getFirstPaymentAmount(tariff: PaymentTariffOffer) {
	if (
		selectedTariffSlug.value === String(tariff.slug) &&
		pendingCheckoutAmount.value != null &&
		pendingCheckoutAmount.value > 0
	) {
		return pendingCheckoutAmount.value
	}

	return resolveTariffFirstAmount({
		tariff,
		cardType: selectedCardType.value,
		hasDiscount: false,
		showPriceFirst: pricingContext.value === 'external',
		pendingAmount:
			selectedTariffSlug.value === String(tariff.slug) ? pendingCheckoutAmount.value : null,
	})
}

function getRegularPaymentAmount(tariff: PaymentTariffOffer) {
	const price = Number(tariff.price ?? 0)
	return Number.isFinite(price) ? price : 0
}

function formatSubscriptionDate(value: string | null | undefined) {
	if (!value) return '—'
	const parsed = new Date(value)
	if (Number.isNaN(parsed.getTime())) return value
	return parsed.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })
}

function formatPrice(value: string | number) {
	const amount = Number(value)
	return Number.isFinite(amount) ? amount.toLocaleString('ru-RU') : String(value)
}

async function payForTariff(tariff: PaymentTariffOffer) {
	if (checkoutLoading.value) return
	selectedTariffSlug.value = String(tariff.slug)
	selectedCardType.value = 'russian'

	const firstAmount = getFirstPaymentAmount(tariff)
	const regularAmount = getRegularPaymentAmount(tariff)
	const durationDays = Number(tariff.durationDays ?? 0)
	if (!firstAmount || !regularAmount || !durationDays) {
		paymentError.value = 'Не удалось определить сумму тарифа'
		return
	}

	paymentError.value = ''
	paymentNotice.value = ''
	checkoutUrlFallback.value = ''
	checkoutLoading.value = true

	if (!checkoutEmailValid.value) {
		paymentError.value = 'Введите email для доступа'
		checkoutLoading.value = false
		return
	}
	if (!checkoutPasswordValid.value || !checkoutPasswordsMatch.value) {
		paymentError.value = !checkoutPasswordsMatch.value
			? 'Пароли не совпадают'
			: 'Пароль должен быть не короче 6 символов'
		checkoutLoading.value = false
		return
	}

	if (!legalConsentAccepted.value) {
		paymentError.value = 'Подтвердите согласие с документами'
		checkoutLoading.value = false
		return
	}

	rememberCheckoutIdentity()
	if (import.meta.client) {
		localStorage.setItem(
			'pending_checkout',
			JSON.stringify({
				tariff: String(tariff.slug),
				cardType: selectedCardType.value,
				amount: firstAmount,
				email: normalizedCheckoutEmail.value,
			}),
		)
	}

	const res = await api.post<PaymentCheckoutLinkResponse>('/api/payments/checkout-link', {
		tariffSlug: String(tariff.slug),
		cardType: selectedCardType.value,
		email: normalizedCheckoutEmail.value,
		fullName:
			checkoutIdentity.fullName.trim().length >= 2 ? checkoutIdentity.fullName.trim() : undefined,
		phone: checkoutIdentity.phone.trim().length >= 7 ? checkoutIdentity.phone.trim() : undefined,
		password: auth.user ? undefined : checkoutIdentity.password,
		referralCode: referralCode.value || undefined,
		useReferralBalance: useReferralBalance.value,
	})

	checkoutLoading.value = false

	if (!res.success) {
		paymentError.value =
			res.error.code === 'CONFIG_ERROR' ? 'Оплата пока недоступна.' : res.error.message
		return
	}

	if (import.meta.client) {
		const nextUrl = String(res.data.checkoutUrl ?? '').trim()
		if (!nextUrl) {
			paymentError.value = 'Не удалось получить ссылку на оплату'
			return
		}

		checkoutUrlFallback.value = nextUrl
		paymentNotice.value = 'Открываем страницу оплаты...'

		try {
			await navigateTo(nextUrl, { external: true })
			return
		} catch {
			// fallback below
		}

		try {
			window.location.assign(nextUrl)
		} catch {
			paymentNotice.value = ''
			paymentError.value =
				'Не удалось автоматически открыть страницу оплаты. Откройте её по кнопке ниже.'
		}

		window.setTimeout(() => {
			if (document.visibilityState === 'visible') {
				paymentNotice.value = ''
				paymentError.value =
					'Не удалось автоматически открыть страницу оплаты. Откройте её по кнопке ниже.'
			}
		}, 1200)
	}
}
</script>

<template>
	<div class="club-page payment-page mx-auto max-w-3xl">
		<header class="payment-header" :class="{ 'is-tariffs': paymentPage === 'tariffs' }">
			<button type="button" class="payment-back-button" aria-label="Назад" @click="handleBack">
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
				</svg>
			</button>
			<div v-if="paymentPage === 'details'" class="payment-heading min-w-0">
				<img
					:src="'/pwa-icon?size=512&format=webp'"
					alt=""
					width="512"
					height="512"
					loading="eager"
					fetchpriority="high"
					decoding="async"
					class="payment-heading-mark"
				/>
				<div>
					<p class="payment-eyebrow">Club App · клубный доступ</p>
					<h1>{{ pageTitle }}</h1>
					<p>{{ pageLead }}</p>
				</div>
			</div>
		</header>

		<div v-if="loading" class="payment-loader">
			<div class="animate-spin h-8 w-8 rounded-full border-4 border-[color-mix(in_srgb,var(--app-accent)_20%,transparent)] border-t-[var(--app-accent)]" />
		</div>

		<template v-else>
			<section v-if="subscription && paymentPage === 'details'" class="club-card payment-card">
				<div class="club-section-head mb-3">
					<span class="club-section-line" />
					<h2 class="payment-section-title">Текущий доступ</h2>
				</div>
				<div class="payment-info-grid">
					<div class="payment-info-row">
						<span>Тариф</span>
						<strong>{{ subscription.tarrif ?? '—' }}</strong>
					</div>
					<div class="payment-info-row">
						<span>Активен до</span>
						<strong>{{ formatSubscriptionDate(subscription.dateFinish) }}</strong>
					</div>
					<div class="payment-info-row">
						<span>Автосписание</span>
						<strong :class="subscription.autoPayment ? 'text-[var(--app-success)]' : 'text-[var(--app-danger)]'">
							{{ subscription.autoPayment ? 'Включено' : 'Отключено' }}
						</strong>
					</div>
				</div>
				<button
					v-if="subscription.autoPayment"
					type="button"
					class="payment-danger-button"
					@click="cancelSubscription"
				>
					Отменить автоподписку
				</button>
			</section>

			<template v-if="paymentPage === 'tariffs'">
				<section v-if="isTariffChangeMode && remainingDays > 0" class="payment-renewal-note">
					<p class="text-sm font-semibold text-[var(--app-success)]">Осталось {{ remainingDays }} дн.</p>
					<p class="mt-1 text-sm leading-6 text-[var(--app-muted)]">
						Неиспользованные дни будут добавлены к новой подписке.
					</p>
				</section>

				<PaymentTariffSelection
					:tariffs="visibleTariffs"
					:selected-slug="selectedTariffSlug"
					:trial-days="trialAvailable ? (testAccessSettings?.days ?? null) : null"
					:trial-selected="trialSelected"
					:price-for="getFirstPaymentAmount"
					:format-price="formatPrice"
					@select="selectTariff"
					@select-trial="selectTrial"
					@continue="continueToCheckout"
				/>
			</template>

			<template v-else>
				<PaymentTrialActivation
					v-if="trialSelected && trialAvailable && testAccessSettings"
					v-model:email="checkoutIdentity.email"
					v-model:password="checkoutIdentity.password"
					v-model:confirm-password="checkoutIdentity.confirmPassword"
					v-model:consent-accepted="legalConsentAccepted"
					:days="testAccessSettings.days"
					:authenticated="Boolean(auth.user)"
					:account-email="auth.user?.email ?? checkoutIdentity.email"
					@back="goToTariffPage"
				/>

				<section v-else-if="selectedTariff" class="payment-checkout-panel">
					<div class="payment-checkout-summary">
						<div class="min-w-0">
							<p class="payment-summary-label">Тариф</p>
							<h2 class="payment-summary-title">{{ selectedTariff.name }}</h2>
							<p class="payment-summary-meta">{{ selectedTariff.durationDays }} дн.</p>
						</div>
						<div class="payment-summary-side">
							<div class="payment-price-box">
								<p class="payment-price">{{ formatPrice(getFirstPaymentAmount(selectedTariff)) }} ₽</p>
								<p
									v-if="Number(getFirstPaymentAmount(selectedTariff)) < Number(selectedTariff.price ?? 0)"
									class="text-xs text-[var(--app-muted-soft)] line-through"
								>
									{{ formatPrice(selectedTariff.price) }} ₽
								</p>
							</div>
							<button type="button" class="payment-change-button is-compact" @click="goToTariffPage">
								Изменить
							</button>
						</div>
					</div>

					<div class="payment-checkout-block">
						<div class="club-section-head mb-3">
							<span class="club-section-line" />
							<h2 class="payment-section-title">Данные для доступа</h2>
						</div>
						<div class="payment-form-grid">
							<label class="payment-field">
								<span>Email</span>
								<input
									v-model="checkoutIdentity.email"
									type="email"
									autocomplete="email"
									placeholder="name@example.com"
									:disabled="Boolean(auth.user)"
									required
								/>
							</label>
							<label class="payment-field">
								<span>Имя</span>
								<input
									v-model="checkoutIdentity.fullName"
									type="text"
									autocomplete="name"
									placeholder="Ваше имя"
								/>
							</label>
							<label class="payment-field">
								<span>Телефон</span>
								<input
									v-model="checkoutIdentity.phone"
									type="tel"
									autocomplete="tel"
									placeholder="+7"
								/>
							</label>
							<template v-if="!auth.user">
								<label class="payment-field">
									<span>Пароль для входа</span>
									<SecurePasswordField
										v-model="checkoutIdentity.password"
										placeholder="Не менее 6 символов"
										autocomplete="new-password"
										:minlength="6"
										:invalid="!checkoutPasswordValid || !checkoutPasswordsMatch"
									/>
								</label>
								<label class="payment-field">
									<span>Повторите пароль</span>
									<SecurePasswordField
										v-model="checkoutIdentity.confirmPassword"
										placeholder="Повторите пароль"
										autocomplete="new-password"
										:minlength="6"
										:invalid="!checkoutPasswordsMatch"
									/>
								</label>
								<p class="payment-password-note">Этот пароль будет использоваться для входа в клуб.</p>
							</template>
						</div>
					</div>

<div class="payment-checkout-block">
	<label class="flex items-start gap-3 text-sm text-[var(--app-muted)]">
		<input
			type="checkbox"
			class="mt-0.5 h-4 w-4 accent-[var(--app-accent)] shrink-0"
			v-model="useReferralBalance"
		/>
		<span>При последующих списаниях учитывать партнёрские отчисления</span>
	</label>
</div>
<div class="payment-checkout-block">
	<LegalConsent v-model="legalConsentAccepted" scope="payment" />
</div>

					<button
						type="button"
						class="payment-pay-button"
						:disabled="checkoutLoading || !selectedTariff || !legalConsentAccepted"
						@click="paySelectedTariff"
					>
						<span>{{ checkoutLoading ? 'Открываем оплату...' : 'Оплатить' }}</span>
						<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14m-5-5 5 5-5 5" />
						</svg>
					</button>
				</section>

				<section v-else class="payment-empty-card">
					<p>Выберите тариф, чтобы продолжить.</p>
					<button type="button" class="payment-change-button" @click="goToTariffPage">
						К тарифам
					</button>
				</section>
			</template>

			<p v-if="paymentError" class="payment-message is-error">
				{{ paymentError }}
			</p>

			<p v-if="paymentNotice" class="payment-message is-success">
				{{ paymentNotice }}
			</p>

			<a
				v-if="checkoutUrlFallback"
				:href="checkoutUrlFallback"
				target="_self"
				rel="noopener noreferrer"
				class="payment-fallback-link"
			>
				Перейти к оплате
			</a>

			<footer v-if="paymentPage === 'details' && ((!trialSelected && requisitesVisible) || legalLinks.length)" class="payment-legal-card">
				<p v-if="!trialSelected && requisitesVisible && checkoutSettings?.requisitesName" class="text-sm font-semibold text-[var(--app-text-strong)]">
					{{ checkoutSettings.requisitesName }}
				</p>
				<p
					v-if="!trialSelected && requisitesVisible && (checkoutSettings?.requisitesTaxId || checkoutSettings?.requisitesRegistrationId)"
					class="mt-2 text-sm text-[var(--app-muted)]"
				>
					{{ [checkoutSettings?.requisitesRegistrationId, checkoutSettings?.requisitesTaxId].filter(Boolean).join(' ') }}
				</p>
				<p v-if="!trialSelected && requisitesVisible && checkoutSettings?.requisitesAddress" class="mt-2 text-sm text-[var(--app-muted)]">
					{{ checkoutSettings.requisitesAddress }}
				</p>

				<div class="mt-5 space-y-2">
					<NuxtLink
						v-for="link in legalLinks"
						:key="link.to"
						:to="link.to"
						class="payment-legal-link"
					>
						{{ link.label }}
					</NuxtLink>
				</div>
			</footer>
		</template>
	</div>
</template>

<style scoped>
.payment-page {
	box-sizing: border-box;
	width: 100%;
	max-width: 46rem;
	padding-bottom: 2rem;
	overflow-x: hidden;
}

.payment-page *,
.payment-page *::before,
.payment-page *::after {
	box-sizing: border-box;
}

.payment-header {
	display: grid;
	grid-template-columns: 1fr;
	gap: 0.75rem;
	align-items: start;
	margin: 0.2rem 0 1.25rem;
}

.payment-back-button {
	display: inline-flex;
	width: 2.55rem;
	height: 2.55rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border-strong);
	border-radius: 50%;
	background: var(--app-surface);
	color: var(--app-muted);
	box-shadow: var(--app-shadow-soft);
}

.payment-loader {
	display: flex;
	justify-content: center;
	padding: 3rem 0;
}

.payment-card {
	margin-bottom: 1rem;
	padding: 1rem;
}

.payment-form-grid {
	display: grid;
	gap: 0.75rem;
}

.payment-field {
	display: grid;
	gap: 0.38rem;
}

.payment-field span {
	color: var(--app-muted);
	font-size: 0.74rem;
	font-weight: 650;
	letter-spacing: 0.08em;
	text-transform: uppercase;
}

.payment-field input {
	width: 100%;
	border: 1px solid var(--app-border);
	border-radius: 1rem;
	background: var(--app-surface);
	padding: 0.82rem 0.9rem;
	color: var(--app-text);
	font-size: 0.92rem;
	outline: none;
	transition:
		border-color 0.18s ease,
		background 0.18s ease,
		box-shadow 0.18s ease;
}

.payment-field input:focus {
	border-color: var(--app-accent);
	background: color-mix(in srgb, var(--app-accent) 7%, var(--app-surface));
	box-shadow: 0 0 0 3px color-mix(in srgb, var(--app-accent) 12%, transparent);
}

.payment-field input:disabled {
	cursor: not-allowed;
	opacity: 0.7;
	background: var(--app-bg-deep);
	color: var(--app-muted);
}

.payment-section-title {
	color: var(--app-accent-strong);
	font-family: inherit;
	font-size: 0.82rem;
	font-weight: 700;
	letter-spacing: 0.16em;
	text-transform: uppercase;
	text-shadow: none;
}

.payment-method-button {
	min-height: 3rem;
	border: 1px solid var(--app-border);
	border-radius: 1rem;
	background: var(--app-surface);
	color: var(--app-muted);
	font-size: 0.86rem;
	font-weight: 650;
	transition: transform 0.18s ease, border-color 0.18s ease, color 0.18s ease, background 0.18s ease;
}

.payment-method-button.is-active {
	border-color: var(--app-accent);
	background: color-mix(in srgb, var(--app-accent) 7%, var(--app-surface));
	color: var(--app-text-strong);
	box-shadow: 0 0 0 3px color-mix(in srgb, var(--app-accent) 12%, transparent);
}

.payment-method-button:active,
.payment-select-button:active,
.payment-pay-button:active,
.payment-change-button:active,
.payment-back-button:active {
	transform: scale(0.98);
}

.payment-info-grid {
	display: grid;
	gap: 0.65rem;
}

.payment-info-row {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 1rem;
	border: 1px solid var(--app-border);
	border-radius: 0.95rem;
	background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface));
	padding: 0.78rem 0.85rem;
	font-size: 0.86rem;
}

.payment-info-row span {
	color: var(--app-muted);
}

.payment-info-row strong {
	color: var(--app-text-strong);
	font-weight: 700;
	text-align: right;
}

.payment-danger-button {
	width: 100%;
	margin-top: 1rem;
	border: 1px solid color-mix(in srgb, var(--app-danger) 28%, var(--app-border));
	border-radius: 1rem;
	background: color-mix(in srgb, var(--app-danger) 7%, var(--app-surface));
	padding: 0.72rem 1rem;
	color: var(--app-danger);
	font-size: 0.86rem;
	font-weight: 650;
}

.payment-renewal-note {
	margin-bottom: 1rem;
	border: 1px solid color-mix(in srgb, var(--app-success) 28%, var(--app-border));
	border-radius: 1.25rem;
	background: color-mix(in srgb, var(--app-success) 7%, var(--app-surface));
	padding: 1rem;
}

.payment-tariffs-section {
	margin-top: 1.25rem;
}

.payment-tariff-card {
	position: relative;
	overflow: hidden;
	width: 100%;
	border: 1px solid var(--app-border);
	border-radius: 1.35rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 34%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	padding: 1rem;
	box-shadow:
		inset 0 1px rgb(255 255 255 / 0.96),
		var(--app-shadow-soft);
}

.payment-tariff-card.is-active {
	border-color: var(--app-accent);
	box-shadow:
		inset 0 0 0 1px color-mix(in srgb, var(--app-accent) 22%, transparent),
		var(--app-shadow-raised);
}

.payment-tariff-main {
	display: grid;
	grid-template-columns: minmax(0, 1fr) auto;
	gap: 1rem;
	align-items: start;
}

.payment-tariff-name {
	margin-top: 0.18rem;
	color: var(--app-text-strong);
	font-size: 1.18rem;
	font-weight: 700;
	letter-spacing: 0.01em;
}

.payment-price-box {
	min-width: 5.8rem;
	text-align: right;
}

.payment-price {
	color: var(--app-text-strong);
	font-size: 1.32rem;
	font-weight: 750;
	letter-spacing: -0.02em;
	text-shadow: none;
}

.payment-checkout-panel {
	display: grid;
	gap: 0.9rem;
	margin-top: 0.25rem;
	border: 1px solid var(--app-border);
	border-radius: 1.45rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 34%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	padding: 1rem;
	box-shadow:
		inset 0 1px rgb(255 255 255 / 0.96),
		var(--app-shadow-soft);
}

.payment-checkout-summary {
	display: grid;
	grid-template-columns: minmax(0, 1fr) auto;
	gap: 1rem;
	align-items: center;
	border: 1px solid var(--app-border);
	border-radius: 1.15rem;
	background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface));
	padding: 0.9rem;
}

.payment-summary-label {
	color: var(--app-muted);
	font-size: 0.68rem;
	font-weight: 750;
	letter-spacing: 0.14em;
	text-transform: uppercase;
}

.payment-summary-title {
	margin-top: 0.2rem;
	color: var(--app-text-strong);
	font-size: 1rem;
	font-weight: 800;
	letter-spacing: 0.01em;
}

.payment-summary-meta {
	margin-top: 0.18rem;
	color: var(--app-muted);
	font-size: 0.78rem;
	font-weight: 650;
}

.payment-summary-side {
	display: grid;
	gap: 0.5rem;
	justify-items: end;
}

.payment-checkout-block {
	border: 1px solid var(--app-border);
	border-radius: 1.15rem;
	background: color-mix(in srgb, var(--app-accent) 5%, var(--app-surface));
	padding: 0.9rem;
}

.payment-password-note {
	grid-column: 1 / -1;
	margin-top: -0.2rem;
	color: var(--app-muted);
	font-size: 0.76rem;
	line-height: 1.45;
}

.payment-select-button,
.payment-pay-button {
	display: flex;
	width: 100%;
	max-width: 100%;
	align-items: center;
	justify-content: center;
	gap: 0.45rem;
	margin-top: 1rem;
	border: 1px solid var(--app-border-strong);
	border-radius: 1rem;
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent));
	padding: 0.86rem 1rem;
	color: var(--app-button-fg);
	font-size: 0.9rem;
	font-weight: 750;
	box-shadow: var(--app-shadow-raised);
	transition: transform 0.18s ease, opacity 0.18s ease;
}

.payment-pay-button:disabled {
	cursor: not-allowed;
	opacity: 0.62;
}

.payment-checkout-panel .payment-pay-button {
	margin-top: 0;
}

.payment-change-button {
	width: 100%;
	margin-top: 0.75rem;
	border: 1px solid var(--app-border-strong);
	border-radius: 1rem;
	background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface));
	padding: 0.76rem 1rem;
	color: var(--app-accent-strong);
	font-size: 0.86rem;
	font-weight: 700;
}

.payment-change-button.is-compact {
	margin-top: 0;
	border-radius: 999px;
	padding: 0.46rem 0.7rem;
	font-size: 0.74rem;
}

.payment-empty-card {
	margin-bottom: 1rem;
	border: 1px solid var(--app-border);
	border-radius: 1.25rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 34%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	padding: 1rem;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
	color: var(--app-muted);
	font-size: 0.9rem;
	text-align: center;
}

.payment-message {
	margin-top: 1rem;
	border-radius: 1rem;
	padding: 0.85rem 1rem;
	font-size: 0.86rem;
}

.payment-message.is-error {
	border: 1px solid color-mix(in srgb, var(--app-danger) 28%, var(--app-border));
	background: color-mix(in srgb, var(--app-danger) 7%, var(--app-surface));
	color: var(--app-danger);
}

.payment-message.is-success {
	border: 1px solid color-mix(in srgb, var(--app-success) 28%, var(--app-border));
	background: color-mix(in srgb, var(--app-success) 7%, var(--app-surface));
	color: var(--app-success);
}

.payment-fallback-link {
	display: flex;
	width: 100%;
	align-items: center;
	justify-content: center;
	margin-top: 1rem;
	border: 1px solid var(--app-border-strong);
	border-radius: 1rem;
	background: color-mix(in srgb, var(--app-accent) 6%, var(--app-surface));
	padding: 0.85rem 1rem;
	color: var(--app-accent-strong);
	font-size: 0.9rem;
	font-weight: 750;
}

.payment-legal-card {
	margin-top: 2rem;
	border: 1px solid var(--app-border);
	border-radius: 1.35rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 34%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	padding: 1.15rem;
	text-align: center;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}

.payment-legal-link {
	display: block;
	color: var(--app-accent-strong);
	font-size: 0.86rem;
	font-weight: 650;
	transition: color 0.18s ease;
}

.payment-legal-link:hover {
	color: var(--app-text-strong);
}

@media (max-width: 560px) {
	.payment-tariff-main {
		grid-template-columns: 1fr;
		gap: 0.7rem;
	}

	.payment-checkout-summary {
		grid-template-columns: 1fr;
	}

	.payment-summary-side {
		grid-template-columns: 1fr auto;
		align-items: center;
		justify-items: stretch;
	}

	.payment-price-box {
		text-align: left;
	}
}

.payment-heading {
	position: relative;
	display: grid;
	grid-template-columns: auto minmax(0, 1fr);
	gap: 0.75rem;
	align-items: center;
	flex: 1;
	min-height: 5.8rem;
	padding: 0.9rem;
	overflow: hidden;
	border: 1px solid var(--app-border);
	border-radius: 1.3rem;
	background: radial-gradient(circle at 100% 0%, color-mix(in srgb, var(--app-accent) 9%, transparent), transparent 34%), linear-gradient(155deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft);
}

.payment-heading-mark {
	width: 3.6rem;
	height: 3.6rem;
	object-fit: contain;
	filter: drop-shadow(0 0 12px rgba(236, 181, 46, 0.34));
}

.payment-eyebrow,
.payment-tariff-kicker,
.payment-duration {
	color: var(--app-accent-strong);
	font-size: 0.62rem;
	font-weight: 700;
	letter-spacing: 0.13em;
	text-transform: uppercase;
}

.payment-heading h1 {
	margin-top: 0.18rem;
	color: var(--app-text-strong);
	font-size: 1.26rem;
	font-weight: 700;
	line-height: 1.1;
}

.payment-heading > div > p:last-child {
	margin-top: 0.3rem;
	color: var(--app-muted);
	font-size: 0.78rem;
	line-height: 1.4;
}

.payment-tariff-kicker {
	font-size: 0.56rem;
}

.payment-tariff-note {
	margin-top: 0.3rem;
	color: var(--app-muted);
	font-size: 0.76rem;
	line-height: 1.4;
}

.payment-duration {
	margin-top: 0.18rem;
	font-size: 0.56rem;
	letter-spacing: 0.06em;
}

@media (prefers-reduced-motion: no-preference) {
	.payment-heading,
	.payment-tariff-card { animation: payment-reveal 0.32s ease-out both; }
}

@keyframes payment-reveal {
	from { opacity: 0; transform: translateY(8px); }
	to { opacity: 1; transform: translateY(0); }
}

</style>
