<script setup lang="ts">
import type { PaymentCheckoutSettings } from '@community-club/shared/types'

const loading = ref(true)
const settings = ref<PaymentCheckoutSettings | null>(null)
const api = useApi()

onMounted(async () => {
	const res = await api.get<PaymentCheckoutSettings>('/api/payments/settings', {
		authRedirect: false,
	})
	if (res.success) settings.value = res.data
	else loading.value = false
})
</script>

<template>
	<div class="payment-off">
		<div class="payment-off-card">
			<h1 class="payment-off-title">Платёжная система временно не работает</h1>
			<p class="payment-off-text">
				Для оплаты напишите мне — Олегу Горскому — в личные сообщения Telegram.
			</p>
			<a
				href="https://t.me/oleggorskyj"
				target="_blank"
				rel="noopener noreferrer"
				class="payment-off-button"
			>
				Перейти в Telegram
			</a>
		</div>
	</div>
</template>

<style scoped>
.payment-off {
	display: flex;
	min-height: 80svh;
	align-items: center;
	justify-content: center;
	padding: 1.5rem;
	background: var(--app-bg);
}
.payment-off-card {
	width: min(100%, 26rem);
	border: 1px solid var(--app-border-strong);
	border-radius: 1.5rem;
	background: radial-gradient(circle at 90% 0, color-mix(in srgb, var(--app-accent) 12%, transparent), transparent 34%), linear-gradient(145deg, var(--app-surface), var(--app-bg));
	padding: 2rem 1.5rem;
	text-align: center;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-floating);
}
.payment-off-title {
	margin: 0;
	color: var(--app-text-strong);
	font-size: 1.25rem;
	font-weight: 700;
	line-height: 1.2;
}
.payment-off-text {
	margin: 0.9rem 0 0;
	color: var(--app-muted);
	font-size: 0.92rem;
	line-height: 1.5;
}
.payment-off-button {
	display: inline-block;
	margin-top: 1.5rem;
	border-radius: 0.85rem;
	background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent));
	padding: 0.85rem 1.5rem;
	color: var(--app-button-fg);
	font-size: 0.95rem;
	font-weight: 700;
	text-decoration: none;
	box-shadow: var(--app-shadow-raised);
	transition: transform 0.16s ease;
}
.payment-off-button:active {
	transform: scale(0.97);
}
</style>
