<script setup lang="ts">
import type { Event } from '@community-club/shared/db/schema'
import AppScreenSkeleton from '~/components/ui/AppScreenSkeleton.vue'

definePageMeta({ middleware: 'auth', keepalive: true })

const eventsStore = useEventsStore()
const { goBack: navigateBack } = useAppBack('/app/events')
const currentDate = ref(new Date())
const selectedDate = ref(startOfDay(new Date()))
const loading = ref(!eventsStore.getMonthSnapshot(new Date().toISOString().slice(0, 7)))

const monthName = computed(() =>
	currentDate.value.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' }),
)

const monthKey = computed(() => {
	const year = currentDate.value.getFullYear()
	const month = String(currentDate.value.getMonth() + 1).padStart(2, '0')
	return `${year}-${month}`
})
const events = computed<Event[]>(() => eventsStore.getMonthEvents(monthKey.value))

const weekDays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']

const calendarDays = computed(() => {
	const firstDay = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth(), 1)
	const lastDay = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() + 1, 0)
	const startOffset = (firstDay.getDay() + 6) % 7
	const cells: Array<{
		key: string
		date: Date
		label: number
		inMonth: boolean
		events: Event[]
	}> = []

	for (let i = startOffset; i > 0; i--) {
		const date = new Date(firstDay)
		date.setDate(firstDay.getDate() - i)
		cells.push(makeCalendarCell(date, false))
	}

	for (let day = 1; day <= lastDay.getDate(); day++) {
		const date = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth(), day)
		cells.push(makeCalendarCell(date, true))
	}

	while (cells.length % 7 !== 0) {
		const nextDate = new Date(cells[cells.length - 1]?.date ?? lastDay)
		nextDate.setDate(nextDate.getDate() + 1)
		cells.push(makeCalendarCell(nextDate, false))
	}

	return cells
})

const selectedDayEvents = computed(() =>
	events.value
		.filter((item) => isSameDay(new Date(item.eventDate), selectedDate.value))
		.sort((a, b) => +new Date(a.eventDate) - +new Date(b.eventDate)),
)

function startOfDay(date: Date) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

function isSameDay(a: Date, b: Date) {
	return (
		a.getFullYear() === b.getFullYear() &&
		a.getMonth() === b.getMonth() &&
		a.getDate() === b.getDate()
	)
}

function makeCalendarCell(date: Date, inMonth: boolean) {
	return {
		key: date.toISOString(),
		date,
		label: date.getDate(),
		inMonth,
		events: events.value.filter((item) => isSameDay(new Date(item.eventDate), date)),
	}
}

function isToday(date: Date) {
	return isSameDay(date, new Date())
}

function prevMonth() {
	currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() - 1, 1)
	selectedDate.value = startOfDay(currentDate.value)
}

function nextMonth() {
	currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() + 1, 1)
	selectedDate.value = startOfDay(currentDate.value)
}

function selectDay(date: Date) {
	selectedDate.value = startOfDay(date)
}

function goBack() {
	void navigateBack('/app/events')
}

function formatEventDate(dateStr: string) {
	return new Date(dateStr).toLocaleString('ru-RU', {
		day: 'numeric',
		month: 'long',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

async function loadEvents() {
	loading.value = !eventsStore.getMonthSnapshot(monthKey.value)
	await eventsStore.fetchMonth(monthKey.value)
	loading.value = false
}

watch(monthKey, async () => {
	await loadEvents()
})

onMounted(async () => {
	await loadEvents()
})
</script>

<template>
	<div class="club-page space-y-4">
		<div class="flex items-center gap-3">
			<button class="flex h-10 w-10 items-center justify-center rounded-2xl glass hover:bg-[var(--app-bg)]" @click="goBack">
				<svg class="h-5 w-5 text-[var(--app-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" /></svg>
			</button>
			<h2 class="club-section-title text-2xl font-bold">Календарь</h2>
		</div>

		<div class="club-card rounded-3xl p-4">
			<div class="mb-4 flex items-center justify-between">
				<button class="p-2 rounded-xl glass hover:bg-[var(--app-bg)]" @click="prevMonth">
					<svg class="w-5 h-5 text-[var(--app-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" /></svg>
				</button>
				<span class="font-semibold text-lg text-[var(--app-text-strong)] capitalize">{{ monthName }}</span>
				<button class="p-2 rounded-xl glass hover:bg-[var(--app-bg)]" @click="nextMonth">
					<svg class="w-5 h-5 text-[var(--app-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" /></svg>
				</button>
			</div>

			<div class="mb-2 grid grid-cols-7 gap-1">
				<div v-for="wd in weekDays" :key="wd" class="py-1 text-center text-xs font-medium text-[var(--app-muted-soft)]">
					{{ wd }}
				</div>
			</div>

			<div class="grid grid-cols-7 gap-1">
				<button
					v-for="day in calendarDays"
					:key="day.key"
					type="button"
					class="calendar-day min-h-[78px] rounded-2xl p-2 text-left transition-all"
					:class="
						day.inMonth
							? isSameDay(day.date, selectedDate)
								? 'bg-[color-mix(in_srgb,var(--app-accent)_10%,var(--app-surface))] ring-2 ring-[color-mix(in_srgb,var(--app-accent)_60%,transparent)]'
								: 'bg-[var(--app-surface)] hover:bg-[var(--app-bg)]'
							: 'bg-[var(--app-bg)] text-[var(--app-muted-soft)] opacity-50'
					"
					@click="selectDay(day.date)"
				>
					<div class="flex items-start justify-between">
						<span
							class="text-sm font-semibold"
							:class="day.inMonth ? (isToday(day.date) ? 'text-[var(--app-accent-strong)]' : 'text-[var(--app-text)]') : 'text-[var(--app-muted-soft)]'"
						>
							{{ day.label }}
						</span>
					</div>
					<div class="mt-auto flex items-end justify-start">
						<span
							v-if="day.events.length"
							class="rounded-full border border-[var(--app-border-strong)] bg-[var(--app-bg-deep)] px-2 py-0.5 text-[10px] font-semibold text-[var(--app-accent-strong)]"
						>
							{{ day.events.length }}
						</span>
					</div>
				</button>
			</div>
		</div>

		<div class="club-card rounded-3xl p-4">
			<div class="mb-3">
				<h3 class="text-lg font-semibold text-[var(--app-text-strong)]">
					{{ selectedDate.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) }}
				</h3>
				<p class="text-sm text-[var(--app-muted)]">
					{{ selectedDayEvents.length ? 'События на выбранный день' : 'На выбранный день событий нет' }}
				</p>
			</div>

			<div v-if="loading" class="py-1">
				<AppScreenSkeleton variant="calendar" />
			</div>

			<div v-else-if="selectedDayEvents.length === 0" class="py-8 text-center text-sm text-[var(--app-muted-soft)]">
				Свободный день в календаре
			</div>

			<div v-else class="space-y-3">
				<div v-for="eventItem in selectedDayEvents" :key="eventItem.id" class="rounded-2xl border border-[var(--app-border)] bg-[var(--app-surface)] p-3 shadow-[var(--app-shadow-soft)]">
					<div
						v-if="eventItem.imageUrl"
						class="mb-3 aspect-[16/9] overflow-hidden rounded-2xl bg-[var(--app-bg-deep)]"
					>
						<img :src="eventItem.imageUrl" :alt="eventItem.title" class="h-full w-full object-cover" />
					</div>
					<h4 class="text-base font-semibold text-[var(--app-text-strong)]">{{ eventItem.title }}</h4>
					<p class="mt-1 text-xs font-medium text-[var(--app-accent-strong)]">{{ formatEventDate(eventItem.eventDate) }}</p>
					<p v-if="eventItem.description" class="mt-2 text-sm text-[var(--app-muted)] whitespace-pre-wrap">
						{{ eventItem.description }}
					</p>
				</div>
			</div>
		</div>
	</div>
</template>

<style scoped>
.calendar-day {
	display: flex;
	flex-direction: column;
}
</style>
