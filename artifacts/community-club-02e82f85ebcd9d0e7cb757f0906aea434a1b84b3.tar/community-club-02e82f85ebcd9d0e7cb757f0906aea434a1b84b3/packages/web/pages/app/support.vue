<script setup lang="ts">
import type {
	ChatMessageWithMeta,
	MentionCandidate,
	MentionPayload,
	ScheduledChatMessageItem,
	WSServerMessage,
} from '@community-club/shared/types'
import AppScreenSkeleton from '~/components/ui/AppScreenSkeleton.vue'
import type { ChatMessage } from '~/stores/chat'
import { getChatMessageDeleteTarget } from '~/utils/chat-message-delete'

definePageMeta({ middleware: 'auth', layout: false })

const api = useApi()
const auth = useAuthStore()
const ws = useWebSocket()
const chatStore = useChatStore()
const homeStore = useHomeStore()
const { uploadChatAttachment } = useChatAttachmentUpload()
const route = useRoute()
const router = useRouter()
const { goBack } = useAppBack('/app')
const {
	chatNotificationsEnabled,
	chatNotificationsLoading,
	chatNotificationsToast,
	loadChatNotificationSettings,
	toggleChatNotifications,
} = useChatNotifications()

const loading = ref(true)
const paging = ref(false)
const threadId = ref<number | null>(null)
const cursor = ref<string | null>(null)
const hasMore = ref(true)
const replyTo = ref<ChatMessage | null>(null)
const editingMessage = ref<ChatMessage | null>(null)
const showVoiceRecorder = ref(false)
const uploading = ref(false)
const uploadProgress = ref<number | null>(null)
const uiError = ref('')
const acceptedNotice = ref('')
const messagesContainer = ref<HTMLElement | null>(null)
const isAtBottom = ref(true)
const newMessagesBelowCount = ref(0)
const mentionCandidates = ref<MentionCandidate[]>([])
const searchOpen = ref(false)
const searchQuery = ref('')
const searchResults = ref<ChatMessage[]>([])
const searchLoading = ref(false)
const prefilledText = ref('')
const scheduledMessages = ref<ScheduledChatMessageItem[]>([])
const scheduledLoading = ref(false)
const scheduledBusy = ref(false)
let searchTimeout: ReturnType<typeof setTimeout> | null = null
let scheduledRefreshTimer: ReturnType<typeof setInterval> | null = null
let markReadTimer: ReturnType<typeof setTimeout> | null = null
let markReadRequest: Promise<void> | null = null
const unsubscribers: Array<() => void> = []
const pendingFallbacks = new Map<string, ReturnType<typeof setTimeout>>()
const MESSAGE_FALLBACK_DELAY_MS = 400

type ChatReadState = {
	lastReadMessageId: number
	unreadMessageCount: number
	unreadMentionCount: number
}

type ChatMessagesPage = {
	items: ChatMessage[]
	nextCursor: string | null
	direction?: 'asc' | 'desc'
	readState?: ChatReadState | null
}

function normalizeIncomingMessage(message: ChatMessageWithMeta): ChatMessage {
	return {
		...message,
		mentions: message.mentions ?? [],
		deliveryStatus: 'sent',
	}
}

function getMessageRenderKey(message: ChatMessage) {
	return message.clientMessageId ?? message.id
}

function makeClientMessageId() {
	if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
		return crypto.randomUUID()
	}

	return `support_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
}

function isNearBottom(threshold = 180) {
	const container = messagesContainer.value
	if (!container) return true
	return container.scrollHeight - container.scrollTop - container.clientHeight < threshold
}

function updateBottomState() {
	isAtBottom.value = isNearBottom(120)
	if (isAtBottom.value) {
		newMessagesBelowCount.value = 0
	}
}

function scrollToBottom(behavior: ScrollBehavior = 'auto') {
	const container = messagesContainer.value
	if (!container) return
	container.scrollTo({ top: container.scrollHeight, behavior })
	window.setTimeout(updateBottomState, behavior === 'smooth' ? 280 : 0)
}

async function markLoadedMessagesRead() {
	if (!threadId.value) return
	if (markReadRequest) return markReadRequest

	const loadedMessages = chatStore.getMessages(threadId.value)
	const latestMessage = loadedMessages[loadedMessages.length - 1]
	if (!latestMessage?.id || latestMessage.id < 1) return

	const currentThreadId = threadId.value
	markReadRequest = (async () => {
		const res = await api.post<ChatReadState>(`/api/chats/${currentThreadId}/read`, {
			latestMessageId: latestMessage.id,
		})
		if (res.success) {
			chatStore.applyChatReadState(currentThreadId, res.data)
			homeStore.invalidate()
			if (res.data.unreadMessageCount === 0) {
				newMessagesBelowCount.value = 0
			}
		}
	})()

	try {
		await markReadRequest
	} finally {
		markReadRequest = null
	}
}

function scheduleMarkLoadedMessagesRead(delayMs = 250) {
	if (markReadTimer) {
		clearTimeout(markReadTimer)
	}
	markReadTimer = setTimeout(() => {
		markReadTimer = null
		void markLoadedMessagesRead()
	}, delayMs)
}

async function scrollToLatestMessages() {
	await nextTick()
	scrollToBottom('smooth')
	scheduleMarkLoadedMessagesRead(360)
}

function flashMessage(messageId: number) {
	if (!import.meta.client) return
	const element = document.querySelector<HTMLElement>(`[data-message-id="${messageId}"]`)
	if (!element) return
	element.classList.add('ring-2', 'ring-[var(--app-accent)]', 'rounded-2xl')
	setTimeout(() => {
		element.classList.remove('ring-2', 'ring-[var(--app-accent)]', 'rounded-2xl')
	}, 1600)
}

async function scrollToMessage(messageId: number) {
	await nextTick()
	const element = document.querySelector<HTMLElement>(`[data-message-id="${messageId}"]`)
	if (!element) return false
	element.scrollIntoView({ behavior: 'smooth', block: 'center' })
	flashMessage(messageId)
	return true
}

async function jumpToMessage(messageId: number) {
	if (!threadId.value) return
	if (await scrollToMessage(messageId)) return

	const res = await api.get<ChatMessage>(`/api/chats/${threadId.value}/messages/${messageId}`)
	if (!res.success) return

	chatStore.upsertMessage(threadId.value, normalizeIncomingMessage(res.data as ChatMessageWithMeta))
	await scrollToMessage(messageId)
}

function getRequestedMessageId() {
	const rawMessageId = Array.isArray(route.query.messageId)
		? route.query.messageId[0]
		: route.query.messageId
	const messageId = Number(rawMessageId)
	return Number.isSafeInteger(messageId) && messageId > 0 ? messageId : null
}

async function openRequestedMessageFromQuery() {
	const messageId = getRequestedMessageId()
	if (!messageId) return

	await jumpToMessage(messageId)
	const nextQuery = { ...route.query }
	nextQuery.messageId = undefined
	void router.replace({ query: nextQuery })
}

async function runSearch() {
	if (!threadId.value) return

	const query = searchQuery.value.trim()
	if (!query) {
		searchResults.value = []
		searchLoading.value = false
		return
	}

	searchLoading.value = true
	const res = await api.get<ChatMessage[]>(
		`/api/chats/${threadId.value}/messages/search?q=${encodeURIComponent(query)}`,
	)
	if (res.success) {
		searchResults.value = res.data.map((item) =>
			normalizeIncomingMessage(item as ChatMessageWithMeta),
		)
	}
	searchLoading.value = false
}

function onSearchInput() {
	if (searchTimeout) {
		clearTimeout(searchTimeout)
	}

	searchTimeout = setTimeout(() => {
		void runSearch()
	}, 220)
}

function toggleSearch() {
	searchOpen.value = !searchOpen.value
	if (!searchOpen.value) {
		searchQuery.value = ''
		searchResults.value = []
		searchLoading.value = false
		return
	}

	nextTick(() => {
		const input = document.querySelector<HTMLInputElement>('[data-chat-search-input="support"]')
		input?.focus()
	})
}

function toggleCurrentChatNotifications() {
	void toggleChatNotifications(threadId.value)
}

async function selectSearchResult(messageId: number) {
	await jumpToMessage(messageId)
	searchOpen.value = false
	searchQuery.value = ''
	searchResults.value = []
}

const supportMessages = computed(() =>
	threadId.value == null ? [] : chatStore.getMessages(threadId.value),
)

function showAcceptedNotice() {
	acceptedNotice.value = 'Ваше обращение принято. Наши специалисты разберутся и свяжутся с вами.'
}

async function ensureThread() {
	const res = await api.get<{ id: number; slug: string; name: string; createdAt: string | Date }>(
		'/api/support/thread',
	)
	if (!res.success) {
		uiError.value = res.error.message
		loading.value = false
		return
	}

	threadId.value = res.data.id
	loading.value = chatStore.getMessages(res.data.id).length === 0
	ws.connect()
	ws.send({ type: 'join_room', chatId: res.data.id })
}

async function loadMentionCandidates() {
	if (!threadId.value) return

	const cached = chatStore.getMentionCandidates(threadId.value)
	if (cached.length) {
		mentionCandidates.value = cached
	}
	mentionCandidates.value = await chatStore.fetchMentionCandidates(threadId.value)
}

async function loadMessages() {
	if (!threadId.value) return
	if (chatStore.getMessages(threadId.value).length > 0) {
		loading.value = false
	}

	const isOlderLoad = !!cursor.value
	if (isOlderLoad && paging.value) return
	const container = messagesContainer.value
	const previousScrollHeight = container?.scrollHeight ?? 0
	const previousScrollTop = container?.scrollTop ?? 0
	paging.value = isOlderLoad

	const params = cursor.value ? `?cursor=${cursor.value}&limit=50` : '?limit=50'
	const res = await api.get<ChatMessagesPage>(`/api/chats/${threadId.value}/messages${params}`)
	if (!res.success) {
		uiError.value = res.error.message
		loading.value = false
		paging.value = false
		return
	}

	const items = (res.data.direction === 'asc' ? res.data.items : [...res.data.items].reverse()).map(
		(item) => normalizeIncomingMessage(item as ChatMessageWithMeta),
	)
	chatStore.prependMessages(threadId.value, items)
	if (res.data.readState) {
		chatStore.applyChatReadState(threadId.value, res.data.readState)
		homeStore.invalidate()
	}
	cursor.value = res.data.nextCursor
	hasMore.value = !!res.data.nextCursor
	loading.value = false
	paging.value = false
	await nextTick()
	if (isOlderLoad && container) {
		container.scrollTop = container.scrollHeight - previousScrollHeight + previousScrollTop
		return
	}
	scrollToBottom()
	scheduleMarkLoadedMessagesRead()
}

async function loadScheduledMessages(force = false) {
	if (!auth.isAdmin || !threadId.value) return
	if (scheduledLoading.value && !force) return

	scheduledLoading.value = true
	const res = await api.get<ScheduledChatMessageItem[]>(`/api/chats/${threadId.value}/scheduled`)
	if (res.success) {
		scheduledMessages.value = res.data
	}
	scheduledLoading.value = false
}

function onScroll() {
	if (!messagesContainer.value || loading.value || paging.value) return
	updateBottomState()
	if (isNearBottom(220)) {
		scheduleMarkLoadedMessagesRead()
	}
	if (!hasMore.value) return
	if (messagesContainer.value.scrollTop < 100) {
		void loadMessages()
	}
}

function clearMessageFallback(clientMessageId: string | null | undefined) {
	if (!clientMessageId) return
	const timer = pendingFallbacks.get(clientMessageId)
	if (!timer) return
	clearTimeout(timer)
	pendingFallbacks.delete(clientMessageId)
}

function scheduleMessageFallback(
	clientMessageId: string,
	data: {
		content: string
		messageType: string
		replyToId?: number
		attachmentUrl?: string | null
		attachmentName?: string | null
		attachmentSize?: number | null
		mentions?: MentionPayload[]
	},
) {
	clearMessageFallback(clientMessageId)

	const timer = setTimeout(async () => {
		pendingFallbacks.delete(clientMessageId)
		if (!threadId.value) return

		const optimisticMessage = chatStore
			.getMessages(threadId.value)
			.find((item) => item.clientMessageId === clientMessageId)
		if (!optimisticMessage || optimisticMessage.deliveryStatus === 'sent') {
			return
		}

		const res = await api.post<ChatMessage>(`/api/chats/${threadId.value}/messages`, {
			chatId: threadId.value,
			clientMessageId,
			content: data.content,
			replyToId: data.replyToId,
			messageType: data.messageType,
			mentions: data.mentions,
			attachmentUrl: data.attachmentUrl ?? undefined,
			attachmentName: data.attachmentName ?? undefined,
			attachmentSize: data.attachmentSize ?? undefined,
		})

		if (res.success) {
			chatStore.ackMessage(threadId.value, clientMessageId, normalizeIncomingMessage(res.data))
			showAcceptedNotice()
			nextTick(() => scrollToBottom())
			return
		}

		chatStore.markMessageFailed(threadId.value, clientMessageId)
	}, MESSAGE_FALLBACK_DELAY_MS)

	pendingFallbacks.set(clientMessageId, timer)
}

function handleSocketMessage(message: WSServerMessage) {
	if (!threadId.value) return

	switch (message.type) {
		case 'new_message': {
			if (message.message.chatId !== threadId.value) return
			const shouldStickToBottom =
				message.message.userAuthUuid === auth.user?.authUuid || isNearBottom()
			chatStore.upsertMessage(threadId.value, normalizeIncomingMessage(message.message))
			if (message.message.userAuthUuid === auth.user?.authUuid) {
				showAcceptedNotice()
			}
			if (shouldStickToBottom) {
				nextTick(() => {
					scrollToBottom()
					if (message.message.userAuthUuid !== auth.user?.authUuid) {
						scheduleMarkLoadedMessagesRead()
					}
				})
			} else if (message.message.userAuthUuid !== auth.user?.authUuid) {
				newMessagesBelowCount.value += 1
			}
			break
		}
		case 'message_ack': {
			if (message.message.chatId !== threadId.value) return
			clearMessageFallback(message.clientMessageId)
			chatStore.ackMessage(
				threadId.value,
				message.clientMessageId,
				normalizeIncomingMessage(message.message),
			)
			showAcceptedNotice()
			nextTick(() => scrollToBottom())
			break
		}
		case 'message_updated': {
			if (message.message.chatId !== threadId.value) return
			chatStore.upsertMessage(threadId.value, normalizeIncomingMessage(message.message))
			break
		}
		case 'typing': {
			if (message.chatId !== threadId.value || message.userId === auth.user?.authUuid) return
			chatStore.setTyping(threadId.value, message.userId, message.expiresAt)
			break
		}
		case 'presence': {
			if (message.chatId !== threadId.value) return
			chatStore.setPresence(threadId.value, message.onlineCount)
			break
		}
		case 'message_deleted': {
			if (message.chatId !== threadId.value) return
			chatStore.removeMessage(message.messageId)
			break
		}
		case 'reaction_update': {
			chatStore.updateReaction(message.messageId, message.userId, message.emoji, message.action)
			break
		}
		case 'error': {
			uiError.value = message.message || 'Не удалось отправить сообщение. Попробуйте ещё раз.'
			clearMessageFallback(message.clientMessageId)
			if (message.clientMessageId) {
				chatStore.markMessageFailed(threadId.value, message.clientMessageId)
			}
			break
		}
	}
}

function sendChatMessage(data: {
	content: string
	messageType: string
	replyToId?: number
	attachmentUrl?: string | null
	attachmentName?: string | null
	attachmentSize?: number | null
	mentions?: MentionPayload[]
}) {
	if (!threadId.value) return

	const clientMessageId = makeClientMessageId()
	const optimisticMessageId = -Date.now()
	uiError.value = ''

	chatStore.addOptimisticMessage(threadId.value, {
		id: optimisticMessageId,
		chatId: threadId.value,
		userAuthUuid: auth.user?.authUuid ?? '',
		content: data.content,
		replyToId: replyTo.value?.id ?? data.replyToId ?? null,
		replyTo: replyTo.value ?? null,
		clientMessageId,
		messageType: data.messageType as ChatMessage['messageType'],
		attachmentUrl: data.attachmentUrl ?? null,
		attachmentName: data.attachmentName ?? null,
		attachmentSize: data.attachmentSize ?? null,
		linkPreview: null,
		isDeleted: false,
		createdAt: new Date(),
		updatedAt: new Date(),
		reactions: [],
		mentions:
			data.mentions?.map((mention, index) => ({
				id: optimisticMessageId - index,
				messageId: optimisticMessageId,
				mentionedUserAuthUuid: mention.userAuthUuid,
				displayName: mention.displayName,
				startOffset: mention.start,
				endOffset: mention.end,
				createdAt: new Date(),
			})) ?? [],
		author: {
			fullName: auth.user?.fullName ?? null,
			username: auth.user?.username ?? null,
			avatarUrl: auth.user?.avatarUrl ?? null,
			chatAdminBadge: auth.user?.chatAdminBadge ?? false,
		},
		deliveryStatus: 'sending',
	})

	ws.send({
		type: 'send_message',
		chatId: threadId.value,
		clientMessageId,
		content: data.content,
		messageType: data.messageType,
		replyToId: replyTo.value?.id ?? data.replyToId,
		attachmentUrl: data.attachmentUrl,
		attachmentName: data.attachmentName,
		attachmentSize: data.attachmentSize,
		mentions: data.mentions,
	})
	scheduleMessageFallback(clientMessageId, {
		...data,
		replyToId: replyTo.value?.id ?? data.replyToId,
	})

	replyTo.value = null
	nextTick(() => scrollToBottom())
}

function onSendMessage(data: {
	content: string
	messageType: string
	replyToId?: number
	mentions?: MentionPayload[]
}) {
	sendChatMessage(data)
}

async function onScheduleMessage(data: {
	content: string
	scheduledAt: string
	mentions?: MentionPayload[]
}) {
	if (!threadId.value) return
	scheduledBusy.value = true
	const res = await api.post<ScheduledChatMessageItem>(
		`/api/chats/${threadId.value}/scheduled`,
		data,
	)
	if (res.success) {
		await loadScheduledMessages(true)
	}
	scheduledBusy.value = false
}

async function onDeleteScheduledMessage(id: number) {
	if (!threadId.value) return
	scheduledBusy.value = true
	const res = await api.delete<{ id: number }>(`/api/chats/${threadId.value}/scheduled/${id}`)
	if (res.success) {
		scheduledMessages.value = scheduledMessages.value.filter((item) => item.id !== id)
		await loadScheduledMessages(true)
	}
	scheduledBusy.value = false
}

function onReply(message: ChatMessage) {
	replyTo.value = message
}

function onEdit(message: ChatMessage) {
	replyTo.value = null
	editingMessage.value = message
}

function onSaveEdit(data: { messageId: number; content: string; mentions?: MentionPayload[] }) {
	if (!threadId.value) return

	ws.send({
		type: 'edit_message',
		chatId: threadId.value,
		messageId: data.messageId,
		content: data.content,
		mentions: data.mentions,
	})
	chatStore.updateMessage(threadId.value, data.messageId, (message) => ({
		...message,
		content: data.content,
		updatedAt: new Date(),
		mentions:
			data.mentions?.map((mention, index) => ({
				id: message.id * 1000 + index,
				messageId: message.id,
				mentionedUserAuthUuid: mention.userAuthUuid,
				displayName: mention.displayName,
				startOffset: mention.start,
				endOffset: mention.end,
				createdAt: new Date(),
			})) ?? [],
	}))
	editingMessage.value = null
}

function onReact(messageId: number, emoji: string) {
	if (!threadId.value) return
	ws.send({ type: 'reaction', chatId: threadId.value, messageId, emoji })
}

async function onDeleteMessage(messageId: number) {
	if (!threadId.value) return
	const target = getChatMessageDeleteTarget(chatStore.getMessages(threadId.value), messageId)
	if (!target) return

	clearMessageFallback(target.clientMessageId)
	if (!target.persisted) {
		chatStore.removeMessage(messageId)
		return
	}

	const res = await api.delete<{ deleted: boolean }>(
		`/api/chats/${threadId.value}/messages/${messageId}`,
	)
	if (res.success) {
		chatStore.removeMessage(messageId)
		homeStore.invalidate()
	}
}

async function onAttachment(file: File) {
	if (!threadId.value) return

	uploading.value = true
	uploadProgress.value = 0
	uiError.value = ''

	try {
		const result = await uploadChatAttachment(threadId.value, file, {
			onProgress: (progress) => {
				uploadProgress.value = progress.percent
			},
		})

		if (!result.success) {
			uiError.value = result.error.message
			return
		}

		sendChatMessage({
			content: '',
			messageType: result.data.messageType,
			attachmentUrl: result.data.url,
			attachmentName: result.data.name,
			attachmentSize: result.data.size,
		})
	} catch {
		uiError.value = 'Загрузка прервалась. Попробуйте ещё раз.'
	} finally {
		uploading.value = false
		uploadProgress.value = null
	}
}

async function onVoiceRecorded(blob: Blob) {
	showVoiceRecorder.value = false
	const isOgg = blob.type.includes('ogg')
	const ext = isOgg ? 'ogg' : 'webm'
	await onAttachment(new File([blob], `voice_${Date.now()}.${ext}`, { type: blob.type }))
}

onMounted(async () => {
	unsubscribers.push(ws.on('new_message', handleSocketMessage))
	unsubscribers.push(ws.on('message_ack', handleSocketMessage))
	unsubscribers.push(ws.on('message_updated', handleSocketMessage))
	unsubscribers.push(ws.on('typing', handleSocketMessage))
	unsubscribers.push(ws.on('presence', handleSocketMessage))
	unsubscribers.push(ws.on('message_deleted', handleSocketMessage))
	unsubscribers.push(ws.on('reaction_update', handleSocketMessage))
	unsubscribers.push(ws.on('error', handleSocketMessage))

	await ensureThread()
	await Promise.all([
		loadMentionCandidates(),
		loadMessages(),
		loadScheduledMessages(),
		loadChatNotificationSettings(threadId.value),
	])

	if (auth.isAdmin) {
		scheduledRefreshTimer = setInterval(() => {
			void loadScheduledMessages()
		}, 30_000)
	}

	const rawPrefill = typeof route.query.prefill === 'string' ? route.query.prefill.trim() : ''
	if (rawPrefill) {
		prefilledText.value = rawPrefill
		const nextQuery = { ...route.query }
		nextQuery.prefill = undefined
		void router.replace({ query: nextQuery })
	}

	await openRequestedMessageFromQuery()
})

onUnmounted(() => {
	if (threadId.value) {
		ws.send({ type: 'leave_room', chatId: threadId.value })
	}
	for (const unsubscribe of unsubscribers) {
		unsubscribe()
	}
	for (const timer of pendingFallbacks.values()) {
		clearTimeout(timer)
	}
	pendingFallbacks.clear()
	if (searchTimeout) {
		clearTimeout(searchTimeout)
		searchTimeout = null
	}
	if (markReadTimer) {
		clearTimeout(markReadTimer)
		markReadTimer = null
	}
	if (scheduledRefreshTimer) {
		clearInterval(scheduledRefreshTimer)
		scheduledRefreshTimer = null
	}
})

const typingUsers = computed(() =>
	threadId.value == null ? [] : chatStore.getTypingUsers(threadId.value),
)
const scrollDownBadgeCount = computed(() => newMessagesBelowCount.value)
const showScrollDownButton = computed(() => !isAtBottom.value || scrollDownBadgeCount.value > 0)
</script>

<template>
	<div class="club-chat-shell">
		<header class="club-chat-header">
			<div class="club-chat-header-row">
				<button type="button" class="club-back-button" aria-label="Назад" @click="goBack('/app')">
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</button>
				<div class="min-w-0 flex-1">
					<h1 class="club-chat-title">Техническая поддержка</h1>
					<p class="club-chat-subtitle">Чат поддержки</p>
				</div>
				<button
					type="button"
					:class="[
						'club-round-action',
						chatNotificationsEnabled ? 'is-notification-active' : 'is-notification-muted',
					]"
					:aria-label="chatNotificationsEnabled ? 'Отключить уведомления чата' : 'Включить уведомления чата'"
					:disabled="chatNotificationsLoading || !threadId"
					@click="toggleCurrentChatNotifications"
				>
					<svg
						v-if="chatNotificationsEnabled"
						class="h-5 w-5"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.4-1.4A2 2 0 0 1 18 14.2V11a6 6 0 1 0-12 0v3.2c0 .53-.21 1.04-.59 1.41L4 17h5m6 0a3 3 0 0 1-6 0" />
					</svg>
					<svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 8a6 6 0 0 0-11.2-3M6 11v3.2c0 .53-.21 1.04-.59 1.41L4 17h10m1 0a3 3 0 0 1-5.2 1.9M3 3l18 18" />
					</svg>
				</button>
				<button type="button" class="club-round-action" aria-label="Поиск по чату" @click="toggleSearch">
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21-4.35-4.35m1.85-5.15a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
					</svg>
				</button>
			</div>
			<div v-if="searchOpen" class="club-chat-search-panel">
				<div class="relative">
					<input
						data-chat-search-input="support"
						v-model="searchQuery"
						type="text"
						placeholder="Поиск по чату"
						class="club-chat-search-input"
						@input="onSearchInput"
					/>
					<button
						v-if="searchQuery"
						class="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--app-muted-soft)] transition hover:text-[var(--app-text)]"
						@click="searchQuery = ''; searchResults = []"
					>
						<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 18 6M6 6l12 12" />
						</svg>
					</button>
				</div>
				<div v-if="searchQuery" class="club-chat-results">
					<div v-if="searchLoading" class="px-4 py-3 text-sm text-[var(--app-muted)]">
						Ищу сообщения...
					</div>
					<button
						v-for="result in searchResults"
						:key="result.id"
						class="block w-full border-b border-[var(--app-border)] px-4 py-3 text-left transition last:border-b-0 hover:bg-[var(--app-bg)]"
						@click="selectSearchResult(result.id)"
					>
						<p class="line-clamp-2 text-sm text-[var(--app-text)]">
							{{ result.content || 'Сообщение без текста' }}
						</p>
						<p class="mt-1 text-xs text-[var(--app-muted-soft)]">
							{{ new Date(result.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) }}
						</p>
					</button>
					<div
						v-if="!searchLoading && searchResults.length === 0"
						class="px-4 py-3 text-sm text-[var(--app-muted)]"
					>
						Ничего не найдено
					</div>
				</div>
			</div>
		</header>
		<Transition name="chat-toast">
			<div v-if="chatNotificationsToast" class="club-chat-toast">
				{{ chatNotificationsToast }}
			</div>
		</Transition>

		<div class="shrink-0 px-4 pt-3">
			<div class="club-alert-soft px-4 py-3 text-sm">
				Напишите ваш вопрос в чат и мы поможем вам.
			</div>
			<p v-if="uiError" class="mt-3 rounded-2xl border border-[color-mix(in_srgb,var(--app-accent-wine)_32%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent-wine)_9%,var(--app-surface))] px-4 py-3 text-sm text-[var(--app-accent-wine)]">
				{{ uiError }}
			</p>
		</div>

		<div ref="messagesContainer" class="club-chat-messages chat-pattern" @scroll="onScroll">
			<div v-if="loading" class="py-2">
				<AppScreenSkeleton variant="chat" />
			</div>

			<div
				v-else-if="supportMessages.length === 0"
				class="club-chat-empty"
			>
				<div>
					<svg class="mx-auto mb-3 h-14 w-14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
					</svg>
					<p class="text-sm font-semibold text-[var(--app-text)]">Поддержка на связи</p>
					<p class="mt-1 text-xs">Опишите вопрос, и мы поможем.</p>
				</div>
			</div>

			<div v-else class="space-y-2">
				<ChatMessageBubble
					v-for="message in supportMessages"
					:key="getMessageRenderKey(message)"
					v-memo="[message, message.deliveryStatus, auth.user?.authUuid]"
					:message="message"
					:is-own="message.userAuthUuid === auth.user?.authUuid"
					:show-author="message.userAuthUuid !== auth.user?.authUuid"
					@reply="onReply"
					@edit="onEdit"
					@jump-to-reply="jumpToMessage"
					@react="onReact"
					@delete="onDeleteMessage"
				/>
				<p
					v-if="acceptedNotice"
					class="mt-3 rounded-2xl border border-[color-mix(in_srgb,var(--app-accent-slate)_28%,var(--app-border))] bg-[color-mix(in_srgb,var(--app-accent-slate)_8%,var(--app-surface))] px-4 py-3 text-sm text-[var(--app-text)] shadow-[var(--app-shadow-soft)]"
				>
					{{ acceptedNotice }}
				</p>
			</div>
		</div>

		<Transition name="chat-scroll-down">
			<button
				v-if="showScrollDownButton"
				type="button"
				class="club-chat-scroll-down"
				aria-label="К последним сообщениям"
				@click="scrollToLatestMessages"
			>
				<span v-if="scrollDownBadgeCount > 0" class="club-chat-scroll-down-badge">
					{{ scrollDownBadgeCount > 99 ? '99+' : scrollDownBadgeCount }}
				</span>
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35" d="m6 9 6 6 6-6" />
				</svg>
			</button>
		</Transition>

		<div class="club-chat-composer">
			<div v-if="typingUsers.length" class="px-4 pb-2 pt-2 text-xs text-[var(--app-muted-soft)]">
				Специалист поддержки печатает...
			</div>

			<ChatVoiceRecorder
				v-if="showVoiceRecorder"
				@recorded="onVoiceRecorded"
				@close="showVoiceRecorder = false"
			/>

				<ChatMessageInput
					v-else
					:reply-to="replyTo"
					:editing-message="editingMessage"
					:mention-candidates="mentionCandidates"
					:prefilled-text="prefilledText"
					:can-schedule="auth.isAdmin"
					:scheduled-messages="scheduledMessages"
					:scheduled-loading="scheduledLoading || scheduledBusy"
					@send="onSendMessage"
					@schedule="onScheduleMessage"
					@delete-scheduled="onDeleteScheduledMessage"
					@save-edit="onSaveEdit"
					@typing="() => undefined"
				@cancel-reply="replyTo = null"
				@cancel-edit="editingMessage = null"
				@attachment="onAttachment"
				@voice-start="showVoiceRecorder = true"
			/>

			<div v-if="uploading" class="px-4 pb-3 text-xs text-[var(--app-accent-strong)]">
				Загрузка файла{{ uploadProgress == null ? '' : `: ${uploadProgress}%` }}
			</div>
		</div>
		</div>
	</template>
