<script setup lang="ts">
import LegalDocumentPage from '~/components/legal/LegalDocumentPage.vue'
</script>

<template>
	<LegalDocumentPage doc-key="personalData" back-fallback="/app" />
</template>
