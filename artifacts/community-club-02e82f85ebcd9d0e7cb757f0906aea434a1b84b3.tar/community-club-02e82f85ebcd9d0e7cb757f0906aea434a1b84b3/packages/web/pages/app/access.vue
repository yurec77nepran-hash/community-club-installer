<script setup lang="ts">
definePageMeta({ keepalive: false })

const route = useRoute()

onMounted(() => {
	void navigateTo(
		{
			path: '/app',
			query: {
				access: 'required',
				redirect: typeof route.query.redirect === 'string' ? route.query.redirect : '/app',
				intent: route.query.intent === 'pay' ? 'pay' : undefined,
			},
		},
		{ replace: true },
	)
})
</script>

<template>
	<div class="min-h-screen bg-[var(--app-bg)]" />
</template>
