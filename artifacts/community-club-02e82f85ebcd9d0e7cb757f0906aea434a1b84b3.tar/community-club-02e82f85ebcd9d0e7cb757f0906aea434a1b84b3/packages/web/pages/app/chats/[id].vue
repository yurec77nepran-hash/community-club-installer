<script setup lang="ts">
import type { Message } from '@community-club/shared/db/schema'
import type {
	ChatMessageWithMeta,
	MentionCandidate,
	MentionPayload,
	ScheduledChatMessageItem,
	WSServerMessage,
} from '@community-club/shared/types'
import AppScreenSkeleton from '~/components/ui/AppScreenSkeleton.vue'
import { getChatMessageDeleteTarget } from '~/utils/chat-message-delete'
import { buildInitialChatMessagesQuery } from '~/utils/chat-upload'
import type { ChatMessage } from '../../../stores/chat'

definePageMeta({ middleware: ['auth'], layout: false })

const route = useRoute()
const router = useRouter()
const chatId = computed(() => Number(route.params.id))
const api = useApi()
const auth = useAuthStore()
const ws = useWebSocket()
const chatStore = useChatStore()
const homeStore = useHomeStore()
const { uploadChatAttachment } = useChatAttachmentUpload()
const {
	chatNotificationsEnabled,
	chatNotificationsLoading,
	chatNotificationsToast,
	loadChatNotificationSettings,
	toggleChatNotifications,
} = useChatNotifications()

const loading = ref(chatStore.getMessages(chatId.value).length === 0)
const paging = ref(false)
const cursor = ref<string | null>(null)
const hasMore = ref(true)
const newerCursor = ref<string | null>(null)
const hasNewer = ref(false)
const replyTo = ref<Message | null>(null)
const editingMessage = ref<Message | null>(null)
const showVoiceRecorder = ref(false)
const uploading = ref(false)
const uploadError = ref('')
const uploadProgress = ref<number | null>(null)
const messagesContainer = ref<HTMLElement | null>(null)
const isAtBottom = ref(true)
const newMessagesBelowCount = ref(0)
const mentionCandidates = ref<MentionCandidate[]>([])
const searchOpen = ref(false)
const searchQuery = ref('')
const searchResults = ref<ChatMessage[]>([])
const searchLoading = ref(false)
const scheduledMessages = ref<ScheduledChatMessageItem[]>([])
const scheduledLoading = ref(false)
const scheduledBusy = ref(false)
let searchTimeout: ReturnType<typeof setTimeout> | null = null
let typingTimeout: ReturnType<typeof setTimeout> | null = null
let scheduledRefreshTimer: ReturnType<typeof setInterval> | null = null
let markReadTimer: ReturnType<typeof setTimeout> | null = null
let markReadRequest: Promise<void> | null = null
let lastTypingSentAt = 0
const unsubscribers: Array<() => void> = []
const pendingFallbacks = new Map<string, ReturnType<typeof setTimeout>>()
const MESSAGE_FALLBACK_DELAY_MS = 400
const TYPING_EMIT_COOLDOWN_MS = 1_200
const CHAT_MESSAGES_PAGE_SIZE = 50

type ChatReadState = {
	lastReadMessageId: number
	unreadMessageCount: number
	unreadMentionCount: number
}

type ChatMessagesPage = {
	items: ChatMessage[]
	nextCursor: string | null
	direction?: 'asc' | 'desc'
	newerCursor?: string | null
	hasNewer?: boolean
	readState?: ChatReadState | null
}

function makeClientMessageId() {
	if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
		return crypto.randomUUID()
	}

	return `msg_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
}

function normalizeIncomingMessage(message: ChatMessageWithMeta): ChatMessage {
	return {
		...message,
		mentions: message.mentions ?? [],
		deliveryStatus: 'sent',
	}
}

function getMessageRenderKey(message: ChatMessage) {
	return message.clientMessageId ?? message.id
}

async function loadMentionCandidates() {
	const cached = chatStore.getMentionCandidates(chatId.value)
	if (cached.length) {
		mentionCandidates.value = cached
	}
	mentionCandidates.value = await chatStore.fetchMentionCandidates(chatId.value)
}

function normalizePageItems(page: ChatMessagesPage) {
	const items = page.direction === 'asc' ? page.items : [...page.items].reverse()
	return items.map((item) => normalizeIncomingMessage(item as ChatMessageWithMeta))
}

function applyReadState(readState?: ChatReadState | null) {
	if (!readState) return
	chatStore.applyChatReadState(chatId.value, readState)
	homeStore.invalidate()
}

function isNearBottom(threshold = 180) {
	const container = messagesContainer.value
	if (!container) return true
	return container.scrollHeight - container.scrollTop - container.clientHeight < threshold
}

function updateBottomState() {
	isAtBottom.value = isNearBottom(120)
	if (isAtBottom.value && !hasNewer.value) {
		newMessagesBelowCount.value = 0
	}
}

async function scrollToFirstUnread(afterMessageId: number) {
	await nextTick()
	const target = chatStore.getMessages(chatId.value).find((message) => message.id > afterMessageId)
	if (!target) return false

	const element = document.querySelector<HTMLElement>(`[data-message-id="${target.id}"]`)
	if (!element) return false
	element.scrollIntoView({ behavior: 'auto', block: 'center' })
	window.setTimeout(updateBottomState, 0)
	return true
}

async function loadInitialMessages() {
	if (chatStore.getMessages(chatId.value).length > 0) {
		loading.value = false
	}

	const current = currentChat.value
	const initialRequest = buildInitialChatMessagesQuery({
		limit: CHAT_MESSAGES_PAGE_SIZE,
		lastReadMessageId: current?.lastReadMessageId ?? null,
		unreadMessageCount: current?.unreadMessageCount ?? 0,
		hasRequestedMessage: getRequestedMessageId() != null,
	})

	const res = await api.get<ChatMessagesPage>(
		`/api/chats/${chatId.value}/messages${initialRequest.query}`,
	)
	if (res.success) {
		const items = normalizePageItems(res.data)
		chatStore.prependMessages(chatId.value, items)
		applyReadState(res.data.readState)
		cursor.value = res.data.nextCursor
		hasMore.value = !!res.data.nextCursor
		newerCursor.value =
			res.data.newerCursor ?? (items.length ? String(items[items.length - 1].id) : null)
		hasNewer.value = !!res.data.hasNewer
	}

	loading.value = false

	await nextTick()
	if (
		initialRequest.restoreAfterMessageId &&
		(await scrollToFirstUnread(initialRequest.restoreAfterMessageId))
	) {
		return
	}
	scrollToBottom()
}

async function loadOlderMessages() {
	if (!cursor.value || !hasMore.value || loading.value || paging.value) return
	const container = messagesContainer.value
	const previousScrollHeight = container?.scrollHeight ?? 0
	const previousScrollTop = container?.scrollTop ?? 0

	paging.value = true
	const res = await api.get<ChatMessagesPage>(
		`/api/chats/${chatId.value}/messages?cursor=${cursor.value}&limit=${CHAT_MESSAGES_PAGE_SIZE}`,
	)
	if (res.success) {
		const items = normalizePageItems(res.data)
		chatStore.prependMessages(chatId.value, items)
		applyReadState(res.data.readState)
		cursor.value = res.data.nextCursor
		hasMore.value = !!res.data.nextCursor
	}
	paging.value = false

	await nextTick()
	if (container) {
		container.scrollTop = container.scrollHeight - previousScrollHeight + previousScrollTop
	}
}

async function loadNewerMessages() {
	if (!newerCursor.value || !hasNewer.value || loading.value || paging.value) return

	paging.value = true
	const res = await api.get<ChatMessagesPage>(
		`/api/chats/${chatId.value}/messages?after=${newerCursor.value}&limit=${CHAT_MESSAGES_PAGE_SIZE}`,
	)
	if (res.success) {
		const items = normalizePageItems(res.data)
		chatStore.prependMessages(chatId.value, items)
		applyReadState(res.data.readState)
		newerCursor.value =
			res.data.newerCursor ??
			(items.length ? String(items[items.length - 1].id) : newerCursor.value)
		hasNewer.value = !!res.data.hasNewer
	}
	paging.value = false
}

async function loadScheduledMessages(force = false) {
	if (!auth.isAdmin) return
	if (scheduledLoading.value && !force) return

	scheduledLoading.value = true
	const res = await api.get<ScheduledChatMessageItem[]>(`/api/chats/${chatId.value}/scheduled`)
	if (res.success) {
		scheduledMessages.value = res.data
	}
	scheduledLoading.value = false
}

function scrollToBottom(behavior: ScrollBehavior = 'auto') {
	const container = messagesContainer.value
	if (!container) return
	container.scrollTo({ top: container.scrollHeight, behavior })
	window.setTimeout(updateBottomState, behavior === 'smooth' ? 280 : 0)
}

async function markLoadedMessagesRead() {
	if (markReadRequest) return markReadRequest

	const loadedMessages = chatStore.getMessages(chatId.value)
	const latestMessage = loadedMessages[loadedMessages.length - 1]
	if (!latestMessage?.id || latestMessage.id < 1) return

	const currentChatId = chatId.value
	markReadRequest = (async () => {
		const res = await api.post<ChatReadState>(`/api/chats/${currentChatId}/read`, {
			latestMessageId: latestMessage.id,
		})
		if (res.success) {
			chatStore.applyChatReadState(currentChatId, res.data)
			homeStore.invalidate()
			if (res.data.unreadMessageCount === 0) {
				newMessagesBelowCount.value = 0
			}
		}
	})()

	try {
		await markReadRequest
	} finally {
		markReadRequest = null
	}
}

function scheduleMarkLoadedMessagesRead(delayMs = 250) {
	if (markReadTimer) {
		clearTimeout(markReadTimer)
	}
	markReadTimer = setTimeout(() => {
		markReadTimer = null
		void markLoadedMessagesRead()
	}, delayMs)
}

async function loadLatestMessages() {
	if (loading.value || paging.value) return

	paging.value = true
	const res = await api.get<ChatMessagesPage>(
		`/api/chats/${chatId.value}/messages?limit=${CHAT_MESSAGES_PAGE_SIZE}`,
	)
	if (res.success) {
		const items = normalizePageItems(res.data)
		chatStore.prependMessages(chatId.value, items)
		applyReadState(res.data.readState)
		if (!cursor.value) {
			cursor.value = res.data.nextCursor
			hasMore.value = !!res.data.nextCursor
		}
		newerCursor.value = items.length ? String(items[items.length - 1].id) : newerCursor.value
		hasNewer.value = false
		newMessagesBelowCount.value = 0
	}
	paging.value = false
}

async function scrollToLatestMessages() {
	if (hasNewer.value) {
		await loadLatestMessages()
	}
	await nextTick()
	scrollToBottom('smooth')
	scheduleMarkLoadedMessagesRead(360)
}

function flashMessage(messageId: number) {
	if (!import.meta.client) return
	const element = document.querySelector<HTMLElement>(`[data-message-id="${messageId}"]`)
	if (!element) return
	element.classList.add('ring-2', 'ring-[var(--app-accent)]', 'rounded-2xl')
	setTimeout(() => {
		element.classList.remove('ring-2', 'ring-[var(--app-accent)]', 'rounded-2xl')
	}, 1600)
}

async function scrollToMessage(messageId: number) {
	await nextTick()
	const element = document.querySelector<HTMLElement>(`[data-message-id="${messageId}"]`)
	if (!element) return false
	element.scrollIntoView({ behavior: 'smooth', block: 'center' })
	flashMessage(messageId)
	return true
}

async function jumpToMessage(messageId: number) {
	if (await scrollToMessage(messageId)) return

	const res = await api.get<ChatMessage>(`/api/chats/${chatId.value}/messages/${messageId}`)
	if (!res.success) return

	chatStore.upsertMessage(chatId.value, normalizeIncomingMessage(res.data as ChatMessageWithMeta))
	await scrollToMessage(messageId)
}

function getRequestedMessageId() {
	const rawMessageId = Array.isArray(route.query.messageId)
		? route.query.messageId[0]
		: route.query.messageId
	const messageId = Number(rawMessageId)
	return Number.isSafeInteger(messageId) && messageId > 0 ? messageId : null
}

async function openRequestedMessageFromQuery() {
	const messageId = getRequestedMessageId()
	if (!messageId) return

	await jumpToMessage(messageId)
	const nextQuery = { ...route.query }
	nextQuery.messageId = undefined
	void router.replace({ query: nextQuery })
}

async function runSearch() {
	const query = searchQuery.value.trim()
	if (!query) {
		searchResults.value = []
		searchLoading.value = false
		return
	}

	searchLoading.value = true
	const res = await api.get<ChatMessage[]>(
		`/api/chats/${chatId.value}/messages/search?q=${encodeURIComponent(query)}`,
	)
	if (res.success) {
		searchResults.value = res.data.map((item) =>
			normalizeIncomingMessage(item as ChatMessageWithMeta),
		)
	}
	searchLoading.value = false
}

function onSearchInput() {
	if (searchTimeout) {
		clearTimeout(searchTimeout)
	}

	searchTimeout = setTimeout(() => {
		void runSearch()
	}, 220)
}

function toggleSearch() {
	searchOpen.value = !searchOpen.value
	if (!searchOpen.value) {
		searchQuery.value = ''
		searchResults.value = []
		searchLoading.value = false
		return
	}

	nextTick(() => {
		const input = document.querySelector<HTMLInputElement>('[data-chat-search-input="main"]')
		input?.focus()
	})
}

function toggleCurrentChatNotifications() {
	void toggleChatNotifications(chatId.value)
}

async function selectSearchResult(messageId: number) {
	await jumpToMessage(messageId)
	searchOpen.value = false
	searchQuery.value = ''
	searchResults.value = []
}

function onScroll() {
	if (!messagesContainer.value || loading.value || paging.value) return
	updateBottomState()
	if (messagesContainer.value.scrollTop < 100) {
		void loadOlderMessages()
		return
	}

	if (isNearBottom(220)) {
		void loadNewerMessages()
		scheduleMarkLoadedMessagesRead()
	}
}

function clearMessageFallback(clientMessageId: string | null | undefined) {
	if (!clientMessageId) return
	const timer = pendingFallbacks.get(clientMessageId)
	if (!timer) return
	clearTimeout(timer)
	pendingFallbacks.delete(clientMessageId)
}

function scheduleMessageFallback(
	clientMessageId: string,
	data: {
		content: string
		messageType: string
		replyToId?: number
		attachmentUrl?: string | null
		attachmentName?: string | null
		attachmentSize?: number | null
		mentions?: MentionPayload[]
	},
) {
	clearMessageFallback(clientMessageId)

	const timer = setTimeout(async () => {
		pendingFallbacks.delete(clientMessageId)

		const optimisticMessage = chatStore
			.getMessages(chatId.value)
			.find((item) => item.clientMessageId === clientMessageId)
		if (!optimisticMessage || optimisticMessage.deliveryStatus === 'sent') {
			return
		}

		const res = await api.post<ChatMessage>(`/api/chats/${chatId.value}/messages`, {
			chatId: chatId.value,
			clientMessageId,
			content: data.content,
			replyToId: data.replyToId,
			messageType: data.messageType,
			mentions: data.mentions,
			attachmentUrl: data.attachmentUrl ?? undefined,
			attachmentName: data.attachmentName ?? undefined,
			attachmentSize: data.attachmentSize ?? undefined,
		})

		if (res.success) {
			chatStore.ackMessage(chatId.value, clientMessageId, normalizeIncomingMessage(res.data))
			nextTick(() => scrollToBottom())
			return
		}

		chatStore.markMessageFailed(chatId.value, clientMessageId)
	}, MESSAGE_FALLBACK_DELAY_MS)

	pendingFallbacks.set(clientMessageId, timer)
}

function sendChatMessage(data: {
	content: string
	messageType: string
	replyToId?: number
	attachmentUrl?: string | null
	attachmentName?: string | null
	attachmentSize?: number | null
	mentions?: MentionPayload[]
}) {
	if (!canWriteMessages.value) return
	if (data.messageType !== 'text' && !canUploadAttachments.value) {
		uploadError.value = 'Вложения в этом чате отключены'
		return
	}
	const clientMessageId = makeClientMessageId()
	const optimisticMessageId = -Date.now()

	chatStore.addOptimisticMessage(chatId.value, {
		id: optimisticMessageId,
		chatId: chatId.value,
		userAuthUuid: auth.user?.authUuid ?? '',
		content: data.content,
		replyToId: replyTo.value?.id ?? data.replyToId ?? null,
		replyTo: (replyTo.value as ChatMessage | null) ?? null,
		clientMessageId,
		messageType: data.messageType as Message['messageType'],
		attachmentUrl: data.attachmentUrl ?? null,
		attachmentName: data.attachmentName ?? null,
		attachmentSize: data.attachmentSize ?? null,
		linkPreview: null,
		isDeleted: false,
		createdAt: new Date(),
		updatedAt: new Date(),
		reactions: [],
		mentions:
			data.mentions?.map((mention, index) => ({
				id: optimisticMessageId - index,
				messageId: optimisticMessageId,
				mentionedUserAuthUuid: mention.userAuthUuid,
				displayName: mention.displayName,
				startOffset: mention.start,
				endOffset: mention.end,
				createdAt: new Date(),
			})) ?? [],
		author: {
			fullName: auth.user?.fullName ?? null,
			username: auth.user?.username ?? null,
			avatarUrl: auth.user?.avatarUrl ?? null,
			chatAdminBadge: auth.user?.chatAdminBadge ?? false,
		},
		deliveryStatus: 'sending',
	})

	ws.send({
		type: 'send_message',
		chatId: chatId.value,
		clientMessageId,
		content: data.content,
		messageType: data.messageType,
		replyToId: replyTo.value?.id ?? data.replyToId,
		attachmentUrl: data.attachmentUrl,
		attachmentName: data.attachmentName,
		attachmentSize: data.attachmentSize,
		mentions: data.mentions,
	})
	scheduleMessageFallback(clientMessageId, {
		...data,
		replyToId: replyTo.value?.id ?? data.replyToId,
	})

	replyTo.value = null
	nextTick(() => scrollToBottom())
}

function onSendMessage(data: {
	content: string
	messageType: string
	replyToId?: number
	mentions?: MentionPayload[]
}) {
	sendChatMessage(data)
}

async function onScheduleMessage(data: {
	content: string
	scheduledAt: string
	mentions?: MentionPayload[]
}) {
	scheduledBusy.value = true
	const res = await api.post<ScheduledChatMessageItem>(`/api/chats/${chatId.value}/scheduled`, data)
	if (res.success) {
		await loadScheduledMessages(true)
	}
	scheduledBusy.value = false
}

async function onDeleteScheduledMessage(id: number) {
	scheduledBusy.value = true
	const res = await api.delete<{ id: number }>(`/api/chats/${chatId.value}/scheduled/${id}`)
	if (res.success) {
		scheduledMessages.value = scheduledMessages.value.filter((item) => item.id !== id)
		await loadScheduledMessages(true)
	}
	scheduledBusy.value = false
}

function onEdit(msg: Message) {
	replyTo.value = null
	editingMessage.value = msg
}

function onSaveEdit(data: { messageId: number; content: string; mentions?: MentionPayload[] }) {
	ws.send({
		type: 'edit_message',
		chatId: chatId.value,
		messageId: data.messageId,
		content: data.content,
		mentions: data.mentions,
	})
	chatStore.updateMessage(chatId.value, data.messageId, (message) => ({
		...message,
		content: data.content,
		updatedAt: new Date(),
		mentions:
			data.mentions?.map((mention, index) => ({
				id: message.id * 1000 + index,
				messageId: message.id,
				mentionedUserAuthUuid: mention.userAuthUuid,
				displayName: mention.displayName,
				startOffset: mention.start,
				endOffset: mention.end,
				createdAt: new Date(),
			})) ?? [],
	}))
	editingMessage.value = null
}

function onTyping() {
	if (!canWriteMessages.value) return
	const now = Date.now()
	if (now - lastTypingSentAt < TYPING_EMIT_COOLDOWN_MS) {
		return
	}
	lastTypingSentAt = now

	if (typingTimeout) {
		clearTimeout(typingTimeout)
	}

	ws.send({ type: 'typing', chatId: chatId.value })
	typingTimeout = setTimeout(() => {
		typingTimeout = null
	}, 3000)
}

function onReply(msg: Message) {
	if (!canWriteMessages.value) return
	replyTo.value = msg
}

function onReact(messageId: number, emoji: string) {
	if (!canUseReactions.value) return
	ws.send({ type: 'reaction', chatId: chatId.value, messageId, emoji })
}

async function onDeleteMessage(messageId: number) {
	const target = getChatMessageDeleteTarget(chatStore.getMessages(chatId.value), messageId)
	if (!target) return

	clearMessageFallback(target.clientMessageId)
	if (!target.persisted) {
		chatStore.removeMessage(messageId)
		return
	}

	const res = await api.delete<{ deleted: boolean }>(
		`/api/chats/${chatId.value}/messages/${messageId}`,
	)
	if (res.success) {
		chatStore.removeMessage(messageId)
		homeStore.invalidate()
	}
}

async function onAttachment(file: File) {
	if (!canWriteMessages.value || !canUploadAttachments.value) {
		uploadError.value = 'Вложения в этом чате отключены'
		return
	}
	uploading.value = true
	uploadError.value = ''
	uploadProgress.value = 0

	try {
		const result = await uploadChatAttachment(chatId.value, file, {
			onProgress: (progress) => {
				uploadProgress.value = progress.percent
			},
		})
		if (result.success) {
			sendChatMessage({
				content: '',
				messageType: result.data.messageType,
				attachmentUrl: result.data.url,
				attachmentName: result.data.name,
				attachmentSize: result.data.size,
			})
			return
		}
		uploadError.value = result.error.message
	} catch {
		uploadError.value = 'Загрузка прервалась. Попробуйте ещё раз.'
	} finally {
		uploading.value = false
		uploadProgress.value = null
	}
}

async function onVoiceRecorded(blob: Blob) {
	if (!canWriteMessages.value || !canUploadAttachments.value) return
	showVoiceRecorder.value = false
	const isOgg = blob.type.includes('ogg')
	const ext = isOgg ? 'ogg' : 'webm'
	await onAttachment(new File([blob], `voice_${Date.now()}.${ext}`, { type: blob.type }))
}

function handleSocketMessage(message: WSServerMessage) {
	switch (message.type) {
		case 'new_message': {
			if (message.message.chatId !== chatId.value) return
			const shouldStickToBottom =
				message.message.userAuthUuid === auth.user?.authUuid || isNearBottom()
			const normalized = normalizeIncomingMessage(message.message)
			chatStore.upsertMessage(chatId.value, normalized)
			if (shouldStickToBottom) {
				nextTick(() => {
					scrollToBottom()
					if (message.message.userAuthUuid !== auth.user?.authUuid) {
						scheduleMarkLoadedMessagesRead()
					}
				})
			} else if (message.message.userAuthUuid !== auth.user?.authUuid) {
				newMessagesBelowCount.value += 1
			}
			break
		}

		case 'message_ack': {
			if (message.message.chatId !== chatId.value) return
			clearMessageFallback(message.clientMessageId)
			chatStore.ackMessage(
				chatId.value,
				message.clientMessageId,
				normalizeIncomingMessage(message.message),
			)
			nextTick(() => scrollToBottom())
			break
		}

		case 'message_updated': {
			if (message.message.chatId !== chatId.value) return
			chatStore.upsertMessage(chatId.value, normalizeIncomingMessage(message.message))
			break
		}

		case 'typing': {
			if (message.chatId !== chatId.value || message.userId === auth.user?.authUuid) return
			chatStore.setTyping(chatId.value, message.userId, message.expiresAt)
			break
		}

		case 'presence': {
			if (message.chatId !== chatId.value) return
			chatStore.setPresence(chatId.value, message.onlineCount)
			break
		}

		case 'message_deleted': {
			if (message.chatId !== chatId.value) return
			chatStore.removeMessage(message.messageId)
			break
		}

		case 'reaction_update': {
			chatStore.updateReaction(message.messageId, message.userId, message.emoji, message.action)
			break
		}

		case 'error': {
			clearMessageFallback(message.clientMessageId)
			if (message.clientMessageId) {
				chatStore.markMessageFailed(chatId.value, message.clientMessageId)
			}
			break
		}
	}
}

onMounted(() => {
	unsubscribers.push(ws.on('new_message', handleSocketMessage))
	unsubscribers.push(ws.on('message_ack', handleSocketMessage))
	unsubscribers.push(ws.on('message_updated', handleSocketMessage))
	unsubscribers.push(ws.on('typing', handleSocketMessage))
	unsubscribers.push(ws.on('presence', handleSocketMessage))
	unsubscribers.push(ws.on('message_deleted', handleSocketMessage))
	unsubscribers.push(ws.on('reaction_update', handleSocketMessage))
	unsubscribers.push(ws.on('error', handleSocketMessage))

	ws.connect()
	ws.send({ type: 'join_room', chatId: chatId.value })
	void (async () => {
		await chatStore.fetchChats(true)
		await Promise.all([
			loadMentionCandidates(),
			loadInitialMessages(),
			loadScheduledMessages(),
			loadChatNotificationSettings(chatId.value),
		])
		await openRequestedMessageFromQuery()
	})()

	if (auth.isAdmin) {
		scheduledRefreshTimer = setInterval(() => {
			void loadScheduledMessages()
		}, 30_000)
	}
})

onUnmounted(() => {
	ws.send({ type: 'leave_room', chatId: chatId.value })
	for (const unsubscribe of unsubscribers) {
		unsubscribe()
	}
	for (const timer of pendingFallbacks.values()) {
		clearTimeout(timer)
	}
	pendingFallbacks.clear()

	if (typingTimeout) {
		clearTimeout(typingTimeout)
		typingTimeout = null
	}
	if (searchTimeout) {
		clearTimeout(searchTimeout)
		searchTimeout = null
	}
	if (markReadTimer) {
		clearTimeout(markReadTimer)
		markReadTimer = null
	}
	if (scheduledRefreshTimer) {
		clearInterval(scheduledRefreshTimer)
		scheduledRefreshTimer = null
	}
})

const messages = computed(() => chatStore.getMessages(chatId.value))
const typingUsers = computed(() => chatStore.getTypingUsers(chatId.value))
const onlineCount = computed(() => chatStore.getPresence(chatId.value))
const currentChat = computed(() => chatStore.chats.find((chat) => chat.id === chatId.value) ?? null)
const chatTitle = computed(() => currentChat.value?.name ?? 'Чат')
const chatAvatarUrl = computed(() => currentChat.value?.avatarUrl ?? null)
const chatScope = computed(() => 'Все участники')
const canManageChat = computed(() => auth.isAdmin)
const chatSettings = computed(() => currentChat.value?.settings ?? null)
const canWriteMessages = computed(
	() => canManageChat.value || chatSettings.value?.allowMemberMessages !== false,
)
const canUploadAttachments = computed(
	() => canManageChat.value || chatSettings.value?.allowAttachments !== false,
)
const canUseReactions = computed(
	() => canManageChat.value || chatSettings.value?.allowReactions !== false,
)
const composerDisabledText = computed(() =>
	currentChat.value?.type === 'channel' || chatSettings.value?.allowMemberMessages === false
		? 'Сообщения в этом чате закрыты'
		: 'Сообщения недоступны',
)
const scrollDownBadgeCount = computed(() =>
	Math.max(newMessagesBelowCount.value, currentChat.value?.unreadMessageCount ?? 0),
)
const showScrollDownButton = computed(
	() => !isAtBottom.value || hasNewer.value || scrollDownBadgeCount.value > 0,
)

function goHome() {
	void navigateTo('/app', { replace: true })
}
</script>

<template>
	<div class="club-chat-shell club-chat-shell--club">
		<header class="club-chat-header">
			<div class="club-chat-header-row">
				<button type="button" class="club-back-button" aria-label="Назад" @click="goHome">
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</button>
				<div v-if="chatAvatarUrl" class="club-chat-avatar">
					<img :src="chatAvatarUrl" :alt="chatTitle" class="h-full w-full object-cover" />
				</div>
				<div class="min-w-0 flex-1">
					<h1 class="club-chat-title">{{ chatTitle }}</h1>
					<p class="club-chat-subtitle">
						{{ chatScope }} · онлайн: <span class="club-chat-online-count">{{ onlineCount }}</span>
					</p>
				</div>
				<button
					type="button"
					:class="[
						'club-round-action',
						chatNotificationsEnabled ? 'is-notification-active' : 'is-notification-muted',
					]"
					:aria-label="chatNotificationsEnabled ? 'Отключить уведомления чата' : 'Включить уведомления чата'"
					:disabled="chatNotificationsLoading"
					@click="toggleCurrentChatNotifications"
				>
					<svg
						v-if="chatNotificationsEnabled"
						class="h-5 w-5"
						fill="none"
						stroke="currentColor"
						viewBox="0 0 24 24"
					>
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.4-1.4A2 2 0 0 1 18 14.2V11a6 6 0 1 0-12 0v3.2c0 .53-.21 1.04-.59 1.41L4 17h5m6 0a3 3 0 0 1-6 0" />
					</svg>
					<svg v-else class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 8a6 6 0 0 0-11.2-3M6 11v3.2c0 .53-.21 1.04-.59 1.41L4 17h10m1 0a3 3 0 0 1-5.2 1.9M3 3l18 18" />
					</svg>
					<span v-if="chatNotificationsEnabled" class="club-chat-notification-dot" aria-hidden="true" />
				</button>
				<button type="button" class="club-round-action" aria-label="Поиск по чату" @click="toggleSearch">
					<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21-4.35-4.35m1.85-5.15a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
					</svg>
				</button>
			</div>
			<div v-if="searchOpen" class="club-chat-search-panel">
				<div class="relative">
					<input
						data-chat-search-input="main"
						v-model="searchQuery"
						type="text"
						placeholder="Поиск по чату"
						class="club-chat-search-input"
						@input="onSearchInput"
					/>
					<button
						v-if="searchQuery"
						class="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--app-muted-soft)] transition hover:text-[var(--app-text)]"
						@click="searchQuery = ''; searchResults = []"
					>
						<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 18 6M6 6l12 12" />
						</svg>
					</button>
				</div>
				<div v-if="searchQuery" class="club-chat-results">
					<div v-if="searchLoading" class="px-4 py-3 text-sm text-[var(--app-muted)]">
						Ищу сообщения...
					</div>
					<button
						v-for="result in searchResults"
						:key="result.id"
						class="block w-full border-b border-[var(--app-border)] px-4 py-3 text-left transition last:border-b-0 hover:bg-[var(--app-bg)]"
						@click="selectSearchResult(result.id)"
					>
						<p class="line-clamp-2 text-sm text-[var(--app-text)]">
							{{ result.content || 'Сообщение без текста' }}
						</p>
						<p class="mt-1 text-xs text-[var(--app-muted-soft)]">
							{{ new Date(result.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) }}
						</p>
					</button>
					<div
						v-if="!searchLoading && searchResults.length === 0"
						class="px-4 py-3 text-sm text-[var(--app-muted)]"
					>
						Ничего не найдено
					</div>
				</div>
			</div>
		</header>
		<Transition name="chat-toast">
			<div v-if="chatNotificationsToast" class="club-chat-toast">
				{{ chatNotificationsToast }}
			</div>
		</Transition>

		<div ref="messagesContainer" class="club-chat-messages chat-pattern" @scroll="onScroll">
			<div v-if="loading" class="py-2">
				<AppScreenSkeleton variant="chat" />
			</div>

			<div v-else-if="messages.length === 0" class="club-chat-empty">
				<div>
					<svg class="mx-auto mb-3 h-14 w-14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
					</svg>
					<p class="text-sm font-semibold text-[var(--app-text)]">Сообщений пока нет</p>
					<p class="mt-1 text-xs">Начните общение первым.</p>
				</div>
			</div>

			<div v-else class="space-y-2">
				<ChatMessageBubble
					v-for="msg in messages"
					:key="getMessageRenderKey(msg)"
					v-memo="[msg, msg.deliveryStatus, canUseReactions, auth.user?.authUuid]"
					:message="msg"
					:is-own="msg.userAuthUuid === auth.user?.authUuid"
					:show-author="true"
					:can-react="canUseReactions"
					@reply="onReply"
					@edit="onEdit"
					@jump-to-reply="jumpToMessage"
					@react="onReact"
					@delete="onDeleteMessage"
				/>
			</div>
		</div>

		<Transition name="chat-scroll-down">
			<button
				v-if="showScrollDownButton"
				type="button"
				class="club-chat-scroll-down"
				aria-label="К последним сообщениям"
				@click="scrollToLatestMessages"
			>
				<span v-if="scrollDownBadgeCount > 0" class="club-chat-scroll-down-badge">
					{{ scrollDownBadgeCount > 99 ? '99+' : scrollDownBadgeCount }}
				</span>
				<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.35" d="m6 9 6 6 6-6" />
				</svg>
			</button>
		</Transition>

		<div class="club-chat-composer">
			<ChatTypingIndicator :users="typingUsers" />

			<div v-if="uploading" class="club-chat-uploading">
				Загрузка файла{{ uploadProgress == null ? '' : `: ${uploadProgress}%` }}
			</div>
			<div v-if="uploadError" class="club-chat-upload-error">
				{{ uploadError }}
			</div>

			<div v-if="showVoiceRecorder" class="px-4 py-2">
				<ChatVoiceRecorder @recorded="onVoiceRecorded" @cancel="showVoiceRecorder = false" />
			</div>

			<div v-else>
				<ChatMessageInput
					:reply-to="replyTo"
					:editing-message="editingMessage"
					:mention-candidates="mentionCandidates"
					:disabled="!canWriteMessages"
					:attachments-enabled="canUploadAttachments"
					:disabled-text="composerDisabledText"
					:can-schedule="auth.isAdmin"
					:scheduled-messages="scheduledMessages"
					:scheduled-loading="scheduledLoading || scheduledBusy"
					@send="onSendMessage"
					@schedule="onScheduleMessage"
					@delete-scheduled="onDeleteScheduledMessage"
					@save-edit="onSaveEdit"
					@typing="onTyping"
					@cancel-reply="replyTo = null"
					@cancel-edit="editingMessage = null"
					@attachment="onAttachment"
					@voice-start="showVoiceRecorder = true"
				/>
			</div>
			</div>
		</div>
	</template>
