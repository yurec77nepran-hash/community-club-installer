<script setup lang="ts">
definePageMeta({ middleware: ['auth'], keepalive: true })

const chatStore = useChatStore()
const chats = computed(() => chatStore.chats)
const loading = computed(() => chatStore.chatsLoading && chats.value.length === 0)

function getChatScope(accessRole: string) {
	void accessRole
	return 'Все участники'
}

onMounted(() => {
	void chatStore.fetchChats()
})
</script>

<template>
	<div class="club-page">
		<div class="club-section-head mb-2">
			<span class="club-section-line" />
			<p class="club-section-kicker">Общение</p>
		</div>
		<h1 class="club-section-title mb-2 text-2xl font-bold">Чаты клуба</h1>
		<p class="mb-5 text-sm leading-6 text-[var(--app-muted)]">
			Здесь проходят обсуждения, быстрые вопросы и клубные объявления.
		</p>

		<div v-if="loading" class="flex justify-center py-12">
			<div class="club-spinner" />
		</div>

		<div v-else-if="chats.length === 0" class="club-empty text-sm">
			Чаты пока недоступны.
		</div>

		<div v-else class="space-y-3">
			<NuxtLink
				v-for="chat in chats"
				:key="chat.id"
				:to="`/app/chats/${chat.id}`"
				class="club-list-row transition-transform"
			>
				<div class="club-icon-badge">
					<img
						v-if="chat.avatarUrl"
						:src="chat.avatarUrl"
						:alt="chat.name"
						class="h-full w-full rounded-[inherit] object-cover"
					/>
					<span v-else class="text-base font-bold">{{ chat.name.charAt(0) }}</span>
				</div>
				<div class="min-w-0 flex-1">
					<h2 class="truncate text-sm font-bold text-[var(--app-text-strong)]">{{ chat.name }}</h2>
					<p class="mt-1 truncate text-xs text-[var(--app-muted-soft)]">
						{{ chat.description || getChatScope(chat.accessRole) }}
					</p>
				</div>
				<div
					v-if="chat.unreadMessageCount > 0"
					class="flex h-6 min-w-6 items-center justify-center rounded-full bg-[var(--app-accent-wine)] px-1.5 text-[11px] font-semibold text-[var(--app-surface)] shadow-[0_8px_20px_color-mix(in_srgb,var(--app-accent-wine)_28%,transparent)]"
				>
					{{ chat.unreadMessageCount > 99 ? '99+' : chat.unreadMessageCount }}
				</div>
				<svg v-else class="h-5 w-5 flex-shrink-0 text-[var(--app-muted-soft)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m9 5 7 7-7 7" />
				</svg>
			</NuxtLink>
		</div>
	</div>
</template>
