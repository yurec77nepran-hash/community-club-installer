<script setup lang="ts">
import type { FeedPostItem } from '@community-club/shared/types'
import AppScreenSkeleton from '~/components/ui/AppScreenSkeleton.vue'

definePageMeta({ middleware: 'auth', keepalive: true })

type FeedSection = 'all'

const api = useApi()
const feedStore = useFeedStore()
const loadMoreSentinel = ref<HTMLElement | null>(null)
let observer: IntersectionObserver | null = null

const activeSection = ref<FeedSection>('all')

const state = computed(() => feedStore.sections[activeSection.value])
const items = computed(() => state.value.items)
const loading = computed(() => state.value.loading)
const loadingMore = computed(() => state.value.loadingMore)
const hasMore = computed(() => Boolean(state.value.nextCursor))

async function ensureLoaded(force = false) {
	await feedStore.fetchInitial(activeSection.value, force)
}

async function toggleReaction(postId: number, emoji: string) {
	const res = await api.post<{ action: string; item: FeedPostItem | null }>(
		`/api/feed/${postId}/reactions`,
		{ emoji },
	)
	if (res.success && res.data.item) {
		feedStore.replaceItem(res.data.item)
	}
}

onMounted(async () => {
	observer = new IntersectionObserver(
		(entries) => {
			if (entries.some((entry) => entry.isIntersecting) && hasMore.value) {
				void feedStore.loadMore(activeSection.value)
			}
		},
		{ threshold: 0.15 },
	)

	watch(
		loadMoreSentinel,
		(current, previous) => {
			if (previous) observer?.unobserve(previous)
			if (current) observer?.observe(current)
		},
		{ immediate: true },
	)

	await ensureLoaded()
})

onUnmounted(() => {
	observer?.disconnect()
	observer = null
})
</script>

<template>
	<div class="club-page feed-page md:px-6">
		<header class="feed-hero">
			<img
				:src="'/pwa-icon?size=512&format=webp'"
				alt=""
				width="512"
				height="512"
				loading="eager"
				fetchpriority="high"
				decoding="async"
				class="feed-hero-mark"
			/>
			<div>
				<h1 class="feed-title">Лента новостей</h1>
			</div>
		</header>

		<div v-if="loading" class="py-1">
			<AppScreenSkeleton variant="feed" :count="3" />
		</div>

		<div v-else-if="items.length === 0" class="feed-empty">
			Публикаций пока нет — новые материалы появятся здесь.
		</div>

		<div v-else class="space-y-5">
			<FeedPostCard
				v-for="item in items"
				:key="item.id"
				:item="item"
				:show-audience="false"
				@react="toggleReaction"
			/>

			<div v-if="loadingMore" class="flex justify-center py-4">
				<div class="h-7 w-7 animate-spin rounded-full border-2 border-[var(--app-border)] border-t-[var(--app-accent)]" />
			</div>

			<div v-if="hasMore" ref="loadMoreSentinel" class="h-8" />
		</div>
	</div>
</template>

<style scoped>
.feed-page {
	max-width: 46rem;
	margin: 0 auto;
}

.feed-hero {
	position: relative;
	display: grid;
	grid-template-columns: auto minmax(0, 1fr);
	gap: 0.9rem;
	align-items: center;
	min-height: 7.5rem;
	margin: 0.2rem 0 1.25rem;
	padding: 1rem;
	overflow: hidden;
	border: 1px solid color-mix(in srgb, var(--app-accent) 32%, var(--app-border));
	border-radius: 1.4rem;
	background:
		radial-gradient(circle at 92% 8%, color-mix(in srgb, var(--app-accent) 18%, transparent), transparent 34%),
		linear-gradient(135deg, var(--app-surface), var(--app-bg));
	box-shadow: inset 0 1px 0 rgb(255 255 255 / 0.96), var(--app-shadow-raised);
}

.feed-hero-mark {
	width: 4.2rem;
	height: 4.2rem;
	object-fit: contain;
	filter: drop-shadow(0 8px 15px color-mix(in srgb, var(--app-accent) 28%, transparent));
}

.feed-title {
	margin-top: 0.22rem;
	color: var(--app-text-strong);
	font-size: clamp(1.5rem, 5vw, 2rem);
	font-weight: 700;
	line-height: 1.1;
}

.feed-empty {
	border: 1px solid var(--app-border);
	border-radius: 1.2rem;
	background: var(--app-surface);
	padding: 2.5rem 1.2rem;
	color: var(--app-muted-soft);
	font-size: 0.9rem;
	text-align: center;
}

@media (prefers-reduced-motion: no-preference) {
	.feed-hero { animation: feed-reveal 0.36s ease-out both; }
}

@keyframes feed-reveal {
	from { opacity: 0; transform: translateY(8px); }
	to { opacity: 1; transform: translateY(0); }
}
</style>
