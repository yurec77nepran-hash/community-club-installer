<script setup lang="ts">
import type {
	HomeBannerItem,
	HomeExperienceSettings,
	HomeStoryItem,
	HomeStoryOverlay,
} from '@community-club/shared/types'
import { filterHomeBannersByChatAccess, getClubChatRoute } from '~/utils/chat-home-shortcuts'
import { preloadHomeBannerImages } from '~/utils/home-banner-preload'
import { withBuildVersion } from '~/utils/pwa-update'

definePageMeta({ keepalive: true })

const auth = useAuthStore()
const api = useApi()
const subscriptionStore = useSubscriptionStore()
const route = useRoute()
const chatStore = useChatStore()
const buildId = useRuntimeConfig().app.buildId

const defaultHomeExperience: HomeExperienceSettings = {
	mainBanner: {
		mediaKey: null,
		mediaUrl: null,
		alt: 'Club App — клуб цифровых решений',
	},
	banners: [
		{
			id: 'about',
			title: 'О клубе',
			subtitle: 'Что внутри',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			actionKind: 'stories',
			internalPath: '/app',
			externalUrl: '',
			requiresAuth: false,
			storiesEnabled: true,
		},
		{
			id: 'chat',
			title: 'Чат',
			subtitle: 'Общение',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			actionKind: 'internal',
			internalPath: '/app/chats',
			externalUrl: '',
			requiresAuth: true,
			storiesEnabled: false,
		},
		{
			id: 'support',
			title: 'Поддержка',
			subtitle: 'Помощь',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			actionKind: 'internal',
			internalPath: '/app/support',
			externalUrl: '',
			requiresAuth: true,
			storiesEnabled: false,
		},
		{
			id: 'referral',
			title: 'Рефералка',
			subtitle: 'Приглашения',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			actionKind: 'internal',
			internalPath: '/app/profile#referrals',
			externalUrl: '',
			requiresAuth: true,
			storiesEnabled: false,
		},
	],
	bannerShape: 'rounded',
	stories: [],
	highlights: [],
	sectionLayout: 'featured',
	sections: [
		{
			id: 'templates',
			title: 'Шаблоны',
			subtitle: 'Готовые цифровые решения',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			icon: 'cube',
			visualMode: 'icon',
			textMode: 'visible',
			actionKind: 'internal',
			internalPath: '/app/content/checklists',
			externalUrl: '',
			requiresAuth: false,
		},
		{
			id: 'lessons',
			title: 'Уроки',
			subtitle: 'Вайбкодинг и продажи',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			icon: 'book',
			visualMode: 'icon',
			textMode: 'visible',
			actionKind: 'internal',
			internalPath: '/app/content/courses',
			externalUrl: '',
			requiresAuth: false,
		},
		{
			id: 'tools',
			title: 'Инструменты',
			subtitle: 'Полезные инструменты',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			icon: 'wrench',
			visualMode: 'icon',
			textMode: 'visible',
			actionKind: 'internal',
			internalPath: '/app/content/other',
			externalUrl: '',
			requiresAuth: false,
		},
		{
			id: 'streams',
			title: 'Эфиры',
			subtitle: 'Эфиры клуба',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			icon: 'microphone',
			visualMode: 'icon',
			textMode: 'visible',
			actionKind: 'internal',
			internalPath: '/app/content/streams',
			externalUrl: '',
			requiresAuth: false,
		},
		{
			id: 'experts',
			title: 'От экспертов',
			subtitle: 'Шаблоны приглашённых экспертов',
			backgroundColor: 'var(--app-surface)',
			textColor: 'var(--app-text)',
			mediaKey: null,
			mediaUrl: null,
			icon: 'star',
			visualMode: 'icon',
			textMode: 'visible',
			actionKind: 'internal',
			internalPath: '/app/content/experts',
			externalUrl: '',
			requiresAuth: false,
		},
	],
	customPages: [],
}

const { data: homeExperience } = await useAsyncData(
	'app-home-experience-settings',
	async () => {
		const res = await api.get<HomeExperienceSettings>('/api/site-settings/home-experience')
		return res.success ? res.data : defaultHomeExperience
	},
	{ default: () => defaultHomeExperience },
)

const storyViewerOpen = ref(false)
const activeStoryIndex = ref(0)
const storyProgress = ref(0)
const homeChatsReady = ref(false)
const loadedStoryImages = ref(new Set<number>())
const storyWaitingForImage = ref(false)
let storyTimer: ReturnType<typeof setTimeout> | null = null
let storyProgressTimer: ReturnType<typeof setInterval> | null = null
let storyStartedAt = 0
let storyElapsedMs = 0
let storyTouchStartAt = 0
const STORY_TAP_THRESHOLD_MS = 250

const availableHomeChats = computed(() => (homeChatsReady.value ? chatStore.chats : []))
const homeBanners = computed(() =>
	filterHomeBannersByChatAccess(homeExperience.value.banners, availableHomeChats.value),
)
const bannerImageUrls = computed(() => [
	homeExperience.value.mainBanner.mediaUrl,
	...homeBanners.value.map((banner) => banner.mediaUrl),
])
const homeBannersReady = ref(false)
const failedHomeBannerUrls = ref<ReadonlySet<string>>(new Set())
let bannerPreloadGeneration = 0

watch(
	bannerImageUrls,
	async (urls) => {
		if (!import.meta.client) return
		const generation = ++bannerPreloadGeneration
		homeBannersReady.value = false
		failedHomeBannerUrls.value = new Set()
		const result = await preloadHomeBannerImages(urls)
		if (generation !== bannerPreloadGeneration) return
		failedHomeBannerUrls.value = result.failedUrls
		homeBannersReady.value = true
	},
	{ immediate: true, flush: 'sync' },
)

function canRenderHomeBannerImage(url: string | null) {
	return Boolean(url?.trim()) && !failedHomeBannerUrls.value.has(url?.trim() ?? '')
}

function markHomeBannerImageFailed(event: Event) {
	if (!(event.currentTarget instanceof HTMLImageElement)) return
	const image = event.currentTarget
	const failedUrls = [image.currentSrc, image.src, image.getAttribute('src')].flatMap((url) => {
		const normalizedUrl = url?.trim()
		return normalizedUrl ? [normalizedUrl] : []
	})
	failedHomeBannerUrls.value = new Set([...failedHomeBannerUrls.value, ...failedUrls])
}

const homeStories = computed<HomeStoryItem[]>(() => {
	const he = homeExperience.value
	if (he.highlights.length > 0) {
		return he.highlights.flatMap((highlight) => {
			const story = highlight.stories[0]
			return story?.mediaUrl ? [story] : []
		})
	}
	return he.stories
})
const homeSections = computed(() => homeExperience.value.sections)
const showJoinClub = computed(
	() => !auth.user || (!auth.isAdmin && !subscriptionStore.hasActiveSubscription),
)
const activeStory = computed(() => homeStories.value[activeStoryIndex.value] ?? null)
const isFinalClubStory = computed(() => activeStory.value?.id === 'club-story-10')
const materialCounts = ref<Record<string, number>>({})

function isMediaStory(
	story: HomeStoryItem,
): story is HomeStoryItem & { mediaUrl: string; layout: Exclude<HomeStoryItem['layout'], 'text'> } {
	return Boolean(story.mediaUrl) && story.layout !== 'text'
}

function storyCardStyle(story: HomeStoryItem) {
	if (isMediaStory(story)) {
		return { backgroundColor: story.backgroundColor, color: story.textColor }
	}
	return { backgroundColor: 'var(--app-surface)', color: 'var(--app-text)' }
}

const generatedSectionArtwork: Record<string, string> = {
	templates: withBuildVersion('/images/home/section-templates.webp', buildId),
	lessons: withBuildVersion('/images/home/section-lessons.webp', buildId),
	tools: withBuildVersion('/images/home/section-tools.webp', buildId),
	streams: withBuildVersion('/images/home/section-streams.webp', buildId),
	experts: withBuildVersion('/images/home/section-experts.webp', buildId),
}

function getBannerIcon(banner: HomeBannerItem) {
	const path = banner.internalPath
	if (banner.actionKind === 'stories' || banner.storiesEnabled || banner.id === 'about')
		return 'info'
	if (path.includes('/chats') || banner.id.includes('chat')) return 'chat'
	if (path.includes('/support') || banner.id.includes('support')) return 'support'
	if (path.includes('/profile') || banner.id.includes('referral')) return 'referral'
	if (path.includes('/feed') || banner.id.includes('feed')) return 'feed'
	if (path.includes('/materials') || banner.id.includes('materials')) return 'materials'
	return 'spark'
}

function requestAccessModal(intent: 'login' | 'pay' | null = null, redirect = route.fullPath) {
	if (!import.meta.client) return
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: {
				redirect,
				intent,
			},
		}),
	)
}

// Кнопка «Зайти в клуб»: показываем выбор «Код или оплата»
function openJoinChoice() {
	if (!import.meta.client) return
	window.dispatchEvent(
		new CustomEvent('club-access-required', {
			detail: {
				redirect: route.fullPath,
				variant: 'join',
			},
		}),
	)
}

function isBannerLocked(item: HomeBannerItem) {
	return item.requiresAuth && !auth.user
}

function isSectionLocked(item: HomeExperienceSettings['sections'][number]) {
	return item.requiresAuth && !auth.user
}

function openStories(index = 0) {
	if (homeStories.value.length === 0) return
	activeStoryIndex.value = Math.min(Math.max(index, 0), homeStories.value.length - 1)
	storyViewerOpen.value = true
	storyElapsedMs = 0
	preloadStory(activeStoryIndex.value)
	preloadStoryAhead()
	startStoryTimer()
}

function stopStoryTimer() {
	if (storyTimer) {
		clearTimeout(storyTimer)
		storyTimer = null
	}
	if (storyProgressTimer) {
		clearInterval(storyProgressTimer)
		storyProgressTimer = null
	}
}

function startStoryTimer() {
	stopStoryTimer()
	const current = activeStory.value
	if (!current) return

	// Картинка ещё грузится: держим спиннер и не запускаем отсчёт,
	// чтобы сторис не проскочила. Таймер стартует по @load картинки.
	if (isMediaStory(current) && !loadedStoryImages.value.has(activeStoryIndex.value)) {
		storyWaitingForImage.value = true
		storyElapsedMs = 0
		storyProgress.value = 0
		return
	}
	storyWaitingForImage.value = false

	const duration = current.durationMs || 5000
	storyElapsedMs = Math.min(storyElapsedMs, duration)
	storyStartedAt = Date.now() - storyElapsedMs
	storyProgress.value = Math.min(100, (storyElapsedMs / duration) * 100)
	storyProgressTimer = window.setInterval(() => {
		storyProgress.value = Math.min(100, ((Date.now() - storyStartedAt) / duration) * 100)
	}, 80)
	storyTimer = window.setTimeout(
		() => {
			nextStory()
		},
		Math.max(0, duration - storyElapsedMs),
	)
}

function pauseStoryTimer() {
	const current = activeStory.value
	if (!current) return
	const duration = current.durationMs || 5000
	storyElapsedMs = Math.min(duration, Math.max(0, Date.now() - storyStartedAt))
	stopStoryTimer()
}

function resumeStoryTimer() {
	if (storyViewerOpen.value && activeStory.value) {
		startStoryTimer()
	}
}

function handleStoryPointerDown() {
	storyTouchStartAt = Date.now()
	pauseStoryTimer()
}

function handleStoryPointerUp() {
	resumeStoryTimer()
}

function closeStories() {
	storyViewerOpen.value = false
	stopStoryTimer()
	storyTouchStartAt = 0
	storyWaitingForImage.value = false
}

function openStoryJoinChoice() {
	closeStories()
	openJoinChoice()
}

function nextStory() {
	if (activeStoryIndex.value >= homeStories.value.length - 1) {
		closeStories()
		return
	}
	storyElapsedMs = 0
	activeStoryIndex.value += 1
	preloadStoryAhead()
	startStoryTimer()
}

function previousStory() {
	if (activeStoryIndex.value <= 0) {
		startStoryTimer()
		return
	}
	storyElapsedMs = 0
	activeStoryIndex.value -= 1
	preloadStoryAhead()
	startStoryTimer()
}

function handleStorySurfaceClick(event: MouseEvent) {
	if (storyTouchStartAt !== 0 && Date.now() - storyTouchStartAt > STORY_TAP_THRESHOLD_MS) {
		return
	}
	const target = event.currentTarget as HTMLElement
	const rect = target.getBoundingClientRect()
	const x = event.clientX - rect.left
	if (x < rect.width / 2) previousStory()
	else nextStory()
}

function markStoryImageLoaded(index: number) {
	loadedStoryImages.value.add(index)
	// Картинка активной сторис догрузилась — начинаем отсчёт с полного времени
	if (index === activeStoryIndex.value && storyWaitingForImage.value && storyViewerOpen.value) {
		startStoryTimer()
	}
}

function markStoryImageError(index: number) {
	// Картинка не загрузилась — не зависаем на спиннере, продолжаем показ
	if (index === activeStoryIndex.value && storyWaitingForImage.value && storyViewerOpen.value) {
		storyWaitingForImage.value = false
		storyElapsedMs = 0
		startStoryTimer()
	}
}

const OVERLAY_SECTION_PATHS: Record<string, string> = {
	materials: '/app/materials',
	chats: '/app/chats',
	channel: '/app/channel',
	feed: '/app/feed',
	calendar: '/app/calendar',
	profile: '/app/profile',
	payment: '/app/payment',
	support: '/app/support',
}

function overlayStyle(overlay: HomeStoryOverlay) {
	const base: Record<string, string> = {
		left: `${overlay.x}%`,
		top: `${overlay.y}%`,
		width: `${overlay.width}%`,
	}
	if (typeof overlay.opacity === 'number') {
		base.opacity = String(overlay.opacity / 100)
	}
	if (overlay.type === 'text') {
		return {
			...base,
			color: overlay.textColor,
			fontSize: `${overlay.fontSize}px`,
			textAlign: overlay.align,
		}
	}
	if (overlay.type === 'image') {
		return { ...base, borderRadius: `${overlay.borderRadius || 0}px` }
	}
	return {
		...base,
		backgroundColor: overlay.backgroundColor,
		color: overlay.textColor,
		border: `${overlay.borderWidth || 0}px solid ${overlay.borderColor || 'transparent'}`,
		borderRadius: `${overlay.borderRadius || 0}px`,
	}
}

async function openClubChat() {
	const chats = await chatStore.fetchChats()
	const target = getClubChatRoute(chats)
	if (target === '/app/chats') return
	closeStories()
	await navigateTo(target)
}

function handleOverlayClick(overlay: HomeStoryOverlay) {
	if (overlay.action === 'link' && /^https?:\/\//i.test(overlay.linkUrl)) {
		window.open(overlay.linkUrl, '_blank', 'noopener,noreferrer')
		return
	}
	if (overlay.action === 'section' && overlay.section === 'chats') {
		stopStoryTimer()
		void openClubChat()
		return
	}
	if (overlay.action === 'section' && overlay.section && OVERLAY_SECTION_PATHS[overlay.section]) {
		stopStoryTimer()
		void navigateTo(OVERLAY_SECTION_PATHS[overlay.section])
	}
}

const isActiveStoryImageLoading = computed(() => {
	const story = activeStory.value
	if (!story || !isMediaStory(story)) return false
	return !loadedStoryImages.value.has(activeStoryIndex.value)
})

const storyImageCache = new Set<string>()

function preloadStory(index: number) {
	const story = homeStories.value[index]
	if (story?.mediaUrl) preloadStoryImage(story.mediaUrl)
}

function preloadStoryAhead() {
	preloadStory(activeStoryIndex.value + 1)
	preloadStory(activeStoryIndex.value + 2)
}

function preloadStoryImage(url: string) {
	if (storyImageCache.has(url)) return
	storyImageCache.add(url)
	const image = new Image()
	image.src = url
}

function handleBannerClick(event: MouseEvent, item: HomeBannerItem) {
	if (isBannerLocked(item)) {
		event.preventDefault()
		requestAccessModal()
		return
	}

	if (item.actionKind === 'stories' || item.storiesEnabled) {
		event.preventDefault()
		openStories()
		return
	}

	if (item.actionKind === 'internal' && item.internalPath === '/app/chats') {
		event.preventDefault()
		void openClubChat()
		return
	}

	if (item.actionKind === 'external' && item.externalUrl) {
		event.preventDefault()
		window.open(item.externalUrl, '_blank', 'noopener,noreferrer')
	}
}

function getBannerTarget(item: HomeBannerItem) {
	if (item.actionKind === 'internal') return item.internalPath || '/app'
	return route.fullPath || '/app'
}

function getSectionTarget(item: HomeExperienceSettings['sections'][number]) {
	if (item.actionKind === 'internal') return item.internalPath || '/app'
	return route.fullPath || '/app'
}

function getSectionArtwork(item: HomeExperienceSettings['sections'][number]) {
	return item.mediaUrl || generatedSectionArtwork[item.id] || null
}

const sectionMaterialTypes: Record<string, string> = {
	templates: 'checklists',
	lessons: 'courses',
	tools: 'other',
	streams: 'streams',
	experts: 'experts',
}

function getSectionCount(sectionId: string) {
	const type = sectionMaterialTypes[sectionId]
	return type ? materialCounts.value[type] : undefined
}

function formatMaterialCount(count: number) {
	if (count === 0) return 'Смотреть'

	const last = count % 10
	const lastTwo = count % 100
	const noun =
		last === 1 && lastTwo !== 11
			? 'материал'
			: last >= 2 && last <= 4 && (lastTwo < 12 || lastTwo > 14)
				? 'материала'
				: 'материалов'
	return `${count} ${noun}`
}

function handleSectionClick(event: MouseEvent, item: HomeExperienceSettings['sections'][number]) {
	if (isSectionLocked(item)) {
		event.preventDefault()
		requestAccessModal()
		return
	}
	if (item.actionKind === 'external' && item.externalUrl) {
		event.preventDefault()
		window.open(item.externalUrl, '_blank', 'noopener,noreferrer')
	}
}

onMounted(async () => {
	await auth.restoreSession()
	void api
		.get<Record<string, number>>(
			auth.user ? '/api/materials/stats' : '/api/materials/public-preview/stats',
			{ authRedirect: false },
		)
		.then((stats) => {
			if (stats.success) materialCounts.value = stats.data
		})
	if (auth.user) {
		chatStore.setChats([])
		await chatStore.fetchChats(true)
		homeChatsReady.value = true
	}
	if (auth.user && !auth.isAdmin) {
		subscriptionStore.hydrateSnapshot()
		await subscriptionStore.fetchSubscription()
	}
})

onUnmounted(() => {
	stopStoryTimer()
})
</script>

<template>
	<div class="home-shell">
		<div class="home-aurora" />
		<div class="home-dust home-dust-top" />
		<div class="home-dust home-dust-bottom" />

		<div class="home-flow">
			<div v-if="homeBannersReady" class="flex flex-col gap-[var(--home-section-gap)]">
				<section class="home-banners">
					<NuxtLink
						v-for="banner in homeBanners"
						:key="banner.id"
						:to="getBannerTarget(banner)"
						class="home-banner-card"
						:class="[`home-banner-card-${homeExperience.bannerShape}`, `home-banner-card-${banner.id}`]"
						:style="{ backgroundColor: banner.backgroundColor, color: banner.textColor }"
						@click="handleBannerClick($event, banner)"
					>
						<img
							v-if="canRenderHomeBannerImage(banner.mediaUrl)"
							:src="banner.mediaUrl ?? undefined"
							:alt="banner.title"
							class="home-banner-image"
							@error="markHomeBannerImageFailed"
						/>
					<div class="home-banner-shade" />
					<div class="home-banner-icon" aria-hidden="true">
						<svg v-if="getBannerIcon(banner) === 'chat'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M7.5 16.5 4 20v-4.7A7.2 7.2 0 0 1 3 11.6C3 7.4 7 4 12 4s9 3.4 9 7.6-4 7.6-9 7.6a10.4 10.4 0 0 1-4.5-1" />
						</svg>
						<svg v-else-if="getBannerIcon(banner) === 'feed'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M5 5.5A2.5 2.5 0 0 1 7.5 3H14l5 5v10.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 5 18.5v-13Z" />
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M14 3v5h5M8.5 13h7M8.5 17h4.5" />
						</svg>
						<svg v-else-if="getBannerIcon(banner) === 'materials'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M5 6.5A2.5 2.5 0 0 1 7.5 4H19v14H7.5A2.5 2.5 0 0 0 5 20.5v-14Z" />
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M5 20.5A2.5 2.5 0 0 1 7.5 18H19M9 8h6M9 11.5h5" />
						</svg>
						<svg v-else-if="getBannerIcon(banner) === 'info'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 11.2v5" />
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M12 7.75h.01" />
						</svg>
						<svg v-else-if="getBannerIcon(banner) === 'support'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M5 13a7 7 0 0 1 14 0v4.5a2 2 0 0 1-2 2H15" />
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M5 13H4a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h1m14-5h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1M12 21h3" />
						</svg>
						<svg v-else-if="getBannerIcon(banner) === 'referral'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M15.5 20v-1.5a3.5 3.5 0 0 0-3.5-3.5h-4a3.5 3.5 0 0 0-3.5 3.5V20m10-8.5a3 3 0 1 0 0-6m5.5 14v-1a3 3 0 0 0-3-3h-.5M10 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
						</svg>
						<svg v-else fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.85" d="M12 3l1.7 5.1L19 10l-5.3 1.9L12 17l-1.7-5.1L5 10l5.3-1.9L12 3Z" />
						</svg>
					</div>
					<div v-if="isBannerLocked(banner)" class="home-banner-lock">
						<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
						</svg>
					</div>
					<div class="home-banner-content">
						<h2>{{ banner.title }}</h2>
					</div>
					</NuxtLink>
				</section>

				<button
					type="button"
					class="home-club-story-banner aspect-[1697/927]"
					aria-label="Открыть истории о клубе"
					@click="openStories()"
				>
					<div class="home-club-story-banner__placeholder" aria-hidden="true">
						<span class="home-club-story-banner__placeholder-title">Главный баннер</span>
						<span>1697 × 927 px</span>
					</div>
					<img
						v-if="canRenderHomeBannerImage(homeExperience.mainBanner.mediaUrl)"
						:src="homeExperience.mainBanner.mediaUrl ?? undefined"
						:alt="homeExperience.mainBanner.alt"
						class="home-club-story-banner__image"
						width="1697"
						height="927"
						fetchpriority="high"
						@error="markHomeBannerImageFailed"
					/>
				</button>
			</div>
			<div
				v-else
				class="flex flex-col gap-[var(--home-section-gap)]"
				role="status"
				aria-label="Загружаем баннеры"
			>
				<section class="home-banners" aria-hidden="true">
					<div
						v-for="banner in homeBanners"
						:key="banner.id"
						class="home-banner-card app-skeleton-box"
						:class="`home-banner-card-${homeExperience.bannerShape}`"
					/>
				</section>
				<div class="home-club-story-banner app-skeleton-box aspect-[1697/927]" aria-hidden="true" />
			</div>

			<button v-if="showJoinClub" type="button" class="home-join-club" @click="openJoinChoice">
				<span class="home-join-club__title">ЗАЙТИ В КЛУБ</span>
				<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h14m-6-6 6 6-6 6" />
				</svg>
			</button>

			<section class="home-sections">
				<NuxtLink
					v-for="(section, index) in homeSections"
					:key="section.id"
					:to="getSectionTarget(section)"
					class="home-section-tile"
					:class="[
						`home-section-tile-${index}`,
						`home-section-tile-${section.id}`,
						{ 'home-section-tile-locked': isSectionLocked(section) },
					]"
					:style="{ backgroundColor: section.backgroundColor, color: section.textColor }"
					@click="handleSectionClick($event, section)"
				>
					<img
						v-if="getSectionArtwork(section)"
						:src="getSectionArtwork(section) ?? undefined"
						:alt="section.title"
						class="home-section-image"
					/>
					<div class="home-section-glow" />
					<div v-if="isSectionLocked(section)" class="home-section-lock">
						<svg class="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.4" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
						</svg>
					</div>
					<div v-if="section.icon" class="home-section-icon">
						<svg v-if="section.icon === 'cube'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Zm0 9 8-4.5M12 12 4 7.5M12 12v9" />
						</svg>
						<svg v-else-if="section.icon === 'book'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.5 5.5A2.5 2.5 0 0 1 6 3h4a3 3 0 0 1 2 1v16a3 3 0 0 0-2-1H6a2.5 2.5 0 0 0-2.5 2v-15.5ZM20.5 5.5A2.5 2.5 0 0 0 18 3h-4a3 3 0 0 0-2 1v16a3 3 0 0 1 2-1h4a2.5 2.5 0 0 1 2.5 2v-15.5Z" />
						</svg>
						<svg v-else-if="section.icon === 'wrench'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z" />
						</svg>
						<svg v-else-if="section.icon === 'microphone'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<rect width="6.5" height="11" x="8.75" y="3" rx="3.25" stroke-width="2" />
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7" />
						</svg>
						<svg v-else-if="section.icon === 'star'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" />
						</svg>
						<svg v-else-if="section.icon === 'video'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 10l4.2-2.1A1 1 0 0121 8.8v6.4a1 1 0 01-1.8.9L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
						</svg>
						<svg v-else-if="section.icon === 'check'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M9 12l2 2 4-4M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z" />
						</svg>
						<svg v-else-if="section.icon === 'play'" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M8 5v14l11-7L8 5z" />
						</svg>
						<svg v-else fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M12 3l1.7 5.1L19 10l-5.3 1.9L12 17l-1.7-5.1L5 10l5.3-1.9L12 3z" />
						</svg>
					</div>
					<h3 v-if="section.textMode === 'visible'" class="home-section-title">{{ section.title }}</h3>
					<p v-if="section.textMode === 'visible' && section.subtitle" class="home-section-subtitle">
						{{ section.subtitle }}
					</p>
					<span v-if="sectionMaterialTypes[section.id]" class="home-section-count">
						{{ formatMaterialCount(getSectionCount(section.id) ?? 0) }}
						<span aria-hidden="true">→</span>
					</span>
				</NuxtLink>
			</section>
		</div>

		<Transition name="home-story">
			<div v-if="storyViewerOpen && activeStory" class="home-story-layer">
				<section
						class="home-story-card"
						:class="{ 'home-story-card-media': isMediaStory(activeStory) }"
						:style="storyCardStyle(activeStory)"
						@click="handleStorySurfaceClick"
						@pointerdown="handleStoryPointerDown"
						@pointerup="handleStoryPointerUp"
						@pointercancel="handleStoryPointerUp"
						@pointerleave="handleStoryPointerUp"
					>
					<div class="home-story-progress">
						<span
							v-for="(story, index) in homeStories"
							:key="story.id"
							class="home-story-progress-track"
						>
							<span
								class="home-story-progress-fill"
								:style="{ width: index < activeStoryIndex ? '100%' : index === activeStoryIndex ? `${storyProgress}%` : '0%' }"
							/>
						</span>
					</div>
					<button type="button" class="home-story-close" aria-label="Закрыть" @click.stop="closeStories">
						<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 6l12 12M18 6L6 18" />
						</svg>
					</button>
					<img
						v-if="isMediaStory(activeStory)"
						:src="activeStory.mediaUrl"
						:alt="activeStory.title || `Хайлайт ${activeStoryIndex + 1}`"
						class="home-story-image"
						@load="markStoryImageLoaded(activeStoryIndex)"
						@error="markStoryImageError(activeStoryIndex)"
					/>
					<div v-if="isActiveStoryImageLoading" class="home-story-loader" aria-hidden="true">
						<span class="home-story-loader-spinner" />
					</div>
					<div
						v-if="activeStory.text"
						class="home-story-content"
						:class="activeStory.layout === 'imageText' ? 'home-story-content-bottom' : ''"
					>
						<p>{{ activeStory.text }}</p>
					</div>
					<div
						v-if="activeStory.overlays && activeStory.overlays.length"
						class="home-story-overlays"
						@click.stop
					>
						<div
							v-for="overlay in activeStory.overlays"
							:key="overlay.id"
							class="home-story-overlay"
							:class="`home-story-overlay-${overlay.type}`"
							:style="overlayStyle(overlay)"
							@click="handleOverlayClick(overlay)"
						>
							<p v-if="overlay.type === 'text'" class="home-story-overlay-text">
								{{ overlay.text }}
							</p>
							<img v-else-if="overlay.type === 'image'" :src="overlay.mediaUrl ?? undefined" alt="" />
							<span v-else-if="overlay.type === 'button'">{{ overlay.label }}</span>
						</div>
					</div>
					<div v-if="isFinalClubStory" class="home-story-actions" @click.stop>
						<button
							type="button"
							class="home-story-join-button"
							@click="openStoryJoinChoice"
						>
							Войти в клуб
						</button>
					</div>
				</section>
			</div>
		</Transition>
	</div>
</template>

<style scoped>
.home-shell {
	position: relative;
	overflow: hidden;
	min-height: calc(100dvh - var(--bottom-dock-reserve, 5rem));
	background:
		radial-gradient(circle at 88% 4%, color-mix(in srgb, var(--app-accent) 10%, transparent), transparent 30%),
		linear-gradient(180deg, var(--app-bg), var(--app-bg-deep));
	padding: calc(env(safe-area-inset-top, 0px) + 0.8rem) 0.75rem 1rem;
	border-radius: 0;
	--home-section-gap: 1rem;
}

.home-flow {
	position: relative;
	z-index: 1;
	display: flex;
	flex-direction: column;
	gap: var(--home-section-gap);
}

.home-aurora {
	display: none;
}

.home-dust {
	display: none;
}

.home-dust-top {
	top: 5rem;
	right: -5.5rem;
}

.home-dust-bottom {
	bottom: 10rem;
	left: -6rem;
}

.home-banners {
	position: relative;
	z-index: 1;
	display: flex;
	justify-content: space-between;
	max-width: 64rem;
	gap: 0;
	overflow-x: auto;
	padding: 0.1rem 0 1.8rem;
	scroll-snap-type: x proximity;
	scrollbar-width: none;
	-webkit-overflow-scrolling: touch;
}

.home-banners::-webkit-scrollbar {
	display: none;
}

.home-banner-card {
	position: relative;
	display: flex;
	flex: 0 0 clamp(3.95rem, 19vw, 4.7rem);
	width: clamp(3.95rem, 19vw, 4.7rem);
	aspect-ratio: 1 / 1;
	align-items: flex-end;
	justify-content: center;
	overflow: hidden;
	border: 1px solid var(--banner-border, var(--app-border));
	background: var(--banner-fill, var(--app-surface)) !important;
	color: var(--banner-accent, var(--app-text)) !important;
	text-decoration: none;
	scroll-snap-align: start;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft), 0 0 18px var(--banner-glow, transparent);
	transition:
		transform 0.18s ease,
		border-color 0.18s ease;
}

.home-banner-card-about {
	--banner-accent: var(--app-accent-strong);
	--banner-fill: color-mix(in srgb, var(--app-accent) 10%, var(--app-surface));
	--banner-border: color-mix(in srgb, var(--app-accent) 34%, var(--app-border));
	--banner-glow: color-mix(in srgb, var(--app-accent) 12%, transparent);
}

.home-banner-card-chat {
	--banner-accent: var(--app-accent-wine);
	--banner-fill: color-mix(in srgb, var(--app-accent-wine) 9%, var(--app-surface));
	--banner-border: color-mix(in srgb, var(--app-accent-wine) 30%, var(--app-border));
	--banner-glow: color-mix(in srgb, var(--app-accent-wine) 11%, transparent);
}

.home-banner-card-support {
	--banner-accent: var(--app-accent-slate);
	--banner-fill: color-mix(in srgb, var(--app-accent-slate) 9%, var(--app-surface));
	--banner-border: color-mix(in srgb, var(--app-accent-slate) 30%, var(--app-border));
	--banner-glow: color-mix(in srgb, var(--app-accent-slate) 11%, transparent);
}

.home-banner-card-referral {
	--banner-accent: var(--app-text-strong);
	--banner-fill: color-mix(in srgb, var(--app-text) 6%, var(--app-surface));
	--banner-border: color-mix(in srgb, var(--app-text) 20%, var(--app-border));
	--banner-glow: color-mix(in srgb, var(--app-text) 8%, transparent);
}

.home-banner-card-rounded {
	border-radius: 0.9rem;
}

.home-banner-card-circle {
	border-radius: 999px;
	overflow: visible;
	border-color: transparent;
	background: var(--banner-fill, var(--app-surface)) !important;
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-soft), 0 0 14px var(--banner-glow, transparent);
}

.home-banner-card-circle .home-banner-icon {
	display: flex;
}

.home-banner-card-circle .home-banner-lock {
	display: none;
}

.home-banner-card-circle .home-banner-shade {
	inset: 1px;
	background: radial-gradient(circle at 34% 20%, rgb(255 255 255 / 0.92), transparent 50%);
	border-radius: inherit;
}

.home-banner-card-circle .home-banner-content {
	position: absolute;
	top: calc(100% + 0.56rem);
	left: 0;
	width: 100%;
	min-height: 0;
	margin: 0;
	padding: 0;
	text-align: center;
}

.home-banner-card-circle .home-banner-content h2 {
	display: block;
	overflow: visible;
	color: var(--app-text);
	font-size: 0.57rem;
	font-weight: 700;
	letter-spacing: 0.025em;
	line-height: 1.18;
	max-width: 4.1rem;
	margin-inline: auto;
	text-align: center;
	text-transform: uppercase;
	-webkit-line-clamp: unset;
}

.home-banner-card-circle .home-banner-icon {
	top: 50%;
	left: 50%;
	width: 2.75rem;
	height: 2.75rem;
	border: 0;
	background: transparent;
	color: var(--banner-accent, var(--app-accent-strong));
	transform: translate(-50%, -50%);
	backdrop-filter: none;
	filter: drop-shadow(0 0 4px var(--banner-glow, transparent));
}

.home-banner-card-circle .home-banner-icon svg {
	width: 1.8rem;
	height: 1.8rem;
}

.home-banner-card:active {
	transform: scale(0.985);
}

.home-banner-card:hover {
	border-color: var(--banner-accent, var(--app-border-strong));
}

.home-club-story-banner {
	position: relative;
	display: block;
	width: 100%;
	max-width: 34rem;
	padding: 0;
	overflow: hidden;
	border: 0;
	border-radius: 1rem;
	background: transparent;
	box-shadow: none;
	cursor: pointer;
	transition: transform 0.18s ease;
}

.home-club-story-banner__placeholder {
	position: absolute;
	inset: 5%;
	display: grid;
	place-content: center;
	border: 1px solid var(--app-border);
	background:
		linear-gradient(to top right, transparent calc(50% - 0.5px), var(--app-border) 50%, transparent calc(50% + 0.5px)),
		linear-gradient(to bottom right, transparent calc(50% - 0.5px), var(--app-border) 50%, transparent calc(50% + 0.5px));
	color: var(--app-muted);
	line-height: 1.5;
	pointer-events: none;
	text-align: center;
}

.home-club-story-banner__placeholder span {
	position: relative;
	z-index: 1;
	padding-inline: 0.25rem;
	background: var(--app-bg);
}

.home-club-story-banner__placeholder-title {
	color: var(--app-text);
	font-weight: 600;
}

.home-club-story-banner__image {
	position: absolute;
	inset: 0;
	z-index: 2;
	display: block;
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.home-club-story-banner:hover {
	border-color: transparent;
	box-shadow: none;
}

.home-club-story-banner:active {
	transform: scale(0.99);
}

.home-club-story-banner:focus-visible {
	outline: 2px solid var(--app-accent);
	outline-offset: 0.18rem;
}

.home-join-club { position: relative; display: grid; grid-template-columns: 1fr auto; align-items: center; gap: 0.8rem; width: 100%; max-width: 34rem; min-height: 5.2rem; overflow: hidden; border: 1px solid var(--app-border-strong); border-radius: 1rem; padding: 1rem 1.1rem; background: linear-gradient(112deg, var(--app-surface), color-mix(in srgb, var(--app-accent) 12%, var(--app-bg)) 66%, var(--app-surface)); box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-raised); color: var(--app-text-strong); text-align: left; text-decoration: none; transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease; }
.home-join-club::after { position: absolute; right: -1.5rem; top: -4.5rem; width: 9rem; height: 9rem; border: 1px solid color-mix(in srgb, var(--app-accent) 28%, transparent); border-radius: 50%; box-shadow: 0 0 3rem color-mix(in srgb, var(--app-accent) 14%, transparent); content: ''; }
.home-join-club__title { grid-column: 1; justify-self: start; font-size: 0.96rem; font-weight: 800; letter-spacing: 0.06em; }
.home-join-club svg { grid-column: 2; width: 1.35rem; height: 1.35rem; color: var(--app-accent-strong); }
.home-join-club:hover { border-color: var(--app-accent); box-shadow: inset 0 1px rgb(255 255 255 / 0.96), var(--app-shadow-raised), 0 0 1.8rem color-mix(in srgb, var(--app-accent) 12%, transparent); }
.home-join-club:active { transform: scale(0.99); }
.home-join-club:focus-visible { outline: 2px solid var(--app-accent); outline-offset: 0.18rem; }

.home-banner-image,
.home-banner-shade {
	position: absolute;
	inset: 0;
}

.home-banner-image {
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.home-banner-shade {
	background: radial-gradient(circle at 86% 18%, rgb(255 255 255 / 0.72), transparent 34%);
}

.home-banner-card:has(.home-banner-image) .home-banner-shade {
	background: linear-gradient(180deg, rgb(0 0 0 / 0.08), rgb(0 0 0 / 0.62)), radial-gradient(circle at 86% 18%, rgb(255 255 255 / 0.18), transparent 28%);
}

.home-banner-card:has(.home-banner-image) .home-banner-content,
.home-banner-card:has(.home-banner-image) .home-banner-icon {
	color: white;
}

.home-banner-lock {
	position: absolute;
	top: 0.4rem;
	right: 0.4rem;
	z-index: 2;
	display: flex;
	width: 1.32rem;
	height: 1.32rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border);
	border-radius: 999px;
	background: rgb(255 255 255 / 0.72);
	color: var(--app-text);
	backdrop-filter: blur(12px);
}

.home-banner-icon {
	position: absolute;
	top: 0.42rem;
	left: 0.42rem;
	z-index: 2;
	display: flex;
	width: 1.6rem;
	height: 1.6rem;
	align-items: center;
	justify-content: center;
	border: 1px solid var(--app-border);
	border-radius: 999px;
	background: rgb(255 255 255 / 0.68);
	color: var(--banner-accent, var(--app-muted));
	backdrop-filter: blur(12px);
}

.home-banner-icon svg {
	width: 0.94rem;
	height: 0.94rem;
}

.home-banner-content {
	position: relative;
	z-index: 1;
	display: flex;
	width: 100%;
	min-height: 2.25rem;
	align-items: flex-end;
	justify-content: flex-start;
	padding: 0.48rem 0.46rem 0.5rem;
	text-align: left;
}

.home-banner-content h2 {
	margin: 0;
	display: -webkit-box;
	overflow: hidden;
	font-size: 0.64rem;
	font-weight: 700;
	letter-spacing: 0;
	line-height: 1.05;
	overflow-wrap: normal;
	text-wrap: balance;
	-webkit-box-orient: vertical;
	-webkit-line-clamp: 2;
	word-break: normal;
}

.home-sections {
	--orbit-radius: clamp(8rem, 38vw, 10.75rem);
	position: relative;
	z-index: 1;
	isolation: isolate;
	width: 100%;
	max-width: 34rem;
	height: clamp(26rem, 108vw, 33rem);
}

.home-sections::before {
	content: '';
	position: absolute;
	inset: 2% -3%;
	z-index: 0;
	pointer-events: none;
	border-radius: 50%;
	background: repeating-radial-gradient(
		circle at center,
		transparent 0 4.8rem,
		color-mix(in srgb, var(--app-accent-strong) 42%, transparent) 4.85rem 4.93rem,
		transparent 4.98rem 6.35rem
	);
	-webkit-mask-image: repeating-conic-gradient(from -8deg, #000 0 9deg, transparent 10deg 16deg);
	mask-image: repeating-conic-gradient(from -8deg, #000 0 9deg, transparent 10deg 16deg);
	opacity: 0.94;
	animation: home-orbit-drift 28s linear infinite;
}

.home-sections::after {
	content: '';
	position: absolute;
	inset: 0;
	z-index: 1;
	pointer-events: none;
	background:
		radial-gradient(circle at 50% 11%, color-mix(in srgb, var(--app-accent) 58%, var(--app-surface)) 0 0.22rem, transparent 0.27rem),
		radial-gradient(circle at 84% 35%, var(--app-accent) 0 0.17rem, transparent 0.22rem),
		radial-gradient(circle at 68% 82%, color-mix(in srgb, var(--app-accent) 38%, var(--app-surface)) 0 0.18rem, transparent 0.23rem),
		radial-gradient(circle at 20% 70%, color-mix(in srgb, var(--app-accent-strong) 72%, var(--app-surface)) 0 0.15rem, transparent 0.2rem),
		radial-gradient(circle at 18% 33%, color-mix(in srgb, var(--app-accent) 76%, var(--app-surface)) 0 0.14rem, transparent 0.19rem);
	filter: drop-shadow(0 0 0.35rem color-mix(in srgb, var(--app-accent) 78%, transparent));
}

.home-orbit-core {
	position: absolute;
	top: 50%;
	left: 50%;
	z-index: 2;
	display: flex;
	width: clamp(7.5rem, 33vw, 10.5rem);
	aspect-ratio: 1;
	align-items: center;
	justify-content: center;
	border: 1px solid color-mix(in srgb, var(--app-accent) 55%, transparent);
	border-radius: 50%;
	background: var(--app-surface);
	box-shadow:
		inset 0 0 1.4rem color-mix(in srgb, var(--app-accent) 8%, transparent),
		0 0 1.2rem color-mix(in srgb, var(--app-accent) 18%, transparent),
		0 0 3.2rem color-mix(in srgb, var(--app-accent-strong) 10%, transparent);
	transform: translate(-50%, -50%);
}

.home-orbit-core::before {
	display: none;
}

@keyframes home-orbit-drift {
	to {
		transform: rotate(1turn);
	}
}

@media (prefers-reduced-motion: reduce) {
	.home-sections::before {
		animation: none;
	}
}

.home-orbit-core-emblem {
	position: relative;
	z-index: 1;
	width: 88%;
	height: 88%;
	object-fit: contain;
	filter: drop-shadow(0 0 0.8rem color-mix(in srgb, var(--app-accent) 36%, transparent));
}

.home-section-tile {
	--orbit-color: var(--app-accent-violet);
	position: absolute;
	top: 50%;
	left: 50%;
	z-index: 3;
	display: flex;
	width: clamp(3.8rem, 18vw, 4.75rem);
	min-height: 0;
	flex-direction: column;
	align-items: center;
	padding: 0;
	overflow: visible;
	border: 0;
	border-radius: 0;
	background: transparent !important;
	color: var(--app-text) !important;
	text-decoration: none;
	isolation: isolate;
	top: var(--orbit-top);
	left: var(--orbit-left);
	transform: translate(-50%, -50%);
}

.home-section-tile-templates,
.home-section-tile-streams,
.home-section-tile-experts {
	--orbit-radius: clamp(10rem, 47vw, 12rem);
}

.home-section-tile-0 {
	--orbit-color: var(--app-accent-violet);
}

.home-section-tile-1 {
	--orbit-color: var(--app-accent-blue);
}

.home-section-tile-2 {
	--orbit-color: var(--app-accent-amber);
}

.home-section-tile-3,
.home-section-tile-7,
.home-section-tile-11 {
	--orbit-color: var(--app-accent-wine);
}

.home-section-tile-4,
.home-section-tile-8 {
	--orbit-color: var(--app-accent-slate);
}

.home-section-tile-5,
.home-section-tile-9 {
	--orbit-color: var(--app-accent-amber);
}

.home-section-image,
.home-section-glow {
	position: absolute;
	top: 0;
	left: 50%;
	width: 100%;
	aspect-ratio: 1;
	border-radius: 50%;
	transform: translateX(-50%);
}

.home-section-image {
	z-index: 0;
	object-fit: cover;
	opacity: 0.54;
	mix-blend-mode: screen;
}

.home-section-glow {
	z-index: 1;
	background: radial-gradient(circle, transparent 52%, color-mix(in srgb, var(--orbit-color) 44%, transparent) 66%, transparent 78%);
	filter: blur(0.58rem);
	opacity: 0.7;
}

.home-section-lock {
	display: none;
}

.home-section-icon {
	position: absolute;
	top: 0;
	left: 50%;
	z-index: 2;
	display: flex;
	width: 100%;
	aspect-ratio: 1;
	align-items: center;
	justify-content: center;
	border: 1px solid color-mix(in srgb, var(--orbit-color) 60%, white);
	border-radius: 999px;
	background:
		radial-gradient(circle at 37% 24%, color-mix(in srgb, var(--orbit-color) 16%, transparent), transparent 32%),
		radial-gradient(circle at center, var(--app-surface) 0 46%, var(--app-bg-deep) 76%);
	color: var(--orbit-color);
	box-shadow:
		inset 0 0 1.25rem color-mix(in srgb, var(--orbit-color) 12%, transparent),
		0 0 0.55rem color-mix(in srgb, var(--orbit-color) 42%, transparent),
		0 0 1.55rem color-mix(in srgb, var(--orbit-color) 20%, transparent);
	transform: translateX(-50%);
	transition: transform 0.18s ease, filter 0.18s ease;
}

.home-section-icon::before {
	content: '';
	position: absolute;
	inset: 0.32rem;
	border: 1px solid color-mix(in srgb, var(--orbit-color) 28%, transparent);
	border-radius: inherit;
	box-shadow: inset 0 0 0.6rem color-mix(in srgb, var(--orbit-color) 8%, transparent);
}

.home-section-icon svg {
	position: relative;
	z-index: 1;
	width: 48%;
	height: 48%;
	filter: drop-shadow(0 0 0.45rem color-mix(in srgb, var(--orbit-color) 78%, transparent));
}

.home-section-title {
	position: absolute;
	top: calc(clamp(3.8rem, 18vw, 4.75rem) + 0.64rem);
	left: 50%;
	z-index: 3;
	width: 6.75rem;
	margin: 0;
	color: var(--app-text-strong);
	font-size: clamp(0.58rem, 2.05vw, 0.7rem);
	font-weight: 450;
	line-height: 1.18;
	letter-spacing: 0.035em;
	text-align: center;
	text-shadow: none;
	text-transform: uppercase;
	transform: translateX(-50%);
}

.home-section-subtitle {
	position: absolute;
	top: calc(clamp(3.8rem, 18vw, 4.75rem) + 1.76rem);
	left: 50%;
	z-index: 3;
	width: 6.9rem;
	margin: 0;
	color: var(--app-muted);
	font-size: clamp(0.5rem, 1.75vw, 0.62rem);
	font-weight: 400;
	line-height: 1.32;
	text-align: center;
	text-shadow: none;
	transform: translateX(-50%);
}

.home-section-tile-lessons .home-section-title,
.home-section-tile-lessons .home-section-subtitle {
	transform: translateX(-28%);
}

.home-section-tile-tools .home-section-title,
.home-section-tile-tools .home-section-subtitle {
	transform: translateX(-68%);
}

.home-section-tile:hover .home-section-icon,
.home-section-tile:focus-visible .home-section-icon {
	filter: brightness(1.14);
	transform: translateX(-50%) scale(1.045);
}

.home-section-tile:focus-visible {
	outline: 2px solid var(--orbit-color);
	outline-offset: 0.35rem;
	border-radius: 50%;
}

.home-story-layer {
	position: fixed;
	top: 0;
	bottom: 0;
	left: 50%;
	right: auto;
	z-index: 90;
	display: flex;
	width: var(--app-viewport-width);
	max-width: var(--app-viewport-max);
	align-items: center;
	justify-content: center;
	background: rgba(0, 0, 0, 0.72);
	padding: 1rem;
	backdrop-filter: blur(18px);
	transform: translateX(-50%);
}

.home-story-card {
	position: relative;
	width: min(27rem, 100%, calc((100dvh - 2rem) / 1.77777778));
	aspect-ratio: 9 / 16;
	height: auto;
	overflow: hidden;
	border: 1px solid var(--app-border);
	border-radius: 1.7rem;
	box-shadow: var(--app-shadow-floating);
	color: var(--app-text);
	background: var(--app-surface);
}

.home-story-card-media {
	border-color: rgba(255, 255, 255, 0.16);
	box-shadow: 0 32px 90px rgba(0, 0, 0, 0.58);
}

.home-story-progress {
	position: absolute;
	top: 0.85rem;
	right: 0.9rem;
	left: 0.9rem;
	z-index: 4;
	display: flex;
	gap: 0.3rem;
}

.home-story-progress-track {
	display: block;
	height: 0.16rem;
	flex: 1;
	overflow: hidden;
	border-radius: 999px;
	background: color-mix(in srgb, var(--app-text) 18%, transparent);
}

.home-story-progress-fill {
	display: block;
	height: 100%;
	border-radius: inherit;
	background: color-mix(in srgb, var(--app-text) 78%, transparent);
}

.home-story-card-media .home-story-progress-track {
	background: rgba(255, 255, 255, 0.24);
}

.home-story-card-media .home-story-progress-fill {
	background: rgba(255, 255, 255, 0.92);
}

.home-story-close {
	position: absolute;
	top: 1.45rem;
	right: 0.95rem;
	z-index: 5;
	display: flex;
	width: 2.55rem;
	height: 2.55rem;
	align-items: center;
	justify-content: center;
	border-radius: 999px;
	background: color-mix(in srgb, var(--app-surface) 88%, transparent);
	color: var(--app-text);
	backdrop-filter: blur(12px);
}

.home-story-card-media .home-story-close {
	background: rgba(0, 0, 0, 0.32);
	color: rgba(255, 255, 255, 0.9);
}

.home-story-loader {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 3;
	display: flex;
	align-items: center;
	justify-content: center;
	background: rgba(9, 9, 9, 0.72);
}

.home-story-loader-spinner {
	width: 2.25rem;
	height: 2.25rem;
	border: 0.2rem solid rgba(255, 255, 255, 0.22);
	border-top-color: rgba(255, 255, 255, 0.9);
	border-radius: 999px;
	animation: home-story-spin 0.8s linear infinite;
}

@keyframes home-story-spin {
	to {
		transform: rotate(360deg);
	}
}

.home-story-image {
	position: absolute;
	inset: 0;
	width: 100%;
	height: 100%;
	object-fit: cover;
	object-position: center;
}

.home-story-content {
	position: absolute;
	inset: 0;
	z-index: 2;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	padding: 4.6rem 2rem 3rem;
	text-align: center;
	background: linear-gradient(180deg, color-mix(in srgb, var(--app-accent) 3%, transparent), color-mix(in srgb, var(--app-accent) 7%, transparent));
}

.home-story-content-bottom {
	top: 52%;
	justify-content: flex-start;
	background: linear-gradient(180deg, color-mix(in srgb, var(--app-accent) 4%, transparent), color-mix(in srgb, var(--app-accent) 10%, transparent));
}

.home-story-card-media .home-story-content {
	background: linear-gradient(180deg, rgba(0, 0, 0, 0.08), rgba(0, 0, 0, 0.22));
}

.home-story-card-media .home-story-content-bottom {
	background: linear-gradient(180deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.38));
}

.home-story-content p {
	margin: 0;
	max-width: 20rem;
	font-size: 1.05rem;
	font-weight: 540;
	line-height: 1.42;
	opacity: 0.82;
}

.home-story-overlays {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 4;
	pointer-events: none;
}

.home-story-overlay {
	position: absolute;
	pointer-events: auto;
	line-height: 1.25;
}

.home-story-overlay-text {
	margin: 0;
	white-space: pre-wrap;
	overflow-wrap: break-word;
}

.home-story-overlay-image img,
.home-story-overlay img {
	display: block;
	width: 100%;
	height: auto;
	object-fit: contain;
}

.home-story-overlay-button {
	display: flex;
	align-items: center;
	justify-content: center;
	min-height: 2.5rem;
	padding: 0.4rem 0.8rem;
	cursor: pointer;
	user-select: none;
}

.home-story-actions {
	position: absolute;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 5;
	pointer-events: none;
}

.home-story-join-button {
	position: absolute;
	top: 84%;
	left: 11%;
	width: 78%;
	height: 11%;
	border-radius: 999px;
	border: none;
	background: var(--app-button-bg);
	color: var(--app-button-fg);
	cursor: pointer;
	font-size: 1rem;
	font-weight: 700;
	letter-spacing: 0.01em;
	box-shadow: 0 0.8rem 1.75rem color-mix(in srgb, var(--app-accent-strong) 32%, transparent);
	pointer-events: auto;
	transition: transform 0.16s ease, background 0.16s ease;
	-webkit-tap-highlight-color: transparent;
}

.home-story-join-button:active {
	transform: scale(0.98);
}

.home-story-join-button:focus-visible {
	outline: 2px solid var(--app-surface);
	outline-offset: 0.2rem;
}

.home-story-enter-active,
.home-story-leave-active {
	transition: opacity 0.2s ease;
}

.home-story-enter-from,
.home-story-leave-to {
	opacity: 0;
}

@media (max-width: 640px) {
	.home-banners {
		margin-right: -0.75rem;
		padding-right: 0.75rem;
	}
}

@media (max-width: 360px) {
	.home-banners {
		gap: 0.38rem;
	}

	.home-banner-icon {
		top: 0.36rem;
		left: 0.36rem;
		width: 1.36rem;
		height: 1.36rem;
	}

	.home-banner-icon svg {
		width: 0.82rem;
		height: 0.82rem;
	}

	.home-banner-lock {
		top: 0.36rem;
		right: 0.36rem;
		width: 1.16rem;
		height: 1.16rem;
	}

	.home-banner-lock svg {
		width: 0.7rem;
		height: 0.7rem;
	}

	.home-banner-content {
		min-height: 2rem;
		padding: 0.4rem 0.3rem 0.42rem;
	}

	.home-banner-content h2 {
		font-size: 0.52rem;
		line-height: 1.06;
	}
}
.home-sections {
	position: relative;
	display: grid;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 0.7rem;
	width: 100%;
	max-width: 34rem;
	height: auto;
	isolation: auto;
}

.home-sections::before,
.home-sections::after,
.home-orbit-core {
	display: none;
}

.home-sections::before {
	content: none;
	animation: none;
}

.home-section-tile {
	position: relative;
	top: auto;
	left: auto;
	display: block;
	width: auto;
	aspect-ratio: 1 / 1;
	min-height: 0;
	padding: 1.1rem;
	overflow: hidden;
	border: 1px solid color-mix(in srgb, var(--orbit-color) 28%, var(--app-border));
	border-radius: 1rem;
	background-color: var(--app-surface) !important;
	background-image: radial-gradient(circle at 100% 0, color-mix(in srgb, var(--orbit-color) 15%, transparent), transparent 48%), linear-gradient(180deg, var(--app-surface), var(--app-bg));
	box-shadow:
		inset 0 1px rgb(255 255 255 / 0.96),
		inset 0 0 2.5rem color-mix(in srgb, var(--orbit-color) 5%, transparent),
		var(--app-shadow-soft),
		0 0 1.5rem color-mix(in srgb, var(--orbit-color) 12%, transparent);
	transform: none;
	transition: transform 0.18s ease, border-color 0.18s ease;
}

.home-section-tile:hover {
	border-color: color-mix(in srgb, var(--orbit-color) 62%, transparent);
}

.home-section-tile-templates {
	grid-column: 1 / -1;
	aspect-ratio: 2.05 / 1;
	--orbit-color: var(--app-accent-violet);
}

.home-section-tile-lessons { --orbit-color: var(--app-accent-blue); }
.home-section-tile-tools { --orbit-color: var(--app-accent-amber); }
.home-section-tile-streams { --orbit-color: var(--app-accent-wine); }
.home-section-tile-experts { --orbit-color: var(--app-accent-slate); }

.home-section-tile::before {
	content: '';
	position: absolute;
	inset: 0;
	pointer-events: none;
	background: radial-gradient(circle at 95% 10%, color-mix(in srgb, var(--orbit-color) 20%, transparent), transparent 48%);
}

.home-section-glow { display: none; }

.home-section-image {
	top: 0;
	left: auto;
	right: 0;
	width: 68%;
	height: 100%;
	aspect-ratio: auto;
	border-radius: 0;
	object-fit: cover;
	opacity: 0.88;
	mix-blend-mode: normal;
	transform: none;
	-webkit-mask-image: linear-gradient(to right, transparent, #000 24%);
	mask-image: linear-gradient(to right, transparent, #000 24%);
}

.home-section-tile-experts .home-section-image {
	transform: scale(2);
	transform-origin: right center;
}

.home-section-icon {
	position: absolute;
	top: 1.1rem;
	left: 1.1rem;
	width: 3rem;
	margin-bottom: 0;
	z-index: 2;
	transform: none;
}

.home-sections .home-section-icon {
	background: radial-gradient(circle at 37% 24%, rgb(255 255 255 / 0.96), transparent 38%), color-mix(in srgb, var(--orbit-color) 10%, var(--app-surface));
	box-shadow: inset 0 1px rgb(255 255 255 / 0.96), 0 0 1.2rem color-mix(in srgb, var(--orbit-color) 18%, transparent);
}

.home-section-tile:hover .home-section-icon,
.home-section-tile:focus-visible .home-section-icon {
	filter: none;
	transform: none;
}

.home-section-title,
.home-section-subtitle,
.home-section-tile-lessons .home-section-title,
.home-section-tile-lessons .home-section-subtitle,
.home-section-tile-tools .home-section-title,
.home-section-tile-tools .home-section-subtitle {
	position: absolute;
	top: 46%;
	left: 1.1rem;
	width: auto;
	margin: 0;
	transform: none;
	text-align: left;
	z-index: 2;
}

.home-section-title {
	margin-top: 0;
	font-size: 0.9rem;
	font-weight: 560;
	letter-spacing: 0.025em;
}

.home-section-subtitle {
	top: calc(46% + 1.5rem);
	margin-top: 0;
	font-size: 0.68rem;
	line-height: 1.32;
}

:is(
	.home-section-tile-lessons,
	.home-section-tile-tools,
	.home-section-tile-streams,
	.home-section-tile-experts
) .home-section-title {
	right: 1.1rem;
	color: var(--app-text-strong);
}

:is(
	.home-section-tile-lessons,
	.home-section-tile-tools,
	.home-section-tile-streams,
	.home-section-tile-experts
) .home-section-subtitle {
	right: 1.1rem;
	color: var(--app-muted);
}

.home-section-tile-lessons .home-section-subtitle,
.home-section-tile-tools .home-section-subtitle {
	top: calc(46% + 1.5rem);
}

.home-section-count {
	position: absolute;
	bottom: 1.1rem;
	left: 1.1rem;
	display: flex;
	gap: 0.6rem;
	align-items: center;
	margin-top: 0;
	z-index: 2;
	font-size: 0.7rem;
	font-weight: 500;
	color: var(--orbit-color);
}

.home-section-count span {
	font-size: 1rem;
	line-height: 1;
}

:is(
	.home-section-tile-lessons,
	.home-section-tile-tools,
	.home-section-tile-streams,
	.home-section-tile-experts
) .home-section-count {
	color: var(--app-text-strong);
}

:is(
	.home-section-tile-lessons,
	.home-section-tile-tools,
	.home-section-tile-streams,
	.home-section-tile-experts
) .home-section-count span {
	color: var(--orbit-color);
}

@media (max-width: 360px) {
	.home-section-tile {
		min-height: 7.8rem;
		padding: 0.82rem;
	}

	:is(
		.home-section-tile-lessons,
		.home-section-tile-tools,
		.home-section-tile-streams,
		.home-section-tile-experts
	) .home-section-title,
	:is(
		.home-section-tile-lessons,
		.home-section-tile-tools,
		.home-section-tile-streams,
		.home-section-tile-experts
	) .home-section-subtitle {
		left: 0.82rem;
		right: 0.82rem;
	}

	:is(
		.home-section-tile-lessons,
		.home-section-tile-tools,
		.home-section-tile-streams,
		.home-section-tile-experts
	) .home-section-count {
		left: 0.82rem;
		bottom: 0.82rem;
	}
}
</style>
