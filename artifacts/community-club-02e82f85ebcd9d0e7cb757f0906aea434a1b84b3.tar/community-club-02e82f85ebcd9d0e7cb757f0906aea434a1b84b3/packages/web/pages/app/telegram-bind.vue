<script setup lang="ts">
import type { TelegramBotAuthSettings } from '@community-club/shared/types'

definePageMeta({ keepalive: false })

const route = useRoute()
const auth = useAuthStore()
const api = useApi()

const botAuthSettings = ref<TelegramBotAuthSettings | null>(null)
const bound = ref(false)
const loadingSettings = ref(true)

const bindUrl = computed(() => {
	if (!auth.user?.authUuid) return ''
	const handle = botAuthSettings.value?.botHandle?.trim().replace(/^@/, '')
	return handle ? `https://t.me/${handle}?start=bind_${auth.user.authUuid}` : ''
})

async function loadBotSettings() {
	const res = await api.get<TelegramBotAuthSettings>('/api/site-settings/telegram-bot-auth', {
		authRedirect: false,
	})
	if (res.success) {
		botAuthSettings.value = res.data
	}
	loadingSettings.value = false
}

let pollTimer: ReturnType<typeof setInterval> | null = null

function startPolling() {
	if (pollTimer || !import.meta.client) return
	pollTimer = setInterval(async () => {
		if (auth.user?.telegramChatId) {
			bound.value = true
			if (pollTimer) {
				clearInterval(pollTimer)
				pollTimer = null
			}
			const redirect =
				typeof route.query.redirect === 'string' && route.query.redirect
					? route.query.redirect
					: '/app'
			await navigateTo(redirect)
			return
		}
		await auth.loadUser(true)
	}, 3000)
}

onMounted(async () => {
	await loadBotSettings()
	if (auth.user?.telegramChatId) {
		bound.value = true
		const redirect =
			typeof route.query.redirect === 'string' && route.query.redirect
				? route.query.redirect
				: '/app'
		await navigateTo(redirect)
		return
	}
	startPolling()
})

onUnmounted(() => {
	if (pollTimer) {
		clearInterval(pollTimer)
		pollTimer = null
	}
})
</script>

<template>
	<div class="club-bind">
		<div class="club-bind__icon" aria-hidden="true">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
				<path d="M21.6 4.1 3.8 11.2c-.9.35-.84 1.63.08 1.9l4.3 1.27 1.66 5.06c.25.77 1.24.92 1.71.26l2.3-3.24 4.45 3.26c.64.47 1.53.09 1.68-.72L22.9 5.1c.18-.97-.75-1.67-1.3-1Z" />
				<path d="M8.2 14.4 18 6.3a.39.39 0 0 0-.06-.6.4.4 0 0 0-.5.05L7.9 13.6" />
			</svg>
		</div>
		<h1 class="club-bind__title">Подключите Telegram</h1>
		<p class="club-bind__text">
			Чтобы входить в клуб по коду из телеграм-бота и всегда иметь доступ к аккаунту, подключите
			свой Telegram.
		</p>

		<a
			v-if="bindUrl"
			:href="bindUrl"
			target="_blank"
			rel="noopener noreferrer"
			class="club-bind__button"
		>
			Подключить Telegram
		</a>
		<p v-else-if="!loadingSettings" class="club-bind__error">
			Телеграм-бот ещё не настроен. Напишите Олегу Горскому.
		</p>

		<p v-if="bound" class="club-bind__success">Telegram подключён ✅</p>
		<p v-else-if="bindUrl" class="club-bind__hint">
			Нажмите на кнопку, запустите бота в Telegram — и возвращайтесь сюда.
		</p>
	</div>
</template>

<style scoped>
.club-bind { display: flex; min-height: 100svh; flex-direction: column; align-items: center; justify-content: center; padding: 2rem 1.5rem; text-align: center; }
.club-bind__icon { display: grid; width: 3.4rem; height: 3.4rem; place-items: center; border: 1px solid var(--app-border-strong); border-radius: 1rem; background: color-mix(in srgb, var(--app-accent) 8%, var(--app-surface)); color: var(--app-accent-strong); box-shadow: var(--app-shadow-soft); }
.club-bind__icon svg { width: 1.7rem; height: 1.7rem; }
.club-bind__title { margin: 1.1rem 0 0; color: var(--app-text-strong); font-size: 1.35rem; font-weight: 700; line-height: 1.2; }
.club-bind__text { margin: 0.6rem auto 0; max-width: 21rem; color: var(--app-muted); font-size: 0.88rem; line-height: 1.5; }
.club-bind__button { display: inline-block; margin-top: 1.6rem; border-radius: 0.85rem; padding: 0.85rem 1.5rem; background: linear-gradient(135deg, color-mix(in srgb, var(--app-accent) 76%, white), var(--app-accent)); color: var(--app-button-fg); font-size: 0.92rem; font-weight: 700; box-shadow: var(--app-shadow-raised); transition: transform 0.16s ease; }
.club-bind__button:active { transform: scale(0.98); }
.club-bind__hint, .club-bind__success, .club-bind__error { margin: 1.1rem 0 0; font-size: 0.82rem; line-height: 1.45; }
.club-bind__hint { color: var(--app-muted); }
.club-bind__success { color: var(--app-success); }
.club-bind__error { color: var(--app-danger); }
</style>
