import { describe, expect, test } from 'bun:test'
import { getPasswordChangeFormState } from './password-change'

describe('password change form state', () => {
	test('allows saving when current and matching new passwords are valid', () => {
		expect(
			getPasswordChangeFormState({
				currentPassword: 'old-password',
				newPassword: 'new-secret',
				confirmPassword: 'new-secret',
			}),
		).toEqual({
			canSubmit: true,
			passwordsMismatch: false,
		})
	})

	test('blocks saving when new passwords do not match', () => {
		expect(
			getPasswordChangeFormState({
				currentPassword: 'old-password',
				newPassword: 'new-secret',
				confirmPassword: 'other-secret',
			}),
		).toEqual({
			canSubmit: false,
			passwordsMismatch: true,
		})
	})

	test('blocks saving when required values are missing or short', () => {
		expect(
			getPasswordChangeFormState({
				currentPassword: '',
				newPassword: '12345',
				confirmPassword: '12345',
			}).canSubmit,
		).toBe(false)
	})
})
