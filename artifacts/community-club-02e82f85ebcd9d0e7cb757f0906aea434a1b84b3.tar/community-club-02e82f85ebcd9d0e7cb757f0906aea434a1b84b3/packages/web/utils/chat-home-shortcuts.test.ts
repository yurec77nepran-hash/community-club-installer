import { describe, expect, test } from 'bun:test'
import type { ChatListItem, HomeBannerItem, HomeStoryItem } from '@community-club/shared/types'
import {
	buildHomeChatShortcuts,
	filterHomeBannersByChatAccess,
	filterHomeStoriesByChatAccess,
	getClubChatRoute,
} from './chat-home-shortcuts'

function chat(overrides: Partial<ChatListItem>): ChatListItem {
	return {
		id: 1,
		slug: 'club-chat',
		name: 'Чат клуба',
		type: 'chat',
		accessRole: 'all',
		createdAt: new Date('2026-05-16T00:00:00Z'),
		lastReadMessageId: null,
		unreadMessageCount: 0,
		unreadMentionCount: 0,
		...overrides,
	}
}

function banner(overrides: Partial<HomeBannerItem>): HomeBannerItem {
	return {
		id: 'feed',
		title: 'Лента новостей',
		subtitle: 'Публикации',
		backgroundColor: '#243042',
		textColor: '#ffffff',
		mediaKey: null,
		mediaUrl: null,
		actionKind: 'internal',
		internalPath: '/app/feed',
		externalUrl: '',
		requiresAuth: true,
		storiesEnabled: false,
		...overrides,
	}
}

function story(overrides: Partial<HomeStoryItem>): HomeStoryItem {
	return {
		id: 'story-feed',
		title: 'Лента',
		text: 'Новости клуба появляются в ленте.',
		layout: 'text',
		backgroundColor: '#141414',
		textColor: '#ffffff',
		mediaKey: null,
		mediaUrl: null,
		durationMs: 5000,
		...overrides,
	}
}

describe('home chat shortcuts', () => {
	test('opens the configured club chat directly instead of the chat list', () => {
		expect(getClubChatRoute([chat({ id: 17, slug: 'club-chat' })])).toBe('/app/chats/17')
	})

	test('uses real chat unread counts for the fixed home shortcuts', () => {
		const shortcuts = buildHomeChatShortcuts(
			[
				chat({ id: 17, slug: 'club-chat', unreadMessageCount: 4 }),
				chat({
					id: 21,
					slug: 'club-channel',
					name: 'Клубный канал',
					accessRole: 'all',
					unreadMessageCount: 12,
				}),
			],
			'user',
		)

		expect(shortcuts.map((item) => [item.id, item.unreadMessageCount, item.locked])).toEqual([
			[17, 4, false],
			[21, 12, false],
		])
	})

	test('treats chats returned by the API as accessible even for fallback-locked roles', () => {
		const shortcuts = buildHomeChatShortcuts(
			[
				chat({ id: 1, slug: 'club-chat', unreadMessageCount: 4 }),
				chat({
					id: 2,
					slug: 'club-channel',
					name: 'Клубный канал',
					accessRole: 'all',
					unreadMessageCount: 9,
				}),
			],
			'user',
			{ chatsLoaded: true },
		)

		expect(shortcuts.map((item) => [item.slug, item.locked, item.unreadMessageCount])).toEqual([
			['club-chat', false, 4],
			['club-channel', false, 9],
		])
	})

	test('uses any enabled chat returned by the API for home chat access', () => {
		const customChat = chat({ id: 31, slug: 'club-chat-2', name: 'Общий чат' })
		const chatBanner = banner({
			id: 'chat',
			title: 'Чаты клуба',
			internalPath: '/app/chats',
		})

		expect(buildHomeChatShortcuts([customChat])[0]).toMatchObject({
			id: 31,
			route: '/app/chats/31',
		})
		expect(filterHomeBannersByChatAccess([chatBanner], [customChat])).toEqual([chatBanner])
	})

	test('keeps fallback club chats visible without locks', () => {
		const shortcuts = buildHomeChatShortcuts(
			[chat({ id: 1, slug: 'club-chat', unreadMessageCount: 7 })],
			'user',
			{ chatsLoaded: true },
		)

		expect(shortcuts[0]).toMatchObject({
			id: 1,
			locked: false,
			unreadMessageCount: 7,
		})
		expect(shortcuts[1]).toMatchObject({
			id: 2,
			slug: 'club-channel',
			route: '/app/feed',
			locked: false,
			unreadMessageCount: 0,
		})
	})

	test('does not show a club chat shortcut before chat access is loaded', () => {
		const shortcuts = buildHomeChatShortcuts([], 'user', { chatsLoaded: false })

		expect(shortcuts.map((item) => [item.slug, item.locked, item.unreadMessageCount])).toEqual([
			['club-channel', false, 0],
		])
	})

	test('does not show a club chat shortcut when chat access is absent', () => {
		const shortcuts = buildHomeChatShortcuts([], 'user', { chatsLoaded: true })

		expect(shortcuts).toEqual([
			expect.objectContaining({
				id: 2,
				slug: 'club-channel',
				route: '/app/feed',
				locked: false,
				unreadMessageCount: 0,
			}),
		])
	})

	test('keeps configured home banners visible before chat access loads', () => {
		const chatBanner = banner({
			id: 'chat',
			title: 'Чаты клуба',
			internalPath: '/app/chats',
		})
		const feedBanner = banner({ id: 'feed', title: 'Лента новостей' })

		expect(filterHomeBannersByChatAccess([chatBanner, feedBanner], [])).toEqual([
			chatBanner,
			feedBanner,
		])
		expect(
			filterHomeBannersByChatAccess(
				[chatBanner, feedBanner],
				[chat({ id: 17, slug: 'club-chat' })],
			),
		).toEqual([chatBanner, feedBanner])
	})

	test('hides chat stories unless club chat is available', () => {
		const chatStory = story({
			id: 'story-chat',
			title: 'Чат',
			text: 'Обсуждения доступны участникам клуба.',
		})
		const feedStory = story({ id: 'story-feed', title: 'Лента' })

		expect(filterHomeStoriesByChatAccess([chatStory, feedStory], [])).toEqual([feedStory])
		expect(
			filterHomeStoriesByChatAccess([chatStory, feedStory], [chat({ id: 17, slug: 'club-chat' })]),
		).toEqual([chatStory, feedStory])
	})
})
