import { describe, expect, test } from 'bun:test'
import { AVATAR_MAX_BYTES, getAvatarFileError } from './avatar-upload'

describe('avatar upload validation', () => {
	test('accepts supported image files and blocks unsupported or oversized files', () => {
		expect(getAvatarFileError({ name: 'avatar.jpg', type: 'image/jpeg', size: 1024 })).toBeNull()
		expect(getAvatarFileError({ name: 'avatar.heic', type: '', size: 1024 })).toBeNull()
		expect(getAvatarFileError({ name: 'avatar.svg', type: 'image/svg+xml', size: 1024 })).toContain(
			'JPEG',
		)
		expect(
			getAvatarFileError({ name: 'avatar.jpg', type: 'image/jpeg', size: AVATAR_MAX_BYTES + 1 }),
		).toContain('15 МБ')
	})
})
