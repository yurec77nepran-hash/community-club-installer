import { describe, expect, test } from 'bun:test'
import { buildDemoAccessRequest } from './demo-access'

describe('demo access request', () => {
	test('uses the current-user endpoint without a payload when authenticated', () => {
		const request = buildDemoAccessRequest({
			authenticated: true,
			email: 'member@example.com',
			password: 'secret12',
		})

		expect(request).toEqual({ endpoint: '/api/auth/demo-access/current' })
	})

	test('uses guest credentials with the public demo endpoint when unauthenticated', () => {
		const request = buildDemoAccessRequest({
			authenticated: false,
			email: '  Guest@Example.com ',
			password: 'secret12',
		})

		expect(request).toEqual({
			endpoint: '/api/auth/demo-access',
			body: { email: 'guest@example.com', password: 'secret12' },
		})
	})
})
