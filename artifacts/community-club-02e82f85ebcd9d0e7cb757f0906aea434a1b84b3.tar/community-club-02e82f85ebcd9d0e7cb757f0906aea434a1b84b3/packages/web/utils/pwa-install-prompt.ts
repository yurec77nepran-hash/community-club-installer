import { computed, shallowRef } from 'vue'
import { type PwaInstallState, nextPwaInstallState } from './pwa-runtime'

const deferredPrompt = shallowRef<BeforeInstallPromptEvent | null>(null)
const installState = shallowRef<PwaInstallState>('idle')

export const installPromptAvailable = computed(() => deferredPrompt.value !== null)
export const pwaInstallState = computed(() => installState.value)

export function captureInstallPrompt(event: BeforeInstallPromptEvent): void {
	event.preventDefault()
	deferredPrompt.value = event
}

export async function requestPwaInstall(): Promise<'accepted' | 'dismissed' | 'unavailable'> {
	const prompt = deferredPrompt.value
	if (prompt === null) return 'unavailable'

	deferredPrompt.value = null
	installState.value = nextPwaInstallState(installState.value, 'install_requested')
	await prompt.prompt()
	const choice = await prompt.userChoice
	installState.value = nextPwaInstallState(installState.value, `prompt_${choice.outcome}`)
	return choice.outcome
}

export function handlePwaInstalled(): void {
	deferredPrompt.value = null
	installState.value = nextPwaInstallState(installState.value, 'app_installed')
}
