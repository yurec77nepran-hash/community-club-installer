import { describe, expect, test } from 'bun:test'
import { readFileSync } from 'node:fs'

const appHeaderSource = readFileSync(
	new URL('../components/app/AppHeader.vue', import.meta.url),
	'utf8',
)
const notificationsModalSource = readFileSync(
	new URL('../components/app/NotificationsModal.vue', import.meta.url),
	'utf8',
)

describe('notification center component contract', () => {
	test('AppHeader renders the Nuxt auto-imported AppNotificationsModal component', () => {
		// Given
		const nuxtComponentName = 'AppNotificationsModal'

		// When
		const rendersGeneratedComponent = appHeaderSource.includes(`<${nuxtComponentName}`)

		// Then
		expect(rendersGeneratedComponent).toBe(true)
	})

	test('AppHeader accepts unread count updates from the notifications modal', () => {
		// Given
		const unreadCountListener = '@update:unread-count="unreadCount = $event"'

		// When
		const acceptsUnreadCountUpdate = appHeaderSource.includes(unreadCountListener)

		// Then
		expect(acceptsUnreadCountUpdate).toBe(true)
	})

	test('NotificationsModal emits the new unread count after reading one notification', () => {
		// Given
		const openNotificationSource =
			notificationsModalSource.match(
				/async function openNotification[\s\S]*?\n}\n\nasync function markAllRead/,
			)?.[0] ?? ''

		// When
		const emitsUpdatedCount =
			/unreadCount\.value = Math\.max\([\s\S]*?\)\s*emit\('update:unreadCount',\s*unreadCount\.value,?\s*\)/.test(
				openNotificationSource,
			)

		// Then
		expect(emitsUpdatedCount).toBe(true)
	})

	test('NotificationsModal emits zero unread notifications after reading all', () => {
		// Given
		const markAllReadSource =
			notificationsModalSource.match(/async function markAllRead[\s\S]*?\n}\n\nwatch\(/)?.[0] ?? ''

		// When
		const emitsEmptyCount =
			/unreadCount\.value = 0\s*emit\('update:unreadCount',\s*unreadCount\.value,?\s*\)/.test(
				markAllReadSource,
			)

		// Then
		expect(emitsEmptyCount).toBe(true)
	})
})
