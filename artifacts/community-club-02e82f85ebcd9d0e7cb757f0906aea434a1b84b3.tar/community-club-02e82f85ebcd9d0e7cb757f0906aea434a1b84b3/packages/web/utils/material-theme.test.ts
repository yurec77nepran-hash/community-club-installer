import { describe, expect, test } from 'bun:test'
import { getMaterialTheme } from './material-theme'

describe('material theme', () => {
	test('uses the approved section accents', () => {
		expect({
			checklists: getMaterialTheme('checklists').accent,
			courses: getMaterialTheme('courses').accent,
			other: getMaterialTheme('other').accent,
			streams: getMaterialTheme('streams').accent,
			experts: getMaterialTheme('experts').accent,
		}).toEqual({
			checklists: '#7A5AF8',
			courses: '#4DA3FF',
			other: '#F2A900',
			streams: '#A6465D',
			experts: '#6E7C91',
		})
	})

	test('uses amber as the fallback accent', () => {
		expect(getMaterialTheme('unknown')).toEqual(getMaterialTheme('other'))
	})
})
