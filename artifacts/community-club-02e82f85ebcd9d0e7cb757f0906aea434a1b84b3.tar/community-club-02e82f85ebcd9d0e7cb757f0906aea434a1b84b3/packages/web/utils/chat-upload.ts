export type ChatAttachmentMessageType = 'image' | 'video' | 'audio' | 'voice' | 'document'

export const CHAT_DIRECT_UPLOAD_MAX_BYTES = 32 * 1024 * 1024
export const CHAT_ATTACHMENT_MAX_BYTES = 3 * 1024 * 1024 * 1024

const IMAGE_EXTENSIONS = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif', 'heic', 'heif'])
const VIDEO_EXTENSIONS = new Set(['mp4', 'mov', 'm4v', 'webm'])
const AUDIO_EXTENSIONS = new Set(['ogg', 'oga', 'mp3', 'm4a', 'aac', 'wav', 'flac', 'opus'])

export function shouldUseChunkedChatUpload(fileSize: number) {
	return fileSize > CHAT_DIRECT_UPLOAD_MAX_BYTES
}

export function formatChatUploadLimit(bytes: number) {
	if (bytes >= 1024 * 1024 * 1024) {
		const value = bytes / 1024 / 1024 / 1024
		return `${Number.isInteger(value) ? value.toFixed(0) : value.toFixed(1)} ГБ`
	}

	const value = bytes / 1024 / 1024
	return `${Number.isInteger(value) ? value.toFixed(0) : value.toFixed(1)} МБ`
}

function getFileExtension(fileName: string) {
	return fileName.split('.').pop()?.trim().toLowerCase() ?? ''
}

export function getChatAttachmentMessageType(params: {
	fileName: string
	contentType?: string | null
}): ChatAttachmentMessageType {
	const contentType = params.contentType?.trim().toLowerCase() ?? ''
	const extension = getFileExtension(params.fileName)
	const isVoice =
		params.fileName.startsWith('voice_') &&
		(contentType.includes('webm') || contentType.startsWith('audio/'))

	if (isVoice) return 'voice'
	if (contentType.startsWith('image/') || IMAGE_EXTENSIONS.has(extension)) return 'image'
	if (contentType.startsWith('video/') || VIDEO_EXTENSIONS.has(extension)) return 'video'
	if (contentType.startsWith('audio/') || AUDIO_EXTENSIONS.has(extension)) return 'audio'
	return 'document'
}

export function getChatUploadProgressPercent(loaded: number, total: number | null) {
	if (!total || total <= 0) return 0
	const percent = Math.round((loaded / total) * 100)
	return Math.max(0, Math.min(100, percent))
}

export function buildInitialChatMessagesQuery(params: {
	limit: number
	lastReadMessageId?: number | null
	unreadMessageCount?: number | null
	hasRequestedMessage: boolean
}) {
	const shouldRestore =
		!params.hasRequestedMessage &&
		(params.lastReadMessageId ?? 0) > 0 &&
		(params.unreadMessageCount ?? 0) > 0

	if (!shouldRestore) {
		return {
			query: `?limit=${params.limit}`,
			restoreAfterMessageId: null,
		}
	}

	return {
		query: `?after=${params.lastReadMessageId}&limit=${params.limit}`,
		restoreAfterMessageId: params.lastReadMessageId ?? null,
	}
}
