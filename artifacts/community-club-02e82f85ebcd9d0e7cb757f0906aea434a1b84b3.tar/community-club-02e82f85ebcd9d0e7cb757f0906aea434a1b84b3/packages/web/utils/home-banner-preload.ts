export type PreloadableImage = {
	onload: ((event: Event) => void) | null
	onerror: ((event: Event) => void) | null
	src: string
}

type PreloadTimer = number

export type HomeBannerPreloadDependencies = {
	readonly createImage: () => PreloadableImage
	readonly setTimer: (callback: () => void, timeoutMs: number) => PreloadTimer
	readonly clearTimer: (timer: PreloadTimer) => void
}

type HomeBannerPreloadOptions = {
	readonly timeoutMs?: number
	readonly dependencies?: HomeBannerPreloadDependencies
}

export type HomeBannerPreloadResult = {
	readonly failedUrls: ReadonlySet<string>
}

const DEFAULT_TIMEOUT_MS = 8_000

const browserDependencies: HomeBannerPreloadDependencies = {
	createImage: () => new Image(),
	setTimer: (callback, timeoutMs) => window.setTimeout(callback, timeoutMs),
	clearTimer: (timer) => window.clearTimeout(timer),
}

export async function preloadHomeBannerImages(
	urls: readonly (string | null | undefined)[],
	options: HomeBannerPreloadOptions = {},
): Promise<HomeBannerPreloadResult> {
	const uniqueUrls = [
		...new Set(urls.map((url) => url?.trim()).filter((url): url is string => Boolean(url))),
	]
	const dependencies = options.dependencies ?? browserDependencies
	const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS

	const outcomes = await Promise.all(
		uniqueUrls.map(
			(url) =>
				new Promise<string | null>((resolve) => {
					const image = dependencies.createImage()
					let settled = false
					const timer = dependencies.setTimer(() => settle(url), timeoutMs)

					function settle(failedUrl: string | null) {
						if (settled) return
						settled = true
						dependencies.clearTimer(timer)
						image.onload = null
						image.onerror = null
						resolve(failedUrl)
					}

					image.onload = () => settle(null)
					image.onerror = () => settle(url)
					image.src = url
				}),
		),
	)

	return { failedUrls: new Set(outcomes.filter((url): url is string => url !== null)) }
}
