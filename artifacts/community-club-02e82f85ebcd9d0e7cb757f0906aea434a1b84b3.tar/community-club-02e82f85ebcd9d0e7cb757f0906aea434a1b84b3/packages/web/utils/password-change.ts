export type PasswordChangeFormValues = {
	currentPassword: string
	newPassword: string
	confirmPassword: string
}

export function getPasswordChangeFormState(
	values: PasswordChangeFormValues,
	options: { currentPasswordRequired?: boolean } = {},
) {
	const currentPasswordRequired = options.currentPasswordRequired !== false
	const passwordsMismatch =
		values.confirmPassword.length > 0 && values.newPassword !== values.confirmPassword
	const canSubmit =
		(!currentPasswordRequired || values.currentPassword.length > 0) &&
		values.newPassword.length >= 6 &&
		values.confirmPassword.length >= 6 &&
		!passwordsMismatch

	return {
		canSubmit,
		passwordsMismatch,
	}
}
