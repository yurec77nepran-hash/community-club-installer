import { describe, expect, it } from 'bun:test'
import { readFileSync } from 'node:fs'

const sources = {
	feed: readFileSync(new URL('../pages/app/feed.vue', import.meta.url), 'utf8'),
	payment: readFileSync(new URL('../pages/app/payment.vue', import.meta.url), 'utf8'),
} as const

function logoImageTag(source: string, className: string): string | undefined {
	return [...source.matchAll(/<img\b[\s\S]*?>/g)]
		.map(([tag]) => tag)
		.find((tag) => tag.includes(className))
}

describe('page brand logo sources', () => {
	it('uses the dynamic endpoint on feed and payment pages', () => {
		expect(logoImageTag(sources.feed, 'feed-hero-mark')).toContain(
			`:src="'/pwa-icon?size=512&format=webp'"`,
		)
		expect(logoImageTag(sources.payment, 'payment-heading-mark')).toContain(
			`:src="'/pwa-icon?size=512&format=webp'"`,
		)
	})

	it('marks feed and payment logo images as eager high-priority async-decoded images with dimensions', () => {
		const logoTags = [
			logoImageTag(sources.feed, 'feed-hero-mark'),
			logoImageTag(sources.payment, 'payment-heading-mark'),
		]
		for (const tag of logoTags) {
			expect(tag).toBeDefined()
			expect(tag).toContain('width="512"')
			expect(tag).toContain('height="512"')
			expect(tag).toContain('loading="eager"')
			expect(tag).toContain('fetchpriority="high"')
			expect(tag).toContain('decoding="async"')
		}
	})

	it('does not reference legacy logo assets on app pages', () => {
		for (const source of Object.values(sources)) {
			expect(source).not.toContain('/icons/gold-black-emblem.svg')
			expect(source).not.toContain('/icons/logo_234_gold.png')
		}
	})
})
