import { describe, expect, test } from 'bun:test'
import {
	buildOfficeDocumentViewerUrl,
	getDocumentPreviewKind,
	getDocumentTypeLabel,
	isPreviewableDocument,
} from './document-preview'

describe('document preview helpers', () => {
	test('detects PDF documents from filename or signed URL', () => {
		expect(
			getDocumentPreviewKind({
				name: 'Чек-лист',
				type: 'document',
				url: 'https://cdn.test/file.pdf?token=1',
			}),
		).toBe('pdf')
		expect(getDocumentTypeLabel({ name: 'manual.PDF', type: 'document' })).toBe('PDF')
	})

	test('detects office documents that can be opened through the embedded viewer', () => {
		expect(getDocumentPreviewKind({ name: 'plan.docx', type: 'document' })).toBe('office')
		expect(getDocumentPreviewKind({ name: 'table.xls', type: 'document' })).toBe('office')
		expect(getDocumentPreviewKind({ name: 'slides.pptx', type: 'document' })).toBe('office')
		expect(getDocumentTypeLabel({ name: 'table.xlsx', type: 'document' })).toBe('EXCEL')
	})

	test('builds a stable office viewer URL from the original file URL', () => {
		const sourceUrl = 'https://media.example.com/document/report.docx?X-Amz-Signature=abc'
		expect(buildOfficeDocumentViewerUrl(sourceUrl)).toBe(
			`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(sourceUrl)}`,
		)
	})

	test('does not expose preview for unsupported file extensions', () => {
		const file = { name: 'archive.zip', type: 'document' }
		expect(getDocumentPreviewKind(file)).toBe('none')
		expect(isPreviewableDocument(file)).toBe(false)
	})
})
