import { describe, expect, it } from 'bun:test'
import {
	getContrastRatio,
	getReadableForeground,
	getRelativeLuminance,
	getStrongAccent,
	normalizeHexColor,
} from './site-branding-colors'

describe('site branding color helpers', () => {
	describe('normalizeHexColor', () => {
		it('normalizes a valid six-digit hex color', () => {
			expect(normalizeHexColor('  #A6465D  ')).toBe('#a6465d')
		})

		it('uses the approved amber default when the color is missing', () => {
			expect(normalizeHexColor(undefined)).toBe('#D4A62A')
			expect(normalizeHexColor(null)).toBe('#D4A62A')
		})

		it('uses the requested fallback when the color is invalid', () => {
			expect(normalizeHexColor('#abc', '#FFFFFF')).toBe('#FFFFFF')
			expect(normalizeHexColor('not-a-color', '#1F1F1F')).toBe('#1F1F1F')
		})
	})

	describe('WCAG contrast', () => {
		it('calculates relative luminance with sRGB linearization', () => {
			expect(getRelativeLuminance('#000000')).toBe(0)
			expect(getRelativeLuminance('#FFFFFF')).toBe(1)
			expect(getRelativeLuminance('#777777')).toBeCloseTo(0.184475, 6)
		})

		it('calculates the WCAG contrast ratio independent of color order', () => {
			expect(getContrastRatio('#000000', '#FFFFFF')).toBe(21)
			expect(getContrastRatio('#FFFFFF', '#000000')).toBe(21)
			expect(getContrastRatio('#777777', '#FFFFFF')).toBeCloseTo(4.478, 3)
		})
	})

	describe('getReadableForeground', () => {
		it('selects an approved readable foreground for representative backgrounds', () => {
			const backgrounds = ['#1F1F1F', '#F7F5F0', '#D4A62A'] as const

			for (const background of backgrounds) {
				const foreground = getReadableForeground(background)

				expect(['#1F1F1F', '#FFFFFF']).toContain(foreground)
				expect(getContrastRatio(foreground, background)).toBeGreaterThanOrEqual(4.5)
			}

			expect(getReadableForeground('#1F1F1F')).toBe('#FFFFFF')
			expect(getReadableForeground('#F7F5F0')).toBe('#1F1F1F')
			expect(getReadableForeground('#D4A62A')).toBe('#1F1F1F')
		})

		it('never returns a foreground below 4.5 contrast across grayscale', () => {
			for (let value = 0; value <= 255; value += 1) {
				const channel = value.toString(16).padStart(2, '0')
				const background = `#${channel}${channel}${channel}`
				const foreground = getReadableForeground(background)

				expect(getContrastRatio(foreground, background)).toBeGreaterThanOrEqual(4.5)
			}
		})
	})

	describe('getStrongAccent', () => {
		it('preserves an accent that already passes against white', () => {
			const accent = '#a6465d'

			expect(getContrastRatio(accent, '#FFFFFF')).toBeGreaterThanOrEqual(4.5)
			expect(getStrongAccent(accent)).toBe(accent)
		})

		it('darkens the approved amber until it passes against white', () => {
			const accent = '#D4A62A'
			const strongAccent = getStrongAccent(accent)

			expect(strongAccent).not.toBe(accent)
			expect(getRelativeLuminance(strongAccent)).toBeLessThan(getRelativeLuminance(accent))
			expect(getContrastRatio(strongAccent, '#FFFFFF')).toBeGreaterThanOrEqual(4.5)
		})
	})
})
