export function getMaterialTheme(type: string) {
	const themes: Record<string, { accent: string; soft: string }> = {
		checklists: { accent: '#7A5AF8', soft: 'rgb(122 90 248 / 0.14)' },
		courses: { accent: '#4DA3FF', soft: 'rgb(77 163 255 / 0.14)' },
		experts: { accent: '#6E7C91', soft: 'rgb(110 124 145 / 0.14)' },
		streams: { accent: '#A6465D', soft: 'rgb(166 70 93 / 0.14)' },
		other: { accent: '#F2A900', soft: 'rgb(242 169 0 / 0.14)' },
	}

	return themes[type] ?? themes.other
}
