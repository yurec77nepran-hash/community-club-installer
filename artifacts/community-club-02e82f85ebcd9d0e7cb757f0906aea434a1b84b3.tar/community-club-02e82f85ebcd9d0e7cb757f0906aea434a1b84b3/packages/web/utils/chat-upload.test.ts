import { describe, expect, test } from 'bun:test'
import {
	CHAT_ATTACHMENT_MAX_BYTES,
	CHAT_DIRECT_UPLOAD_MAX_BYTES,
	buildInitialChatMessagesQuery,
	formatChatUploadLimit,
	getChatAttachmentMessageType,
	shouldUseChunkedChatUpload,
} from './chat-upload'

describe('chat upload helpers', () => {
	test('allows chat attachments up to 3 GB and switches large files to chunked upload', () => {
		expect(formatChatUploadLimit(CHAT_ATTACHMENT_MAX_BYTES)).toBe('3 ГБ')
		expect(shouldUseChunkedChatUpload(CHAT_DIRECT_UPLOAD_MAX_BYTES)).toBe(false)
		expect(shouldUseChunkedChatUpload(CHAT_DIRECT_UPLOAD_MAX_BYTES + 1)).toBe(true)
		expect(shouldUseChunkedChatUpload(CHAT_ATTACHMENT_MAX_BYTES)).toBe(true)
	})

	test('maps uploaded file mime type to chat message type', () => {
		expect(
			getChatAttachmentMessageType({ fileName: 'voice_1.webm', contentType: 'audio/webm' }),
		).toBe('voice')
		expect(getChatAttachmentMessageType({ fileName: 'photo.jpg', contentType: 'image/jpeg' })).toBe(
			'image',
		)
		expect(getChatAttachmentMessageType({ fileName: 'video.mp4', contentType: 'video/mp4' })).toBe(
			'video',
		)
		expect(
			getChatAttachmentMessageType({ fileName: 'doc.pdf', contentType: 'application/pdf' }),
		).toBe('document')
	})
})

describe('chat read position helpers', () => {
	test('opens chat from the last read message when unread messages exist', () => {
		expect(
			buildInitialChatMessagesQuery({
				limit: 50,
				lastReadMessageId: 123,
				unreadMessageCount: 7,
				hasRequestedMessage: false,
			}),
		).toEqual({
			query: '?after=123&limit=50',
			restoreAfterMessageId: 123,
		})
	})

	test('opens latest page when there is no unread restore point or a direct message jump is requested', () => {
		expect(
			buildInitialChatMessagesQuery({
				limit: 50,
				lastReadMessageId: 123,
				unreadMessageCount: 0,
				hasRequestedMessage: false,
			}),
		).toEqual({ query: '?limit=50', restoreAfterMessageId: null })

		expect(
			buildInitialChatMessagesQuery({
				limit: 50,
				lastReadMessageId: 123,
				unreadMessageCount: 7,
				hasRequestedMessage: true,
			}),
		).toEqual({ query: '?limit=50', restoreAfterMessageId: null })
	})
})
