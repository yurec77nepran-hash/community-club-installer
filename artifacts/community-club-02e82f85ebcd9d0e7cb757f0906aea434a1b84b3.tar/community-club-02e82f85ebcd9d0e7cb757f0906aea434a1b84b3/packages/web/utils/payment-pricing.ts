import type { PaymentCardType, PaymentTariffOffer } from '@community-club/shared/types'

export function resolveTariffFirstAmount(params: {
	tariff: PaymentTariffOffer | Record<string, unknown>
	cardType: PaymentCardType
	hasDiscount: boolean
	showPriceFirst: boolean
	pendingAmount?: number | null
}) {
	if (
		params.pendingAmount != null &&
		Number.isFinite(params.pendingAmount) &&
		params.pendingAmount > 0
	) {
		return params.pendingAmount
	}

	if (params.cardType === 'foreign' && params.hasDiscount) {
		const foreignPrice = Number(params.tariff.foreignDiscountPrice ?? 0)
		if (Number.isFinite(foreignPrice) && foreignPrice > 0) {
			return foreignPrice
		}
	}

	if (params.hasDiscount) {
		const discountPrice = Number(params.tariff.discountPrice ?? 0)
		if (Number.isFinite(discountPrice) && discountPrice > 0) {
			return discountPrice
		}
	}

	if (params.showPriceFirst) {
		const firstPrice = Number(params.tariff.priceFirst ?? 0)
		if (Number.isFinite(firstPrice) && firstPrice > 0) {
			return firstPrice
		}
	}

	const defaultPrice = Number(params.tariff.price ?? 0)
	return Number.isFinite(defaultPrice) ? defaultPrice : 0
}
