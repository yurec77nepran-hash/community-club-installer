import { describe, expect, it } from 'bun:test'
import {
	type HomeBannerPreloadDependencies,
	type PreloadableImage,
	preloadHomeBannerImages,
} from './home-banner-preload'

type PendingTimer = {
	readonly callback: () => void
	cancelled: boolean
}

function createHarness() {
	const images: PreloadableImage[] = []
	const timers: PendingTimer[] = []
	const dependencies: HomeBannerPreloadDependencies = {
		createImage: () => {
			const image: PreloadableImage = { onload: null, onerror: null, src: '' }
			images.push(image)
			return image
		},
		setTimer: (callback) => {
			const timer = { callback, cancelled: false }
			timers.push(timer)
			return timers.length - 1
		},
		clearTimer: (timer) => {
			const pendingTimer = timers[timer]
			if (pendingTimer) pendingTimer.cancelled = true
		},
	}

	return { dependencies, images, timers }
}

describe('preloadHomeBannerImages', () => {
	it('starts unique non-empty image URLs concurrently', async () => {
		// Given
		const harness = createHarness()

		// When
		const preload = preloadHomeBannerImages(
			[' /main.webp ', null, '', '/secondary.webp', '/main.webp', '   '],
			{ dependencies: harness.dependencies, timeoutMs: 1_000 },
		)

		// Then
		expect(harness.images.map((image) => image.src)).toEqual(['/main.webp', '/secondary.webp'])
		for (const image of harness.images) image.onload?.(new Event('load'))
		expect((await preload).failedUrls).toEqual(new Set())
	})

	it('settles after every image loads or errors and reports failed URLs', async () => {
		// Given
		const harness = createHarness()
		const preload = preloadHomeBannerImages(['/main.webp', '/broken.webp'], {
			dependencies: harness.dependencies,
			timeoutMs: 1_000,
		})
		const [mainImage, brokenImage] = harness.images

		// When
		mainImage?.onload?.(new Event('load'))
		brokenImage?.onerror?.(new Event('error'))

		// Then
		expect((await preload).failedUrls).toEqual(new Set(['/broken.webp']))
		expect(harness.timers.every((timer) => timer.cancelled)).toBe(true)
	})

	it('settles stalled images on the bounded timeout', async () => {
		// Given
		const harness = createHarness()
		const preload = preloadHomeBannerImages(['/stalled.webp'], {
			dependencies: harness.dependencies,
			timeoutMs: 1_000,
		})

		// When
		harness.timers[0]?.callback()

		// Then
		expect((await preload).failedUrls).toEqual(new Set(['/stalled.webp']))
	})

	it('settles immediately when no usable URLs are provided', async () => {
		// Given
		const harness = createHarness()

		// When
		const result = await preloadHomeBannerImages([null, '', '  '], {
			dependencies: harness.dependencies,
			timeoutMs: 1_000,
		})

		// Then
		expect(result.failedUrls).toEqual(new Set())
		expect(harness.images).toHaveLength(0)
	})
})
