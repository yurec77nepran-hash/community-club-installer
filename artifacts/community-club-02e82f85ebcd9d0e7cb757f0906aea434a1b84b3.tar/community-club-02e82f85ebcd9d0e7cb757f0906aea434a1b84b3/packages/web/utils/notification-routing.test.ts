import { describe, expect, test } from 'bun:test'
import { readFileSync } from 'node:fs'
import { normalizeNotificationClickUrl } from './notification-routing'

describe('notification routing', () => {
	test('keeps safe in-app notification URLs', () => {
		expect(normalizeNotificationClickUrl('/app/chats/2?messageId=42', 'https://example.com')).toBe(
			'/app/chats/2?messageId=42',
		)
	})

	test('normalizes same-origin absolute URLs to SPA paths', () => {
		expect(
			normalizeNotificationClickUrl(
				'https://example.com/app/chats/3?messageId=7',
				'https://example.com',
			),
		).toBe('/app/chats/3?messageId=7')
	})

	test('rejects external notification URLs', () => {
		expect(
			normalizeNotificationClickUrl('https://external.example/app/chats/3', 'https://example.com'),
		).toBeNull()
	})

	test('service worker forwards clicks into an already open app window', () => {
		const workerSource = readFileSync(new URL('../public/sw-push.js', import.meta.url), 'utf8')

		expect(workerSource).toContain('COMMUNITY_NOTIFICATION_CLICK')
		expect(workerSource).toContain('postMessage')
	})
})
