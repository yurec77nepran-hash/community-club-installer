type DemoAccessRequestInput = {
	readonly authenticated: boolean
	readonly email: string
	readonly password: string
}

type DemoAccessRequest =
	| { readonly endpoint: '/api/auth/demo-access/current' }
	| {
			readonly endpoint: '/api/auth/demo-access'
			readonly body: { readonly email: string; readonly password: string }
	  }

export function buildDemoAccessRequest(input: DemoAccessRequestInput): DemoAccessRequest {
	if (input.authenticated) {
		return { endpoint: '/api/auth/demo-access/current' }
	}

	return {
		endpoint: '/api/auth/demo-access',
		body: {
			email: input.email.trim().toLowerCase(),
			password: input.password,
		},
	}
}
