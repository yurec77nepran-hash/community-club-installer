export type PwaUpdateEnvironment = {
	readonly deleteCache: (cacheName: string) => Promise<boolean>
	readonly getReloadGuard: () => string | null
	readonly reload: () => void
	readonly retiredCacheNames: readonly string[]
	readonly setReloadGuard: (sourceBuildId: string) => void
}

export type PwaUpdateManagerOptions = {
	readonly environment: PwaUpdateEnvironment
	readonly sourceBuildId: string
	readonly startedControlled: boolean
}

export type PwaUpdateManager = {
	readonly onControllerChange: () => Promise<void>
	readonly onNeedReload: () => Promise<void>
}

export function createPwaUpdateManager(options: PwaUpdateManagerOptions): PwaUpdateManager {
	let controllerPresent = options.startedControlled
	let updateInFlight: Promise<void> | null = null

	const onUpdateSignal = (): Promise<void> => {
		if (updateInFlight) return updateInFlight
		if (options.environment.getReloadGuard() === options.sourceBuildId) return Promise.resolve()

		options.environment.setReloadGuard(options.sourceBuildId)
		updateInFlight = (async () => {
			for (const cacheName of options.environment.retiredCacheNames) {
				await options.environment.deleteCache(cacheName)
			}
			options.environment.reload()
		})()
		return updateInFlight
	}

	const onControllerChange = (): Promise<void> => {
		if (controllerPresent) return onUpdateSignal()
		controllerPresent = true
		return Promise.resolve()
	}

	return {
		onControllerChange,
		onNeedReload: onUpdateSignal,
	}
}

export function withBuildVersion(url: string, buildId: string): string {
	if (!buildId) return url

	const hashIndex = url.indexOf('#')
	const pathAndQuery = hashIndex === -1 ? url : url.slice(0, hashIndex)
	const hash = hashIndex === -1 ? '' : url.slice(hashIndex)
	const queryIndex = pathAndQuery.indexOf('?')
	const path = queryIndex === -1 ? pathAndQuery : pathAndQuery.slice(0, queryIndex)
	const search = queryIndex === -1 ? '' : pathAndQuery.slice(queryIndex + 1)
	const parameters = new URLSearchParams(search)
	parameters.set('build', buildId)
	const query = [...parameters.entries()]
		.map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
		.join('&')

	return `${path}?${query}${hash}`
}
