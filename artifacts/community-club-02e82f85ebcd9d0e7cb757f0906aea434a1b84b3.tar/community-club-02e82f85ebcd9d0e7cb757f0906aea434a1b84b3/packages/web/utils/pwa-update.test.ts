import { describe, expect, test } from 'bun:test'
import { type PwaUpdateEnvironment, createPwaUpdateManager, withBuildVersion } from './pwa-update'

type FakeEnvironmentOptions = {
	readonly cacheNames?: readonly string[]
	readonly deleteGate?: Promise<void>
	readonly initialReloadGuard?: string | null
	readonly retiredCacheNames?: readonly string[]
}

type FakeEnvironment = {
	readonly deletedCacheNames: readonly string[]
	readonly environment: PwaUpdateEnvironment
	readonly getCacheNames: () => readonly string[]
	readonly getGuardAtFirstDelete: () => string | null
	readonly getReloadCount: () => number
	readonly reloadGuardWrites: readonly string[]
}

function createEnvironment(options: FakeEnvironmentOptions = {}): FakeEnvironment {
	let reloadGuard = options.initialReloadGuard ?? null
	let reloadCount = 0
	let guardAtFirstDelete: string | null = null
	const cacheNames = new Set(options.cacheNames ?? [])
	const deletedCacheNames: string[] = []
	const reloadGuardWrites: string[] = []
	const environment: PwaUpdateEnvironment = {
		deleteCache: async (cacheName) => {
			if (deletedCacheNames.length === 0) guardAtFirstDelete = reloadGuard
			if (options.deleteGate) await options.deleteGate
			deletedCacheNames.push(cacheName)
			return cacheNames.delete(cacheName)
		},
		getReloadGuard: () => reloadGuard,
		reload: () => {
			reloadCount += 1
		},
		retiredCacheNames: options.retiredCacheNames ?? [],
		setReloadGuard: (sourceBuildId) => {
			reloadGuard = sourceBuildId
			reloadGuardWrites.push(sourceBuildId)
		},
	}

	return {
		deletedCacheNames,
		environment,
		getCacheNames: () => [...cacheNames],
		getGuardAtFirstDelete: () => guardAtFirstDelete,
		getReloadCount: () => reloadCount,
		reloadGuardWrites,
	}
}

function createManager(
	environment: PwaUpdateEnvironment,
	sourceBuildId: string,
	startedControlled = true,
) {
	return createPwaUpdateManager({ environment, sourceBuildId, startedControlled })
}

describe('PWA source-document update lifecycle', () => {
	test('does nothing on a fresh boot without an update signal', () => {
		// Given
		const fake = createEnvironment()

		// When
		createManager(fake.environment, 'build A')

		// Then
		expect(fake.reloadGuardWrites).toEqual([])
		expect(fake.deletedCacheNames).toEqual([])
		expect(fake.getReloadCount()).toBe(0)
	})

	test('does not reload when an initially uncontrolled document acquires its first controller', async () => {
		// Given
		const fake = createEnvironment()
		const manager = createManager(fake.environment, 'build A', false)

		// When
		await manager.onControllerChange()

		// Then
		expect(fake.reloadGuardWrites).toEqual([])
		expect(fake.getReloadCount()).toBe(0)
	})

	test('writes the source build guard before awaiting retired cache deletion', async () => {
		// Given
		let releaseDelete = () => {}
		const deleteGate = new Promise<void>((resolve) => {
			releaseDelete = resolve
		})
		const fake = createEnvironment({
			cacheNames: ['retired-cache'],
			deleteGate,
			retiredCacheNames: ['retired-cache'],
		})
		const manager = createManager(fake.environment, 'build A')

		// When
		const update = manager.onControllerChange()
		releaseDelete()
		await update

		// Then
		expect(fake.getGuardAtFirstDelete()).toBe('build A')
	})

	test('deletes only exact retired cache allowlist entries before one reload', async () => {
		// Given
		const retiredPrecache = 'workbox-precache-v2-community-club-build-a'
		const retiredImages = 'community-club-images-build-a'
		const currentWorkboxCache = 'workbox-precache-v2-community-club-build-b'
		const unrelatedCache = 'third-party-image-cache'
		const fake = createEnvironment({
			cacheNames: [retiredPrecache, currentWorkboxCache, unrelatedCache, retiredImages],
			retiredCacheNames: [retiredPrecache, retiredImages],
		})
		const manager = createManager(fake.environment, 'build A')

		// When
		await manager.onControllerChange()

		// Then
		expect(fake.deletedCacheNames).toEqual([retiredPrecache, retiredImages])
		expect(fake.getCacheNames()).toEqual([currentWorkboxCache, unrelatedCache])
		expect(fake.reloadGuardWrites).toEqual(['build A'])
		expect(fake.getReloadCount()).toBe(1)
	})

	test('shares one single-flight guard across concurrent and repeated update signals', async () => {
		// Given
		const fake = createEnvironment({ retiredCacheNames: ['retired-cache'] })
		const manager = createManager(fake.environment, 'build A')

		// When
		await Promise.all([
			manager.onNeedReload(),
			manager.onControllerChange(),
			manager.onNeedReload(),
		])

		// Then
		expect(fake.reloadGuardWrites).toEqual(['build A'])
		expect(fake.deletedCacheNames).toEqual(['retired-cache'])
		expect(fake.getReloadCount()).toBe(1)
	})

	test('suppresses a repeated reload for a new manager of the guarded source document', async () => {
		// Given
		const fake = createEnvironment({ initialReloadGuard: 'build A' })
		const manager = createManager(fake.environment, 'build A')

		// When
		await manager.onControllerChange()

		// Then
		expect(fake.reloadGuardWrites).toEqual([])
		expect(fake.getReloadCount()).toBe(0)
	})

	test('allows document B to reload when the tab-local guard belongs to document A', async () => {
		// Given
		const fake = createEnvironment({ initialReloadGuard: 'build A' })
		const manager = createManager(fake.environment, 'build B')

		// When
		await manager.onNeedReload()

		// Then
		expect(fake.reloadGuardWrites).toEqual(['build B'])
		expect(fake.getReloadCount()).toBe(1)
	})

	test('allows separate tab-local environments to reload independently', async () => {
		// Given
		const firstTab = createEnvironment()
		const secondTab = createEnvironment()
		const firstManager = createManager(firstTab.environment, 'build A')
		const secondManager = createManager(secondTab.environment, 'build A')

		// When
		await Promise.all([firstManager.onControllerChange(), secondManager.onControllerChange()])

		// Then
		expect(firstTab.reloadGuardWrites).toEqual(['build A'])
		expect(secondTab.reloadGuardWrites).toEqual(['build A'])
		expect(firstTab.getReloadCount()).toBe(1)
		expect(secondTab.getReloadCount()).toBe(1)
	})
})

describe('PWA build-versioned URLs', () => {
	test('preserves the asset path and appends an encoded build query', () => {
		// Given
		const path = '/images/home/section-tools.webp'

		// When
		const versionedPath = withBuildVersion(path, 'build 2')

		// Then
		expect(versionedPath).toBe('/images/home/section-tools.webp?build=build%202')
	})

	test('leaves the asset URL unchanged when the build ID is empty', () => {
		// Given
		const path = '/images/home/section-tools.webp'

		// When
		const versionedPath = withBuildVersion(path, '')

		// Then
		expect(versionedPath).toBe(path)
	})

	test('preserves existing query parameters and a hash when appending the build query', () => {
		// Given
		const path = '/images/home/section-tools.webp?size=large#tools'

		// When
		const versionedPath = withBuildVersion(path, 'build 2')

		// Then
		expect(versionedPath).toBe('/images/home/section-tools.webp?size=large&build=build%202#tools')
	})

	test('replaces an existing build query without duplicating it or moving the hash', () => {
		// Given
		const path = '/images/home/section-tools.webp?build=build%201&size=large#tools'

		// When
		const versionedPath = withBuildVersion(path, 'build 2')

		// Then
		expect(versionedPath).toBe('/images/home/section-tools.webp?build=build%202&size=large#tools')
	})
})
