import type { ChatListItem, HomeBannerItem, HomeStoryItem } from '@community-club/shared/types'

const HOME_CHAT_META = [
	{
		slug: 'club-chat',
		fallbackId: 1,
		name: 'Чат клуба',
		kind: 'chat',
	},
	{
		slug: 'club-channel',
		fallbackId: 2,
		name: 'Клубный канал',
		kind: 'feed',
	},
] as const

export type HomeChatShortcut = {
	id: number
	slug: string
	name: string
	route: string
	locked: boolean
	unreadMessageCount: number
}

type BuildHomeChatShortcutsOptions = {
	chatsLoaded?: boolean
}

export function getClubChatRoute(availableChats: ChatListItem[]) {
	const chat = availableChats.find((item) => item.slug === 'club-chat') ?? availableChats[0]
	return chat ? `/app/chats/${chat.id}` : '/app/chats'
}

function hasChatHint(value: string) {
	const normalized = value.toLowerCase()
	return normalized.includes('chat') || normalized.includes('чат')
}

function hasClubChatAccess(availableChats: ChatListItem[]) {
	return availableChats.length > 0
}

function isClubChatStory(story: HomeStoryItem) {
	return hasChatHint(story.id) || hasChatHint(story.title) || hasChatHint(story.text)
}

export function filterHomeBannersByChatAccess(
	banners: HomeBannerItem[],
	availableChats: ChatListItem[],
) {
	void availableChats
	return banners
}

export function filterHomeStoriesByChatAccess(
	stories: HomeStoryItem[],
	availableChats: ChatListItem[],
) {
	if (hasClubChatAccess(availableChats)) return stories
	return stories.filter((story) => !isClubChatStory(story))
}

export function buildHomeChatShortcuts(
	availableChats: ChatListItem[],
	userRole?: unknown,
	options: BuildHomeChatShortcutsOptions = {},
): HomeChatShortcut[] {
	void userRole
	void options

	return HOME_CHAT_META.flatMap((meta) => {
		const chat =
			meta.kind === 'chat'
				? (availableChats.find((item) => item.slug === meta.slug) ?? availableChats[0])
				: availableChats.find((item) => item.slug === meta.slug)
		if (meta.kind === 'chat' && !chat) return []

		const id = chat?.id ?? meta.fallbackId
		const locked = false

		return [
			{
				id,
				slug: chat?.slug ?? meta.slug,
				name: chat?.name ?? meta.name,
				route: meta.kind === 'feed' ? '/app/feed' : getClubChatRoute(availableChats),
				locked,
				unreadMessageCount: locked ? 0 : (chat?.unreadMessageCount ?? 0),
			},
		]
	})
}
