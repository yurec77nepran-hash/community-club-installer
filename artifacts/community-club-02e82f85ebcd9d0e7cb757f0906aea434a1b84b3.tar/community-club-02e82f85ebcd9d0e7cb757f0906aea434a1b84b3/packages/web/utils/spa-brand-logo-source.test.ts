import { describe, expect, it } from 'bun:test'
import { readFileSync } from 'node:fs'

const spaLoadingTemplate = readFileSync(
	new URL('../app/spa-loading-template.html', import.meta.url),
	'utf8',
)
const nuxtConfig = readFileSync(new URL('../nuxt.config.ts', import.meta.url), 'utf8')
const criticalLogoUrl = '/pwa-icon?size=512&format=webp'

describe('SPA brand logo source', () => {
	it('uses the dynamic endpoint in the pre-hydration loader', () => {
		expect(spaLoadingTemplate).toMatch(/<img\b[^>]*src="\/pwa-icon\?size=512&format=webp"[^>]*>/)
	})

	it('declares one matching critical logo preload in the Nuxt document head', () => {
		const preloadPattern = new RegExp(
			`\\{\\s*rel: 'preload',\\s*as: 'image',\\s*href: '${criticalLogoUrl.replace('?', '\\?')}',\\s*fetchpriority: 'high',?\\s*\\}`,
		)
		const loaderImageUrl = spaLoadingTemplate.match(/<img\b[^>]*src="([^"]+)"/)?.[1]

		expect(nuxtConfig).toMatch(preloadPattern)
		expect([
			...nuxtConfig.matchAll(new RegExp(criticalLogoUrl.replace('?', '\\?'), 'g')),
		]).toHaveLength(1)
		expect(loaderImageUrl).toBe(criticalLogoUrl)
		expect(spaLoadingTemplate).not.toMatch(/<link\b[^>]*rel="preload"/)
	})

	it('marks the loader image as a critical async-decoded image with intrinsic dimensions', () => {
		expect(spaLoadingTemplate).toContain(
			'<img src="/pwa-icon?size=512&format=webp" alt="" width="512" height="512" loading="eager" fetchpriority="high" decoding="async" />',
		)
	})

	it('does not reference legacy logo assets', () => {
		expect(spaLoadingTemplate).not.toContain('/icons/gold-black-emblem.svg')
		expect(spaLoadingTemplate).not.toContain('/icons/logo_234_gold.png')
	})
})
