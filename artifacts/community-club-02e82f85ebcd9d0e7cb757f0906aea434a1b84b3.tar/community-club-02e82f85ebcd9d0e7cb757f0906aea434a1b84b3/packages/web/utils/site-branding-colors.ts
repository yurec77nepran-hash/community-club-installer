const DEFAULT_ACCENT = '#D4A62A'
const DARK_FOREGROUND = '#1F1F1F'
const LIGHT_FOREGROUND = '#FFFFFF'
const BLACK_FOREGROUND = '#000000'
const MINIMUM_CONTRAST = 4.5
const MIX_STEPS = 20

type RgbColor = readonly [red: number, green: number, blue: number]

export function normalizeHexColor(
	value: string | null | undefined,
	fallback = DEFAULT_ACCENT,
): string {
	const normalized = value?.trim().toLowerCase() ?? ''
	return /^#[0-9a-f]{6}$/.test(normalized) ? normalized : fallback
}

function parseHexColor(hexColor: string): RgbColor {
	const hex = normalizeHexColor(hexColor, BLACK_FOREGROUND).slice(1)
	return [
		Number.parseInt(hex.slice(0, 2), 16),
		Number.parseInt(hex.slice(2, 4), 16),
		Number.parseInt(hex.slice(4, 6), 16),
	]
}

function toLinearSrgb(channel: number): number {
	const srgb = channel / 255
	return srgb <= 0.04045 ? srgb / 12.92 : ((srgb + 0.055) / 1.055) ** 2.4
}

export function getRelativeLuminance(hexColor: string): number {
	const [red, green, blue] = parseHexColor(hexColor)
	return 0.2126 * toLinearSrgb(red) + 0.7152 * toLinearSrgb(green) + 0.0722 * toLinearSrgb(blue)
}

export function getContrastRatio(firstColor: string, secondColor: string): number {
	const firstLuminance = getRelativeLuminance(firstColor)
	const secondLuminance = getRelativeLuminance(secondColor)
	const lighter = Math.max(firstLuminance, secondLuminance)
	const darker = Math.min(firstLuminance, secondLuminance)
	return (lighter + 0.05) / (darker + 0.05)
}

export function getReadableForeground(background: string): string {
	if (getContrastRatio(DARK_FOREGROUND, background) >= MINIMUM_CONTRAST) {
		return DARK_FOREGROUND
	}
	if (getContrastRatio(LIGHT_FOREGROUND, background) >= MINIMUM_CONTRAST) {
		return LIGHT_FOREGROUND
	}
	return BLACK_FOREGROUND
}

function mixColor(start: RgbColor, end: RgbColor, amount: number): string {
	const channels = start.map((channel, index) =>
		Math.round(channel + (end[index] - channel) * amount),
	)
	return `#${channels.map((channel) => channel.toString(16).padStart(2, '0')).join('')}`
}

export function getStrongAccent(accent: string): string {
	const normalizedAccent = normalizeHexColor(accent)
	if (getContrastRatio(normalizedAccent, LIGHT_FOREGROUND) >= MINIMUM_CONTRAST) {
		return normalizedAccent
	}

	const accentRgb = parseHexColor(normalizedAccent)
	const darkRgb = parseHexColor(DARK_FOREGROUND)
	for (let step = 1; step <= MIX_STEPS; step += 1) {
		const candidate = mixColor(accentRgb, darkRgb, step / MIX_STEPS)
		if (getContrastRatio(candidate, LIGHT_FOREGROUND) >= MINIMUM_CONTRAST) {
			return candidate
		}
	}

	return DARK_FOREGROUND
}
