import { describe, expect, test } from 'bun:test'
import type { ChatMessage } from '../stores/chat'
import { getChatMessageDeleteTarget } from './chat-message-delete'

function message(overrides: Partial<ChatMessage>): ChatMessage {
	return {
		id: 1,
		chatId: 1,
		userAuthUuid: 'user-1',
		content: 'Привет',
		replyToId: null,
		clientMessageId: null,
		messageType: 'text',
		attachmentUrl: null,
		attachmentName: null,
		attachmentSize: null,
		linkPreview: null,
		isDeleted: false,
		createdAt: new Date('2026-05-24T10:00:00Z'),
		updatedAt: new Date('2026-05-24T10:00:00Z'),
		author: {
			fullName: 'User',
			username: null,
			avatarUrl: null,
			chatAdminBadge: false,
		},
		replyTo: null,
		mentions: [],
		reactions: [],
		deliveryStatus: 'sent',
		...overrides,
	}
}

describe('chat message delete target', () => {
	test('keeps the client id for optimistic messages so pending fallback can be cancelled', () => {
		expect(
			getChatMessageDeleteTarget(
				[message({ id: -10, clientMessageId: 'client-1', deliveryStatus: 'sending' })],
				-10,
			),
		).toEqual({
			id: -10,
			clientMessageId: 'client-1',
			persisted: false,
		})
	})
})
