export type DocumentPreviewKind = 'pdf' | 'office' | 'none'

type DocumentPreviewFile = {
	name: string
	type?: string | null
	url?: string | null
}

const PDF_EXTENSIONS = new Set(['pdf'])
const WORD_EXTENSIONS = new Set(['doc', 'docx'])
const SPREADSHEET_EXTENSIONS = new Set(['xls', 'xlsx'])
const PRESENTATION_EXTENSIONS = new Set(['ppt', 'pptx'])
const OFFICE_EXTENSIONS = new Set([
	...WORD_EXTENSIONS,
	...SPREADSHEET_EXTENSIONS,
	...PRESENTATION_EXTENSIONS,
])

function getExtensionFromValue(value: string | null | undefined) {
	if (!value?.trim()) return null
	const withoutQuery = value.split(/[?#]/)[0] ?? ''
	const fileName = withoutQuery.split('/').pop() ?? withoutQuery

	try {
		const decodedFileName = decodeURIComponent(fileName)
		const extension = decodedFileName.split('.').pop()?.trim().toLowerCase()
		return extension && extension !== decodedFileName.toLowerCase() ? extension : null
	} catch {
		const extension = fileName.split('.').pop()?.trim().toLowerCase()
		return extension && extension !== fileName.toLowerCase() ? extension : null
	}
}

export function getDocumentFileExtension(file: DocumentPreviewFile) {
	return getExtensionFromValue(file.name) ?? getExtensionFromValue(file.url)
}

export function getDocumentPreviewKind(file: DocumentPreviewFile): DocumentPreviewKind {
	if (file.type && file.type !== 'document') return 'none'

	const extension = getDocumentFileExtension(file)
	if (!extension) return 'none'
	if (PDF_EXTENSIONS.has(extension)) return 'pdf'
	if (OFFICE_EXTENSIONS.has(extension)) return 'office'
	return 'none'
}

export function isPreviewableDocument(file: DocumentPreviewFile) {
	return getDocumentPreviewKind(file) !== 'none'
}

export function buildOfficeDocumentViewerUrl(sourceUrl: string) {
	return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(sourceUrl)}`
}

export function getDocumentTypeLabel(file: DocumentPreviewFile) {
	const extension = getDocumentFileExtension(file)
	if (!extension) return 'Файл'
	if (PDF_EXTENSIONS.has(extension)) return 'PDF'
	if (WORD_EXTENSIONS.has(extension)) return 'WORD'
	if (SPREADSHEET_EXTENSIONS.has(extension)) return 'EXCEL'
	if (PRESENTATION_EXTENSIONS.has(extension)) return 'PPT'
	return 'Файл'
}
