type ImageSaveParams = {
	src?: string | null
	downloadUrl?: string | null
	downloadable?: boolean | null
}

type ImageFileNameParams = {
	title?: string | null
	contentType?: string | null
}

const IMAGE_EXTENSION_BY_CONTENT_TYPE: Record<string, string> = {
	'image/jpeg': 'jpg',
	'image/jpg': 'jpg',
	'image/png': 'png',
	'image/webp': 'webp',
	'image/gif': 'gif',
	'image/avif': 'avif',
	'image/heic': 'heic',
	'image/heif': 'heif',
}

export function canOfferImageSave(params: ImageSaveParams) {
	if (params.downloadable === false) return false
	return Boolean(params.downloadUrl?.trim() || params.src?.trim())
}

function getImageExtension(contentType: string | null | undefined) {
	const normalizedType = contentType?.split(';')[0]?.trim().toLowerCase()
	return normalizedType ? (IMAGE_EXTENSION_BY_CONTENT_TYPE[normalizedType] ?? 'jpg') : 'jpg'
}

function normalizeImageTitle(title: string | null | undefined) {
	const normalizedTitle = title
		?.replace(/[\\/:*?"<>|]/g, ' ')
		.replace(/\s+/g, ' ')
		.trim()
	return normalizedTitle || 'image'
}

export function getImageDownloadFileName(params: ImageFileNameParams) {
	const title = normalizeImageTitle(params.title)
	const extension = getImageExtension(params.contentType)
	const titleWithoutExtension = title.replace(/\.(jpe?g|png|webp|gif|avif|hei[cf])$/i, '')
	return `${titleWithoutExtension}.${extension}`
}
