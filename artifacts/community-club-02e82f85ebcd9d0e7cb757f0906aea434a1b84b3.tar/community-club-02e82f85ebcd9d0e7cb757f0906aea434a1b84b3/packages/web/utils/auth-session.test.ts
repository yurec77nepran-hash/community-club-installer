import { describe, expect, test } from 'bun:test'
import {
	shouldAttemptRefreshDuringRestore,
	shouldLogoutAfterApiRefreshFailure,
	shouldLogoutAfterRestoreFailure,
	shouldRetryRequestAfterUnauthorized,
} from './auth-session'

describe('auth session restore strategy', () => {
	test('tries refresh when local access token is missing', () => {
		expect(shouldAttemptRefreshDuringRestore({ hasAccessToken: false, hasUser: false })).toBe(true)
	})

	test('tries refresh when access token exists but current user is not restored', () => {
		expect(shouldAttemptRefreshDuringRestore({ hasAccessToken: true, hasUser: false })).toBe(true)
	})

	test('does not refresh when both token and user are already restored', () => {
		expect(shouldAttemptRefreshDuringRestore({ hasAccessToken: true, hasUser: true })).toBe(false)
	})

	test('logs out when refresh explicitly reports unauthorized', () => {
		expect(
			shouldLogoutAfterRestoreFailure({
				refreshResult: 'unauthorized',
				hasUser: true,
				hadRecoverableState: true,
			}),
		).toBe(true)
	})

	test('keeps session state on network failure when recoverable state exists', () => {
		expect(
			shouldLogoutAfterRestoreFailure({
				refreshResult: 'network_error',
				hasUser: false,
				hadRecoverableState: true,
			}),
		).toBe(false)
	})

	test('logs out on network failure only when nothing can be recovered', () => {
		expect(
			shouldLogoutAfterRestoreFailure({
				refreshResult: 'network_error',
				hasUser: false,
				hadRecoverableState: false,
			}),
		).toBe(true)
	})

	test('does not log out API callers when refresh is temporarily pending or network failed', () => {
		expect(shouldLogoutAfterApiRefreshFailure('network_error')).toBe(false)
		expect(shouldLogoutAfterApiRefreshFailure('unauthorized')).toBe(true)
	})

	test('does not retry an unauthorized request when exactly-once semantics disable auth retry', () => {
		// Given
		const input = {
			retryOnUnauthorized: false,
			isAuthenticated: true,
			hasSessionHint: true,
		}

		// When
		const shouldRetry = shouldRetryRequestAfterUnauthorized(input)

		// Then
		expect(shouldRetry).toBe(false)
	})

	test('keeps auth retry enabled by default for ordinary requests', () => {
		// Given
		const input = {
			retryOnUnauthorized: undefined,
			isAuthenticated: true,
			hasSessionHint: false,
		}

		// When
		const shouldRetry = shouldRetryRequestAfterUnauthorized(input)

		// Then
		expect(shouldRetry).toBe(true)
	})
})
