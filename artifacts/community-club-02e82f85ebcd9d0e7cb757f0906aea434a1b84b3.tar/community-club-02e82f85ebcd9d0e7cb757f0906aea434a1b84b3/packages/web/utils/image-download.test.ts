import { describe, expect, test } from 'bun:test'
import { canOfferImageSave, getImageDownloadFileName } from './image-download'

describe('image download helpers', () => {
	test('allows saving when an image has a source but no explicit download URL', () => {
		expect(
			canOfferImageSave({
				src: 'https://media.example.com/image/photo.jpg',
				downloadUrl: null,
				downloadable: undefined,
			}),
		).toBe(true)
	})

	test('keeps explicit disabled downloads disabled', () => {
		expect(
			canOfferImageSave({
				src: 'https://media.example.com/image/photo.jpg',
				downloadUrl: '/api/media/1/download?index=0',
				downloadable: false,
			}),
		).toBe(false)
	})

	test('builds a safe image filename from title and response type', () => {
		expect(getImageDownloadFileName({ title: 'Пептидные патчи', contentType: 'image/png' })).toBe(
			'Пептидные патчи.png',
		)
	})
})
