export function normalizeNotificationClickUrl(rawUrl: unknown, origin: string): string | null {
	if (typeof rawUrl !== 'string' || rawUrl.trim() === '') {
		return '/'
	}

	try {
		const url = new URL(rawUrl, origin)
		if (url.origin !== origin) return null
		if (!url.pathname.startsWith('/app') && url.pathname !== '/') return null
		return `${url.pathname}${url.search}${url.hash}`
	} catch {
		return null
	}
}
