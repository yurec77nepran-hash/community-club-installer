export type PwaRuntimeSignals = {
	readonly displayModeStandalone: boolean
	readonly navigatorStandalone: boolean
	readonly userAgent: string
	readonly platform: string
	readonly maxTouchPoints: number
}

export type PwaRuntime = {
	readonly isStandalone: boolean
	readonly isIos: boolean
	readonly isAndroid: boolean
	readonly deviceLabel: string
}

export type PwaBannerKind =
	| 'hidden'
	| 'install_prompt'
	| 'installing'
	| 'installed'
	| 'ios_instructions'
	| 'open_app'

export type PwaBannerDecisionInput = {
	readonly isStandalone: boolean
	readonly isIos: boolean
	readonly isAndroid: boolean
	readonly hasInstallPrompt: boolean
	readonly hasStandaloneLaunch: boolean
}

export type PwaInstallState = 'idle' | 'installing' | 'installed'

export type PwaInstallUiEvent =
	| 'install_requested'
	| 'prompt_accepted'
	| 'prompt_dismissed'
	| 'app_installed'

export function shouldRenderPwaBanner(
	bannerKind: PwaBannerKind,
	isOnboardingOpen: boolean,
): boolean {
	return bannerKind !== 'hidden' && !isOnboardingOpen
}

const standaloneLaunchesByDocument = new WeakMap<object, Set<string>>()

export function nextPwaInstallState(
	state: PwaInstallState,
	event: PwaInstallUiEvent,
): PwaInstallState {
	switch (event) {
		case 'install_requested':
		case 'prompt_accepted':
			return state === 'installed' ? 'installed' : 'installing'
		case 'prompt_dismissed':
			return state === 'installed' ? 'installed' : 'idle'
		case 'app_installed':
			return 'installed'
	}
}

export function claimStandaloneLaunch(documentIdentity: object, userId: string): boolean {
	const reportedUserIds = standaloneLaunchesByDocument.get(documentIdentity)
	if (reportedUserIds?.has(userId)) return false

	if (reportedUserIds) reportedUserIds.add(userId)
	else standaloneLaunchesByDocument.set(documentIdentity, new Set([userId]))

	return true
}

export function openInstalledPwa(
	openContext: (url: string, target: string, features: string) => unknown,
): void {
	openContext('/app?pwa-open=1', '_blank', 'noopener')
}

export function detectPwaRuntime(signals: PwaRuntimeSignals): PwaRuntime {
	const userAgent = signals.userAgent.toLowerCase()
	const isAndroid = userAgent.includes('android')
	const isNativeIos = /iphone|ipad|ipod/.test(userAgent)
	const isTouchMacintosh =
		(userAgent.includes('macintosh') || signals.platform === 'MacIntel') &&
		signals.maxTouchPoints > 1
	const isIos = isNativeIos || isTouchMacintosh

	let deviceLabel = signals.platform || 'Web'
	if (isTouchMacintosh || userAgent.includes('ipad')) deviceLabel = 'iPadOS'
	else if (isNativeIos) deviceLabel = 'iOS'
	else if (userAgent.includes('android')) deviceLabel = 'Android'
	else if (userAgent.includes('windows')) deviceLabel = 'Windows'
	else if (userAgent.includes('macintosh')) deviceLabel = 'macOS'
	else if (userAgent.includes('linux')) deviceLabel = 'Linux'

	return {
		isStandalone: signals.displayModeStandalone || signals.navigatorStandalone,
		isIos,
		isAndroid,
		deviceLabel,
	}
}

export function selectPwaBanner(input: PwaBannerDecisionInput): PwaBannerKind {
	if (input.isStandalone) return 'hidden'
	if (input.isIos) return 'ios_instructions'
	if (!input.isAndroid) return 'hidden'
	if (input.hasStandaloneLaunch) return 'open_app'
	if (input.hasInstallPrompt) return 'install_prompt'
	return 'hidden'
}
