export const AVATAR_FILE_ACCEPT =
	'image/jpeg,image/png,image/webp,image/gif,image/avif,image/heic,image/heif'
export const AVATAR_MAX_BYTES = 15 * 1024 * 1024

const AVATAR_IMAGE_TYPES = new Set(AVATAR_FILE_ACCEPT.split(','))
const AVATAR_IMAGE_EXTENSIONS = new Set([
	'jpg',
	'jpeg',
	'png',
	'webp',
	'gif',
	'avif',
	'heic',
	'heif',
])

function getFileExtension(fileName: string) {
	return fileName.split('.').pop()?.trim().toLowerCase() ?? ''
}

export function getAvatarFileError(file: { name: string; size: number; type?: string | null }) {
	const type = file.type?.trim().toLowerCase() ?? ''
	const isSupportedImage =
		AVATAR_IMAGE_TYPES.has(type) ||
		(!type && AVATAR_IMAGE_EXTENSIONS.has(getFileExtension(file.name)))

	if (!isSupportedImage) {
		return 'Выберите фото в формате JPEG, PNG, WebP, GIF, AVIF или HEIC.'
	}

	if (file.size > AVATAR_MAX_BYTES) {
		return 'Фото слишком большое. Выберите файл до 15 МБ.'
	}

	return null
}
