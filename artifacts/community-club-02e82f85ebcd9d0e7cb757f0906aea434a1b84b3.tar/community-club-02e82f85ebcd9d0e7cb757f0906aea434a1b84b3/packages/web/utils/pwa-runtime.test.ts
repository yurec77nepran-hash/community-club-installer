import { describe, expect, test } from 'bun:test'
import {
	claimStandaloneLaunch,
	detectPwaRuntime,
	nextPwaInstallState,
	openInstalledPwa,
	selectPwaBanner,
	shouldRenderPwaBanner,
} from './pwa-runtime'

describe('PWA runtime detection', () => {
	test('detects standalone when the display-mode media query matches', () => {
		// Given
		const signals = {
			displayModeStandalone: true,
			navigatorStandalone: false,
			userAgent: 'Mozilla/5.0 (Linux; Android 15)',
			platform: 'Linux armv8l',
			maxTouchPoints: 5,
		}

		// When
		const runtime = detectPwaRuntime(signals)

		// Then
		expect(runtime.isStandalone).toBe(true)
	})

	test('detects Android from the user agent', () => {
		// Given
		const signals = {
			displayModeStandalone: false,
			navigatorStandalone: false,
			userAgent: 'Mozilla/5.0 (Linux; Android 15)',
			platform: 'Linux armv8l',
			maxTouchPoints: 5,
		}

		// When
		const runtime = detectPwaRuntime(signals)

		// Then
		expect(runtime.isAndroid).toBe(true)
	})

	test('detects standalone through the iOS navigator flag', () => {
		// Given
		const signals = {
			displayModeStandalone: false,
			navigatorStandalone: true,
			userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)',
			platform: 'iPhone',
			maxTouchPoints: 5,
		}

		// When
		const runtime = detectPwaRuntime(signals)

		// Then
		expect(runtime.isStandalone).toBe(true)
	})

	test('detects touch-enabled Macintosh as iPadOS', () => {
		// Given
		const signals = {
			displayModeStandalone: false,
			navigatorStandalone: false,
			userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15',
			platform: 'MacIntel',
			maxTouchPoints: 5,
		}

		// When
		const runtime = detectPwaRuntime(signals)

		// Then
		expect(runtime.isIos).toBe(true)
		expect(runtime.deviceLabel).toBe('iPadOS')
	})

	test('does not classify a non-touch Macintosh as iOS', () => {
		// Given
		const signals = {
			displayModeStandalone: false,
			navigatorStandalone: false,
			userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
			platform: 'MacIntel',
			maxTouchPoints: 0,
		}

		// When
		const runtime = detectPwaRuntime(signals)

		// Then
		expect(runtime.isIos).toBe(false)
		expect(runtime.deviceLabel).toBe('macOS')
	})
})

describe('PWA banner decision', () => {
	test('suppresses a non-hidden banner while onboarding is open', () => {
		// Given
		const bannerKind = 'install_prompt'

		// When
		const result = shouldRenderPwaBanner(bannerKind, true)

		// Then
		expect(result).toBe(false)
	})

	test('renders a non-hidden banner after onboarding closes', () => {
		// Given
		const bannerKind = 'install_prompt'

		// When
		const result = shouldRenderPwaBanner(bannerKind, false)

		// Then
		expect(result).toBe(true)
	})

	test('suppresses a hidden banner after onboarding closes', () => {
		// Given
		const bannerKind = 'hidden'

		// When
		const result = shouldRenderPwaBanner(bannerKind, false)

		// Then
		expect(result).toBe(false)
	})

	test('hides the banner in standalone mode', () => {
		// Given
		const input = {
			isStandalone: true,
			isIos: false,
			isAndroid: true,
			hasInstallPrompt: true,
			hasStandaloneLaunch: false,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('hidden')
	})

	test('hides an installed iOS app', () => {
		// Given
		const input = {
			isStandalone: true,
			isIos: true,
			isAndroid: false,
			hasInstallPrompt: true,
			hasStandaloneLaunch: true,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('hidden')
	})

	test('offers the captured Chromium install prompt before first standalone launch', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: false,
			isAndroid: true,
			hasInstallPrompt: true,
			hasStandaloneLaunch: false,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('install_prompt')
	})

	test('offers manual instructions on iOS before first standalone launch', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: true,
			isAndroid: false,
			hasInstallPrompt: false,
			hasStandaloneLaunch: false,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('ios_instructions')
	})

	test('hides the banner on desktop without an install action', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: false,
			isAndroid: false,
			hasInstallPrompt: false,
			hasStandaloneLaunch: false,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('hidden')
	})

	test('hides the banner on desktop despite install prompt and standalone history', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: false,
			isAndroid: false,
			hasInstallPrompt: true,
			hasStandaloneLaunch: true,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('hidden')
	})

	test('opens Android app when PostgreSQL has a standalone launch', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: false,
			isAndroid: true,
			hasInstallPrompt: false,
			hasStandaloneLaunch: true,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('open_app')
	})

	test('opens iOS instructions even with install prompt or standalone history', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: true,
			isAndroid: false,
			hasInstallPrompt: true,
			hasStandaloneLaunch: true,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('ios_instructions')
	})

	test('hides Android browser without install prompt or standalone history', () => {
		// Given
		const input = {
			isStandalone: false,
			isIos: false,
			isAndroid: true,
			hasInstallPrompt: false,
			hasStandaloneLaunch: false,
		}

		// When
		const result = selectPwaBanner(input)

		// Then
		expect(result).toBe('hidden')
	})
})

describe('PWA document lifecycle', () => {
	test('enters installing state when installation is requested', () => {
		// Given
		const state = 'idle'

		// When
		const result = nextPwaInstallState(state, 'install_requested')

		// Then
		expect(result).toBe('installing')
	})

	test('remains installing when the install prompt is accepted', () => {
		// Given
		const state = 'installing'

		// When
		const result = nextPwaInstallState(state, 'prompt_accepted')

		// Then
		expect(result).toBe('installing')
	})

	test('returns to idle when the install prompt is dismissed', () => {
		// Given
		const state = 'installing'

		// When
		const result = nextPwaInstallState(state, 'prompt_dismissed')

		// Then
		expect(result).toBe('idle')
	})

	test('enters installed state only when appinstalled fires', () => {
		// Given
		const state = 'installing'

		// When
		const result = nextPwaInstallState(state, 'app_installed')

		// Then
		expect(result).toBe('installed')
	})

	test('keeps installed state when userChoice resolves after appinstalled', () => {
		// Given
		const state = nextPwaInstallState('installing', 'app_installed')

		// When
		const result = nextPwaInstallState(state, 'prompt_accepted')

		// Then
		expect(result).toBe('installed')
	})

	test('claims one standalone launch per user within the same document', () => {
		// Given
		const documentIdentity = {}

		// When
		const firstUserInitialClaim = claimStandaloneLaunch(documentIdentity, 'user-a')
		const firstUserDuplicateClaim = claimStandaloneLaunch(documentIdentity, 'user-a')
		const secondUserInitialClaim = claimStandaloneLaunch(documentIdentity, 'user-b')
		const nextDocumentInitialClaim = claimStandaloneLaunch({}, 'user-a')

		// Then
		expect(firstUserInitialClaim).toBe(true)
		expect(firstUserDuplicateClaim).toBe(false)
		expect(secondUserInitialClaim).toBe(true)
		expect(nextDocumentInitialClaim).toBe(true)
	})

	test('opens an in-scope route in a new top-level context', () => {
		// Given
		const navigations: Array<readonly [string, string, string]> = []
		const openContext = (url: string, target: string, features: string) => {
			navigations.push([url, target, features])
			return null
		}

		// When
		openInstalledPwa(openContext)

		// Then
		expect(navigations).toEqual([['/app?pwa-open=1', '_blank', 'noopener']])
	})
})
