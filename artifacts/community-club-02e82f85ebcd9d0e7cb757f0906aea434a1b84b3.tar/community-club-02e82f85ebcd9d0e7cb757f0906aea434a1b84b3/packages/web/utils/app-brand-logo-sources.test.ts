import { describe, expect, it } from 'bun:test'
import { readFileSync } from 'node:fs'

const sources = {
	appHeader: readFileSync(new URL('../components/app/AppHeader.vue', import.meta.url), 'utf8'),
	appMenu: readFileSync(new URL('../components/app/AppMenu.vue', import.meta.url), 'utf8'),
	homeLogo: readFileSync(new URL('../components/HomeLogo.vue', import.meta.url), 'utf8'),
	introSplash: readFileSync(
		new URL('../components/app/AppIntroSplash.vue', import.meta.url),
		'utf8',
	),
	adminSettings: readFileSync(
		new URL('../../admin/components/AdminSettingsWorkspace.vue', import.meta.url),
		'utf8',
	),
} as const

function imageTagsContaining(source: string, marker: string): readonly string[] {
	return [...source.matchAll(/<img\b[\s\S]*?>/g)]
		.map(([tag]) => tag)
		.filter((tag) => tag.includes(marker))
}

function expectCriticalLogo(tag: string): void {
	expect(tag).toContain('width="512"')
	expect(tag).toContain('height="512"')
	expect(tag).toContain('loading="eager"')
	expect(tag).toContain('fetchpriority="high"')
	expect(tag).toContain('decoding="async"')
}

describe('app brand logo sources', () => {
	it('uses the canonical endpoint for every saved club logo branch', () => {
		const headerLogos = imageTagsContaining(sources.appHeader, 'app-header-logo-image')
		expect(headerLogos).toHaveLength(2)
		for (const tag of headerLogos) {
			expect(tag).toContain(`:src="'/pwa-icon?size=512&format=webp'"`)
		}

		expect(imageTagsContaining(sources.introSplash, '/pwa-icon?size=512&format=webp')).toHaveLength(
			1,
		)
		expect(imageTagsContaining(sources.homeLogo, '/pwa-icon?size=512&format=webp')).toHaveLength(1)
	})

	it('keeps the configured center-button image ahead of the dynamic fallback', () => {
		expect(sources.appMenu).toContain(
			`:src="settings.menu.centerButton.imageUrl || '/pwa-icon?size=512&format=webp'"`,
		)
	})

	it('marks first-screen app logo images as eager high-priority async-decoded images with dimensions', () => {
		const logoTags = [
			...imageTagsContaining(sources.appHeader, 'app-header-logo-image'),
			...imageTagsContaining(sources.appMenu, 'app-menu-center-image'),
			...imageTagsContaining(sources.introSplash, '/pwa-icon?size=512&format=webp'),
			...imageTagsContaining(sources.homeLogo, 'club-home-logo-image'),
		]
		expect(logoTags).toHaveLength(5)
		for (const tag of logoTags) {
			expectCriticalLogo(tag)
		}
	})

	it('keeps the unsaved admin logo URL direct and gives its preview stable dimensions', () => {
		const [previewTag] = imageTagsContaining(sources.adminSettings, ':src="previewLogoUrl"')
		expect(previewTag).toBeDefined()
		expect(sources.adminSettings).toMatch(
			/selectedImage\.value &&[\s\S]*?form\.homeLogoMediaKey !== savedLogoMediaKey[\s\S]*?return selectedImage\.value\.url[\s\S]*?`\/pwa-icon\?size=512&format=webp&v=\$\{encodeURIComponent\(savedLogoMediaKey\)\}`/,
		)
		expect(previewTag).toContain('width="512"')
		expect(previewTag).toContain('height="512"')
		expect(previewTag).toContain('loading="lazy"')
		expect(previewTag).toContain('decoding="async"')
		expect(previewTag).not.toContain('/pwa-icon')
	})

	it('does not reference legacy logo assets in app components', () => {
		for (const source of [
			sources.appHeader,
			sources.appMenu,
			sources.homeLogo,
			sources.introSplash,
		]) {
			expect(source).not.toContain('/icons/gold-black-emblem.svg')
			expect(source).not.toContain('/icons/logo_234_gold.png')
		}
	})
})
