import type { ChatMessage } from '../stores/chat'

export function getChatMessageDeleteTarget(messages: ChatMessage[], messageId: number) {
	const message = messages.find((item) => item.id === messageId)
	if (!message) return null

	return {
		id: message.id,
		clientMessageId: message.clientMessageId ?? null,
		persisted: message.id > 0,
	}
}
