export type SessionRefreshResult = 'success' | 'unauthorized' | 'network_error'

export function shouldAttemptRefreshDuringRestore(params: {
	hasAccessToken: boolean
	hasUser: boolean
}) {
	return !(params.hasAccessToken && params.hasUser)
}

export function shouldLogoutAfterRestoreFailure(params: {
	refreshResult: Exclude<SessionRefreshResult, 'success'>
	hasUser: boolean
	hadRecoverableState: boolean
}) {
	if (params.refreshResult === 'unauthorized') {
		return true
	}

	return !params.hasUser && !params.hadRecoverableState
}

export function shouldLogoutAfterApiRefreshFailure(
	refreshResult: Exclude<SessionRefreshResult, 'success'>,
) {
	return refreshResult === 'unauthorized'
}

export function shouldRetryRequestAfterUnauthorized(params: {
	readonly retryOnUnauthorized: boolean | undefined
	readonly isAuthenticated: boolean
	readonly hasSessionHint: boolean
}) {
	return params.retryOnUnauthorized !== false && (params.isAuthenticated || params.hasSessionHint)
}
