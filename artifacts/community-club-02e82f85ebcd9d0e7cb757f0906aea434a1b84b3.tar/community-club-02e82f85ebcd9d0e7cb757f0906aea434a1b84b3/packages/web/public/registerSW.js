const RECOVERY_RELOAD_KEY = 'pwa-recovery-reloaded'

function handleServiceWorkerUpdateError(error) {
	if (error instanceof TypeError) return
	if (error instanceof DOMException) {
		switch (error.name) {
			case 'AbortError':
			case 'InvalidStateError':
			case 'NetworkError':
				return
		}
	}
	throw error
}

function getRecoveryMessage(reason) {
	if (typeof reason === 'string') return reason
	if (reason instanceof Error) return reason.message
	if (reason && typeof reason.message === 'string') return reason.message
	return ''
}

function shouldRecoverFromStartupError(message) {
	if (!message) return false

	return (
		message.includes('can\'t access property "default"') ||
		message.includes("Cannot read properties of undefined (reading 'default')") ||
		message.includes('Failed to fetch dynamically imported module') ||
		message.includes('Importing a module script failed') ||
		message.includes('Unable to preload CSS') ||
		(message.includes('/_nuxt/') &&
			(message.includes('не удалась') ||
				message.includes('failed') ||
				message.includes('error loading module')))
	)
}

async function hardRecoverApp() {
	if (sessionStorage.getItem(RECOVERY_RELOAD_KEY) === '1') {
		return
	}

	sessionStorage.setItem(RECOVERY_RELOAD_KEY, '1')

	try {
		if ('serviceWorker' in navigator) {
			const registrations = await navigator.serviceWorker.getRegistrations()
			await Promise.all(
				registrations.map((registration) =>
					registration.update().then(() => undefined, handleServiceWorkerUpdateError),
				),
			)
		}
	} finally {
		window.location.reload()
	}
}

window.addEventListener('error', (event) => {
	const target = event.target
	if (target instanceof HTMLScriptElement) {
		void hardRecoverApp()
		return
	}

	if (shouldRecoverFromStartupError(getRecoveryMessage(event.error))) {
		void hardRecoverApp()
	}
})

window.addEventListener('unhandledrejection', (event) => {
	if (shouldRecoverFromStartupError(getRecoveryMessage(event.reason))) {
		event.preventDefault()
		void hardRecoverApp()
	}
})
