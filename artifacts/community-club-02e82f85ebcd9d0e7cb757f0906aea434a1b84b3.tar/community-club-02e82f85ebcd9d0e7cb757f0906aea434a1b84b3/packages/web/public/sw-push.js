// Service Worker для Push уведомлений
// Этот файл работает отдельно от основного SW (workbox)

self.addEventListener('push', (event) => {
	if (!event.data) return

	const data = event.data.json()
	const { title, body, url, icon, badge } = data

	const options = {
		body,
		icon: icon || '/icons/icon-192x192.png',
		badge: badge || '/icons/icon-192x192.png',
		vibrate: [100, 50, 100],
		data: { url: url || '/' },
		actions: [
			{ action: 'open', title: 'Открыть' },
			{ action: 'close', title: 'Закрыть' },
		],
	}

	event.waitUntil(self.registration.showNotification(title, options))
})

function normalizeNotificationUrl(rawUrl) {
	try {
		const url = new URL(rawUrl || '/', self.location.origin)
		if (url.origin !== self.location.origin) return '/'
		if (!url.pathname.startsWith('/app') && url.pathname !== '/') return '/'
		return `${url.pathname}${url.search}${url.hash}`
	} catch {
		return '/'
	}
}

function isSameOriginClient(client) {
	try {
		return new URL(client.url).origin === self.location.origin
	} catch {
		return false
	}
}

function isAppClient(client) {
	try {
		const url = new URL(client.url)
		return url.origin === self.location.origin && url.pathname.startsWith('/app')
	} catch {
		return false
	}
}

async function openNotificationTarget(rawUrl) {
	const path = normalizeNotificationUrl(rawUrl)
	const targetUrl = new URL(path, self.location.origin).href
	const clientList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true })
	const existingClient =
		clientList.find((client) => isAppClient(client) && 'focus' in client) ??
		clientList.find((client) => isSameOriginClient(client) && 'focus' in client)

	if (!existingClient) {
		return self.clients.openWindow(targetUrl)
	}

	existingClient.postMessage({ type: 'COMMUNITY_NOTIFICATION_CLICK', url: path })

	if ('navigate' in existingClient) {
		try {
			const navigatedClient = await existingClient.navigate(targetUrl)
			return (navigatedClient || existingClient).focus()
		} catch {
			return existingClient.focus()
		}
	}

	return existingClient.focus()
}

self.addEventListener('notificationclick', (event) => {
	event.notification.close()

	const url = event.notification.data?.url || '/'

	if (event.action === 'close') return

	event.waitUntil(openNotificationTarget(url))
})

self.addEventListener('pushsubscriptionchange', (event) => {
	event.waitUntil(
		(async () => {
			if (!event.newSubscription) return
			const json = event.newSubscription.toJSON()
			if (!json.endpoint || !json.keys) return

			try {
				await fetch('/api/push/subscribe', {
					method: 'POST',
					credentials: 'include',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify({
						endpoint: json.endpoint,
						keys: json.keys,
						expirationTime: event.newSubscription.expirationTime || null,
						permission: self.Notification?.permission || null,
						userAgent: self.navigator?.userAgent || null,
						platform: self.navigator?.platform || null,
						deviceLabel: 'Service Worker',
					}),
				})
			} catch {}
		})(),
	)
})
