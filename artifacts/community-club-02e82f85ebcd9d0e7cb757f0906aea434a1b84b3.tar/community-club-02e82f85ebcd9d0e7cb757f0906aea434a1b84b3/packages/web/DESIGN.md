# Community Club Light Premium Tech Design System

## 1. Atmosphere & Identity

Community Club feels warm, precise, and quietly premium: a light technical workspace built from ivory canvas, white layered surfaces, graphite typography, and restrained gold hardware details. The signature is soft dimensional layering, where warm tonal steps, fine borders, and diffuse shadows preserve the existing premium 3D character without dark application chrome.

## 2. Color

### Palette

| Role | CSS token | Value | Usage |
| --- | --- | --- | --- |
| Canvas | `--app-bg` | `#F7F5F0` | Page and PWA background |
| Canvas/deep | `--app-bg-deep` | `#F1EEE7` | Warm secondary layer and gradients |
| Surface | `--app-surface` | `#FFFFFF` | Cards, inputs, navigation, popovers |
| Surface/raised | `--app-surface-raised` | `#FFFFFF` | Elevated cards and overlays |
| Border | `--app-border` | `#E6DDCC` | Dividers and component outlines |
| Text/primary | `--app-text`, `--app-text-strong` | `#1F1F1F` | Body, headings, controls |
| Text/secondary | `--app-muted` | `#5C5C5C` | Supporting copy and inactive navigation |
| Text/muted | `--app-muted-soft` | `#8A8A8A` | Metadata, placeholders, disabled states |
| Gold | `--app-accent`, `--app-button-bg` | `#D4A62A` | Primary actions and premium details |
| Gold/dark | `--app-accent-strong` | `#A97800` | Links, active icons, hover/focus definition |
| Checklists | `--app-accent-violet` | `#7A5AF8` | Checklist material identity |
| Courses | `--app-accent-blue` | `#4DA3FF` | Course material identity |
| Other | `--app-accent-amber` | `#F2A900` | Other material identity |
| Streams | `--app-accent-wine` | `#A6465D` | Stream material identity and destructive emphasis |
| Experts | `--app-accent-slate` | `#6E7C91` | Expert material identity and quiet status emphasis |

### Rules

- These values are the complete visual palette. Alpha and `color-mix()` variants may derive only from these tokens.
- Runtime branding may override only `--app-accent`, `--app-accent-strong`, `--app-button-bg`, and its computed foreground. Runtime neutral background, surface, and text settings remain API-compatible but are not applied visually.
- Gold is reserved for primary interaction, active navigation, focus, and small premium details. Section accents identify material types.
- Dark neutrals are allowed only inside explicit image/video overlays where they protect media legibility; they are not application surfaces.

## 3. Typography

The existing system stack is preserved to avoid font-loading and layout changes: `ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`. Existing page and component type sizes, weights, line heights, and tracking remain unchanged during the foundation migration. New work must reuse the established Tailwind scale and existing component typography rather than add ad-hoc sizes.

## 4. Spacing & Layout

The base spacing unit is 4px. Existing Tailwind spacing steps, the mobile-first single viewport, the 430px desktop app viewport, safe-area offsets, header/menu reserves, breakpoints, radii, and responsive structure are preserved exactly. This foundation changes material and color only; it does not change dimensions, grid, content order, or scroll ownership.

## 5. Components

### Layered surface (`.glass`, `.glass-strong`, `.glass-card`, `.club-card`)
- **Structure:** existing containers and slots remain unchanged.
- **Material:** white or warm-white layers, warm border, inset highlight, diffuse shadow.
- **States:** existing hover, active, focus, loading, and disabled behavior is preserved.
- **Accessibility:** content uses graphite text; focus uses gold definition.

### Input (`.glass-input`)
- **Material:** white fill, warm border, graphite input/caret, muted placeholder.
- **States:** focus uses gold border/ring; autofill remains light; secure inputs use the same contract.
- **Accessibility:** browser light color scheme and visible focus remain mandatory.

### Navigation (`.glass-header`, `.glass-nav`, app menu settings)
- **Material:** translucent white chrome with warm border and soft elevation.
- **States:** dark-gold active icon, secondary inactive icon, existing press/glow behavior unchanged.
- **Data rule:** server navigation can change structure and behavior but cannot restore dark neutral chrome.

### Skeleton (`.app-skeleton-*`)
- **Material:** warm secondary base with a white-to-border shimmer.
- **Motion:** existing transform-only shimmer timing remains unchanged.

### Chat shell (`.club-chat-*`, `.chat-pattern`)
- **Material:** warm canvas, white composer/header/results, light message surfaces, gold club accents.
- **Media exception:** black translucent scrims over image/video content remain dark for contrast.
- **Behavior:** fixed shell, sticky header, scrolling, composer, gestures, and animations remain unchanged.

## 6. Motion & Interaction

Existing motion durations, easing, transforms, active scales, skeleton shimmer, and menu waves are preserved. This foundation introduces no new animation or behavior. New motion must use `transform`, `opacity`, or `filter`, and `prefers-reduced-motion` remains the required escape hatch for future non-essential motion.

## 7. Depth & Surface

The strategy is mixed tonal layering plus soft shadows. `--app-shadow-soft` separates resting cards, `--app-shadow-raised` lifts navigation and interactive surfaces, and `--app-shadow-floating` is reserved for floating controls and overlays. Borders use `--app-border`; inset highlights derive from white. Harsh black shadows and dark glass are not application materials.

## 8. Accessibility Constraints & Migration Scope

### Constraints

- Target WCAG 2.2 AA: 4.5:1 for body text and 3:1 for large text and essential UI boundaries.
- Graphite is the default text on every light application surface; muted colors are not used for essential controls without stronger state styling.
- Every interactive element retains visible keyboard focus, keyboard reachability, touch target geometry, and existing semantic markup.
- Dark media scrims must remain local to media and never leak into surrounding chrome.

### Migration Scope

- The Light Premium Tech migration covers the full application surface: shared shell and primitives plus feature pages and feature-specific feed, chat, material, media, and payment components.
- Feature-local application surfaces follow the same light canvas, white surface, graphite text, token-derived color, and warm depth rules as shared primitives.
- Dark neutrals remain a deliberate local exception only for explicit image and video overlays where media legibility requires them.
- Responsive browser verification is part of application-surface migration QA rather than deferred feature debt.
