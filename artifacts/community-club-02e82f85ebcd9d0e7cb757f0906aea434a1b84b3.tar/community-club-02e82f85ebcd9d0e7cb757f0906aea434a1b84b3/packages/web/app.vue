<script setup lang="ts">
import CookieBanner from '~/components/legal/CookieBanner.vue'

const route = useRoute()
const auth = useAuthStore()
const push = usePush()
const splashVisible = ref(route.path.startsWith('/app'))
let splashTimer: ReturnType<typeof setTimeout> | undefined

function startSplash() {
	clearTimeout(splashTimer)
	splashVisible.value = true
	const introStartedAt = Number(
		(window as Window & { __clubIntroStartedAt?: number }).__clubIntroStartedAt ?? Date.now(),
	)
	const remaining = Math.max(0, 3000 - (Date.now() - introStartedAt))
	splashTimer = setTimeout(() => {
		splashVisible.value = false
	}, remaining)
}

onMounted(() => {
	if (splashVisible.value) startSplash()
})

watch(
	() => auth.isAuthenticated,
	(isAuthenticated) => {
		if (isAuthenticated) void push.refreshStatus()
	},
	{ immediate: true },
)

watch(
	() => route.path,
	(path, previousPath) => {
		if (path.startsWith('/app') && !previousPath?.startsWith('/app')) startSplash()
	},
)

onUnmounted(() => clearTimeout(splashTimer))
</script>

<template>
	<div class="app-shell-bg app-shell-root min-h-screen">
		<div class="app-viewport">
			<NuxtLayout>
				<NuxtPage />
			</NuxtLayout>
		</div>
		<CookieBanner />
		<Transition name="app-intro-splash">
			<AppIntroSplash v-if="splashVisible" />
		</Transition>
	</div>
</template>

<style scoped>
.app-intro-splash-leave-active { transition: opacity 0.24s ease; }
.app-intro-splash-leave-to { opacity: 0; }
</style>
