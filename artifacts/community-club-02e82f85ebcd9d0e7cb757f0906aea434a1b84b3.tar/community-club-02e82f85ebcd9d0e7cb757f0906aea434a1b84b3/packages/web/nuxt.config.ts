const apiUrl = process.env.API_URL ?? process.env.NUXT_PUBLIC_API_URL ?? 'http://localhost:3001'
const devApiProxyTarget = process.env.NUXT_DEV_API_PROXY_TARGET

export default defineNuxtConfig({
	compatibilityDate: '2025-01-01',
	devtools: { enabled: process.env.NODE_ENV === 'development' },

	experimental: {
		appManifest: false,
		defaults: {
			nuxtLink: {
				prefetch: false,
			},
		},
		emitRouteChunkError: false,
		renderJsonPayloads: false,
	},

	modules: ['@nuxtjs/tailwindcss', '@pinia/nuxt', '@vite-pwa/nuxt'],

	// SSR для публичных, SPA для авторизованных
	ssr: true,
	routeRules: {
		'/': { headers: { 'cache-control': 'no-store, max-age=0, must-revalidate' } },
		'/login': { headers: { 'cache-control': 'no-store, max-age=0, must-revalidate' } },
		'/register': { headers: { 'cache-control': 'no-store, max-age=0, must-revalidate' } },
		'/reset-password': { headers: { 'cache-control': 'no-store, max-age=0, must-revalidate' } },
		'/pwa-manifest': {
			headers: {
				'cache-control': 'no-store, max-age=0, must-revalidate',
				'content-type': 'application/manifest+json',
			},
		},
		'/app/**': {
			ssr: false,
			headers: { 'cache-control': 'no-store, max-age=0, must-revalidate' },
		},
	},

	runtimeConfig: {
		public: {
			apiUrl,
		},
	},

	vite: {
		build: {
			chunkSizeWarningLimit: 600,
			rollupOptions: {
				output: {
					manualChunks(id) {
						if (!id.includes('node_modules')) return

						if (
							id.includes('/vue/') ||
							id.includes('/vue-router/') ||
							id.includes('/pinia/') ||
							id.includes('/nuxt/') ||
							id.includes('/@vue/')
						) {
							return 'framework-core'
						}

						if (id.includes('radix-vue') || id.includes('reka-ui') || id.includes('vee-validate')) {
							return 'forms-ui'
						}

						if (
							id.includes('hls.js') ||
							id.includes('vue-virtual-scroller') ||
							id.includes('@iconify')
						) {
							return 'media-vendor'
						}

						if (id.includes('/@formkit/')) {
							return 'app-utils'
						}

						return 'vendor'
					},
				},
			},
		},
	},

	nitro: {
		devProxy: devApiProxyTarget
			? {
					'/api': {
						target: devApiProxyTarget,
						changeOrigin: true,
					},
				}
			: undefined,
		esbuild: {
			options: {
				target: 'es2020',
			},
		},
	},

	// PWA
	pwa: {
		registerType: 'autoUpdate',
		client: {
			registerPlugin: false,
		},
		manifest: false,
		workbox: {
			importScripts: ['/sw-push.js'],
			navigateFallback: null,
			skipWaiting: true,
			clientsClaim: true,
			runtimeCaching: [],
		},
	},

	// Tailwind
	tailwindcss: {
		cssPath: '~/assets/css/main.css',
	},

	// Auto-imports
	imports: {
		dirs: ['stores', 'composables'],
	},

	// App config
	app: {
		head: {
			title: 'Community Club',
			meta: [
				{ name: 'viewport', content: 'width=device-width, initial-scale=1, maximum-scale=1' },
				{ name: 'theme-color', content: '#F7F5F0' },
				{ name: 'mobile-web-app-capable', content: 'yes' },
				{ name: 'apple-mobile-web-app-capable', content: 'yes' },
				{ name: 'apple-mobile-web-app-status-bar-style', content: 'default' },
			],
			link: [
				{
					rel: 'preload',
					as: 'image',
					href: '/pwa-icon?size=512&format=webp',
					fetchpriority: 'high',
				},
				{
					rel: 'icon',
					href: '/pwa-icon?size=192&purpose=favicon',
				},
				{
					rel: 'apple-touch-icon',
					href: '/pwa-icon?size=192&purpose=apple',
				},
				{ rel: 'manifest', href: '/pwa-manifest' },
			],
			style: [
				{
					children:
						'html,body,#__nuxt{min-height:100%;margin:0;background:#F7F5F0;color:#1F1F1F;}body,#__nuxt{background:linear-gradient(180deg,#F7F5F0 0%,#FFFFFF 52%,#F1EEE7 100%) fixed;}',
				},
			],
			script: [{ src: '/registerSW.js' }],
		},
	},
})
