import { useAuthStore } from '~/stores/auth'

export default defineNuxtRouteMiddleware(async (to) => {
	const auth = useAuthStore()
	auth.init()

	if (to.path === '/admin' || to.path.startsWith('/admin/')) {
		const path = to.fullPath.replace(/^\/admin(?=\/|$)/, '') || '/'
		return navigateTo(`/admin${path}`, { external: true, replace: true })
	}

	if (to.path === '/login' || to.path === '/login/') {
		const { ok } = await auth.fetchMe()
		if (ok) return navigateTo('/')
		return
	}

	if (!auth.user) {
		const { ok } = await auth.fetchMe()
		if (!ok) {
			auth.logout()
			return navigateTo('/login')
		}
	}
})
