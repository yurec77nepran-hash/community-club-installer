<script setup lang="ts">
import { useDarkMode } from '~/composables/useDarkMode'

const { init } = useDarkMode()
onMounted(() => init())
</script>

<template>
	<div class="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-primary-50">
		<slot />
	</div>
</template>
