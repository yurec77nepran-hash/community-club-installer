<script setup lang="ts">
import { useDarkMode } from '~/composables/useDarkMode'
import { useAuthStore } from '~/stores/auth'

const auth = useAuthStore()
const { init } = useDarkMode()
const isMobile = ref(false)
const sidebarCollapsed = ref(false)
const mobileMenuOpen = ref(false)
let pageScrollLocked = false
let previousBodyOverflow = ''
let previousHtmlOverflow = ''

function checkViewport() {
	if (!import.meta.client) return
	isMobile.value = window.innerWidth < 768
	if (!isMobile.value) mobileMenuOpen.value = false
}

function setPageScrollLocked(locked: boolean) {
	if (!import.meta.client || locked === pageScrollLocked) return
	pageScrollLocked = locked
	if (locked) {
		previousBodyOverflow = document.body.style.overflow
		previousHtmlOverflow = document.documentElement.style.overflow
		document.body.style.overflow = 'hidden'
		document.documentElement.style.overflow = 'hidden'
		return
	}
	document.body.style.overflow = previousBodyOverflow
	document.documentElement.style.overflow = previousHtmlOverflow
}

onMounted(() => {
	init()
	checkViewport()
	window.addEventListener('resize', checkViewport)
})

onUnmounted(() => {
	if (import.meta.client) window.removeEventListener('resize', checkViewport)
	setPageScrollLocked(false)
})

const navItems = [
	{ to: '/', label: 'Аналитика', icon: 'chart', permission: 'analytics' },
	{ to: '/users', label: 'Пользователи', icon: 'users', permission: 'users' },
	{
		to: '/user-actions',
		label: 'Действия участников',
		icon: 'activity',
		permission: 'userActions',
	},
	{ to: '/support', label: 'Поддержка', icon: 'support', permission: 'support' },
	{ to: '/events', label: 'События', icon: 'calendar', permission: 'events' },
	{ to: '/design', label: 'Дизайн', icon: 'design', permission: 'settings' },
	{ to: '/materials', label: 'Материалы', icon: 'book', permission: 'materials' },
	{ to: '/media', label: 'Медиа', icon: 'media', permission: 'media' },
	{ to: '/chats', label: 'Чаты', icon: 'chat', permission: 'chats' },
	{
		to: '/payments?tab=providers',
		label: 'Платежи',
		icon: 'payments',
		permission: 'payments',
	},
	{ to: '/referrals', label: 'Рефералка', icon: 'tag', permission: 'referrals' },
	{ to: '/documents', label: 'Документы', icon: 'document', permission: 'documents' },
	{ to: '/settings', label: 'Настройки', icon: 'settings', permission: 'settings' },
	{
		to: '/staff-actions',
		label: 'Действия сотрудников',
		icon: 'bell',
		permission: 'staffActions',
	},
	{ to: '/feed', label: 'Лента новостей', icon: 'feed', permission: 'feed' },
	{ to: '/replies', label: 'Лента ответов', icon: 'bell', permission: 'replies' },
	{ to: '/tariffs', label: 'Тарифы', icon: 'tag', permission: 'tariffs' },
	{ to: '/notifications', label: 'Уведомления', icon: 'bell', permission: 'notifications' },
	{
		to: '/telegram-broadcasts',
		label: 'Рассылки',
		icon: 'chat',
		permission: 'telegramBroadcasts',
	},
]

const visibleNavItems = computed(() => {
	if (auth.user?.role === 'superadmin') return navItems
	const permissions = auth.user?.adminPermissions
	if (!permissions || permissions.length === 0) return navItems
	return navItems.filter((item) => permissions.includes(item.permission))
})

const route = useRoute()
watch(
	() => route.path,
	() => {
		if (isMobile.value) mobileMenuOpen.value = false
	},
)

watch(
	() => isMobile.value && mobileMenuOpen.value,
	(locked) => setPageScrollLocked(locked),
)
</script>

<template>
	<div class="admin-shell flex h-[100dvh] min-h-screen overflow-hidden bg-slate-950 text-slate-100">
		<!-- Desktop sidebar -->
		<aside
			v-if="!isMobile"
			class="flex h-[100dvh] min-h-0 flex-col flex-shrink-0 overflow-hidden glass-sidebar transition-all duration-300"
			:class="sidebarCollapsed ? 'w-16' : 'w-60'"
		>
			<div class="h-14 flex shrink-0 items-center border-b border-gray-200/30 dark:border-white/5 px-3 gap-2">
				<button
					class="p-1.5 rounded-xl hover:bg-gray-100/60 dark:hover:bg-white/10 transition text-gray-500 dark:text-gray-400"
					@click="sidebarCollapsed = !sidebarCollapsed"
				>
					<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
					</svg>
				</button>
				<template v-if="!sidebarCollapsed">
					<span class="font-bold text-sm text-slate-900 dark:text-slate-100">Community Club</span>
				</template>
			</div>

			<nav class="min-h-0 flex-1 space-y-0.5 overflow-y-auto overscroll-contain p-2">
				<NuxtLink
					v-for="item in visibleNavItems"
					:key="item.to"
					:to="item.to"
					class="flex items-center gap-3 rounded-2xl text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-100/60 dark:hover:bg-white/10 transition-all duration-200"
					:class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5'"
					active-class="!bg-primary-500/10 dark:!bg-primary-500/15 !text-primary-600 dark:!text-primary-400 font-medium"
					:title="sidebarCollapsed ? item.label : undefined"
				>
					<SidebarIcon :name="item.icon" class="w-5 h-5 flex-shrink-0" />
					<span v-if="!sidebarCollapsed">{{ item.label }}</span>
				</NuxtLink>
			</nav>

			<div class="shrink-0 p-2 border-t border-gray-200/30 dark:border-white/5">
				<button
					class="flex items-center gap-3 w-full rounded-2xl text-sm text-gray-500 dark:text-gray-400 hover:bg-red-50/60 dark:hover:bg-red-500/10 hover:text-red-600 dark:hover:text-red-400 transition-all duration-200"
					:class="sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5'"
					@click="auth.logout()"
				>
					<svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
					</svg>
					<span v-if="!sidebarCollapsed">Выйти</span>
				</button>
			</div>
		</aside>

		<!-- Main content -->
		<div class="flex-1 flex min-h-0 flex-col min-w-0">
			<header class="h-14 glass-header flex items-center justify-between px-4 flex-shrink-0">
				<div class="flex items-center gap-3">
					<button
						v-if="isMobile"
						class="p-1.5 rounded-xl hover:bg-gray-100/60 dark:hover:bg-white/10 transition text-gray-500 dark:text-gray-400"
						@click="mobileMenuOpen = !mobileMenuOpen"
					>
						<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
						</svg>
					</button>
					<span class="text-sm font-medium text-gray-400 dark:text-gray-500">Администрирование</span>
				</div>
				<div class="flex items-center gap-3">
					<span class="text-sm text-gray-500 dark:text-gray-400">{{ auth.user?.fullName || auth.user?.email }}</span>
				</div>
			</header>

			<main class="admin-main-scroll min-h-0 flex-1 overflow-y-auto overflow-x-hidden overscroll-contain">
				<slot />
			</main>
		</div>

		<!-- Mobile overlay menu -->
		<Teleport to="body">
			<Transition name="backdrop">
				<div
					v-if="isMobile && mobileMenuOpen"
					class="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
					@click="mobileMenuOpen = false"
				/>
			</Transition>
			<Transition name="slide">
				<aside
					v-if="isMobile && mobileMenuOpen"
					class="fixed inset-y-0 left-0 z-50 flex h-[100dvh] max-h-[100dvh] w-[min(18rem,calc(100vw-2rem))] flex-col overflow-hidden overscroll-contain glass-sidebar shadow-2xl"
					@click.stop
				>
					<div class="h-14 flex shrink-0 items-center border-b border-gray-200/30 dark:border-white/5 px-4">
						<span class="font-bold text-sm text-slate-900 dark:text-slate-100">Community Club</span>
					</div>
					<nav class="min-h-0 flex-1 space-y-0.5 overflow-y-auto overscroll-contain p-2 pb-5">
						<NuxtLink
					v-for="item in visibleNavItems"
							:key="item.to"
							:to="item.to"
							class="flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-100/60 dark:hover:bg-white/10 transition-all duration-200"
							active-class="!bg-primary-500/10 dark:!bg-primary-500/15 !text-primary-600 dark:!text-primary-400 font-medium"
						>
							<SidebarIcon :name="item.icon" class="w-5 h-5 flex-shrink-0" />
							<span>{{ item.label }}</span>
						</NuxtLink>
					</nav>
					<div class="shrink-0 p-2 border-t border-gray-200/30 dark:border-white/5">
						<button
							class="flex items-center gap-3 w-full px-3 py-2.5 rounded-2xl text-sm text-gray-500 dark:text-gray-400 hover:bg-red-50/60 dark:hover:bg-red-500/10 hover:text-red-600 dark:hover:text-red-400 transition-all duration-200"
							@click="auth.logout()"
						>
							<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
							</svg>
							<span>Выйти</span>
						</button>
					</div>
				</aside>
			</Transition>
		</Teleport>
	</div>
</template>

<style scoped>
.backdrop-enter-active, .backdrop-leave-active { transition: opacity 0.2s ease; }
.backdrop-enter-from, .backdrop-leave-to { opacity: 0; }
.slide-enter-active { transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
.slide-leave-active { transition: transform 0.2s ease-in; }
.slide-enter-from, .slide-leave-to { transform: translateX(-100%); }
</style>
