export default defineNuxtConfig({
	compatibilityDate: '2025-01-01',
	devtools: { enabled: process.env.NODE_ENV === 'development' },

	experimental: {
		appManifest: false,
		viteEnvironmentApi: true,
		defaults: {
			nuxtLink: {
				prefetch: false,
			},
		},
		emitRouteChunkError: false,
		renderJsonPayloads: false,
	},

	ssr: false,

	modules: ['@nuxtjs/tailwindcss', '@pinia/nuxt'],

	runtimeConfig: {
		public: {
			apiUrl: process.env.API_URL || 'http://localhost:3001',
		},
	},

	vite: {
		build: {
			chunkSizeWarningLimit: 400,
			rollupOptions: {
				output: {
					manualChunks(id) {
						if (!id.includes('node_modules')) return

						if (
							id.includes('/vue/') ||
							id.includes('/vue-router/') ||
							id.includes('/pinia/') ||
							id.includes('/nuxt/') ||
							id.includes('/@vue/')
						) {
							return 'framework-core'
						}

						if (id.includes('chart.js') || id.includes('vue-chartjs')) {
							return 'charts-vendor'
						}

						if (id.includes('emoji-picker-element')) {
							return 'emoji-vendor'
						}

						if (id.includes('/zod/') || id.includes('/zod@')) {
							return 'validation-vendor'
						}

						if (id.includes('@kurkle/color') || id.includes('/lodash/')) {
							return 'utility-vendor'
						}

						return 'vendor'
					},
				},
			},
		},
	},

	tailwindcss: {
		cssPath: '~/assets/css/main.css',
		config: {
			darkMode: 'class',
			theme: {
				extend: {
					colors: {
						primary: {
							50: '#F7F5F0',
							100: '#F1EEE7',
							200: '#E6DDCC',
							300: '#D4A62A',
							400: '#D4A62A',
							500: '#D4A62A',
							600: '#A97800',
							700: '#A97800',
							800: '#1F1F1F',
							900: '#1F1F1F',
						},
					},
				},
			},
		},
	},

	app: {
		baseURL: '/admin/',
		head: {
			title: 'Community Club Admin',
		},
	},
})
