import { describe, expect, test } from 'bun:test'
import type { HomeHighlightItem, HomeStoryItem } from '@community-club/shared/types'
import { normalizeHighlightSlots } from './highlight-slots'

const createId = (kind: 'highlight' | 'story', slotIndex: number) => `${kind}-${slotIndex + 1}`

function createLegacyStory(
	id: string,
	mediaKey: string | null,
	mediaUrl: string | null,
): HomeStoryItem {
	return {
		id,
		title: 'Старый заголовок',
		text: 'Старый текст',
		layout: 'imageText',
		backgroundColor: '#abcdef',
		textColor: '#123456',
		mediaKey,
		mediaUrl,
		durationMs: 9000,
		imageScale: 2,
		imageX: 30,
		imageY: -20,
		overlays: [
			{
				id: 'overlay-1',
				type: 'text',
				x: 10,
				y: 20,
				width: 80,
				text: 'Оверлей',
				textColor: '#ffffff',
				fontSize: 20,
				align: 'center',
				mediaKey: null,
				mediaUrl: null,
				borderRadius: 0,
				opacity: 100,
				label: '',
				backgroundColor: '#000000',
				borderColor: null,
				borderWidth: 0,
				action: 'none',
				linkUrl: '',
				section: '',
			},
		],
	}
}

function expectCanonicalStory(
	story: HomeStoryItem,
	expected: {
		readonly id: string
		readonly mediaKey: string | null
		readonly mediaUrl: string | null
	},
) {
	expect(story).toEqual({
		id: expected.id,
		title: '',
		text: '',
		layout: 'image',
		backgroundColor: '#141414',
		textColor: '#ffffff',
		mediaKey: expected.mediaKey,
		mediaUrl: expected.mediaUrl,
		durationMs: 5000,
		imageScale: 1,
		imageX: 0,
		imageY: 0,
		overlays: [],
	})
}

describe('normalizeHighlightSlots', () => {
	test('uses only the first story from each existing highlight and creates missing slots', () => {
		// Given
		const highlights: HomeHighlightItem[] = [
			{
				id: 'legacy-highlight',
				title: 'Старое название',
				stories: [
					createLegacyStory('retained-story', 'image/one.webp', '/media/one.webp'),
					createLegacyStory('discarded-story', 'image/two.webp', '/media/two.webp'),
				],
			},
		]

		// When
		const result = normalizeHighlightSlots(highlights, [], createId)

		// Then
		expect(result).toHaveLength(5)
		expect(result[0]?.id).toBe('legacy-highlight')
		expect(result[0]?.title).toBe('')
		expect(result[0]?.stories).toHaveLength(1)
		const retainedStory = result[0]?.stories[0]
		expect(retainedStory).toBeDefined()
		if (retainedStory) {
			expectCanonicalStory(retainedStory, {
				id: 'retained-story',
				mediaKey: 'image/one.webp',
				mediaUrl: '/media/one.webp',
			})
		}
		expect(result.slice(1).map((highlight) => highlight.id)).toEqual([
			'highlight-2',
			'highlight-3',
			'highlight-4',
			'highlight-5',
		])
		expect(result.slice(1).map((highlight) => highlight.stories[0]?.id)).toEqual([
			'story-2',
			'story-3',
			'story-4',
			'story-5',
		])
	})

	test('splits legacy top-level stories when highlights are absent', () => {
		// Given
		const stories = [
			createLegacyStory('legacy-1', 'image/one.webp', '/media/one.webp'),
			createLegacyStory('legacy-2', 'image/two.webp', '/media/two.webp'),
		]

		// When
		const result = normalizeHighlightSlots([], stories, createId)

		// Then
		expect(result).toHaveLength(5)
		expect(result.map((highlight) => highlight.stories.length)).toEqual([1, 1, 1, 1, 1])
		expect(result.map((highlight) => highlight.stories[0]?.mediaKey)).toEqual([
			'image/one.webp',
			'image/two.webp',
			null,
			null,
			null,
		])
	})

	test('does not restore legacy top-level stories when highlights exist', () => {
		// Given
		const highlights: HomeHighlightItem[] = [{ id: 'empty-highlight', title: '', stories: [] }]
		const stories = [createLegacyStory('legacy-1', 'image/one.webp', '/media/one.webp')]

		// When
		const result = normalizeHighlightSlots(highlights, stories, createId)

		// Then
		expect(result[0]?.stories[0]?.mediaKey).toBeNull()
		expect(result[0]?.stories[0]?.mediaUrl).toBeNull()
	})
})
