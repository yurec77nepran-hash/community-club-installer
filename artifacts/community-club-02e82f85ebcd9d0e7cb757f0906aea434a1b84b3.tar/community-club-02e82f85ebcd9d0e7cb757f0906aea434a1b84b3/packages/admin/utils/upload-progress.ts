export function getUploadProgressPercent(loaded: number, total: number | null) {
	if (!Number.isFinite(loaded) || !Number.isFinite(total) || !total || total <= 0) {
		return 0
	}

	const percent = Math.round((loaded / total) * 100)
	return Math.min(100, Math.max(0, percent))
}

export function getBatchUploadProgressPercent(
	completedBytes: number,
	currentLoadedBytes: number,
	totalBytes: number,
) {
	return getUploadProgressPercent(completedBytes + currentLoadedBytes, totalBytes)
}
