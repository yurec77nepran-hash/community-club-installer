import { describe, expect, test } from 'bun:test'
import { getBatchUploadProgressPercent, getUploadProgressPercent } from './upload-progress'

describe('admin upload progress', () => {
	test('calculates a bounded single-file upload percent', () => {
		expect(getUploadProgressPercent(25, 100)).toBe(25)
		expect(getUploadProgressPercent(125, 100)).toBe(100)
		expect(getUploadProgressPercent(-10, 100)).toBe(0)
	})

	test('returns zero when total size is unknown', () => {
		expect(getUploadProgressPercent(50, 0)).toBe(0)
		expect(getUploadProgressPercent(50, null)).toBe(0)
	})

	test('calculates batch upload percent from completed and current bytes', () => {
		expect(getBatchUploadProgressPercent(100, 50, 300)).toBe(50)
		expect(getBatchUploadProgressPercent(300, 50, 300)).toBe(100)
	})
})
