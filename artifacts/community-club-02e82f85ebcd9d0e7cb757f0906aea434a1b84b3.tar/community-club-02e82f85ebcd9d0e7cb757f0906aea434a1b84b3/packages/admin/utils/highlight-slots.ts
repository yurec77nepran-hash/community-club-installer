import type { HomeHighlightItem, HomeStoryItem } from '@community-club/shared/types'

type HighlightSlotIdFactory = (kind: 'highlight' | 'story', slotIndex: number) => string

const HIGHLIGHT_SLOT_COUNT = 5

function normalizeSlotStory(
	story: HomeStoryItem | undefined,
	slotIndex: number,
	createId: HighlightSlotIdFactory,
): HomeStoryItem {
	return {
		id: story?.id || createId('story', slotIndex),
		title: '',
		text: '',
		layout: 'image',
		backgroundColor: '#141414',
		textColor: '#ffffff',
		mediaKey: story?.mediaKey ?? null,
		mediaUrl: story?.mediaUrl ?? null,
		durationMs: 5000,
		imageScale: 1,
		imageX: 0,
		imageY: 0,
		overlays: [],
	}
}

export function normalizeHighlightSlots(
	highlights: readonly HomeHighlightItem[],
	legacyStories: readonly HomeStoryItem[],
	createId: HighlightSlotIdFactory,
): HomeHighlightItem[] {
	const hasHighlights = highlights.length > 0

	return Array.from({ length: HIGHLIGHT_SLOT_COUNT }, (_, slotIndex) => {
		const highlight = hasHighlights ? highlights[slotIndex] : undefined
		const story = hasHighlights ? highlight?.stories[0] : legacyStories[slotIndex]

		return {
			id: highlight?.id || createId('highlight', slotIndex),
			title: '',
			stories: [normalizeSlotStory(story, slotIndex, createId)],
		}
	})
}
