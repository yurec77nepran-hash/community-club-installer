<script setup lang="ts">
useHead({
	script: [
		{
			innerHTML:
				"document.documentElement.classList.add('dark');localStorage.setItem('admin_dark','1');",
			tagPosition: 'head',
		},
	],
})
</script>

<template>
	<NuxtLayout>
		<NuxtPage />
	</NuxtLayout>
</template>
