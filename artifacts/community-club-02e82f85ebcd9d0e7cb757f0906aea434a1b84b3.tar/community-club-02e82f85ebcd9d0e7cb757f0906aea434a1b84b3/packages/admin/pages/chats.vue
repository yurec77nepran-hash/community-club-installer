<script setup lang="ts">
import type {
	AdminChatItem,
	AdminMediaLibraryItem,
	ChatSettings,
	CursorPaginatedResponse,
} from '@community-club/shared/types'

type ChatForm = {
	id: number | null
	name: string
	slug: string
	type: 'chat' | 'channel'
	accessRole: 'all'
	isEnabled: boolean
	avatarUrl: string
	description: string
	settings: ChatSettings
}

const api = useAdminApi()
const chats = ref<AdminChatItem[]>([])
const selectedId = ref<number | null>(null)
const loading = ref(true)
const saving = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const mediaLibraryOpen = ref(false)
const mediaLibraryLoading = ref(false)
const mediaLibraryLoadingMore = ref(false)
const mediaLibraryItems = ref<AdminMediaLibraryItem[]>([])
const mediaLibraryCursor = ref<string | null>(null)

const emptySettings: ChatSettings = {
	allowMemberMessages: true,
	allowAttachments: true,
	allowReactions: true,
	slowModeSeconds: 0,
	welcomeText: null,
}

const form = reactive<ChatForm>({
	id: null,
	name: '',
	slug: '',
	type: 'chat',
	accessRole: 'all',
	isEnabled: true,
	avatarUrl: '',
	description: '',
	settings: { ...emptySettings },
})

const selectedChat = computed(
	() => chats.value.find((chat) => chat.id === selectedId.value) ?? null,
)
const hasChats = computed(() => chats.value.length > 0)
const canSave = computed(() => form.name.trim().length >= 2)
const enabledCount = computed(() => chats.value.filter((chat) => chat.isEnabled).length)

function accessLabel(role: AdminChatItem['accessRole']) {
	return 'Все участники'
}

function typeLabel(type: AdminChatItem['type']) {
	return type === 'channel' ? 'Канал' : 'Чат'
}

function formatNumber(value: number) {
	return new Intl.NumberFormat('ru-RU').format(value)
}

function formatMediaSize(size: number | null) {
	if (!size) return ''
	if (size < 1024 * 1024) return `${Math.round(size / 1024)} КБ`
	return `${(size / (1024 * 1024)).toFixed(1)} МБ`
}

function formatMediaDate(value: string | Date | null) {
	if (!value) return ''
	return new Date(value).toLocaleDateString('ru-RU', {
		day: '2-digit',
		month: 'short',
		year: 'numeric',
	})
}

function makeSlug(value: string) {
	return value
		.toLowerCase()
		.replace(/[^a-z0-9а-яё]+/gi, '-')
		.replace(/[а-яё]/gi, '')
		.replace(/^-+|-+$/g, '')
		.replace(/-{2,}/g, '-')
		.slice(0, 80)
}

function makeUniqueSlug(value: string, currentId = form.id) {
	const base = makeSlug(value) || 'club-chat'
	const used = new Set(chats.value.filter((chat) => chat.id !== currentId).map((chat) => chat.slug))
	if (!used.has(base)) return base
	for (let index = 2; index < 1000; index += 1) {
		const suffix = `-${index}`
		const next = `${base.slice(0, 80 - suffix.length)}${suffix}`
		if (!used.has(next)) return next
	}
	return `${base.slice(0, 64)}-${Date.now().toString(36)}`
}

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}

function applyChat(chat: AdminChatItem) {
	form.id = chat.id
	form.name = chat.name
	form.slug = chat.slug
	form.type = chat.type
	form.accessRole = chat.accessRole
	form.isEnabled = chat.isEnabled
	form.avatarUrl = chat.avatarUrl ?? ''
	form.description = chat.description ?? ''
	form.settings = { ...emptySettings, ...chat.settings }
	selectedId.value = chat.id
	resetMessages()
}

function startCreate() {
	form.id = null
	form.name = ''
	form.slug = makeUniqueSlug('club-chat', null)
	form.type = 'chat'
	form.accessRole = 'all'
	form.isEnabled = true
	form.avatarUrl = ''
	form.description = ''
	form.settings = { ...emptySettings }
	selectedId.value = null
	resetMessages()
}

function onNameInput() {
	if (form.id) return
	form.slug = makeUniqueSlug(form.name, null)
}

async function loadChats() {
	loading.value = true
	resetMessages()
	const res = await api.get<AdminChatItem[]>('/api/admin/chats')
	if (res.success) {
		chats.value = res.data
		if (selectedId.value) {
			const current = chats.value.find((chat) => chat.id === selectedId.value)
			if (current) applyChat(current)
		} else if (chats.value[0]) {
			applyChat(chats.value[0])
		} else {
			startCreate()
		}
	} else {
		errorMessage.value = res.error.message
	}
	loading.value = false
}

function buildPayload() {
	const slug = form.id ? form.slug.trim() : makeUniqueSlug(form.name, null)
	return {
		name: form.name.trim(),
		slug,
		type: form.type,
		accessRole: form.accessRole,
		isEnabled: form.isEnabled,
		avatarUrl: form.avatarUrl.trim() || null,
		description: form.description.trim() || null,
		settings: {
			allowMemberMessages: form.settings.allowMemberMessages,
			allowAttachments: form.settings.allowAttachments,
			allowReactions: form.settings.allowReactions,
			slowModeSeconds: Number(form.settings.slowModeSeconds) || 0,
			welcomeText: form.settings.welcomeText?.trim() || null,
		},
	}
}

async function saveChat() {
	if (saving.value || !canSave.value) return
	resetMessages()
	saving.value = true

	const payload = buildPayload()
	const res = form.id
		? await api.patch<AdminChatItem>(`/api/admin/chats/${form.id}`, payload)
		: await api.post<AdminChatItem>('/api/admin/chats', payload)

	if (res.success) {
		const index = chats.value.findIndex((chat) => chat.id === res.data.id)
		if (index >= 0) chats.value.splice(index, 1, res.data)
		else chats.value.unshift(res.data)
		applyChat(res.data)
		successMessage.value = 'Чат сохранён'
	} else {
		errorMessage.value = res.error.message
	}

	saving.value = false
}

async function toggleChat(chat: AdminChatItem) {
	applyChat(chat)
	form.isEnabled = !chat.isEnabled
	await saveChat()
}

async function loadAvatarMediaLibrary(options?: { append?: boolean }) {
	const append = options?.append ?? false
	if (append) {
		if (!mediaLibraryCursor.value || mediaLibraryLoadingMore.value) return
		mediaLibraryLoadingMore.value = true
	} else {
		mediaLibraryLoading.value = true
	}

	const query = new URLSearchParams({
		limit: '24',
		type: 'image',
		sortBy: 'updatedAt',
		sortDir: 'desc',
	})
	if (append && mediaLibraryCursor.value) query.set('cursor', mediaLibraryCursor.value)

	const res = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		`/api/admin/media-library?${query.toString()}`,
	)
	if (res.success) {
		mediaLibraryItems.value = append
			? [...mediaLibraryItems.value, ...res.data.items]
			: res.data.items
		mediaLibraryCursor.value = res.data.nextCursor
	} else {
		errorMessage.value = res.error.message
	}

	mediaLibraryLoading.value = false
	mediaLibraryLoadingMore.value = false
}

async function openAvatarMediaLibrary() {
	resetMessages()
	mediaLibraryOpen.value = true
	await loadAvatarMediaLibrary()
}

function selectAvatar(item: AdminMediaLibraryItem) {
	form.avatarUrl = item.url
	mediaLibraryOpen.value = false
}

onMounted(loadChats)
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
			<div>
				<p class="text-sm font-medium text-primary-600">Коммуникации</p>
				<h1 class="mt-1 text-2xl font-bold text-gray-900 dark:text-white">Чаты</h1>
				<p class="mt-2 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
					Управляйте доступом, оформлением и правилами общения в клубе.
				</p>
			</div>
			<div class="flex w-full flex-wrap items-center gap-3 lg:w-auto lg:justify-end">
				<div class="min-w-[130px] flex-1 rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm dark:border-white/10 dark:bg-white/5 sm:flex-none">
					<span class="text-gray-500 dark:text-gray-400">Включено:</span>
					<span class="ml-1 font-semibold text-gray-900 dark:text-white">{{ enabledCount }}</span>
				</div>
				<button type="button" class="btn-primary flex-1 sm:flex-none" @click="startCreate">+ Новый чат</button>
			</div>
		</div>

		<div v-if="loading" class="rounded-xl border border-gray-100 bg-white p-8 text-center text-gray-400 dark:border-white/10 dark:bg-white/5">
			Загрузка...
		</div>

		<div v-else class="grid gap-5 xl:grid-cols-[minmax(320px,420px)_1fr]">
			<section class="rounded-xl border border-gray-100 bg-white shadow-sm dark:border-white/10 dark:bg-white/5">
				<div class="border-b border-gray-100 px-5 py-4 dark:border-white/10">
					<h2 class="font-semibold text-gray-900 dark:text-white">Список</h2>
				</div>
				<div v-if="!hasChats" class="p-5 text-sm text-gray-500 dark:text-gray-400">
					Чаты ещё не добавлены.
				</div>
				<div v-else class="divide-y divide-gray-100 dark:divide-white/10">
					<div
						v-for="chat in chats"
						:key="chat.id"
						role="button"
						tabindex="0"
						class="flex w-full items-center gap-3 px-5 py-4 text-left transition hover:bg-gray-50 dark:hover:bg-white/5"
						:class="selectedId === chat.id ? 'bg-primary-50/80 dark:bg-primary-500/10' : ''"
						@click="applyChat(chat)"
						@keydown.enter.prevent="applyChat(chat)"
						@keydown.space.prevent="applyChat(chat)"
					>
						<div class="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-gray-100 dark:bg-white/10">
							<img v-if="chat.avatarUrl" :src="chat.avatarUrl" :alt="chat.name" class="h-full w-full object-cover" />
							<div v-else class="flex h-full w-full items-center justify-center text-sm font-bold text-gray-500 dark:text-gray-300">
								{{ chat.name.charAt(0) }}
							</div>
						</div>
						<div class="min-w-0 flex-1">
							<div class="flex items-center gap-2">
								<h3 class="truncate text-sm font-semibold text-gray-900 dark:text-white">{{ chat.name }}</h3>
								<span
									class="h-2 w-2 rounded-full"
									:class="chat.isEnabled ? 'bg-emerald-500' : 'bg-gray-300 dark:bg-gray-600'"
								/>
							</div>
							<p class="mt-1 truncate text-xs text-gray-500 dark:text-gray-400">
								{{ typeLabel(chat.type) }} · {{ accessLabel(chat.accessRole) }}
							</p>
						</div>
						<button
							type="button"
							class="rounded-lg px-3 py-1.5 text-xs font-semibold"
							:class="chat.isEnabled ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-200' : 'bg-gray-100 text-gray-500 dark:bg-white/10 dark:text-gray-300'"
							@click.stop="toggleChat(chat)"
						>
							{{ chat.isEnabled ? 'Вкл' : 'Выкл' }}
						</button>
					</div>
				</div>
			</section>

			<section class="rounded-xl border border-gray-100 bg-white shadow-sm dark:border-white/10 dark:bg-white/5">
				<div class="flex flex-col gap-3 border-b border-gray-100 px-5 py-4 dark:border-white/10 md:flex-row md:items-center md:justify-between">
					<div>
						<h2 class="font-semibold text-gray-900 dark:text-white">
							{{ form.id ? 'Настройки чата' : 'Новый чат' }}
						</h2>
						<p v-if="selectedChat" class="mt-1 text-xs text-gray-500 dark:text-gray-400">
							{{ formatNumber(selectedChat.membersCount) }} участников · {{ formatNumber(selectedChat.messagesCount) }} сообщений
						</p>
					</div>
					<button type="button" class="btn-primary" :disabled="saving || !canSave" @click="saveChat">
						{{ saving ? 'Сохранение...' : 'Сохранить' }}
					</button>
				</div>

				<div class="space-y-5 p-5">
					<div v-if="errorMessage" class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200">
						{{ errorMessage }}
					</div>
					<div v-if="successMessage" class="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-200">
						{{ successMessage }}
					</div>

					<div class="grid gap-4 xl:grid-cols-[13rem_1fr]">
						<div class="rounded-2xl border border-gray-100 bg-gray-50 p-3 dark:border-white/10 dark:bg-white/5">
							<div class="aspect-square overflow-hidden rounded-2xl bg-slate-900/5 dark:bg-black/20">
								<img v-if="form.avatarUrl" :src="form.avatarUrl" alt="" class="h-full w-full object-cover" />
								<div v-else class="flex h-full w-full items-center justify-center text-4xl font-bold text-gray-400">
									{{ form.name.charAt(0) || 'Ч' }}
								</div>
							</div>
							<div class="mt-3 grid gap-2">
								<button type="button" class="btn-secondary w-full justify-center" @click="openAvatarMediaLibrary">
									Выбрать из Медиа
								</button>
								<button
									v-if="form.avatarUrl"
									type="button"
									class="rounded-2xl border border-gray-200/70 px-4 py-2 text-sm font-semibold text-gray-500 transition hover:text-gray-900 dark:border-white/10 dark:text-gray-400 dark:hover:text-white"
									@click="form.avatarUrl = ''"
								>
									Убрать
								</button>
							</div>
						</div>

						<div class="grid content-start gap-4">
							<div class="grid gap-4 md:grid-cols-[1fr_13rem]">
								<label class="block">
									<span class="mb-1 block text-xs font-semibold uppercase tracking-wide text-gray-500">Название</span>
									<input v-model="form.name" class="glass-input" placeholder="Клубный чат" @input="onNameInput" />
								</label>
								<label class="block">
									<span class="mb-1 block text-xs font-semibold uppercase tracking-wide text-gray-500">Тип</span>
									<select v-model="form.type" class="glass-input">
										<option value="chat">Чат</option>
										<option value="channel">Канал</option>
									</select>
								</label>
							</div>
							<label class="block">
								<span class="mb-1 block text-xs font-semibold uppercase tracking-wide text-gray-500">Описание</span>
								<textarea v-model="form.description" rows="3" class="glass-input resize-none" placeholder="Коротко о теме чата" />
							</label>
							<div class="grid gap-4 md:grid-cols-[1fr_1fr]">
								<label class="block">
									<span class="mb-1 block text-xs font-semibold uppercase tracking-wide text-gray-500">Доступ</span>
									<select v-model="form.accessRole" class="glass-input">
										<option value="all">Все участники</option>
									</select>
								</label>
								<label class="flex items-start gap-3 rounded-2xl border border-gray-100 bg-gray-50 px-4 py-3 dark:border-white/10 dark:bg-white/5">
									<input v-model="form.isEnabled" type="checkbox" class="glass-check mt-0.5" />
									<span>
										<span class="block text-sm font-medium text-gray-800 dark:text-gray-100">Показывать участникам</span>
										<span class="mt-1 block text-xs leading-5 text-gray-500 dark:text-gray-400">
											Если выключить, чат пропадёт из приложения.
										</span>
									</span>
								</label>
							</div>
						</div>
					</div>

					<div class="rounded-xl border border-gray-100 p-4 dark:border-white/10">
						<div class="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
							<h3 class="text-sm font-semibold text-gray-900 dark:text-white">Сообщения</h3>
							<p class="text-xs text-gray-500 dark:text-gray-400">Права участников и стартовый текст</p>
						</div>
						<div class="mt-4 grid gap-3 lg:grid-cols-3">
							<label class="flex items-start gap-3 rounded-lg bg-gray-50 p-3 dark:bg-white/5">
								<input v-model="form.settings.allowMemberMessages" type="checkbox" class="glass-check mt-0.5" />
								<span>
									<span class="block text-sm font-medium text-gray-900 dark:text-white">Писать в чат</span>
									<span class="text-xs text-gray-500 dark:text-gray-400">Для обычных участников</span>
								</span>
							</label>
							<label class="flex items-start gap-3 rounded-lg bg-gray-50 p-3 dark:bg-white/5">
								<input v-model="form.settings.allowAttachments" type="checkbox" class="glass-check mt-0.5" />
								<span>
									<span class="block text-sm font-medium text-gray-900 dark:text-white">Вложения</span>
									<span class="text-xs text-gray-500 dark:text-gray-400">Фото, видео и файлы</span>
								</span>
							</label>
							<label class="flex items-start gap-3 rounded-lg bg-gray-50 p-3 dark:bg-white/5">
								<input v-model="form.settings.allowReactions" type="checkbox" class="glass-check mt-0.5" />
								<span>
									<span class="block text-sm font-medium text-gray-900 dark:text-white">Реакции</span>
									<span class="text-xs text-gray-500 dark:text-gray-400">Эмодзи под сообщениями</span>
								</span>
							</label>
						</div>
						<div class="mt-4 grid gap-4 lg:grid-cols-[13rem_1fr]">
							<label class="block">
								<span class="mb-1 block text-xs font-semibold uppercase tracking-wide text-gray-500">Медленный режим, сек.</span>
								<input v-model.number="form.settings.slowModeSeconds" type="number" min="0" max="3600" class="glass-input" />
							</label>
							<label class="block">
								<span class="mb-1 block text-xs font-semibold uppercase tracking-wide text-gray-500">Приветствие</span>
								<input v-model="form.settings.welcomeText" class="glass-input" placeholder="Текст перед началом общения" />
							</label>
						</div>
					</div>
				</div>
			</section>
		</div>

		<Teleport to="body">
			<Transition name="modal">
				<div
					v-if="mediaLibraryOpen"
					class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm"
					@click.self="mediaLibraryOpen = false"
				>
					<div class="flex max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-3xl border border-white/10 bg-slate-950 shadow-2xl">
						<div class="flex flex-col gap-3 border-b border-white/10 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
							<div>
								<h2 class="text-lg font-semibold text-white">Выбор аватарки</h2>
								<p class="mt-1 text-sm text-slate-400">Изображения из раздела «Медиа».</p>
							</div>
							<button type="button" class="btn-secondary" @click="mediaLibraryOpen = false">Закрыть</button>
						</div>

						<div class="flex-1 overflow-auto px-5 py-5">
							<div v-if="mediaLibraryLoading" class="py-10 text-center text-sm text-slate-400">
								Загружаю медиатеку...
							</div>
							<div
								v-else-if="mediaLibraryItems.length === 0"
								class="rounded-2xl border border-dashed border-white/10 px-4 py-10 text-center text-sm text-slate-400"
							>
								В медиатеке пока нет изображений.
							</div>
							<div v-else class="space-y-5">
								<div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
									<button
										v-for="item in mediaLibraryItems"
										:key="item.key"
										type="button"
										class="group overflow-hidden rounded-2xl border border-white/10 bg-white/5 text-left transition hover:border-primary-400/70 hover:bg-white/10"
										@click="selectAvatar(item)"
									>
										<div class="aspect-square overflow-hidden bg-black/20">
											<img :src="item.url" :alt="item.name" class="h-full w-full object-cover transition group-hover:scale-[1.03]" />
										</div>
										<div class="space-y-1 px-3 py-3">
											<p class="truncate text-sm font-medium text-white">{{ item.title || item.name }}</p>
											<p class="truncate text-xs text-slate-400">
												{{ formatMediaDate(item.lastModified) }}
												<span v-if="item.size"> · {{ formatMediaSize(item.size) }}</span>
											</p>
										</div>
									</button>
								</div>

								<div class="flex justify-center">
									<button
										v-if="mediaLibraryCursor"
										type="button"
										class="btn-secondary"
										:disabled="mediaLibraryLoadingMore"
										@click="loadAvatarMediaLibrary({ append: true })"
									>
										{{ mediaLibraryLoadingMore ? 'Загрузка...' : 'Показать ещё' }}
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</Transition>
		</Teleport>
	</div>
</template>
