<script setup lang="ts">
const api = useAdminApi()
const title = ref('')
const body = ref('')
const targetRole = ref('all')
const sending = ref(false)
const result = ref<{ sent: number; failed: number } | null>(null)

async function sendPush() {
	if (!title.value || !body.value) return
	sending.value = true
	result.value = null

	const res = await api.post<{ sent: number; failed: number }>('/api/push/send', {
		title: title.value,
		body: body.value,
		targetRole: targetRole.value,
	})

	if (res.success) {
		result.value = res.data
		title.value = ''
		body.value = ''
	}
	sending.value = false
}
</script>

<template>
	<div class="p-6">
		<h1 class="text-2xl font-bold mb-6">Push-уведомления</h1>

		<div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100 max-w-lg">
			<div class="space-y-4">
				<div>
					<label class="block text-sm font-medium text-gray-700 mb-1">Заголовок</label>
					<input v-model="title" class="w-full px-3 py-2 rounded-lg border text-sm" placeholder="Заголовок уведомления" />
				</div>
				<div>
					<label class="block text-sm font-medium text-gray-700 mb-1">Текст</label>
					<textarea v-model="body" class="w-full px-3 py-2 rounded-lg border text-sm resize-none" rows="3" placeholder="Текст уведомления" />
				</div>
				<div>
					<label class="block text-sm font-medium text-gray-700 mb-1">Целевая аудитория</label>
					<select v-model="targetRole" class="w-full px-3 py-2 rounded-lg border text-sm">
						<option value="all">Все</option>
					</select>
				</div>
				<button
					:disabled="!title || !body || sending"
					class="w-full py-2.5 bg-primary-600 text-white rounded-lg text-sm font-medium disabled:opacity-50"
					@click="sendPush"
				>
					{{ sending ? 'Отправка...' : 'Отправить' }}
				</button>

				<div v-if="result" class="p-3 bg-green-50 rounded-lg text-sm text-green-700">
					Отправлено: {{ result.sent }}, Ошибок: {{ result.failed }}
				</div>
			</div>
		</div>
	</div>
</template>
