<script setup lang="ts">
import type { AdminActivityLogItem, PaginatedResponse } from '@community-club/shared/types'

const api = useAdminApi()
const logs = ref<AdminActivityLogItem[]>([])
const loading = ref(true)
const page = ref(1)
const pageSize = 50

async function loadLogs() {
	loading.value = true
	const params = new URLSearchParams({
		page: String(page.value),
		pageSize: String(pageSize),
	})
	const res = await api.get<PaginatedResponse<AdminActivityLogItem> | AdminActivityLogItem[]>(
		`/api/admin/activity-logs?${params.toString()}`,
	)
	if (res.success) {
		logs.value = Array.isArray(res.data) ? res.data : res.data.items
	}
	loading.value = false
}

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
		second: '2-digit',
	})
}

function formatActor(log: AdminActivityLogItem) {
	return log.actorName || log.actorEmail || 'Сотрудник'
}

function formatValue(value: unknown) {
	if (value === null || value === undefined || value === '') return 'не указано'
	if (typeof value === 'boolean') return value ? 'Да' : 'Нет'
	if (Array.isArray(value)) return value.length ? value.join(', ') : 'не указано'
	return String(value)
}

function formatDetails(log: AdminActivityLogItem) {
	if (!log.details || typeof log.details !== 'object') return []

	const details = log.details as Record<string, unknown>
	const lines: string[] = []

	if (details.folderName) {
		lines.push(`Папка: ${formatValue(details.folderName)}`)
	}
	if (details.fileName) {
		lines.push(`Файл: ${formatValue(details.fileName)}`)
	}
	if (details.email) {
		lines.push(`Логин: ${formatValue(details.email)}`)
	}
	if (details.role) {
		lines.push(`Роль: ${formatValue(details.role)}`)
	}
	if (details.title) {
		lines.push(`Название: ${formatValue(details.title)}`)
	}
	if (details.type) {
		lines.push(`Раздел: ${formatValue(details.type)}`)
	}

	const changed = details.changed
	if (changed && typeof changed === 'object' && !Array.isArray(changed)) {
		for (const [key, value] of Object.entries(changed as Record<string, unknown>)) {
			if (!value || typeof value !== 'object' || Array.isArray(value)) continue
			const change = value as { before?: unknown; after?: unknown }
			lines.push(`${translateFieldName(key)}: ${formatValue(change.after)}`)
		}
	}

	return lines
}

function translateFieldName(field: string) {
	const labels: Record<string, string> = {
		fullName: 'Имя',
		email: 'Логин',
		phone: 'Телефон',
		role: 'Роль',
		chatAdminBadge: 'Плашка админ',
		title: 'Название',
		note: 'Комментарий',
		folderId: 'Папка',
		subsection: 'Подраздел',
		mediaType: 'Тип медиа',
		searchQuery: 'Поиск',
		typeFilter: 'Фильтр',
		sortBy: 'Сортировка',
		sortDir: 'Порядок',
		viewMode: 'Вид',
	}

	return labels[field] || field
}

watch(page, () => {
	void loadLogs()
})

onMounted(() => {
	void loadLogs()
})
</script>

<template>
	<div class="p-6">
		<div class="mb-6">
			<h1 class="text-2xl font-bold text-gray-900 dark:text-white">Действия сотрудников</h1>
			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				Неизменяемый журнал добавлений, изменений и удалений в админке.
			</p>
		</div>

		<div class="glass overflow-hidden rounded-[30px]">
			<div v-if="loading" class="px-6 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
				Загружаю журнал...
			</div>
			<div v-else-if="logs.length === 0" class="px-6 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
				Записей пока нет.
			</div>
			<div v-else class="divide-y divide-white/10">
				<article
					v-for="log in logs"
					:key="log.id"
					class="grid gap-3 px-6 py-5 lg:grid-cols-[220px_220px_minmax(0,1fr)]"
				>
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Когда</p>
						<p class="mt-2 text-sm text-gray-700 dark:text-gray-200">{{ formatDate(log.createdAt) }}</p>
					</div>
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Кто</p>
						<p class="mt-2 text-sm font-medium text-gray-900 dark:text-white">{{ formatActor(log) }}</p>
						<p v-if="log.actorEmail" class="mt-1 text-xs text-gray-500 dark:text-gray-400">{{ log.actorEmail }}</p>
					</div>
					<div class="min-w-0">
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Что сделал</p>
						<p class="mt-2 text-sm font-medium text-gray-900 dark:text-white">{{ log.summary }}</p>
						<div
							v-if="formatDetails(log).length"
							class="mt-3 rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-xs text-white/65"
						>
							<p v-for="line in formatDetails(log)" :key="line" class="leading-5">{{ line }}</p>
						</div>
					</div>
				</article>
			</div>
		</div>

		<div class="mt-5 flex justify-center">
			<button type="button" class="btn-secondary" @click="page += 1">Показать ещё</button>
		</div>
	</div>
</template>
