<script setup lang="ts">
import type { CursorPaginatedResponse, MaterialCommentFeedItem } from '@community-club/shared/types'

const api = useAdminApi()
const config = useRuntimeConfig()

const items = ref<MaterialCommentFeedItem[]>([])
const nextCursor = ref<string | null>(null)
const loading = ref(true)
const loadingMore = ref(false)
const drafts = ref<Record<number, string>>({})
const submitting = ref<number | null>(null)

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'short',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function getAuthorName(item: MaterialCommentFeedItem) {
	return (
		item.author.fullName || item.author.username || `Участник ${item.author.authUuid.slice(0, 6)}`
	)
}

function getMaterialUrl(item: MaterialCommentFeedItem) {
	return `${config.public.apiUrl}/app/content/${item.materialType}/${item.materialId}`
}

function getInitial(item: MaterialCommentFeedItem) {
	return getAuthorName(item).trim().charAt(0).toUpperCase()
}

async function loadFeed(options?: { append?: boolean }) {
	const append = options?.append ?? false
	if (append) {
		if (!nextCursor.value || loadingMore.value) return
		loadingMore.value = true
	} else {
		loading.value = true
	}

	const query = new URLSearchParams()
	query.set('limit', '20')
	if (append && nextCursor.value) {
		query.set('cursor', nextCursor.value)
	}

	const res = await api.get<CursorPaginatedResponse<MaterialCommentFeedItem>>(
		`/api/admin/material-comments/feed?${query.toString()}`,
	)

	if (res.success) {
		items.value = append ? [...items.value, ...res.data.items] : res.data.items
		nextCursor.value = res.data.nextCursor
	}

	loading.value = false
	loadingMore.value = false
}

async function submitReply(commentId: number) {
	const content = drafts.value[commentId]?.trim()
	if (!content || submitting.value === commentId) return

	submitting.value = commentId
	const res = await api.post(`/api/admin/material-comments/${commentId}/reply`, { content })
	if (res.success) {
		drafts.value = {
			...drafts.value,
			[commentId]: '',
		}
		await loadFeed()
	}
	submitting.value = null
}

onMounted(() => {
	void loadFeed()
})
</script>

<template>
	<div class="p-6">
		<div class="mb-6">
			<h1 class="text-2xl font-bold dark:text-white">Лента ответов</h1>
			<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
				Свежие комментарии к материалам. Отвечать можно прямо из ленты.
			</p>
		</div>

		<div v-if="loading" class="glass rounded-3xl p-6 text-sm text-gray-500 dark:text-gray-400">
			Загружаю комментарии...
		</div>

		<div v-else-if="items.length === 0" class="glass rounded-3xl p-6 text-sm text-gray-500 dark:text-gray-400">
			Комментариев пока нет.
		</div>

		<div v-else class="space-y-4">
			<article
				v-for="item in items"
				:key="item.id"
				class="glass rounded-3xl p-5"
			>
				<div class="flex items-start gap-3">
					<div class="rounded-full overflow-hidden">
						<div class="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-primary-100 text-sm font-semibold text-primary-600 dark:bg-primary-500/15 dark:text-primary-300">
							<img
								v-if="item.author.avatarUrl && !item.author.avatarUrl.startsWith('emoji:')"
								:src="item.author.avatarUrl"
								:alt="getAuthorName(item)"
								class="h-full w-full object-cover"
							/>
							<span v-else-if="item.author.avatarUrl?.startsWith('emoji:')">
								{{ item.author.avatarUrl.slice('emoji:'.length) }}
							</span>
							<span v-else>{{ getInitial(item) }}</span>
						</div>
					</div>
					<div class="min-w-0 flex-1">
						<div class="flex flex-wrap items-center gap-x-2 gap-y-1">
							<p class="text-sm font-semibold text-gray-900 dark:text-white">{{ getAuthorName(item) }}</p>
							<span class="text-[11px] text-gray-400 dark:text-gray-500">{{ formatDate(item.createdAt) }}</span>
							<span
								v-if="item.repliesCount > 0"
								class="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600 dark:text-emerald-400"
							>
								Ответов: {{ item.repliesCount }}
							</span>
						</div>

						<p class="mt-2 whitespace-pre-wrap text-sm text-gray-600 dark:text-gray-300 [overflow-wrap:anywhere] break-words">
							{{ item.content }}
						</p>

						<div class="mt-3 flex flex-wrap items-center gap-2 text-xs">
							<span class="rounded-full bg-gray-100 px-2.5 py-1 text-gray-500 dark:bg-white/5 dark:text-gray-400">
								{{ item.materialTitle }}
							</span>
							<a
								:href="getMaterialUrl(item)"
								target="_blank"
								rel="noopener noreferrer"
								class="rounded-full bg-primary-500/10 px-2.5 py-1 font-medium text-primary-600 dark:text-primary-400"
							>
								Перейти в карточку
							</a>
						</div>

						<div class="mt-4 rounded-2xl border border-gray-200/60 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
							<textarea
								v-model="drafts[item.id]"
								rows="3"
								class="w-full resize-none rounded-2xl border border-gray-200/70 bg-white px-3 py-2 text-sm outline-none transition focus:border-primary-400 dark:border-white/10 dark:bg-black/20 dark:text-white"
								placeholder="Ответить от имени администратора"
							/>
							<div class="mt-3 flex justify-end">
								<button
									class="btn-primary"
									:disabled="!drafts[item.id]?.trim() || submitting === item.id"
									@click="submitReply(item.id)"
								>
									{{ submitting === item.id ? 'Отправка...' : 'Ответить' }}
								</button>
							</div>
						</div>
					</div>
				</div>
			</article>

			<div class="flex justify-center">
				<button
					v-if="nextCursor"
					class="btn-secondary"
					:disabled="loadingMore"
					@click="loadFeed({ append: true })"
				>
					{{ loadingMore ? 'Загрузка...' : 'Показать ещё' }}
				</button>
			</div>
		</div>
	</div>
</template>
