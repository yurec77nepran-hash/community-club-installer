<script setup lang="ts">
interface PushCampaign {
	id: number
	name: string
	kind: 'one_time' | 'billing_relative'
	status: 'draft' | 'scheduled' | 'active' | 'paused' | 'processing' | 'completed' | 'failed'
	audience: 'all' | 'active'
	title: string
	body: string
	url: string | null
	offsetDays: number[]
	sendAt: string | null
	isEnabled: boolean
	lastRunAt: string | null
	lastRunSent: number
	lastRunFailed: number
	lastRunAudienceSize: number
	lastError: string | null
	createdAt: string
}

interface PushCampaignRun {
	id: number
	runKey: string
	scheduledFor: string
	offsetDays: number | null
	status: 'processing' | 'completed' | 'failed'
	audienceSize: number
	subscriptionCount: number
	sentCount: number
	failedCount: number
	errorMessage: string | null
	startedAt: string
	completedAt: string | null
	campaign: {
		id: number
		name: string
		kind: 'one_time' | 'billing_relative'
		audience: PushCampaign['audience']
	}
}

const api = useAdminApi()

const loading = ref(true)
const savingOneTime = ref(false)
const savingRegular = ref(false)
const actionLoadingId = ref<number | null>(null)
const errorMessage = ref('')
const successMessage = ref('')

const campaigns = ref<PushCampaign[]>([])
const runs = ref<PushCampaignRun[]>([])
const audiences = ref<Array<PushCampaign['audience']>>([])
const visibleAudiences = computed(() =>
	audiences.value.filter((audience) => audience === 'all' || audience === 'active'),
)
const bodyMaxLength = ref(2000)
const titleMaxLength = ref(120)

const commonOffsets = [5, 3, 2, 1, 0, -1, -2, -3, -5, -7]
const audienceOptions: Record<PushCampaign['audience'], string> = {
	all: 'Всем',
	active: 'Активным участникам',
}

const oneTimeForm = ref({
	id: null as number | null,
	name: '',
	title: '',
	body: '',
	url: '',
	audience: 'all' as PushCampaign['audience'],
	sendAt: '',
})

const regularForm = ref({
	id: null as number | null,
	name: '',
	title: '',
	body: '',
	url: '',
	audience: 'all' as PushCampaign['audience'],
	offsets: [] as number[],
	customOffsets: '',
	isEnabled: true,
})

const inputClass =
	'min-h-[48px] w-full rounded-2xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition focus:border-primary-400 dark:border-white/10 dark:bg-white/5 dark:text-white'

const regularCampaigns = computed(() =>
	campaigns.value.filter((campaign) => campaign.kind === 'billing_relative'),
)
const oneTimeCampaigns = computed(() =>
	campaigns.value.filter((campaign) => campaign.kind === 'one_time'),
)

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}

function toDateTimeLocal(value: string | Date | null | undefined) {
	if (!value) return ''
	const date = typeof value === 'string' ? new Date(value) : value
	if (Number.isNaN(date.getTime())) return ''
	const pad = (part: number) => String(part).padStart(2, '0')
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function formatDateTime(value: string | null) {
	if (!value) return '—'
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function parseCustomOffsets(input: string) {
	return input
		.split(',')
		.map((item) => Number(item.trim()))
		.filter((item) => Number.isInteger(item) && item >= -30 && item <= 30)
}

function buildRegularOffsets() {
	return Array.from(
		new Set([...regularForm.value.offsets, ...parseCustomOffsets(regularForm.value.customOffsets)]),
	).sort((a, b) => a - b)
}

function formatOffsetLabel(offset: number) {
	if (offset > 0) return `за ${offset} дн.`
	if (offset === 0) return 'в день'
	return `+${Math.abs(offset)} дн.`
}

function resetOneTimeForm() {
	oneTimeForm.value = {
		id: null,
		name: '',
		title: '',
		body: '',
		url: '',
		audience: 'all',
		sendAt: '',
	}
}

function resetRegularForm() {
	regularForm.value = {
		id: null,
		name: '',
		title: '',
		body: '',
		url: '',
		audience: 'all',
		offsets: [],
		customOffsets: '',
		isEnabled: true,
	}
}

function editOneTime(campaign: PushCampaign) {
	resetMessages()
	oneTimeForm.value = {
		id: campaign.id,
		name: campaign.name,
		title: campaign.title,
		body: campaign.body,
		url: campaign.url ?? '',
		audience: campaign.audience,
		sendAt: toDateTimeLocal(campaign.sendAt),
	}
}

function editRegular(campaign: PushCampaign) {
	resetMessages()
	const selectedCommon = campaign.offsetDays.filter((value) => commonOffsets.includes(value))
	const custom = campaign.offsetDays.filter((value) => !commonOffsets.includes(value))
	regularForm.value = {
		id: campaign.id,
		name: campaign.name,
		title: campaign.title,
		body: campaign.body,
		url: campaign.url ?? '',
		audience: campaign.audience,
		offsets: selectedCommon,
		customOffsets: custom.join(', '),
		isEnabled: campaign.isEnabled,
	}
}

async function loadData() {
	loading.value = true
	resetMessages()
	const res = await api.get<{
		campaigns: PushCampaign[]
		runs: PushCampaignRun[]
		audiences: Array<PushCampaign['audience']>
		bodyMaxLength: number
		titleMaxLength: number
	}>('/api/admin/notifications')

	if (res.success) {
		campaigns.value = res.data.campaigns
		runs.value = res.data.runs
		audiences.value = res.data.audiences
		bodyMaxLength.value = res.data.bodyMaxLength
		titleMaxLength.value = res.data.titleMaxLength
	} else {
		errorMessage.value = res.error.message
	}

	loading.value = false
}

async function saveOneTime() {
	resetMessages()
	savingOneTime.value = true

	const payload = {
		name: oneTimeForm.value.name.trim(),
		title: oneTimeForm.value.title.trim(),
		body: oneTimeForm.value.body.trim(),
		url: oneTimeForm.value.url.trim() || null,
		audience: oneTimeForm.value.audience,
		sendAt: oneTimeForm.value.sendAt ? new Date(oneTimeForm.value.sendAt).toISOString() : undefined,
	}

	const res = oneTimeForm.value.id
		? await api.patch<PushCampaign>(`/api/admin/notifications/${oneTimeForm.value.id}`, payload)
		: await api.post<PushCampaign>('/api/admin/notifications/one-time', payload)

	if (res.success) {
		successMessage.value = oneTimeForm.value.id
			? 'Разовая push-кампания обновлена.'
			: 'Разовая push-кампания поставлена в очередь.'
		resetOneTimeForm()
		await loadData()
	} else {
		errorMessage.value = res.error.message
	}

	savingOneTime.value = false
}

async function saveRegular() {
	resetMessages()
	savingRegular.value = true

	const offsets = buildRegularOffsets()
	if (offsets.length === 0) {
		errorMessage.value = 'Укажите хотя бы один день относительно даты списания.'
		savingRegular.value = false
		return
	}

	const payload = {
		name: regularForm.value.name.trim(),
		title: regularForm.value.title.trim(),
		body: regularForm.value.body.trim(),
		url: regularForm.value.url.trim() || null,
		audience: regularForm.value.audience,
		offsetDays: offsets,
		isEnabled: regularForm.value.isEnabled,
	}

	const res = regularForm.value.id
		? await api.patch<PushCampaign>(`/api/admin/notifications/${regularForm.value.id}`, payload)
		: await api.post<PushCampaign>('/api/admin/notifications/regular', payload)

	if (res.success) {
		successMessage.value = regularForm.value.id
			? 'Регулярная push-кампания обновлена.'
			: 'Регулярная push-кампания сохранена.'
		resetRegularForm()
		await loadData()
	} else {
		errorMessage.value = res.error.message
	}

	savingRegular.value = false
}

async function toggleRegular(campaign: PushCampaign) {
	actionLoadingId.value = campaign.id
	resetMessages()

	const res = await api.patch<PushCampaign>(`/api/admin/notifications/${campaign.id}`, {
		isEnabled: !campaign.isEnabled,
		status: campaign.isEnabled ? 'paused' : 'active',
	})

	if (res.success) {
		successMessage.value = campaign.isEnabled
			? 'Регулярная рассылка приостановлена.'
			: 'Регулярная рассылка включена.'
		await loadData()
	} else {
		errorMessage.value = res.error.message
	}

	actionLoadingId.value = null
}

async function sendOneTimeNow(campaign: PushCampaign) {
	actionLoadingId.value = campaign.id
	resetMessages()
	const res = await api.post<PushCampaign>(`/api/admin/notifications/${campaign.id}/send-now`)
	if (res.success) {
		successMessage.value = 'Разовая рассылка поставлена на немедленную отправку.'
		await loadData()
	} else {
		errorMessage.value = res.error.message
	}
	actionLoadingId.value = null
}

onMounted(async () => {
	await loadData()
})
</script>

<template>
	<div class="p-6 space-y-6">
		<div>
			<h1 class="text-2xl font-bold dark:text-white">Уведомления</h1>
			<p class="text-sm text-gray-500 dark:text-gray-400">
				Разовые рассылки и регулярные push-кампании по дате списания. Текст хранится с запасом:
				до {{ bodyMaxLength }} символов.
			</p>
		</div>

		<p
			v-if="errorMessage"
			class="rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-500 dark:text-red-300"
		>
			{{ errorMessage }}
		</p>
		<p
			v-if="successMessage"
			class="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-600 dark:text-emerald-300"
		>
			{{ successMessage }}
		</p>

		<div v-if="loading" class="flex justify-center py-16">
			<div class="animate-spin w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full" />
		</div>

		<div v-else class="grid grid-cols-1 xl:grid-cols-2 gap-6">
			<section class="glass rounded-3xl p-5 space-y-4">
				<div class="flex items-center justify-between gap-3">
					<div>
						<h2 class="text-lg font-semibold dark:text-white">Разовая рассылка</h2>
						<p class="text-sm text-gray-500 dark:text-gray-400">
							Создаёт разовую кампанию для рассылки по выбранной аудитории.
						</p>
					</div>
					<button
						v-if="oneTimeForm.id"
						class="rounded-2xl border border-gray-200 px-4 py-2 text-sm dark:border-white/10 dark:text-white"
						@click="resetOneTimeForm"
					>
						Новая
					</button>
				</div>

				<input v-model="oneTimeForm.name" :maxlength="120" :class="inputClass" placeholder="Название кампании" />
				<input v-model="oneTimeForm.title" :maxlength="titleMaxLength" :class="inputClass" placeholder="Заголовок push" />
				<textarea
					v-model="oneTimeForm.body"
					:maxlength="bodyMaxLength"
					:class="inputClass"
					class="min-h-[140px]"
					placeholder="Текст уведомления"
				/>
				<div class="flex justify-end text-xs text-gray-500 dark:text-gray-400">
					{{ oneTimeForm.body.length }}/{{ bodyMaxLength }}
				</div>
				<input v-model="oneTimeForm.url" :class="inputClass" placeholder="Ссылка при открытии, например /app/chats" />
				<div class="grid grid-cols-1 md:grid-cols-2 gap-3">
					<select v-model="oneTimeForm.audience" :class="inputClass">
						<option v-for="audience in visibleAudiences" :key="audience" :value="audience">
							{{ audienceOptions[audience] }}
						</option>
					</select>
					<input
						v-model="oneTimeForm.sendAt"
						type="datetime-local"
						:class="inputClass"
						placeholder="Если пусто — отправится сразу"
					/>
				</div>
				<div class="flex gap-3">
					<button class="btn-primary px-4 py-2.5" :disabled="savingOneTime" @click="saveOneTime">
						{{ savingOneTime ? 'Сохранение...' : oneTimeForm.id ? 'Сохранить изменения' : 'Создать рассылку' }}
					</button>
				</div>
			</section>

			<section class="glass rounded-3xl p-5 space-y-4">
				<div class="flex items-center justify-between gap-3">
					<div>
						<h2 class="text-lg font-semibold dark:text-white">Регулярные уведомления</h2>
						<p class="text-sm text-gray-500 dark:text-gray-400">
							Срабатывают относительно даты списания: за 5, 3, 2, 1 день, в день списания и после него.
						</p>
					</div>
					<button
						v-if="regularForm.id"
						class="rounded-2xl border border-gray-200 px-4 py-2 text-sm dark:border-white/10 dark:text-white"
						@click="resetRegularForm"
					>
						Новая
					</button>
				</div>

				<input v-model="regularForm.name" :maxlength="120" :class="inputClass" placeholder="Название регулярной кампании" />
				<input v-model="regularForm.title" :maxlength="titleMaxLength" :class="inputClass" placeholder="Заголовок push" />
				<textarea
					v-model="regularForm.body"
					:maxlength="bodyMaxLength"
					:class="inputClass"
					class="min-h-[140px]"
					placeholder="Текст уведомления"
				/>
				<div class="flex justify-end text-xs text-gray-500 dark:text-gray-400">
					{{ regularForm.body.length }}/{{ bodyMaxLength }}
				</div>
				<input v-model="regularForm.url" :class="inputClass" placeholder="Ссылка при открытии, например /app/payment" />
				<select v-model="regularForm.audience" :class="inputClass">
					<option v-for="audience in visibleAudiences" :key="audience" :value="audience">
						{{ audienceOptions[audience] }}
					</option>
				</select>
				<div class="space-y-3 rounded-2xl border border-gray-200 p-4 dark:border-white/10">
					<p class="text-sm font-medium dark:text-white">Дни относительно даты списания</p>
					<div class="flex flex-wrap gap-2">
						<label
							v-for="offset in commonOffsets"
							:key="offset"
							class="inline-flex items-center gap-2 rounded-full border border-gray-200 px-3 py-2 text-sm dark:border-white/10 dark:text-white"
						>
							<input v-model="regularForm.offsets" type="checkbox" :value="offset" class="rounded" />
								<span>{{ formatOffsetLabel(offset) }}</span>
						</label>
					</div>
					<input
						v-model="regularForm.customOffsets"
						:class="inputClass"
						placeholder="Доп. дни через запятую: 10 — заранее, -2 — после"
					/>
				</div>
				<label class="inline-flex items-center gap-3 text-sm dark:text-white">
					<input v-model="regularForm.isEnabled" type="checkbox" class="rounded" />
					<span>Кампания активна сразу после сохранения</span>
				</label>
				<button class="btn-primary px-4 py-2.5" :disabled="savingRegular" @click="saveRegular">
					{{ savingRegular ? 'Сохранение...' : regularForm.id ? 'Сохранить изменения' : 'Сохранить регулярную кампанию' }}
				</button>
			</section>
		</div>

		<div v-if="!loading" class="grid grid-cols-1 xl:grid-cols-2 gap-6">
			<section class="glass rounded-3xl p-5 space-y-4">
				<h2 class="text-lg font-semibold dark:text-white">Регулярные кампании</h2>
				<div v-if="regularCampaigns.length === 0" class="text-sm text-gray-500 dark:text-gray-400">
					Регулярные push-кампании ещё не созданы.
				</div>
				<div v-for="campaign in regularCampaigns" :key="campaign.id" class="rounded-2xl border border-gray-200 p-4 dark:border-white/10">
					<div class="flex items-start justify-between gap-4">
						<div class="space-y-1">
							<p class="font-medium dark:text-white">{{ campaign.name }}</p>
							<p class="text-sm text-gray-500 dark:text-gray-400">
								{{ audienceOptions[campaign.audience] }} · дни:
								{{ campaign.offsetDays.join(', ') || '—' }}
							</p>
							<p class="text-xs text-gray-500 dark:text-gray-500">
								Последний запуск: {{ formatDateTime(campaign.lastRunAt) }} · отправлено:
								{{ campaign.lastRunSent }} · ошибок: {{ campaign.lastRunFailed }}
							</p>
							<p v-if="campaign.lastError" class="text-xs text-red-500">{{ campaign.lastError }}</p>
						</div>
						<div class="flex flex-col gap-2">
							<button
								class="rounded-2xl border border-gray-200 px-3 py-2 text-sm dark:border-white/10 dark:text-white"
								@click="editRegular(campaign)"
							>
								Изменить
							</button>
							<button
								class="rounded-2xl px-3 py-2 text-sm text-white"
								:class="campaign.isEnabled ? 'bg-amber-500' : 'bg-emerald-600'"
								:disabled="actionLoadingId === campaign.id"
								@click="toggleRegular(campaign)"
							>
								{{
									actionLoadingId === campaign.id
										? '...'
										: campaign.isEnabled
											? 'Пауза'
											: 'Включить'
								}}
							</button>
						</div>
					</div>
				</div>
			</section>

			<section class="glass rounded-3xl p-5 space-y-4">
				<h2 class="text-lg font-semibold dark:text-white">Разовые кампании</h2>
				<div v-if="oneTimeCampaigns.length === 0" class="text-sm text-gray-500 dark:text-gray-400">
					Разовые push-кампании ещё не создавались.
				</div>
				<div v-for="campaign in oneTimeCampaigns" :key="campaign.id" class="rounded-2xl border border-gray-200 p-4 dark:border-white/10">
					<div class="flex items-start justify-between gap-4">
						<div class="space-y-1">
							<p class="font-medium dark:text-white">{{ campaign.name }}</p>
							<p class="text-sm text-gray-500 dark:text-gray-400">
								{{ audienceOptions[campaign.audience] }} · статус: {{ campaign.status }}
							</p>
							<p class="text-xs text-gray-500 dark:text-gray-500">
								План: {{ formatDateTime(campaign.sendAt) }} · отправлено: {{ campaign.lastRunSent }}
								· ошибок: {{ campaign.lastRunFailed }}
							</p>
							<p v-if="campaign.lastError" class="text-xs text-red-500">{{ campaign.lastError }}</p>
						</div>
						<div class="flex flex-col gap-2">
							<button
								class="rounded-2xl border border-gray-200 px-3 py-2 text-sm dark:border-white/10 dark:text-white"
								@click="editOneTime(campaign)"
							>
								Изменить
							</button>
							<button
								class="rounded-2xl bg-primary-600 px-3 py-2 text-sm text-white"
								:disabled="actionLoadingId === campaign.id"
								@click="sendOneTimeNow(campaign)"
							>
								{{ actionLoadingId === campaign.id ? '...' : 'Отправить сейчас' }}
							</button>
						</div>
					</div>
				</div>
			</section>
		</div>

		<section v-if="!loading" class="glass rounded-3xl p-5 space-y-4">
			<h2 class="text-lg font-semibold dark:text-white">Аудит запусков</h2>
			<div class="overflow-auto">
				<table class="min-w-full text-sm">
					<thead class="text-left text-gray-500 dark:text-gray-400">
						<tr>
							<th class="pb-3 pr-4">Кампания</th>
							<th class="pb-3 pr-4">Дата запуска</th>
							<th class="pb-3 pr-4">Сценарий</th>
							<th class="pb-3 pr-4">Аудитория</th>
							<th class="pb-3 pr-4">Подписок</th>
							<th class="pb-3 pr-4">Отправлено</th>
							<th class="pb-3 pr-4">Ошибок</th>
							<th class="pb-3">Статус</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="run in runs" :key="run.id" class="border-t border-gray-200/60 dark:border-white/10">
							<td class="py-3 pr-4 dark:text-white">{{ run.campaign.name }}</td>
							<td class="py-3 pr-4 text-gray-500 dark:text-gray-400">{{ formatDateTime(run.startedAt) }}</td>
							<td class="py-3 pr-4 text-gray-500 dark:text-gray-400">
								{{ run.offsetDays == null ? 'Разовая' : `${run.offsetDays > 0 ? '+' : ''}${run.offsetDays} дн.` }}
							</td>
							<td class="py-3 pr-4 text-gray-500 dark:text-gray-400">{{ run.audienceSize }}</td>
							<td class="py-3 pr-4 text-gray-500 dark:text-gray-400">{{ run.subscriptionCount }}</td>
							<td class="py-3 pr-4 text-emerald-600 dark:text-emerald-400">{{ run.sentCount }}</td>
							<td class="py-3 pr-4 text-red-500">{{ run.failedCount }}</td>
							<td class="py-3">
								<span
									class="inline-flex rounded-full px-2.5 py-1 text-xs font-medium"
									:class="
										run.status === 'completed'
											? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-300'
											: run.status === 'failed'
												? 'bg-red-500/10 text-red-500 dark:text-red-300'
												: 'bg-amber-500/10 text-amber-600 dark:text-amber-300'
									"
								>
									{{ run.status }}
								</span>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</section>
	</div>
</template>
