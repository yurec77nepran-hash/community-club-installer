<script setup lang="ts">
import type { Event } from '@community-club/shared/db/schema'

const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()

const loading = ref(true)
const saving = ref(false)
const uploadingCover = ref(false)
const events = ref<Event[]>([])
const currentDate = ref(new Date())
const selectedDate = ref(startOfDay(new Date()))
const showForm = ref(false)
const editItem = ref<Event | null>(null)
const errorMessage = ref('')

const form = ref({
	title: '',
	description: '',
	imageUrl: '',
	eventDate: toDateTimeLocal(new Date()),
})

const weekDays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
const inputClass =
	'min-h-[48px] w-full rounded-2xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition focus:border-primary-400 dark:border-white/10 dark:bg-white/5 dark:text-white'

const monthLabel = computed(() =>
	currentDate.value.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' }),
)

const monthKey = computed(() => {
	const year = currentDate.value.getFullYear()
	const month = String(currentDate.value.getMonth() + 1).padStart(2, '0')
	return `${year}-${month}`
})

const calendarDays = computed(() => {
	const firstDay = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth(), 1)
	const lastDay = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() + 1, 0)
	const startOffset = (firstDay.getDay() + 6) % 7
	const cells: Array<{
		key: string
		date: Date
		label: number
		inMonth: boolean
		events: Event[]
	}> = []

	for (let i = startOffset; i > 0; i--) {
		const date = new Date(firstDay)
		date.setDate(firstDay.getDate() - i)
		cells.push(makeCalendarCell(date, false))
	}

	for (let day = 1; day <= lastDay.getDate(); day++) {
		const date = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth(), day)
		cells.push(makeCalendarCell(date, true))
	}

	while (cells.length % 7 !== 0) {
		const lastCellDate = new Date(cells[cells.length - 1]?.date ?? lastDay)
		lastCellDate.setDate(lastCellDate.getDate() + 1)
		cells.push(makeCalendarCell(lastCellDate, false))
	}

	return cells
})

const selectedDayEvents = computed(() =>
	events.value
		.filter((item) => isSameDay(new Date(item.eventDate), selectedDate.value))
		.sort((a, b) => +new Date(a.eventDate) - +new Date(b.eventDate)),
)

function startOfDay(date: Date) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

function isSameDay(a: Date, b: Date) {
	return (
		a.getFullYear() === b.getFullYear() &&
		a.getMonth() === b.getMonth() &&
		a.getDate() === b.getDate()
	)
}

function makeCalendarCell(date: Date, inMonth: boolean) {
	return {
		key: date.toISOString(),
		date,
		label: date.getDate(),
		inMonth,
		events: events.value.filter((item) => isSameDay(new Date(item.eventDate), date)),
	}
}

function toDateTimeLocal(date: Date) {
	const pad = (value: number) => String(value).padStart(2, '0')
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function formatEventDate(dateStr: string) {
	return new Date(dateStr).toLocaleString('ru-RU', {
		day: 'numeric',
		month: 'long',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function prevMonth() {
	currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() - 1, 1)
}

function nextMonth() {
	currentDate.value = new Date(currentDate.value.getFullYear(), currentDate.value.getMonth() + 1, 1)
}

function selectDay(date: Date) {
	selectedDate.value = startOfDay(date)
}

function openCreate(date = selectedDate.value) {
	editItem.value = null
	errorMessage.value = ''
	const prefill = new Date(date)
	prefill.setHours(12, 0, 0, 0)
	form.value = {
		title: '',
		description: '',
		imageUrl: '',
		eventDate: toDateTimeLocal(prefill),
	}
	showForm.value = true
}

function openEdit(item: Event) {
	editItem.value = item
	errorMessage.value = ''
	form.value = {
		title: item.title,
		description: item.description ?? '',
		imageUrl: (item as Event & { imageUrl?: string | null }).imageUrl ?? '',
		eventDate: toDateTimeLocal(new Date(item.eventDate)),
	}
	showForm.value = true
}

async function loadEvents() {
	loading.value = true
	const res = await api.get<Event[]>('/api/admin/events')
	if (res.success) {
		events.value = res.data
	} else {
		errorMessage.value = res.error.message
	}
	loading.value = false
}

async function saveEvent() {
	saving.value = true
	errorMessage.value = ''

	const payload = {
		title: form.value.title.trim(),
		description: form.value.description.trim() || undefined,
		imageUrl: form.value.imageUrl.trim() || null,
		eventDate: new Date(form.value.eventDate).toISOString(),
	}

	const res = editItem.value
		? await api.patch<Event>(`/api/admin/events/${editItem.value.id}`, payload)
		: await api.post<Event>('/api/admin/events', payload)

	if (res.success) {
		showForm.value = false
		await loadEvents()
		selectedDate.value = startOfDay(new Date(payload.eventDate))
	} else {
		errorMessage.value = res.error.message
	}

	saving.value = false
}

async function deleteEvent(id: number) {
	errorMessage.value = ''
	const res = await api.delete<{ deleted: true }>(`/api/admin/events/${id}`)
	if (res.success) {
		await loadEvents()
	} else {
		errorMessage.value = res.error.message
	}
}

async function uploadCover(event: Event) {
	const input = event.target as HTMLInputElement
	const file = input.files?.[0]
	if (!file) return
	input.value = ''

	uploadingCover.value = true
	errorMessage.value = ''

	try {
		const result = await mediaUpload.uploadFile(file)

		if (result.success) {
			form.value.imageUrl = result.data.url ?? result.data.path
		} else {
			errorMessage.value = result.error.message
		}
	} catch {
		errorMessage.value = 'Ошибка сети при загрузке обложки.'
	} finally {
		uploadingCover.value = false
	}
}

onMounted(async () => {
	await loadEvents()
})
</script>

<template>
	<div class="p-6 space-y-6">
		<div class="flex items-center justify-between gap-4">
			<div>
				<h1 class="text-2xl font-bold dark:text-white">Календарь событий</h1>
				<p class="text-sm text-gray-500 dark:text-gray-400">
					Выберите день и добавьте событие, которое увидят пользователи в разделе календаря.
				</p>
			</div>
			<button class="btn-primary px-4 py-2.5" @click="openCreate()">Добавить событие</button>
		</div>

		<p
			v-if="errorMessage"
			class="rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-500 dark:text-red-300"
		>
			{{ errorMessage }}
		</p>

		<div v-if="loading" class="flex justify-center py-16">
			<div
				class="animate-spin w-8 h-8 border-2 border-primary-200 border-t-primary-600 rounded-full"
			/>
		</div>

		<div v-else class="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
			<div class="glass rounded-3xl p-5 shadow-xl">
				<div class="mb-4 flex items-center justify-between">
					<button class="btn-secondary px-3 py-2" @click="prevMonth">←</button>
					<h2 class="text-lg font-semibold capitalize dark:text-white">{{ monthLabel }}</h2>
					<button class="btn-secondary px-3 py-2" @click="nextMonth">→</button>
				</div>

				<div class="mb-2 grid grid-cols-7 gap-2">
					<div
						v-for="weekDay in weekDays"
						:key="weekDay"
						class="py-2 text-center text-xs font-semibold uppercase tracking-wide text-gray-400"
					>
						{{ weekDay }}
					</div>
				</div>

				<div class="grid grid-cols-7 gap-2">
					<button
						v-for="day in calendarDays"
						:key="day.key"
						type="button"
						class="min-h-[110px] rounded-2xl border p-2 text-left transition-all"
						:class="
							day.inMonth
								? isSameDay(day.date, selectedDate)
									? 'border-primary-500 bg-primary-500/10 shadow-lg shadow-primary-500/10'
									: 'border-gray-200/70 bg-white/70 hover:border-primary-300 dark:border-white/8 dark:bg-white/5 dark:hover:border-white/20'
								: 'border-transparent bg-gray-100/60 text-gray-300 dark:bg-white/[0.03] dark:text-white/15'
						"
						@click="selectDay(day.date)"
					>
						<div class="mb-2 flex items-center justify-between">
							<span class="text-sm font-semibold" :class="day.inMonth ? 'dark:text-white text-gray-900' : ''">
								{{ day.label }}
							</span>
							<span
								v-if="day.events.length"
								class="rounded-full bg-primary-500/15 px-2 py-0.5 text-[10px] font-semibold text-primary-600 dark:text-primary-300"
							>
								{{ day.events.length }}
							</span>
						</div>

						<div v-if="day.events.length" class="space-y-1">
							<div
								v-for="eventItem in day.events.slice(0, 2)"
								:key="eventItem.id"
								class="truncate rounded-xl bg-primary-500/10 px-2 py-1 text-[11px] font-medium text-primary-700 dark:text-primary-200"
							>
								{{ eventItem.title }}
							</div>
							<div
								v-if="day.events.length > 2"
								class="text-[11px] text-gray-500 dark:text-gray-400"
							>
								ещё {{ day.events.length - 2 }}
							</div>
						</div>
					</button>
				</div>
			</div>

			<div class="glass rounded-3xl p-5 shadow-xl">
				<div class="mb-4 flex items-center justify-between gap-3">
					<div>
						<h3 class="text-lg font-semibold dark:text-white">
							{{ selectedDate.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) }}
						</h3>
						<p class="text-sm text-gray-500 dark:text-gray-400">
							{{ selectedDayEvents.length ? 'События на выбранный день' : 'На этот день событий пока нет' }}
						</p>
					</div>
					<button class="btn-secondary px-3 py-2" @click="openCreate(selectedDate)">
						Добавить
					</button>
				</div>

				<div v-if="selectedDayEvents.length" class="space-y-3">
					<div
						v-for="eventItem in selectedDayEvents"
						:key="eventItem.id"
						class="rounded-2xl border border-gray-200/70 bg-white/80 p-3 dark:border-white/8 dark:bg-white/5"
					>
						<div
							v-if="eventItem.imageUrl"
							class="mb-3 aspect-[16/9] overflow-hidden rounded-2xl bg-black/10"
						>
							<img
								:src="eventItem.imageUrl"
								:alt="eventItem.title"
								class="h-full w-full object-cover"
							/>
						</div>

						<div class="mb-2 flex items-start justify-between gap-3">
							<div>
								<h4 class="font-semibold dark:text-white">{{ eventItem.title }}</h4>
								<p class="text-xs text-primary-600 dark:text-primary-300">
									{{ formatEventDate(eventItem.eventDate) }}
								</p>
							</div>
						</div>

						<p
							v-if="eventItem.description"
							class="mb-3 text-sm text-gray-600 dark:text-gray-300 whitespace-pre-wrap"
						>
							{{ eventItem.description }}
						</p>

						<div class="flex gap-2">
							<button class="btn-secondary px-3 py-2" @click="openEdit(eventItem)">Изменить</button>
							<button class="px-3 py-2 rounded-xl bg-red-500/10 text-red-600 dark:text-red-300" @click="deleteEvent(eventItem.id)">
								Удалить
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div
			v-if="showForm"
			class="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm"
			@click.self="showForm = false"
		>
			<div class="glass w-full max-w-2xl rounded-3xl p-6 shadow-2xl">
				<div class="mb-4 flex items-center justify-between">
					<h3 class="text-xl font-semibold dark:text-white">
						{{ editItem ? 'Редактировать событие' : 'Новое событие' }}
					</h3>
					<button class="text-gray-400 hover:text-gray-700 dark:hover:text-white" @click="showForm = false">
						✕
					</button>
				</div>

				<div class="grid gap-4 md:grid-cols-2">
					<label class="space-y-1 md:col-span-2">
						<span class="text-sm font-medium dark:text-white">Название</span>
						<input v-model="form.title" :class="inputClass" placeholder="Встреча по..." />
					</label>

					<label class="space-y-1">
						<span class="text-sm font-medium dark:text-white">Дата и время</span>
						<input v-model="form.eventDate" type="datetime-local" :class="inputClass" />
					</label>

					<div class="space-y-1">
						<span class="text-sm font-medium dark:text-white">Обложка</span>
						<div class="flex items-center gap-2">
							<label class="btn-secondary cursor-pointer px-3 py-2">
								<input type="file" class="hidden" accept="image/*" @change="uploadCover" />
								{{ uploadingCover ? 'Загружаю...' : 'Загрузить' }}
							</label>
							<button
								v-if="form.imageUrl"
								type="button"
								class="px-3 py-2 rounded-xl bg-red-500/10 text-red-600 dark:text-red-300"
								@click="form.imageUrl = ''"
							>
								Убрать
							</button>
						</div>
					</div>

					<div
						v-if="form.imageUrl"
						class="md:col-span-2 aspect-[16/9] overflow-hidden rounded-2xl bg-black/10"
					>
						<img :src="form.imageUrl" alt="Обложка события" class="h-full w-full object-cover" />
					</div>

					<label class="space-y-1 md:col-span-2">
						<span class="text-sm font-medium dark:text-white">Описание</span>
						<textarea
							v-model="form.description"
							:class="`${inputClass} min-h-[140px]`"
							placeholder="Краткое описание события"
						/>
					</label>
				</div>

				<div class="mt-6 flex justify-end gap-3">
					<button class="btn-secondary px-4 py-2.5" @click="showForm = false">Отмена</button>
					<button class="btn-primary px-4 py-2.5" :disabled="saving || !form.title.trim()" @click="saveEvent">
						{{ saving ? 'Сохраняю...' : editItem ? 'Сохранить' : 'Создать событие' }}
					</button>
				</div>
			</div>
		</div>
	</div>
</template>
