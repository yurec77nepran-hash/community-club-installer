<script setup lang="ts">
import type { ChannelPost } from '@community-club/shared/db/schema'

const api = useAdminApi()
const posts = ref<ChannelPost[]>([])
const loading = ref(true)
const newPostContent = ref('')
const posting = ref(false)

onMounted(async () => {
	const res = await api.get<{ items: ChannelPost[] }>('/api/channels?limit=50')
	if (res.success) {
		posts.value = res.data.items
	}
	loading.value = false
})

async function createPost() {
	if (!newPostContent.value.trim()) return
	posting.value = true
	const res = await api.post<ChannelPost>('/api/channels', { content: newPostContent.value })
	if (res.success) {
		posts.value.unshift(res.data)
		newPostContent.value = ''
	}
	posting.value = false
}

async function deletePost(id: number) {
	if (!confirm('Удалить пост?')) return
	await api.delete(`/api/channels/${id}`)
	posts.value = posts.value.filter((p) => p.id !== id)
}

async function togglePin(id: number) {
	const res = await api.patch<ChannelPost>(`/api/channels/${id}/pin`)
	if (res.success) {
		const idx = posts.value.findIndex((p) => p.id === id)
		if (idx !== -1) posts.value[idx] = res.data
	}
}
</script>

<template>
	<div class="p-6">
		<h1 class="text-2xl font-bold mb-6">Канал объявлений</h1>

		<!-- Создать пост -->
		<div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100 mb-6">
			<textarea
				v-model="newPostContent"
				placeholder="Написать объявление..."
				class="w-full px-3 py-2 rounded-lg border text-sm resize-none"
				rows="3"
			/>
			<div class="flex justify-end mt-2">
				<button
					:disabled="!newPostContent.trim() || posting"
					class="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm disabled:opacity-50"
					@click="createPost"
				>
					{{ posting ? 'Публикация...' : 'Опубликовать' }}
				</button>
			</div>
		</div>

		<!-- Посты -->
		<div class="space-y-3">
			<div v-for="post in posts" :key="post.id" class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
				<div class="flex justify-between items-start mb-2">
					<span v-if="post.isPinned" class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">Закреплён</span>
					<span v-else />
					<div class="flex gap-2">
						<button class="text-xs text-primary-600" @click="togglePin(post.id)">
							{{ post.isPinned ? 'Открепить' : 'Закрепить' }}
						</button>
						<button class="text-xs text-red-500" @click="deletePost(post.id)">Удалить</button>
					</div>
				</div>
				<p class="text-sm whitespace-pre-wrap">{{ post.content }}</p>
				<p class="text-xs text-gray-400 mt-2">
					{{ new Date(post.createdAt).toLocaleString('ru') }}
				</p>
			</div>
		</div>
	</div>
</template>
