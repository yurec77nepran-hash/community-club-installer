<script setup lang="ts">
import type { User } from '@community-club/shared/db/schema'

type PaymentSystemCheck = {
	checkedAt: string
	error: string | null
	current: {
		dateStart: string | null
		dateFinish: string | null
		tarrif: string | null
		amount: string | number | null
		autoPayment: boolean
	}
	payment: {
		date: string | null
		amount: number | null
		currency: string | null
		status: string | null
		invoiceId: string | null
		transactionId: string | null
		description: string | null
	}
	subscription: {
		id: string | null
		status: string | null
		amount: number | null
		currency: string | null
		startDate: string | null
		lastPaymentDate: string | null
		nextPaymentDate: string | null
		description: string | null
	}
	proposedUpdate: {
		dateStart: string | null
		dateFinish: string | null
		tarrif: string | null
		amount: string | null
		cpSubscriptionId: string | null
		cpAccountId: string | null
		autoPayment: boolean | null
	} | null
	canUpdate: boolean
}

type TelegramBot = { username: string; label: string }
type TelegramContact = {
	id: number
	botUsername: string
	telegramUserId: string
	telegramUsername: string | null
}
type MessengerContact = {
	id: number
	provider: 'telegram' | 'vk' | 'max'
	connectionLabel: string
	externalUserId: string
	displayName: string | null
	username: string | null
	consentStatus: 'active' | 'revoked'
	lastSeenAt: string | null
}

const route = useRoute()
const api = useAdminApi()
const uuid = computed(() => route.params.uuid as string)

const user = ref<User | null>(null)
const payment = ref<Record<string, unknown> | null>(null)
const loading = ref(true)
const savingProfile = ref(false)
const savingPassword = ref(false)
const savingPayment = ref(false)
const profileMessage = ref('')
const profileError = ref('')
const paymentMessage = ref('')
const paymentError = ref('')
const passwordMessage = ref('')
const passwordError = ref('')
const checkingPaymentSystem = ref(false)
const syncingPaymentSystem = ref(false)
const paymentSystemResult = ref<PaymentSystemCheck | null>(null)
const paymentSystemMessage = ref('')
const paymentSystemError = ref('')
const deletingUser = ref(false)
const deleteError = ref('')
const telegramContacts = ref<TelegramContact[]>([])
const messengerContacts = ref<MessengerContact[]>([])
const telegramBots = ref<TelegramBot[]>([])
const savingTelegramContact = ref(false)
const telegramContactError = ref('')
const telegramContactForm = ref({ botUsername: '', telegramUserId: '', telegramUsername: '' })

const editRole = ref('')
const editFullName = ref('')
const editEmail = ref('')
const editPhone = ref('')
const editTelegramChatId = ref('')
const editTelegramUsername = ref('')
const editMaxMessengerUserId = ref('')
const editPassword = ref('')
const editChatAdminBadge = ref(false)
const editAdminPermissions = ref<string[]>([])

const editPayment = ref({
	dateStart: '',
	dateFinish: '',
	autoPayment: false,
})

const roleOptions = [
	{ value: 'user', label: 'Пользователь' },
	{ value: 'admin', label: 'Сотрудник' },
	{ value: 'superadmin', label: 'Владелец' },
]

const adminPermissionOptions = [
	{ value: 'analytics', label: 'Аналитика' },
	{ value: 'users', label: 'Пользователи' },
	{ value: 'userActions', label: 'Действия участников' },
	{ value: 'support', label: 'Поддержка' },
	{ value: 'events', label: 'События' },
	{ value: 'materials', label: 'Материалы' },
	{ value: 'media', label: 'Медиа' },
	{ value: 'chats', label: 'Чаты' },
	{ value: 'payments', label: 'Платежи' },
	{ value: 'referrals', label: 'Рефералка' },
	{ value: 'documents', label: 'Документы' },
	{ value: 'settings', label: 'Настройки' },
	{ value: 'staffActions', label: 'Действия' },
	{ value: 'feed', label: 'Новости' },
	{ value: 'replies', label: 'Ответы' },
	{ value: 'tariffs', label: 'Тарифы' },
	{ value: 'notifications', label: 'Уведомления' },
	{ value: 'telegramBroadcasts', label: 'Рассылки' },
]

async function loadTelegramContacts() {
	const res = await api.get<{ contacts: TelegramContact[]; bots: TelegramBot[] }>(
		`/api/admin/users/${uuid.value}/telegram-contacts`,
	)
	if (!res.success) {
		telegramContactError.value = res.error.message
		return
	}
	telegramContacts.value = res.data.contacts
	telegramBots.value = res.data.bots
	if (!telegramContactForm.value.botUsername && telegramBots.value[0]) {
		telegramContactForm.value.botUsername = telegramBots.value[0].username
	}
}

async function loadMessengerContacts() {
	const res = await api.get<MessengerContact[]>(`/api/admin/users/${uuid.value}/messenger-contacts`)
	if (res.success) messengerContacts.value = res.data
}

function telegramBotLabel(username: string) {
	const bot = telegramBots.value.find((item) => item.username === username)
	return bot ? `${bot.label} (@${bot.username})` : `@${username}`
}

async function addTelegramContact() {
	telegramContactError.value = ''
	savingTelegramContact.value = true
	const res = await api.post<TelegramContact>(`/api/admin/users/${uuid.value}/telegram-contacts`, {
		...telegramContactForm.value,
		telegramUsername: telegramContactForm.value.telegramUsername || null,
	})
	if (res.success) {
		telegramContactForm.value = {
			botUsername: telegramBots.value[0]?.username ?? '',
			telegramUserId: '',
			telegramUsername: '',
		}
		await loadTelegramContacts()
	} else {
		telegramContactError.value = res.error.message
	}
	savingTelegramContact.value = false
}

async function deleteTelegramContact(id: number) {
	telegramContactError.value = ''
	const res = await api.delete(`/api/admin/users/${uuid.value}/telegram-contacts/${id}`)
	if (res.success) await loadTelegramContacts()
	else telegramContactError.value = res.error.message
}

onMounted(async () => {
	const [userRes] = await Promise.all([
		api.get<{ user: User; payment: Record<string, unknown> | null }>(
			`/api/admin/users/${uuid.value}`,
		),
		loadTelegramContacts(),
		loadMessengerContacts(),
	])

	if (userRes.success) {
		user.value = userRes.data.user
		payment.value = userRes.data.payment
		editRole.value = userRes.data.user.role
		editFullName.value = userRes.data.user.fullName ?? ''
		editEmail.value = userRes.data.user.email ?? ''
		editPhone.value = userRes.data.user.phone ?? ''
		editTelegramChatId.value = userRes.data.user.telegramChatId ?? ''
		editTelegramUsername.value = userRes.data.user.telegramUsername ?? ''
		editMaxMessengerUserId.value = userRes.data.user.maxMessengerUserId ?? ''
		editChatAdminBadge.value = userRes.data.user.chatAdminBadge
		editAdminPermissions.value = Array.isArray(userRes.data.user.adminPermissions)
			? userRes.data.user.adminPermissions
			: []
		fillPaymentForm(userRes.data.payment)
	}
	loading.value = false
})

function fillPaymentForm(p: Record<string, unknown> | null) {
	editPayment.value = {
		dateStart: String(p?.dateStart ?? '').slice(0, 10),
		dateFinish: String(p?.dateFinish ?? '').slice(0, 10),
		autoPayment: Boolean(p?.autoPayment),
	}
}

async function saveUser() {
	profileMessage.value = ''
	profileError.value = ''
	savingProfile.value = true
	const res = await api.patch(`/api/admin/users/${uuid.value}`, {
		role: editRole.value,
		fullName: editFullName.value,
		email: editEmail.value,
		phone: editPhone.value,
		telegramChatId: editTelegramChatId.value || null,
		telegramUsername: editTelegramUsername.value || null,
		maxMessengerUserId: editMaxMessengerUserId.value || null,
		adminPermissions: editRole.value === 'admin' ? editAdminPermissions.value : null,
		chatAdminBadge: editChatAdminBadge.value,
	})

	if (res.success && user.value) {
		user.value = { ...user.value, ...res.data }
		editRole.value = res.data.role ?? ''
		editFullName.value = res.data.fullName ?? ''
		editEmail.value = res.data.email ?? ''
		editPhone.value = res.data.phone ?? ''
		editTelegramChatId.value = res.data.telegramChatId ?? ''
		editTelegramUsername.value = res.data.telegramUsername ?? ''
		editMaxMessengerUserId.value = res.data.maxMessengerUserId ?? ''
		editAdminPermissions.value = Array.isArray(res.data.adminPermissions)
			? res.data.adminPermissions
			: []
		editChatAdminBadge.value = Boolean(res.data.chatAdminBadge)
		profileMessage.value = 'Профиль сохранён'
	} else {
		profileError.value = res.error.message
	}

	savingProfile.value = false
}

async function savePayment() {
	paymentMessage.value = ''
	paymentError.value = ''
	savingPayment.value = true
	const res = await api.patch(`/api/admin/users/${uuid.value}/payment`, {
		...editPayment.value,
	})
	if (res.success) {
		payment.value = res.data
		fillPaymentForm(res.data)
		paymentMessage.value = 'Подписка сохранена'
	} else {
		paymentError.value = res.error.message
	}
	savingPayment.value = false
}

async function savePassword() {
	passwordMessage.value = ''
	passwordError.value = ''

	if (!editPassword.value || editPassword.value.length < 8) {
		passwordError.value = 'Пароль должен быть не короче 8 символов'
		return
	}

	savingPassword.value = true
	const res = await api.patch<{ message: string }>(`/api/admin/users/${uuid.value}/password`, {
		password: editPassword.value,
	})

	if (res.success) {
		passwordMessage.value = 'Пароль сохранён'
		editPassword.value = ''
	} else {
		passwordError.value = res.error.message
	}

	savingPassword.value = false
}

function formatDate(value: unknown) {
	if (!value) return '—'
	const date = new Date(String(value))
	if (Number.isNaN(date.getTime())) return String(value).slice(0, 10) || '—'
	return date.toLocaleDateString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
	})
}

function formatDateTime(value: unknown) {
	if (!value) return '—'
	const date = new Date(String(value))
	if (Number.isNaN(date.getTime())) return String(value)
	return date.toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function formatMoney(value: unknown, currency = 'RUB') {
	const amount = Number(value)
	if (!Number.isFinite(amount)) return '—'
	return new Intl.NumberFormat('ru-RU', {
		style: 'currency',
		currency: currency || 'RUB',
		maximumFractionDigits: 2,
	}).format(amount)
}

function statusLabel(value: unknown) {
	const status = String(value ?? '').trim()
	if (!status) return '—'
	const labels: Record<string, string> = {
		Completed: 'Оплачен',
		Authorized: 'Авторизован',
		Declined: 'Отклонён',
		Active: 'Активна',
		Cancelled: 'Отменена',
		Rejected: 'Отклонена',
		success: 'Успешно',
		failed: 'Ошибка',
	}
	return labels[status] ?? status
}

async function checkPaymentSystem() {
	paymentSystemError.value = ''
	paymentSystemMessage.value = ''
	checkingPaymentSystem.value = true
	const res = await api.post<PaymentSystemCheck>(
		`/api/admin/users/${uuid.value}/payment-system/check`,
	)
	if (res.success) {
		paymentSystemResult.value = res.data
		if (res.data.error) {
			paymentSystemError.value = res.data.error
		}
	} else {
		paymentSystemError.value = res.error.message
	}
	checkingPaymentSystem.value = false
}

async function syncPaymentSystem() {
	paymentSystemError.value = ''
	paymentSystemMessage.value = ''
	syncingPaymentSystem.value = true
	const res = await api.post<{ payment: Record<string, unknown>; check: PaymentSystemCheck }>(
		`/api/admin/users/${uuid.value}/payment-system/sync`,
	)
	if (res.success) {
		payment.value = res.data.payment
		paymentSystemResult.value = res.data.check
		fillPaymentForm(res.data.payment)
		paymentSystemMessage.value = 'Платёжные данные обновлены'
	} else {
		paymentSystemError.value = res.error.message
	}
	syncingPaymentSystem.value = false
}

async function deleteUser() {
	deleteError.value = ''
	if (!user.value) return
	if (!confirm('Удалить пользователя?')) return

	deletingUser.value = true
	const res = await api.delete<{ deleted: boolean }>(`/api/admin/users/${uuid.value}`)
	if (res.success) {
		await navigateTo('/users')
		return
	}

	deleteError.value = res.error.message
	deletingUser.value = false
}
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-wrap items-center justify-between gap-3">
			<div class="flex items-center gap-3">
				<NuxtLink to="/users" class="p-1.5 rounded-xl hover:bg-gray-100/60 dark:hover:bg-white/10 transition text-gray-400">
					<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
					</svg>
				</NuxtLink>
				<h1 class="text-2xl font-bold dark:text-white">Пользователь</h1>
			</div>
		</div>

		<div v-if="loading" class="flex justify-center py-12">
			<div class="animate-spin w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full" />
		</div>

		<template v-else-if="user">
			<div class="mx-auto max-w-4xl space-y-5">
				<!-- Profile -->
				<div class="glass rounded-2xl p-5">
					<h2 class="font-semibold mb-4 dark:text-white">Профиль</h2>
					<div class="space-y-4">
						<div class="float-label">
							<input v-model="editFullName" class="glass-input" placeholder=" " />
							<label>Имя</label>
						</div>
						<div class="float-label">
							<input v-model="editEmail" type="email" class="glass-input" placeholder=" " />
							<label>Email</label>
						</div>
						<div class="float-label">
							<input v-model="editPhone" class="glass-input" placeholder=" " />
							<label>Телефон</label>
						</div>
						<div class="float-label">
							<input v-model="editTelegramChatId" class="glass-input" placeholder=" " />
							<label>Telegram ID</label>
						</div>
						<div class="float-label">
							<input v-model="editTelegramUsername" class="glass-input" placeholder=" " />
							<label>Telegram username</label>
						</div>
						<div class="float-label">
							<input v-model="editMaxMessengerUserId" class="glass-input" placeholder=" " />
							<label>MAX ID</label>
						</div>
						<div class="float-label">
							<select v-model="editRole" class="glass-input">
								<option v-for="option in roleOptions" :key="option.value" :value="option.value">
									{{ option.label }}
								</option>
							</select>
							<label>Доступ</label>
						</div>
						<div
							v-if="editRole === 'admin'"
							class="rounded-2xl border border-gray-200/60 bg-white/45 p-4 dark:border-white/10 dark:bg-white/[0.03]"
						>
							<p class="mb-3 text-sm font-semibold dark:text-white">Разделы админки</p>
							<div class="grid gap-3 sm:grid-cols-2">
								<label
									v-for="option in adminPermissionOptions"
									:key="option.value"
									class="flex items-center gap-2 text-sm dark:text-gray-300 cursor-pointer"
								>
									<input
										v-model="editAdminPermissions"
										type="checkbox"
										:value="option.value"
										class="glass-check"
									/>
									{{ option.label }}
								</label>
							</div>
						</div>
						<label class="flex items-start gap-3 rounded-2xl border border-gray-200/60 bg-white/45 p-4 text-sm text-gray-800 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-200">
							<input v-model="editChatAdminBadge" type="checkbox" class="glass-check mt-0.5" />
							<span>
								<span class="block font-semibold">Админ</span>
								<span class="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">
									Плашка появится рядом с именем в чатах.
								</span>
							</span>
						</label>
						<p v-if="profileError" class="text-sm text-red-500 dark:text-red-400">
							{{ profileError }}
						</p>
						<p v-else-if="profileMessage" class="text-sm text-green-600 dark:text-green-400">
							{{ profileMessage }}
						</p>
						<button
							class="btn-primary w-full"
							:disabled="savingProfile"
							@click="saveUser"
						>
							{{ savingProfile ? 'Сохранение...' : 'Сохранить профиль' }}
						</button>
					</div>
				</div>

				<div class="glass rounded-2xl p-5">
					<div class="mb-4 flex flex-wrap items-center justify-between gap-2">
						<h2 class="font-semibold dark:text-white">Telegram-профили</h2>
						<span class="text-xs text-gray-500 dark:text-gray-400">Можно привязать несколько ботов</span>
					</div>
					<div v-if="telegramContacts.length" class="mb-4 divide-y divide-gray-100/70 dark:divide-white/5">
						<div v-for="contact in telegramContacts" :key="contact.id" class="flex flex-wrap items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
							<div class="min-w-0">
								<p class="text-sm font-medium dark:text-white">{{ telegramBotLabel(contact.botUsername) }}</p>
								<p class="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
									ID {{ contact.telegramUserId }}<template v-if="contact.telegramUsername"> · @{{ contact.telegramUsername }}</template>
								</p>
							</div>
							<button class="text-xs text-gray-500 hover:text-red-500" @click="deleteTelegramContact(contact.id)">Удалить</button>
						</div>
					</div>
					<p v-else class="mb-4 text-sm text-gray-500 dark:text-gray-400">Telegram-профилей пока нет.</p>
					<div v-if="telegramBots.length" class="grid gap-3 sm:grid-cols-3">
						<div class="float-label">
							<select v-model="telegramContactForm.botUsername" class="glass-input">
								<option v-for="bot in telegramBots" :key="bot.username" :value="bot.username">{{ bot.label }}</option>
							</select>
							<label>Бот</label>
						</div>
						<div class="float-label">
							<input v-model="telegramContactForm.telegramUserId" inputmode="numeric" class="glass-input" placeholder=" " />
							<label>Telegram ID</label>
						</div>
						<div class="float-label">
							<input v-model="telegramContactForm.telegramUsername" class="glass-input" placeholder=" " />
							<label>Username (необязательно)</label>
						</div>
					</div>
					<p v-else class="text-xs text-amber-700 dark:text-amber-300">Боты для рассылки ещё не настроены.</p>
					<p v-if="telegramContactError" class="mt-3 text-sm text-red-500 dark:text-red-400">{{ telegramContactError }}</p>
					<button v-if="telegramBots.length" class="btn-secondary mt-4 w-full" :disabled="savingTelegramContact || !telegramContactForm.telegramUserId" @click="addTelegramContact">
						{{ savingTelegramContact ? 'Сохранение…' : 'Добавить Telegram-профиль' }}
					</button>
				</div>

				<div class="glass rounded-2xl p-5">
					<div class="mb-4 flex items-center justify-between gap-2">
						<h2 class="font-semibold dark:text-white">Мессенджеры</h2>
						<span class="text-xs text-gray-500 dark:text-gray-400">Сохраняются автоматически</span>
					</div>
					<div v-if="messengerContacts.length" class="divide-y divide-gray-100/70 dark:divide-white/5">
						<div v-for="contact in messengerContacts" :key="contact.id" class="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
							<div class="min-w-0">
								<p class="text-sm font-medium capitalize dark:text-white">{{ contact.provider }} · {{ contact.connectionLabel }}</p>
								<p class="mt-0.5 truncate text-xs text-gray-500 dark:text-gray-400">ID {{ contact.externalUserId }}<template v-if="contact.username"> · @{{ contact.username }}</template></p>
							</div>
							<span class="rounded-full px-2 py-1 text-xs" :class="contact.consentStatus === 'active' ? 'bg-green-500/10 text-green-700 dark:text-green-300' : 'bg-gray-500/10 text-gray-600 dark:text-gray-300'">{{ contact.consentStatus === 'active' ? 'Активен' : 'Отписан' }}</span>
						</div>
					</div>
					<p v-else class="text-sm text-gray-500 dark:text-gray-400">Профили VK и MAX появятся после первого сообщения пользователю или старта бота.</p>
				</div>

				<div class="glass rounded-2xl p-5">
					<h2 class="font-semibold mb-4 dark:text-white">Пароль</h2>
					<div class="space-y-4">
						<div class="float-label">
							<input
								v-model="editPassword"
								type="text"
								class="glass-input"
								placeholder=" "
							/>
							<label>Новый пароль</label>
						</div>
						<p class="text-xs text-gray-500 dark:text-gray-400">
							Можно вручную назначить пароль для входа пользователя. Текущая система входа при этом сохраняется.
						</p>
						<p v-if="passwordError" class="text-sm text-red-500 dark:text-red-400">
							{{ passwordError }}
						</p>
						<p v-else-if="passwordMessage" class="text-sm text-green-600 dark:text-green-400">
							{{ passwordMessage }}
						</p>
						<button
							class="btn-primary w-full"
							:disabled="savingPassword"
							@click="savePassword"
						>
							{{ savingPassword ? 'Сохранение...' : 'Сохранить пароль' }}
						</button>
					</div>
				</div>

				<!-- Payment -->
				<div class="glass rounded-2xl p-5">
					<h2 class="font-semibold mb-4 dark:text-white">Подписка</h2>
					<div class="space-y-4">
							<div class="float-label">
								<input v-model="editPayment.dateStart" type="date" class="glass-input" />
								<label>Начало</label>
							</div>
							<div class="float-label">
								<input v-model="editPayment.dateFinish" type="date" class="glass-input" />
								<label>Окончание</label>
							</div>
							<label class="flex items-center gap-2 text-sm dark:text-gray-300 cursor-pointer">
								<input v-model="editPayment.autoPayment" type="checkbox" class="glass-check" /> Автооплата
							</label>
							<p v-if="paymentError" class="text-sm text-red-500 dark:text-red-400">
								{{ paymentError }}
							</p>
							<p v-else-if="paymentMessage" class="text-sm text-green-600 dark:text-green-400">
								{{ paymentMessage }}
							</p>
							<button
								class="btn-primary w-full"
								:disabled="savingPayment"
								@click="savePayment"
							>
								{{ savingPayment ? 'Сохранение...' : 'Сохранить подписку' }}
							</button>
					</div>
				</div>

				<div class="glass rounded-2xl p-5">
					<div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
						<div>
							<h2 class="font-semibold dark:text-white">Платёжная система</h2>
						</div>
						<button
							class="btn-secondary shrink-0"
							:disabled="checkingPaymentSystem || syncingPaymentSystem"
							@click="checkPaymentSystem"
						>
							{{ checkingPaymentSystem ? 'Проверяем...' : 'Проверить' }}
						</button>
					</div>

					<div v-if="paymentSystemResult" class="mt-5 space-y-4">
						<div class="grid gap-3 md:grid-cols-3">
							<div class="rounded-2xl border border-gray-200/60 bg-white/45 p-4 dark:border-white/10 dark:bg-white/[0.03]">
								<p class="text-xs text-gray-500 dark:text-gray-400">Последний платёж</p>
								<p class="mt-1 text-sm font-semibold dark:text-white">
									{{ formatDateTime(paymentSystemResult.payment.date) }}
								</p>
								<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									{{ statusLabel(paymentSystemResult.payment.status) }}
								</p>
							</div>
							<div class="rounded-2xl border border-gray-200/60 bg-white/45 p-4 dark:border-white/10 dark:bg-white/[0.03]">
								<p class="text-xs text-gray-500 dark:text-gray-400">Сумма</p>
								<p class="mt-1 text-sm font-semibold dark:text-white">
									{{ formatMoney(paymentSystemResult.payment.amount ?? paymentSystemResult.subscription.amount, paymentSystemResult.payment.currency ?? paymentSystemResult.subscription.currency ?? 'RUB') }}
								</p>
								<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									{{ paymentSystemResult.payment.description || paymentSystemResult.subscription.description || 'Описание не передано' }}
								</p>
							</div>
							<div class="rounded-2xl border border-gray-200/60 bg-white/45 p-4 dark:border-white/10 dark:bg-white/[0.03]">
								<p class="text-xs text-gray-500 dark:text-gray-400">Автоплатёж</p>
								<p class="mt-1 text-sm font-semibold dark:text-white">
									{{ paymentSystemResult.subscription.id ? statusLabel(paymentSystemResult.subscription.status) : 'Не найден' }}
								</p>
								<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									Следующая дата: {{ formatDate(paymentSystemResult.subscription.nextPaymentDate) }}
								</p>
							</div>
						</div>

						<div
							v-if="paymentSystemResult.proposedUpdate"
							class="rounded-2xl border border-primary-200/70 bg-primary-50/60 p-4 dark:border-primary-500/20 dark:bg-primary-500/10"
						>
							<div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
								<div>
									<p class="text-sm font-semibold text-gray-900 dark:text-white">Данные для обновления</p>
									<div class="mt-2 grid gap-x-5 gap-y-1 text-sm text-gray-600 sm:grid-cols-2 dark:text-gray-300">
										<span>Начало: {{ formatDate(paymentSystemResult.proposedUpdate.dateStart) }}</span>
										<span>Окончание: {{ formatDate(paymentSystemResult.proposedUpdate.dateFinish) }}</span>
										<span>Тариф: {{ paymentSystemResult.proposedUpdate.tarrif || '—' }}</span>
										<span>Сумма: {{ formatMoney(paymentSystemResult.proposedUpdate.amount, 'RUB') }}</span>
									</div>
								</div>
								<button
									class="btn-primary shrink-0"
									:disabled="!paymentSystemResult.canUpdate || syncingPaymentSystem"
									@click="syncPaymentSystem"
								>
									{{ syncingPaymentSystem ? 'Обновляем...' : 'Обновить данные в базе' }}
								</button>
							</div>
						</div>

						<p
							v-else
							class="rounded-2xl border border-gray-200/60 px-4 py-3 text-sm text-gray-500 dark:border-white/10 dark:text-gray-400"
						>
							Данные для обновления не найдены.
						</p>
					</div>

					<p v-if="paymentSystemError" class="mt-3 text-sm text-red-500 dark:text-red-400">
						{{ paymentSystemError }}
					</p>
					<p v-else-if="paymentSystemMessage" class="mt-3 text-sm text-green-600 dark:text-green-400">
						{{ paymentSystemMessage }}
					</p>
				</div>

				<div class="glass rounded-2xl border border-red-500/20 p-5">
					<h2 class="font-semibold text-red-300">Удаление</h2>
					<p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
						Пользователь и связанные данные будут удалены.
					</p>
					<p v-if="deleteError" class="mt-3 text-sm text-red-500 dark:text-red-400">
						{{ deleteError }}
					</p>
					<button
						class="mt-4 w-full rounded-2xl bg-red-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-red-500 disabled:opacity-50"
						:disabled="deletingUser"
						@click="deleteUser"
					>
						{{ deletingUser ? 'Удаление...' : 'Удалить пользователя' }}
					</button>
				</div>

			</div>
		</template>
	</div>
</template>
