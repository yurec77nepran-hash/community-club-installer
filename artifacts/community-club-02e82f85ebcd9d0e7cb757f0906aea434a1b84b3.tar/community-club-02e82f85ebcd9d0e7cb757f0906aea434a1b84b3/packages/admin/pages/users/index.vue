<script setup lang="ts">
import type { User } from '@community-club/shared/db/schema'
import type { PaginatedResponse } from '@community-club/shared/types/api'

interface UserWithPayment extends User {
	telegramBots?: string[]
	telegramUserIds?: string[]
	payment: {
		dateStart?: string
		dateFinish?: string
		amount?: string
	} | null
}

type UserSortBy =
	| 'createdAt'
	| 'fullName'
	| 'email'
	| 'phone'
	| 'dateStart'
	| 'dateFinish'
	| 'amount'

const api = useAdminApi()
const users = ref<UserWithPayment[]>([])
const search = ref('')
const searchField = ref<
	| 'all'
	| 'id'
	| 'authUuid'
	| 'fullName'
	| 'email'
	| 'phone'
	| 'telegram'
	| 'dateStart'
	| 'dateFinish'
	| 'amount'
>('all')
const sortBy = ref<UserSortBy>('createdAt')
const sortDir = ref<'asc' | 'desc'>('desc')
const page = ref(1)
const pageSize = 100
const total = ref(0)
const loading = ref(false)
const showCreateModal = ref(false)
const saving = ref(false)
const createError = ref('')
const searchFocused = ref(false)
let searchDebounce: ReturnType<typeof setTimeout> | null = null

const createForm = ref({
	fullName: '',
	email: '',
	phone: '',
	role: 'user',
	adminPermissions: [] as string[],
	chatAdminBadge: false,
	password: '',
})

const roleOptions = [
	{ value: 'user', label: 'Пользователь' },
	{ value: 'admin', label: 'Сотрудник' },
	{ value: 'superadmin', label: 'Владелец' },
]

const adminPermissionOptions = [
	{ value: 'analytics', label: 'Аналитика' },
	{ value: 'users', label: 'Пользователи' },
	{ value: 'userActions', label: 'Действия участников' },
	{ value: 'support', label: 'Поддержка' },
	{ value: 'events', label: 'События' },
	{ value: 'materials', label: 'Материалы' },
	{ value: 'media', label: 'Медиа' },
	{ value: 'chats', label: 'Чаты' },
	{ value: 'payments', label: 'Платежи' },
	{ value: 'referrals', label: 'Рефералка' },
	{ value: 'documents', label: 'Документы' },
	{ value: 'settings', label: 'Настройки' },
	{ value: 'staffActions', label: 'Действия' },
	{ value: 'feed', label: 'Новости' },
	{ value: 'replies', label: 'Ответы' },
	{ value: 'tariffs', label: 'Тарифы' },
	{ value: 'notifications', label: 'Уведомления' },
	{ value: 'telegramBroadcasts', label: 'Рассылки' },
]

const sortOptions: Array<{ value: UserSortBy; label: string }> = [
	{ value: 'createdAt', label: 'Дата создания' },
	{ value: 'fullName', label: 'Имя' },
	{ value: 'email', label: 'Email' },
	{ value: 'phone', label: 'Телефон' },
	{ value: 'dateStart', label: 'Старт подписки' },
	{ value: 'dateFinish', label: 'Окончание подписки' },
	{ value: 'amount', label: 'Сумма' },
]

const tableHeaders: Array<{ key: UserSortBy; label: string; align?: 'left' | 'center' }> = [
	{ key: 'fullName', label: 'Имя' },
	{ key: 'email', label: 'Email' },
	{ key: 'phone', label: 'Телефон' },
	{ key: 'dateStart', label: 'Старт' },
	{ key: 'dateFinish', label: 'Оконч.' },
	{ key: 'amount', label: 'Сумма' },
]

async function loadUsers() {
	loading.value = true
	const params = new URLSearchParams({
		page: String(page.value),
		pageSize: String(pageSize),
		field: searchField.value,
		sortBy: sortBy.value,
		sortDir: sortDir.value,
	})
	if (search.value) params.set('q', search.value)

	const res = await api.get<PaginatedResponse<UserWithPayment>>(`/api/admin/users?${params}`)
	if (res.success) {
		users.value = res.data.items
		total.value = res.data.total
	}
	loading.value = false
}

function scheduleReload(resetPage = false) {
	if (searchDebounce) clearTimeout(searchDebounce)
	searchDebounce = setTimeout(() => {
		if (resetPage && page.value !== 1) {
			page.value = 1
			return
		}
		void loadUsers()
	}, 180)
}

watch(search, () => scheduleReload(true), { immediate: true })
watch([searchField, sortBy, sortDir], () => scheduleReload(true))

watch(page, () => {
	void loadUsers()
})

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / pageSize)))

const pageItemsLabel = computed(() => {
	return total.value === 0
		? '0 из 0'
		: `${(page.value - 1) * pageSize + 1}-${Math.min(page.value * pageSize, total.value)} из ${total.value}`
})

const pageNumbers = computed(() => {
	const items: number[] = []
	const start = Math.max(1, page.value - 2)
	const end = Math.min(totalPages.value, page.value + 2)
	for (let current = start; current <= end; current += 1) items.push(current)
	return items
})

const suggestions = computed(() => {
	if (!search.value.trim()) return []
	return users.value.slice(0, 8)
})

function openUser(authUuid: string) {
	void navigateTo(`/users/${authUuid}`)
}

function toggleSort(column: UserSortBy) {
	if (sortBy.value === column) {
		sortDir.value = sortDir.value === 'desc' ? 'asc' : 'desc'
		return
	}

	sortBy.value = column
	sortDir.value = 'desc'
}

function sortMark(column: UserSortBy) {
	if (sortBy.value !== column) return '↕'
	return sortDir.value === 'desc' ? '↓' : '↑'
}

function selectSuggestion(user: UserWithPayment) {
	search.value = user.email || user.fullName || user.authUuid
	searchFocused.value = false
	void openUser(user.authUuid)
}

function fmtDate(d?: string) {
	if (!d) return '—'
	return new Date(d).toLocaleDateString('ru')
}

function formatSuggestionCaption(user: UserWithPayment) {
	const parts = [user.email, user.phone, user.telegramUserIds?.join(', '), `ID ${user.id}`].filter(
		Boolean,
	)
	return parts.join(' • ')
}

function openCreateModal() {
	createError.value = ''
	createForm.value = {
		fullName: '',
		email: '',
		phone: '',
		role: 'user',
		adminPermissions: [],
		chatAdminBadge: false,
		password: '',
	}
	showCreateModal.value = true
}

async function createUser() {
	saving.value = true
	createError.value = ''

	const res = await api.post<User>('/api/admin/users', {
		fullName: createForm.value.fullName,
		email: createForm.value.email,
		phone: createForm.value.phone,
		role: createForm.value.role,
		adminPermissions: createForm.value.role === 'admin' ? createForm.value.adminPermissions : null,
		chatAdminBadge: createForm.value.chatAdminBadge,
		password: createForm.value.password,
	})

	if (!res.success) {
		createError.value = res.error.message
		saving.value = false
		return
	}

	showCreateModal.value = false
	page.value = 1
	await loadUsers()
	saving.value = false
}
</script>

<template>
	<div class="users-page p-4 sm:p-6">
		<div class="mb-6 flex flex-col items-stretch gap-4 sm:flex-row sm:items-center sm:justify-between">
			<h1 class="text-2xl font-bold leading-tight dark:text-white">Пользователи</h1>
			<button class="btn-primary min-h-11 w-full sm:w-auto" @click="openCreateModal">+ Добавить пользователя</button>
		</div>

		<div class="mb-4 space-y-3">
			<div class="glass rounded-2xl p-4">
				<div class="grid gap-3 lg:grid-cols-[minmax(0,1.7fr)_220px_220px_180px]">
					<div class="relative">
						<div class="float-label">
							<input
								v-model="search"
								type="text"
								class="glass-input"
								placeholder=" "
								@focus="searchFocused = true"
								@blur="setTimeout(() => (searchFocused = false), 120)"
							/>
							<label>Поиск по email, id, uuid, телефону, имени...</label>
						</div>
						<div
							v-if="searchFocused && suggestions.length"
							class="absolute left-0 right-0 top-full z-20 mt-2 overflow-hidden rounded-2xl border border-white/10 bg-[#120818]/95 shadow-[0_20px_60px_rgba(0,0,0,0.45)] backdrop-blur-xl"
						>
							<button
								v-for="user in suggestions"
								:key="user.authUuid"
								class="flex w-full items-start justify-between gap-3 border-b border-white/6 px-4 py-3 text-left transition hover:bg-white/[0.04] last:border-b-0"
								@mousedown.prevent="selectSuggestion(user)"
							>
								<span class="min-w-0">
									<span class="block truncate text-sm font-medium text-white">{{ user.fullName || 'Без имени' }}</span>
									<span class="block truncate text-xs text-white/45">{{ formatSuggestionCaption(user) }}</span>
								</span>
							</button>
						</div>
					</div>

					<div class="float-label">
						<select v-model="searchField" class="glass-input">
							<option value="all">Все поля</option>
							<option value="fullName">Имя</option>
							<option value="email">Email</option>
							<option value="phone">Телефон</option>
							<option value="telegram">Telegram ID</option>
							<option value="id">ID</option>
							<option value="authUuid">UUID</option>
							<option value="dateStart">Старт</option>
							<option value="dateFinish">Окончание</option>
							<option value="amount">Сумма</option>
						</select>
						<label>Поле</label>
					</div>

					<div class="float-label">
						<select v-model="sortBy" class="glass-input">
							<option v-for="option in sortOptions" :key="option.value" :value="option.value">
								{{ option.label }}
							</option>
						</select>
						<label>Сортировка</label>
					</div>

					<div class="float-label">
						<select v-model="sortDir" class="glass-input">
							<option value="desc">По убыванию</option>
							<option value="asc">По возрастанию</option>
						</select>
						<label>Порядок</label>
					</div>
				</div>

				<div class="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-white/45">
					<p>По 100 строк на страницу. Клик по строке открывает карточку пользователя.</p>
					<p>{{ pageItemsLabel }} · страниц: {{ totalPages }}</p>
				</div>
			</div>
		</div>

		<div class="glass glass-table overflow-hidden rounded-2xl">
			<div class="users-table-scroll overflow-x-auto">
				<table class="w-full min-w-[680px] whitespace-nowrap text-[10px] sm:text-xs">
					<thead>
						<tr class="text-[10px] uppercase tracking-wider text-gray-500 dark:text-gray-400">
							<th
								v-for="header in tableHeaders"
								:key="header.key"
								class="px-2 py-2 sm:px-3 sm:py-3"
								:class="header.align === 'center' ? 'text-center' : 'text-left'"
							>
								<button
									type="button"
									class="inline-flex items-center gap-1 rounded-lg text-inherit transition hover:text-primary-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-400/60"
									:class="header.align === 'center' ? 'justify-center' : 'justify-start'"
									@click="toggleSort(header.key)"
								>
									<span>{{ header.label }}</span>
									<span
										class="text-[11px] leading-none transition"
										:class="sortBy === header.key ? 'text-primary-500 dark:text-primary-300' : 'text-gray-300 dark:text-gray-600'"
									>
										{{ sortMark(header.key) }}
									</span>
								</button>
							</th>
							<th class="px-2 py-2 sm:px-3 sm:py-3"></th>
							<th class="px-2 py-2 text-left sm:px-3 sm:py-3">Telegram</th>
						</tr>
					</thead>
					<tbody class="divide-y divide-gray-100/50 dark:divide-white/5">
						<tr
							v-for="u in users"
							:key="u.id"
							class="cursor-pointer transition-all duration-150 hover:bg-primary-50/30 dark:hover:bg-white/5"
							@click="openUser(u.authUuid)"
						>
							<td class="px-2 py-2 font-medium dark:text-white sm:px-3 sm:py-2.5">{{ u.fullName ?? '—' }}</td>
							<td class="px-2 py-2 text-gray-500 dark:text-gray-400 sm:px-3 sm:py-2.5">{{ u.email ?? '—' }}</td>
							<td class="px-2 py-2 text-gray-500 dark:text-gray-400 sm:px-3 sm:py-2.5">{{ u.phone ?? '—' }}</td>
							<td class="px-2 py-2 text-gray-400 sm:px-3 sm:py-2.5">{{ fmtDate(u.payment?.dateStart) }}</td>
							<td class="px-2 py-2 text-gray-400 sm:px-3 sm:py-2.5">{{ fmtDate(u.payment?.dateFinish) }}</td>
							<td class="px-2 py-2 dark:text-gray-300 sm:px-3 sm:py-2.5">{{ u.payment?.amount ? `${u.payment.amount} ₽` : '—' }}</td>
							<td class="px-2 py-2 text-gray-500 dark:text-gray-400 sm:px-3 sm:py-2.5">
								{{ u.telegramBots?.map((bot) => `@${bot}`).join(', ') || u.telegramChatId || '—' }}
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<div v-if="loading" class="p-8 text-center">
				<div class="animate-spin w-6 h-6 border-2 border-primary-200 border-t-primary-600 rounded-full mx-auto" />
			</div>
		</div>

		<div class="mt-4 flex flex-wrap items-center justify-center gap-2">
			<button
				:disabled="page <= 1"
				class="btn-secondary disabled:opacity-50"
				@click="page = Math.max(1, page - 1)"
			>
				Назад
			</button>
			<button
				v-for="pageNumber in pageNumbers"
				:key="pageNumber"
				class="min-w-11 rounded-2xl px-3 py-2.5 text-sm font-medium transition"
				:class="
					pageNumber === page
						? 'bg-primary-600 text-white'
						: 'bg-white/5 text-white/70 hover:bg-white/10'
				"
				@click="page = pageNumber"
			>
				{{ pageNumber }}
			</button>
			<span class="px-2 py-2.5 text-sm text-gray-500 dark:text-gray-400">из {{ totalPages }}</span>
			<button
				:disabled="page >= totalPages"
				class="btn-secondary disabled:opacity-50"
				@click="page = Math.min(totalPages, page + 1)"
			>
				Далее
			</button>
		</div>

		<Teleport to="body">
			<Transition name="backdrop">
				<div
					v-if="showCreateModal"
					class="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
					@click="showCreateModal = false"
				/>
			</Transition>
			<Transition name="modal">
				<div
					v-if="showCreateModal"
					class="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
				>
					<div
						class="glass w-full max-w-lg rounded-3xl p-6 shadow-2xl pointer-events-auto"
					>
						<h2 class="mb-5 text-lg font-semibold dark:text-white">Новый пользователь</h2>

						<div class="space-y-4">
							<div class="float-label">
								<input v-model="createForm.fullName" class="glass-input" placeholder=" " />
								<label>Имя</label>
							</div>
							<div class="float-label">
								<input v-model="createForm.email" type="email" class="glass-input" placeholder=" " />
								<label>Email</label>
							</div>
							<div class="float-label">
								<input v-model="createForm.phone" class="glass-input" placeholder=" " />
								<label>Телефон</label>
							</div>
							<div class="float-label">
								<select v-model="createForm.role" class="glass-input">
									<option v-for="option in roleOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
								<label>Доступ</label>
							</div>
							<div
								v-if="createForm.role === 'admin'"
								class="rounded-2xl border border-gray-200/60 bg-white/45 p-4 dark:border-white/10 dark:bg-white/[0.03]"
							>
								<p class="mb-3 text-sm font-semibold dark:text-white">Разделы админки</p>
								<div class="grid gap-3 sm:grid-cols-2">
									<label
										v-for="option in adminPermissionOptions"
										:key="option.value"
										class="flex items-center gap-2 text-sm dark:text-gray-300 cursor-pointer"
									>
										<input
											v-model="createForm.adminPermissions"
											type="checkbox"
											:value="option.value"
											class="glass-check"
										/>
										{{ option.label }}
									</label>
								</div>
							</div>
							<label class="flex items-start gap-3 rounded-2xl border border-gray-200/60 bg-white/45 p-4 text-sm text-gray-800 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-200">
								<input v-model="createForm.chatAdminBadge" type="checkbox" class="glass-check mt-0.5" />
								<span>
									<span class="block font-semibold">Админ</span>
									<span class="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">
										Плашка появится рядом с именем в чатах.
									</span>
								</span>
							</label>
							<div class="float-label">
								<input
									v-model="createForm.password"
									type="text"
									class="glass-input"
									placeholder=" "
								/>
								<label>Временный пароль</label>
							</div>

							<p v-if="createError" class="text-sm text-red-500 dark:text-red-400">
								{{ createError }}
							</p>

							<div class="flex justify-end gap-3 pt-2">
								<button class="btn-secondary" @click="showCreateModal = false">
									Отмена
								</button>
								<button class="btn-primary" :disabled="saving" @click="createUser">
									{{ saving ? 'Создание...' : 'Создать пользователя' }}
								</button>
							</div>
						</div>
					</div>
				</div>
			</Transition>
		</Teleport>
	</div>
</template>

<style scoped>
.users-page {
	box-sizing: border-box;
	width: 100%;
	max-width: 100%;
	min-width: 0;
	overflow-x: hidden;
}

.users-page :deep(*) {
	box-sizing: border-box;
}
</style>
