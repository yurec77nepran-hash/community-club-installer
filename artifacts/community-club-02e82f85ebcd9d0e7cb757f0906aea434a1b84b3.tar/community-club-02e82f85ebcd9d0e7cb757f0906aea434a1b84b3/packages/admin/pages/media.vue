<script setup lang="ts">
import type {
	AdminMediaLibraryFolder,
	AdminMediaLibraryItem,
	AdminMediaLibraryPreferencesPayload,
	CursorPaginatedResponse,
} from '@community-club/shared/types'
import { getBatchUploadProgressPercent, getUploadProgressPercent } from '~/utils/upload-progress'

const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()

type MediaFilter = AdminMediaLibraryPreferencesPayload['typeFilter']
type MediaSortBy = AdminMediaLibraryPreferencesPayload['sortBy']
type MediaSortDir = AdminMediaLibraryPreferencesPayload['sortDir']
type MediaViewMode = AdminMediaLibraryPreferencesPayload['viewMode']
type UploadProgressState = {
	currentName: string
	currentIndex: number
	totalFiles: number
	currentPercent: number
	overallPercent: number
	loadedBytes: number
	totalBytes: number
}

const defaultPreferences: AdminMediaLibraryPreferencesPayload = {
	viewMode: 'cards',
	sortBy: 'updatedAt',
	sortDir: 'desc',
	typeFilter: 'all',
	searchQuery: '',
	folderId: null,
}

const items = ref<AdminMediaLibraryItem[]>([])
const folders = ref<AdminMediaLibraryFolder[]>([])
const preferences = ref<AdminMediaLibraryPreferencesPayload>({ ...defaultPreferences })
const nextCursor = ref<string | null>(null)
const loading = ref(true)
const loadingMore = ref(false)
const uploading = ref(false)
const uploadProgress = ref<UploadProgressState>(createEmptyUploadProgress())
const errorMessage = ref('')
const successMessage = ref('')
const deletingKeys = ref<string[]>([])
const optimizingKeys = ref<string[]>([])
const movingKeys = ref<string[]>([])
const deletingFolderIds = ref<number[]>([])
const previewItem = ref<AdminMediaLibraryItem | null>(null)
const previewVideo = ref<HTMLVideoElement | null>(null)
const videoPreviewState = ref<'idle' | 'loading' | 'ready' | 'playing' | 'error'>('idle')
const copiedKey = ref<string | null>(null)
const draggedKey = ref<string | null>(null)
const dragOverFolderId = ref<number | 'root' | null>(null)
const searchDraft = ref('')
const pageReady = ref(false)
const uploadInput = ref<HTMLInputElement | null>(null)
let searchDebounce: ReturnType<typeof setTimeout> | null = null
let savePreferencesDebounce: ReturnType<typeof setTimeout> | null = null

const filterLabels: Record<MediaFilter, string> = {
	all: 'Все',
	image: 'Изображения',
	video: 'Видео',
	audio: 'Аудио',
	document: 'Файлы',
}

const viewLabels: Record<MediaViewMode, string> = {
	cards: 'Карточки',
	list: 'Список',
}

const sortOptions: Array<{ value: MediaSortBy; label: string }> = [
	{ value: 'updatedAt', label: 'По дате' },
	{ value: 'title', label: 'По названию' },
	{ value: 'size', label: 'По размеру' },
	{ value: 'type', label: 'По типу' },
]

const currentFolder = computed(
	() => folders.value.find((folder) => folder.id === preferences.value.folderId) ?? null,
)

const canLoadMore = computed(() => Boolean(nextCursor.value))
const isPdfPreview = computed(
	() =>
		previewItem.value?.type === 'document' && previewItem.value.key.toLowerCase().endsWith('.pdf'),
)

function isDeleting(key: string) {
	return deletingKeys.value.includes(key)
}

function isOptimizing(key: string) {
	return optimizingKeys.value.includes(key)
}

function isMoving(key: string) {
	return movingKeys.value.includes(key)
}

function isDeletingFolder(id: number) {
	return deletingFolderIds.value.includes(id)
}

function formatSize(size: number | null) {
	if (!size) return ''
	if (size < 1024 * 1024) return `${Math.round(size / 1024)} КБ`
	return `${(size / (1024 * 1024)).toFixed(1)} МБ`
}

function formatUploadSize(size: number) {
	return formatSize(size) || '0 КБ'
}

function createEmptyUploadProgress(): UploadProgressState {
	return {
		currentName: '',
		currentIndex: 0,
		totalFiles: 0,
		currentPercent: 0,
		overallPercent: 0,
		loadedBytes: 0,
		totalBytes: 0,
	}
}

function updateUploadProgress(params: {
	file: File
	index: number
	totalFiles: number
	completedBytes: number
	totalBytes: number
	loaded: number
	total: number | null
}) {
	const fileLoadedBytes =
		params.file.size > 0 ? Math.min(params.loaded, params.file.size) : params.loaded
	uploadProgress.value = {
		currentName: params.file.name,
		currentIndex: params.index + 1,
		totalFiles: params.totalFiles,
		currentPercent: getUploadProgressPercent(fileLoadedBytes, params.total ?? params.file.size),
		overallPercent: getBatchUploadProgressPercent(
			params.completedBytes,
			fileLoadedBytes,
			params.totalBytes,
		),
		loadedBytes: Math.min(params.completedBytes + fileLoadedBytes, params.totalBytes),
		totalBytes: params.totalBytes,
	}
}

function formatDate(value: string | Date | null) {
	if (!value) return ''
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}

function mediaTypeLabel(type: AdminMediaLibraryItem['type']) {
	switch (type) {
		case 'image':
			return 'Изображение'
		case 'video':
			return 'Видео'
		case 'audio':
			return 'Аудио'
		default:
			return 'Файл'
	}
}

function isPdfItem(item: AdminMediaLibraryItem) {
	return item.type === 'document' && item.key.toLowerCase().endsWith('.pdf')
}

function getPreviewItemTitle(item: AdminMediaLibraryItem) {
	return item.title || item.name
}

async function loadFolders() {
	const res = await api.get<AdminMediaLibraryFolder[]>('/api/admin/media-library/folders')
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	folders.value = res.data
}

async function loadPreferences() {
	const res = await api.get<AdminMediaLibraryPreferencesPayload>(
		'/api/admin/media-library/preferences',
	)
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	preferences.value = { ...defaultPreferences, ...res.data }
	searchDraft.value = preferences.value.searchQuery
}

async function loadMedia(options?: { append?: boolean }) {
	const append = options?.append ?? false
	resetMessages()

	if (append) {
		if (!nextCursor.value || loadingMore.value) return
		loadingMore.value = true
	} else {
		loading.value = true
	}

	const query = new URLSearchParams({
		limit: '36',
		type: preferences.value.typeFilter,
		sortBy: preferences.value.sortBy,
		sortDir: preferences.value.sortDir,
	})
	if (preferences.value.searchQuery.trim())
		query.set('search', preferences.value.searchQuery.trim())
	if (preferences.value.folderId != null) query.set('folderId', String(preferences.value.folderId))
	if (append && nextCursor.value) query.set('cursor', nextCursor.value)

	const res = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		`/api/admin/media-library?${query.toString()}`,
	)

	if (res.success) {
		items.value = append ? [...items.value, ...res.data.items] : res.data.items
		nextCursor.value = res.data.nextCursor
	} else {
		errorMessage.value = res.error.message
	}

	loading.value = false
	loadingMore.value = false
}

function schedulePreferencesSave() {
	if (!pageReady.value) return
	if (savePreferencesDebounce) clearTimeout(savePreferencesDebounce)
	savePreferencesDebounce = setTimeout(async () => {
		await api.post<AdminMediaLibraryPreferencesPayload>(
			'/api/admin/media-library/preferences',
			preferences.value,
		)
	}, 180)
}

async function refreshLibrary() {
	await Promise.all([loadFolders(), loadMedia()])
}

async function initializePage() {
	loading.value = true
	await Promise.all([loadFolders(), loadPreferences()])
	pageReady.value = true
	await loadMedia()
}

function openPreview(item: AdminMediaLibraryItem) {
	previewItem.value = item
	videoPreviewState.value = item.type === 'video' ? 'loading' : 'idle'
	if (item.type === 'video') {
		void nextTick(() => {
			previewVideo.value?.load()
		})
	}
}

function closePreview() {
	previewVideo.value?.pause()
	previewItem.value = null
	videoPreviewState.value = 'idle'
}

function handleVideoLoadStart() {
	if (previewItem.value?.type === 'video') videoPreviewState.value = 'loading'
}

function handleVideoReady() {
	if (previewItem.value?.type === 'video') videoPreviewState.value = 'ready'
}

function handleVideoPlaying() {
	if (previewItem.value?.type === 'video') videoPreviewState.value = 'playing'
}

function handleVideoWaiting() {
	if (previewItem.value?.type === 'video' && videoPreviewState.value !== 'playing') {
		videoPreviewState.value = 'loading'
	}
}

function handleVideoError() {
	if (previewItem.value?.type === 'video') videoPreviewState.value = 'error'
}

async function copyPublicLink(item: AdminMediaLibraryItem) {
	try {
		await navigator.clipboard.writeText(item.url)
		copiedKey.value = item.key
		successMessage.value = 'Публичная ссылка скопирована.'
		setTimeout(() => {
			if (copiedKey.value === item.key) copiedKey.value = null
		}, 1600)
	} catch {
		errorMessage.value = 'Не удалось скопировать ссылку.'
	}
}

async function createFolder() {
	const name = window.prompt('Название папки')
	if (!name?.trim()) return
	resetMessages()
	const res = await api.post<AdminMediaLibraryFolder>('/api/admin/media-library/folders', {
		name,
	})
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	successMessage.value = `Папка «${res.data.name}» создана.`
	await loadFolders()
	preferences.value.folderId = res.data.id
	schedulePreferencesSave()
	await loadMedia()
}

async function deleteFolder(folder: AdminMediaLibraryFolder) {
	if (!confirm(`Удалить папку «${folder.name}»? Файлы останутся в медиатеке.`)) return
	deletingFolderIds.value.push(folder.id)
	resetMessages()
	const res = await api.delete<{ deleted: true }>(`/api/admin/media-library/folders/${folder.id}`)
	deletingFolderIds.value = deletingFolderIds.value.filter((id) => id !== folder.id)
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	if (preferences.value.folderId === folder.id) {
		preferences.value.folderId = null
		schedulePreferencesSave()
	}
	successMessage.value = `Папка «${folder.name}» удалена.`
	await refreshLibrary()
}

async function moveItemToFolder(key: string, folderId: number | null) {
	if (isMoving(key)) return
	movingKeys.value.push(key)
	resetMessages()
	const res = await api.post('/api/admin/media-library/move', { key, folderId })
	movingKeys.value = movingKeys.value.filter((itemKey) => itemKey !== key)
	draggedKey.value = null
	dragOverFolderId.value = null
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	successMessage.value =
		folderId == null ? 'Файл перемещён в общий список.' : 'Файл перемещён в папку.'
	await refreshLibrary()
}

async function deleteMedia(item: AdminMediaLibraryItem) {
	const label = item.title || item.name
	if (!confirm(`Удалить файл «${label}» из медиатеки? Это действие необратимо.`)) return
	deletingKeys.value.push(item.key)
	resetMessages()
	const query = new URLSearchParams({ key: item.key })
	const res = await api.delete<{ deleted: true; key: string }>(
		`/api/admin/media-library?${query.toString()}`,
	)
	deletingKeys.value = deletingKeys.value.filter((key) => key !== item.key)
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	if (previewItem.value?.key === item.key) closePreview()
	successMessage.value = 'Файл удалён из медиатеки.'
	await refreshLibrary()
}

async function optimizePdf(item: AdminMediaLibraryItem) {
	if (!isPdfItem(item) || isOptimizing(item.key)) return
	optimizingKeys.value.push(item.key)
	resetMessages()
	const res = await api.post<{
		key: string
		beforeSize: number
		afterSize: number
		changed: boolean
	}>('/api/admin/media-library/optimize-pdf', { key: item.key })
	optimizingKeys.value = optimizingKeys.value.filter((key) => key !== item.key)
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}
	successMessage.value = res.data.changed
		? 'PDF обновлён и облегчён.'
		: 'PDF переупакован для более стабильного открытия.'
	await loadMedia()
}

async function uploadSelectedFiles(fileList: FileList | null) {
	if (!fileList?.length) return
	const files = Array.from(fileList)
	const totalBytes = files.reduce((sum, file) => sum + file.size, 0)
	let completedBytes = 0

	uploading.value = true
	uploadProgress.value = {
		...createEmptyUploadProgress(),
		currentName: files[0]?.name ?? '',
		currentIndex: 1,
		totalFiles: files.length,
		totalBytes,
	}
	resetMessages()
	try {
		for (const [index, file] of files.entries()) {
			updateUploadProgress({
				file,
				index,
				totalFiles: files.length,
				completedBytes,
				totalBytes,
				loaded: 0,
				total: file.size,
			})
			const result = await mediaUpload.uploadFile(file, {
				bucket: 'media',
				folderId: preferences.value.folderId,
				onProgress: (progress) => {
					updateUploadProgress({
						file,
						index,
						totalFiles: files.length,
						completedBytes,
						totalBytes,
						loaded: progress.loaded,
						total: progress.total ?? file.size,
					})
				},
			})
			if (!result.success) {
				throw new Error(result.error.message)
			}
			completedBytes += file.size
			updateUploadProgress({
				file,
				index,
				totalFiles: files.length,
				completedBytes: completedBytes - file.size,
				totalBytes,
				loaded: file.size,
				total: file.size,
			})
		}
		successMessage.value =
			files.length === 1 ? 'Файл загружен.' : `Загружено файлов: ${files.length}.`
		await refreshLibrary()
	} catch (error) {
		errorMessage.value =
			error instanceof Error && error.message ? error.message : 'Не удалось загрузить файлы.'
	} finally {
		uploading.value = false
		uploadProgress.value = createEmptyUploadProgress()
		if (uploadInput.value) uploadInput.value.value = ''
	}
}

function openUploadDialog() {
	uploadInput.value?.click()
}

function handleUploadInputChange(event: Event) {
	const target = event.target as HTMLInputElement | null
	void uploadSelectedFiles(target?.files ?? null)
}

function handleSearchInput(value: string) {
	searchDraft.value = value
	if (searchDebounce) clearTimeout(searchDebounce)
	searchDebounce = setTimeout(() => {
		preferences.value.searchQuery = searchDraft.value.trim()
		schedulePreferencesSave()
		void loadMedia()
	}, 220)
}

function startDrag(item: AdminMediaLibraryItem) {
	draggedKey.value = item.key
}

function clearDrag() {
	draggedKey.value = null
	dragOverFolderId.value = null
}

function handleFolderDragEnter(folderId: number | 'root') {
	dragOverFolderId.value = folderId
}

async function handleFolderDrop(folderId: number | null) {
	if (!draggedKey.value) return
	await moveItemToFolder(draggedKey.value, folderId)
}

watch(
	() => [
		preferences.value.typeFilter,
		preferences.value.sortBy,
		preferences.value.sortDir,
		preferences.value.folderId,
	],
	() => {
		if (!pageReady.value) return
		schedulePreferencesSave()
		void loadMedia()
	},
)

watch(
	() => preferences.value.viewMode,
	() => {
		schedulePreferencesSave()
	},
)

onMounted(() => {
	void initializePage()
})
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-wrap items-end justify-between gap-4">
			<div>
				<h1 class="text-2xl font-bold text-gray-900 dark:text-white">Медиа</h1>
				<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
					Общая медиатека с папками, быстрым просмотром и персональными настройками вида.
				</p>
			</div>
			<div class="flex flex-wrap gap-2">
				<input
					ref="uploadInput"
					type="file"
					multiple
					class="hidden"
					@change="handleUploadInputChange"
				/>
				<button type="button" class="btn-secondary" :disabled="uploading" @click="openUploadDialog">
					{{
						uploading
							? `Загрузка ${uploadProgress.overallPercent}%`
							: currentFolder
								? `Загрузить в «${currentFolder.name}»`
								: 'Загрузить файлы'
					}}
				</button>
				<button type="button" class="btn-primary" @click="createFolder">+ Папка</button>
			</div>
		</div>

		<div
			v-if="errorMessage"
			class="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-300"
		>
			{{ errorMessage }}
		</div>
		<div
			v-if="successMessage"
			class="mb-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300"
		>
			{{ successMessage }}
		</div>
		<div
			v-if="uploading"
			class="mb-4 rounded-[24px] border border-primary-300/30 bg-primary-500/10 px-4 py-4 text-sm text-gray-800 shadow-[0_18px_45px_rgba(124,58,237,0.12)] dark:border-primary-400/20 dark:bg-primary-500/10 dark:text-white"
		>
			<div class="flex flex-wrap items-start justify-between gap-3">
				<div class="min-w-0">
					<p class="font-semibold">
						Загрузка {{ uploadProgress.currentIndex }} из {{ uploadProgress.totalFiles }}
					</p>
					<p class="mt-1 truncate text-xs text-gray-500 dark:text-gray-400">
						{{ uploadProgress.currentName }}
					</p>
				</div>
				<div class="text-right">
					<p class="text-lg font-bold text-primary-700 dark:text-primary-200">
						{{ uploadProgress.overallPercent }}%
					</p>
					<p class="text-xs text-gray-500 dark:text-gray-400">
						{{ uploadProgress.currentPercent }}% файла
					</p>
				</div>
			</div>
			<div class="mt-3 h-2 overflow-hidden rounded-full bg-black/10 dark:bg-white/10">
				<div
					class="h-full rounded-full bg-primary-500 transition-[width] duration-200 ease-out"
					:style="{ width: `${uploadProgress.overallPercent}%` }"
				/>
			</div>
			<p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
				{{ formatUploadSize(uploadProgress.loadedBytes) }} из
				{{ formatUploadSize(uploadProgress.totalBytes) }}
			</p>
		</div>

		<div class="glass rounded-[30px] p-5">
			<div class="grid gap-3 xl:grid-cols-[minmax(0,1.4fr)_220px_220px_220px_180px]">
				<input
					:model-value="searchDraft"
					type="search"
					class="glass-input"
					placeholder="Поиск по названию, комментарию или имени файла"
					@input="handleSearchInput(($event.target as HTMLInputElement).value)"
				/>
				<select v-model="preferences.typeFilter" class="glass-input">
					<option v-for="(label, key) in filterLabels" :key="key" :value="key">
						{{ label }}
					</option>
				</select>
				<select v-model="preferences.sortBy" class="glass-input">
					<option v-for="option in sortOptions" :key="option.value" :value="option.value">
						{{ option.label }}
					</option>
				</select>
				<select v-model="preferences.sortDir" class="glass-input">
					<option value="desc">По убыванию</option>
					<option value="asc">По возрастанию</option>
				</select>
				<select v-model="preferences.viewMode" class="glass-input">
					<option v-for="(label, key) in viewLabels" :key="key" :value="key">
						{{ label }}
					</option>
				</select>
			</div>

			<div class="mt-5 flex flex-wrap gap-3">
				<button
					type="button"
					class="group inline-flex items-center gap-2 rounded-2xl border px-4 py-2 text-sm transition"
					:class="[
						preferences.folderId == null
							? 'border-amber-400/40 bg-amber-500/10 text-amber-800 dark:text-amber-300'
							: 'border-gray-200 bg-white text-gray-600 hover:border-amber-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-300',
						dragOverFolderId === 'root' ? '!border-emerald-400 !bg-emerald-500/10' : '',
					]"
					@dragenter.prevent="handleFolderDragEnter('root')"
					@dragover.prevent="handleFolderDragEnter('root')"
					@dragleave.prevent="dragOverFolderId = null"
					@drop.prevent="handleFolderDrop(null)"
					@click="preferences.folderId = null"
				>
					<span>Все файлы</span>
				</button>

				<button
					v-for="folder in folders"
					:key="folder.id"
					type="button"
					class="group inline-flex items-center gap-2 rounded-2xl border px-4 py-2 text-sm transition"
					:class="[
						preferences.folderId === folder.id
							? 'border-amber-400/40 bg-amber-500/10 text-amber-800 dark:text-amber-300'
							: 'border-gray-200 bg-white text-gray-600 hover:border-amber-300 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-300',
						dragOverFolderId === folder.id ? '!border-emerald-400 !bg-emerald-500/10' : '',
					]"
					:disabled="isDeletingFolder(folder.id)"
					@dragenter.prevent="handleFolderDragEnter(folder.id)"
					@dragover.prevent="handleFolderDragEnter(folder.id)"
					@dragleave.prevent="dragOverFolderId = null"
					@drop.prevent="handleFolderDrop(folder.id)"
					@click="preferences.folderId = folder.id"
				>
					<span class="truncate max-w-[180px]">{{ folder.name }}</span>
					<span class="text-xs opacity-60">{{ folder.itemsCount }}</span>
					<span
						class="opacity-0 transition group-hover:opacity-100"
						@click.stop="deleteFolder(folder)"
					>
						<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
						</svg>
					</span>
				</button>
			</div>

			<div v-if="loading" class="py-10 text-center text-sm text-gray-500 dark:text-gray-400">
				Загружаю медиатеку...
			</div>
			<div
				v-else-if="items.length === 0"
				class="mt-5 rounded-3xl border border-dashed border-gray-200 px-4 py-10 text-center text-sm text-gray-500 dark:border-white/10 dark:text-gray-400"
			>
				В этой подборке пока нет файлов.
			</div>

			<div v-else class="mt-5">
				<div
					v-if="preferences.viewMode === 'cards'"
					class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4"
				>
					<article
						v-for="item in items"
						:key="item.key"
						draggable="true"
						class="overflow-hidden rounded-[28px] border border-gray-200/80 bg-white shadow-[0_20px_50px_rgba(15,23,42,0.08)] transition hover:-translate-y-0.5 hover:shadow-[0_24px_60px_rgba(15,23,42,0.14)] dark:border-white/10 dark:bg-black/20 dark:shadow-none"
						:class="isMoving(item.key) ? 'opacity-60' : ''"
						@dragstart="startDrag(item)"
						@dragend="clearDrag"
						@click="openPreview(item)"
					>
						<div class="relative aspect-[16/10] overflow-hidden bg-gray-100 dark:bg-white/[0.04]">
							<img v-if="item.type === 'image'" :src="item.url" :alt="item.name" class="h-full w-full object-cover" />
							<div
								v-else-if="item.type === 'video'"
								class="flex h-full items-center justify-center bg-[radial-gradient(circle_at_center,rgba(148,163,184,0.18),transparent_58%),linear-gradient(180deg,rgba(24,24,27,0.12),rgba(24,24,27,0.82))] text-white/80"
							>
								<div class="flex flex-col items-center gap-2">
									<svg class="h-9 w-9" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M7 5.75A1.75 1.75 0 018.75 4h6.5A1.75 1.75 0 0117 5.75v12.5A1.75 1.75 0 0115.25 20h-6.5A1.75 1.75 0 017 18.25V5.75z" />
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M10.5 9.75v4.5L14 12l-3.5-2.25z" />
									</svg>
									<span class="text-xs uppercase tracking-[0.18em]">Видео</span>
								</div>
							</div>
							<div
								v-else-if="item.type === 'audio'"
								class="flex h-full items-end bg-[radial-gradient(circle_at_top_left,rgba(148,163,184,0.18),transparent_55%),linear-gradient(180deg,rgba(24,24,27,0.18),rgba(24,24,27,0.78))] p-4"
							>
								<div class="text-xs uppercase tracking-[0.18em] text-white/80">Аудио</div>
							</div>
							<div
								v-else
								class="flex h-full items-end bg-[radial-gradient(circle_at_top_left,rgba(148,163,184,0.16),transparent_55%),linear-gradient(180deg,rgba(24,24,27,0.16),rgba(24,24,27,0.8))] p-4"
							>
								<div class="text-xs uppercase tracking-[0.18em] text-white/80">Файл</div>
							</div>
							<div class="absolute left-3 top-3 rounded-full border border-black/10 bg-white/85 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-gray-700 dark:border-white/10 dark:bg-black/65 dark:text-white/80">
								{{ mediaTypeLabel(item.type) }}
							</div>
						</div>

						<div class="space-y-2 px-4 py-4">
							<p class="truncate text-sm font-medium text-gray-900 dark:text-white">{{ getPreviewItemTitle(item) }}</p>
							<p v-if="item.note" class="line-clamp-2 text-xs text-gray-500 dark:text-gray-400">{{ item.note }}</p>
							<p class="text-xs text-gray-500 dark:text-gray-400">
								{{ formatDate(item.lastModified) }}
								<span v-if="item.size"> · {{ formatSize(item.size) }}</span>
							</p>
						</div>

						<div class="flex items-center justify-between gap-3 border-t border-gray-200/70 px-4 py-3 dark:border-white/10">
							<button
								type="button"
								class="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/70 text-gray-600 transition hover:bg-white dark:bg-white/[0.06] dark:text-white/80 dark:hover:bg-white/[0.12]"
								@click.stop="copyPublicLink(item)"
								:title="copiedKey === item.key ? 'Ссылка скопирована' : 'Скопировать ссылку'"
							>
								<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 17H7a4 4 0 010-8h4m-2 4h6m0 0h1a4 4 0 010 8h-4m2-4H8" />
								</svg>
							</button>
							<div class="flex items-center gap-3">
								<button
									v-if="isPdfItem(item)"
									type="button"
									class="text-sm font-medium text-emerald-700 transition hover:text-emerald-800 disabled:cursor-not-allowed disabled:opacity-60 dark:text-emerald-300 dark:hover:text-emerald-200"
									:disabled="isOptimizing(item.key)"
									@click.stop="optimizePdf(item)"
								>
									{{ isOptimizing(item.key) ? 'Идёт...' : 'PDF' }}
								</button>
								<button
									type="button"
									class="text-sm font-medium text-red-600 transition hover:text-red-700 dark:text-red-300 dark:hover:text-red-200"
									:disabled="isDeleting(item.key)"
									@click.stop="deleteMedia(item)"
								>
									{{ isDeleting(item.key) ? 'Удаляю...' : 'Удалить' }}
								</button>
							</div>
						</div>
					</article>
				</div>

				<div v-else class="overflow-hidden rounded-[28px] border border-white/10">
						<div
							v-for="item in items"
							:key="item.key"
							draggable="true"
							role="button"
							tabindex="0"
							class="flex w-full items-center gap-4 border-b border-white/10 bg-white px-4 py-3 text-left transition hover:bg-amber-50/50 last:border-b-0 dark:bg-black/20 dark:hover:bg-white/[0.04]"
							:class="isMoving(item.key) ? 'opacity-60' : ''"
							@dragstart="startDrag(item)"
							@dragend="clearDrag"
							@click="openPreview(item)"
							@keydown.enter.prevent="openPreview(item)"
							@keydown.space.prevent="openPreview(item)"
						>
						<div class="h-12 w-16 shrink-0 overflow-hidden rounded-2xl bg-white/10">
							<img v-if="item.type === 'image'" :src="item.url" :alt="item.name" class="h-full w-full object-cover" />
							<div
								v-else-if="item.type === 'video'"
								class="flex h-full items-center justify-center bg-[radial-gradient(circle_at_center,rgba(148,163,184,0.18),transparent_58%),linear-gradient(180deg,rgba(24,24,27,0.12),rgba(24,24,27,0.82))] text-white/80"
							>
								<svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M7 5.75A1.75 1.75 0 018.75 4h6.5A1.75 1.75 0 0117 5.75v12.5A1.75 1.75 0 0115.25 20h-6.5A1.75 1.75 0 017 18.25V5.75z" />
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M10.5 9.75v4.5L14 12l-3.5-2.25z" />
								</svg>
							</div>
							<div v-else class="flex h-full items-center justify-center text-[10px] uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">
								{{ item.type === 'audio' ? 'Аудио' : 'Файл' }}
							</div>
						</div>
						<div class="min-w-0 flex-1">
							<p class="truncate text-sm font-medium text-gray-900 dark:text-white">{{ getPreviewItemTitle(item) }}</p>
							<p class="truncate text-xs text-gray-500 dark:text-gray-400">
								{{ item.note || mediaTypeLabel(item.type) }}
							</p>
						</div>
						<div class="hidden text-xs text-gray-500 dark:text-gray-400 lg:block">
							{{ formatDate(item.lastModified) }}
						</div>
						<div class="hidden min-w-[80px] text-right text-xs text-gray-500 dark:text-gray-400 md:block">
							{{ formatSize(item.size) }}
						</div>
						<button
							type="button"
							class="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/70 text-gray-600 transition hover:bg-white dark:bg-white/[0.06] dark:text-white/80 dark:hover:bg-white/[0.12]"
							@click.stop="copyPublicLink(item)"
						>
							<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 17H7a4 4 0 010-8h4m-2 4h6m0 0h1a4 4 0 010 8h-4m2-4H8" />
							</svg>
						</button>
						</div>
					</div>

				<div class="mt-5 flex justify-center">
					<button
						v-if="canLoadMore"
						type="button"
						class="btn-secondary"
						:disabled="loadingMore"
						@click="loadMedia({ append: true })"
					>
						{{ loadingMore ? 'Загрузка...' : 'Показать ещё' }}
					</button>
				</div>
			</div>
		</div>

		<Teleport to="body">
			<Transition name="modal">
				<div
					v-if="previewItem"
					class="fixed inset-0 z-[90] bg-black/70 px-4 py-6 backdrop-blur-sm"
					@click.self="closePreview"
				>
					<div class="mx-auto flex h-full w-full max-w-5xl flex-col overflow-hidden rounded-[32px] border border-white/10 bg-[#120818] shadow-[0_30px_90px_rgba(0,0,0,0.5)]">
						<div class="flex items-start justify-between gap-4 border-b border-white/10 px-6 py-5">
							<div class="min-w-0">
								<h2 class="truncate text-lg font-semibold text-white">{{ getPreviewItemTitle(previewItem) }}</h2>
								<p class="mt-1 text-sm text-white/50">
									{{ mediaTypeLabel(previewItem.type) }}
									<span v-if="previewItem.size"> · {{ formatSize(previewItem.size) }}</span>
									<span v-if="previewItem.lastModified"> · {{ formatDate(previewItem.lastModified) }}</span>
								</p>
							</div>
							<button
								type="button"
								class="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.06] text-white/70 transition hover:bg-white/[0.12] hover:text-white"
								@click="closePreview"
							>
								<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
								</svg>
							</button>
						</div>

						<div class="flex-1 overflow-auto px-6 py-6">
							<img
								v-if="previewItem.type === 'image'"
								:src="previewItem.url"
								:alt="previewItem.name"
								class="max-h-[72vh] w-full rounded-[28px] object-contain"
							/>
							<div
								v-else-if="previewItem.type === 'video'"
								class="relative overflow-hidden rounded-[28px] bg-black"
							>
								<video
									ref="previewVideo"
									:key="previewItem.key"
									:src="previewItem.url"
									class="max-h-[72vh] w-full bg-black object-contain"
									controls
									playsinline
									preload="metadata"
									@loadstart="handleVideoLoadStart"
									@loadedmetadata="handleVideoReady"
									@canplay="handleVideoReady"
									@playing="handleVideoPlaying"
									@waiting="handleVideoWaiting"
									@stalled="handleVideoWaiting"
									@error="handleVideoError"
								/>
								<div
									v-if="videoPreviewState === 'loading'"
									class="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/45 text-sm font-medium text-white/80"
								>
									Видео загружается...
								</div>
								<div
									v-else-if="videoPreviewState === 'error'"
									class="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 px-6 text-center text-white"
								>
									<p class="text-sm font-medium">Не удалось открыть видео в браузере.</p>
									<a
										:href="previewItem.url"
										target="_blank"
										rel="noopener"
										class="rounded-full border border-white/15 bg-white/[0.08] px-4 py-2 text-sm text-white/85 transition hover:bg-white/[0.14]"
									>
										Открыть файл
									</a>
								</div>
							</div>
							<div v-else-if="previewItem.type === 'audio'" class="rounded-[28px] border border-white/10 bg-white/[0.04] p-6">
								<audio :src="previewItem.url" class="w-full" controls preload="metadata" />
								<p v-if="previewItem.note" class="mt-4 text-sm text-white/65">{{ previewItem.note }}</p>
							</div>
							<iframe
								v-else-if="isPdfPreview"
								:src="previewItem.url"
								class="h-[72vh] w-full rounded-[28px] border border-white/10 bg-white"
								title="Предпросмотр PDF"
							/>
							<div v-else class="rounded-[28px] border border-white/10 bg-white/[0.04] p-6 text-white/70">
								<p class="text-sm">Для этого формата прямой предпросмотр ограничен.</p>
								<p class="mt-2 text-xs text-white/45">Скопируй публичную ссылку ниже и открой файл в отдельном приложении при необходимости.</p>
							</div>
						</div>

						<div class="flex items-center justify-between gap-3 border-t border-white/10 px-6 py-4">
							<p class="truncate text-xs text-white/40">{{ previewItem.key }}</p>
							<button
								type="button"
								class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-4 py-2 text-sm text-white/80 transition hover:bg-white/[0.12]"
								@click="copyPublicLink(previewItem)"
							>
								<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 17H7a4 4 0 010-8h4m-2 4h6m0 0h1a4 4 0 010 8h-4m2-4H8" />
								</svg>
								<span>{{ copiedKey === previewItem.key ? 'Ссылка скопирована' : 'Скопировать публичную ссылку' }}</span>
							</button>
						</div>
					</div>
				</div>
			</Transition>
		</Teleport>
	</div>
</template>

<style scoped>
.modal-enter-active {
	transition: opacity 0.2s ease;
}

.modal-leave-active {
	transition: opacity 0.16s ease;
}

.modal-enter-from,
.modal-leave-to {
	opacity: 0;
}
</style>
