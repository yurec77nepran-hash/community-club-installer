<script setup lang="ts">
import type {
	ChatMessageWithMeta,
	CursorPaginatedResponse,
	SupportThreadContext,
	SupportThreadSummary,
	WSServerMessage,
} from '@community-club/shared/types'

type SupportMessage = ChatMessageWithMeta & {
	deliveryStatus?: 'sending' | 'sent' | 'failed'
}

const api = useAdminApi()
const auth = useAuthStore()
const ws = useAdminWebSocket()
const route = useRoute()

const threads = ref<SupportThreadSummary[]>([])
const activeThreadId = ref<number | null>(null)
const messages = ref<SupportMessage[]>([])
const threadContext = ref<SupportThreadContext | null>(null)
const loadingThreads = ref(true)
const loadingMoreThreads = ref(false)
const loadingMessages = ref(false)
const loadingContext = ref(false)
const sending = ref(false)
const messageText = ref('')
const errorMessage = ref('')
const messagesContainer = ref<HTMLElement | null>(null)
const fullscreenImageUrl = ref<string | null>(null)
const fullscreenVideoUrl = ref<string | null>(null)
const imagePreviewCloseButton = ref<HTMLButtonElement | null>(null)
const videoPreviewCloseButton = ref<HTMLButtonElement | null>(null)
const mediaPreviewTrigger = ref<HTMLElement | null>(null)
const copiedFieldKey = ref<string | null>(null)
const unsubscribers: Array<() => void> = []
const THREADS_PAGE_SIZE = 50
const threadNextCursor = ref<string | null>(null)
let refreshThreadsTimer: ReturnType<typeof setInterval> | null = null
const pendingFallbacks = new Map<string, ReturnType<typeof setTimeout>>()
const MESSAGE_FALLBACK_DELAY_MS = 600

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function formatDateLong(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'long',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function previewMessage(thread: SupportThreadSummary) {
	if (!thread.lastMessage) return 'Диалог ещё пустой'
	if (thread.lastMessage.content) return thread.lastMessage.content
	if (thread.lastMessage.messageType === 'image') return 'Изображение'
	if (thread.lastMessage.messageType === 'voice') return 'Голосовое сообщение'
	if (thread.lastMessage.messageType === 'audio') return 'Аудиофайл'
	if (thread.lastMessage.messageType === 'video') return 'Видео'
	return 'Вложение'
}

function getRouteThreadId() {
	const raw = Array.isArray(route.query.chatId) ? route.query.chatId[0] : route.query.chatId
	const id = Number(raw)
	return Number.isInteger(id) && id > 0 ? id : null
}

function formatUserRole(role: string | null | undefined) {
	switch (role) {
		case 'admin':
			return 'Администратор'
		case 'superadmin':
			return 'Суперадмин'
		default:
			return 'Пользователь'
	}
}

function initials(name: string | null | undefined) {
	const source = name?.trim()
	if (!source) return 'SC'

	return source
		.split(/\s+/)
		.filter(Boolean)
		.slice(0, 2)
		.map((part) => part[0]?.toUpperCase() ?? '')
		.join('')
}

function compactLineClass(value: string | null | undefined, kind: 'name' | 'email' = 'name') {
	const length = value?.trim().length ?? 0

	if (kind === 'email') {
		if (length > 34) return 'text-[10px]'
		if (length > 26) return 'text-[11px]'
		return 'text-[12px]'
	}

	if (length > 38) return 'text-[11px]'
	if (length > 26) return 'text-[12px]'
	return 'text-[13px]'
}

function isImageMessage(message: SupportMessage) {
	return message.messageType === 'image' && Boolean(message.attachmentUrl)
}

function isVideoMessage(message: SupportMessage) {
	return message.messageType === 'video' && Boolean(message.attachmentUrl)
}

function isAudioMessage(message: SupportMessage) {
	return (
		(message.messageType === 'audio' || message.messageType === 'voice') &&
		Boolean(message.attachmentUrl)
	)
}

function isDocumentMessage(message: SupportMessage) {
	return message.messageType === 'document' && Boolean(message.attachmentUrl)
}

function hasTextContent(message: SupportMessage) {
	return Boolean(message.content?.trim())
}

function openImagePreview(event: MouseEvent, url: string | null | undefined) {
	if (!(event.currentTarget instanceof HTMLElement) || !url) return
	mediaPreviewTrigger.value = event.currentTarget
	fullscreenImageUrl.value = url
	nextTick(() => imagePreviewCloseButton.value?.focus())
}

function openVideoPreview(event: MouseEvent, url: string | null | undefined) {
	if (!(event.currentTarget instanceof HTMLElement) || !url) return
	mediaPreviewTrigger.value = event.currentTarget
	fullscreenVideoUrl.value = url
	nextTick(() => videoPreviewCloseButton.value?.focus())
}

function closeImagePreview() {
	const trigger = mediaPreviewTrigger.value
	fullscreenImageUrl.value = null
	mediaPreviewTrigger.value = null
	nextTick(() => trigger?.focus())
}

function closeVideoPreview() {
	const trigger = mediaPreviewTrigger.value
	fullscreenVideoUrl.value = null
	mediaPreviewTrigger.value = null
	nextTick(() => trigger?.focus())
}

function handleMediaPreviewKeydown(event: KeyboardEvent) {
	if (event.key !== 'Escape') return
	if (fullscreenImageUrl.value) {
		event.preventDefault()
		closeImagePreview()
		return
	}
	if (fullscreenVideoUrl.value) {
		event.preventDefault()
		closeVideoPreview()
	}
}

function formatAttachmentSize(size: number | null | undefined) {
	if (!size || size <= 0) return ''
	if (size < 1024) return `${size} Б`
	if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} КБ`
	return `${(size / (1024 * 1024)).toFixed(1)} МБ`
}

function formatValue(value: string | Date | number | boolean | null | undefined) {
	if (value == null) return '—'
	if (value instanceof Date) return formatDateLong(value)
	if (typeof value === 'boolean') return value ? 'Да' : 'Нет'
	return String(value)
}

async function copyField(key: string, value: string | Date | number | boolean | null | undefined) {
	const raw =
		value instanceof Date
			? value.toISOString()
			: typeof value === 'boolean'
				? value
					? 'Да'
					: 'Нет'
				: value
	if (raw == null || raw === '') return

	try {
		await navigator.clipboard.writeText(String(raw))
		copiedFieldKey.value = key
		setTimeout(() => {
			if (copiedFieldKey.value === key) {
				copiedFieldKey.value = null
			}
		}, 1600)
	} catch {
		errorMessage.value = 'Не удалось скопировать поле. Проверьте доступ к буферу обмена.'
	}
}

function accessChips(context: SupportThreadContext | null) {
	if (!context?.payment) return []

	return [context.payment.dateFinish ? 'Участник' : null].filter(Boolean) as string[]
}

function formatPaymentStatus(context: SupportThreadContext | null) {
	if (!context?.payment?.dateFinish) return 'Нет активной подписки'
	return new Date(context.payment.dateFinish).getTime() >= Date.now()
		? `Активна до ${formatDate(context.payment.dateFinish)}`
		: `Истекла ${formatDate(context.payment.dateFinish)}`
}

function paymentStatusClass(context: SupportThreadContext | null) {
	if (!context?.payment?.dateFinish) return 'support-status-muted'
	return new Date(context.payment.dateFinish).getTime() >= Date.now()
		? 'support-status-success'
		: 'support-status-warning'
}

function makeClientMessageId() {
	if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
		return crypto.randomUUID()
	}

	return `admin_support_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
}

function scrollToBottom() {
	if (messagesContainer.value) {
		messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
	}
}

function sortMessages() {
	messages.value.sort((left, right) => {
		const delta = new Date(left.createdAt).getTime() - new Date(right.createdAt).getTime()
		if (delta !== 0) return delta
		return left.id - right.id
	})
}

function upsertMessage(message: SupportMessage) {
	const byIdIndex = messages.value.findIndex((item) => item.id === message.id)
	const byClientMessageIndex =
		message.clientMessageId == null
			? -1
			: messages.value.findIndex(
					(item) =>
						item.clientMessageId != null && item.clientMessageId === message.clientMessageId,
				)

	if (byIdIndex !== -1) {
		messages.value.splice(byIdIndex, 1, {
			...messages.value[byIdIndex],
			...message,
			deliveryStatus: message.deliveryStatus ?? 'sent',
		})
	} else if (byClientMessageIndex !== -1) {
		messages.value.splice(byClientMessageIndex, 1, {
			...messages.value[byClientMessageIndex],
			...message,
			deliveryStatus: message.deliveryStatus ?? 'sent',
		})
	} else {
		messages.value.push({
			...message,
			deliveryStatus: message.deliveryStatus ?? 'sent',
		})
	}

	sortMessages()
}

function updateThreadPreview(message: SupportMessage) {
	const thread = threads.value.find((item) => item.chatId === message.chatId)
	if (!thread) return

	thread.lastMessage = {
		id: message.id,
		content: message.content,
		messageType: message.messageType,
		createdAt: message.createdAt,
		userAuthUuid: message.userAuthUuid,
	}

	threads.value.sort((left, right) => {
		const leftTs = left.lastMessage
			? new Date(left.lastMessage.createdAt).getTime()
			: new Date(left.createdAt).getTime()
		const rightTs = right.lastMessage
			? new Date(right.lastMessage.createdAt).getTime()
			: new Date(right.createdAt).getTime()
		return rightTs - leftTs
	})
}

function mergeThreads(primary: SupportThreadSummary[], secondary: SupportThreadSummary[]) {
	const byId = new Map<number, SupportThreadSummary>()

	for (const thread of [...primary, ...secondary]) {
		if (!byId.has(thread.chatId)) {
			byId.set(thread.chatId, thread)
		}
	}

	return Array.from(byId.values())
}

async function loadThreads(options?: { append?: boolean }) {
	const append = options?.append ?? false

	if (append) {
		loadingMoreThreads.value = true
	} else {
		loadingThreads.value = true
	}
	errorMessage.value = ''

	const query = new URLSearchParams({
		limit: String(THREADS_PAGE_SIZE),
	})
	if (append && threadNextCursor.value) {
		query.set('cursor', threadNextCursor.value)
	}

	const res = await api.get<CursorPaginatedResponse<SupportThreadSummary>>(
		`/api/support/threads?${query.toString()}`,
	)
	if (!res.success) {
		errorMessage.value = res.error.message
		loadingThreads.value = false
		loadingMoreThreads.value = false
		return
	}

	if (append) {
		threads.value = mergeThreads(threads.value, res.data.items)
	} else {
		threads.value = res.data.items
	}

	threadNextCursor.value = res.data.nextCursor

	if (
		activeThreadId.value != null &&
		!threads.value.some((thread) => thread.chatId === activeThreadId.value)
	) {
		activeThreadId.value = null
		threadContext.value = null
		messages.value = []
	}

	const routeThreadId = getRouteThreadId()
	if (routeThreadId && threads.value.some((thread) => thread.chatId === routeThreadId)) {
		await selectThread(routeThreadId)
	} else if (!activeThreadId.value && threads.value.length > 0) {
		await selectThread(threads.value[0].chatId)
	}

	loadingThreads.value = false
	loadingMoreThreads.value = false
}

async function loadMessages(chatId: number) {
	loadingMessages.value = true
	errorMessage.value = ''

	const res = await api.get<{ items: SupportMessage[]; nextCursor: string | null }>(
		`/api/chats/${chatId}/messages?limit=100`,
	)
	if (!res.success) {
		errorMessage.value = res.error.message
		loadingMessages.value = false
		return
	}

	messages.value = res.data.items.reverse().map((message) => ({
		...message,
		deliveryStatus: 'sent',
	}))
	sortMessages()
	loadingMessages.value = false
	nextTick(() => scrollToBottom())
}

async function loadThreadContext(chatId: number) {
	loadingContext.value = true

	const res = await api.get<SupportThreadContext>(`/api/support/threads/${chatId}/context`)
	if (!res.success) {
		errorMessage.value = res.error.message
		threadContext.value = null
		loadingContext.value = false
		return
	}

	threadContext.value = res.data
	loadingContext.value = false
}

async function selectThread(chatId: number) {
	if (activeThreadId.value === chatId) return

	if (activeThreadId.value) {
		ws.send({ type: 'leave_room', chatId: activeThreadId.value })
	}

	activeThreadId.value = chatId
	messages.value = []
	threadContext.value = null
	ws.connect()
	ws.send({ type: 'join_room', chatId })
	await Promise.all([loadMessages(chatId), loadThreadContext(chatId)])
}

function handleSocketMessage(message: WSServerMessage) {
	if (!activeThreadId.value) return

	switch (message.type) {
		case 'new_message': {
			updateThreadPreview(message.message)
			if (message.message.chatId !== activeThreadId.value) return
			upsertMessage({ ...message.message, deliveryStatus: 'sent' })
			nextTick(() => scrollToBottom())
			break
		}
		case 'message_ack': {
			updateThreadPreview(message.message)
			clearMessageFallback(message.clientMessageId)
			if (message.message.chatId !== activeThreadId.value) return
			upsertMessage({
				...message.message,
				clientMessageId: message.clientMessageId ?? message.message.clientMessageId,
				deliveryStatus: 'sent',
			})
			sending.value = false
			nextTick(() => scrollToBottom())
			break
		}
		case 'message_deleted': {
			if (message.chatId !== activeThreadId.value) return
			messages.value = messages.value.filter((item) => item.id !== message.messageId)
			break
		}
		case 'error': {
			errorMessage.value = message.message || 'Не удалось отправить сообщение. Попробуйте ещё раз.'
			clearMessageFallback(message.clientMessageId)
			if (message.clientMessageId) {
				const optimistic = messages.value.find(
					(item) => item.clientMessageId === message.clientMessageId,
				)
				if (optimistic) {
					optimistic.deliveryStatus = 'failed'
				}
			}
			sending.value = false
			break
		}
	}
}

function clearMessageFallback(clientMessageId: string | null | undefined) {
	if (!clientMessageId) return
	const timer = pendingFallbacks.get(clientMessageId)
	if (!timer) return
	clearTimeout(timer)
	pendingFallbacks.delete(clientMessageId)
}

function scheduleMessageFallback(chatId: number, clientMessageId: string, content: string) {
	clearMessageFallback(clientMessageId)
	const timer = setTimeout(async () => {
		pendingFallbacks.delete(clientMessageId)

		const optimistic = messages.value.find((item) => item.clientMessageId === clientMessageId)
		if (!optimistic || optimistic.deliveryStatus === 'sent') return

		const res = await api.post<SupportMessage>(`/api/chats/${chatId}/messages`, {
			clientMessageId,
			content,
			messageType: 'text',
		})
		if (res.success) {
			updateThreadPreview(res.data)
			if (activeThreadId.value === chatId) {
				upsertMessage({ ...res.data, deliveryStatus: 'sent' })
				sending.value = false
				nextTick(() => scrollToBottom())
			}
			return
		}

		if (activeThreadId.value === chatId) {
			optimistic.deliveryStatus = 'failed'
			errorMessage.value = res.error.message
			sending.value = false
		}
	}, MESSAGE_FALLBACK_DELAY_MS)
	pendingFallbacks.set(clientMessageId, timer)
}

function sendMessage() {
	if (!activeThreadId.value) return

	const content = messageText.value.trim()
	if (!content) return

	const clientMessageId = makeClientMessageId()
	const optimisticId = -Date.now()
	sending.value = true
	errorMessage.value = ''

	upsertMessage({
		id: optimisticId,
		chatId: activeThreadId.value,
		userAuthUuid: auth.user?.authUuid ?? '',
		content,
		replyToId: null,
		clientMessageId,
		messageType: 'text',
		attachmentUrl: null,
		attachmentName: null,
		attachmentSize: null,
		linkPreview: null,
		isDeleted: false,
		createdAt: new Date(),
		updatedAt: new Date(),
		author: {
			fullName: auth.user?.fullName ?? null,
			username: null,
			avatarUrl: null,
			chatAdminBadge: auth.user?.chatAdminBadge ?? false,
		},
		reactions: [],
		deliveryStatus: 'sending',
	})

	ws.send({
		type: 'send_message',
		chatId: activeThreadId.value,
		clientMessageId,
		content,
		messageType: 'text',
	})
	scheduleMessageFallback(activeThreadId.value, clientMessageId, content)

	messageText.value = ''
	nextTick(() => scrollToBottom())
}

const activeThread = computed(() =>
	activeThreadId.value == null
		? null
		: (threads.value.find((item) => item.chatId === activeThreadId.value) ?? null),
)

onMounted(async () => {
	window.addEventListener('keydown', handleMediaPreviewKeydown)
	ws.connect()
	unsubscribers.push(ws.on('new_message', handleSocketMessage))
	unsubscribers.push(ws.on('message_ack', handleSocketMessage))
	unsubscribers.push(ws.on('message_deleted', handleSocketMessage))
	unsubscribers.push(ws.on('error', handleSocketMessage))
	await loadThreads()
	refreshThreadsTimer = setInterval(() => {
		void loadThreads()
	}, 15000)
})

watch(
	() => route.query.chatId,
	async () => {
		const routeThreadId = getRouteThreadId()
		if (!routeThreadId || activeThreadId.value === routeThreadId) return
		if (threads.value.some((thread) => thread.chatId === routeThreadId)) {
			await selectThread(routeThreadId)
		}
	},
)

onUnmounted(() => {
	window.removeEventListener('keydown', handleMediaPreviewKeydown)
	if (activeThreadId.value) {
		ws.send({ type: 'leave_room', chatId: activeThreadId.value })
	}
	for (const unsubscribe of unsubscribers) {
		unsubscribe()
	}
	for (const timer of pendingFallbacks.values()) {
		clearTimeout(timer)
	}
	pendingFallbacks.clear()
	if (refreshThreadsTimer) {
		clearInterval(refreshThreadsTimer)
		refreshThreadsTimer = null
	}
	ws.disconnect()
})
</script>

<template>
	<div class="flex min-h-[calc(100dvh-56px)] flex-col p-6 xl:h-[calc(100dvh-56px)] xl:min-h-0">
		<div class="mb-6 flex flex-wrap items-center justify-between gap-3">
			<div>
				<h1 class="text-2xl font-bold text-gray-900">Поддержка</h1>
				<p class="text-sm text-gray-600">Входящие обращения, история пользователя и его платёжный контекст</p>
			</div>
			<button type="button" class="btn-primary support-primary-button" @click="loadThreads()">Обновить</button>
		</div>

		<p
			v-if="errorMessage"
			class="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
			role="alert"
		>
			{{ errorMessage }}
		</p>

		<div class="grid grid-cols-1 gap-4 xl:min-h-0 xl:flex-1 xl:grid-cols-[280px_minmax(0,1fr)_280px] 2xl:grid-cols-[320px_minmax(0,1fr)_340px]">
			<section class="glass flex max-h-[min(420px,55dvh)] min-h-0 flex-col overflow-hidden rounded-3xl p-3 xl:max-h-none">
				<div
					v-if="loadingThreads"
					class="flex h-full items-center justify-center gap-2 text-sm text-gray-600"
					role="status"
					aria-live="polite"
				>
					<span>Загружаю диалоги...</span>
				</div>
				<div v-else-if="threads.length === 0" class="flex h-full items-center justify-center text-sm text-gray-600">
					Диалогов пока нет
				</div>
				<div v-else class="min-h-0 flex-1 space-y-2 overflow-y-auto pr-1">
					<button
						v-for="thread in threads"
						:key="thread.chatId"
						type="button"
						class="support-thread-button w-full rounded-3xl border px-4 py-3 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
						:class="
							activeThreadId === thread.chatId
								? 'border-primary-300 bg-primary-50/80 text-gray-900'
								: ''
						"
						:aria-current="activeThreadId === thread.chatId ? 'true' : undefined"
						@click="selectThread(thread.chatId)"
					>
						<div class="flex items-start gap-3">
							<div class="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-primary-200 bg-primary-50 text-sm font-semibold text-gray-900">
								<img
									v-if="thread.user.avatarUrl"
									:src="thread.user.avatarUrl"
									:alt="thread.user.fullName || 'Пользователь'"
									class="h-full w-full object-cover"
								/>
								<span v-else>{{ initials(thread.user.fullName || thread.user.email) }}</span>
							</div>
							<div class="min-w-0 flex-1">
								<div class="flex items-start justify-between gap-3">
									<div class="min-w-0">
									<p
										class="truncate font-semibold leading-5 text-gray-900"
										:class="compactLineClass(thread.user.fullName || thread.user.email)"
										:title="thread.user.fullName || thread.user.email || 'Пользователь'"
									>
											{{ thread.user.fullName || thread.user.email || 'Пользователь' }}
										</p>
									<p
										class="truncate leading-5 text-gray-600"
										:class="compactLineClass(thread.user.email, 'email')"
										:title="thread.user.email || 'Без email'"
									>
											{{ thread.user.email || 'Без email' }}
										</p>
									</div>
									<span class="shrink-0 pt-0.5 text-[11px] text-gray-500">{{ formatDate(thread.lastMessage?.createdAt || thread.createdAt) }}</span>
									</div>
								</div>
						</div>
					</button>
					<button
						v-if="threadNextCursor"
						type="button"
						class="w-full rounded-2xl border border-dashed border-gray-300 bg-white/60 px-4 py-3 text-sm text-gray-600 transition hover:border-primary-300 hover:bg-primary-50/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500 disabled:cursor-not-allowed disabled:opacity-60"
						:disabled="loadingMoreThreads"
						@click="loadThreads({ append: true })"
					>
						{{ loadingMoreThreads ? 'Загружаю ещё...' : 'Показать ещё диалоги' }}
					</button>
				</div>
			</section>

			<section class="glass flex min-h-[520px] flex-col overflow-hidden rounded-3xl xl:min-h-0">
				<div v-if="!activeThread" class="flex h-full items-center justify-center text-sm text-gray-600">
					Выберите диалог
				</div>
				<template v-else>
					<div class="shrink-0 border-b border-gray-200 px-5 py-4">
						<div class="flex items-center gap-3">
							<div class="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-primary-200 bg-primary-50 text-sm font-semibold text-gray-900">
								<img
									v-if="activeThread.user.avatarUrl"
									:src="activeThread.user.avatarUrl"
									:alt="activeThread.user.fullName || 'Пользователь'"
									class="h-full w-full object-cover"
								/>
								<span v-else>{{ initials(activeThread.user.fullName || activeThread.user.email) }}</span>
							</div>
							<div class="min-w-0 flex-1">
								<p class="[overflow-wrap:anywhere] text-base font-semibold text-gray-900">
									{{ activeThread.user.fullName || activeThread.user.email || 'Пользователь' }}
								</p>
								<p class="[overflow-wrap:anywhere] text-sm text-gray-600">
									{{ activeThread.user.phone || activeThread.user.email || 'Без контакта' }}
								</p>
							</div>
						</div>
					</div>

					<div ref="messagesContainer" class="min-h-0 flex-1 space-y-3 overflow-y-auto bg-gray-50 px-5 py-4">
						<div
							v-if="loadingMessages"
							class="flex h-full items-center justify-center gap-2 text-sm text-gray-600"
							role="status"
							aria-live="polite"
						>
							<span>Загружаю сообщения...</span>
						</div>
						<div v-else-if="messages.length === 0" class="flex h-full items-center justify-center text-sm text-gray-600">
							Сообщений пока нет
						</div>
						<div
							v-for="message in messages"
							:key="message.id"
							class="max-w-[92%] overflow-hidden rounded-3xl border px-4 py-3 shadow-sm sm:max-w-[76%]"
							:class="
								message.userAuthUuid === auth.user?.authUuid
									? 'ml-auto border-primary-200 bg-primary-50/80 text-gray-900'
									: 'border-gray-200 bg-white text-gray-900'
							"
						>
							<p
								class="mb-2 text-xs font-medium"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'text-primary-800' : 'text-gray-600'"
							>
								{{ message.userAuthUuid === auth.user?.authUuid ? 'Вы' : message.author?.fullName || activeThread.user.fullName || activeThread.user.email }}
							</p>
							<button
								v-if="isImageMessage(message)"
								type="button"
								class="mb-2 block cursor-zoom-in overflow-hidden rounded-2xl border bg-gray-100 p-0 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'border-primary-200' : 'border-gray-200'"
								:aria-label="`Открыть изображение: ${message.attachmentName || 'вложение'}`"
								@click="openImagePreview($event, message.attachmentUrl)"
							>
								<img
									:src="message.attachmentUrl || undefined"
									:alt="message.attachmentName || 'Изображение'"
									class="max-h-[190px] max-w-full object-cover sm:max-w-[240px]"
									loading="lazy"
								/>
							</button>
							<button
								v-if="isVideoMessage(message)"
								type="button"
								class="mb-2 block cursor-pointer overflow-hidden rounded-2xl border bg-gray-100 p-0 text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'border-primary-200' : 'border-gray-200'"
								:aria-label="`Открыть видео: ${message.attachmentName || 'вложение'}`"
								@click="openVideoPreview($event, message.attachmentUrl)"
							>
								<video
									:src="message.attachmentUrl || undefined"
									class="max-h-[190px] max-w-full object-cover sm:max-w-[240px]"
									preload="metadata"
									playsinline
								/>
							</button>
							<div v-if="isAudioMessage(message)" class="mb-2 min-w-0 sm:min-w-[240px]">
								<audio
									:src="message.attachmentUrl!"
									controls
									class="h-10 w-full"
									preload="metadata"
								/>
							</div>
							<a
								v-if="isDocumentMessage(message)"
								:href="message.attachmentUrl!"
								target="_blank"
								rel="noopener noreferrer"
								class="mb-2 flex items-center gap-3 rounded-2xl border px-3 py-2 text-left text-gray-900 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'border-primary-200 bg-white/60 hover:bg-white' : 'border-gray-200 bg-gray-50 hover:bg-gray-100'"
							>
								<div class="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50 text-primary-700">
									<svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
									</svg>
								</div>
								<div class="min-w-0 flex-1">
									<p class="truncate text-sm font-medium">
										{{ message.attachmentName || 'Документ' }}
									</p>
									<p class="text-xs text-gray-600">
										{{ formatAttachmentSize(message.attachmentSize) || 'Открыть файл' }}
									</p>
								</div>
							</a>
							<p
								v-if="hasTextContent(message)"
								class="whitespace-pre-wrap break-words text-sm leading-6"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'text-gray-900' : 'text-gray-800'"
							>
								{{ message.content }}
							</p>
							<p
								v-else-if="!message.attachmentUrl"
								class="whitespace-pre-wrap break-words text-sm"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'text-gray-900' : 'text-gray-800'"
							>
								Вложение
							</p>
							<div
								class="mt-2 flex flex-wrap items-center gap-2 text-[11px]"
								:class="message.userAuthUuid === auth.user?.authUuid ? 'text-primary-800' : 'text-gray-500'"
							>
								<span>{{ formatDate(message.createdAt) }}</span>
								<span v-if="message.deliveryStatus === 'sending'" class="font-semibold text-amber-700" role="status">Отправка...</span>
								<span v-else-if="message.deliveryStatus === 'failed'" class="font-semibold text-red-700" role="status">Не отправлено</span>
							</div>
						</div>
					</div>

					<div class="shrink-0 border-t border-gray-200 bg-white/70 px-5 py-4 backdrop-blur-sm">
						<div class="flex flex-col items-stretch gap-3 sm:flex-row sm:items-end">
							<textarea
								v-model="messageText"
								rows="3"
								placeholder="Введите сообщение пользователю..."
								aria-label="Сообщение пользователю"
								class="glass-input support-composer-input min-h-[56px] flex-1 resize-none placeholder:text-gray-500"
								@keydown.enter.exact.prevent="sendMessage"
							/>
							<button
								type="button"
								class="btn-primary support-primary-button h-12 px-5 disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
								:disabled="sending || !messageText.trim()"
								@click="sendMessage"
							>
								{{ sending ? 'Отправка...' : 'Отправить' }}
							</button>
						</div>
					</div>
				</template>
			</section>

			<aside class="glass max-h-[520px] min-h-0 overflow-hidden rounded-3xl p-5 xl:max-h-none">
				<div v-if="!activeThread" class="flex h-full items-center justify-center text-sm text-gray-600">
					Карточка пользователя появится после выбора диалога
				</div>
				<div
					v-else-if="loadingContext"
					class="flex h-full items-center justify-center gap-2 text-sm text-gray-600"
					role="status"
					aria-live="polite"
				>
					<span>Загружаю данные пользователя...</span>
				</div>
				<div v-else-if="threadContext" class="h-full space-y-6 overflow-y-auto pr-1">
					<div class="flex items-start gap-4">
						<div class="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-primary-200 bg-primary-50 text-lg font-semibold text-gray-900">
							<img
								v-if="threadContext.user.avatarUrl"
								:src="threadContext.user.avatarUrl"
								:alt="threadContext.user.fullName || 'Пользователь'"
								class="h-full w-full object-cover"
							/>
							<span v-else>{{ initials(threadContext.user.fullName || threadContext.user.email) }}</span>
						</div>
						<div class="min-w-0">
							<p class="break-words text-lg font-semibold text-gray-900">
								{{ threadContext.user.fullName || 'Без имени' }}
							</p>
							<p class="text-sm text-gray-600">{{ formatUserRole(threadContext.user.role) }}</p>
						</div>
					</div>

					<section class="space-y-2">
						<h3 class="text-xs font-semibold uppercase tracking-[0.24em] text-gray-600">Профиль</h3>
						<div class="divide-y divide-gray-200 overflow-hidden rounded-2xl border border-gray-200 bg-white/60">
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'fullName' ? 'ФИО скопировано' : 'Копировать ФИО'" @click="copyField('fullName', threadContext.user.fullName)">
								<span class="support-info-label">ФИО</span>
								<span class="support-info-value">{{ formatValue(threadContext.user.fullName) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'fullName'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
									</svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
									</svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'phone' ? 'Телефон скопирован' : 'Копировать Телефон'" @click="copyField('phone', threadContext.user.phone)">
								<span class="support-info-label">Телефон</span>
								<span class="support-info-value">{{ formatValue(threadContext.user.phone) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'phone'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'email' ? 'Email скопирован' : 'Копировать Email'" @click="copyField('email', threadContext.user.email)">
								<span class="support-info-label">Email</span>
								<span class="support-info-value">{{ formatValue(threadContext.user.email) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'email'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'createdAt' ? 'Дата вступления скопирована' : 'Копировать дату вступления'" @click="copyField('createdAt', threadContext.user.createdAt)">
								<span class="support-info-label">В клубе с</span>
								<span class="support-info-value">{{ formatValue(threadContext.user.createdAt) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'createdAt'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'city' ? 'Город скопирован' : 'Копировать Город'" @click="copyField('city', threadContext.user.city)">
								<span class="support-info-label">Город</span>
								<span class="support-info-value">{{ formatValue(threadContext.user.city) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'city'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'workPlace' ? 'Место работы скопировано' : 'Копировать Место работы'" @click="copyField('workPlace', threadContext.user.workPlace)">
								<span class="support-info-label">Место работы</span>
								<span class="support-info-value">{{ formatValue(threadContext.user.workPlace) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'workPlace'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'userMessages' ? 'Количество сообщений скопировано' : 'Копировать количество сообщений'" @click="copyField('userMessages', threadContext.stats.userMessages)">
								<span class="support-info-label">Сообщений</span>
								<span class="support-info-value">{{ threadContext.stats.userMessages }} от пользователя</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'userMessages'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
						</div>
					</section>

					<section class="space-y-2">
						<div class="flex items-center justify-between gap-3">
							<h3 class="text-xs font-semibold uppercase tracking-[0.24em] text-gray-600">Подписка</h3>
							<span :class="paymentStatusClass(threadContext)" class="text-xs font-medium">
								{{ formatPaymentStatus(threadContext) }}
							</span>
						</div>
						<div class="divide-y divide-gray-200 overflow-hidden rounded-2xl border border-gray-200 bg-white/60">
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'amount' ? 'Сумма скопирована' : 'Копировать Сумму'" @click="copyField('amount', threadContext.payment?.amount)">
								<span class="support-info-label">Сумма</span>
								<span class="support-info-value">{{ formatValue(threadContext.payment?.amount) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'amount'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'paymentProvider' ? 'Провайдер скопирован' : 'Копировать Провайдера'" @click="copyField('paymentProvider', threadContext.payment?.paymentProvider)">
								<span class="support-info-label">Провайдер</span>
								<span class="support-info-value">{{ formatValue(threadContext.payment?.paymentProvider) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'paymentProvider'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'autoPayment' ? 'Автосписание скопировано' : 'Копировать Автосписание'" @click="copyField('autoPayment', threadContext.payment?.autoPayment)">
								<span class="support-info-label">Автосписание</span>
								<span class="support-info-value">{{ formatValue(threadContext.payment?.autoPayment) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'autoPayment'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'dateStart' ? 'Дата старта скопирована' : 'Копировать Дату старта'" @click="copyField('dateStart', threadContext.payment?.dateStart)">
								<span class="support-info-label">Дата старта</span>
								<span class="support-info-value">{{ formatValue(threadContext.payment?.dateStart) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'dateStart'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'dateFinish' ? 'Дата окончания скопирована' : 'Копировать Дату окончания'" @click="copyField('dateFinish', threadContext.payment?.dateFinish)">
								<span class="support-info-label">Дата окончания</span>
								<span class="support-info-value">{{ formatValue(threadContext.payment?.dateFinish) }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'dateFinish'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
							<button type="button" class="support-info-row" :aria-label="copiedFieldKey === 'access' ? 'Доступы скопированы' : 'Копировать Доступы'" @click="copyField('access', accessChips(threadContext).join(', '))">
								<span class="support-info-label">Доступы</span>
								<span class="support-info-value">{{ accessChips(threadContext).length ? accessChips(threadContext).join(', ') : '—' }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === 'access'" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
						</div>
					</section>

					<section class="space-y-2">
						<h3 class="text-xs font-semibold uppercase tracking-[0.24em] text-gray-600">Покупки и списания</h3>
						<div v-if="threadContext.paymentLogs.length > 0" class="divide-y divide-gray-200 overflow-hidden rounded-2xl border border-gray-200 bg-white/60">
							<button
								v-for="log in threadContext.paymentLogs"
								:key="log.id"
								type="button"
								class="support-info-row"
								:aria-label="copiedFieldKey === `paymentLog-${log.id}` ? `${log.tariff || log.event} скопировано` : `Копировать ${log.tariff || log.event}`"
								@click="copyField(`paymentLog-${log.id}`, `${log.tariff || log.event} | ${log.amount || '—'} | ${log.status || 'не указан'} | ${formatValue(log.paymentDate || log.createdAt)}`)"
							>
								<span class="support-info-label">{{ log.tariff || log.event }}</span>
								<span class="support-info-value">{{ formatValue(log.paymentDate || log.createdAt) }} · {{ log.amount || '—' }} · {{ log.status || 'не указан' }}</span>
								<span class="support-copy-state" aria-hidden="true">
									<svg v-if="copiedFieldKey === `paymentLog-${log.id}`" class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
									<svg v-else class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
								</span>
							</button>
						</div>
						<p v-else class="rounded-2xl border border-gray-200 bg-white/60 px-4 py-3 text-sm text-gray-600">
							История оплат пока пустая.
						</p>
					</section>
				</div>
			</aside>
		</div>
	</div>

	<Teleport to="body">
		<div
			v-if="fullscreenImageUrl"
			class="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-4"
			role="dialog"
			aria-modal="true"
			aria-label="Просмотр изображения"
			@click.self="closeImagePreview"
		>
			<button
				ref="imagePreviewCloseButton"
				type="button"
				class="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
				aria-label="Закрыть просмотр изображения"
				@click="closeImagePreview"
			>
				<svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>
			<img :src="fullscreenImageUrl" alt="Вложение" class="max-h-full max-w-full object-contain" />
		</div>
	</Teleport>

	<Teleport to="body">
		<div
			v-if="fullscreenVideoUrl"
			class="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-4"
			role="dialog"
			aria-modal="true"
			aria-label="Просмотр видео"
			@click.self="closeVideoPreview"
		>
			<button
				ref="videoPreviewCloseButton"
				type="button"
				class="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
				aria-label="Закрыть просмотр видео"
				@click="closeVideoPreview"
			>
				<svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
				</svg>
			</button>
			<video
				:src="fullscreenVideoUrl"
				class="max-h-full max-w-full"
				controls
				autoplay
				playsinline
			/>
		</div>
	</Teleport>
</template>

<style scoped>
.support-primary-button:hover {
	background-color: var(--admin-accent);
	color: var(--admin-text);
}

.support-primary-button:focus-visible {
	outline: 2px solid var(--admin-accent-strong);
	outline-offset: 2px;
}

.support-composer-input:focus-visible {
	outline: 2px solid var(--admin-accent-strong);
	outline-offset: 2px;
	box-shadow: 0 0 0 4px color-mix(in srgb, var(--admin-accent) 28%, transparent);
}

.support-thread-button:not([aria-current="true"]) {
	border-color: var(--admin-border);
	background-color: color-mix(in srgb, var(--admin-surface) 60%, transparent);
	color: var(--admin-text);
}

.support-thread-button:not([aria-current="true"]):hover {
	border-color: var(--admin-accent);
	background-color: color-mix(in srgb, var(--admin-accent) 12%, var(--admin-surface));
}

.support-info-row {
	display: grid;
	width: 100%;
	grid-template-columns: minmax(0, 1fr) auto;
	gap: 12px;
	padding: 14px 16px;
	text-align: left;
	color: var(--admin-text);
	transition: background-color 0.2s ease, box-shadow 0.2s ease;
}

.support-info-row:hover {
	background: var(--admin-bg-deep);
}

.support-info-row:focus-visible {
	outline: none;
	box-shadow: inset 0 0 0 2px var(--admin-accent);
}

.support-info-label {
	min-width: 0;
	font-size: 11px;
	font-weight: 600;
	letter-spacing: 0.18em;
	text-transform: uppercase;
	color: var(--admin-muted);
}

.support-info-value {
	grid-column: 1 / -1;
	min-width: 0;
	overflow-wrap: anywhere;
	font-size: 14px;
	line-height: 1.45;
	color: var(--admin-text);
}

.support-copy-state {
	grid-column: 2;
	grid-row: 1;
	align-self: start;
	font-size: 11px;
	font-weight: 500;
	color: var(--admin-muted);
}

.support-status-muted {
	color: var(--admin-muted);
}

.support-status-success {
	color: var(--admin-success-text);
}

.support-status-warning {
	color: var(--admin-warning-text);
}

@media (min-width: 1536px) {
	.support-info-row {
		grid-template-columns: 112px minmax(0, 1fr) auto;
	}

	.support-info-value,
	.support-copy-state {
		grid-column: auto;
		grid-row: auto;
	}
}
</style>
