<template>
	<AdminSettingsWorkspace mode="design" />
</template>
