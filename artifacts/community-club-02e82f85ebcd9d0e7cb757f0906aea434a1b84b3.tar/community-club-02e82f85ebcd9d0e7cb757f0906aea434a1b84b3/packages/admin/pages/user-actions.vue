<script setup lang="ts">
import type { PaginatedResponse } from '@community-club/shared/types'

type UserActionType =
	| 'registration'
	| 'payment'
	| 'demo_access'
	| 'payment_error'
	| 'material_view'
	| 'material_complete'

type UserActionItem = {
	id: string
	type: UserActionType
	userAuthUuid: string | null
	userName: string | null
	userEmail: string | null
	userPhone: string | null
	title: string
	description: string | null
	meta: Record<string, unknown> | null
	createdAt: string | Date
}

const api = useAdminApi()
const actions = ref<UserActionItem[]>([])
const loading = ref(true)
const loadingMore = ref(false)
const page = ref(1)
const pageSize = 50
const total = ref(0)
const hasMore = ref(false)
const search = ref('')
const selectedType = ref<UserActionType | 'all'>('all')
let searchDebounce: ReturnType<typeof setTimeout> | null = null

const actionTypeOptions: Array<{ value: UserActionType | 'all'; label: string }> = [
	{ value: 'all', label: 'Все' },
	{ value: 'registration', label: 'Регистрации' },
	{ value: 'payment', label: 'Оплаты' },
	{ value: 'demo_access', label: 'Тестовые доступы' },
	{ value: 'payment_error', label: 'Ошибки' },
	{ value: 'material_view', label: 'Просмотры' },
	{ value: 'material_complete', label: 'Завершения' },
]

async function loadActions(reset = false) {
	if (reset) page.value = 1
	if (page.value === 1) loading.value = true
	else loadingMore.value = true

	const params = new URLSearchParams({
		page: String(page.value),
		pageSize: String(pageSize),
	})
	if (selectedType.value !== 'all') params.set('type', selectedType.value)
	if (search.value.trim()) params.set('q', search.value.trim())

	const res = await api.get<PaginatedResponse<UserActionItem>>(
		`/api/admin/user-actions?${params.toString()}`,
	)
	if (res.success) {
		actions.value =
			reset || page.value === 1 ? res.data.items : [...actions.value, ...res.data.items]
		total.value = res.data.total
		hasMore.value = res.data.hasMore
	}

	loading.value = false
	loadingMore.value = false
}

function scheduleReload() {
	if (searchDebounce) clearTimeout(searchDebounce)
	searchDebounce = setTimeout(() => {
		void loadActions(true)
	}, 200)
}

function loadMore() {
	if (loadingMore.value || !hasMore.value) return
	page.value += 1
	void loadActions()
}

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function userLabel(action: UserActionItem) {
	return action.userName || action.userEmail || action.userPhone || 'Участник не определён'
}

function userSubline(action: UserActionItem) {
	return [action.userEmail, action.userPhone].filter(Boolean).join(' · ')
}

function actionClass(type: UserActionType) {
	const classes: Record<UserActionType, string> = {
		registration: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-200',
		payment: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-200',
		demo_access: 'bg-violet-50 text-violet-700 dark:bg-violet-500/10 dark:text-violet-200',
		payment_error: 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-200',
		material_view: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-200',
		material_complete: 'bg-lime-50 text-lime-700 dark:bg-lime-500/10 dark:text-lime-200',
	}
	return classes[type]
}

function metaLines(action: UserActionItem) {
	const meta = action.meta ?? {}
	const lines: string[] = []

	if (meta.tariff) lines.push(`Тариф: ${meta.tariff}`)
	if (meta.amount) lines.push(`Сумма: ${meta.amount}`)
	if (meta.provider) lines.push(`Провайдер: ${meta.provider}`)
	if (meta.status) lines.push(`Статус: ${meta.status}`)
	if (meta.event) lines.push(`Событие: ${meta.event}`)
	if (meta.dateFinish) lines.push(`Доступ до: ${String(meta.dateFinish).slice(0, 10)}`)
	if (meta.materialId) lines.push(`Материал #${meta.materialId}`)
	if (meta.positionSeconds) lines.push(`Позиция: ${meta.positionSeconds} сек.`)
	if (meta.durationSeconds) lines.push(`Длительность: ${meta.durationSeconds} сек.`)

	return lines
}

watch(selectedType, () => {
	void loadActions(true)
})
watch(search, scheduleReload)

onMounted(() => {
	void loadActions(true)
})
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
			<div>
				<p class="text-sm font-medium text-primary-600">Активность</p>
				<h1 class="mt-1 text-2xl font-bold text-gray-900 dark:text-white">Действия участников</h1>
				<p class="mt-2 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
					Лента регистраций, оплат, тестовых доступов, ошибок и просмотров материалов.
				</p>
			</div>
			<div class="flex flex-col gap-3 md:flex-row md:items-center">
				<input
					v-model="search"
					class="glass-input md:w-72"
					placeholder="Поиск по имени, email или событию"
				/>
				<select v-model="selectedType" class="glass-input md:w-56">
					<option v-for="option in actionTypeOptions" :key="option.value" :value="option.value">
						{{ option.label }}
					</option>
				</select>
			</div>
		</div>

		<div class="mb-4 rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-400">
			Найдено: <span class="font-semibold text-gray-900 dark:text-white">{{ total }}</span>
		</div>

		<div class="glass overflow-hidden rounded-[30px]">
			<div v-if="loading" class="px-6 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
				Загружаю действия...
			</div>
			<div v-else-if="actions.length === 0" class="px-6 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
				Действий пока нет.
			</div>
			<div v-else class="divide-y divide-white/10">
				<article
					v-for="action in actions"
					:key="action.id"
					class="grid gap-4 px-6 py-5 lg:grid-cols-[180px_240px_minmax(0,1fr)]"
				>
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Когда</p>
						<p class="mt-2 text-sm text-gray-700 dark:text-gray-200">{{ formatDate(action.createdAt) }}</p>
					</div>
					<div class="min-w-0">
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Участник</p>
						<p class="mt-2 truncate text-sm font-medium text-gray-900 dark:text-white">{{ userLabel(action) }}</p>
						<p v-if="userSubline(action)" class="mt-1 truncate text-xs text-gray-500 dark:text-gray-400">
							{{ userSubline(action) }}
						</p>
					</div>
					<div class="min-w-0">
						<div class="flex flex-wrap items-center gap-2">
							<span class="rounded-full px-2.5 py-1 text-xs font-semibold" :class="actionClass(action.type)">
								{{ action.title }}
							</span>
						</div>
						<p v-if="action.description" class="mt-3 text-sm font-medium text-gray-900 dark:text-white">
							{{ action.description }}
						</p>
						<div
							v-if="metaLines(action).length"
							class="mt-3 rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-xs text-white/65"
						>
							<p v-for="line in metaLines(action)" :key="line" class="leading-5">{{ line }}</p>
						</div>
					</div>
				</article>
			</div>
		</div>

		<div v-if="hasMore" class="mt-5 flex justify-center">
			<button type="button" class="btn-secondary" :disabled="loadingMore" @click="loadMore">
				{{ loadingMore ? 'Загрузка...' : 'Показать ещё' }}
			</button>
		</div>
	</div>
</template>
