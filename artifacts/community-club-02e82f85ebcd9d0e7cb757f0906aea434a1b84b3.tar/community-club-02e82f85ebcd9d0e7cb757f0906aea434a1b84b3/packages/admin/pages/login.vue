<script setup lang="ts">
import { useAuthStore } from '~/stores/auth'

definePageMeta({ layout: 'auth' })

const auth = useAuthStore()
const email = ref('')
const password = ref('')
const error = ref('')
const loading = ref(false)

async function handleLogin() {
	error.value = ''
	loading.value = true
	try {
		const result = await auth.login(email.value, password.value)
		if (result.ok) {
			await navigateTo('/')
		} else {
			error.value = result.error ?? 'Ошибка авторизации'
		}
	} catch {
		error.value = 'Ошибка сети'
	} finally {
		loading.value = false
	}
}
</script>

<template>
	<div class="w-full max-w-sm mx-4">
		<div class="glass rounded-3xl p-8">
			<h1 class="text-xl font-bold text-center mb-1 text-slate-900 dark:text-slate-100">
				Community Club
			</h1>
			<p class="text-sm text-gray-400 text-center mb-6">Вход в панель администратора</p>

			<form @submit.prevent="handleLogin" class="space-y-4">
				<div class="float-label">
					<input
						v-model="email"
						type="email"
						required
						autocomplete="email"
						class="glass-input"
						placeholder=" "
					/>
					<label>Email</label>
				</div>
				<div class="float-label">
					<input
						v-model="password"
						type="password"
						required
						autocomplete="current-password"
						class="glass-input"
						placeholder=" "
					/>
					<label>Пароль</label>
				</div>

				<p v-if="error" class="text-sm text-red-500">{{ error }}</p>

				<button
					type="submit"
					:disabled="loading"
					class="btn-primary w-full"
				>
					{{ loading ? 'Вход...' : 'Войти' }}
				</button>
			</form>
		</div>
	</div>
</template>
