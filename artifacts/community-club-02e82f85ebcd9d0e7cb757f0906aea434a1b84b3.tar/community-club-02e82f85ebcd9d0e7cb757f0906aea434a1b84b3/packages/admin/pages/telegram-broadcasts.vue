<script setup lang="ts">
import {
	type AdminTelegramBroadcast,
	type AdminTelegramBroadcastBot,
	sanitizeTelegramBroadcastHtml,
} from '@community-club/shared'
import MessengerBroadcastComposer from '~/components/messenger/MessengerBroadcastComposer.vue'
import MessengerConnections from '~/components/messenger/MessengerConnections.vue'
import TelegramBroadcastComposer from '~/components/telegram/TelegramBroadcastComposer.vue'

type FailedDelivery = {
	id: number
	error_message: string | null
	telegram_user_id: string
	telegram_username: string | null
	full_name: string | null
}

const api = useAdminApi()
const loading = ref(true)
const errorMessage = ref('')
const campaigns = ref<AdminTelegramBroadcast[]>([])
const bots = ref<AdminTelegramBroadcastBot[]>([])
const failures = ref<FailedDelivery[]>([])
const failuresFor = ref<number | null>(null)

function formatDate(value: string | Date) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}
function statusLabel(status: AdminTelegramBroadcast['status']) {
	return {
		scheduled: 'Запланирована',
		processing: 'Отправляется',
		paused: 'Приостановлена',
		completed: 'Завершена',
		failed: 'Ошибка',
		cancelled: 'Отменена',
	}[status]
}
function botLabel(username: string) {
	const bot = bots.value.find((item) => item.username === username)
	return bot ? `${bot.label} (@${bot.username})` : `@${username}`
}
function campaignBots(campaign: AdminTelegramBroadcast) {
	return (campaign.botUsernames.length ? campaign.botUsernames : [campaign.botUsername])
		.map(botLabel)
		.join(' · ')
}

async function loadData() {
	loading.value = true
	const res = await api.get<{
		campaigns: AdminTelegramBroadcast[]
		bots: AdminTelegramBroadcastBot[]
	}>('/api/admin/telegram-broadcasts')
	if (res.success) {
		campaigns.value = res.data.campaigns
		bots.value = res.data.bots
	} else errorMessage.value = res.error.message
	loading.value = false
}

async function cancelBroadcast(id: number) {
	const res = await api.delete(`/api/admin/telegram-broadcasts/${id}`)
	if (res.success) await loadData()
	else errorMessage.value = res.error.message
}

async function pauseBroadcast(id: number) {
	const res = await api.post(`/api/admin/telegram-broadcasts/${id}/pause`, {})
	if (res.success) await loadData()
	else errorMessage.value = res.error.message
}

async function resumeBroadcast(id: number) {
	const res = await api.post(`/api/admin/telegram-broadcasts/${id}/resume`, {})
	if (res.success) await loadData()
	else errorMessage.value = res.error.message
}

async function stopBroadcast(id: number) {
	if (!confirm('Остановить рассылку? Неотправленные сообщения не будут доставлены.')) return
	const res = await api.post(`/api/admin/telegram-broadcasts/${id}/stop`, {})
	if (res.success) await loadData()
	else errorMessage.value = res.error.message
}

async function loadFailures(id: number) {
	if (failuresFor.value === id) {
		failuresFor.value = null
		failures.value = []
		return
	}
	const res = await api.get<FailedDelivery[]>(
		`/api/admin/telegram-broadcasts/${id}/deliveries?status=failed`,
	)
	if (res.success) {
		failuresFor.value = id
		failures.value = res.data
	} else errorMessage.value = res.error.message
}

onMounted(loadData)
</script>

<template>
	<div class="p-4 sm:p-6">
		<div class="mb-6"><h1 class="text-2xl font-bold dark:text-white">Рассылки</h1><p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Telegram-рассылки уже готовы. Подключайте VK и MAX здесь же — их аудитория будет собираться автоматически.</p></div>
		<MessengerConnections class="mb-6" />
		<MessengerBroadcastComposer class="mb-6" />
		<div class="mb-3"><h2 class="font-semibold dark:text-white">Расширенный Telegram-редактор</h2><p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Медиа, кнопки, форматирование и предпросмотр сообщения.</p></div>
		<div v-if="!loading && !bots.length" class="glass rounded-2xl p-5 text-sm text-amber-700 dark:text-amber-300">Боты ещё не настроены на сервере. Добавьте TELEGRAM_BROADCAST_BOTS в .env demo-контура.</div>
		<TelegramBroadcastComposer v-else-if="!loading" :bots="bots" @created="loadData" />
		<div v-else class="glass rounded-2xl p-12 text-center text-sm text-gray-500">Загружаю настройки рассылки…</div>
		<p v-if="errorMessage" class="mt-4 text-sm text-red-500">{{ errorMessage }}</p>

		<section class="glass mt-6 overflow-hidden rounded-2xl"><div class="border-b border-gray-200/60 px-5 py-4 dark:border-white/10"><h2 class="font-semibold dark:text-white">История</h2></div><div v-if="!campaigns.length" class="p-8 text-sm text-gray-500">Рассылок пока нет.</div><div v-else class="divide-y divide-gray-100/70 dark:divide-white/5"><article v-for="campaign in campaigns" :key="campaign.id" class="p-5"><div class="flex flex-wrap items-start justify-between gap-3"><div><p class="font-medium dark:text-white">{{ campaign.name }}</p><p class="mt-1 text-xs text-gray-500">{{ campaignBots(campaign) }} · {{ formatDate(campaign.sendAt) }}</p></div><span class="rounded-full bg-primary-500/10 px-2.5 py-1 text-xs font-medium text-primary-700 dark:text-primary-300">{{ statusLabel(campaign.status) }}</span></div><div v-if="campaign.media" class="mt-3 text-xs text-gray-500">📎 {{ campaign.media.name }}</div><div v-if="campaign.body" class="telegram-history mt-3 text-sm text-gray-600 dark:text-gray-300" v-html="sanitizeTelegramBroadcastHtml(campaign.body)" /><div class="mt-4 flex flex-wrap items-center gap-3 text-xs text-gray-500"><span>Получателей: {{ campaign.audienceSize }}</span><span class="text-green-600">Отправлено: {{ campaign.sentCount }}</span><span v-if="campaign.failedCount" class="text-red-500">Ошибок: {{ campaign.failedCount }}</span><span v-if="campaign.deliveryMode === 'unique'">Без дублей</span><button v-if="campaign.failedCount" class="text-red-500 hover:underline" @click="loadFailures(campaign.id)">Показать ошибки</button><button v-if="campaign.status === 'scheduled'" class="hover:text-red-500" @click="cancelBroadcast(campaign.id)">Отменить</button><button v-if="campaign.status === 'processing'" class="hover:text-amber-500" @click="pauseBroadcast(campaign.id)">Пауза</button><button v-if="campaign.status === 'paused'" class="hover:text-green-600" @click="resumeBroadcast(campaign.id)">Возобновить</button><button v-if="campaign.status === 'processing' || campaign.status === 'paused'" class="hover:text-red-500" @click="stopBroadcast(campaign.id)">Остановить</button></div><div v-if="failuresFor === campaign.id" class="mt-4 rounded-xl bg-red-50/70 p-3 text-xs dark:bg-red-500/10"><p v-if="!failures.length" class="text-gray-500">Ошибки не найдены.</p><ul v-else class="space-y-2"><li v-for="failure in failures" :key="failure.id" class="text-red-700 dark:text-red-300">{{ failure.full_name || failure.telegram_username || failure.telegram_user_id }}: {{ failure.error_message || 'Неизвестная ошибка' }}</li></ul></div></article></div></section>
	</div>
</template>

<style scoped>
.telegram-history :deep(b), .telegram-history :deep(strong) { font-weight: 700; }
.telegram-history :deep(i), .telegram-history :deep(em) { font-style: italic; }
.telegram-history :deep(u) { text-decoration: underline; }
.telegram-history :deep(s), .telegram-history :deep(strike), .telegram-history :deep(del) { text-decoration: line-through; }
.telegram-history :deep(a) { color: rgb(37 99 235); text-decoration: underline; }
</style>
