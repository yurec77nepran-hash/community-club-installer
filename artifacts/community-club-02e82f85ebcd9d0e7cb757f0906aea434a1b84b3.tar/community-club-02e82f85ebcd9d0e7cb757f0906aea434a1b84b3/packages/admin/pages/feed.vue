<script setup lang="ts">
import { FEED_AUDIENCES, buildFeedExcerpt } from '@community-club/shared'
import type {
	AdminMediaLibraryItem,
	CursorPaginatedResponse,
	FeedMediaItem,
	FeedPostDraftItem,
	FeedPostItem,
} from '@community-club/shared/types'
import AdminFeedPostPreview from '~/components/feed/AdminFeedPostPreview.vue'

type FeedSection = 'club'

const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()

const activeAudience = ref<FeedSection>('club')
const loading = ref(true)
const publishing = ref(false)
const uploading = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const posts = ref<FeedPostItem[]>([])
const nextCursor = ref<string | null>(null)
const loadingMore = ref(false)
const editorRef = ref<HTMLTextAreaElement | null>(null)
const emojiPickerAnchorRef = ref<HTMLElement | null>(null)
const showEmojiPicker = ref(false)
const lastDraftSavedAt = ref<string | null>(null)
const selectedDraftId = ref<number | null>(null)
const draftsLoading = ref(false)
const drafts = ref<FeedPostDraftItem[]>([])

const mediaLibraryOpen = ref(false)
const mediaLibraryLoading = ref(false)
const mediaLibraryLoadingMore = ref(false)
const mediaLibraryItems = ref<AdminMediaLibraryItem[]>([])
const mediaLibraryCursor = ref<string | null>(null)

const draft = ref({
	audience: 'club' as FeedSection,
	content: '',
	buttonLabel: '',
	buttonUrl: '',
	notifyAll: true,
	media: [] as FeedMediaItem[],
})

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}

function applyDraftState(
	value: Pick<
		FeedPostDraftItem,
		'audience' | 'content' | 'buttonLabel' | 'buttonUrl' | 'notifyAll' | 'media'
	> | null,
	audience: FeedSection,
) {
	draft.value.audience = audience
	draft.value.content = value?.content ?? ''
	draft.value.buttonLabel = value?.buttonLabel ?? ''
	draft.value.buttonUrl = value?.buttonUrl ?? ''
	draft.value.notifyAll = value?.notifyAll ?? true
	draft.value.media = Array.isArray(value?.media) ? [...value.media] : []
}

const previewItem = computed<FeedPostItem>(() => ({
	id: 0,
	audience: draft.value.audience,
	content: draft.value.content,
	contentHtml: '',
	buttonLabel: draft.value.buttonLabel.trim() || null,
	buttonUrl: draft.value.buttonUrl.trim() || null,
	notifyAll: draft.value.notifyAll,
	media: draft.value.media,
	createdAt: new Date().toISOString(),
	author: null,
	reactions: [],
}))

const previewIsEmpty = computed(
	() =>
		!draft.value.content.trim() &&
		draft.value.media.length === 0 &&
		!draft.value.buttonLabel.trim() &&
		!draft.value.buttonUrl.trim(),
)

const previewKey = computed(
	() =>
		`${draft.value.audience}|${draft.value.content}|${draft.value.buttonLabel}|${draft.value.buttonUrl}|${draft.value.notifyAll}|${draft.value.media.map((item) => item.path).join(',')}`,
)

const previewTimestamp = computed(() => {
	if (previewIsEmpty.value) return null
	return lastDraftSavedAt.value || previewItem.value.createdAt
})

function formatSize(size: number | null) {
	if (!size) return ''
	if (size < 1024 * 1024) return `${Math.round(size / 1024)} КБ`
	return `${(size / (1024 * 1024)).toFixed(1)} МБ`
}

function formatDate(value: string | Date | null) {
	if (!value) return ''
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'long',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}

async function loadPosts(options?: { append?: boolean }) {
	const append = options?.append ?? false
	if (append) {
		if (!nextCursor.value || loadingMore.value) return
		loadingMore.value = true
	} else {
		loading.value = true
	}

	resetMessages()

	const query = new URLSearchParams({
		limit: '12',
		audience: activeAudience.value,
	})
	if (append && nextCursor.value) {
		query.set('cursor', nextCursor.value)
	}

	const res = await api.get<CursorPaginatedResponse<FeedPostItem>>(
		`/api/admin/feed-posts?${query.toString()}`,
	)
	if (res.success) {
		posts.value = append ? [...posts.value, ...res.data.items] : res.data.items
		nextCursor.value = res.data.nextCursor
	} else {
		errorMessage.value = res.error.message
	}

	loading.value = false
	loadingMore.value = false
}

async function loadDrafts(audience: FeedSection) {
	draftsLoading.value = true
	const res = await api.get<FeedPostDraftItem[]>(`/api/admin/feed-drafts?audience=${audience}`)
	if (res.success) {
		drafts.value = res.data
	} else {
		errorMessage.value = res.error.message
	}
	draftsLoading.value = false
}

async function loadMediaLibrary(options?: { append?: boolean }) {
	const append = options?.append ?? false
	if (append) {
		if (!mediaLibraryCursor.value || mediaLibraryLoadingMore.value) return
		mediaLibraryLoadingMore.value = true
	} else {
		mediaLibraryLoading.value = true
	}

	const query = new URLSearchParams({ limit: '24' })
	if (append && mediaLibraryCursor.value) {
		query.set('cursor', mediaLibraryCursor.value)
	}

	const res = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		`/api/admin/media-library?${query.toString()}`,
	)
	if (res.success) {
		const allowedItems = res.data.items.filter(
			(item) => item.type === 'image' || item.type === 'video',
		)
		mediaLibraryItems.value = append ? [...mediaLibraryItems.value, ...allowedItems] : allowedItems
		mediaLibraryCursor.value = res.data.nextCursor
	} else {
		errorMessage.value = res.error.message
	}

	mediaLibraryLoading.value = false
	mediaLibraryLoadingMore.value = false
}

watch(activeAudience, () => {
	resetEditor(activeAudience.value)
	void Promise.all([loadPosts(), loadDrafts(activeAudience.value)])
})

function resetEditor(audience = activeAudience.value) {
	applyDraftState(null, audience)
	draft.value.audience = audience
	selectedDraftId.value = null
	lastDraftSavedAt.value = null
}

function createNewDraft() {
	resetMessages()
	resetEditor(activeAudience.value)
	successMessage.value = 'Можно собирать новый черновик.'
}

function loadDraftIntoEditor(id: number) {
	resetMessages()
	const item = drafts.value.find((draftItem) => draftItem.id === id)
	if (!item) {
		errorMessage.value = 'Черновик не найден'
		return
	}

	selectedDraftId.value = item.id
	applyDraftState(item, item.audience)
	lastDraftSavedAt.value = String(item.updatedAt)
}

async function deleteSelectedDraft(options?: { silent?: boolean }) {
	resetMessages()
	if (!selectedDraftId.value) {
		resetEditor(activeAudience.value)
		if (!options?.silent) {
			successMessage.value = 'Редактор очищен.'
		}
		return
	}

	const res = await api.delete<{ deleted: true }>(`/api/admin/feed-drafts/${selectedDraftId.value}`)
	if (!res.success) {
		errorMessage.value = res.error.message
		return
	}

	resetEditor(activeAudience.value)
	await loadDrafts(activeAudience.value)
	if (!options?.silent) {
		successMessage.value = 'Черновик очищен.'
	}
}

async function saveDraft() {
	resetMessages()
	const payload = {
		audience: draft.value.audience,
		content: draft.value.content.trim(),
		buttonLabel: draft.value.buttonLabel.trim() || null,
		buttonUrl: draft.value.buttonUrl.trim() || null,
		notifyAll: draft.value.notifyAll,
		media: draft.value.media,
	}

	const res = selectedDraftId.value
		? await api.patch<FeedPostDraftItem>(`/api/admin/feed-drafts/${selectedDraftId.value}`, payload)
		: await api.post<FeedPostDraftItem>('/api/admin/feed-drafts', payload)
	if (res.success) {
		selectedDraftId.value = res.data.id
		lastDraftSavedAt.value = String(res.data.updatedAt)
		successMessage.value = 'Черновик сохранён в базе.'
		await loadDrafts(draft.value.audience)
	} else {
		errorMessage.value = res.error.message
	}
}

function insertAtCursor(snippet: string) {
	const textarea = editorRef.value
	if (!textarea) {
		draft.value.content += snippet
		return
	}

	const start = textarea.selectionStart
	const end = textarea.selectionEnd
	const value = draft.value.content
	const before = value.slice(0, start)
	const after = value.slice(end)
	draft.value.content = `${before}${snippet}${after}`

	nextTick(() => {
		textarea.focus()
		const caret = start + snippet.length
		textarea.selectionStart = caret
		textarea.selectionEnd = caret
	})
}

function wrapSelection(tag: 'strong' | 'em' | 'u' | 's') {
	const textarea = editorRef.value
	if (!textarea) return

	const start = textarea.selectionStart
	const end = textarea.selectionEnd
	const value = draft.value.content
	const before = value.slice(0, start)
	const selection = value.slice(start, end) || 'текст'
	const after = value.slice(end)
	const wrapped = `<${tag}>${selection}</${tag}>`
	draft.value.content = `${before}${wrapped}${after}`

	nextTick(() => {
		textarea.focus()
		textarea.selectionStart = start
		textarea.selectionEnd = start + wrapped.length
	})
}

function insertEmoji(emoji: string) {
	insertAtCursor(`${emoji} `)
	showEmojiPicker.value = false
}

function toggleEmojiPicker() {
	showEmojiPicker.value = !showEmojiPicker.value
}

function onDocumentClick(event: MouseEvent) {
	if (!showEmojiPicker.value) return
	const anchor = emojiPickerAnchorRef.value
	if (!anchor) return
	if (anchor.contains(event.target as Node)) return
	showEmojiPicker.value = false
}

function onEmojiPickerSelect(event: Event) {
	const emoji = (event as CustomEvent<{ unicode?: string }>).detail?.unicode
	if (!emoji) return
	insertEmoji(emoji)
}

async function readMediaMetadata(file: File) {
	if (file.type.startsWith('image/')) {
		return new Promise<Pick<FeedMediaItem, 'type' | 'width' | 'height' | 'durationSeconds'>>(
			(resolve) => {
				const url = URL.createObjectURL(file)
				const image = new Image()
				image.onload = () => {
					resolve({
						type: 'image',
						width: image.naturalWidth,
						height: image.naturalHeight,
						durationSeconds: null,
					})
					URL.revokeObjectURL(url)
				}
				image.onerror = () => {
					resolve({ type: 'image', width: null, height: null, durationSeconds: null })
					URL.revokeObjectURL(url)
				}
				image.src = url
			},
		)
	}

	return new Promise<Pick<FeedMediaItem, 'type' | 'width' | 'height' | 'durationSeconds'>>(
		(resolve) => {
			const url = URL.createObjectURL(file)
			const video = document.createElement('video')
			video.preload = 'metadata'
			video.onloadedmetadata = () => {
				resolve({
					type: 'video',
					width: video.videoWidth || null,
					height: video.videoHeight || null,
					durationSeconds: Number.isFinite(video.duration) ? Math.round(video.duration) : null,
				})
				URL.revokeObjectURL(url)
			}
			video.onerror = () => {
				resolve({ type: 'video', width: null, height: null, durationSeconds: null })
				URL.revokeObjectURL(url)
			}
			video.src = url
		},
	)
}

async function uploadMedia(event: Event) {
	const files = Array.from((event.target as HTMLInputElement).files ?? [])
	if (files.length === 0) return

	uploading.value = true
	resetMessages()

	try {
		for (const file of files) {
			if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) continue
			const meta = await readMediaMetadata(file)
			const result = await mediaUpload.uploadFile(file)
			if (!result.success) {
				throw new Error(result.error.message)
			}

			const createdItem: FeedMediaItem = {
				type: meta.type,
				path: result.data.path,
				url: result.data.url ?? result.data.path,
				name: file.name,
				size: file.size,
				width: meta.width,
				height: meta.height,
				durationSeconds: meta.durationSeconds,
			}

			draft.value.media.push(createdItem)
			mediaLibraryItems.value = [
				{
					key: createdItem.path,
					name: createdItem.name || createdItem.path,
					url: createdItem.url || createdItem.path,
					type: createdItem.type,
					size: createdItem.size,
					lastModified: new Date().toISOString(),
				},
				...mediaLibraryItems.value.filter((item) => item.key !== createdItem.path),
			]
		}
	} catch (error) {
		errorMessage.value = error instanceof Error ? error.message : 'Не удалось загрузить медиа'
	} finally {
		uploading.value = false
		;(event.target as HTMLInputElement).value = ''
	}
}

function isMediaAdded(item: AdminMediaLibraryItem) {
	return draft.value.media.some((media) => media.path === item.key)
}

function addMediaFromLibrary(item: AdminMediaLibraryItem) {
	if (isMediaAdded(item)) return
	draft.value.media.push({
		type: item.type,
		path: item.key,
		url: item.url,
		name: item.name,
		size: item.size,
		width: null,
		height: null,
		durationSeconds: null,
	})
}

function removeMedia(index: number) {
	draft.value.media.splice(index, 1)
}

async function openMediaLibrary() {
	mediaLibraryOpen.value = true
	if (mediaLibraryItems.value.length === 0) {
		await loadMediaLibrary()
	}
}

async function publishPost() {
	resetMessages()
	publishing.value = true

	const payload = {
		audience: draft.value.audience,
		content: draft.value.content.trim(),
		buttonLabel: draft.value.buttonLabel.trim() || null,
		buttonUrl: draft.value.buttonUrl.trim() || null,
		notifyAll: draft.value.notifyAll,
		media: draft.value.media,
	}

	const res = await api.post<FeedPostItem>('/api/admin/feed-posts', payload)
	if (res.success) {
		if (selectedDraftId.value) {
			await api.delete<{ deleted: true }>(`/api/admin/feed-drafts/${selectedDraftId.value}`)
		}
		successMessage.value = payload.notifyAll
			? 'Пост опубликован и push-уведомления отправлены.'
			: 'Пост опубликован без push-уведомления.'
		resetEditor(activeAudience.value)
		await Promise.all([loadPosts(), loadDrafts(activeAudience.value)])
	} else {
		errorMessage.value = res.error.message
	}

	publishing.value = false
}

async function deletePost(id: number) {
	resetMessages()
	const res = await api.delete<{ deleted: true }>(`/api/admin/feed-posts/${id}`)
	if (res.success) {
		posts.value = posts.value.filter((item) => item.id !== id)
		successMessage.value = 'Пост удалён.'
	} else {
		errorMessage.value = res.error.message
	}
}

onMounted(() => {
	if (import.meta.client) {
		void import('emoji-picker-element')
		document.addEventListener('click', onDocumentClick)
	}
	resetEditor(activeAudience.value)
	void Promise.all([loadPosts(), loadDrafts(activeAudience.value)])
})

onUnmounted(() => {
	if (import.meta.client) {
		document.removeEventListener('click', onDocumentClick)
	}
})
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-wrap items-end justify-between gap-4">
			<div>
				<h1 class="text-2xl font-bold text-gray-900 dark:text-white">Лента новостей</h1>
			</div>
			<div class="flex gap-2">
					<button
						v-for="audience in ['club'] as FeedSection[]"
					:key="audience"
					class="btn-secondary"
					:class="activeAudience === audience ? '!border-amber-400/40 !bg-amber-500/10 !text-amber-700 dark:!text-amber-300' : ''"
					@click="activeAudience = audience"
				>
					{{ FEED_AUDIENCES[audience] }}
				</button>
			</div>
		</div>

		<div v-if="errorMessage" class="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-300">
			{{ errorMessage }}
		</div>
		<div v-if="successMessage" class="mb-4 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300">
			{{ successMessage }}
		</div>

		<div class="grid gap-6 xl:grid-cols-[minmax(0,1.08fr)_minmax(360px,0.92fr)]">
			<section class="glass rounded-[30px] p-5">
				<div class="mb-5 flex items-center justify-between gap-3">
					<div>
						<h2 class="text-lg font-semibold text-gray-900 dark:text-white">Редактор</h2>
						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
							{{ selectedDraftId ? `Редактируете черновик #${selectedDraftId}` : 'Новый черновик' }}
						</p>
					</div>
				</div>

				<div class="space-y-4">
					<div class="float-label">
						<label>Для кого пост</label>
						<select v-model="activeAudience" class="glass-input">
							<option value="club">Участники</option>
						</select>
					</div>

					<div class="rounded-3xl border border-gray-200/70 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]">
						<div class="mb-3 flex flex-wrap items-center gap-2">
							<button type="button" class="btn-secondary !px-3 !py-2" @click="wrapSelection('strong')"><strong>Ж</strong></button>
							<button type="button" class="btn-secondary !px-3 !py-2 italic" @click="wrapSelection('em')">К</button>
							<button type="button" class="btn-secondary !px-3 !py-2 underline" @click="wrapSelection('u')">Ч</button>
							<button type="button" class="btn-secondary !px-3 !py-2 line-through" @click="wrapSelection('s')">З</button>
							<div class="mx-1 h-6 w-px bg-gray-200 dark:bg-white/10" />
							<div ref="emojiPickerAnchorRef" class="relative">
								<button
									type="button"
									class="btn-secondary !px-3 !py-2"
									@click.stop="toggleEmojiPicker"
								>
									😊
								</button>
								<ClientOnly>
									<div
										v-if="showEmojiPicker"
										class="absolute left-0 top-[calc(100%+10px)] z-20 overflow-hidden rounded-[26px] border border-gray-200/80 bg-white shadow-[0_20px_60px_rgba(15,23,42,0.18)] dark:border-white/10 dark:bg-[#111019]"
									>
										<emoji-picker
											class="admin-emoji-picker"
											locale="ru"
											@emoji-click="onEmojiPickerSelect"
										/>
									</div>
								</ClientOnly>
							</div>
						</div>
						<textarea
							ref="editorRef"
							v-model="draft.content"
							rows="10"
							class="min-h-[220px] w-full resize-y rounded-2xl border border-gray-200/80 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition focus:border-primary-400 dark:border-white/10 dark:bg-black/20 dark:text-white"
							placeholder="Текст поста. Эмодзи вставляются прямо сюда, ссылки становятся кликабельными автоматически."
						/>
					</div>

					<div class="grid gap-4 md:grid-cols-2">
						<div class="float-label">
							<label>Подпись кнопки</label>
							<input v-model="draft.buttonLabel" class="glass-input" maxlength="80" placeholder="Например: Открыть запись" />
						</div>
						<div class="float-label">
							<label>Ссылка кнопки</label>
							<input v-model="draft.buttonUrl" class="glass-input" placeholder="https://..." />
						</div>
					</div>

					<div class="rounded-3xl border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
						<div class="flex flex-wrap items-center justify-between gap-3">
							<div>
								<p class="text-sm font-medium text-gray-900 dark:text-white">Медиа</p>
								<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
									Можно загрузить новый файл или выбрать уже существующий из медиатеки.
								</p>
							</div>
							<div class="flex flex-wrap gap-2">
								<button type="button" class="btn-secondary" @click="openMediaLibrary">
									Выбрать из медиатеки
								</button>
								<label class="btn-secondary cursor-pointer">
									<input type="file" class="hidden" accept="image/*,video/*" multiple @change="uploadMedia" />
									{{ uploading ? 'Загрузка...' : 'Загрузить новое' }}
								</label>
							</div>
						</div>
						<div v-if="draft.media.length" class="mt-4 grid gap-3 sm:grid-cols-2">
							<div
								v-for="(item, index) in draft.media"
								:key="`${item.path}-${index}`"
								class="overflow-hidden rounded-[26px] border border-gray-200/80 bg-white dark:border-white/10 dark:bg-black/20"
							>
								<div class="relative aspect-[4/3] overflow-hidden bg-gray-100 dark:bg-white/[0.04]">
									<img
										v-if="item.type === 'image'"
										:src="item.url || item.path"
										:alt="item.name || 'Изображение'"
										class="h-full w-full object-cover"
									/>
									<video
										v-else
										:src="item.url || item.path"
										class="h-full w-full object-cover"
										muted
										playsinline
										preload="metadata"
									/>
									<div class="absolute left-3 top-3 rounded-full border border-black/10 bg-white/90 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-gray-700 dark:border-white/10 dark:bg-black/65 dark:text-white/80">
										{{ item.type === 'video' ? 'Видео' : 'Изображение' }}
									</div>
								</div>
								<div class="space-y-1 px-4 py-3">
									<p class="truncate text-sm font-medium text-gray-900 dark:text-white">
										{{ item.name || item.path }}
									</p>
									<p class="text-xs text-gray-500 dark:text-gray-400">
										<span v-if="item.width && item.height">{{ item.width }}×{{ item.height }}</span>
										<span v-if="item.width && item.height && item.size"> · </span>
										<span v-if="item.size">{{ formatSize(item.size) }}</span>
									</p>
								</div>
								<div class="border-t border-gray-200/70 px-4 py-3 dark:border-white/10">
									<button type="button" class="text-sm font-medium text-red-500" @click="removeMedia(index)">
										Удалить
									</button>
								</div>
							</div>
						</div>
					</div>

					<label class="flex items-center gap-3 text-sm text-gray-700 dark:text-gray-300">
						<input v-model="draft.notifyAll" type="checkbox" class="glass-check" />
						<span>Уведомлять всех push-уведомлением</span>
					</label>

					<div class="flex flex-wrap gap-3">
						<button type="button" class="btn-secondary" @click="saveDraft">Сохранить черновик</button>
						<button type="button" class="btn-secondary" @click="createNewDraft">Новый</button>
						<button type="button" class="btn-secondary" @click="deleteSelectedDraft">
							{{ selectedDraftId ? 'Удалить черновик' : 'Очистить редактор' }}
						</button>
						<button type="button" class="btn-primary" :disabled="publishing || !draft.content.trim()" @click="publishPost">
							{{ publishing ? 'Публикую...' : 'Опубликовать' }}
						</button>
					</div>
				</div>
			</section>

			<section class="space-y-6">
				<div class="glass rounded-[30px] p-5">
					<div class="mb-4 flex items-start justify-between gap-4">
						<div>
							<h2 class="text-lg font-semibold text-gray-900 dark:text-white">Предпросмотр</h2>
							<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Пост выглядит так же, как и в приложении.</p>
						</div>
						<p
							v-if="previewTimestamp"
							class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500"
						>
							Черновик: {{ formatDate(previewTimestamp) }}
						</p>
					</div>
					<div
						v-if="previewIsEmpty"
						class="rounded-[28px] border border-dashed border-gray-200/80 bg-white/55 px-5 py-10 text-center text-sm text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-400"
					>
						<div class="mx-auto flex min-h-[220px] max-w-xl flex-col items-center justify-center rounded-[24px] border border-dashed border-gray-200/80 bg-white/80 px-6 py-10 dark:border-white/10 dark:bg-black/20">
							<p class="text-sm font-semibold text-gray-800 dark:text-white/85">Предпросмотр пока пуст</p>
							<p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
								Начните вводить текст, добавьте медиа или кнопку, и здесь сразу появится карточка поста.
							</p>
						</div>
					</div>
					<AdminFeedPostPreview v-else :key="previewKey" :item="previewItem" />
				</div>

				<div class="glass rounded-[30px] p-5">
					<div class="mb-4 flex items-start justify-between gap-3">
						<div>
							<h2 class="text-lg font-semibold text-gray-900 dark:text-white">Черновики</h2>
							<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Сохраняются вручную. Сверху свежие.</p>
						</div>
						<span class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">
							{{ FEED_AUDIENCES[activeAudience] }}
						</span>
					</div>

					<div v-if="draftsLoading" class="py-8 text-center text-sm text-gray-500 dark:text-gray-400">
						Загружаю черновики...
					</div>
					<div
						v-else-if="drafts.length === 0"
						class="rounded-[28px] border border-dashed border-gray-200/80 bg-white/55 px-5 py-10 text-center text-sm text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-400"
					>
						Для этого раздела черновиков пока нет.
					</div>
					<div v-else class="space-y-3">
						<button
							v-for="item in drafts"
							:key="item.id"
							type="button"
							class="w-full rounded-[24px] border px-4 py-4 text-left transition"
							:class="
								selectedDraftId === item.id
									? 'border-amber-300/50 bg-amber-500/10'
									: 'border-gray-200/80 bg-white hover:border-amber-200/70 hover:bg-amber-50/50 dark:border-white/10 dark:bg-white/[0.03] dark:hover:bg-white/[0.05]'
							"
							@click="loadDraftIntoEditor(item.id)"
						>
							<div class="flex items-start justify-between gap-3">
								<div class="min-w-0 flex-1">
									<p class="truncate text-sm font-semibold text-gray-900 dark:text-white">
										{{ buildFeedExcerpt(item.content, 88) || 'Черновик без текста' }}
									</p>
									<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
										{{ formatDate(item.updatedAt) }}
										<span v-if="item.media.length"> · медиа: {{ item.media.length }}</span>
										<span v-if="item.buttonLabel"> · кнопка</span>
									</p>
								</div>
								<span
									v-if="selectedDraftId === item.id"
									class="rounded-full border border-amber-300/40 bg-amber-500/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-amber-700 dark:text-amber-300"
								>
									Открыт
								</span>
							</div>
						</button>
					</div>
				</div>

				<div class="glass rounded-[30px] p-5">
					<div class="mb-4 flex items-center justify-between gap-3">
						<div>
							<h2 class="text-lg font-semibold text-gray-900 dark:text-white">Опубликованные посты</h2>
							<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Сверху свежие, ниже более старые.</p>
						</div>
					</div>

					<div v-if="loading" class="py-8 text-center text-sm text-gray-500 dark:text-gray-400">
						Загружаю посты...
					</div>
					<div v-else-if="posts.length === 0" class="rounded-3xl border border-dashed border-gray-200 px-4 py-8 text-center text-sm text-gray-500 dark:border-white/10 dark:text-gray-400">
						Для этого раздела постов пока нет.
					</div>
					<div v-else class="space-y-4">
						<div v-for="item in posts" :key="item.id" class="space-y-3">
							<div class="flex items-center justify-between gap-3">
								<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">
									ID {{ item.id }} · {{ FEED_AUDIENCES[item.audience] }}
								</p>
								<button type="button" class="text-sm text-red-500" @click="deletePost(item.id)">Удалить</button>
							</div>
							<AdminFeedPostPreview :item="item" />
						</div>

						<div class="flex justify-center">
							<button
								v-if="nextCursor"
								type="button"
								class="btn-secondary"
								:disabled="loadingMore"
								@click="loadPosts({ append: true })"
							>
								{{ loadingMore ? 'Загрузка...' : 'Показать ещё' }}
							</button>
						</div>
					</div>
				</div>
			</section>
		</div>

		<Teleport to="body">
			<Transition name="backdrop">
				<div
					v-if="mediaLibraryOpen"
					class="fixed inset-0 z-40 bg-black/55 backdrop-blur-sm"
					@click="mediaLibraryOpen = false"
				/>
			</Transition>
			<Transition name="modal">
				<div
					v-if="mediaLibraryOpen"
					class="fixed inset-0 z-50 flex items-center justify-center p-4"
				>
					<div class="pointer-events-auto flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-[32px] border border-gray-200/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.98),rgba(248,250,252,0.98))] shadow-[0_28px_120px_rgba(15,23,42,0.24)] dark:border-white/10 dark:bg-[linear-gradient(180deg,rgba(17,24,39,0.98),rgba(8,10,15,0.98))]">
						<div class="flex items-start justify-between gap-4 border-b border-gray-200/70 px-6 py-5 dark:border-white/10">
							<div>
								<h2 class="text-xl font-semibold text-gray-900 dark:text-white">Медиатека</h2>
								<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
									Выбирайте изображения и видео из медиатеки без повторной загрузки.
								</p>
							</div>
							<button type="button" class="btn-secondary" @click="mediaLibraryOpen = false">Закрыть</button>
						</div>

						<div class="flex-1 overflow-auto px-6 py-5">
							<div v-if="mediaLibraryLoading" class="py-10 text-center text-sm text-gray-500 dark:text-gray-400">
								Загружаю медиатеку...
							</div>
							<div v-else-if="mediaLibraryItems.length === 0" class="rounded-3xl border border-dashed border-gray-200 px-4 py-10 text-center text-sm text-gray-500 dark:border-white/10 dark:text-gray-400">
								В медиатеке пока нет изображений или видео.
							</div>
							<div v-else class="space-y-5">
								<div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
									<div
										v-for="item in mediaLibraryItems"
										:key="item.key"
										class="overflow-hidden rounded-[28px] border border-gray-200/80 bg-white shadow-[0_20px_50px_rgba(15,23,42,0.08)] dark:border-white/10 dark:bg-black/20 dark:shadow-none"
									>
										<div class="relative aspect-[4/3] overflow-hidden bg-gray-100 dark:bg-white/[0.04]">
											<img
												v-if="item.type === 'image'"
												:src="item.url"
												:alt="item.name"
												class="h-full w-full object-cover"
											/>
											<video
												v-else
												:src="item.url"
												class="h-full w-full object-cover"
												muted
												playsinline
												preload="metadata"
											/>
											<div class="absolute left-3 top-3 rounded-full border border-black/10 bg-white/90 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-gray-700 dark:border-white/10 dark:bg-black/65 dark:text-white/80">
												{{ item.type === 'video' ? 'Видео' : 'Изображение' }}
											</div>
										</div>
										<div class="space-y-2 px-4 py-4">
											<p class="truncate text-sm font-medium text-gray-900 dark:text-white">{{ item.name }}</p>
											<p class="text-xs text-gray-500 dark:text-gray-400">
												{{ formatDate(item.lastModified) }}
												<span v-if="item.size"> · {{ formatSize(item.size) }}</span>
											</p>
										</div>
										<div class="flex items-center justify-between border-t border-gray-200/70 px-4 py-3 dark:border-white/10">
											<p class="truncate text-xs text-gray-400 dark:text-gray-500">{{ item.key }}</p>
											<button
												type="button"
												class="rounded-full border px-3 py-1.5 text-sm transition"
												:class="isMediaAdded(item) ? 'border-emerald-300/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' : 'border-amber-300/40 bg-amber-500/10 text-amber-700 hover:bg-amber-500/15 dark:text-amber-300'"
												@click="addMediaFromLibrary(item)"
											>
												{{ isMediaAdded(item) ? 'Уже добавлено' : 'Добавить' }}
											</button>
										</div>
									</div>
								</div>

								<div class="flex justify-center">
									<button
										v-if="mediaLibraryCursor"
										type="button"
										class="btn-secondary"
										:disabled="mediaLibraryLoadingMore"
										@click="loadMediaLibrary({ append: true })"
									>
										{{ mediaLibraryLoadingMore ? 'Загрузка...' : 'Показать ещё' }}
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</Transition>
		</Teleport>
	</div>
</template>

<style scoped>
.backdrop-enter-active,
.backdrop-leave-active {
	transition: opacity 0.2s ease;
}

.backdrop-enter-from,
.backdrop-leave-to {
	opacity: 0;
}

.modal-enter-active {
	transition:
		opacity 0.22s ease,
		transform 0.22s ease;
}

.modal-leave-active {
	transition:
		opacity 0.18s ease,
		transform 0.18s ease;
}

.modal-enter-from,
.modal-leave-to {
	opacity: 0;
	transform: translateY(12px) scale(0.985);
}

:deep(.admin-emoji-picker) {
	--border-color: rgba(255, 255, 255, 0.08);
	--background: #111019;
	--input-border-color: rgba(255, 255, 255, 0.08);
	--input-background: rgba(255, 255, 255, 0.04);
	--input-font-color: rgba(255, 255, 255, 0.86);
	--category-font-color: rgba(255, 255, 255, 0.46);
	--emoji-size: 1.32rem;
	--num-columns: 8;
	height: 420px;
	width: 352px;
}
</style>
