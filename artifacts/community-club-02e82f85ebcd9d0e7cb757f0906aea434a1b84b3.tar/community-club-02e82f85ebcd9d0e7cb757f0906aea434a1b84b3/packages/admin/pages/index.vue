<script setup lang="ts">
import { defineAsyncComponent } from 'vue'

const AdminLineChart = defineAsyncComponent(
	() => import('~/components/charts/LineChart.client.vue'),
)

interface Stats {
	totalUsers: number
	totalPaymentBase: number
	activePaidSubscribers: number
	members: {
		monthRenewal: number
		ninetyDays: number
		year: number
		activePaidTotal: number
		activeTotal: number
	}
	payments: {
		rfActive: number
		foreignActive: number
		autopayActive: number
		manualActive: number
	}
	formerMembers: {
		total: number
	}
	monthRevenue: number
	totalSales: number
	metrics: {
		revenueGrowthPercent: number
		retention30Days: number
		dau: number
		dauGrowthPercent: number
		averageCheck: number
		averageCheckGrowthPercent: number
		newUsers30Days: number
		newUsersGrowthPercent: number
		payments30Days: number
		paymentsGrowthPercent: number
	}
	cohortRetention: Array<{
		cohort: string
		base: number
		day1: number | null
		day7: number | null
		day14: number | null
		day30: number | null
	}>
	charts: {
		registrations: Array<{ day: string; count: number }>
		revenue: Array<{ day: string; total: number }>
		averageCheck: Array<{ day: string; average: number }>
		dailyActive: Array<{ day: string; count: number }>
		logins: Array<{ day: string; memberCount: number; nonMemberCount: number }>
	}
	unfinishedOrders: number
}

type KpiCard = {
	label: string
	value: string
	delta?: number
	deltaText?: string
	values: number[]
	color: string
	mode: 'line' | 'bars'
}

const api = useAdminApi()
const stats = ref<Stats | null>(null)
const salesFrom = ref('')
const salesTo = ref('')
const salesResult = ref<{ count: number; total: number } | null>(null)
const salesLoading = ref(false)

const kpiCards = computed<KpiCard[]>(() => {
	if (!stats.value) return []
	const revenueValues = stats.value.charts.revenue.map((item) => item.total)
	const registrationValues = stats.value.charts.registrations.map((item) => item.count)
	const cumulativeRevenueValues = cumulativeValues(revenueValues)
	const cumulativeUserValues = cumulativeUsers(registrationValues, stats.value.totalUsers)
	const retentionValues = stats.value.cohortRetention
		.map((item) => item.day30)
		.filter((value): value is number => value != null)
	const activeValues = stats.value.charts.dailyActive.map((item) => item.count)
	const averageCheckValues = stats.value.charts.averageCheck.map((item) => item.average)

	return [
		{
			label: 'Прирост выручки',
			value: formatMoney(stats.value.monthRevenue),
			delta: stats.value.metrics.revenueGrowthPercent,
			values: cumulativeRevenueValues,
			color: '#60a5fa',
			mode: 'line',
		},
		{
			label: 'Ретеншн (30 дней)',
			value: `${fmt(stats.value.metrics.retention30Days)}%`,
			deltaText: 'по когортам',
			values: retentionValues.length ? retentionValues : [stats.value.metrics.retention30Days],
			color: '#86efac',
			mode: 'line',
		},
		{
			label: 'Пользователи',
			value: fmt(stats.value.totalUsers),
			deltaText: `+ ${fmt(stats.value.metrics.newUsers30Days)} новых`,
			values: cumulativeUserValues,
			color: '#3b82f6',
			mode: 'bars',
		},
		{
			label: 'Активные пользователи (DAU)',
			value: fmt(stats.value.metrics.dau),
			delta: stats.value.metrics.dauGrowthPercent,
			values: activeValues,
			color: '#8b5cf6',
			mode: 'line',
		},
		{
			label: 'Средний чек',
			value: formatMoney(stats.value.metrics.averageCheck),
			delta: stats.value.metrics.averageCheckGrowthPercent,
			values: averageCheckValues,
			color: '#f472b6',
			mode: 'line',
		},
	]
})

const paymentCards = computed(() => {
	if (!stats.value) return []
	return [
		{ label: 'РФ карты', value: stats.value.payments.rfActive, tone: 'text-white' },
		{ label: 'Зарубежные', value: stats.value.payments.foreignActive, tone: 'text-white' },
		{
			label: 'С автосписанием',
			value: stats.value.payments.autopayActive,
			tone: 'text-emerald-300',
		},
		{
			label: 'Без автосписания',
			value: stats.value.payments.manualActive,
			tone: 'text-orange-300',
		},
	]
})

const tariffStats = computed(() => {
	if (!stats.value) return null
	return stats.value.members
})

onMounted(async () => {
	const res = await api.get<Stats>('/api/admin/stats')
	if (res.success) stats.value = res.data
})

async function filterSales() {
	if (!salesFrom.value || !salesTo.value) return
	salesLoading.value = true
	const res = await api.get<{ count: number; total: number }>(
		`/api/admin/stats/sales-filter?from=${salesFrom.value}&to=${salesTo.value}`,
	)
	if (res.success) salesResult.value = res.data
	salesLoading.value = false
}

const registrationChartData = computed(() => {
	const data = stats.value?.charts.registrations ?? []
	return {
		labels: data.map((d) => d.day.slice(5)),
		datasets: [
			{
				label: 'Регистрации',
				data: data.map((d) => d.count),
				borderColor: '#f472b6',
				backgroundColor: 'rgba(244, 114, 182, 0.14)',
				fill: true,
				tension: 0.35,
			},
		],
	}
})

const loginChartData = computed(() => {
	const data = stats.value?.charts.logins ?? []
	return {
		labels: data.map((d) => d.day.slice(5)),
		datasets: [
			{
				label: 'Участники',
				data: data.map((d) => d.memberCount),
				borderColor: '#34d399',
				backgroundColor: 'rgba(52, 211, 153, 0.14)',
				fill: true,
				tension: 0.35,
			},
			{
				label: 'Не участники',
				data: data.map((d) => d.nonMemberCount),
				borderColor: '#f87171',
				backgroundColor: 'rgba(248, 113, 113, 0.14)',
				fill: true,
				tension: 0.35,
			},
		],
	}
})

const revenueChartData = computed(() => {
	const data = stats.value?.charts.revenue ?? []
	const totals = cumulativeValues(data.map((d) => d.total))
	return {
		labels: data.map((d) => d.day.slice(5)),
		datasets: [
			{
				label: 'Выручка накопительно, ₽',
				data: totals,
				borderColor: '#34d399',
				backgroundColor: 'rgba(52, 211, 153, 0.14)',
				fill: true,
				tension: 0.35,
			},
		],
	}
})

const userGrowthBars = computed(() => {
	if (!stats.value) return []
	const values = cumulativeUsers(
		stats.value.charts.registrations.map((bar) => bar.count),
		stats.value.totalUsers,
	)
	return stats.value.charts.registrations.map((bar, index) => ({
		day: bar.day,
		count: values[index] ?? 0,
	}))
})
const userGrowthValues = computed(() => userGrowthBars.value.map((bar) => bar.count))

const chartOptions = {
	responsive: true,
	maintainAspectRatio: false,
	plugins: { legend: { display: false } },
	scales: {
		x: { grid: { color: 'rgba(148, 163, 184, 0.08)' }, ticks: { color: '#94a3b8' } },
		y: {
			beginAtZero: true,
			grid: { color: 'rgba(148, 163, 184, 0.08)' },
			ticks: { color: '#94a3b8' },
		},
	},
}

const chartOptionsWithLegend = {
	responsive: true,
	maintainAspectRatio: false,
	plugins: {
		legend: {
			display: true,
			position: 'top' as const,
			labels: { color: '#94a3b8', boxWidth: 12, padding: 12 },
		},
	},
	scales: {
		x: { grid: { color: 'rgba(148, 163, 184, 0.08)' }, ticks: { color: '#94a3b8' } },
		y: {
			beginAtZero: true,
			grid: { color: 'rgba(148, 163, 184, 0.08)' },
			ticks: { color: '#94a3b8' },
		},
	},
}

function fmt(n: number | undefined) {
	return n != null ? Number(n).toLocaleString('ru') : '—'
}

function formatMoney(n: number | undefined) {
	const value = Number(n ?? 0)
	if (value >= 1_000_000) {
		return `${(value / 1_000_000).toLocaleString('ru', { maximumFractionDigits: 1 })} млн ₽`
	}
	return `${fmt(value)} ₽`
}

function deltaClass(value: number | undefined) {
	if (!value) return 'text-slate-500'
	return value > 0 ? 'text-emerald-300' : 'text-rose-300'
}

function deltaLabel(value: number | undefined) {
	if (!value) return '0%'
	return `${value > 0 ? '↑' : '↓'} ${Math.abs(value)}%`
}

function cumulativeValues(values: number[]) {
	let total = 0
	return values.map((value) => {
		total += value
		return total
	})
}

function cumulativeUsers(registrations: number[], totalUsers: number) {
	let total = Math.max(0, totalUsers - registrations.reduce((sum, value) => sum + value, 0))
	return registrations.map((value) => {
		total += value
		return total
	})
}

function sparklinePath(values: number[]) {
	if (!values.length) return ''
	const max = Math.max(...values, 1)
	const min = Math.min(...values)
	const range = max - min || 1

	return values
		.map((value, index) => {
			const x = values.length === 1 ? 80 : (index / (values.length - 1)) * 160
			const y = 44 - ((value - min) / range) * 36
			return `${index === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`
		})
		.join(' ')
}

function barHeight(value: number, values: number[]) {
	const max = Math.max(...values, 1)
	return `${Math.max(8, Math.round((value / max) * 44))}px`
}

function tallBarHeight(value: number, values: number[]) {
	const max = Math.max(...values, 1)
	return `${Math.max(8, Math.round((value / max) * 220))}px`
}
</script>

<template>
	<div class="admin-dashboard-page space-y-6 p-4 sm:p-6">
		<div class="space-y-2">
			<p class="text-xs uppercase tracking-[0.28em] text-slate-500">Analytics</p>
			<h1 class="text-2xl font-semibold text-white">Подписки и жизненный цикл клуба</h1>
		</div>

		<div class="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
			<div
				v-for="card in kpiCards"
				:key="card.label"
				class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-5 shadow-[0_24px_60px_rgba(0,0,0,0.28)]"
			>
				<div class="flex items-center justify-between gap-3">
					<p class="admin-metric-label text-slate-500">{{ card.label }}</p>
					<span class="h-4 w-4 rounded-full border border-white/10 text-center text-[10px] leading-4 text-slate-500">i</span>
				</div>
				<p class="mt-3 text-[1.65rem] font-semibold leading-tight text-white">{{ card.value }}</p>
				<p class="mt-2 text-sm font-semibold" :class="deltaClass(card.delta)">
					{{ card.deltaText ?? deltaLabel(card.delta) }}
				</p>
				<div class="dashboard-chart-box mt-4 h-12">
					<div v-if="card.mode === 'bars'" class="flex h-12 w-full min-w-0 items-end gap-[2px] overflow-hidden">
						<span
							v-for="(value, index) in card.values"
							:key="`${card.label}-${index}`"
							class="flex-1 rounded-t bg-blue-500/75"
							:style="{ height: barHeight(value, card.values) }"
						/>
					</div>
					<svg v-else viewBox="0 0 160 48" class="h-12 w-full overflow-hidden">
						<path
							:d="sparklinePath(card.values)"
							fill="none"
							:stroke="card.color"
							stroke-width="3"
							stroke-linecap="round"
							stroke-linejoin="round"
							opacity="0.9"
						/>
					</svg>
				</div>
			</div>
		</div>

		<div class="grid gap-6 xl:grid-cols-[1.05fr_0.95fr_1fr]">
			<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)] xl:col-span-1">
				<div class="flex items-start justify-between gap-4">
					<div>
						<p class="admin-metric-label text-slate-500">Выручка</p>
						<h2 class="mt-2 text-xl font-semibold text-white">{{ formatMoney(stats?.monthRevenue) }}</h2>
						<p class="mt-2 text-sm font-semibold" :class="deltaClass(stats?.metrics.revenueGrowthPercent)">
							{{ deltaLabel(stats?.metrics.revenueGrowthPercent) }} к прошлым 30 дням
						</p>
					</div>
				</div>
				<div class="dashboard-chart-box mt-5 h-64">
					<AdminLineChart v-if="stats" :data="revenueChartData" :options="chartOptions" />
				</div>
			</section>

			<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
				<div class="flex items-start justify-between gap-4">
					<div>
						<p class="admin-metric-label text-slate-500">Ретеншн по когортам</p>
						<h2 class="mt-2 text-xl font-semibold text-white">{{ fmt(stats?.metrics.retention30Days) }}%</h2>
					</div>
					<p class="text-sm font-semibold text-slate-400">30 дней</p>
				</div>
				<div class="mt-5 overflow-x-auto">
					<table class="w-full table-fixed border-separate border-spacing-0 text-xs sm:text-sm">
						<thead>
							<tr class="text-left text-xs uppercase tracking-[0.12em] text-slate-500">
								<th class="w-[38%] pb-3 font-semibold">Когорта</th>
								<th class="pb-3 text-right font-semibold">Д1</th>
								<th class="pb-3 text-right font-semibold">Д7</th>
								<th class="pb-3 text-right font-semibold">Д14</th>
								<th class="pb-3 text-right font-semibold">Д30</th>
							</tr>
						</thead>
						<tbody>
							<tr v-for="row in stats?.cohortRetention ?? []" :key="row.cohort" class="text-slate-200">
								<td class="border-t border-white/8 py-3 pr-3 text-slate-400">{{ row.cohort }}</td>
								<td class="border-t border-white/8 py-3 text-right">{{ fmt(row.day1 ?? undefined) }}%</td>
								<td class="border-t border-white/8 py-3 text-right">{{ row.day7 == null ? '—' : `${fmt(row.day7)}%` }}</td>
								<td class="border-t border-white/8 py-3 text-right">{{ row.day14 == null ? '—' : `${fmt(row.day14)}%` }}</td>
								<td class="border-t border-white/8 py-3 text-right">{{ row.day30 == null ? '—' : `${fmt(row.day30)}%` }}</td>
							</tr>
							<tr v-if="!stats?.cohortRetention.length">
								<td colspan="5" class="border-t border-white/8 py-8 text-center text-sm text-slate-500">Пока нет когорт.</td>
							</tr>
						</tbody>
					</table>
				</div>
			</section>

			<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
				<div class="flex items-start justify-between gap-4">
					<div>
						<p class="admin-metric-label text-slate-500">Рост пользователей</p>
						<h2 class="mt-2 text-xl font-semibold text-white">{{ fmt(stats?.totalUsers) }}</h2>
						<p class="mt-2 text-sm font-semibold text-emerald-300">
							+ {{ fmt(stats?.metrics.newUsers30Days) }} новых
						</p>
					</div>
				</div>
				<div class="dashboard-chart-box mt-6 flex h-64 items-end gap-[3px] border-b border-l border-white/8 px-3 pb-3">
					<span
						v-for="item in userGrowthBars"
						:key="item.day"
						class="min-w-[3px] flex-1 rounded-t bg-blue-500/75"
						:style="{ height: tallBarHeight(item.count, userGrowthValues) }"
					/>
				</div>
			</section>
		</div>

		<div>
			<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-emerald-500/12 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
				<div class="flex items-start justify-between gap-4">
					<div>
						<p class="admin-metric-label text-emerald-300/80">Участники</p>
						<h2 class="mt-2 text-xl font-semibold text-white">Активные тарифы</h2>
					</div>
					<p class="text-right text-sm text-slate-400">
						Платных: <span class="font-semibold text-emerald-300">{{ fmt(tariffStats?.activePaidTotal) }}</span><br>
						Всего: <span class="font-semibold text-white">{{ fmt(tariffStats?.activeTotal) }}</span>
					</p>
				</div>
				<div class="mt-5 grid gap-3 sm:grid-cols-3">
					<div class="w-full min-w-0 overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-4">
						<p class="admin-metric-label text-slate-500">1 месяц продление</p>
						<p class="mt-2 text-2xl font-semibold text-white">{{ fmt(tariffStats?.monthRenewal) }}</p>
					</div>
					<div class="w-full min-w-0 overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-4">
						<p class="admin-metric-label text-slate-500">90 дней</p>
						<p class="mt-2 text-2xl font-semibold text-white">{{ fmt(tariffStats?.ninetyDays) }}</p>
					</div>
					<div class="w-full min-w-0 overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-4">
						<p class="admin-metric-label text-slate-500">12 месяцев</p>
						<p class="mt-2 text-2xl font-semibold text-white">{{ fmt(tariffStats?.year) }}</p>
					</div>
				</div>
			</section>
		</div>

		<div class="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
			<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
				<p class="admin-metric-label text-slate-500">Оплаты и автопродление</p>
				<h2 class="mt-2 text-xl font-semibold text-white">Структура активных оплат</h2>
				<div class="mt-5 grid gap-3 sm:grid-cols-2 2xl:grid-cols-4">
					<div
						v-for="card in paymentCards"
						:key="card.label"
						class="w-full min-w-0 overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-4"
					>
						<p class="admin-metric-label text-slate-500">{{ card.label }}</p>
						<p class="mt-2 text-2xl font-semibold" :class="card.tone">{{ fmt(card.value) }}</p>
					</div>
				</div>
				<div class="mt-5 grid gap-3 sm:grid-cols-2">
					<div class="w-full min-w-0 overflow-hidden rounded-2xl border border-emerald-500/12 bg-emerald-500/[0.05] p-4">
						<p class="admin-metric-label text-emerald-200/80">Выручка за 30 дней</p>
						<p class="mt-2 text-2xl font-semibold text-emerald-300">
							{{ stats ? formatMoney(stats.monthRevenue) : '—' }}
						</p>
					</div>
					<div class="w-full min-w-0 overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-4">
						<p class="admin-metric-label text-slate-500">Всего продаж</p>
						<p class="mt-2 text-2xl font-semibold text-white">
							{{ stats ? formatMoney(stats.totalSales) : '—' }}
						</p>
					</div>
				</div>
			</section>

			<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-rose-500/12 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
				<p class="admin-metric-label text-rose-300/80">Отток</p>
				<h2 class="mt-2 text-xl font-semibold text-white">Бывшие участники</h2>
				<div class="mt-5 space-y-3">
					<div class="w-full min-w-0 overflow-hidden rounded-2xl border border-white/8 bg-white/[0.03] p-4">
						<p class="admin-metric-label text-slate-500">Всего бывших</p>
						<p class="mt-2 text-2xl font-semibold text-rose-300">{{ fmt(stats?.formerMembers.total) }}</p>
					</div>
				</div>
			</section>
		</div>

		<div class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
			<h3 class="text-lg font-semibold text-white">Продажи по периоду</h3>
			<div class="mt-4 flex flex-wrap items-end gap-3">
				<div class="float-label">
					<input v-model="salesFrom" type="date" class="glass-input !w-auto" />
					<label>От</label>
				</div>
				<div class="float-label">
					<input v-model="salesTo" type="date" class="glass-input !w-auto" />
					<label>До</label>
				</div>
				<button class="btn-primary" :disabled="!salesFrom || !salesTo || salesLoading" @click="filterSales">
					{{ salesLoading ? 'Загрузка...' : 'Показать' }}
				</button>
			</div>
			<div v-if="salesResult" class="mt-4 flex flex-wrap gap-6 text-sm text-slate-300">
				<span>Количество: <strong class="text-white">{{ salesResult.count }}</strong></span>
				<span>Сумма: <strong class="text-white">{{ fmt(salesResult.total) }} ₽</strong></span>
			</div>
		</div>

<div class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
				<h3 class="text-lg font-semibold text-white">Регистрации за 30 дней</h3>
				<div class="dashboard-chart-box mt-5 h-56">
					<AdminLineChart v-if="stats" :data="registrationChartData" :options="chartOptions" />
				</div>
			</div>

			<div class="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
				<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-white/8 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
					<h3 class="text-lg font-semibold text-white">Входы за 30 дней</h3>
					<div class="dashboard-chart-box mt-5 h-56">
						<AdminLineChart v-if="stats" :data="loginChartData" :options="chartOptionsWithLegend" />
					</div>
					<div class="mt-2 flex gap-4 text-xs text-slate-400">
						<span class="inline-flex items-center gap-2"><i class="h-2 w-2 rounded-full bg-emerald-400" /> Участники</span>
						<span class="inline-flex items-center gap-2"><i class="h-2 w-2 rounded-full bg-rose-400" /> Не участники</span>
					</div>
				</section>

				<section class="w-full min-w-0 overflow-hidden rounded-3xl border border-amber-500/12 bg-[#11131b] p-6 shadow-[0_24px_60px_rgba(0,0,0,0.28)]">
					<p class="admin-metric-label text-amber-300/80">Количество заказов</p>
					<h2 class="mt-2 text-xl font-semibold text-white">Создали ссылку, не оплатили</h2>
					<div class="mt-5 rounded-2xl border border-white/8 bg-white/[0.03] p-4">
						<p class="admin-metric-label text-slate-500">За 30 дней</p>
						<p class="mt-2 text-3xl font-semibold text-amber-300">{{ fmt(stats?.unfinishedOrders) }}</p>
						<p class="mt-2 text-xs text-slate-500">Считаются люди, создавшие платёжную ссылку, но не оплатившие. После успешной оплаты человек уходит из этого показателя.</p>
					</div>
				</section>
			</div>

	</div>
</template>

<style scoped>
.admin-dashboard-page {
	box-sizing: border-box;
	width: 100%;
	max-width: 100%;
	min-width: 0;
	overflow-x: hidden;
}

.admin-dashboard-page :deep(*) {
	box-sizing: border-box;
}

.dashboard-chart-box {
	position: relative;
	width: 100%;
	max-width: 100%;
	min-width: 0;
	overflow: hidden;
}

.admin-metric-label {
	overflow-wrap: anywhere;
	word-break: normal;
	hyphens: auto;
	font-size: 0.72rem;
	font-weight: 600;
	line-height: 1.55;
	letter-spacing: 0.12em;
	text-transform: uppercase;
}
</style>
