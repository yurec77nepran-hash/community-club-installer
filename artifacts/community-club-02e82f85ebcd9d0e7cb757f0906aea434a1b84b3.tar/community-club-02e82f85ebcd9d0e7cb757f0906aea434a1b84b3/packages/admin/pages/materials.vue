<script setup lang="ts">
import {
	formatVideoChapterTime,
	normalizeVideoChapters,
	parseVideoChapterTime,
} from '@community-club/shared'
import type { Material } from '@community-club/shared/db/schema'
import type {
	AdminMediaLibraryItem,
	AdminMediaLibraryPreferencesPayload,
	CursorPaginatedResponse,
	GuestContentBlockAccess,
	MaterialGuestAccess,
} from '@community-club/shared/types'
import { getBatchUploadProgressPercent, getUploadProgressPercent } from '~/utils/upload-progress'

type MaterialEditorFile = {
	path: string
	type: string
	url: string
	displayName?: string
	downloadable?: boolean
	guestAccess?: GuestContentBlockAccess
	chapters?: {
		collapsible: boolean
		items: Array<{ time: string; description: string }>
	}
}

type MaterialAdminRecord = Material & {
	storageFiles?: MaterialEditorFile[]
}

type MaterialTypeOption = {
	key: string
	label: string
	system: boolean
	usedCount: number
}

type MediaLibraryFilter = 'all' | 'image' | 'video' | 'audio' | 'document'
type MediaPickerSortBy = AdminMediaLibraryPreferencesPayload['sortBy']
type MediaPickerSortDir = AdminMediaLibraryPreferencesPayload['sortDir']
type MediaPickerViewMode = AdminMediaLibraryPreferencesPayload['viewMode']
type UploadProgressState = {
	currentName: string
	currentIndex: number
	totalFiles: number
	currentPercent: number
	overallPercent: number
	loadedBytes: number
	totalBytes: number
}

const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()
const materials = ref<MaterialAdminRecord[]>([])
const loading = ref(true)
const showForm = ref(false)
const editItem = ref<Material | null>(null)
const uploading = ref(false)
const mediaUploadProgress = ref<UploadProgressState>(createEmptyUploadProgress())
const uploadingCover = ref(false)
const uploadingVideoCover = ref(false)
const brokenCoverIds = ref<number[]>([])
const brokenVideoCoverIds = ref<number[]>([])
const searchQuery = ref('')
const filterType = ref('all')
const filterMedia = ref('all')
const filterStatus = ref('all')
const filterComments = ref('all')
const filterSubsection = ref('all')
const sortBy = ref<'createdDesc' | 'createdAsc' | 'titleAsc' | 'titleDesc' | 'typeAsc'>(
	'createdDesc',
)

// Custom type/subsection adding
const showNewType = ref(false)
const newTypeLabel = ref('')
const showSectionManager = ref(false)
const materialTypesLoading = ref(false)
const materialTypeOptions = ref<MaterialTypeOption[]>([])
const editingTypeKey = ref<string | null>(null)
const editingTypeLabel = ref('')
const typeError = ref('')
const showNewSubsection = ref(false)
const showSubsectionDropdown = ref(false)
const newSubsection = ref('')
const editingSubsectionTitle = ref<string | null>(null)
const editingSubsectionLabel = ref('')
const savedSubsections = ref<string[]>([])
const copiedMaterialId = ref<number | null>(null)
const copyToastMessage = ref('')
const formError = ref('')
const subsectionError = ref('')
const subsectionDropdownRef = ref<HTMLElement | null>(null)

const allTypeOptions = computed(() => {
	return materialTypeOptions.value.map(({ key, label }) => ({ key, label }))
})
const materialTypeLabelByKey = computed(
	() => new Map(materialTypeOptions.value.map((item) => [item.key, item.label])),
)

// Unique subsections from existing materials
const existingSubsections = computed(() => {
	const subs = new Set<string>()
	for (const m of materials.value) {
		if (m.subsection) subs.add(m.subsection)
	}
	for (const subsection of savedSubsections.value) {
		if (subsection) subs.add(subsection)
	}
	return [...subs].sort()
})

const currentSubsectionLabel = computed(() => form.value.subsection || '— Без подраздела —')

const visibleMaterials = computed(() => {
	const normalizedSearch = searchQuery.value.trim().toLowerCase()
	const filtered = materials.value.filter((item) => {
		if (normalizedSearch && !item.title.toLowerCase().includes(normalizedSearch)) {
			return false
		}

		if (filterType.value !== 'all' && item.type !== filterType.value) {
			return false
		}

		if (filterMedia.value !== 'all' && (item.mediaType ?? 'none') !== filterMedia.value) {
			return false
		}

		const isActive = (item as Record<string, unknown>).active !== false
		if (filterStatus.value === 'active' && !isActive) {
			return false
		}
		if (filterStatus.value === 'inactive' && isActive) {
			return false
		}

		const commentsEnabled = Boolean((item as Record<string, unknown>).commentsEnabled)
		if (filterComments.value === 'enabled' && !commentsEnabled) {
			return false
		}
		if (filterComments.value === 'disabled' && commentsEnabled) {
			return false
		}

		const subsection = item.subsection?.trim() || 'none'
		if (filterSubsection.value !== 'all' && subsection !== filterSubsection.value) {
			return false
		}

		return true
	})

	return filtered.toSorted((left, right) => {
		switch (sortBy.value) {
			case 'createdAsc':
				return (
					new Date(left.createdAt).getTime() - new Date(right.createdAt).getTime() ||
					left.id - right.id
				)
			case 'titleAsc':
				return left.title.localeCompare(right.title, 'ru', { sensitivity: 'base' })
			case 'titleDesc':
				return right.title.localeCompare(left.title, 'ru', { sensitivity: 'base' })
			case 'typeAsc':
				return getMaterialTypeLabel(left.type).localeCompare(
					getMaterialTypeLabel(right.type),
					'ru',
					{
						sensitivity: 'base',
					},
				)
			default:
				return (
					new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime() ||
					right.id - left.id
				)
		}
	})
})

const activeFilterCount = computed(
	() =>
		[
			searchQuery.value.trim(),
			filterType.value !== 'all',
			filterMedia.value !== 'all',
			filterStatus.value !== 'all',
			filterComments.value !== 'all',
			filterSubsection.value !== 'all',
			sortBy.value !== 'createdDesc',
		].filter(Boolean).length,
)

// Media files list (stored as JSON array in storagePath)
const mediaFiles = ref<MaterialEditorFile[]>([])
const showMediaPicker = ref(false)
const mediaLibraryLoading = ref(false)
const mediaLibraryLoadingMore = ref(false)
const mediaLibraryItems = ref<AdminMediaLibraryItem[]>([])
const mediaLibraryCursor = ref<string | null>(null)
const mediaLibraryFilter = ref<MediaLibraryFilter>('all')
const mediaLibrarySearch = ref('')
const mediaLibrarySearchDraft = ref('')
const mediaPickerViewMode = ref<MediaPickerViewMode>('cards')
const mediaPickerSortBy = ref<MediaPickerSortBy>('updatedAt')
const mediaPickerSortDir = ref<MediaPickerSortDir>('desc')
const mediaPickerPreferencesLoaded = ref(false)
const mediaPickerSelectedItems = ref<AdminMediaLibraryItem[]>([])
const mediaLibraryFilterLabels: Record<MediaLibraryFilter, string> = {
	all: 'Все',
	image: 'Картинки',
	video: 'Видео',
	audio: 'Аудио',
	document: 'Файлы',
}
const mediaPickerViewLabels: Record<MediaPickerViewMode, string> = {
	cards: 'Карточки',
	list: 'Список',
}
const mediaPickerSortOptions: Array<{ value: MediaPickerSortBy; label: string }> = [
	{ value: 'updatedAt', label: 'По дате' },
	{ value: 'title', label: 'По названию' },
	{ value: 'size', label: 'По размеру' },
	{ value: 'type', label: 'По разделу' },
]
const selectedMediaPaths = computed(() => new Set(mediaFiles.value.map((item) => item.path)))
const selectedMediaLibraryKeys = computed(
	() => new Set(mediaPickerSelectedItems.value.map((item) => item.key)),
)
const selectedMediaLibraryCount = computed(() => mediaPickerSelectedItems.value.length)
const expandedVideoPaths = ref<string[]>([])
const editingMediaPath = ref<string | null>(null)
const draggingMediaIndex = ref<number | null>(null)
let mediaDragPointerId: number | null = null
let mediaLibrarySearchDebounce: ReturnType<typeof setTimeout> | null = null
let mediaPickerPreferencesDebounce: ReturnType<typeof setTimeout> | null = null
const mediaPickerTabs = ['image', 'video', 'audio', 'document'] as const
const mediaPickerAcceptMap: Record<(typeof mediaPickerTabs)[number], string> = {
	image: 'image/*',
	video: 'video/*',
	audio: 'audio/*',
	document: '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip',
}
const defaultMediaPickerPreferences: AdminMediaLibraryPreferencesPayload = {
	viewMode: 'cards',
	sortBy: 'updatedAt',
	sortDir: 'desc',
	typeFilter: 'all',
	searchQuery: '',
	folderId: null,
}
const fallbackCoverGradients: Record<string, string> = {
	streams: 'from-slate-700 via-slate-600 to-slate-500',
	podcasts: 'from-slate-700 via-slate-600 to-slate-500',
	checklists: 'from-slate-700 via-slate-600 to-slate-500',
	books: 'from-slate-700 via-slate-600 to-slate-500',
	movies: 'from-slate-700 via-slate-600 to-slate-500',
	promotions: 'from-slate-700 via-slate-600 to-slate-500',
	shop: 'from-slate-700 via-slate-600 to-slate-500',
	courses: 'from-slate-700 via-slate-600 to-slate-500',
	socialContent: 'from-slate-700 via-slate-600 to-slate-500',
	calendar: 'from-slate-700 via-slate-600 to-slate-500',
}

const form = ref({
	type: '',
	title: '',
	fullDescription: '',
	telegramPostUrl: '',
	mediaType: '' as string,
	subsection: '',
	active: true,
	imageUrl: '',
	videoCoverUrl: '',
	commentsEnabled: true,
	guestAccess: {
		cover: 'visible' as GuestContentBlockAccess,
		description: 'visible' as GuestContentBlockAccess,
		link: 'visible' as GuestContentBlockAccess,
	},
})

const defaultGuestAccess = (): MaterialGuestAccess => ({
	cover: 'visible',
	description: 'visible',
	link: 'visible',
})

function parseGuestAccess(item: Material | null): MaterialGuestAccess {
	if (!item?.storagePath) return defaultGuestAccess()
	try {
		const parsed = JSON.parse(item.storagePath) as { guestAccess?: Partial<MaterialGuestAccess> }
		return {
			cover:
				parsed.guestAccess?.cover === 'blurred' || parsed.guestAccess?.cover === 'locked'
					? parsed.guestAccess.cover
					: 'visible',
			description:
				parsed.guestAccess?.description === 'blurred' ||
				parsed.guestAccess?.description === 'locked'
					? parsed.guestAccess.description
					: 'visible',
			link:
				parsed.guestAccess?.link === 'blurred' || parsed.guestAccess?.link === 'locked'
					? parsed.guestAccess.link
					: 'visible',
		}
	} catch {
		return defaultGuestAccess()
	}
}

onMounted(async () => {
	await Promise.all([loadMaterials(), loadSubsectionOptions(), loadMaterialTypeOptions()])
})

onBeforeUnmount(() => {
	stopMediaDrag()
	if (mediaLibrarySearchDebounce) {
		clearTimeout(mediaLibrarySearchDebounce)
	}
	if (mediaPickerPreferencesDebounce) {
		clearTimeout(mediaPickerPreferencesDebounce)
	}
	if (import.meta.client) {
		document.removeEventListener('pointerdown', handleSubsectionPointerDown)
	}
})

if (import.meta.client) {
	document.addEventListener('pointerdown', handleSubsectionPointerDown)
}

async function loadMaterials() {
	loading.value = true
	const res = await api.get<MaterialAdminRecord[]>('/api/admin/materials')
	if (res.success) materials.value = res.data
	loading.value = false
}

async function loadSubsectionOptions() {
	const res = await api.get<string[]>('/api/admin/material-subsections')
	if (res.success) {
		savedSubsections.value = res.data
	}
}

async function loadMaterialTypeOptions() {
	materialTypesLoading.value = true
	const res = await api.get<MaterialTypeOption[]>('/api/admin/material-types')
	if (res.success) {
		materialTypeOptions.value = res.data
	} else {
		typeError.value = res.error.message
	}
	materialTypesLoading.value = false
}

async function loadMediaLibrary(options?: { append?: boolean }) {
	const append = options?.append ?? false
	if (append) {
		if (!mediaLibraryCursor.value || mediaLibraryLoadingMore.value) return
		mediaLibraryLoadingMore.value = true
	} else {
		mediaLibraryLoading.value = true
	}

	const query = new URLSearchParams({
		limit: '48',
		type: mediaLibraryFilter.value,
		sortBy: mediaPickerSortBy.value,
		sortDir: mediaPickerSortDir.value,
	})
	const search = mediaLibrarySearch.value.trim()
	if (search) {
		query.set('search', search)
	}
	if (append && mediaLibraryCursor.value) {
		query.set('cursor', mediaLibraryCursor.value)
	}

	const res = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		`/api/admin/media-library?${query.toString()}`,
	)

	if (res.success) {
		mediaLibraryItems.value = append
			? [...mediaLibraryItems.value, ...res.data.items]
			: res.data.items
		mediaLibraryCursor.value = res.data.nextCursor
	} else if (!append) {
		mediaLibraryItems.value = []
		mediaLibraryCursor.value = null
	}

	mediaLibraryLoading.value = false
	mediaLibraryLoadingMore.value = false
}

function buildMediaPickerPreferencesPayload(): AdminMediaLibraryPreferencesPayload {
	return {
		viewMode: mediaPickerViewMode.value,
		sortBy: mediaPickerSortBy.value,
		sortDir: mediaPickerSortDir.value,
		typeFilter: mediaLibraryFilter.value,
		searchQuery: mediaLibrarySearch.value,
		folderId: null,
	}
}

async function loadMediaPickerPreferences(initialFilter: MediaLibraryFilter = 'image') {
	const res = await api.get<AdminMediaLibraryPreferencesPayload>(
		'/api/admin/media-library/preferences?scope=materialPicker',
	)
	const prefs = res.success
		? { ...defaultMediaPickerPreferences, ...res.data }
		: { ...defaultMediaPickerPreferences, typeFilter: initialFilter }
	mediaPickerViewMode.value = prefs.viewMode
	mediaPickerSortBy.value = prefs.sortBy
	mediaPickerSortDir.value = prefs.sortDir
	mediaLibraryFilter.value = prefs.typeFilter === 'all' ? initialFilter : prefs.typeFilter
	mediaLibrarySearch.value = prefs.searchQuery
	mediaLibrarySearchDraft.value = prefs.searchQuery
	mediaPickerPreferencesLoaded.value = true
}

function scheduleMediaPickerPreferencesSave() {
	if (!mediaPickerPreferencesLoaded.value) return
	if (mediaPickerPreferencesDebounce) {
		clearTimeout(mediaPickerPreferencesDebounce)
	}
	mediaPickerPreferencesDebounce = setTimeout(async () => {
		await api.post<AdminMediaLibraryPreferencesPayload>(
			'/api/admin/media-library/preferences?scope=materialPicker',
			buildMediaPickerPreferencesPayload(),
		)
	}, 180)
}

const mediaPickerAccept = computed(() => {
	if (mediaLibraryFilter.value === 'all') {
		return 'video/*,audio/*,image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip'
	}
	return mediaPickerAcceptMap[mediaLibraryFilter.value]
})

async function openMediaPicker(initialFilter: MediaLibraryFilter = 'image') {
	if (!mediaPickerPreferencesLoaded.value) {
		await loadMediaPickerPreferences(initialFilter)
	}
	showMediaPicker.value = true
	mediaPickerSelectedItems.value = []
	mediaLibraryItems.value = []
	mediaLibraryCursor.value = null
	await loadMediaLibrary()
}

function closeMediaPicker() {
	showMediaPicker.value = false
	mediaPickerSelectedItems.value = []
}

function selectMediaPickerTab(filter: (typeof mediaPickerTabs)[number]) {
	if (mediaLibraryFilter.value === filter) return
	mediaLibraryFilter.value = filter
}

function addMediaFromLibrary(item: AdminMediaLibraryItem) {
	if (selectedMediaPaths.value.has(item.key)) return
	mediaFiles.value.push({
		path: item.key,
		type: item.type,
		url: item.url,
		displayName: item.note?.trim() || item.title || item.name,
		downloadable: false,
	})
	if (!form.value.mediaType) {
		form.value.mediaType = item.type
	}
}

function toggleMediaLibrarySelection(item: AdminMediaLibraryItem) {
	if (selectedMediaPaths.value.has(item.key)) return
	const selected = selectedMediaLibraryKeys.value
	if (selected.has(item.key)) {
		mediaPickerSelectedItems.value = mediaPickerSelectedItems.value.filter(
			(selectedItem) => selectedItem.key !== item.key,
		)
		return
	}
	mediaPickerSelectedItems.value.push(item)
}

function isMediaLibrarySelected(item: AdminMediaLibraryItem) {
	return selectedMediaLibraryKeys.value.has(item.key)
}

function addSelectedMediaFromLibrary() {
	if (mediaPickerSelectedItems.value.length === 0) return
	for (const item of mediaPickerSelectedItems.value) {
		if (selectedMediaPaths.value.has(item.key)) continue
		addMediaFromLibrary(item)
	}
	mediaPickerSelectedItems.value = []
	showMediaPicker.value = false
}

const canAssignVideoCover = computed(
	() => form.value.mediaType === 'video' || mediaFiles.value.some((item) => item.type === 'video'),
)

function isMediaSelected(item: AdminMediaLibraryItem) {
	return selectedMediaPaths.value.has(item.key)
}

function parseMediaFiles(item: MaterialAdminRecord | null): MaterialEditorFile[] {
	if (!item?.storagePath) return []
	if (Array.isArray(item.storageFiles) && item.storageFiles.length > 0) {
		return item.storageFiles
			.filter((file) => file.path && file.url)
			.map((file) => ({
				path: file.path,
				type: file.type || item.mediaType || 'document',
				url: file.url,
				displayName: file.displayName,
				downloadable: file.downloadable === true,
				guestAccess:
					file.guestAccess === 'blurred' || file.guestAccess === 'locked'
						? file.guestAccess
						: 'visible',
				chapters: toEditorVideoChapters(file.chapters),
			}))
	}
	try {
		const parsed = JSON.parse(item.storagePath)
		const files = Array.isArray(parsed)
			? parsed
			: typeof parsed === 'object' && parsed !== null && Array.isArray(parsed.files)
				? parsed.files
				: []
		if (files.length > 0) {
			return files
				.filter(
					(file): file is Partial<MaterialEditorFile> => typeof file === 'object' && file !== null,
				)
				.map((file) => ({
					path: String(file.path ?? ''),
					type: String(file.type ?? item.mediaType ?? 'document'),
					url: String(file.url ?? file.path ?? ''),
					displayName: typeof file.displayName === 'string' ? file.displayName : undefined,
					downloadable: file.downloadable === true,
					guestAccess:
						file.guestAccess === 'blurred' || file.guestAccess === 'locked'
							? file.guestAccess
							: 'visible',
					chapters: toEditorVideoChapters(file.chapters),
				}))
				.filter((file) => file.path.length > 0)
		}
	} catch {
		// single path string
	}
	return [
		{
			path: item.storagePath,
			type: item.mediaType ?? 'document',
			url: item.storagePath,
			guestAccess: 'visible',
		},
	]
}

function toEditorVideoChapters(value: unknown) {
	const chapters = normalizeVideoChapters(value)
	if (!chapters) return undefined
	return {
		collapsible: chapters.collapsible,
		items: chapters.items.map((item) => ({
			time: formatVideoChapterTime(item.time),
			description: item.description,
		})),
	}
}

function toggleVideoChapters(file: MaterialEditorFile) {
	file.chapters = file.chapters ? undefined : { collapsible: false, items: [] }
}

function addVideoChapter(file: MaterialEditorFile) {
	if (!file.chapters) return
	file.chapters.items.push({ time: '00:00', description: '' })
}

function removeVideoChapter(file: MaterialEditorFile, index: number) {
	file.chapters?.items.splice(index, 1)
}

function serializeVideoChapters(file: MaterialEditorFile) {
	if (file.type !== 'video' || !file.chapters) return undefined
	return {
		collapsible: file.chapters.collapsible,
		items: file.chapters.items.map((item) => ({
			time: parseVideoChapterTime(item.time) ?? -1,
			description: item.description.trim(),
		})),
	}
}

function hasInvalidVideoChapters() {
	return mediaFiles.value.some((file) =>
		file.chapters?.items.some(
			(item) => parseVideoChapterTime(item.time) === null || !item.description.trim(),
		),
	)
}

function hasBrokenCover(id: number) {
	return brokenCoverIds.value.includes(id)
}

function markCoverBroken(id: number) {
	if (!brokenCoverIds.value.includes(id)) {
		brokenCoverIds.value.push(id)
	}
}

function hasBrokenVideoCover(id: number) {
	return brokenVideoCoverIds.value.includes(id)
}

function markVideoCoverBroken(id: number) {
	if (!brokenVideoCoverIds.value.includes(id)) {
		brokenVideoCoverIds.value.push(id)
	}
}

function getFallbackCoverGradient(type: string) {
	return fallbackCoverGradients[type] ?? 'from-slate-500/80 via-gray-500/70 to-zinc-400/80'
}

function getMaterialPublicLink(item: Pick<Material, 'id' | 'type'>) {
	if (!import.meta.client) return ''
	return `${window.location.origin}/app/content/${item.type}/${item.id}`
}

async function copyMaterialLink(item: Pick<Material, 'id' | 'type'>) {
	const link = getMaterialPublicLink(item)
	if (!link) return
	try {
		await navigator.clipboard.writeText(link)
		copiedMaterialId.value = item.id
		copyToastMessage.value = 'Ссылка скопирована'
		setTimeout(() => {
			if (copiedMaterialId.value === item.id) {
				copiedMaterialId.value = null
			}
		}, 1600)
		setTimeout(() => {
			if (copyToastMessage.value === 'Ссылка скопирована') {
				copyToastMessage.value = ''
			}
		}, 1600)
	} catch {
		copiedMaterialId.value = null
		copyToastMessage.value = ''
	}
}

function openCreate() {
	stopMediaDrag()
	formError.value = ''
	subsectionError.value = ''
	showSubsectionDropdown.value = false
	editItem.value = null
	form.value = {
		type: '',
		title: '',
		fullDescription: '',
		telegramPostUrl: '',
		mediaType: '',
		subsection: '',
		active: true,
		commentsEnabled: true,
		imageUrl: '',
		videoCoverUrl: '',
		guestAccess: defaultGuestAccess(),
	}
	mediaFiles.value = []
	expandedVideoPaths.value = []
	editingMediaPath.value = null
	showMediaPicker.value = false
	showForm.value = true
}

function openEdit(item: Material) {
	stopMediaDrag()
	formError.value = ''
	subsectionError.value = ''
	showSubsectionDropdown.value = false
	editItem.value = item
	form.value = {
		type: item.type,
		title: item.title,
		fullDescription: ((item as Record<string, unknown>).fullDescription as string) ?? '',
		telegramPostUrl: ((item as Record<string, unknown>).telegramPostUrl as string) ?? '',
		mediaType: item.mediaType ?? '',
		subsection: item.subsection ?? '',
		active: (item as Record<string, unknown>).active !== false,
		commentsEnabled: Boolean((item as Record<string, unknown>).commentsEnabled),
		imageUrl: ((item as Record<string, unknown>).imageUrl as string) ?? '',
		videoCoverUrl: ((item as Record<string, unknown>).videoCoverUrl as string) ?? '',
		guestAccess: parseGuestAccess(item),
	}
	mediaFiles.value = parseMediaFiles(item)
	expandedVideoPaths.value = []
	editingMediaPath.value = null
	showMediaPicker.value = false
	showForm.value = true
}

function detectMaterialMediaType(file: File) {
	if (file.type.startsWith('video/')) return 'video'
	if (file.type.startsWith('audio/')) return 'audio'
	if (file.type.startsWith('image/')) return 'image'
	return 'document'
}

function createEmptyUploadProgress(): UploadProgressState {
	return {
		currentName: '',
		currentIndex: 0,
		totalFiles: 0,
		currentPercent: 0,
		overallPercent: 0,
		loadedBytes: 0,
		totalBytes: 0,
	}
}

function updateMaterialUploadProgress(params: {
	file: File
	index: number
	totalFiles: number
	completedBytes: number
	totalBytes: number
	loaded: number
	total: number | null
}) {
	const fileLoadedBytes =
		params.file.size > 0 ? Math.min(params.loaded, params.file.size) : params.loaded
	mediaUploadProgress.value = {
		currentName: params.file.name,
		currentIndex: params.index + 1,
		totalFiles: params.totalFiles,
		currentPercent: getUploadProgressPercent(fileLoadedBytes, params.total ?? params.file.size),
		overallPercent: getBatchUploadProgressPercent(
			params.completedBytes,
			fileLoadedBytes,
			params.totalBytes,
		),
		loadedBytes: Math.min(params.completedBytes + fileLoadedBytes, params.totalBytes),
		totalBytes: params.totalBytes,
	}
}

async function uploadSingleMediaFile(
	file: File,
	onProgress?: (progress: { loaded: number; total: number | null; percent: number }) => void,
) {
	const result = await mediaUpload.uploadFile(file, { onProgress })
	if (!result.success) {
		throw new Error(result.error.message)
	}

	const mediaType =
		typeof result.data?.mediaType === 'string' && result.data.mediaType
			? result.data.mediaType
			: detectMaterialMediaType(file)
	mediaFiles.value.push({
		path: result.data.path,
		type: mediaType,
		url: result.data.url ?? result.data.path,
		displayName: file.name,
		downloadable: false,
	})

	if (!form.value.mediaType) {
		form.value.mediaType = mediaType
	}
}

async function uploadMediaFile(e: Event) {
	const input = e.target as HTMLInputElement
	const files = Array.from(input.files ?? [])
	if (files.length === 0) return
	input.value = ''

	uploading.value = true
	const totalBytes = files.reduce((sum, file) => sum + file.size, 0)
	let completedBytes = 0
	mediaUploadProgress.value = {
		...createEmptyUploadProgress(),
		currentName: files[0]?.name ?? '',
		currentIndex: 1,
		totalFiles: files.length,
		totalBytes,
	}
	try {
		for (const [index, file] of files.entries()) {
			updateMaterialUploadProgress({
				file,
				index,
				totalFiles: files.length,
				completedBytes,
				totalBytes,
				loaded: 0,
				total: file.size,
			})
			await uploadSingleMediaFile(file, (progress) => {
				updateMaterialUploadProgress({
					file,
					index,
					totalFiles: files.length,
					completedBytes,
					totalBytes,
					loaded: progress.loaded,
					total: progress.total ?? file.size,
				})
			})
			completedBytes += file.size
			updateMaterialUploadProgress({
				file,
				index,
				totalFiles: files.length,
				completedBytes: completedBytes - file.size,
				totalBytes,
				loaded: file.size,
				total: file.size,
			})
		}
		showMediaPicker.value = false
	} catch (error) {
		formError.value =
			error instanceof Error && error.message ? error.message : 'Не удалось загрузить файл.'
	}
	uploading.value = false
	mediaUploadProgress.value = createEmptyUploadProgress()
}

function removeMedia(idx: number) {
	const removed = mediaFiles.value[idx]
	mediaFiles.value.splice(idx, 1)
	if (removed?.path === editingMediaPath.value) {
		editingMediaPath.value = null
	}
	if (removed?.type === 'video') {
		expandedVideoPaths.value = expandedVideoPaths.value.filter((path) => path !== removed.path)
	}
	if (mediaFiles.value.length === 0) {
		form.value.mediaType = ''
	}
}

async function uploadCover(e: Event) {
	const input = e.target as HTMLInputElement
	const file = input.files?.[0]
	if (!file) return
	input.value = ''

	uploadingCover.value = true
	try {
		const result = await mediaUpload.uploadFile(file)
		if (result.success) {
			form.value.imageUrl = result.data.url ?? result.data.path
		} else {
			formError.value = result.error.message
		}
	} catch (error) {
		formError.value =
			error instanceof Error && error.message ? error.message : 'Не удалось загрузить обложку.'
	}
	uploadingCover.value = false
}

function removeCover() {
	form.value.imageUrl = ''
}

async function uploadVideoCover(e: Event) {
	const input = e.target as HTMLInputElement
	const file = input.files?.[0]
	if (!file) return
	input.value = ''

	uploadingVideoCover.value = true
	try {
		const result = await mediaUpload.uploadFile(file)
		if (result.success) {
			form.value.videoCoverUrl = result.data.url ?? result.data.path
		} else {
			formError.value = result.error.message
		}
	} catch (error) {
		formError.value =
			error instanceof Error && error.message
				? error.message
				: 'Не удалось загрузить обложку видео.'
	}
	uploadingVideoCover.value = false
}

function removeVideoCover() {
	form.value.videoCoverUrl = ''
}

function applyMediaImageAsCover(target: 'card' | 'video', fileUrl: string) {
	if (target === 'card') {
		form.value.imageUrl = fileUrl
		return
	}

	form.value.videoCoverUrl = fileUrl
}

function toggleVideoExpanded(path: string) {
	if (expandedVideoPaths.value.includes(path)) {
		expandedVideoPaths.value = expandedVideoPaths.value.filter((item) => item !== path)
		return
	}
	expandedVideoPaths.value = [...expandedVideoPaths.value, path]
}

function isVideoExpanded(path: string) {
	return expandedVideoPaths.value.includes(path)
}

function getMediaDisplayName(file: MaterialEditorFile) {
	return file.displayName?.trim() || 'Без названия'
}

function startEditingMediaName(path: string) {
	editingMediaPath.value = path
}

function stopEditingMediaName() {
	editingMediaPath.value = null
}

function moveMedia(fromIndex: number, toIndex: number) {
	if (fromIndex === toIndex) return
	const next = [...mediaFiles.value]
	const [moved] = next.splice(fromIndex, 1)
	if (!moved) return
	next.splice(toIndex, 0, moved)
	mediaFiles.value = next
	draggingMediaIndex.value = toIndex
}

function resolveMediaDropIndex(target: EventTarget | null) {
	if (!(target instanceof Element)) return null
	const row = target.closest<HTMLElement>('[data-media-index]')
	if (!row) return null
	const rawIndex = row.dataset.mediaIndex
	if (typeof rawIndex !== 'string') return null
	const parsed = Number(rawIndex)
	return Number.isInteger(parsed) ? parsed : null
}

function handleMediaDragMove(event: PointerEvent) {
	if (mediaDragPointerId !== event.pointerId || draggingMediaIndex.value === null) return
	event.preventDefault()
	const target = document.elementFromPoint(event.clientX, event.clientY)
	const dropIndex = resolveMediaDropIndex(target)
	if (dropIndex === null || dropIndex === draggingMediaIndex.value) return
	moveMedia(draggingMediaIndex.value, dropIndex)
}

function stopMediaDrag(pointerId?: number) {
	if (pointerId !== undefined && mediaDragPointerId !== pointerId) return
	mediaDragPointerId = null
	draggingMediaIndex.value = null
	window.removeEventListener('pointermove', handleMediaDragMove)
	window.removeEventListener('pointerup', handleMediaDragEnd)
	window.removeEventListener('pointercancel', handleMediaDragEnd)
}

function handleMediaDragEnd(event: PointerEvent) {
	stopMediaDrag(event.pointerId)
}

function startMediaDrag(event: PointerEvent, index: number) {
	if (mediaFiles.value.length < 2) return
	stopMediaDrag()
	mediaDragPointerId = event.pointerId
	draggingMediaIndex.value = index
	window.addEventListener('pointermove', handleMediaDragMove, { passive: false })
	window.addEventListener('pointerup', handleMediaDragEnd)
	window.addEventListener('pointercancel', handleMediaDragEnd)
}

async function addCustomType() {
	const label = newTypeLabel.value.trim()
	if (!label) return
	typeError.value = ''
	const res = await api.post<MaterialTypeOption[]>('/api/admin/material-types', { label })
	if (!res.success) {
		typeError.value = res.error.message
		return
	}
	materialTypeOptions.value = res.data
	const created = res.data.find((item) => item.label === label) ?? res.data.at(-1)
	if (created) form.value.type = created.key
	newTypeLabel.value = ''
	showNewType.value = false
}

function startEditType(item: MaterialTypeOption) {
	editingTypeKey.value = item.key
	editingTypeLabel.value = item.label
	typeError.value = ''
}

function cancelEditType() {
	editingTypeKey.value = null
	editingTypeLabel.value = ''
}

async function saveTypeLabel(key: string) {
	const label = editingTypeLabel.value.trim()
	if (!label) return
	typeError.value = ''
	const res = await api.patch<MaterialTypeOption[]>(
		`/api/admin/material-types/${encodeURIComponent(key)}`,
		{ label },
	)
	if (!res.success) {
		typeError.value = res.error.message
		return
	}
	materialTypeOptions.value = res.data
	cancelEditType()
}

async function deleteMaterialType(item: MaterialTypeOption) {
	if (item.system) return
	if (!confirm('Удалить раздел? Материалы останутся без раздела.')) return
	typeError.value = ''
	const res = await api.delete<MaterialTypeOption[]>(
		`/api/admin/material-types/${encodeURIComponent(item.key)}`,
	)
	if (!res.success) {
		typeError.value = res.error.message
		return
	}
	materialTypeOptions.value = res.data
	if (form.value.type === item.key) form.value.type = ''
	if (filterType.value === item.key) filterType.value = 'all'
	await loadMaterials()
}

async function addCustomSubsection() {
	const subsection = newSubsection.value.trim()
	if (!subsection) return
	subsectionError.value = ''
	const res = await api.post<string[]>('/api/admin/material-subsections', { title: subsection })
	if (!res.success) {
		subsectionError.value = res.error.message
		return
	}
	savedSubsections.value = res.data
	form.value.subsection = res.data.find((item) => item === subsection) ?? subsection
	newSubsection.value = ''
	showNewSubsection.value = false
	showSubsectionDropdown.value = true
}

async function deleteSubsection(title: string) {
	if (!confirm('Удалить подраздел? Материалы останутся без подраздела.')) return
	subsectionError.value = ''
	const res = await api.delete<string[]>(
		`/api/admin/material-subsections/${encodeURIComponent(title)}`,
	)
	if (!res.success) {
		subsectionError.value = res.error.message
		return
	}
	savedSubsections.value = res.data
	if (form.value.subsection === title) {
		form.value.subsection = ''
	}
	showSubsectionDropdown.value = false
	await loadMaterials()
}

function startEditSubsection(title: string) {
	editingSubsectionTitle.value = title
	editingSubsectionLabel.value = title
	subsectionError.value = ''
}

function cancelEditSubsection() {
	editingSubsectionTitle.value = null
	editingSubsectionLabel.value = ''
}

async function saveSubsectionTitle(title: string) {
	const nextTitle = editingSubsectionLabel.value.trim()
	if (!nextTitle) return
	subsectionError.value = ''
	const res = await api.patch<string[]>(
		`/api/admin/material-subsections/${encodeURIComponent(title)}`,
		{ title: nextTitle },
	)
	if (!res.success) {
		subsectionError.value = res.error.message
		return
	}
	savedSubsections.value = res.data
	if (form.value.subsection === title) form.value.subsection = nextTitle
	if (filterSubsection.value === title) filterSubsection.value = nextTitle
	cancelEditSubsection()
	await loadMaterials()
}

function toggleSubsectionDropdown() {
	showSubsectionDropdown.value = !showSubsectionDropdown.value
}

function selectSubsection(title: string) {
	form.value.subsection = title
	showSubsectionDropdown.value = false
}

function clearSubsection() {
	form.value.subsection = ''
	showSubsectionDropdown.value = false
}

function handleSubsectionPointerDown(event: PointerEvent) {
	if (!showSubsectionDropdown.value) return
	const target = event.target
	if (!(target instanceof Node)) return
	if (subsectionDropdownRef.value?.contains(target)) return
	showSubsectionDropdown.value = false
}

function formatMediaLibraryDate(value: string | Date | null) {
	if (!value) return ''
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: 'short',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function formatMediaLibrarySize(size: number | null) {
	if (!size) return ''
	if (size < 1024 * 1024) return `${Math.round(size / 1024)} КБ`
	return `${(size / (1024 * 1024)).toFixed(1)} МБ`
}

function formatUploadProgressSize(size: number) {
	return formatMediaLibrarySize(size) || '0 КБ'
}

watch(mediaLibraryFilter, () => {
	if (!showMediaPicker.value) return
	scheduleMediaPickerPreferencesSave()
	mediaLibraryItems.value = []
	mediaLibraryCursor.value = null
	void loadMediaLibrary()
})

watch([mediaPickerSortBy, mediaPickerSortDir], () => {
	if (!showMediaPicker.value) return
	scheduleMediaPickerPreferencesSave()
	mediaLibraryItems.value = []
	mediaLibraryCursor.value = null
	void loadMediaLibrary()
})

watch(mediaPickerViewMode, () => {
	if (!showMediaPicker.value) return
	scheduleMediaPickerPreferencesSave()
})

watch(mediaLibrarySearchDraft, () => {
	if (!showMediaPicker.value) return
	if (mediaLibrarySearchDebounce) {
		clearTimeout(mediaLibrarySearchDebounce)
	}
	mediaLibrarySearchDebounce = setTimeout(() => {
		mediaLibrarySearch.value = mediaLibrarySearchDraft.value.trim()
		scheduleMediaPickerPreferencesSave()
		mediaLibraryItems.value = []
		mediaLibraryCursor.value = null
		void loadMediaLibrary()
	}, 250)
})

async function save() {
	formError.value = ''
	if (hasInvalidVideoChapters()) {
		formError.value = 'Заполните описание и время каждого таймкода в формате 05:30.'
		return
	}
	const data: Record<string, unknown> = { ...form.value }
	data.storagePath = JSON.stringify({
		files: mediaFiles.value.map((file) => ({
			...file,
			chapters: serializeVideoChapters(file),
			guestAccess: file.guestAccess ?? 'visible',
		})),
		guestAccess: form.value.guestAccess,
	})
	data.guestAccess = undefined
	data.fileSizeBytes = undefined

	if (editItem.value) {
		if (!form.value.fullDescription.trim()) {
			data.fullDescription = null
		}
	}
	if (editItem.value && !form.value.imageUrl.trim()) {
		data.imageUrl = null
	}
	if (editItem.value && !form.value.videoCoverUrl.trim()) {
		data.videoCoverUrl = null
	}
	if (editItem.value && !form.value.mediaType.trim()) {
		data.mediaType = null
	}
	if (editItem.value && !form.value.subsection.trim()) {
		data.subsection = null
	}
	for (const key of Object.keys(data)) {
		if (data[key] === undefined) delete data[key]
		if (!editItem.value && data[key] === '') delete data[key]
	}

	if (editItem.value) {
		const res = await api.patch(`/api/admin/materials/${editItem.value.id}`, data)
		if (!res.success) {
			formError.value = res.error.message
			return
		}
	} else {
		const res = await api.post('/api/admin/materials', data)
		if (!res.success) {
			formError.value = res.error.message
			return
		}
	}
	showForm.value = false
	await Promise.all([loadMaterials(), loadSubsectionOptions(), loadMaterialTypeOptions()])
}

async function remove(id: number) {
	if (!confirm('Удалить материал?')) return
	await api.delete(`/api/admin/materials/${id}`)
	await loadMaterials()
}

function getMediaIcon(type: string) {
	if (type === 'video') return 'V'
	if (type === 'audio') return 'A'
	if (type === 'document') return 'D'
	return 'F'
}

function getMaterialTypeLabel(type: string) {
	return materialTypeLabelByKey.value.get(type) ?? type
}

function resetFilters() {
	searchQuery.value = ''
	filterType.value = 'all'
	filterMedia.value = 'all'
	filterStatus.value = 'all'
	filterComments.value = 'all'
	filterSubsection.value = 'all'
	sortBy.value = 'createdDesc'
}

function formatMaterialDate(value: string | Date | null | undefined) {
	if (!value) return ''
	return new Date(value).toLocaleDateString('ru-RU', {
		day: '2-digit',
		month: 'short',
		year: 'numeric',
	})
}
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
			<div>
				<p class="text-[11px] uppercase tracking-[0.22em] text-primary-500/80">Реестр контента</p>
				<h1 class="mt-2 text-2xl font-bold dark:text-white">Материалы</h1>
			</div>
			<button class="btn-primary" @click="openCreate">
				+ Добавить
			</button>
		</div>

		<div class="glass mb-5 rounded-3xl p-4 sm:p-5">
			<div class="grid gap-3 xl:grid-cols-[minmax(0,1.6fr)_repeat(5,minmax(0,1fr))]">
				<label class="relative block">
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Поиск по названию</span>
					<input
						v-model="searchQuery"
						type="text"
						class="glass-input"
						placeholder="Начните вводить название материала"
					/>
				</label>

				<label>
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Раздел</span>
					<select v-model="filterType" class="glass-input">
						<option value="all">Все разделы</option>
						<option v-for="opt in allTypeOptions" :key="opt.key" :value="opt.key">{{ opt.label }}</option>
					</select>
				</label>

				<label>
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Медиа</span>
					<select v-model="filterMedia" class="glass-input">
						<option value="all">Любое</option>
						<option value="video">Видео</option>
						<option value="audio">Аудио</option>
						<option value="image">Изображение</option>
						<option value="document">Документ</option>
						<option value="text">Текст</option>
						<option value="none">Без медиа</option>
					</select>
				</label>

				<label>
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Статус</span>
					<select v-model="filterStatus" class="glass-input">
						<option value="all">Все</option>
						<option value="active">Активные</option>
						<option value="inactive">Выключенные</option>
					</select>
				</label>

				<label>
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Комментарии</span>
					<select v-model="filterComments" class="glass-input">
						<option value="all">Все</option>
						<option value="enabled">Включены</option>
						<option value="disabled">Выключены</option>
					</select>
				</label>

				<label>
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Порядок</span>
					<select v-model="sortBy" class="glass-input">
						<option value="createdDesc">Сначала новые</option>
						<option value="createdAsc">Сначала старые</option>
						<option value="titleAsc">Название А-Я</option>
						<option value="titleDesc">Название Я-А</option>
						<option value="typeAsc">По разделу</option>
					</select>
				</label>
			</div>

			<div class="mt-3 flex flex-wrap items-center gap-2">
				<label class="min-w-0 flex-1 sm:min-w-[220px] sm:max-w-xs">
					<span class="mb-2 block text-[11px] font-medium uppercase tracking-[0.2em] text-gray-500 dark:text-gray-400">Подраздел</span>
					<select v-model="filterSubsection" class="glass-input">
						<option value="all">Все подразделы</option>
						<option value="none">Без подраздела</option>
						<option v-for="sub in existingSubsections" :key="sub" :value="sub">{{ sub }}</option>
					</select>
				</label>
				<div class="flex w-full flex-wrap items-center gap-2 sm:ml-auto sm:w-auto">
					<div class="rounded-2xl border border-white/10 bg-black/10 px-3 py-2 text-xs text-gray-500 dark:text-gray-400">
						Фильтров активно: <span class="font-semibold text-gray-900 dark:text-white">{{ activeFilterCount }}</span>
					</div>
					<button class="btn-secondary" @click="showSectionManager = true">Разделы</button>
					<button class="btn-secondary" @click="resetFilters">Сбросить</button>
				</div>
			</div>
		</div>

		<Teleport to="body">
			<Transition name="backdrop">
				<div v-if="showSectionManager" class="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm" @click="showSectionManager = false" />
			</Transition>
			<Transition name="modal">
				<div v-if="showSectionManager" class="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
					<div class="glass max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-3xl p-6 shadow-2xl pointer-events-auto mx-4">
						<div class="mb-5 flex items-start justify-between gap-4">
							<div>
								<p class="text-[11px] uppercase tracking-[0.22em] text-primary-500/80">Структура</p>
								<h2 class="mt-2 text-lg font-semibold dark:text-white">Разделы материалов</h2>
							</div>
							<button class="btn-secondary" @click="showSectionManager = false">Закрыть</button>
						</div>

						<div class="grid gap-5 lg:grid-cols-2">
							<section class="rounded-3xl border border-white/10 bg-white/50 p-4 dark:bg-white/[0.03]">
								<div class="mb-4">
									<h3 class="font-semibold text-gray-900 dark:text-white">Верхние разделы</h3>
								</div>
								<div class="mb-4 flex gap-2">
									<input v-model="newTypeLabel" class="glass-input" placeholder="Новый раздел" />
									<button class="btn-primary shrink-0" :disabled="!newTypeLabel.trim()" @click="addCustomType">
										Добавить
									</button>
								</div>
								<p v-if="typeError" class="mb-3 text-xs text-red-300">{{ typeError }}</p>
								<div v-if="materialTypesLoading" class="py-6 text-sm text-gray-500 dark:text-gray-400">
									Загрузка...
								</div>
								<div v-else class="space-y-2">
									<div
										v-for="item in materialTypeOptions"
										:key="item.key"
										class="rounded-2xl border border-gray-200/70 bg-white/60 p-3 dark:border-white/10 dark:bg-black/10"
									>
										<div v-if="editingTypeKey === item.key" class="flex gap-2">
											<input v-model="editingTypeLabel" class="glass-input !py-2 text-sm" />
											<button class="btn-primary !px-3 !py-2 text-xs" @click="saveTypeLabel(item.key)">Ок</button>
											<button class="btn-secondary !px-3 !py-2 text-xs" @click="cancelEditType">Отмена</button>
										</div>
										<div v-else class="flex items-center gap-3">
											<div class="min-w-0 flex-1">
												<p class="truncate text-sm font-medium text-gray-900 dark:text-white">{{ item.label }}</p>
												<p class="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
													{{ item.usedCount }} материалов
												</p>
											</div>
											<button class="btn-secondary !px-3 !py-2 text-xs" @click="startEditType(item)">Править</button>
											<button
												class="btn-secondary !px-3 !py-2 text-xs"
												:disabled="item.system"
												:title="item.system ? 'Базовый раздел' : 'Удалить раздел'"
												@click="deleteMaterialType(item)"
											>
												Удалить
											</button>
										</div>
									</div>
								</div>
							</section>

							<section class="rounded-3xl border border-white/10 bg-white/50 p-4 dark:bg-white/[0.03]">
								<div class="mb-4">
									<h3 class="font-semibold text-gray-900 dark:text-white">Подразделы</h3>
								</div>
								<div class="mb-4 flex gap-2">
									<input v-model="newSubsection" class="glass-input" placeholder="Новый подраздел" />
									<button class="btn-primary shrink-0" :disabled="!newSubsection.trim()" @click="addCustomSubsection">
										Добавить
									</button>
								</div>
								<p v-if="subsectionError" class="mb-3 text-xs text-red-300">{{ subsectionError }}</p>
								<div class="space-y-2">
									<div
										v-for="sub in existingSubsections"
										:key="`manage-sub-${sub}`"
										class="rounded-2xl border border-gray-200/70 bg-white/60 p-3 dark:border-white/10 dark:bg-black/10"
									>
										<div v-if="editingSubsectionTitle === sub" class="flex gap-2">
											<input v-model="editingSubsectionLabel" class="glass-input !py-2 text-sm" />
											<button class="btn-primary !px-3 !py-2 text-xs" @click="saveSubsectionTitle(sub)">Ок</button>
											<button class="btn-secondary !px-3 !py-2 text-xs" @click="cancelEditSubsection">Отмена</button>
										</div>
										<div v-else class="flex items-center gap-3">
											<p class="min-w-0 flex-1 truncate text-sm font-medium text-gray-900 dark:text-white">{{ sub }}</p>
											<button class="btn-secondary !px-3 !py-2 text-xs" @click="startEditSubsection(sub)">Править</button>
											<button class="btn-secondary !px-3 !py-2 text-xs" @click="deleteSubsection(sub)">Удалить</button>
										</div>
									</div>
									<div v-if="existingSubsections.length === 0" class="py-6 text-sm text-gray-500 dark:text-gray-400">
										Подразделов пока нет.
									</div>
								</div>
							</section>
						</div>
					</div>
				</div>
			</Transition>
		</Teleport>

		<!-- Form modal -->
		<Teleport to="body">
			<Transition name="backdrop">
				<div v-if="showForm" class="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm" @click="showForm = false" />
			</Transition>
			<Transition name="modal">
				<div v-if="showForm" class="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
					<div class="glass rounded-3xl p-6 w-full max-w-2xl mx-4 shadow-2xl max-h-[90vh] overflow-y-auto pointer-events-auto">
						<h2 class="text-lg font-semibold mb-5 dark:text-white">
							{{ editItem ? 'Редактировать' : 'Новый материал' }}
						</h2>
						<p v-if="formError" class="mb-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
							{{ formError }}
						</p>
						<div class="space-y-4">
							<div class="float-label">
								<input v-model="form.title" class="glass-input" placeholder=" " />
								<label>Название</label>
							</div>

							<!-- Type with + button -->
							<div class="flex gap-2 items-start">
								<div class="float-label flex-1">
									<select v-model="form.type" class="glass-input">
										<option value="">Выберите раздел</option>
										<option v-for="opt in allTypeOptions" :key="opt.key" :value="opt.key">{{ opt.label }}</option>
									</select>
									<label>Раздел</label>
								</div>
								<button
									type="button"
									class="mt-1 w-10 h-10 rounded-xl border border-gray-200/60 dark:border-white/10 bg-white/50 dark:bg-white/5 flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-primary-50 dark:hover:bg-primary-500/10 hover:text-primary-600 dark:hover:text-primary-400 transition-all duration-200 flex-shrink-0"
									title="Добавить раздел"
									@click="showNewType = !showNewType"
								>
									<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
									</svg>
								</button>
							</div>
							<!-- New type form -->
							<div v-if="showNewType" class="rounded-2xl border border-primary-200/40 dark:border-primary-500/20 bg-primary-50/30 dark:bg-primary-500/5 p-3 space-y-2">
								<div class="float-label">
									<input v-model="newTypeLabel" class="glass-input !py-2 text-xs" placeholder=" " />
									<label>Название раздела</label>
								</div>
								<button class="btn-primary !py-1.5 !px-3 !text-xs" :disabled="!newTypeLabel.trim()" @click="addCustomType">
									Добавить раздел
								</button>
							</div>

							<div class="float-label">
								<textarea v-model="form.fullDescription" rows="3" class="glass-input resize-none" placeholder=" " />
								<label>Описание</label>
							</div>
							<div class="float-label">
								<input v-model="form.telegramPostUrl" type="url" class="glass-input" placeholder=" " />
								<label>Ссылка в карточке</label>
							</div>

							<div class="rounded-[24px] border border-amber-400/20 bg-amber-500/[0.06] p-4">
								<div>
									<p class="text-sm font-semibold text-gray-900 dark:text-white">Предпросмотр для неучастников</p>
									<p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Работает, когда в настройках выбран режим «Открывать карточки с ограничениями».</p>
								</div>
								<div class="mt-3 grid gap-3 sm:grid-cols-3">
									<label class="text-xs text-gray-600 dark:text-gray-300">Обложка<select v-model="form.guestAccess.cover" class="glass-input mt-1 !py-2 text-sm"><option value="visible">Показать</option><option value="blurred">Размыть</option><option value="locked">Скрыть с замком</option></select></label>
									<label class="text-xs text-gray-600 dark:text-gray-300">Текст<select v-model="form.guestAccess.description" class="glass-input mt-1 !py-2 text-sm"><option value="visible">Показать</option><option value="blurred">Размыть</option><option value="locked">Скрыть с замком</option></select></label>
									<label class="text-xs text-gray-600 dark:text-gray-300">Ссылка<select v-model="form.guestAccess.link" class="glass-input mt-1 !py-2 text-sm"><option value="visible">Показать</option><option value="blurred">Размыть</option><option value="locked">Скрыть с замком</option></select></label>
								</div>
							</div>

							<!-- Subsection with + button -->
							<div class="flex gap-2 items-start">
								<div ref="subsectionDropdownRef" class="float-label relative flex-1">
									<button
										type="button"
										class="glass-input flex w-full items-center justify-between text-left"
										@click="toggleSubsectionDropdown"
									>
										<span class="truncate pr-3">{{ currentSubsectionLabel }}</span>
										<svg
											class="h-4 w-4 shrink-0 transition-transform"
											:class="showSubsectionDropdown ? 'rotate-180' : ''"
											fill="none"
											stroke="currentColor"
											viewBox="0 0 24 24"
										>
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
										</svg>
									</button>
									<label>Подраздел</label>
									<div
										v-if="showSubsectionDropdown"
										class="absolute left-0 right-0 top-[calc(100%+8px)] z-30 overflow-hidden rounded-2xl border border-white/10 bg-[#16161d] shadow-2xl"
									>
										<button
											type="button"
											class="flex w-full items-center justify-between px-4 py-3 text-left text-sm text-gray-200 transition hover:bg-white/5"
											@click="clearSubsection"
										>
											<span>— Без подраздела —</span>
										</button>
										<div v-if="existingSubsections.length" class="max-h-64 overflow-y-auto">
											<div
												v-for="sub in existingSubsections"
												:key="`sub-option-${sub}`"
												class="group flex items-center gap-2 px-4 py-3 text-sm text-gray-200 transition hover:bg-white/5"
											>
												<button
													type="button"
													class="min-w-0 flex-1 truncate text-left"
													@click="selectSubsection(sub)"
												>
													{{ sub }}
												</button>
												<button
													type="button"
													class="shrink-0 text-gray-500 opacity-0 transition hover:text-red-300 group-hover:opacity-100"
													:title="`Удалить ${sub}`"
													@click.stop="deleteSubsection(sub)"
												>
													<svg class="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
														<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
													</svg>
												</button>
											</div>
										</div>
									</div>
								</div>
								<button
									type="button"
									class="mt-1 w-10 h-10 rounded-xl border border-gray-200/60 dark:border-white/10 bg-white/50 dark:bg-white/5 flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-primary-50 dark:hover:bg-primary-500/10 hover:text-primary-600 dark:hover:text-primary-400 transition-all duration-200 flex-shrink-0"
									title="Добавить подраздел"
									@click="showNewSubsection = !showNewSubsection"
								>
									<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
										<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
									</svg>
								</button>
							</div>
							<!-- New subsection form -->
							<div v-if="showNewSubsection" class="rounded-2xl border border-primary-200/40 dark:border-primary-500/20 bg-primary-50/30 dark:bg-primary-500/5 p-3 flex gap-2">
								<div class="float-label flex-1">
									<input v-model="newSubsection" class="glass-input !py-2 text-xs" placeholder=" " />
									<label>Новый подраздел</label>
								</div>
								<button class="btn-primary !py-1.5 !px-3 !text-xs self-end" :disabled="!newSubsection.trim()" @click="addCustomSubsection">
									Ок
								</button>
							</div>
							<p v-if="subsectionError" class="text-xs text-red-300">
								{{ subsectionError }}
							</p>

							<!-- Cover -->
							<div>
								<p class="text-xs text-gray-500 dark:text-gray-400 mb-2">Обложка карточки</p>
								<div
									v-if="form.imageUrl"
									class="mb-2 rounded-2xl overflow-hidden border border-gray-200/30 dark:border-white/10"
								>
									<img :src="form.imageUrl" alt="Обложка" class="w-full h-40 object-cover" />
								</div>
								<div
									v-else
									class="mb-2 h-40 rounded-2xl overflow-hidden border border-gray-200/30 dark:border-white/10 bg-gradient-to-br flex items-center justify-center"
									:class="getFallbackCoverGradient(form.type)"
								>
									<svg
										class="w-10 h-10 text-white/50"
										fill="none"
										stroke="currentColor"
										viewBox="0 0 24 24"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											stroke-width="1.8"
											d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
										/>
									</svg>
								</div>
								<div class="flex flex-wrap gap-2">
									<label class="btn-secondary inline-flex items-center gap-2 cursor-pointer">
										<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
										</svg>
										{{ uploadingCover ? 'Загрузка...' : 'Загрузить обложку' }}
										<input type="file" accept="image/*" class="hidden" :disabled="uploadingCover" @change="uploadCover" />
									</label>
									<button
										v-if="form.imageUrl"
										type="button"
										class="btn-secondary"
										@click="removeCover"
									>
										Удалить обложку
									</button>
								</div>
								<p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
									Эта обложка показывается в списках карточек и сверху внутри материала.
								</p>
							</div>

							<div v-if="canAssignVideoCover">
								<p class="text-xs text-gray-500 dark:text-gray-400 mb-2">Обложка видео</p>
								<div
									v-if="form.videoCoverUrl"
									class="mb-2 rounded-2xl overflow-hidden border border-gray-200/30 dark:border-white/10"
								>
									<img :src="form.videoCoverUrl" alt="Обложка видео" class="w-full aspect-video object-cover" />
								</div>
								<div
									v-else
									class="mb-2 aspect-video rounded-2xl overflow-hidden border border-dashed border-gray-200/40 dark:border-white/10 bg-black/20 flex items-center justify-center text-xs text-gray-500 dark:text-gray-400"
								>
									Отдельная обложка для видеоплеера не задана
								</div>
								<div class="flex flex-wrap gap-2">
									<label class="btn-secondary inline-flex items-center gap-2 cursor-pointer">
										<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
										</svg>
										{{ uploadingVideoCover ? 'Загрузка...' : 'Загрузить обложку видео' }}
										<input type="file" accept="image/*" class="hidden" :disabled="uploadingVideoCover" @change="uploadVideoCover" />
									</label>
									<button
										v-if="form.videoCoverUrl"
										type="button"
										class="btn-secondary"
										@click="removeVideoCover"
									>
										Удалить обложку видео
									</button>
								</div>
								<p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
									Эта обложка используется как постер видео. Если её нет, используется обложка карточки.
								</p>
							</div>

							<div class="rounded-[28px] border border-white/10 bg-black/10 p-4 space-y-4">
								<div class="flex items-center justify-between gap-3">
									<div class="text-sm font-medium text-gray-900 dark:text-white">Файлы</div>
								</div>

								<button
									type="button"
									class="flex w-full items-center justify-center rounded-[24px] border border-dashed border-white/15 bg-white/[0.03] px-4 py-4 text-sm font-medium text-gray-200 transition hover:border-primary-400/40 hover:bg-primary-500/8 hover:text-white"
									@click="openMediaPicker(mediaLibraryFilter === 'all' ? 'image' : mediaLibraryFilter)"
								>
									Добавить медиа +
								</button>

								<div v-if="mediaFiles.length === 0" class="rounded-3xl border border-dashed border-white/10 px-4 py-8 text-center text-sm text-gray-500 dark:text-gray-400">
									Пока пусто
								</div>

								<div v-else class="space-y-3">
									<div
										v-for="(mf, idx) in mediaFiles"
										:key="`${mf.path}-${idx}`"
										:data-media-index="idx"
										class="rounded-[24px] border border-white/10 bg-black/20 p-3 transition-colors"
										:class="draggingMediaIndex === idx ? 'border-primary-400/50 bg-primary-500/10' : ''"
									>
										<div class="flex items-start gap-3">
											<button
												type="button"
												class="mt-2 flex shrink-0 cursor-grab touch-none items-center justify-center text-gray-500 transition hover:text-white active:cursor-grabbing"
												title="Переместить"
												@pointerdown="startMediaDrag($event, idx)"
											>
												<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 6h.01M8 12h.01M8 18h.01M16 6h.01M16 12h.01M16 18h.01" />
												</svg>
											</button>

											<div class="min-w-0 flex-1 space-y-2">
												<div class="flex flex-wrap items-center gap-2">
													<div class="min-w-0 flex-1 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-2">
														<input
															v-if="editingMediaPath === mf.path"
															v-model="mf.displayName"
															type="text"
															class="w-full bg-transparent text-sm text-white outline-none placeholder:text-gray-500"
															placeholder="Имя файла"
															@blur="stopEditingMediaName"
															@keydown.enter.prevent="stopEditingMediaName"
															@keydown.esc.prevent="stopEditingMediaName"
														/>
														<div v-else class="truncate text-sm text-gray-100">
															{{ getMediaDisplayName(mf) }}
														</div>
													</div>
													<button
														type="button"
														class="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-gray-300 transition hover:border-primary-400/40 hover:text-white"
														title="Изменить имя"
														@click="startEditingMediaName(mf.path)"
													>
														<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
															<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536M9 11l6.768-6.768a2.5 2.5 0 113.536 3.536L12.536 14.536A4 4 0 019.708 15.7L8 16l.3-1.708A4 4 0 019 11z" />
														</svg>
													</button>
													<button
														v-if="mf.type === 'video'"
														type="button"
														class="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-gray-200"
														@click="toggleVideoExpanded(mf.path)"
													>
														{{ isVideoExpanded(mf.path) ? 'Скрыть видео' : 'Показать видео' }}
													</button>
													<button
														type="button"
														class="flex h-8 w-8 items-center justify-center text-gray-500 transition hover:text-red-400"
														title="Удалить файл"
														@click="removeMedia(idx)"
													>
														<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
															<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6M9 7V4a1 1 0 011-1h4a1 1 0 011 1v3m-7 0h8" />
														</svg>
													</button>
												</div>

												<audio
													v-if="mf.type === 'audio' && mf.url"
													:src="mf.url"
													class="w-full"
													controls
													preload="none"
												/>

										<video
											v-else-if="mf.type === 'video' && mf.url && isVideoExpanded(mf.path)"
													:src="mf.url"
													class="h-44 w-full rounded-2xl bg-black/40"
													controls
											preload="metadata"
										/>

										<div v-if="mf.type === 'video'" class="rounded-2xl border border-white/10 bg-white/[0.025] p-3">
											<label class="flex items-center gap-2 text-xs font-medium text-gray-100">
												<input :checked="Boolean(mf.chapters)" type="checkbox" class="glass-check" @change="toggleVideoChapters(mf)" />
												Таймкоды
											</label>

											<div v-if="mf.chapters" class="mt-3 space-y-2.5">
												<label class="flex items-center gap-2 text-xs text-gray-300">
													<input v-model="mf.chapters.collapsible" type="checkbox" class="glass-check" />
													Сворачиваемый
												</label>
												<div v-if="mf.chapters.items.length" class="space-y-2">
													<div v-for="(chapter, chapterIndex) in mf.chapters.items" :key="`${mf.path}-chapter-${chapterIndex}`" class="grid gap-2 sm:grid-cols-[6.5rem_minmax(0,1fr)_2rem]">
														<input v-model="chapter.time" type="text" inputmode="numeric" pattern="\\d{1,3}:[0-5]\\d" maxlength="6" class="glass-input !py-2 text-sm" placeholder="05:30" aria-label="Время таймкода" />
														<input v-model="chapter.description" type="text" class="glass-input !py-2 text-sm" placeholder="Например, основы вайбкодинга" aria-label="Описание таймкода" />
														<button type="button" class="flex h-9 w-9 items-center justify-center self-center text-gray-500 transition hover:text-red-400" title="Удалить таймкод" @click="removeVideoChapter(mf, chapterIndex)">
															<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m6 6 12 12M18 6 6 18" /></svg>
														</button>
													</div>
												</div>
												<button type="button" class="rounded-xl border border-primary-400/30 bg-primary-500/10 px-3 py-2 text-xs font-medium text-primary-200 transition hover:bg-primary-500/20" @click="addVideoChapter(mf)">Добавить таймкод</button>
											</div>
										</div>

										<div v-if="mf.type === 'image'" class="flex flex-wrap gap-2">
													<button
														type="button"
														class="rounded-xl bg-black/70 px-3 py-2 text-xs font-medium text-white"
														@click="applyMediaImageAsCover('card', mf.url)"
													>
														На карточку
													</button>
													<button
														v-if="canAssignVideoCover"
														type="button"
														class="rounded-xl bg-black/70 px-3 py-2 text-xs font-medium text-white"
														@click="applyMediaImageAsCover('video', mf.url)"
													>
														На видео
													</button>
												</div>

												<label class="flex items-center gap-2 text-xs text-gray-300">
													<input
														v-model="mf.downloadable"
														type="checkbox"
														class="glass-check"
													/>
													Разрешить скачивание
												</label>
												<label class="block text-xs text-gray-300">
													Для неучастников
													<select v-model="mf.guestAccess" class="glass-input mt-1 !py-2 text-sm">
														<option value="visible">Показать</option>
														<option value="blurred">Размыть</option>
														<option value="locked">Скрыть с замком</option>
													</select>
												</label>
											</div>
										</div>
									</div>
								</div>
							</div>

							<label class="flex items-center gap-2 text-sm dark:text-gray-300">
								<input v-model="form.active" type="checkbox" class="glass-check" /> Активен
							</label>
							<label class="flex items-center gap-2 text-sm dark:text-gray-300">
								<input v-model="form.commentsEnabled" type="checkbox" class="glass-check" /> Комментарии включены
							</label>
						</div>
						<div class="flex gap-2 mt-5">
							<button class="btn-secondary flex-1" @click="showForm = false">Отмена</button>
							<button
								class="btn-primary flex-1"
								:disabled="!form.title || !form.type"
								@click="save"
							>
								Сохранить
							</button>
						</div>
					</div>
				</div>
			</Transition>

			<Transition name="backdrop">
				<div v-if="showMediaPicker" class="fixed inset-0 z-[60] bg-black/55 backdrop-blur-sm" @click="closeMediaPicker" />
			</Transition>
			<Transition name="modal">
				<div v-if="showMediaPicker" class="fixed inset-0 z-[70] flex items-center justify-center p-4 pointer-events-none">
					<div class="glass w-full max-w-[1440px] rounded-[32px] border border-white/10 bg-[#161616]/95 shadow-2xl max-h-[90vh] overflow-y-auto pointer-events-auto">
						<div class="sticky top-0 z-20 border-b border-white/10 bg-[#161616]/95 px-5 py-5 backdrop-blur">
							<div class="flex flex-col gap-4">
								<div class="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
									<div>
										<h3 class="text-lg font-semibold text-white">Добавить медиа</h3>
										<p class="mt-1 text-sm text-gray-400">
											Выбирайте несколько файлов сразу. Поиск работает по названию, описанию и имени файла.
										</p>
									</div>
									<div class="flex items-center gap-2 self-end xl:self-start">
										<button
											type="button"
											class="btn-primary whitespace-nowrap"
											:disabled="selectedMediaLibraryCount === 0"
											@click="addSelectedMediaFromLibrary"
										>
											Добавить<span v-if="selectedMediaLibraryCount"> · {{ selectedMediaLibraryCount }}</span>
										</button>
										<button
											type="button"
											class="flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-gray-300 transition hover:text-white"
											@click="closeMediaPicker"
										>
											&times;
										</button>
									</div>
								</div>

								<div class="flex flex-wrap gap-2">
									<button
										v-for="filter in mediaPickerTabs"
										:key="filter"
										type="button"
										class="rounded-2xl px-4 py-2 text-sm font-medium transition-all"
										:class="mediaLibraryFilter === filter
											? 'bg-primary-500 text-white shadow-lg shadow-primary-500/20'
											: 'border border-white/10 bg-black/20 text-gray-400 hover:text-white'"
										@click="selectMediaPickerTab(filter)"
									>
										{{ mediaLibraryFilterLabels[filter] }}
									</button>
								</div>

								<div class="grid gap-3 xl:grid-cols-[auto,minmax(0,1fr),200px,180px,180px]">
									<label class="btn-secondary inline-flex cursor-pointer items-center justify-center whitespace-nowrap">
										<span>{{ uploading ? `Загрузка ${mediaUploadProgress.overallPercent}%` : 'Загрузить' }}</span>
										<input
											type="file"
											:accept="mediaPickerAccept"
											multiple
											class="hidden"
											:disabled="uploading"
											@change="uploadMediaFile"
										/>
									</label>
									<input
										v-model="mediaLibrarySearchDraft"
										type="text"
										class="glass-input"
										placeholder="Поиск по названию, описанию и имени файла"
									/>
									<select v-model="mediaPickerSortBy" class="glass-input">
										<option v-for="option in mediaPickerSortOptions" :key="option.value" :value="option.value">
											{{ option.label }}
										</option>
									</select>
									<select v-model="mediaPickerSortDir" class="glass-input">
										<option value="asc">Сначала вверх</option>
										<option value="desc">Сначала вниз</option>
									</select>
									<select v-model="mediaPickerViewMode" class="glass-input">
										<option v-for="(label, value) in mediaPickerViewLabels" :key="value" :value="value">
											{{ label }}
										</option>
									</select>
								</div>

								<div
									v-if="uploading"
									class="rounded-[22px] border border-primary-400/20 bg-primary-500/10 px-4 py-3 text-sm text-white"
								>
									<div class="flex flex-wrap items-start justify-between gap-3">
										<div class="min-w-0">
											<p class="font-semibold">
												Загрузка {{ mediaUploadProgress.currentIndex }} из {{ mediaUploadProgress.totalFiles }}
											</p>
											<p class="mt-1 truncate text-xs text-gray-400">
												{{ mediaUploadProgress.currentName }}
											</p>
										</div>
										<div class="text-right">
											<p class="text-base font-bold text-primary-200">
												{{ mediaUploadProgress.overallPercent }}%
											</p>
											<p class="text-xs text-gray-400">
												{{ mediaUploadProgress.currentPercent }}% файла
											</p>
										</div>
									</div>
									<div class="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
										<div
											class="h-full rounded-full bg-primary-500 transition-[width] duration-200 ease-out"
											:style="{ width: `${mediaUploadProgress.overallPercent}%` }"
										/>
									</div>
									<p class="mt-2 text-xs text-gray-400">
										{{ formatUploadProgressSize(mediaUploadProgress.loadedBytes) }} из
										{{ formatUploadProgressSize(mediaUploadProgress.totalBytes) }}
									</p>
								</div>
							</div>
						</div>

						<div class="px-5 py-5">
							<div v-if="mediaLibraryLoading" class="py-10 text-center text-sm text-gray-500 dark:text-gray-400">Загружаю медиатеку...</div>
							<div v-else-if="mediaLibraryItems.length === 0" class="rounded-[24px] border border-dashed border-white/10 px-4 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
								Для выбранного раздела файлов пока нет.
							</div>

							<div
								v-else-if="mediaPickerViewMode === 'cards'"
								class="grid gap-3 md:grid-cols-2 xl:grid-cols-4"
							>
								<button
									v-for="item in mediaLibraryItems"
									:key="item.key"
									type="button"
									class="group relative rounded-[24px] border p-3 text-left transition-all"
									:class="selectedMediaPaths.has(item.key)
										? 'cursor-not-allowed border-white/10 bg-white/[0.03] opacity-55'
										: isMediaLibrarySelected(item)
											? 'border-primary-400/60 bg-primary-500/12 shadow-lg shadow-primary-500/10'
											: 'border-white/10 bg-black/20 hover:border-primary-400/30 hover:bg-white/[0.04]'"
									@click="toggleMediaLibrarySelection(item)"
								>
									<div class="absolute right-3 top-3">
										<div
											v-if="selectedMediaPaths.has(item.key)"
											class="rounded-full border border-white/10 bg-black/50 px-2 py-1 text-[10px] font-medium text-gray-300"
										>
											Уже в карточке
										</div>
										<div
											v-else
											class="flex h-6 w-6 items-center justify-center rounded-full border text-xs transition"
											:class="isMediaLibrarySelected(item)
												? 'border-primary-300 bg-primary-500 text-white'
												: 'border-white/15 bg-black/45 text-transparent group-hover:text-white/70'"
										>
											✓
										</div>
									</div>

									<div class="flex h-40 items-center justify-center overflow-hidden rounded-[20px] border border-white/10 bg-white/5">
										<img v-if="item.type === 'image'" :src="item.url" alt="" class="h-full w-full object-cover" />
										<div
											v-else-if="item.type === 'video'"
											class="flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_center,rgba(148,163,184,0.18),transparent_58%),linear-gradient(180deg,rgba(24,24,27,0.12),rgba(24,24,27,0.82))] text-white/80"
										>
											<div class="flex flex-col items-center gap-2">
												<svg class="h-9 w-9" fill="none" stroke="currentColor" viewBox="0 0 24 24">
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M7 5.75A1.75 1.75 0 018.75 4h6.5A1.75 1.75 0 0117 5.75v12.5A1.75 1.75 0 0115.25 20h-6.5A1.75 1.75 0 017 18.25V5.75z" />
													<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M10.5 9.75v4.5L14 12l-3.5-2.25z" />
												</svg>
												<span class="text-xs uppercase tracking-[0.18em]">Видео</span>
											</div>
										</div>
										<div v-else class="flex items-center justify-center text-gray-400 dark:text-gray-500">
											<svg
												v-if="item.type === 'audio'"
												class="h-9 w-9"
												fill="none"
												stroke="currentColor"
												viewBox="0 0 24 24"
											>
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M9 18V5l10-2v13M9 9l10-2M6 20a2 2 0 100-4 2 2 0 000 4zm10-2a2 2 0 100-4 2 2 0 000 4z" />
											</svg>
											<svg
												v-else
												class="h-9 w-9"
												fill="none"
												stroke="currentColor"
												viewBox="0 0 24 24"
											>
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M7 3h7l5 5v13a1 1 0 01-1 1H7a2 2 0 01-2-2V5a2 2 0 012-2z" />
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M14 3v5h5" />
											</svg>
										</div>
									</div>

									<div class="mt-3 min-w-0">
										<p class="truncate text-sm font-medium text-white">{{ item.title || item.name }}</p>
										<p v-if="item.note?.trim()" class="mt-1 line-clamp-2 text-xs text-gray-300">
											{{ item.note }}
										</p>
										<p class="mt-1 truncate text-xs text-gray-500">{{ item.name }}</p>
										<p class="mt-2 text-[11px] text-gray-400">
											{{ formatMediaLibraryDate(item.lastModified) }}
											<span v-if="item.size"> · {{ formatMediaLibrarySize(item.size) }}</span>
										</p>
									</div>

									<audio
										v-if="item.type === 'audio'"
										:src="item.url"
										class="mt-3 w-full"
										controls
										preload="none"
										@click.stop
									/>
								</button>
							</div>

							<div v-else class="overflow-hidden rounded-[24px] border border-white/10">
								<button
									v-for="item in mediaLibraryItems"
									:key="item.key"
									type="button"
									class="flex w-full items-center gap-4 border-b border-white/10 bg-black/20 px-4 py-3 text-left transition last:border-b-0 hover:bg-white/[0.04]"
									:class="selectedMediaPaths.has(item.key)
										? 'cursor-not-allowed opacity-55'
										: isMediaLibrarySelected(item)
											? 'bg-primary-500/10'
											: ''"
									@click="toggleMediaLibrarySelection(item)"
								>
									<div
										class="flex h-5 w-5 shrink-0 items-center justify-center rounded-md border text-[11px]"
										:class="selectedMediaPaths.has(item.key)
											? 'border-white/10 bg-black/40 text-gray-400'
											: isMediaLibrarySelected(item)
												? 'border-primary-300 bg-primary-500 text-white'
												: 'border-white/20 text-transparent'"
									>
										✓
									</div>
									<div class="h-12 w-16 shrink-0 overflow-hidden rounded-2xl bg-white/10">
										<img v-if="item.type === 'image'" :src="item.url" :alt="item.name" class="h-full w-full object-cover" />
										<div
											v-else-if="item.type === 'video'"
											class="flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_center,rgba(148,163,184,0.18),transparent_58%),linear-gradient(180deg,rgba(24,24,27,0.12),rgba(24,24,27,0.82))] text-white/80"
										>
											<svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M7 5.75A1.75 1.75 0 018.75 4h6.5A1.75 1.75 0 0117 5.75v12.5A1.75 1.75 0 0115.25 20h-6.5A1.75 1.75 0 017 18.25V5.75z" />
												<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.7" d="M10.5 9.75v4.5L14 12l-3.5-2.25z" />
											</svg>
										</div>
										<div v-else class="flex h-full items-center justify-center text-[10px] uppercase tracking-[0.18em] text-gray-500 dark:text-gray-400">
											{{ item.type === 'audio' ? 'Аудио' : 'Файл' }}
										</div>
									</div>
									<div class="min-w-0 flex-1">
										<p class="truncate text-sm font-medium text-gray-100">{{ item.title || item.name }}</p>
										<p class="truncate text-xs text-gray-400">{{ item.note?.trim() || item.name }}</p>
									</div>
									<div class="hidden min-w-[160px] text-xs text-gray-500 lg:block">
										{{ formatMediaLibraryDate(item.lastModified) }}
									</div>
									<div class="hidden min-w-[90px] text-right text-xs text-gray-500 md:block">
										{{ formatMediaLibrarySize(item.size) }}
									</div>
									<div
										v-if="selectedMediaPaths.has(item.key)"
										class="hidden rounded-full border border-white/10 bg-black/50 px-2 py-1 text-[10px] font-medium text-gray-300 xl:block"
									>
										Уже в карточке
									</div>
								</button>
							</div>
						</div>

						<div class="px-5 pb-5 flex justify-center">
							<button
								v-if="mediaLibraryCursor"
								type="button"
								class="btn-secondary"
								:disabled="mediaLibraryLoadingMore"
								@click="loadMediaLibrary({ append: true })"
							>
								{{ mediaLibraryLoadingMore ? 'Загрузка...' : 'Показать ещё файлы' }}
							</button>
						</div>
					</div>
				</div>
			</Transition>
		</Teleport>

		<!-- Table -->
		<div class="glass glass-table rounded-2xl overflow-hidden">
			<div class="overflow-x-auto">
				<table class="w-full text-sm">
					<thead>
						<tr class="text-[10px] uppercase tracking-wider text-gray-500 dark:text-gray-400">
							<th class="px-4 py-3 text-left">ID</th>
							<th class="px-4 py-3 text-left">Название</th>
							<th class="px-4 py-3 text-left">Раздел</th>
							<th class="px-4 py-3 text-left">Подраздел</th>
							<th class="px-4 py-3 text-left">Дата</th>
							<th class="px-4 py-3 text-center">Комментарии</th>
							<th class="px-4 py-3 text-center">Активен</th>
							<th class="px-4 py-3"></th>
						</tr>
					</thead>
					<tbody class="divide-y divide-gray-100/50 dark:divide-white/5">
						<tr
							v-for="item in visibleMaterials"
							:key="item.id"
							class="cursor-pointer transition-all duration-150 hover:bg-primary-50/30 dark:hover:bg-white/5"
							@click="openEdit(item)"
						>
							<td class="px-4 py-3 align-top text-xs font-medium text-gray-400 dark:text-gray-500">#{{ item.id }}</td>
							<td class="px-4 py-3">
								<div class="flex items-center gap-3">
									<img
										v-if="(item as Record<string, unknown>).imageUrl && !hasBrokenCover(item.id)"
										:src="String((item as Record<string, unknown>).imageUrl)"
										class="w-10 h-10 rounded-xl object-cover flex-shrink-0"
										alt=""
										@error="markCoverBroken(item.id)"
									/>
									<div
										v-else
										class="w-10 h-10 rounded-xl bg-gradient-to-br flex items-center justify-center flex-shrink-0"
										:class="getFallbackCoverGradient(item.type)"
									>
										<svg class="w-5 h-5 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
										</svg>
									</div>
									<div
										v-if="(item as Record<string, unknown>).videoCoverUrl && !hasBrokenVideoCover(item.id)"
										class="w-10 h-10 rounded-xl overflow-hidden border border-white/10 flex-shrink-0"
									>
										<img
											:src="String((item as Record<string, unknown>).videoCoverUrl)"
											class="w-full h-full object-cover"
											alt=""
											@error="markVideoCoverBroken(item.id)"
										/>
									</div>
									<div class="min-w-0">
										<p class="font-medium leading-snug dark:text-white">{{ item.title }}</p>
										<p class="mt-1 text-xs text-gray-400 dark:text-gray-500">{{ item.mediaType || 'Без медиа' }}</p>
									</div>
								</div>
							</td>
							<td class="px-4 py-3 text-gray-500 dark:text-gray-400">
								{{ getMaterialTypeLabel(item.type) }}
							</td>
							<td class="px-4 py-3 text-gray-500 dark:text-gray-400">
								{{ item.subsection || '—' }}
							</td>
							<td class="px-4 py-3 text-gray-500 dark:text-gray-400">
								{{ formatMaterialDate(item.createdAt) }}
							</td>
							<td class="px-4 py-3 text-center">
								<span
									class="px-2 py-0.5 rounded-full text-xs font-medium"
									:class="(item as Record<string, unknown>).commentsEnabled
										? 'bg-sky-500/10 text-sky-600 dark:text-sky-400'
										: 'bg-gray-500/10 text-gray-500 dark:text-gray-400'"
								>
									{{ (item as Record<string, unknown>).commentsEnabled ? 'Вкл' : 'Выкл' }}
								</span>
							</td>
							<td class="px-4 py-3 text-center">
								<span
									class="px-2 py-0.5 rounded-full text-xs font-medium"
									:class="(item as Record<string, unknown>).active !== false
										? 'bg-green-500/10 text-green-600 dark:text-green-400'
										: 'bg-gray-500/10 text-gray-500 dark:text-gray-400'"
								>
									{{ (item as Record<string, unknown>).active !== false ? 'Да' : 'Нет' }}
								</span>
							</td>
							<td class="px-4 py-3">
								<div class="flex items-center justify-end gap-3">
									<button
										type="button"
										class="inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/70 text-gray-600 transition hover:bg-white dark:bg-white/[0.06] dark:text-white/80 dark:hover:bg-white/[0.12]"
										:title="copiedMaterialId === item.id ? 'Ссылка скопирована' : 'Скопировать ссылку на карточку'"
										@click.stop="copyMaterialLink(item)"
									>
										<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
											<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 17H7a4 4 0 010-8h4m-2 4h6m0 0h1a4 4 0 010 8h-4m2-4H8" />
										</svg>
									</button>
									<button class="text-primary-600 dark:text-primary-400 text-xs font-medium hover:underline" @click.stop="openEdit(item)">Ред.</button>
									<button class="text-red-500 text-xs font-medium hover:underline" @click.stop="remove(item.id)">Удал.</button>
								</div>
							</td>
						</tr>
						<tr v-if="!loading && visibleMaterials.length === 0">
							<td colspan="8" class="px-4 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
								Ничего не найдено. Измените поиск, фильтры или сортировку.
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<Teleport to="body">
			<Transition
				enter-active-class="transition duration-200 ease-out"
				enter-from-class="translate-y-3 opacity-0"
				enter-to-class="translate-y-0 opacity-100"
				leave-active-class="transition duration-150 ease-in"
				leave-from-class="translate-y-0 opacity-100"
				leave-to-class="translate-y-3 opacity-0"
			>
				<div
					v-if="copyToastMessage"
					class="pointer-events-none fixed bottom-6 left-1/2 z-[80] -translate-x-1/2 rounded-full border border-emerald-400/20 bg-emerald-500 px-4 py-2 text-sm font-medium text-white shadow-2xl shadow-emerald-950/30"
				>
					{{ copyToastMessage }}
				</div>
			</Transition>
		</Teleport>
	</div>
</template>
