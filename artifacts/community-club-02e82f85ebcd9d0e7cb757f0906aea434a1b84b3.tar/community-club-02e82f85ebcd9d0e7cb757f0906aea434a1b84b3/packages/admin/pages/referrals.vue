<script setup lang="ts">
import type {
	AdminReferralProgramAnalyticsResponse,
	ReferralProgramSettings,
} from '@community-club/shared/types'

const api = useAdminApi()

const activeTab = ref<'settings' | 'analytics'>('settings')
const loading = ref(true)
const saving = ref(false)
const error = ref('')
const message = ref('')
const analyticsLoading = ref(false)
const analytics = ref<AdminReferralProgramAnalyticsResponse | null>(null)
const referralDetailsOpen = ref(false)
const referralDetailsLoading = ref(false)
const referralDetails = ref<{
	referrer: { authUuid: string; fullName: string | null; email: string | null } | null
	totalReferred: number
	totalPaid: number
	totalBonus: number
	referrals: Array<{
		id: number
		status: string
		createdAt: string | Date
		referred: { fullName: string | null; email: string | null } | null
	}>
} | null>(null)
const form = reactive<ReferralProgramSettings>({
	enabled: false,
	description: '',
})

const today = new Date()
const from = ref(new Date(today.getTime() - 29 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10))
const to = ref(today.toISOString().slice(0, 10))

const metricCards = computed(() => {
	const totals = analytics.value?.totals
	return [
		{ label: 'Всего приглашений', value: totals?.referrals ?? 0 },
		{ label: 'Оплатили', value: totals?.paid ?? 0 },
		{ label: 'Ожидают оплаты', value: totals?.pending ?? 0 },
		{ label: 'Приглашают', value: totals?.referrers ?? 0 },
		{ label: 'Заработано, ₽', value: totals?.totalBonus ?? 0 },
	]
})

const maxDaily = computed(() =>
	Math.max(...(analytics.value?.daily ?? []).map((item) => item.referrals), 1),
)

onMounted(async () => {
	await Promise.all([loadSettings(), loadAnalytics()])
	loading.value = false
})

async function loadSettings() {
	const res = await api.get<ReferralProgramSettings>('/api/admin/referral-settings')
	if (res.success) {
		form.enabled = res.data.enabled
		form.description = res.data.description
	} else {
		error.value = res.error.message
	}
}

async function loadAnalytics() {
	analyticsLoading.value = true
	const res = await api.get<AdminReferralProgramAnalyticsResponse>(
		`/api/admin/referral-analytics?from=${from.value}&to=${to.value}`,
	)
	if (res.success) {
		analytics.value = res.data
	} else {
		error.value = res.error.message
	}
	analyticsLoading.value = false
}

async function saveSettings() {
	saving.value = true
	error.value = ''
	message.value = ''
	const res = await api.put<ReferralProgramSettings>('/api/admin/referral-settings', form)
	if (res.success) {
		form.enabled = res.data.enabled
		form.description = res.data.description
		message.value = 'Настройки сохранены'
	} else {
		error.value = res.error.message
	}
	saving.value = false
}

async function openReferralDetails(authUuid: string) {
	referralDetailsOpen.value = true
	referralDetailsLoading.value = true
	referralDetails.value = null
	const res = await api.get<typeof referralDetails.value>(`/api/admin/referrals/${authUuid}`)
	if (res.success) referralDetails.value = res.data
	else error.value = res.error.message
	referralDetailsLoading.value = false
}

function fmt(value: number) {
	return Number(value ?? 0).toLocaleString('ru-RU')
}

function formatDate(value: string | Date) {
	const parsed = new Date(value)
	if (Number.isNaN(parsed.getTime())) return String(value)
	return parsed.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' })
}

function barHeight(value: number) {
	return `${Math.max(8, Math.round((value / maxDaily.value) * 160))}px`
}
</script>

<template>
	<div class="min-h-screen bg-slate-950 p-4 text-slate-100 sm:p-6">
		<div class="mx-auto max-w-7xl space-y-6">
			<header class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
				<div>
					<p class="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Администрирование</p>
					<h1 class="mt-2 text-2xl font-semibold text-white sm:text-3xl">Рефералка</h1>
				</div>
				<button class="btn-primary w-full sm:w-auto" :disabled="saving" @click="saveSettings">
					{{ saving ? 'Сохраняем...' : 'Сохранить' }}
				</button>
			</header>

			<div class="flex flex-wrap gap-2 rounded-3xl border border-white/8 bg-[#11131b] p-2">
				<button
					type="button"
					class="rounded-2xl px-4 py-2 text-sm font-medium transition"
					:class="activeTab === 'settings' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'"
					@click="activeTab = 'settings'"
				>
					Настройки
				</button>
				<button
					type="button"
					class="rounded-2xl px-4 py-2 text-sm font-medium transition"
					:class="activeTab === 'analytics' ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'"
					@click="activeTab = 'analytics'"
				>
					Аналитика
				</button>
			</div>

			<p v-if="error" class="rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
				{{ error }}
			</p>
			<p v-if="message" class="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200">
				{{ message }}
			</p>

			<section v-if="loading" class="rounded-3xl border border-white/8 bg-[#11131b] p-6 text-slate-400">
				Загружаем...
			</section>

			<section v-else-if="activeTab === 'settings'" class="rounded-3xl border border-white/8 bg-[#11131b] p-5 sm:p-6">
				<label class="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
					<input v-model="form.enabled" type="checkbox" class="glass-check mt-1" />
					<span>
						<span class="block font-semibold text-white">Включить реферальную программу</span>
						<span class="mt-1 block text-sm leading-6 text-slate-400">
							Когда включено, блок с ссылкой появится в профиле участника.
						</span>
					</span>
				</label>

				<div class="mt-5 float-label">
					<textarea
						v-model="form.description"
						class="glass-input min-h-40 sm:min-h-32"
						maxlength="500"
						placeholder=" "
						rows="5"
						style="min-height: 10rem"
					/>
					<label>Описание в профиле</label>
				</div>
			</section>

			<section v-else class="space-y-6">
				<div class="rounded-3xl border border-white/8 bg-[#11131b] p-5 sm:p-6">
					<div class="flex flex-col gap-3 sm:flex-row sm:items-end">
						<div class="float-label">
							<input v-model="from" type="date" class="glass-input !w-auto" />
							<label>От</label>
						</div>
						<div class="float-label">
							<input v-model="to" type="date" class="glass-input !w-auto" />
							<label>До</label>
						</div>
						<button class="btn-primary" :disabled="analyticsLoading" @click="loadAnalytics">
							{{ analyticsLoading ? 'Загрузка...' : 'Показать' }}
						</button>
					</div>
				</div>

				<div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
					<div
						v-for="card in metricCards"
						:key="card.label"
						class="rounded-3xl border border-white/8 bg-[#11131b] p-5 shadow-[0_24px_60px_rgba(0,0,0,0.24)]"
					>
						<p class="text-xs font-semibold uppercase tracking-[0.12em] text-slate-500">{{ card.label }}</p>
						<p class="mt-3 text-3xl font-semibold text-white">{{ fmt(card.value) }}</p>
					</div>
				</div>

				<div class="rounded-3xl border border-white/8 bg-[#11131b] p-5 sm:p-6">
					<h2 class="text-lg font-semibold text-white">Приглашения по дням</h2>
					<div v-if="analytics?.daily.length" class="mt-6 flex h-52 items-end gap-2 overflow-x-auto pb-2">
						<div
							v-for="item in analytics.daily"
							:key="item.day"
							class="flex min-w-9 flex-1 flex-col items-center gap-2"
						>
							<div class="w-full rounded-t-xl bg-primary-400/70" :style="{ height: barHeight(item.referrals) }" />
							<span class="text-[10px] text-slate-500">{{ item.day.slice(5) }}</span>
						</div>
					</div>
					<p v-else class="mt-5 text-sm text-slate-500">За выбранный период приглашений нет.</p>
				</div>

				<div class="overflow-hidden rounded-3xl border border-white/8 bg-[#11131b]">
					<div class="border-b border-white/8 p-5 sm:p-6">
						<h2 class="text-lg font-semibold text-white">Кто сколько пригласил</h2>
					</div>
					<div class="overflow-x-auto">
						<table class="min-w-full divide-y divide-white/8 text-sm">
							<thead class="bg-white/[0.03] text-left text-xs uppercase tracking-[0.12em] text-slate-500">
								<tr>
									<th class="px-5 py-3">Участник</th>
									<th class="px-5 py-3">Приглашено</th>
									<th class="px-5 py-3">Оплатили</th>
									<th class="px-5 py-3">Заработано</th>
									<th class="px-5 py-3">Последнее</th>
								</tr>
							</thead>
							<tbody class="divide-y divide-white/8">
								<tr v-for="item in analytics?.topReferrers ?? []" :key="item.authUuid" class="cursor-pointer transition hover:bg-white/[0.035]" @click="openReferralDetails(item.authUuid)">
									<td class="px-5 py-4">
										<p class="font-medium text-white">{{ item.fullName || 'Без имени' }}</p>
										<p class="mt-1 text-xs text-slate-500">{{ item.email || item.authUuid }}</p>
									</td>
									<td class="px-5 py-4 text-white">{{ fmt(item.referrals) }}</td>
									<td class="px-5 py-4 text-emerald-300">{{ fmt(item.paid) }}</td>
									<td class="px-5 py-4 text-primary-300">{{ fmt(item.totalBonus) }} ₽</td>
									<td class="px-5 py-4 text-slate-400">{{ formatDate(item.lastReferralAt) }}</td>
								</tr>
								<tr v-if="!analytics?.topReferrers.length">
									<td colspan="5" class="px-5 py-8 text-center text-slate-500">Данных пока нет.</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</section>
		</div>

		<Teleport to="body">
			<div v-if="referralDetailsOpen" class="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" @click.self="referralDetailsOpen = false">
				<section class="max-h-[85dvh] w-full max-w-lg overflow-y-auto rounded-3xl border border-white/10 bg-[#11131b] p-5 shadow-2xl">
					<div class="flex items-start justify-between gap-4">
						<div><p class="text-xs font-semibold uppercase tracking-[0.13em] text-slate-500">Рефералы участника</p><h2 class="mt-1 text-lg font-semibold text-white">{{ referralDetails?.referrer?.fullName || 'Без имени' }}</h2><p class="text-sm text-slate-400">{{ referralDetails?.referrer?.email }}</p></div>
						<button type="button" class="rounded-full border border-white/10 px-3 py-1.5 text-sm text-slate-300" @click="referralDetailsOpen = false">Закрыть</button>
					</div>
					<p v-if="referralDetailsLoading" class="mt-6 text-sm text-slate-400">Загружаем...</p>
					<template v-else-if="referralDetails">
						<div class="mt-5 grid grid-cols-3 gap-2"><div class="rounded-2xl bg-white/[0.04] p-3"><span class="text-xs text-slate-500">Всего</span><strong class="mt-1 block text-white">{{ referralDetails.totalReferred }}</strong></div><div class="rounded-2xl bg-white/[0.04] p-3"><span class="text-xs text-slate-500">Оплатили</span><strong class="mt-1 block text-emerald-300">{{ referralDetails.totalPaid }}</strong></div><div class="rounded-2xl bg-white/[0.04] p-3"><span class="text-xs text-slate-500">Заработано</span><strong class="mt-1 block text-primary-300">{{ fmt(referralDetails.totalBonus) }} ₽</strong></div></div>
						<div class="mt-5 divide-y divide-white/8"><div v-for="item in referralDetails.referrals" :key="item.id" class="py-3"><p class="font-medium text-white">{{ item.referred?.fullName || 'Без имени' }}</p><p class="text-sm text-slate-500">{{ item.referred?.email || 'Email не указан' }}</p></div><p v-if="!referralDetails.referrals.length" class="py-3 text-sm text-slate-500">Приглашённых пока нет.</p></div>
					</template>
				</section>
			</div>
		</Teleport>
	</div>
</template>
