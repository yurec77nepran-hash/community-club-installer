<script setup lang="ts">
import type {
	AdminPaymentProviderSettings,
	AdminPaymentProviderSettingsPayload,
	PaymentCheckoutSettings,
	PaymentProviderCode,
	PaymentProviderConnection,
	PaymentRecurrentInterval,
} from '@community-club/shared/types'

type PaymentTab = 'payments' | 'logs' | 'providers'

const api = useAdminApi()
const route = useRoute()
const router = useRouter()
const tab = ref<PaymentTab>('payments')
const payments = ref<Array<Record<string, unknown>>>([])
const logs = ref<Array<Record<string, unknown>>>([])
const providerSettings = ref<AdminPaymentProviderSettings | null>(null)
const loading = ref(true)
const savingProviders = ref(false)
const providerMessage = ref('')
const providerError = ref('')

type ProviderForm = Record<
	PaymentProviderCode,
	{
		enabled: boolean
		fields: Record<string, string>
		secretFields: Record<string, string>
		clearSecrets: Record<string, boolean>
	}
>

const providerForm = reactive<ProviderForm>({
	cloudpayments: {
		enabled: true,
		fields: { publicId: '' },
		secretFields: { apiSecret: '' },
		clearSecrets: { apiSecret: false },
	},
	prodamus: {
		enabled: false,
		fields: { paymentUrl: '', subscriptionId: '' },
		secretFields: { secretKey: '' },
		clearSecrets: { secretKey: false },
	},
	yookassa: {
		enabled: false,
		fields: { shopId: '' },
		secretFields: { secretKey: '' },
		clearSecrets: { secretKey: false },
	},
	tochka: {
		enabled: false,
		fields: { customerCode: '', merchantId: '', clientId: '', paymentModes: 'card,sbp' },
		secretFields: { jwtToken: '' },
		clearSecrets: { jwtToken: false },
	},
})
const activeProvider = ref<PaymentProviderCode>('cloudpayments')
const checkoutForm = reactive<PaymentCheckoutSettings>({
	foreignCardsEnabled: true,
	billingMode: 'recurrent',
	recurrentInterval: 'tariff',
	recurrentPeriod: 1,
	recurrentMaxPeriods: null,
	recurrentStartDelayDays: null,
	requisitesEnabled: true,
	requisitesName: '',
	requisitesTaxId: '',
	requisitesRegistrationId: '',
	requisitesAddress: '',
	manualPaymentEnabled: false,
})

onMounted(async () => {
	await loadData()
})

watch(
	() => route.query.tab,
	(value) => {
		tab.value = normalizeTab(value)
	},
	{ immediate: true },
)

function normalizeTab(value: unknown): PaymentTab {
	return value === 'logs' || value === 'providers' ? value : 'payments'
}

function setTab(nextTab: PaymentTab) {
	tab.value = nextTab
	const query = { ...route.query }
	if (nextTab === 'payments') {
		query.tab = undefined
	} else {
		query.tab = nextTab
	}
	void router.replace({ query })
}

async function loadData() {
	loading.value = true
	const [payRes, logRes, providerRes] = await Promise.all([
		api.get<Array<Record<string, unknown>>>('/api/admin/payments?page=1&pageSize=50'),
		api.get<Array<Record<string, unknown>>>('/api/admin/payment-logs?page=1&pageSize=50'),
		api.get<AdminPaymentProviderSettings>('/api/admin/payment-providers'),
	])
	if (payRes.success) payments.value = payRes.data
	if (logRes.success) logs.value = logRes.data
	if (providerRes.success) applyProviderSettings(providerRes.data)
	loading.value = false
}

function applyProviderSettings(settings: AdminPaymentProviderSettings) {
	providerSettings.value = settings
	activeProvider.value = settings.activeProvider
	if (settings.checkout) Object.assign(checkoutForm, settings.checkout)
	for (const provider of settings.providers) {
		const form = providerForm[provider.provider]
		form.enabled = provider.enabled
		for (const [key, value] of Object.entries(provider.fields)) {
			if (typeof value === 'string') form.fields[key] = value
		}
		for (const key of Object.keys(provider.secretFields)) {
			form.secretFields[key] = ''
			form.clearSecrets[key] = false
		}
	}
}

function providerByCode(code: PaymentProviderCode) {
	return providerSettings.value?.providers.find((provider) => provider.provider === code) ?? null
}

function providerFieldLabel(provider: PaymentProviderCode, key: string) {
	const labels: Record<string, string> = {
		publicId: 'Public ID',
		apiSecret: 'API Secret',
		paymentUrl: 'Ссылка формы',
		subscriptionId: 'ID подписки',
		secretKey: 'Секретный ключ',
		shopId: 'Shop ID',
		customerCode: 'Customer Code',
		merchantId: 'Merchant ID',
		clientId: 'Client ID',
		paymentModes: 'Способы оплаты',
		jwtToken: 'JWT-токен',
	}
	return labels[key] ?? key
}

function providerFieldPlaceholder(provider: PaymentProviderCode, key: string) {
	if (provider === 'prodamus' && key === 'paymentUrl') return 'https://payform.prodamus.ru/...'
	if (provider === 'prodamus' && key === 'subscriptionId') return '12345'
	if (provider === 'yookassa' && key === 'shopId') return '123456'
	if (provider === 'tochka' && key === 'customerCode') return '300000000000000'
	if (provider === 'tochka' && key === 'merchantId') return '200000000000000'
	if (provider === 'tochka' && key === 'paymentModes') return 'card,sbp'
	return ''
}

function normalizeNullableInteger(value: unknown, min: number) {
	if (value == null || value === '') return null
	const numeric = Number(value)
	return Number.isFinite(numeric) && numeric >= min ? Math.trunc(numeric) : null
}

async function copyWebhook(url: string) {
	if (!import.meta.client) return
	await navigator.clipboard.writeText(url)
	providerMessage.value = 'Ссылка скопирована'
}

async function saveProviders() {
	if (savingProviders.value) return
	providerMessage.value = ''
	providerError.value = ''
	savingProviders.value = true

	const providers: AdminPaymentProviderSettingsPayload['providers'] = (
		['cloudpayments', 'prodamus', 'yookassa', 'tochka'] as PaymentProviderCode[]
	).map((provider) => {
		const form = providerForm[provider]
		const current = providerByCode(provider)
		const secretFields: Record<string, string | null | undefined> = {}
		for (const key of Object.keys(current?.secretFields ?? form.secretFields)) {
			if (form.clearSecrets[key]) {
				secretFields[key] = null
			} else if (form.secretFields[key]?.trim()) {
				secretFields[key] = form.secretFields[key].trim()
			}
		}
		return {
			provider,
			enabled: form.enabled,
			fields: { ...form.fields },
			secretFields,
		}
	})

	const checkoutPayload: PaymentCheckoutSettings = {
		...checkoutForm,
		recurrentPeriod: Math.max(1, Math.trunc(Number(checkoutForm.recurrentPeriod) || 1)),
		recurrentMaxPeriods: normalizeNullableInteger(checkoutForm.recurrentMaxPeriods, 1),
		recurrentStartDelayDays: normalizeNullableInteger(checkoutForm.recurrentStartDelayDays, 1),
	}
	const res = await api.put<AdminPaymentProviderSettings>('/api/admin/payment-providers', {
		activeProvider: activeProvider.value,
		checkout: checkoutPayload,
		providers,
		manualPaymentEnabled: checkoutForm.manualPaymentEnabled,
	})
	if (res.success) {
		applyProviderSettings(res.data)
		providerMessage.value = 'Платёжные системы сохранены'
	} else {
		providerError.value = res.error.message
	}

	savingProviders.value = false
}

function formatDate(d: unknown) {
	if (!d) return '—'
	return new Date(String(d)).toLocaleDateString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: '2-digit',
	})
}

function formatDateTime(d: unknown) {
	if (!d) return '—'
	return new Date(String(d)).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
	})
}

function statusClass(provider: PaymentProviderConnection) {
	if (provider.connected && provider.enabled) return 'text-emerald-600 dark:text-emerald-300'
	if (provider.enabled) return 'text-amber-600 dark:text-amber-300'
	return 'text-gray-400'
}

function statusText(provider: PaymentProviderConnection) {
	if (provider.connected && provider.enabled) return 'Подключена'
	if (provider.enabled) return 'Нужны данные'
	return 'Выключена'
}

function recurrentIntervalLabel(value: PaymentRecurrentInterval) {
	if (value === 'tariff') return 'По сроку тарифа'
	if (value === 'Day') return 'Дни'
	if (value === 'Week') return 'Недели'
	return 'Месяцы'
}
</script>

<template>
	<div class="p-6">
		<h1 class="text-2xl font-bold mb-6">Платежи</h1>

		<!-- Tabs -->
		<div class="mb-4 flex gap-2 overflow-x-auto pb-1">
			<button
				class="shrink-0 rounded-lg px-4 py-2 text-sm font-medium"
				:class="tab === 'payments' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'"
				@click="setTab('payments')"
			>
				Подписки
			</button>
			<button
				class="shrink-0 rounded-lg px-4 py-2 text-sm font-medium"
				:class="tab === 'logs' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'"
				@click="setTab('logs')"
			>
				Логи вебхуков
			</button>
			<button
				class="shrink-0 rounded-lg px-4 py-2 text-sm font-medium"
				:class="tab === 'providers' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'"
				@click="setTab('providers')"
			>
				Системы оплат
			</button>
		</div>

		<div v-if="loading" class="text-center py-8 text-gray-400">Загрузка...</div>

		<!-- Payments table -->
		<div v-else-if="tab === 'payments'" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
			<div class="overflow-x-auto">
				<table class="w-full text-sm">
						<thead class="bg-gray-50 text-gray-500 text-xs uppercase">
							<tr>
								<th class="px-4 py-3 text-left">UUID</th>
								<th class="px-4 py-3 text-left">Начало</th>
								<th class="px-4 py-3 text-left">Конец</th>
								<th class="px-4 py-3 text-left">Авто</th>
							<th class="px-4 py-3 text-left">Сумма</th>
						</tr>
					</thead>
						<tbody class="divide-y divide-gray-100">
							<tr v-for="p in payments" :key="String(p.id)" class="hover:bg-gray-50">
								<td class="px-4 py-3 text-xs font-mono text-gray-500">{{ String(p.userAuthUuid).slice(0, 8) }}</td>
								<td class="px-4 py-3 text-gray-500">{{ formatDate(p.dateStart) }}</td>
								<td class="px-4 py-3 text-gray-500">{{ formatDate(p.dateFinish) }}</td>
							<td class="px-4 py-3">
								<span :class="p.autoPayment ? 'text-green-600' : 'text-gray-400'">
									{{ p.autoPayment ? 'Да' : 'Нет' }}
								</span>
							</td>
							<td class="px-4 py-3">{{ p.amount ?? '—' }} ₽</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<!-- Webhook logs -->
		<div v-else-if="tab === 'logs'" class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
			<div class="overflow-x-auto">
				<table class="w-full text-sm">
						<thead class="bg-gray-50 text-gray-500 text-xs uppercase">
							<tr>
								<th class="px-4 py-3 text-left">Дата</th>
								<th class="px-4 py-3 text-left">Тип</th>
								<th class="px-4 py-3 text-left">Статус</th>
								<th class="px-4 py-3 text-left">Сумма</th>
							</tr>
						</thead>
					<tbody class="divide-y divide-gray-100">
						<tr v-for="log in logs" :key="String(log.id)" class="hover:bg-gray-50">
							<td class="px-4 py-3 text-xs text-gray-500">{{ formatDate(log.createdAt) }}</td>
							<td class="px-4 py-3">
								<span class="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs">
									{{ log.webhookType ?? log.event }}
								</span>
							</td>
							<td class="px-4 py-3">
								<span
									class="px-2 py-0.5 rounded-full text-xs"
									:class="log.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'"
								>
									{{ log.status }}
								</span>
							</td>
							<td class="px-4 py-3">{{ log.amount ?? '—' }} ₽</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<div v-else class="space-y-5">
			<div class="flex flex-wrap items-center justify-between gap-3">
				<div>
					<p class="text-sm text-gray-500 dark:text-gray-400">Активная система</p>
					<select v-model="activeProvider" class="glass-input mt-2 max-w-xs">
						<option value="cloudpayments">CloudPayments</option>
						<option value="prodamus">Продамус</option>
						<option value="yookassa">ЮKassa</option>
						<option value="tochka">Точка Банк</option>
					</select>
				</div>
				<button type="button" class="btn-primary" :disabled="savingProviders" @click="saveProviders">
					{{ savingProviders ? 'Сохраняю...' : 'Сохранить' }}
				</button>
			</div>

			<section class="rounded-[26px] border border-gray-200/70 bg-white/80 p-5 shadow-sm dark:border-white/10 dark:bg-white/[0.04]">
				<div class="grid gap-5 xl:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
					<div class="space-y-4">
						<h2 class="text-lg font-semibold text-gray-900 dark:text-white">Страница оплаты</h2>
						<div class="grid gap-3 sm:grid-cols-2">
							<label class="rounded-2xl border border-gray-200/70 bg-white/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
								<span class="flex items-center justify-between gap-3 text-sm font-medium text-gray-700 dark:text-gray-200">
									Зарубежные карты
									<input v-model="checkoutForm.foreignCardsEnabled" type="checkbox" class="glass-check" />
								</span>
							</label>
							<label class="rounded-2xl border border-gray-200/70 bg-white/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
								<span class="flex items-center justify-between gap-3 text-sm font-medium text-gray-700 dark:text-gray-200">
									Реквизиты
									<input v-model="checkoutForm.requisitesEnabled" type="checkbox" class="glass-check" />
								</span>
							</label>
							<label class="rounded-2xl border border-gray-200/70 bg-white/70 p-4 dark:border-white/10 dark:bg-white/[0.03]">
								<span class="flex items-center justify-between gap-3 text-sm font-medium text-gray-700 dark:text-gray-200">
									Ручная оплата (Telegram-заглушка)
									<input v-model="checkoutForm.manualPaymentEnabled" type="checkbox" class="glass-check" />
								</span>
								<p class="mt-1 text-xs text-gray-400">При включении все кнопки «Оплатить» ведут на страницу «Платёжная система временно не работает»</p>
							</label>
						</div>
						<div>
							<p class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
								Списания
							</p>
							<div class="mt-2 grid grid-cols-2 gap-2">
								<button
									type="button"
									class="rounded-2xl border px-4 py-3 text-sm font-semibold transition"
									:class="checkoutForm.billingMode === 'recurrent' ? 'border-primary-500 bg-primary-500 text-white' : 'border-gray-200 bg-white/70 text-gray-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-300'"
									@click="checkoutForm.billingMode = 'recurrent'"
								>
									Автоподписка
								</button>
								<button
									type="button"
									class="rounded-2xl border px-4 py-3 text-sm font-semibold transition"
									:class="checkoutForm.billingMode === 'one_time' ? 'border-primary-500 bg-primary-500 text-white' : 'border-gray-200 bg-white/70 text-gray-600 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-300'"
									@click="checkoutForm.billingMode = 'one_time'"
								>
									Разовый платёж
								</button>
							</div>
						</div>
						<div
							v-if="checkoutForm.billingMode === 'recurrent'"
							class="grid gap-3 sm:grid-cols-2"
						>
							<label class="block">
								<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
									Период автосписания
								</span>
								<select v-model="checkoutForm.recurrentInterval" class="glass-input mt-2">
									<option value="tariff">{{ recurrentIntervalLabel('tariff') }}</option>
									<option value="Day">{{ recurrentIntervalLabel('Day') }}</option>
									<option value="Week">{{ recurrentIntervalLabel('Week') }}</option>
									<option value="Month">{{ recurrentIntervalLabel('Month') }}</option>
								</select>
							</label>
							<label class="block">
								<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
									Каждые
								</span>
								<input
									v-model.number="checkoutForm.recurrentPeriod"
									type="number"
									min="1"
									max="365"
									class="glass-input mt-2"
									:disabled="checkoutForm.recurrentInterval === 'tariff'"
								/>
							</label>
							<label class="block">
								<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
									Лимит списаний
								</span>
								<input
									v-model.number="checkoutForm.recurrentMaxPeriods"
									type="number"
									min="1"
									max="120"
									class="glass-input mt-2"
									placeholder="Без лимита"
								/>
							</label>
							<label class="block">
								<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
									Первое автосписание через дней
								</span>
								<input
									v-model.number="checkoutForm.recurrentStartDelayDays"
									type="number"
									min="1"
									max="3650"
									class="glass-input mt-2"
									placeholder="По сроку доступа"
								/>
							</label>
						</div>
					</div>

					<div class="grid gap-3 sm:grid-cols-2">
						<label class="block">
							<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
								Название
							</span>
							<input v-model="checkoutForm.requisitesName" type="text" class="glass-input mt-2" autocomplete="off" />
						</label>
						<label class="block">
							<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
								ИНН
							</span>
							<input v-model="checkoutForm.requisitesTaxId" type="text" class="glass-input mt-2" autocomplete="off" />
						</label>
						<label class="block">
							<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
								ОГРН/ОГРНИП
							</span>
							<input v-model="checkoutForm.requisitesRegistrationId" type="text" class="glass-input mt-2" autocomplete="off" />
						</label>
						<label class="block">
							<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
								Адрес
							</span>
							<input v-model="checkoutForm.requisitesAddress" type="text" class="glass-input mt-2" autocomplete="off" />
						</label>
					</div>
				</div>
			</section>

			<p v-if="providerError" class="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-300">
				{{ providerError }}
			</p>
			<p v-else-if="providerMessage" class="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300">
				{{ providerMessage }}
			</p>

			<div class="grid gap-5 xl:grid-cols-3">
				<section
					v-for="provider in providerSettings?.providers ?? []"
					:key="provider.provider"
					class="rounded-[26px] border border-gray-200/70 bg-white/80 p-5 shadow-sm dark:border-white/10 dark:bg-white/[0.04]"
				>
					<div class="flex items-start justify-between gap-4">
						<div>
							<h2 class="text-lg font-semibold text-gray-900 dark:text-white">{{ provider.label }}</h2>
							<p class="mt-1 text-sm font-medium" :class="statusClass(provider)">
								{{ statusText(provider) }}
							</p>
						</div>
						<label class="inline-flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
							<input v-model="providerForm[provider.provider].enabled" type="checkbox" class="glass-check" />
							<span>Включить</span>
						</label>
					</div>

					<div class="mt-5 space-y-3">
						<label
							v-for="(_, key) in providerForm[provider.provider].fields"
							:key="String(key)"
							class="block"
						>
							<span class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
								{{ providerFieldLabel(provider.provider, String(key)) }}
							</span>
							<input
								v-model="providerForm[provider.provider].fields[String(key)]"
								type="text"
								class="glass-input mt-2"
								:placeholder="providerFieldPlaceholder(provider.provider, String(key))"
								autocomplete="off"
							/>
						</label>

						<div
							v-for="(_, key) in provider.secretFields"
							:key="String(key)"
							class="space-y-2"
						>
							<div class="flex items-center justify-between gap-3">
								<label class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
									{{ providerFieldLabel(provider.provider, String(key)) }}
								</label>
								<span class="text-xs" :class="provider.secretFields[String(key)] ? 'text-emerald-600 dark:text-emerald-300' : 'text-gray-400'">
									{{ provider.secretFields[String(key)] ? 'Сохранён' : 'Не задан' }}
								</span>
							</div>
							<input
								v-model="providerForm[provider.provider].secretFields[String(key)]"
								type="password"
								class="glass-input"
								placeholder="Новый ключ"
								autocomplete="new-password"
								:disabled="providerForm[provider.provider].clearSecrets[String(key)]"
							/>
							<label class="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
								<input
									v-model="providerForm[provider.provider].clearSecrets[String(key)]"
									type="checkbox"
									class="glass-check"
								/>
								<span>Убрать ключ</span>
							</label>
						</div>
					</div>

					<div class="mt-5 space-y-2">
						<p class="text-xs uppercase tracking-[0.14em] text-gray-400 dark:text-gray-500">
							Webhook
						</p>
						<div
							v-for="webhook in provider.webhooks"
							:key="webhook.url"
							class="rounded-2xl border border-gray-200/70 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.03]"
						>
							<p class="text-xs font-semibold text-gray-500 dark:text-gray-400">{{ webhook.label }}</p>
							<div class="mt-2 flex gap-2">
								<input :value="webhook.url" readonly class="glass-input font-mono text-xs" />
								<button type="button" class="btn-secondary shrink-0" @click="copyWebhook(webhook.url)">
									Копировать
								</button>
							</div>
						</div>
					</div>

					<div class="mt-5 rounded-2xl border border-gray-200/70 bg-white/60 p-3 text-xs dark:border-white/10 dark:bg-white/[0.03]">
						<p class="font-semibold text-gray-500 dark:text-gray-400">Диагностика</p>
						<div class="mt-2 space-y-1 text-gray-500 dark:text-gray-400">
							<p>Последний webhook: {{ formatDateTime(provider.diagnostics?.lastWebhookAt) }}</p>
							<p>Последняя успешная оплата: {{ formatDateTime(provider.diagnostics?.lastSuccessAt) }}</p>
							<p>Последняя ошибка: {{ formatDateTime(provider.diagnostics?.lastFailureAt) }}</p>
							<p v-if="provider.diagnostics?.lastErrorMessage" class="text-red-600 dark:text-red-300">
								{{ provider.diagnostics.lastErrorMessage }}
							</p>
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
</template>
