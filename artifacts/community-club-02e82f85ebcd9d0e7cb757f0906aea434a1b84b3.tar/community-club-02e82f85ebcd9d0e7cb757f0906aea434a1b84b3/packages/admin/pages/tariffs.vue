<script setup lang="ts">
type PricingRole = 'club'

interface PricingMatrixItem {
	role: PricingRole
	demoFirstMonthPrice: string
	demoDays: number
	activeMonthPrice: string
	formerMonthPrice: string
	externalFirstMonthPrice: string
	externalMonthPrice: string
	active90DaysPrice: string
	former90DaysPrice: string
	external90DaysPrice: string
	active365DaysPrice: string
	former365DaysPrice: string
	external365DaysPrice: string
	foreignDemoFirstMonthPrice: string
	foreignActiveMonthPrice: string
	foreignFormerMonthPrice: string
	foreignExternalFirstMonthPrice: string
	foreignExternalMonthPrice: string
	foreignActive90DaysPrice: string
	foreignFormer90DaysPrice: string
	foreignExternal90DaysPrice: string
	foreignActive365DaysPrice: string
	foreignFormer365DaysPrice: string
	foreignExternal365DaysPrice: string
}

const api = useAdminApi()
const loading = ref(true)
const saving = ref(false)
const saveMessage = ref('')
const saveError = ref('')

const fieldGroups = [
	{
		title: 'Россия',
		fields: [
			['activeMonthPrice', 'Цена продления 1 месяца для действующего участника'],
			['formerMonthPrice', 'Цена продления 1 месяца для бывшего участника'],
			['externalFirstMonthPrice', 'Цена первого месяца для пользователя извне'],
			['externalMonthPrice', 'Цена продления 1 месяца для пользователя извне'],
			['active90DaysPrice', 'Цена за 90 дней для участника действующего'],
			['former90DaysPrice', 'Цена за 90 дней для участника бывшего'],
			['external90DaysPrice', 'Цена за 90 дней для пользователя извне'],
			['active365DaysPrice', 'Цена за 12 месяцев для участника действующего'],
			['former365DaysPrice', 'Цена за 12 месяцев для участника бывшего'],
			['external365DaysPrice', 'Цена за 12 месяцев для пользователя извне'],
		] as const,
	},
	{
		title: 'Зарубежные карты',
		fields: [
			['foreignActiveMonthPrice', 'Цена продления 1 месяца для действующего участника'],
			['foreignFormerMonthPrice', 'Цена продления 1 месяца для бывшего участника'],
			['foreignExternalFirstMonthPrice', 'Цена первого месяца для пользователя извне'],
			['foreignExternalMonthPrice', 'Цена продления 1 месяца для пользователя извне'],
			['foreignActive90DaysPrice', 'Цена за 90 дней для участника действующего'],
			['foreignFormer90DaysPrice', 'Цена за 90 дней для участника бывшего'],
			['foreignExternal90DaysPrice', 'Цена за 90 дней для пользователя извне'],
			['foreignActive365DaysPrice', 'Цена за 12 месяцев для участника действующего'],
			['foreignFormer365DaysPrice', 'Цена за 12 месяцев для участника бывшего'],
			['foreignExternal365DaysPrice', 'Цена за 12 месяцев для пользователя извне'],
		] as const,
	},
] as const

const forms = ref<Record<PricingRole, PricingMatrixItem>>({
	club: emptyRole('club'),
})
const clubForm = computed(() => forms.value.club)

function emptyRole(role: PricingRole): PricingMatrixItem {
	return {
		role,
		demoFirstMonthPrice: '',
		demoDays: 0,
		activeMonthPrice: '',
		formerMonthPrice: '',
		externalFirstMonthPrice: '',
		externalMonthPrice: '',
		active90DaysPrice: '',
		former90DaysPrice: '',
		external90DaysPrice: '',
		active365DaysPrice: '',
		former365DaysPrice: '',
		external365DaysPrice: '',
		foreignDemoFirstMonthPrice: '',
		foreignActiveMonthPrice: '',
		foreignFormerMonthPrice: '',
		foreignExternalFirstMonthPrice: '',
		foreignExternalMonthPrice: '',
		foreignActive90DaysPrice: '',
		foreignFormer90DaysPrice: '',
		foreignExternal90DaysPrice: '',
		foreignActive365DaysPrice: '',
		foreignFormer365DaysPrice: '',
		foreignExternal365DaysPrice: '',
	}
}

onMounted(loadPricingMatrix)

async function loadPricingMatrix() {
	loading.value = true
	const res = await api.get<{ club: PricingMatrixItem | null }>('/api/admin/tariffs')

	if (res.success) {
		forms.value.club = res.data.club ? { ...res.data.club } : emptyRole('club')
		saveError.value = ''
	}

	loading.value = false
}

async function saveTariff() {
	saveError.value = ''
	saveMessage.value = ''
	saving.value = true

	const payload = { ...clubForm.value, role: 'club' as PricingRole, demoDays: 0 }
	const res = await api.patch('/api/admin/tariffs/club', payload)
	if (res.success) {
		forms.value.club = { ...res.data }
		saveMessage.value = 'Тарифы сохранены'
	} else {
		saveError.value = res.error.message
	}

	saving.value = false
}
</script>

<template>
	<div class="p-6">
		<div class="mb-6">
			<h1 class="text-2xl font-bold dark:text-white">Тарифная сетка</h1>
		</div>

		<div v-if="loading" class="flex justify-center py-14">
			<div class="animate-spin w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full" />
		</div>

		<div v-else>
			<section
				class="rounded-[28px] border border-emerald-500/20 bg-gradient-to-b from-emerald-500/18 to-emerald-500/5 p-5 shadow-sm"
			>
				<div class="mb-5 flex items-center justify-between gap-4">
					<div>
						<h2 class="text-lg font-semibold text-gray-900 dark:text-white">Клубный тариф</h2>
					</div>
					<button
						class="btn-primary min-w-[168px]"
						:disabled="saving"
						@click="saveTariff"
					>
						{{ saving ? 'Сохранение...' : 'Сохранить' }}
					</button>
				</div>

				<div class="space-y-5">
					<div
						v-for="group in fieldGroups"
						:key="group.title"
						class="rounded-[24px] border border-black/5 bg-white/70 p-4 dark:border-white/6 dark:bg-black/15"
					>
						<h3 class="mb-4 text-sm font-semibold text-gray-700 dark:text-gray-200">{{ group.title }}</h3>
						<div class="space-y-3">
							<div
								v-for="[field, label] in group.fields"
								:key="field"
								class="grid grid-cols-1 gap-2 md:grid-cols-[minmax(0,1fr)_160px]"
							>
								<label class="text-sm leading-5 text-gray-600 dark:text-gray-300">{{ label }}</label>
								<input
									v-if="field !== 'demoDays'"
									v-model="clubForm[field]"
									type="number"
									min="0"
									step="1"
									class="glass-input"
								/>
								<input
									v-else
									v-model.number="clubForm[field]"
									type="number"
									min="0"
									step="1"
									class="glass-input"
								/>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>

		<p v-if="saveError" class="mt-4 text-sm text-red-500 dark:text-red-400">{{ saveError }}</p>
		<p v-else-if="saveMessage" class="mt-4 text-sm text-emerald-600 dark:text-emerald-400">{{ saveMessage }}</p>
	</div>
</template>
