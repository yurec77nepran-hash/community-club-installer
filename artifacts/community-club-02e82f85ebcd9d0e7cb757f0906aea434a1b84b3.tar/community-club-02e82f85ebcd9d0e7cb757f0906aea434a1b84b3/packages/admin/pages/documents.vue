<script setup lang="ts">
import type {
	LegalDocumentItem,
	LegalDocumentKey,
	LegalDocumentsSettings,
} from '@community-club/shared/types'

const api = useAdminApi()
const loading = ref(true)
const saving = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const form = ref<LegalDocumentsSettings>({ documents: [] })
const activeKey = ref<LegalDocumentKey>('privacy')

const activeDocument = computed(
	() => form.value.documents.find((document) => document.key === activeKey.value) ?? null,
)
const activeDocumentIsCookie = computed(() => activeDocument.value?.key === 'cookie')

function documentPath(document: LegalDocumentItem) {
	if (document.key === 'privacy') return '/app/legal/privacy-policy'
	if (document.key === 'personalData') return '/app/legal/personal-data'
	if (document.key === 'oferta') return '/app/legal/oferta'
	if (document.key === 'requisites') return '/app/legal/requisites'
	return '/app/legal/cookie-policy'
}

async function loadDocuments() {
	loading.value = true
	errorMessage.value = ''
	const res = await api.get<LegalDocumentsSettings>('/api/admin/legal-documents')
	if (res.success) {
		form.value = res.data
		activeKey.value = res.data.documents[0]?.key ?? 'privacy'
	} else {
		errorMessage.value = res.error?.message ?? 'Не удалось загрузить документы'
	}
	loading.value = false
}

async function saveDocuments() {
	saving.value = true
	errorMessage.value = ''
	successMessage.value = ''
	const res = await api.put<LegalDocumentsSettings>('/api/admin/legal-documents', form.value)
	if (res.success) {
		form.value = res.data
		successMessage.value = 'Документы сохранены'
	} else {
		errorMessage.value = res.error?.message ?? 'Не удалось сохранить документы'
	}
	saving.value = false
}

onMounted(loadDocuments)
</script>

<template>
	<div class="p-6">
		<div class="mb-6 flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
			<div>
				<p class="text-sm font-medium text-primary-600">Сайт</p>
				<h1 class="mt-1 text-2xl font-bold text-gray-900 dark:text-white">Документы</h1>
				<p class="mt-2 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
					Тексты для страниц, согласий в формах и уведомления о cookie.
				</p>
			</div>
			<button type="button" class="btn-primary" :disabled="saving || loading" @click="saveDocuments">
				{{ saving ? 'Сохраняю...' : 'Сохранить' }}
			</button>
		</div>

		<div v-if="errorMessage" class="mb-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
			{{ errorMessage }}
		</div>
		<div v-if="successMessage" class="mb-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200">
			{{ successMessage }}
		</div>

		<div v-if="loading" class="glass rounded-[30px] px-6 py-10 text-center text-sm text-gray-500 dark:text-gray-400">
			Загружаю документы...
		</div>

		<div v-else class="grid min-w-0 gap-5 xl:grid-cols-[260px_minmax(0,1fr)]">
			<aside class="glass min-w-0 rounded-[26px] p-2">
				<button
					v-for="document in form.documents"
					:key="document.key"
					type="button"
					class="flex w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left text-sm transition"
					:class="activeKey === document.key ? 'bg-white/12 text-white' : 'text-gray-500 hover:bg-white/8 dark:text-gray-400'"
					@click="activeKey = document.key"
				>
					<span class="min-w-0 truncate font-medium">{{ document.title }}</span>
					<span
						class="shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold"
						:class="document.enabled ? 'bg-emerald-500/12 text-emerald-200' : 'bg-white/8 text-white/45'"
					>
						{{ document.enabled ? 'Вкл' : 'Выкл' }}
					</span>
				</button>
			</aside>

			<section v-if="activeDocument" class="glass min-w-0 overflow-hidden rounded-[30px] p-5 md:p-6">
				<div class="mb-5 flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
					<div class="min-w-0">
						<p class="text-xs uppercase tracking-[0.2em] text-gray-400 dark:text-gray-500">Документ</p>
						<h2 class="mt-2 text-xl font-semibold break-words text-gray-900 dark:text-white">
							{{ activeDocument.title }}
						</h2>
					</div>
					<NuxtLink :to="documentPath(activeDocument)" target="_blank" class="btn-secondary">
						Открыть
					</NuxtLink>
				</div>

				<div class="space-y-5">
					<label class="flex min-w-0 items-start gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
						<input v-model="activeDocument.enabled" type="checkbox" class="glass-check mt-0.5" />
						<span class="min-w-0">
							<span class="block text-sm font-semibold text-gray-900 dark:text-white">Показывать документ</span>
							<span class="mt-1 block text-sm text-gray-500 dark:text-gray-400">
								{{
									activeDocumentIsCookie
										? 'Если выключить, уведомление о cookie не появится.'
										: 'Если выключить, ссылка исчезнет из форм.'
								}}
							</span>
						</span>
					</label>

					<label class="block">
						<span class="text-sm font-medium text-gray-600 dark:text-gray-300">Название страницы</span>
						<input v-model="activeDocument.title" class="glass-input mt-2" maxlength="160" />
					</label>

					<label class="block">
						<span class="text-sm font-medium text-gray-600 dark:text-gray-300">Текст ссылки в форме</span>
						<input v-model="activeDocument.linkLabel" class="glass-input mt-2" maxlength="120" />
					</label>

					<label v-if="activeDocumentIsCookie" class="block">
						<span class="text-sm font-medium text-gray-600 dark:text-gray-300">Текст уведомления</span>
						<textarea
							v-model="activeDocument.noticeText"
							class="glass-input mt-2 min-h-[110px] resize-y text-sm leading-6"
							maxlength="500"
						/>
						<span class="mt-2 block text-xs text-gray-500 dark:text-gray-400">
							Ссылка на политику cookie добавится после этого текста.
						</span>
					</label>

					<label class="block">
						<span class="text-sm font-medium text-gray-600 dark:text-gray-300">Текст документа</span>
						<textarea
							v-model="activeDocument.body"
							class="glass-input mt-2 min-h-[420px] resize-y font-mono text-xs leading-6"
							maxlength="50000"
						/>
					</label>
				</div>
			</section>
		</div>
	</div>
</template>
