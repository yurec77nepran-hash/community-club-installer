<template>
	<AdminSettingsWorkspace mode="settings" />
</template>
