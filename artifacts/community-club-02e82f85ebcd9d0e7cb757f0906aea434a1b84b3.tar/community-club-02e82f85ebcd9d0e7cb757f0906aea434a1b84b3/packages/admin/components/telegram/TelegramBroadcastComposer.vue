<script setup lang="ts">
import type {
	AdminTelegramBroadcastAudience,
	AdminTelegramBroadcastBot,
	TelegramBroadcastButton,
} from '@community-club/shared'
import TelegramBroadcastMediaPicker, {
	type TelegramBroadcastMediaInput,
} from './TelegramBroadcastMediaPicker.vue'
import TelegramBroadcastPreview from './TelegramBroadcastPreview.vue'
import TelegramBroadcastRichEditor from './TelegramBroadcastRichEditor.vue'

const props = defineProps<{ bots: AdminTelegramBroadcastBot[] }>()
const emit = defineEmits<{ created: [] }>()

const api = useAdminApi()
const saving = ref(false)
const testing = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const audience = ref<AdminTelegramBroadcastAudience>({
	contacts: 0,
	uniqueUsers: 0,
	overlapUsers: 0,
})
const plainLength = ref(0)
const form = ref({
	name: '',
	botUsernames: [] as string[],
	deliveryMode: 'all' as 'all' | 'unique',
	preferredBotUsername: '',
	body: '',
	buttons: [] as TelegramBroadcastButton[],
	media: null as TelegramBroadcastMediaInput | null,
	sendAt: '',
})

const inputClass =
	'min-h-[46px] w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-gray-900 outline-none transition focus:border-primary-400 dark:border-white/10 dark:bg-white/5 dark:text-white'
const selectedBotLabel = computed(
	() =>
		props.bots.find((bot) => bot.username === form.value.botUsernames[0])?.label ?? 'Telegram-бот',
)

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}
const DRAFT_KEY = 'tg-broadcast-draft'
function saveDraft() {
	localStorage.setItem(
		DRAFT_KEY,
		JSON.stringify({
			name: form.value.name,
			botUsernames: form.value.botUsernames,
			deliveryMode: form.value.deliveryMode,
			preferredBotUsername: form.value.preferredBotUsername,
			body: form.value.body,
			buttons: form.value.buttons,
			media: form.value.media,
			sendAt: form.value.sendAt,
		}),
	)
	successMessage.value = 'Черновик сохранён'
	setTimeout(() => {
		successMessage.value = ''
	}, 2000)
}
function loadDraft() {
	const raw = localStorage.getItem(DRAFT_KEY)
	if (!raw) return
	try {
		const draft = JSON.parse(raw)
		form.value.name = draft.name || ''
		form.value.botUsernames = draft.botUsernames || []
		form.value.deliveryMode = draft.deliveryMode || 'all'
		form.value.preferredBotUsername = draft.preferredBotUsername || ''
		form.value.body = draft.body || ''
		form.value.buttons = draft.buttons || []
		form.value.media = draft.media || null
		form.value.sendAt = draft.sendAt || ''
		successMessage.value = 'Черновик восстановлен'
	} catch {}
}
function clearDraft() {
	localStorage.removeItem(DRAFT_KEY)
}
function hasDraft() {
	return !!localStorage.getItem(DRAFT_KEY)
}
onMounted(() => {
	if (hasDraft()) loadDraft()
})
function createId() {
	return crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`
}

function toggleBot(username: string) {
	form.value.botUsernames = form.value.botUsernames.includes(username)
		? form.value.botUsernames.filter((item) => item !== username)
		: [...form.value.botUsernames, username]
	if (!form.value.botUsernames.includes(form.value.preferredBotUsername))
		form.value.preferredBotUsername = form.value.botUsernames[0] ?? ''
}

function addButton() {
	editButtonIndex.value = null
	editButtonForm.value = { id: createId(), text: '', url: '', color: 'default' }
	buttonModalOpen.value = true
}
function removeButton(id: string) {
	form.value.buttons = form.value.buttons.filter((button) => button.id !== id)
}
function editButton(button: TelegramBroadcastButton) {
	editButtonIndex.value = form.value.buttons.findIndex((b) => b.id === button.id)
	editButtonForm.value = { ...button }
	buttonModalOpen.value = true
}
function saveButton() {
	if (!editButtonForm.value.text.trim() || !editButtonForm.value.url.trim()) return
	if (editButtonIndex.value !== null) {
		form.value.buttons[editButtonIndex.value] = { ...editButtonForm.value }
	} else {
		form.value.buttons.push({ ...editButtonForm.value })
	}
	buttonModalOpen.value = false
	editButtonForm.value = { id: '', text: '', url: '', color: 'default' }
	editButtonIndex.value = null
}
const buttonModalOpen = ref(false)
const editButtonForm = ref<TelegramBroadcastButton>({ id: '', text: '', url: '', color: 'default' })
const editButtonIndex = ref<number | null>(null)

function payload() {
	return {
		botUsernames: form.value.botUsernames,
		deliveryMode: form.value.deliveryMode,
		preferredBotUsername: form.value.preferredBotUsername || null,
		body: form.value.body,
		buttons: form.value.buttons,
		media: form.value.media
			? { path: form.value.media.path, name: form.value.media.name, type: form.value.media.type }
			: null,
	}
}

async function loadAudience() {
	if (!form.value.botUsernames.length) {
		audience.value = { contacts: 0, uniqueUsers: 0, overlapUsers: 0 }
		return
	}
	const res = await api.get<AdminTelegramBroadcastAudience>(
		`/api/admin/telegram-broadcasts/audience?bots=${encodeURIComponent(form.value.botUsernames.join(','))}`,
	)
	if (res.success) audience.value = res.data
}

async function createBroadcast() {
	resetMessages()
	saving.value = true
	const res = await api.post('/api/admin/telegram-broadcasts', {
		name: form.value.name.trim(),
		...payload(),
		sendAt: form.value.sendAt ? new Date(form.value.sendAt).toISOString() : undefined,
	})
	if (res.success) {
		successMessage.value = form.value.sendAt
			? 'Рассылка запланирована.'
			: 'Рассылка поставлена в очередь.'
		form.value.name = ''
		form.value.body = ''
		form.value.buttons = []
		form.value.media = null
		form.value.sendAt = ''
		emit('created')
	} else errorMessage.value = res.error.message
	saving.value = false
}

async function sendTest() {
	resetMessages()
	testing.value = true
	const res = await api.post<{ sentBots: string[]; missingBots: string[] }>(
		'/api/admin/telegram-broadcasts/test',
		payload(),
	)
	if (res.success)
		successMessage.value = `Тест отправлен из: ${res.data.sentBots.map((bot) => `@${bot}`).join(', ')}.`
	else errorMessage.value = res.error.message
	testing.value = false
}

watch(
	() => props.bots,
	(bots) => {
		if (!form.value.botUsernames.length && bots[0]) {
			form.value.botUsernames = [bots[0].username]
			form.value.preferredBotUsername = bots[0].username
		}
	},
	{ immediate: true },
)
watch(
	() => form.value.botUsernames,
	() => void loadAudience(),
	{ deep: true, immediate: true },
)
</script>

<template>
	<div class="grid items-start gap-6 xl:grid-cols-[minmax(0,1.22fr)_minmax(330px,0.78fr)]">
		<form class="glass rounded-2xl p-4 sm:p-5" @submit.prevent="createBroadcast">
			<div class="mb-5"><h2 class="font-semibold dark:text-white">Новая рассылка</h2><p class="mt-1 text-xs text-gray-500">Редактор отправляет сообщение в Telegram именно в таком виде.</p></div>
			<div class="grid gap-3 sm:grid-cols-2"><label class="space-y-1"><span class="text-xs text-gray-500">Название для истории</span><input v-model="form.name" required :class="inputClass" /></label><label class="space-y-1"><span class="text-xs text-gray-500">Когда отправить</span><input v-model="form.sendAt" type="datetime-local" :class="inputClass" /></label></div>

			<section class="mt-5"><div class="mb-2 flex items-baseline justify-between"><h3 class="text-sm font-medium dark:text-white">Боты и аудитория</h3><span class="text-xs text-gray-500">{{ audience.contacts }} контактов</span></div>
				<div class="grid gap-2 sm:grid-cols-2"><label v-for="bot in bots" :key="bot.username" class="flex cursor-pointer items-start gap-3 rounded-xl border border-gray-200 p-3 transition has-[:checked]:border-primary-400 has-[:checked]:bg-primary-50/60 dark:border-white/10 dark:has-[:checked]:bg-primary-500/10"><input type="checkbox" :checked="form.botUsernames.includes(bot.username)" @change="toggleBot(bot.username)" /><span><b class="block text-sm dark:text-white">{{ bot.label }}</b><small class="text-xs text-gray-500">@{{ bot.username }}</small></span></label></div>
				<div v-if="form.botUsernames.length > 1" class="mt-3 rounded-xl bg-gray-50 p-3 text-sm dark:bg-white/5"><p class="font-medium dark:text-white">{{ audience.overlapUsers }} пользователей есть в нескольких выбранных ботах</p><label class="mt-2 flex gap-2"><input v-model="form.deliveryMode" value="all" type="radio" /><span>Отправить везде — человек получит сообщение от каждого выбранного бота.</span></label><label class="mt-2 flex gap-2"><input v-model="form.deliveryMode" value="unique" type="radio" /><span>Один раз на человека</span></label><label v-if="form.deliveryMode === 'unique'" class="mt-3 block text-xs text-gray-500">При пересечении отправить от<select v-model="form.preferredBotUsername" class="ml-2 rounded border border-gray-200 bg-white px-2 py-1 dark:border-white/10 dark:bg-gray-900 dark:text-white"><option v-for="username in form.botUsernames" :key="username" :value="username">{{ username }}</option></select></label></div>
				<p v-else class="mt-2 text-xs text-gray-500">Уникальных людей: {{ audience.uniqueUsers }}</p>
			</section>

			<section class="mt-5"><div class="mb-2 flex items-baseline justify-between"><h3 class="text-sm font-medium dark:text-white">Сообщение</h3><span class="text-xs" :class="plainLength > 4096 ? 'text-red-500' : 'text-gray-500'">{{ plainLength }} / 4 096</span></div><TelegramBroadcastRichEditor v-model="form.body" @update:plain-length="plainLength = $event" /></section>
			<section class="mt-5"><h3 class="mb-2 text-sm font-medium dark:text-white">Вложение</h3><TelegramBroadcastMediaPicker v-model="form.media" /></section>

			<section class="mt-5"><div class="mb-2 flex items-center justify-between"><h3 class="text-sm font-medium dark:text-white">Кнопки</h3><button type="button" class="text-xs font-medium text-primary-600 hover:underline" :disabled="form.buttons.length >= 10" @click="addButton">+ Добавить кнопку</button></div><div v-if="!form.buttons.length" class="rounded-xl border border-dashed border-gray-200 p-3 text-xs text-gray-500 dark:border-white/10">До 10 ссылок. Цвет — один из поддерживаемых Telegram.</div><div v-for="button in form.buttons" :key="button.id" class="mt-2 flex items-center gap-2 rounded-xl border border-gray-200 p-3 dark:border-white/10">
		<button type="button" class="flex-1 text-left text-sm" :class="{'font-semibold': button.color === 'primary' || button.color === 'success' || button.color === 'danger'}" @click="editButton(button)">{{ button.text || 'Без названия' }}</button>
		<button type="button" class="px-2 text-xs text-red-500 hover:underline" @click="removeButton(button.id)">Удалить</button>
	</div>

	<!-- Модалка добавления/редактирования кнопки -->
	<Teleport to="body">
		<div v-if="buttonModalOpen" class="fixed inset-0 z-[100] flex items-center justify-center bg-black/30" @click.self="buttonModalOpen = false">
			<div class="w-96 rounded-2xl border border-gray-200 bg-white p-5 shadow-xl dark:border-white/10 dark:bg-gray-900">
				<h3 class="text-sm font-semibold dark:text-white">{{ editButtonIndex !== null ? 'Редактировать кнопку' : 'Новая кнопка' }}</h3>
				<div class="mt-4 space-y-3">
					<label class="block"><span class="text-xs text-gray-500">Текст кнопки</span><input v-model="editButtonForm.text" maxlength="64" class="mt-1 w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm outline-none focus:border-primary-400 dark:border-white/10 dark:bg-white/5 dark:text-white" /></label>
					<label class="block"><span class="text-xs text-gray-500">Ссылка</span><input v-model="editButtonForm.url" type="url" class="mt-1 w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm outline-none focus:border-primary-400 dark:border-white/10 dark:bg-white/5 dark:text-white" placeholder="https://…" /></label>
					<label class="block"><span class="text-xs text-gray-500">Цвет</span>
						<select v-model="editButtonForm.color" class="mt-1 w-full rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-sm outline-none focus:border-primary-400 dark:border-white/10 dark:bg-white/5 dark:text-white">
							<option value="default">Обычная</option>
							<option value="primary">Синяя</option>
							<option value="success">Зелёная</option>
							<option value="danger">Красная</option>
						</select>
					</label>
					<!-- Предпросмотр кнопки -->
					<div class="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/5">
						<p class="mb-1 text-[10px] text-gray-500">Предпросмотр</p>
						<div class="block rounded-lg px-3 py-2 text-center text-sm font-medium" :class="{
							'bg-white/90 text-[#168acd] border border-slate-300': editButtonForm.color === 'default',
							'bg-[#168acd] text-white': editButtonForm.color === 'primary',
							'bg-[#35a854] text-white': editButtonForm.color === 'success',
							'bg-[#e55c5c] text-white': editButtonForm.color === 'danger',
						}">{{ editButtonForm.text || 'Текст кнопки' }}</div>
					</div>
				</div>
				<div class="mt-4 flex gap-2">
					<button type="button" class="btn-primary flex-1 py-2 text-sm" :disabled="!editButtonForm.text.trim() || !editButtonForm.url.trim()" @click="saveButton">Сохранить</button>
					<button type="button" class="btn-secondary py-2 text-sm" @click="buttonModalOpen = false">Отмена</button>
				</div>
			</div>
		</div>
	</Teleport>
	</section>

			<p v-if="errorMessage" class="mt-4 text-sm text-red-500">{{ errorMessage }}</p><p v-else-if="successMessage" class="mt-4 text-sm text-green-600">{{ successMessage }}</p>
			<div class="mt-5 flex flex-wrap gap-3"><button class="btn-primary" :disabled="saving || !form.botUsernames.length || plainLength > 4096">{{ saving ? 'Сохранение…' : form.sendAt ? 'Запланировать' : 'Отправить' }}</button><button type="button" class="btn-secondary" :disabled="testing || !form.botUsernames.length" @click="sendTest">{{ testing ? 'Отправляю тест…' : 'Тест владельцу @oleggorskyj' }}</button><button type="button" class="btn-secondary" @click="saveDraft">💾 Сохранить черновик</button><button v-if="hasDraft()" type="button" class="btn-secondary" @click="loadDraft">📂 Восстановить черновик</button><button v-if="hasDraft()" type="button" class="text-xs text-red-500 hover:underline" @click="clearDraft(); loadDraft()">✕ Удалить черновик</button></div>
		</form>
		<div class="xl:sticky xl:top-6"><TelegramBroadcastPreview :bot-label="selectedBotLabel" :body="form.body" :buttons="form.buttons" :media="form.media" /></div>
	</div>
</template>
