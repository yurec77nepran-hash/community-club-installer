<script setup lang="ts">
import type { AdminMediaLibraryItem, CursorPaginatedResponse } from '@community-club/shared/types'

export type TelegramBroadcastMediaInput = {
	path: string
	name: string
	type: 'image' | 'video' | 'audio' | 'document'
	url: string
}

const props = defineProps<{ modelValue: TelegramBroadcastMediaInput | null }>()
const emit = defineEmits<{ 'update:modelValue': [value: TelegramBroadcastMediaInput | null] }>()

const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()
const fileInput = ref<HTMLInputElement | null>(null)
const open = ref(false)
const loading = ref(false)
const uploading = ref(false)
const errorMessage = ref('')
const items = ref<AdminMediaLibraryItem[]>([])

async function loadMedia() {
	loading.value = true
	errorMessage.value = ''
	const res = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		'/api/admin/media-library?limit=36&sortBy=updatedAt&sortDir=desc',
	)
	if (res.success) items.value = res.data.items
	else errorMessage.value = res.error.message
	loading.value = false
}

function showPicker() {
	open.value = true
	void loadMedia()
}

function select(item: AdminMediaLibraryItem) {
	emit('update:modelValue', { path: item.key, name: item.name, type: item.type, url: item.url })
	open.value = false
}

async function upload(event: Event) {
	const file = (event.target as HTMLInputElement).files?.[0]
	if (!file) return
	uploading.value = true
	errorMessage.value = ''
	const res = await mediaUpload.uploadFile(file, { bucket: 'media' })
	if (res.success) {
		select({
			key: res.data.path,
			name: file.name,
			type: res.data.mediaType,
			url: res.data.url,
		} as AdminMediaLibraryItem)
	} else {
		errorMessage.value = res.error.message
	}
	uploading.value = false
	if (fileInput.value) fileInput.value.value = ''
}
</script>

<template>
	<div>
		<div v-if="props.modelValue" class="flex items-center gap-3 rounded-xl border border-gray-200 p-3 dark:border-white/10">
			<img v-if="props.modelValue.type === 'image'" :src="props.modelValue.url" :alt="props.modelValue.name" class="h-12 w-12 rounded-lg object-cover" />
			<div v-else class="flex h-12 w-12 items-center justify-center rounded-lg bg-primary-500/10 text-lg">{{ props.modelValue.type === 'video' ? '▶' : props.modelValue.type === 'audio' ? '♫' : '⌁' }}</div>
			<div class="min-w-0 flex-1"><p class="truncate text-sm font-medium dark:text-white">{{ props.modelValue.name }}</p><p class="text-xs text-gray-500">{{ props.modelValue.type }}</p></div>
			<button type="button" class="text-xs text-red-500 hover:underline" @click="emit('update:modelValue', null)">Убрать</button>
		</div>
		<button v-else type="button" class="btn-secondary w-full" @click="showPicker">Добавить медиа</button>

		<div v-if="open" class="fixed inset-0 z-50 flex items-end bg-black/50 p-3 sm:items-center sm:justify-center" @click.self="open = false">
			<div class="max-h-[85vh] w-full max-w-4xl overflow-auto rounded-2xl bg-white p-5 shadow-2xl dark:bg-gray-900">
				<div class="mb-4 flex items-center justify-between gap-3"><div><h3 class="font-semibold dark:text-white">Медиа для рассылки</h3><p class="text-xs text-gray-500">Фото, видео, аудио или документ — одно вложение.</p></div><button type="button" class="btn-icon" @click="open = false">✕</button></div>
				<div class="mb-4 flex flex-wrap gap-2"><input ref="fileInput" class="hidden" type="file" accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.zip" @change="upload" /><button type="button" class="btn-primary" :disabled="uploading" @click="fileInput?.click()">{{ uploading ? 'Загрузка…' : 'Загрузить файл' }}</button></div>
				<p v-if="errorMessage" class="mb-3 text-sm text-red-500">{{ errorMessage }}</p>
				<p v-if="loading" class="py-10 text-center text-sm text-gray-500">Загружаю медиатеку…</p>
				<div v-else class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
					<button v-for="item in items" :key="item.key" type="button" class="overflow-hidden rounded-xl border border-gray-200 text-left transition hover:border-primary-400 dark:border-white/10" @click="select(item)">
						<img v-if="item.type === 'image'" :src="item.url" :alt="item.title" class="aspect-square w-full object-cover" />
						<div v-else class="flex aspect-square items-center justify-center bg-gray-100 text-2xl dark:bg-white/5">{{ item.type === 'video' ? '▶' : item.type === 'audio' ? '♫' : '⌁' }}</div>
						<p class="truncate px-3 py-2 text-xs dark:text-white">{{ item.title }}</p>
					</button>
				</div>
			</div>
		</div>
	</div>
</template>
