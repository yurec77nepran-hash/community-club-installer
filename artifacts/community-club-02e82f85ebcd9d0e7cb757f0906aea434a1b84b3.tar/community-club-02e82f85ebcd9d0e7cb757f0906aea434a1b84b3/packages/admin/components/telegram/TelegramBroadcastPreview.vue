<script setup lang="ts">
import { sanitizeTelegramBroadcastHtml } from '@community-club/shared'
import type { TelegramBroadcastButton } from '@community-club/shared'
import type { TelegramBroadcastMediaInput } from './TelegramBroadcastMediaPicker.vue'

const props = defineProps<{
	botLabel: string
	body: string
	buttons: TelegramBroadcastButton[]
	media: TelegramBroadcastMediaInput | null
}>()

const messageHtml = computed(() => sanitizeTelegramBroadcastHtml(props.body))
const hasMessage = computed(() => Boolean(messageHtml.value || props.media || props.buttons.length))
const buttonClass = (color: TelegramBroadcastButton['color']) =>
	({
		default: 'bg-white/90 text-[#168acd]',
		primary: 'bg-[#168acd] text-white',
		success: 'bg-[#35a854] text-white',
		danger: 'bg-[#e55c5c] text-white',
	})[color]
</script>

<template>
	<aside class="overflow-hidden rounded-[28px] border border-gray-200 bg-[#8aacc3] shadow-[0_20px_60px_rgba(15,23,42,0.16)] dark:border-white/10">
		<div class="flex items-center gap-3 bg-[#527da0] px-4 py-3 text-white"><div class="flex h-9 w-9 items-center justify-center rounded-full bg-white/20 text-sm">✈</div><div class="min-w-0"><p class="truncate text-sm font-semibold">{{ botLabel || 'Telegram-бот' }}</p><p class="text-xs text-white/70">предпросмотр сообщения</p></div></div>
		<div class="min-h-[530px] bg-[radial-gradient(circle_at_20%_20%,rgba(255,255,255,0.16),transparent_24%),linear-gradient(135deg,#8cb0c5,#759db6)] p-4">
			<div v-if="!hasMessage" class="mt-28 rounded-2xl bg-white/20 px-5 py-4 text-center text-sm text-white/80">Здесь появится сообщение в стиле Telegram.</div>
			<div v-else class="ml-auto max-w-[92%] overflow-hidden rounded-2xl rounded-br-md bg-white shadow-sm">
				<img v-if="media?.type === 'image'" :src="media.url" :alt="media.name" class="max-h-80 w-full object-cover" />
				<div v-else-if="media?.type === 'video'" class="relative flex aspect-video items-center justify-center bg-slate-800 text-4xl text-white"><video :src="media.url" muted playsinline preload="metadata" class="absolute inset-0 h-full w-full object-cover opacity-70" /><span class="relative">▶</span></div>
				<div v-else-if="media" class="flex items-center gap-3 bg-[#edf5f9] p-4 text-slate-700"><span class="text-3xl">{{ media.type === 'audio' ? '♫' : '⌁' }}</span><span class="min-w-0"><b class="block truncate text-sm">{{ media.name }}</b><small class="text-slate-400">{{ media.type === 'audio' ? 'Аудиофайл' : 'Документ' }}</small></span></div>
				<div v-if="messageHtml" class="telegram-text px-3 pb-1 pt-3 text-[15px] leading-5 text-slate-800" v-html="messageHtml" />
				<div v-if="buttons.length" class="space-y-px border-t border-slate-100 bg-slate-100">
					<span v-for="button in buttons" :key="button.id" class="block px-3 py-2 text-center text-sm font-medium" :class="buttonClass(button.color)">{{ button.text }}</span>
				</div>
				<div class="px-3 pb-2 text-right text-[10px] text-slate-400">{{ new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) }} ✓✓</div>
			</div>
		</div>
	</aside>
</template>

<style scoped>
.telegram-text :deep(b), .telegram-text :deep(strong) { font-weight: 700; }
.telegram-text :deep(i), .telegram-text :deep(em) { font-style: italic; }
.telegram-text :deep(u) { text-decoration: underline; }
.telegram-text :deep(s), .telegram-text :deep(strike), .telegram-text :deep(del) { text-decoration: line-through; }
.telegram-text :deep(pre) { overflow-x: auto; border-radius: 8px; background: #edf1f5; padding: 8px; font-size: 12px; }
.telegram-text :deep(blockquote) { margin: 0; border-left: 3px solid #168acd; padding-left: 8px; color: #4a6270; }
.telegram-text :deep(tg-spoiler) { border-radius: 4px; background: #a8b8c0; color: #a8b8c0; }
.telegram-text :deep(a) { color: #168acd; text-decoration: underline; }
</style>
