<script setup lang="ts">
import { FEED_AUDIENCES, REACTIONS } from '@community-club/shared'
import { renderFeedContentHtml } from '@community-club/shared'
import type { FeedMediaItem, FeedPostItem } from '@community-club/shared/types'
import AdminFeedMediaGrid from './AdminFeedMediaGrid.vue'
import AdminFeedRichText from './AdminFeedRichText.vue'

const props = defineProps<{
	item: Pick<
		FeedPostItem,
		| 'id'
		| 'audience'
		| 'content'
		| 'buttonLabel'
		| 'buttonUrl'
		| 'notifyAll'
		| 'media'
		| 'createdAt'
		| 'reactions'
	>
}>()

const previewHtml = computed(() => renderFeedContentHtml(props.item.content))
</script>

<template>
	<article class="overflow-hidden rounded-[30px] border border-gray-200 bg-[linear-gradient(180deg,rgba(255,255,255,0.98),rgba(248,250,252,0.98))] shadow-[0_24px_80px_rgba(15,23,42,0.12)] dark:border-white/10 dark:bg-[linear-gradient(180deg,rgba(17,24,39,0.98),rgba(8,10,15,0.98))] dark:shadow-[0_24px_80px_rgba(0,0,0,0.34)]">
		<div class="border-b border-gray-200/70 px-5 py-4 dark:border-white/8">
			<div class="flex flex-wrap items-center gap-2">
				<p class="text-sm font-semibold tracking-[0.14em] text-gray-900 uppercase dark:text-white/88">Community Club</p>
				<span class="rounded-full border border-amber-300/30 bg-amber-400/10 px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.16em] text-amber-700 dark:border-amber-300/15 dark:text-amber-100/80">
					{{ FEED_AUDIENCES[item.audience] }}
				</span>
			</div>
			<p class="mt-2 text-xs tracking-[0.18em] text-gray-400 uppercase dark:text-white/35">
				{{ new Date(item.createdAt).toLocaleString('ru-RU', { day: '2-digit', month: 'long', hour: '2-digit', minute: '2-digit' }) }}
			</p>
		</div>

		<div class="space-y-4 p-4 md:p-5">
			<AdminFeedMediaGrid v-if="item.media.length" :items="item.media as FeedMediaItem[]" />
			<AdminFeedRichText :html="previewHtml" />

			<a
				v-if="item.buttonLabel && item.buttonUrl"
				:href="item.buttonUrl"
				target="_blank"
				rel="noopener noreferrer"
				class="inline-flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-400/10 px-4 py-2 text-sm font-medium text-amber-700 transition dark:border-amber-300/20 dark:text-amber-50"
			>
				<span>{{ item.buttonLabel }}</span>
				<svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5h5m0 0v5m0-5L10 14" />
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 9v10h10" />
				</svg>
			</a>

			<div class="flex flex-wrap items-center gap-2 border-t border-gray-200/70 pt-2 dark:border-white/8">
				<div
					v-for="emoji in REACTIONS"
					:key="emoji"
					class="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-sm text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-white/60"
				>
					{{ emoji }}
				</div>
			</div>
		</div>
	</article>
</template>
