<script setup lang="ts">
defineProps<{
	html: string
}>()
</script>

<template>
	<div
		class="feed-rich-text text-[15px] leading-7 text-gray-800 dark:text-white/85 [overflow-wrap:anywhere] break-words"
		v-html="html"
	/>
</template>

<style scoped>
.feed-rich-text :deep(strong),
.feed-rich-text :deep(b) {
	font-weight: 700;
}

.feed-rich-text :deep(em),
.feed-rich-text :deep(i) {
	font-style: italic;
}

.feed-rich-text :deep(u) {
	text-decoration: underline;
	text-underline-offset: 0.16em;
}

.feed-rich-text :deep(s) {
	text-decoration: line-through;
}

.feed-rich-text :deep(.feed-inline-link) {
	color: rgb(217 119 6);
	text-decoration: underline;
	text-underline-offset: 0.18em;
}

html.dark .feed-rich-text :deep(.feed-inline-link) {
	color: rgb(251 191 36);
}
</style>
