<script setup lang="ts">
import type { FeedMediaItem } from '@community-club/shared/types'

defineProps<{
	items: FeedMediaItem[]
}>()

function getAspectRatio(item: FeedMediaItem) {
	if (item.width && item.height) {
		return `${item.width} / ${item.height}`
	}
	return item.type === 'video' ? '16 / 9' : '1 / 1'
}
</script>

<template>
	<div v-if="items.length" class="overflow-hidden rounded-[28px] border border-gray-200 bg-[#09070d] dark:border-white/10">
		<div class="grid grid-cols-2 gap-[2px] bg-white/5">
			<div
				v-for="(item, index) in items"
				:key="`${item.path}-${index}`"
				class="relative overflow-hidden bg-[#120f19]"
				:class="items.length === 1 ? 'col-span-2' : items.length === 3 && index === 0 ? 'row-span-2' : ''"
				:style="{ aspectRatio: getAspectRatio(item) }"
			>
				<div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.12),rgba(10,8,15,0.96))]" />
				<img
					v-if="item.type === 'image' && item.url"
					:src="item.url"
					:alt="item.name ?? 'Изображение'"
					class="relative z-[1] h-full w-full object-contain"
					draggable="false"
				/>
				<video
					v-else-if="item.url"
					:src="item.url"
					class="relative z-[1] h-full w-full object-contain"
					muted
					playsinline
					preload="metadata"
				/>
				<div
					v-if="item.type === 'video'"
					class="absolute inset-0 z-[2] flex items-center justify-center bg-black/12"
				>
					<div class="flex h-14 w-14 items-center justify-center rounded-full border border-white/20 bg-black/45 text-white shadow-2xl">
						<svg class="ml-1 h-7 w-7" fill="currentColor" viewBox="0 0 24 24">
							<path d="M8 5v14l11-7z" />
						</svg>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
