<script setup lang="ts">
import {
	CategoryScale,
	Chart as ChartJS,
	Filler,
	LineElement,
	LinearScale,
	PointElement,
	Title,
	Tooltip,
} from 'chart.js'
import { Line } from 'vue-chartjs'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Filler)

defineProps<{
	data: Record<string, unknown>
	options: Record<string, unknown>
}>()
</script>

<template>
	<div class="chart-shell">
		<Line :data="data" :options="options" />
	</div>
</template>

<style scoped>
.chart-shell {
	position: relative;
	width: 100%;
	height: 100%;
	min-width: 0;
	max-width: 100%;
	overflow: hidden;
}

.chart-shell :deep(canvas) {
	display: block;
	width: 100% !important;
	max-width: 100% !important;
	min-width: 0 !important;
}
</style>
