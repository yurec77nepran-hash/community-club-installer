<script setup lang="ts">
import type { AdminMediaLibraryItem, CursorPaginatedResponse } from '@community-club/shared/types'
import { ref, watch } from 'vue'

export type AdminHighlightsMediaSelection = {
	readonly mediaKey: string
	readonly previewUrl: string
}

const props = defineProps<{ open: boolean }>()
const emit = defineEmits<{
	close: []
	select: [selection: AdminHighlightsMediaSelection]
}>()

const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()
const fileInput = ref<HTMLInputElement | null>(null)
const images = ref<AdminMediaLibraryItem[]>([])
const loading = ref(false)
const uploading = ref(false)
const uploadProgress = ref<number | null>(null)
const libraryError = ref('')
const uploadError = ref('')

async function loadMedia() {
	loading.value = true
	libraryError.value = ''
	const response = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		'/api/admin/media-library?type=image&limit=60&sortBy=updatedAt&sortDir=desc',
	)
	if (response.success) {
		images.value = response.data.items
	} else {
		libraryError.value = response.error.message
	}
	loading.value = false
}

function closePicker() {
	if (!uploading.value) emit('close')
}

function selectMedia(item: Pick<AdminMediaLibraryItem, 'key' | 'url'>) {
	emit('select', { mediaKey: item.key, previewUrl: item.url })
}

async function uploadImage(event: Event) {
	if (!(event.target instanceof HTMLInputElement)) return
	const file = event.target.files?.[0]
	if (!file) return

	uploadError.value = ''
	if (!file.type.startsWith('image/')) {
		uploadError.value = 'Выберите изображение.'
		event.target.value = ''
		return
	}

	uploading.value = true
	uploadProgress.value = 0
	const response = await mediaUpload.uploadFile(file, {
		bucket: 'media',
		onProgress: (progress) => {
			uploadProgress.value = progress.percent
		},
	})
	if (response.success) {
		const uploadedImage: AdminMediaLibraryItem = {
			key: response.data.path,
			name: file.name,
			title: file.name,
			url: response.data.url,
			type: 'image',
			size: response.data.size,
			lastModified: new Date(),
			note: null,
			folderId: null,
		}
		images.value = [
			uploadedImage,
			...images.value.filter((image) => image.key !== uploadedImage.key),
		]
		selectMedia(uploadedImage)
	} else {
		uploadError.value = response.error.message
	}
	uploading.value = false
	uploadProgress.value = null
	event.target.value = ''
}

watch(
	() => props.open,
	(open) => {
		if (open) void loadMedia()
	},
)
</script>

<template>
	<Teleport to="body">
		<div
			v-if="open"
			class="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-3 sm:items-center sm:p-4"
			role="dialog"
			aria-modal="true"
			aria-labelledby="highlights-media-picker-title"
			@click.self="closePicker"
		>
			<div
				class="max-h-[85vh] w-full max-w-2xl overflow-hidden rounded-3xl border border-gray-200/70 bg-white p-4 dark:border-white/10 dark:bg-gray-900"
				:aria-busy="loading || uploading"
			>
				<div class="flex items-center justify-between gap-3">
					<h3 id="highlights-media-picker-title" class="text-lg font-semibold text-gray-900 dark:text-white">
						Выбор картинки
					</h3>
					<button
						type="button"
						class="btn-icon"
						aria-label="Закрыть выбор картинки"
						:disabled="uploading"
						@click="closePicker"
					>
						✕
					</button>
				</div>

				<div class="mt-4">
					<input ref="fileInput" class="hidden" type="file" accept="image/*" @change="uploadImage" />
					<button
						type="button"
					class="btn-primary min-h-11 w-full sm:w-auto"
						:disabled="uploading"
						@click="fileInput?.click()"
					>
						{{ uploading ? 'Загрузка изображения…' : 'Загрузить изображение' }}
					</button>
				</div>

				<div v-if="uploading && uploadProgress !== null" class="mt-3" aria-live="polite">
					<div class="mb-1 flex items-center justify-between gap-3 text-xs text-gray-500 dark:text-gray-400">
						<span>Загрузка изображения</span>
						<span>{{ uploadProgress }}%</span>
					</div>
					<progress class="h-2 w-full overflow-hidden rounded-full accent-primary-600" :value="uploadProgress" max="100" />
				</div>
				<p v-if="uploadError" class="mt-3 text-sm text-red-500" role="alert">{{ uploadError }}</p>

				<div v-if="loading" class="py-8 text-center text-gray-500 dark:text-gray-300">Загрузка…</div>
				<p v-else-if="libraryError" class="py-8 text-center text-sm text-red-500" role="alert">
					{{ libraryError }}
				</p>
				<div v-else-if="images.length === 0" class="py-8 text-center text-gray-500 dark:text-gray-300">
					В медиатеке нет изображений. Загрузите первое изображение здесь.
				</div>
				<div v-else class="mt-4 grid max-h-[58vh] grid-cols-2 gap-3 overflow-y-auto sm:grid-cols-4">
					<button
						v-for="item in images"
						:key="item.key"
						type="button"
						class="overflow-hidden rounded-xl border border-gray-200/70 transition hover:border-primary-400 disabled:cursor-not-allowed disabled:opacity-50 dark:border-white/10"
						:aria-label="`Выбрать изображение: ${item.title}`"
						:disabled="uploading"
						@click="selectMedia(item)"
					>
						<img :src="item.url" class="aspect-square w-full object-cover" :alt="item.title" />
					</button>
				</div>
			</div>
		</div>
	</Teleport>
</template>

<style scoped>
.btn-icon {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	height: 2.75rem;
	min-width: 2.75rem;
	padding: 0 0.5rem;
	border-radius: 0.75rem;
	border: 1px solid rgba(255, 255, 255, 0.12);
	background: rgba(255, 255, 255, 0.05);
	color: inherit;
	font-size: 0.85rem;
	cursor: pointer;
}
.btn-icon:disabled {
	opacity: 0.35;
	cursor: not-allowed;
}
</style>
