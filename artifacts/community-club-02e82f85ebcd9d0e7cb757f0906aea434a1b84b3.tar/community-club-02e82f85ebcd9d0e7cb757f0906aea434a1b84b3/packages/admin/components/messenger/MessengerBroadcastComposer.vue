<script setup lang="ts">
type Provider = 'telegram' | 'vk' | 'max'
type Connection = {
	id: number
	provider: Provider
	label: string
	externalId: string
	isActive: boolean
}
type Campaign = {
	id: number
	name: string
	connectionIds: number[]
	body: string
	status: 'scheduled' | 'processing' | 'paused' | 'completed' | 'failed' | 'cancelled'
	sendAt: string
	audienceSize: number
	sentCount: number
	failedCount: number
}
type Audience = { contacts: number; uniqueUsers: number; overlapUsers: number }

const api = useAdminApi()
const loading = ref(true)
const saving = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const connections = ref<Connection[]>([])
const campaigns = ref<Campaign[]>([])
const audience = ref<Audience>({ contacts: 0, uniqueUsers: 0, overlapUsers: 0 })
const form = ref({ name: '', connectionIds: [] as number[], body: '', sendAt: '' })

const activeConnections = computed(() =>
	connections.value.filter((connection) => connection.isActive),
)
const selectedConnections = computed(() =>
	activeConnections.value.filter((connection) => form.value.connectionIds.includes(connection.id)),
)
const includesVk = computed(() =>
	selectedConnections.value.some((connection) => connection.provider === 'vk'),
)

function providerLabel(provider: Provider) {
	return { telegram: 'Telegram', vk: 'VK', max: 'MAX' }[provider]
}
function statusLabel(status: Campaign['status']) {
	return {
		scheduled: 'Запланирована',
		processing: 'Отправляется',
		paused: 'Приостановлена',
		completed: 'Завершена',
		failed: 'Ошибка',
		cancelled: 'Остановлена',
	}[status]
}
function formatDate(value: string) {
	return new Date(value).toLocaleString('ru-RU', {
		day: '2-digit',
		month: '2-digit',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
	})
}
function toggleConnection(id: number) {
	form.value.connectionIds = form.value.connectionIds.includes(id)
		? form.value.connectionIds.filter((item) => item !== id)
		: [...form.value.connectionIds, id]
}
async function load() {
	loading.value = true
	const res = await api.get<{ connections: Connection[]; campaigns: Campaign[] }>(
		'/api/admin/broadcasts',
	)
	if (res.success) {
		connections.value = res.data.connections
		campaigns.value = res.data.campaigns
		form.value.connectionIds = form.value.connectionIds.filter((id) =>
			res.data.connections.some((connection) => connection.id === id && connection.isActive),
		)
	} else errorMessage.value = res.error.message
	loading.value = false
}
async function loadAudience() {
	if (!form.value.connectionIds.length) {
		audience.value = { contacts: 0, uniqueUsers: 0, overlapUsers: 0 }
		return
	}
	const res = await api.get<Audience>(
		`/api/admin/broadcasts/audience?ids=${form.value.connectionIds.join(',')}`,
	)
	if (res.success) audience.value = res.data
}
async function createBroadcast() {
	errorMessage.value = ''
	successMessage.value = ''
	saving.value = true
	const res = await api.post<Campaign>('/api/admin/broadcasts', {
		name: form.value.name.trim(),
		connectionIds: form.value.connectionIds,
		body: form.value.body,
		sendAt: form.value.sendAt ? new Date(form.value.sendAt).toISOString() : undefined,
	})
	if (res.success) {
		successMessage.value = form.value.sendAt
			? 'Рассылка запланирована.'
			: 'Рассылка поставлена в очередь.'
		form.value = { name: '', connectionIds: form.value.connectionIds, body: '', sendAt: '' }
		await load()
	} else errorMessage.value = res.error.message
	saving.value = false
}
async function changeStatus(id: number, action: 'pause' | 'resume' | 'stop') {
	if (
		action === 'stop' &&
		!confirm('Остановить рассылку? Неотправленные сообщения не будут доставлены.')
	)
		return
	const res = await api.post(`/api/admin/broadcasts/${id}/${action}`, {})
	if (res.success) await load()
	else errorMessage.value = res.error.message
}

watch(
	() => form.value.connectionIds,
	() => void loadAudience(),
	{ deep: true },
)
onMounted(load)
</script>

<template>
	<section class="glass rounded-2xl p-4 sm:p-5">
		<div class="mb-5"><h2 class="font-semibold dark:text-white">Рассылка в мессенджеры</h2><p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Выберите Telegram, VK и MAX. Контакты, полученные ботами, добавляются в карточки пользователей автоматически.</p></div>
		<div v-if="loading" class="text-sm text-gray-500">Загружаю каналы…</div>
		<form v-else class="grid gap-4" @submit.prevent="createBroadcast">
			<div v-if="!activeConnections.length" class="rounded-xl bg-amber-500/10 p-3 text-sm text-amber-800 dark:text-amber-200">Подключите VK или MAX выше. Telegram-боты из настроек уже доступны в расширенном редакторе ниже.</div>
			<section v-else><div class="mb-2 flex items-baseline justify-between"><h3 class="text-sm font-medium dark:text-white">Каналы и аудитория</h3><span class="text-xs text-gray-500">{{ audience.contacts }} контактов</span></div><div class="grid gap-2 sm:grid-cols-2"><label v-for="connection in activeConnections" :key="connection.id" class="flex cursor-pointer items-start gap-3 rounded-xl border border-gray-200 p-3 transition has-[:checked]:border-primary-400 has-[:checked]:bg-primary-50/60 dark:border-white/10 dark:has-[:checked]:bg-primary-500/10"><input type="checkbox" :checked="form.connectionIds.includes(connection.id)" @change="toggleConnection(connection.id)" /><span><b class="block text-sm dark:text-white">{{ providerLabel(connection.provider) }} · {{ connection.label }}</b><small class="text-xs text-gray-500">{{ connection.externalId }}</small></span></label></div><p class="mt-2 text-xs text-gray-500">Уникальных людей: {{ audience.uniqueUsers }}<span v-if="audience.overlapUsers"> · пересечений: {{ audience.overlapUsers }}</span></p></section>
			<div class="grid gap-3 sm:grid-cols-2"><label class="space-y-1"><span class="text-xs text-gray-500">Название для истории</span><input v-model="form.name" required class="glass-input" /></label><label class="space-y-1"><span class="text-xs text-gray-500">Когда отправить</span><input v-model="form.sendAt" type="datetime-local" class="glass-input" /></label></div>
			<label class="space-y-1"><span class="text-xs text-gray-500">Сообщение</span><textarea v-model="form.body" required maxlength="4000" rows="7" class="glass-input resize-y" placeholder="Текст рассылки" /></label>
			<p class="text-xs text-gray-500"><template v-if="includesVk">В VK текст отправляется без HTML-разметки. Кнопки и медиа скрыты, потому что выбранный канал их не поддерживает в этом сценарии.</template><template v-else>Для сообщений с медиа, цветными кнопками и визуальным предпросмотром используйте расширенный Telegram-редактор ниже.</template></p>
			<button class="btn-primary" :disabled="saving || !form.connectionIds.length">{{ saving ? 'Сохраняю…' : form.sendAt ? 'Запланировать' : 'Начать рассылку' }}</button>
		</form>
		<p v-if="errorMessage" class="mt-3 text-sm text-red-500">{{ errorMessage }}</p><p v-else-if="successMessage" class="mt-3 text-sm text-green-600">{{ successMessage }}</p>

		<div v-if="campaigns.length" class="mt-6 border-t border-gray-200/70 pt-5 dark:border-white/10"><h3 class="mb-3 text-sm font-medium dark:text-white">История мессенджеров</h3><div class="space-y-3"><article v-for="campaign in campaigns" :key="campaign.id" class="rounded-xl border border-gray-200/70 p-3 dark:border-white/10"><div class="flex flex-wrap items-start justify-between gap-2"><div><p class="text-sm font-medium dark:text-white">{{ campaign.name }}</p><p class="mt-1 text-xs text-gray-500">{{ formatDate(campaign.sendAt) }} · {{ campaign.audienceSize }} получателей · {{ campaign.sentCount }} отправлено<span v-if="campaign.failedCount"> · {{ campaign.failedCount }} ошибок</span></p></div><span class="rounded-full bg-primary-500/10 px-2 py-1 text-xs text-primary-700 dark:text-primary-300">{{ statusLabel(campaign.status) }}</span></div><p class="mt-2 whitespace-pre-wrap text-sm text-gray-600 dark:text-gray-300">{{ campaign.body }}</p><div class="mt-3 flex gap-3 text-xs"><button v-if="campaign.status === 'processing'" class="text-amber-600 hover:underline" @click="changeStatus(campaign.id, 'pause')">Пауза</button><button v-if="campaign.status === 'paused'" class="text-green-600 hover:underline" @click="changeStatus(campaign.id, 'resume')">Возобновить</button><button v-if="campaign.status === 'processing' || campaign.status === 'paused' || campaign.status === 'scheduled'" class="text-red-500 hover:underline" @click="changeStatus(campaign.id, 'stop')">Остановить</button></div></article></div></div>
	</section>
</template>
