<script setup lang="ts">
type Provider = 'telegram' | 'vk' | 'max'
type Connection = {
	id: number
	provider: Provider
	externalId: string
	label: string
	isActive: boolean
	webhookUrl: string | null
}

const api = useAdminApi()
const loading = ref(true)
const saving = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const connections = ref<Connection[]>([])
const form = ref({
	provider: 'vk' as Provider,
	token: '',
	externalId: '',
	label: '',
	confirmationCode: '',
	callbackSecret: '',
})

const providerMeta: Record<Provider, { title: string; hint: string }> = {
	telegram: { title: 'Telegram-бот', hint: 'Проверим токен и получим имя бота автоматически.' },
	vk: { title: 'VK-сообщество', hint: 'Нужны токен сообщества и его числовой ID.' },
	max: { title: 'MAX-бот', hint: 'Webhook подключится автоматически после проверки токена.' },
}

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}

async function loadConnections() {
	loading.value = true
	const res = await api.get<{ connections: Connection[] }>('/api/admin/broadcasts')
	if (res.success) connections.value = res.data.connections
	else errorMessage.value = res.error.message
	loading.value = false
}

async function saveConnection() {
	resetMessages()
	saving.value = true
	const res = await api.post<Connection>('/api/admin/broadcasts/connections', {
		...form.value,
		externalId: form.value.externalId || undefined,
		label: form.value.label || undefined,
		confirmationCode: form.value.confirmationCode || undefined,
		callbackSecret: form.value.callbackSecret || undefined,
	})
	if (res.success) {
		form.value = {
			provider: 'vk',
			token: '',
			externalId: '',
			label: '',
			confirmationCode: '',
			callbackSecret: '',
		}
		successMessage.value = 'Подключение сохранено.'
		await loadConnections()
	} else errorMessage.value = res.error.message
	saving.value = false
}

function providerLabel(provider: Provider) {
	return providerMeta[provider].title
}

onMounted(loadConnections)
</script>

<template>
	<section class="glass rounded-2xl p-4 sm:p-5">
		<div class="mb-5 flex flex-wrap items-start justify-between gap-3">
			<div><h2 class="font-semibold dark:text-white">Подключения</h2><p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Каналы хранят токены на сервере в зашифрованном виде.</p></div>
			<span class="rounded-full bg-primary-500/10 px-2.5 py-1 text-xs font-medium text-primary-700 dark:text-primary-300">{{ connections.length }} подключений</span>
		</div>

		<div v-if="loading" class="text-sm text-gray-500">Загружаю подключения…</div>
		<div v-else-if="connections.length" class="mb-5 divide-y divide-gray-100/70 rounded-xl border border-gray-200/70 px-3 dark:divide-white/5 dark:border-white/10">
			<div v-for="connection in connections" :key="connection.id" class="flex flex-wrap items-center justify-between gap-3 py-3">
				<div><p class="text-sm font-medium dark:text-white">{{ providerLabel(connection.provider) }} · {{ connection.label }}</p><p class="mt-0.5 text-xs text-gray-500 dark:text-gray-400">{{ connection.externalId }}</p><p v-if="connection.webhookUrl" class="mt-1 break-all font-mono text-[11px] text-gray-500 dark:text-gray-400">Callback URL: {{ connection.webhookUrl }}</p></div>
				<span class="rounded-full px-2 py-1 text-xs" :class="connection.isActive ? 'bg-green-500/10 text-green-700 dark:text-green-300' : 'bg-gray-500/10 text-gray-600 dark:text-gray-300'">{{ connection.isActive ? 'Активно' : 'Отключено' }}</span>
			</div>
		</div>

		<form class="grid gap-3 sm:grid-cols-2" @submit.prevent="saveConnection">
			<label class="space-y-1"><span class="text-xs text-gray-500">Канал</span><select v-model="form.provider" class="glass-input"><option value="vk">VK-сообщество</option><option value="max">MAX-бот</option><option value="telegram">Telegram-бот</option></select></label>
			<label class="space-y-1"><span class="text-xs text-gray-500">Название в админке</span><input v-model="form.label" class="glass-input" placeholder="Необязательно" /></label>
			<label v-if="form.provider === 'vk'" class="space-y-1"><span class="text-xs text-gray-500">ID VK-сообщества</span><input v-model="form.externalId" class="glass-input" inputmode="numeric" required placeholder="Например, 123456" /></label>
			<label class="space-y-1" :class="form.provider === 'vk' ? '' : 'sm:col-span-2'"><span class="text-xs text-gray-500">Токен</span><input v-model="form.token" class="glass-input" type="password" autocomplete="new-password" required /></label>
			<template v-if="form.provider === 'vk'"><label class="space-y-1"><span class="text-xs text-gray-500">Код подтверждения Callback API</span><input v-model="form.confirmationCode" class="glass-input" placeholder="Из настроек VK" /></label><label class="space-y-1"><span class="text-xs text-gray-500">Секрет Callback API</span><input v-model="form.callbackSecret" class="glass-input" type="password" placeholder="Необязательно" /></label></template>
			<p class="sm:col-span-2 text-xs text-gray-500 dark:text-gray-400">{{ providerMeta[form.provider].hint }}</p>
			<button class="btn-primary sm:col-span-2" :disabled="saving">{{ saving ? 'Проверяю…' : `Подключить: ${providerMeta[form.provider].title}` }}</button>
		</form>
		<p v-if="errorMessage" class="mt-3 text-sm text-red-500">{{ errorMessage }}</p><p v-else-if="successMessage" class="mt-3 text-sm text-green-600">{{ successMessage }}</p>
		<p v-if="form.provider === 'vk'" class="mt-4 rounded-xl bg-amber-500/10 p-3 text-xs text-amber-800 dark:text-amber-200">После сохранения добавьте Callback URL из списка подключений в настройках VK и включите события <code>message_new</code>, <code>message_allow</code>, <code>message_deny</code>.</p>
	</section>
</template>
