<script setup lang="ts">
import type { HomeExperienceSettings, HomeHighlightItem } from '@community-club/shared/types'
import { reactive, ref, watch } from 'vue'
import { normalizeHighlightSlots } from '../utils/highlight-slots'

type SlotUploadState = {
	uploading: boolean
	progress: number | null
	error: string
	status: string
}

const props = defineProps<{ modelValue: HomeExperienceSettings }>()
const emit = defineEmits<(event: 'update:modelValue', value: HomeExperienceSettings) => void>()
const mediaUpload = useAdminMediaUpload()
const createSlotId = (kind: 'highlight' | 'story', slotIndex: number) =>
	`${kind}-slot-${slotIndex + 1}`

const slots = ref(
	normalizeHighlightSlots(props.modelValue.highlights, props.modelValue.stories, createSlotId),
)
const uploadStates = reactive<SlotUploadState[]>(
	Array.from({ length: 5 }, () => ({ uploading: false, progress: null, error: '', status: '' })),
)

function emitSlots(highlights: HomeHighlightItem[]) {
	emit('update:modelValue', { ...props.modelValue, highlights })
}

function replaceSlotMedia(index: number, mediaKey: string | null, mediaUrl: string | null) {
	const highlight = slots.value[index]
	const story = highlight?.stories[0]
	if (!highlight || !story) return

	const nextSlots = slots.value.map((slot, slotIndex) =>
		slotIndex === index ? { ...slot, stories: [{ ...story, mediaKey, mediaUrl }] } : slot,
	)
	slots.value = nextSlots
	emitSlots(nextSlots)
}

async function uploadImage(event: Event, index: number) {
	if (!(event.target instanceof HTMLInputElement)) return
	const input = event.target
	const file = input.files?.[0]
	if (!file) return
	const state = uploadStates[index]
	if (!state || state.uploading) return

	state.error = ''
	state.status = ''
	if (!file.type.startsWith('image/')) {
		state.error = 'Выберите изображение.'
		input.value = ''
		return
	}

	state.uploading = true
	state.progress = 0
	const response = await mediaUpload.uploadFile(file, {
		bucket: 'media',
		onProgress: (progress) => {
			state.progress = progress.percent
		},
	})
	if (response.success) {
		replaceSlotMedia(index, response.data.path, response.data.url)
		state.status = `Изображение хайлайта ${index + 1} загружено.`
	} else {
		state.error = response.error.message
	}
	state.uploading = false
	state.progress = null
	input.value = ''
}

function clearSlot(index: number) {
	const state = uploadStates[index]
	if (state) {
		state.error = ''
		state.status = `Изображение хайлайта ${index + 1} очищено.`
	}
	replaceSlotMedia(index, null, null)
}

watch(
	() => props.modelValue.highlights,
	(nextHighlights) => {
		const normalized = normalizeHighlightSlots(
			nextHighlights,
			props.modelValue.stories,
			createSlotId,
		)
		if (JSON.stringify(normalized) !== JSON.stringify(slots.value)) slots.value = normalized
	},
	{ deep: true },
)

if (JSON.stringify(props.modelValue.highlights) !== JSON.stringify(slots.value)) {
	emitSlots(slots.value)
}
</script>

<template>
	<div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5">
		<article
			v-for="(highlight, index) in slots"
			:key="highlight.id"
			class="rounded-2xl border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
			:aria-busy="uploadStates[index]?.uploading"
		>
			<h3 class="mb-3 text-sm font-semibold text-gray-900 dark:text-white">
				Хайлайт {{ index + 1 }}
			</h3>

			<div class="mx-auto aspect-[9/16] w-full max-w-[300px] overflow-hidden rounded-[20px] border border-gray-200/70 bg-gray-100 dark:border-white/10 dark:bg-white/[0.04]">
				<img
					v-if="highlight.stories[0]?.mediaUrl"
					:src="highlight.stories[0].mediaUrl"
					:alt="`Изображение хайлайта ${index + 1}`"
					class="h-full w-full object-cover object-center"
				/>
				<div
					v-else
					class="flex h-full items-center justify-center px-4 text-center text-sm text-gray-500 dark:text-gray-400"
				>
					Изображение не загружено
				</div>
			</div>

			<div class="mt-4 grid gap-2">
				<label
					class="btn-primary flex min-h-11 cursor-pointer items-center justify-center text-center focus-within:outline focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-primary-400"
					:class="uploadStates[index]?.uploading ? 'cursor-not-allowed opacity-50' : ''"
				>
					{{
						uploadStates[index]?.uploading
							? 'Загрузка…'
							: highlight.stories[0]?.mediaKey
								? 'Заменить изображение'
								: 'Загрузить изображение'
					}}
					<input
						:id="`highlight-image-${index + 1}`"
						type="file"
						accept="image/*"
						class="sr-only"
						:aria-label="`Загрузить изображение для хайлайта ${index + 1}`"
						:disabled="uploadStates[index]?.uploading"
						@change="uploadImage($event, index)"
					/>
				</label>
				<button
					type="button"
					class="btn-secondary min-h-11 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-400 disabled:cursor-not-allowed disabled:opacity-50"
					:disabled="uploadStates[index]?.uploading || !highlight.stories[0]?.mediaKey"
					:aria-label="`Очистить хайлайт ${index + 1}`"
					@click="clearSlot(index)"
				>
					Очистить
				</button>
			</div>

			<div
				v-if="uploadStates[index]?.uploading && uploadStates[index]?.progress !== null"
				class="mt-3"
				aria-live="polite"
			>
				<div class="mb-1 flex justify-between gap-3 text-xs text-gray-500 dark:text-gray-400">
					<span>Загрузка</span>
					<span>{{ uploadStates[index]?.progress }}%</span>
				</div>
				<progress
					class="h-2 w-full overflow-hidden rounded-full accent-primary-600"
					:value="uploadStates[index]?.progress ?? 0"
					max="100"
					:aria-label="`Загрузка изображения для хайлайта ${index + 1}`"
				/>
			</div>
			<p class="sr-only" role="status" aria-live="polite">
				{{ uploadStates[index]?.status }}
			</p>
			<p v-if="uploadStates[index]?.error" class="mt-3 text-sm text-red-500" role="alert">
				{{ uploadStates[index]?.error }}
			</p>
		</article>
	</div>
</template>
