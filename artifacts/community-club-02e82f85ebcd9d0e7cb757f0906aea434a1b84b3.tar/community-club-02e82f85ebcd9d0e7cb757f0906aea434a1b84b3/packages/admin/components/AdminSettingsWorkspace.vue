<script setup lang="ts">
import type {
	AdminMediaLibraryItem,
	AdminRuntimeSettings,
	AdminTelegramBotAuthSettingsPayload,
	AdminTestAccessSettingsPayload,
	AppNavigationSettings,
	AuthLoginSettings,
	CursorPaginatedResponse,
	CustomDomainStatus,
	DomainProvisionResult,
	GuestContentAccessSettings,
	HomeBannerActionKind,
	HomeBannerItem,
	HomeBannerShape,
	HomeCustomPage,
	HomeCustomPageBlock,
	HomeExperienceSettings,
	HomeSectionGridLayout,
	HomeSectionItem,
	HomeStoryItem,
	HomeStoryLayout,
	SiteBrandingSettings,
} from '@community-club/shared/types'

type MaterialTypeOption = {
	key: string
	label: string
	system: boolean
	usedCount: number
}

type MediaTarget =
	| { type: 'logo' }
	| { type: 'mainBanner' }
	| { type: 'banner'; index: number }
	| { type: 'story'; index: number }
	| { type: 'section'; index: number }
	| { type: 'pageBlock'; pageIndex: number; blockIndex: number }
	| { type: 'centerButton' }

type SettingsTabKey =
	| 'brand'
	| 'access'
	| 'domain'
	| 'home'
	| 'sections'
	| 'stories'
	| 'pages'
	| 'media'
	| 'header'
	| 'menu'

type SettingsWorkspaceMode = 'settings' | 'design'

const props = withDefaults(defineProps<{ mode?: SettingsWorkspaceMode }>(), {
	mode: 'settings',
})
const api = useAdminApi()
const mediaUpload = useAdminMediaUpload()
const defaultButtonBackgroundColor = '#d42d2f'
const defaultAppBackgroundColor = '#141414'
const defaultAppSurfaceColor = '#242424'
const defaultAppTextColor = '#f4f4f5'
const defaultAppAccentColor = '#d42d2f'

const defaultAppNavigation: AppNavigationSettings = {
	header: {
		enabled: true,
		showOnAllPages: false,
		order: ['logo', 'name', 'notifications', 'avatar'],
		logoMode: 'image',
		nameMode: 'club',
	},
	menu: {
		items: [
			{
				id: 'materials',
				label: 'Шаблоны',
				icon: 'cube',
				path: '/app/materials',
				requiresAuth: false,
				requiresAccess: true,
			},
			{
				id: 'calendar',
				label: 'Уроки',
				icon: 'book',
				path: '/app/materials?type=courses&section=lessons',
				requiresAuth: false,
				requiresAccess: true,
			},
			{
				id: 'feed',
				label: 'Инструменты',
				icon: 'wrench',
				path: '/app/materials?type=other&section=tools',
				requiresAuth: false,
				requiresAccess: true,
			},
			{
				id: 'profile',
				label: 'Профиль',
				icon: 'user',
				path: '/app/profile',
				requiresAuth: true,
				requiresAccess: false,
			},
		],
		centerButton: {
			enabled: true,
			icon: 'spark',
			imageKey: null,
			imageUrl: null,
			glowEnabled: true,
			pressEffectEnabled: true,
			actionPath: '/app',
			requiresAuth: false,
		},
		backgroundColor: '#101012',
		borderColor: '#34312d',
		borderRadius: 40,
		marginBottom: 7,
		marginSide: 6,
		iconStrokeColor: null,
		iconGlowEnabled: true,
		iconHighlightEnabled: true,
		activeIconColor: '#f0c75f',
		inactiveIconColor: '#d3c4ad',
		startActivePath: '/app',
	},
}

const form = reactive({
	clubName: 'Community Club',
	homeLogoEnabled: true,
	homeLogoMediaKey: null as string | null,
	buttonBackgroundColor: defaultButtonBackgroundColor,
	appBackgroundColor: defaultAppBackgroundColor,
	appSurfaceColor: defaultAppSurfaceColor,
	appTextColor: defaultAppTextColor,
	appAccentColor: defaultAppAccentColor,
	passwordEnabled: true,
	telegramCodeEnabled: true,
	maxCodeEnabled: false,
	defaultMethod: 'password' as AuthLoginSettings['defaultMethod'],
	botAuthEnabled: false,
	botHandle: '',
	noAccessText: 'У вас нет доступа на этот момент.',
	codeMessageText: 'Ваш код входа в клуб: {code}. Действует 10 минут.',
	subscriptionButtonLabel: 'Оплатить подписку',
	subscriptionButtonUrl: '',
	openAppButtonLabel: 'Открыть приложение',
	ownerHandle: '',
	testAccessEnabled: false,
	testAccessDays: 7,
	guestContentAccessLevel: 'cards' as GuestContentAccessSettings['level'],
	customDomain: '',
	telegramBotToken: '',
	maxBotToken: '',
	maxApiUrl: 'https://platform-api.max.ru',
	homeExperience: {
		mainBanner: {
			mediaKey: null,
			mediaUrl: null,
			alt: 'Главный баннер клуба',
		},
		banners: [],
		bannerShape: 'rounded',
		stories: [],
		highlights: [],
		sectionLayout: 'featured',
		sections: [],
		customPages: [],
	} as HomeExperienceSettings,
	appNavigation: JSON.parse(JSON.stringify(defaultAppNavigation)) as AppNavigationSettings,
})
const savedSettings = ref<SiteBrandingSettings | null>(null)
const savedAuthSettings = ref<AuthLoginSettings | null>(null)
const savedTelegramBotAuthSettings = ref<AdminTelegramBotAuthSettingsPayload | null>(null)
const savedTestAccessSettings = ref<AdminTestAccessSettingsPayload | null>(null)
const savedGuestContentAccessSettings = ref<GuestContentAccessSettings | null>(null)
const savedRuntimeSettings = ref<AdminRuntimeSettings | null>(null)
const savedHomeExperience = ref<HomeExperienceSettings | null>(null)
const savedAppNavigation = ref<AppNavigationSettings | null>(null)
const images = ref<AdminMediaLibraryItem[]>([])
const selectedMainBannerImage = ref<AdminMediaLibraryItem | null>(null)
const materialTypeOptions = ref<MaterialTypeOption[]>([])
const loading = ref(true)
const mediaLoading = ref(true)
const saving = ref(false)
const logoUploading = ref(false)
const logoUploadProgress = ref<number | null>(null)
const checkingDomain = ref(false)
const provisioningDomain = ref(false)
const provisionResult = ref<DomainProvisionResult | null>(null)
const clearTelegramToken = ref(false)
const clearMaxToken = ref(false)
const errorMessage = ref('')
const successMessage = ref('')
const search = ref('')
const mediaTarget = ref<MediaTarget>({
	type: 'logo',
})
const logoUploadInput = ref<HTMLInputElement | null>(null)
const activeTab = ref<SettingsTabKey>(props.mode === 'design' ? 'brand' : 'access')

const allSettingsTabs: Array<{ key: SettingsTabKey; label: string }> = [
	{ key: 'brand', label: 'Бренд' },
	{ key: 'access', label: 'Вход' },
	{ key: 'domain', label: 'Домен' },
	{ key: 'home', label: 'Главная' },
	{ key: 'sections', label: 'Разделы' },
	{ key: 'stories', label: 'Хайлайты' },
	{ key: 'pages', label: 'Страницы' },
	{ key: 'media', label: 'Медиа' },
	{ key: 'header', label: 'Шапка' },
	{ key: 'menu', label: 'Меню' },
]

const designTabKeys = new Set<SettingsTabKey>([
	'brand',
	'home',
	'sections',
	'stories',
	'pages',
	'media',
	'header',
	'menu',
])
const settingsTabs = computed(() =>
	allSettingsTabs.filter((tab) =>
		props.mode === 'design' ? designTabKeys.has(tab.key) : !designTabKeys.has(tab.key),
	),
)
const pageTitle = computed(() => (props.mode === 'design' ? 'Дизайн' : 'Настройки'))
const previewVersion = ref(0)
const selectedPreviewDeviceId = ref('iphone-17-pro')
const previewDeviceGroups = [
	{
		label: 'Apple iPhone',
		devices: [
			{ id: 'iphone-17-pro-max', label: 'iPhone 17 Pro Max', width: 440, height: 956 },
			{ id: 'iphone-17-air', label: 'iPhone 17 Air', width: 420, height: 912 },
			{ id: 'iphone-17-pro', label: 'iPhone 17 / 17 Pro', width: 402, height: 874 },
			{ id: 'iphone-16-pro-max', label: 'iPhone 16 Pro Max', width: 440, height: 956 },
			{ id: 'iphone-16-pro', label: 'iPhone 16 Pro', width: 402, height: 874 },
			{ id: 'iphone-16-plus', label: 'iPhone 16 Plus', width: 430, height: 932 },
			{ id: 'iphone-16', label: 'iPhone 16', width: 393, height: 852 },
			{ id: 'iphone-16e', label: 'iPhone 16e', width: 390, height: 844 },
			{ id: 'iphone-15-pro-max', label: 'iPhone 15 Pro Max', width: 430, height: 932 },
			{ id: 'iphone-15', label: 'iPhone 15 / 15 Pro', width: 393, height: 852 },
			{ id: 'iphone-14-13', label: 'iPhone 14 / 13', width: 390, height: 844 },
		],
	},
	{
		label: 'Samsung Galaxy',
		devices: [
			{ id: 'galaxy-s25-ultra', label: 'Galaxy S25 Ultra', width: 384, height: 824 },
			{ id: 'galaxy-s25-plus', label: 'Galaxy S25+', width: 384, height: 832 },
			{ id: 'galaxy-s25', label: 'Galaxy S25', width: 360, height: 780 },
			{ id: 'galaxy-s24-ultra', label: 'Galaxy S24 Ultra', width: 384, height: 824 },
			{ id: 'galaxy-s24-plus', label: 'Galaxy S24+', width: 384, height: 832 },
			{ id: 'galaxy-s24', label: 'Galaxy S24', width: 360, height: 780 },
			{ id: 'galaxy-z-fold-7-cover', label: 'Galaxy Z Fold7 cover', width: 344, height: 882 },
			{ id: 'galaxy-z-fold-7-open', label: 'Galaxy Z Fold7 open', width: 768, height: 960 },
			{ id: 'galaxy-z-flip-7', label: 'Galaxy Z Flip7', width: 412, height: 915 },
			{ id: 'galaxy-a56-a55', label: 'Galaxy A56 / A55', width: 412, height: 915 },
			{ id: 'galaxy-a36-a35', label: 'Galaxy A36 / A35', width: 384, height: 854 },
		],
	},
	{
		label: 'Google Pixel',
		devices: [
			{ id: 'pixel-10-pro-xl', label: 'Pixel 10 Pro XL', width: 412, height: 915 },
			{ id: 'pixel-10-pro', label: 'Pixel 10 / 10 Pro', width: 412, height: 915 },
			{ id: 'pixel-10-fold-open', label: 'Pixel 10 Pro Fold open', width: 841, height: 892 },
			{ id: 'pixel-9-pro-xl', label: 'Pixel 9 Pro XL', width: 412, height: 915 },
			{ id: 'pixel-9', label: 'Pixel 9 / 9 Pro', width: 412, height: 915 },
			{ id: 'pixel-8', label: 'Pixel 8', width: 412, height: 915 },
		],
	},
	{
		label: 'Android breakpoints',
		devices: [
			{ id: 'android-small', label: 'Small Android', width: 360, height: 800 },
			{ id: 'android-medium', label: 'Medium Android', width: 390, height: 844 },
			{ id: 'android-large', label: 'Large Android', width: 412, height: 915 },
			{ id: 'android-xl', label: 'XL Android', width: 480, height: 1040 },
			{ id: 'foldable-open', label: 'Generic foldable open', width: 768, height: 960 },
		],
	},
	{
		label: 'Desktop',
		devices: [
			{ id: 'desktop-laptop', label: 'Laptop', width: 1366, height: 768, mode: 'desktop' },
			{ id: 'desktop-wide', label: 'Desktop 1440', width: 1440, height: 900, mode: 'desktop' },
			{
				id: 'desktop-fullhd',
				label: 'Desktop Full HD',
				width: 1920,
				height: 1080,
				mode: 'desktop',
			},
		],
	},
]
const previewDevices = previewDeviceGroups.flatMap((group) => group.devices)
const selectedPreviewDevice = computed(
	() =>
		previewDevices.find((device) => device.id === selectedPreviewDeviceId.value) ??
		previewDevices[0],
)
const appPreviewBaseUrl = computed(() => {
	if (!import.meta.client) return 'http://localhost:3000'
	return ['localhost', '127.0.0.1'].includes(window.location.hostname)
		? 'http://localhost:3000'
		: window.location.origin
})
const appPreviewSrc = computed(
	() => `${appPreviewBaseUrl.value}/app?adminPreview=${previewVersion.value}`,
)
const isDesktopPreview = computed(() => selectedPreviewDevice.value.mode === 'desktop')
const selectedPreviewScale = computed(() =>
	isDesktopPreview.value
		? Math.min(0.3, 420 / selectedPreviewDevice.value.width)
		: Math.min(
				0.88,
				296 / selectedPreviewDevice.value.width,
				650 / (selectedPreviewDevice.value.height + 52),
			),
)
const appPreviewStyle = computed(() => ({
	'--preview-width': `${selectedPreviewDevice.value.width}px`,
	'--preview-height': `${selectedPreviewDevice.value.height}px`,
	'--preview-scale': `${selectedPreviewScale.value}`,
	'--preview-display-width': `${(selectedPreviewDevice.value.width + (isDesktopPreview.value ? 0 : 32)) * selectedPreviewScale.value}px`,
	'--preview-display-height': `${(selectedPreviewDevice.value.height + (isDesktopPreview.value ? 36 : 52)) * selectedPreviewScale.value}px`,
}))

const basePageOptions = [
	{ label: 'Главная', value: '/app' },
	{ label: 'Чат клуба', value: '/app/chats' },
	{ label: 'Лента новостей', value: '/app/feed' },
	{ label: 'Материалы', value: '/app/materials' },
	{ label: 'Календарь', value: '/app/calendar' },
	{ label: 'Профиль', value: '/app/profile' },
	{ label: 'Поддержка', value: '/app/support' },
]
const defaultMaterialPageOptions = [
	{ label: 'Материалы: Курсы', value: '/app/content/courses' },
	{ label: 'Материалы: Эфиры', value: '/app/content/streams' },
	{ label: 'Материалы: Чек-листы', value: '/app/content/checklists' },
	{ label: 'Материалы: Прочее', value: '/app/content/other' },
]

const materialPageOptions = computed(() => {
	const options = [
		...materialTypeOptions.value.map((item) => ({
			label: `Материалы: ${item.label}`,
			value: `/app/content/${item.key}`,
		})),
		...defaultMaterialPageOptions,
	]
	const seen = new Set<string>()
	return options.filter((item) => {
		if (seen.has(item.value)) return false
		seen.add(item.value)
		return true
	})
})

const pageOptions = computed(() => [
	...basePageOptions,
	...materialPageOptions.value,
	...form.homeExperience.customPages.map((page) => ({
		label: `Страница: ${page.title || page.slug}`,
		value: `/app/page/${page.slug}`,
	})),
])

const actionOptions: Array<{ label: string; value: HomeBannerActionKind }> = [
	{ label: 'Сторисы', value: 'stories' },
	{ label: 'Страница приложения', value: 'internal' },
	{ label: 'Внешняя ссылка', value: 'external' },
]

const bannerShapeOptions: Array<{ label: string; value: HomeBannerShape }> = [
	{ label: 'Квадратные', value: 'rounded' },
	{ label: 'Круглые', value: 'circle' },
]

const storyLayoutOptions: Array<{ label: string; value: HomeStoryLayout }> = [
	{ label: 'Текст', value: 'text' },
	{ label: 'Картинка', value: 'image' },
	{ label: 'Картинка и текст', value: 'imageText' },
]

const sectionLayoutOptions: Array<{ label: string; value: HomeSectionGridLayout }> = [
	{ label: 'Разный размер', value: 'featured' },
	{ label: 'Один ряд', value: 'equalOneRow' },
	{ label: 'В две строки', value: 'equalTwoRows' },
]

const iconOptions = [
	{ label: 'Куб', value: 'cube' },
	{ label: 'Книга', value: 'book' },
	{ label: 'Ключ', value: 'wrench' },
	{ label: 'Микрофон', value: 'microphone' },
	{ label: 'Звезда', value: 'star' },
	{ label: 'Пуск', value: 'play' },
	{ label: 'Видео', value: 'video' },
	{ label: 'Чек', value: 'check' },
	{ label: 'Искра', value: 'spark' },
]

const headerBlockOptions: Array<{
	label: string
	value: AppNavigationSettings['header']['order'][number]
}> = [
	{ label: 'Логотип', value: 'logo' },
	{ label: 'Аватар', value: 'avatar' },
	{ label: 'Имя', value: 'name' },
	{ label: 'Уведомления', value: 'notifications' },
]

const menuIconOptions: Array<{
	label: string
	value: AppNavigationSettings['menu']['items'][number]['icon']
}> = [
	{ label: 'Дом', value: 'home' },
	{ label: 'Лента', value: 'feed' },
	{ label: 'Календарь', value: 'calendar' },
	{ label: 'Куб', value: 'cube' },
	{ label: 'Книга', value: 'book' },
	{ label: 'Ключ', value: 'wrench' },
	{ label: 'Профиль', value: 'user' },
	{ label: 'Уведомления', value: 'bell' },
	{ label: 'Поддержка', value: 'support' },
	{ label: 'Инфо', value: 'info' },
	{ label: 'Чаты', value: 'chats' },
	{ label: 'Материалы', value: 'materials' },
	{ label: 'Искра', value: 'spark' },
	{ label: 'Пуск', value: 'play' },
	{ label: 'Видео', value: 'video' },
	{ label: 'Чек', value: 'check' },
]

const selectedImage = computed(
	() => images.value.find((item) => item.key === form.homeLogoMediaKey) ?? null,
)
const selectedMediaKey = computed(() => {
	if (mediaTarget.value.type === 'logo') return form.homeLogoMediaKey
	if (mediaTarget.value.type === 'mainBanner') return form.homeExperience.mainBanner.mediaKey
	if (mediaTarget.value.type === 'banner') {
		return form.homeExperience.banners[mediaTarget.value.index]?.mediaKey ?? null
	}
	if (mediaTarget.value.type === 'story') {
		return form.homeExperience.stories[mediaTarget.value.index]?.mediaKey ?? null
	}
	if (mediaTarget.value.type === 'section') {
		return form.homeExperience.sections[mediaTarget.value.index]?.mediaKey ?? null
	}
	if (mediaTarget.value.type === 'centerButton') {
		return form.appNavigation.menu.centerButton.imageKey ?? null
	}
	return (
		form.homeExperience.customPages[mediaTarget.value.pageIndex]?.blocks[
			mediaTarget.value.blockIndex
		]?.mediaKey ?? null
	)
})

const previewLogoUrl = computed(() => {
	const savedLogoMediaKey = savedSettings.value?.homeLogoMediaKey
	if (selectedImage.value && form.homeLogoMediaKey !== savedLogoMediaKey) {
		return selectedImage.value.url
	}
	if (
		savedLogoMediaKey === form.homeLogoMediaKey &&
		savedLogoMediaKey &&
		savedSettings.value.homeLogoUrl
	) {
		return `/pwa-icon?size=512&format=webp&v=${encodeURIComponent(savedLogoMediaKey)}`
	}
	return null
})

const mainBannerPreviewUrl = computed(() => {
	const mediaKey = form.homeExperience.mainBanner.mediaKey
	if (selectedMainBannerImage.value?.key === mediaKey) return selectedMainBannerImage.value.url
	const selectedMedia = images.value.find((item) => item.key === mediaKey)
	if (selectedMedia) return selectedMedia.url
	if (savedHomeExperience.value?.mainBanner.mediaKey === mediaKey) {
		return savedHomeExperience.value.mainBanner.mediaUrl
	}
	return null
})

const selectedTitle = computed(() => selectedImage.value?.title || selectedImage.value?.name || '')
const buttonPreviewTextColor = computed(() => getReadableTextColor(form.buttonBackgroundColor))
const buttonPreviewStyle = computed(() => ({
	backgroundColor: form.buttonBackgroundColor,
	color: buttonPreviewTextColor.value,
}))

const menuBorderVisible = computed({
	get: () => form.appNavigation.menu.borderColor !== null,
	set: (visible: boolean) => {
		form.appNavigation.menu.borderColor = visible
			? (defaultAppNavigation.menu.borderColor ?? '#3f3f46')
			: null
	},
})
const menuBorderColorValue = computed<string>({
	get: () =>
		form.appNavigation.menu.borderColor ?? defaultAppNavigation.menu.borderColor ?? '#3f3f46',
	set: (value: string) => {
		if (menuBorderVisible.value) form.appNavigation.menu.borderColor = value
	},
})
const menuIconStrokeVisible = computed({
	get: () => form.appNavigation.menu.iconStrokeColor !== null,
	set: (visible: boolean) => {
		form.appNavigation.menu.iconStrokeColor = visible ? '#3f3f46' : null
	},
})
const menuIconStrokeColorValue = computed<string>({
	get: () => form.appNavigation.menu.iconStrokeColor ?? '#3f3f46',
	set: (value: string) => {
		if (menuIconStrokeVisible.value) form.appNavigation.menu.iconStrokeColor = value
	},
})
const menuFlushMode = computed({
	get: () =>
		form.appNavigation.menu.marginSide === 0 &&
		form.appNavigation.menu.marginBottom === 0 &&
		form.appNavigation.menu.borderRadius === 0,
	set: (flush: boolean) => {
		if (flush) {
			form.appNavigation.menu.marginSide = 0
			form.appNavigation.menu.marginBottom = 0
			form.appNavigation.menu.borderRadius = 0
		} else {
			form.appNavigation.menu.marginSide = defaultAppNavigation.menu.marginSide
			form.appNavigation.menu.marginBottom = defaultAppNavigation.menu.marginBottom
			form.appNavigation.menu.borderRadius = defaultAppNavigation.menu.borderRadius
		}
	},
})
const colorFields = computed(
	() =>
		[
			{ key: 'buttonBackgroundColor', label: 'Кнопки' },
			{ key: 'appBackgroundColor', label: 'Фон' },
			{ key: 'appSurfaceColor', label: 'Карточки' },
			{ key: 'appTextColor', label: 'Текст' },
			{ key: 'appAccentColor', label: 'Акцент' },
		] as const,
)

const hasChanges = computed(() => {
	if (!savedSettings.value) return true
	return (
		form.clubName.trim() !== savedSettings.value.clubName ||
		form.homeLogoEnabled !== savedSettings.value.homeLogoEnabled ||
		form.homeLogoMediaKey !== savedSettings.value.homeLogoMediaKey ||
		form.buttonBackgroundColor !== savedSettings.value.buttonBackgroundColor ||
		form.appBackgroundColor !== savedSettings.value.appBackgroundColor ||
		form.appSurfaceColor !== savedSettings.value.appSurfaceColor ||
		form.appTextColor !== savedSettings.value.appTextColor ||
		form.appAccentColor !== savedSettings.value.appAccentColor ||
		!savedAuthSettings.value ||
		form.passwordEnabled !== savedAuthSettings.value.passwordEnabled ||
		form.telegramCodeEnabled !== savedAuthSettings.value.telegramCodeEnabled ||
		form.maxCodeEnabled !== savedAuthSettings.value.maxCodeEnabled ||
		form.botAuthEnabled !== savedAuthSettings.value.botAuthEnabled ||
		form.defaultMethod !== savedAuthSettings.value.defaultMethod ||
		!savedTelegramBotAuthSettings.value ||
		form.botHandle !== savedTelegramBotAuthSettings.value.botHandle ||
		form.noAccessText !== savedTelegramBotAuthSettings.value.noAccessText ||
		form.codeMessageText !== savedTelegramBotAuthSettings.value.codeMessageText ||
		form.subscriptionButtonLabel !== savedTelegramBotAuthSettings.value.subscriptionButtonLabel ||
		form.subscriptionButtonUrl !== savedTelegramBotAuthSettings.value.subscriptionButtonUrl ||
		form.openAppButtonLabel !== savedTelegramBotAuthSettings.value.openAppButtonLabel ||
		form.ownerHandle !== savedTelegramBotAuthSettings.value.ownerHandle ||
		!savedTestAccessSettings.value ||
		form.testAccessEnabled !== savedTestAccessSettings.value.enabled ||
		form.testAccessDays !== savedTestAccessSettings.value.days ||
		!savedGuestContentAccessSettings.value ||
		form.guestContentAccessLevel !== savedGuestContentAccessSettings.value.level ||
		!savedRuntimeSettings.value ||
		form.customDomain.trim() !== (savedRuntimeSettings.value.customDomain ?? '') ||
		form.maxApiUrl.trim() !== savedRuntimeSettings.value.maxApiUrl ||
		Boolean(form.telegramBotToken.trim()) ||
		Boolean(form.maxBotToken.trim()) ||
		clearTelegramToken.value ||
		clearMaxToken.value ||
		!savedHomeExperience.value ||
		JSON.stringify(form.homeExperience) !== JSON.stringify(savedHomeExperience.value) ||
		!savedAppNavigation.value ||
		JSON.stringify(form.appNavigation) !== JSON.stringify(savedAppNavigation.value)
	)
})

const enabledLoginMethods = computed(() => [
	...(form.passwordEnabled ? [{ value: 'password', label: 'Email и пароль' }] : []),
	...(form.telegramCodeEnabled || form.botAuthEnabled
		? [{ value: 'telegram', label: 'Telegram' }]
		: []),
	...(form.maxCodeEnabled ? [{ value: 'max', label: 'Код в MAX' }] : []),
])

const domainStatus = computed(() => savedRuntimeSettings.value?.customDomainStatus ?? null)
const domainStatusClass = computed(() => {
	if (domainStatus.value?.status === 'connected') return 'text-emerald-600 dark:text-emerald-300'
	if (domainStatus.value?.status === 'pending') return 'text-amber-600 dark:text-amber-300'
	return 'text-gray-500 dark:text-gray-400'
})
const provisionStatusClass = computed(() => {
	if (provisionResult.value?.status === 'connected') return 'text-emerald-600 dark:text-emerald-300'
	if (provisionResult.value?.status === 'pending') return 'text-amber-600 dark:text-amber-300'
	return 'text-red-600 dark:text-red-300'
})

function getReadableTextColor(hexColor: string) {
	const hex = /^#[0-9a-f]{6}$/i.test(hexColor) ? hexColor.slice(1) : 'e2e8f0'
	const red = Number.parseInt(hex.slice(0, 2), 16)
	const green = Number.parseInt(hex.slice(2, 4), 16)
	const blue = Number.parseInt(hex.slice(4, 6), 16)
	const luminance = (0.2126 * red + 0.7152 * green + 0.0722 * blue) / 255
	return luminance > 0.58 ? '#0f172a' : '#f8fafc'
}

function resetMessages() {
	errorMessage.value = ''
	successMessage.value = ''
}

function openMediaPicker(target: MediaTarget) {
	mediaTarget.value = target
	activeTab.value = 'media'
}

function applySettings(settings: SiteBrandingSettings) {
	savedSettings.value = settings
	form.clubName = settings.clubName
	form.homeLogoEnabled = settings.homeLogoEnabled
	form.homeLogoMediaKey = settings.homeLogoMediaKey
	form.buttonBackgroundColor = settings.buttonBackgroundColor || defaultButtonBackgroundColor
	form.appBackgroundColor = settings.appBackgroundColor || defaultAppBackgroundColor
	form.appSurfaceColor = settings.appSurfaceColor || defaultAppSurfaceColor
	form.appTextColor = settings.appTextColor || defaultAppTextColor
	form.appAccentColor = settings.appAccentColor || defaultAppAccentColor
}

function applyAuthSettings(settings: AuthLoginSettings) {
	savedAuthSettings.value = settings
	form.passwordEnabled = settings.passwordEnabled
	form.telegramCodeEnabled = settings.telegramCodeEnabled
	form.maxCodeEnabled = settings.maxCodeEnabled
	form.defaultMethod = settings.defaultMethod
	form.botAuthEnabled = settings.botAuthEnabled
}

function applyTelegramBotAuthSettings(settings: AdminTelegramBotAuthSettingsPayload) {
	savedTelegramBotAuthSettings.value = settings
	form.botHandle = settings.botHandle
	form.noAccessText = settings.noAccessText
	form.codeMessageText = settings.codeMessageText
	form.subscriptionButtonLabel = settings.subscriptionButtonLabel
	form.subscriptionButtonUrl = settings.subscriptionButtonUrl
	form.openAppButtonLabel = settings.openAppButtonLabel
	form.ownerHandle = settings.ownerHandle
}

function applyTestAccessSettings(settings: AdminTestAccessSettingsPayload) {
	savedTestAccessSettings.value = settings
	form.testAccessEnabled = settings.enabled
	form.testAccessDays = settings.days
}

function applyGuestContentAccessSettings(settings: GuestContentAccessSettings) {
	savedGuestContentAccessSettings.value = settings
	form.guestContentAccessLevel = settings.level
}

function applyRuntimeSettings(settings: AdminRuntimeSettings) {
	savedRuntimeSettings.value = settings
	form.customDomain = settings.customDomain ?? ''
	form.telegramBotToken = ''
	form.maxBotToken = ''
	form.maxApiUrl = settings.maxApiUrl
	clearTelegramToken.value = false
	clearMaxToken.value = false
	provisionResult.value = null
}

function cloneHomeExperience(settings: HomeExperienceSettings): HomeExperienceSettings {
	return JSON.parse(JSON.stringify(settings)) as HomeExperienceSettings
}

function applyHomeExperience(settings: HomeExperienceSettings) {
	savedHomeExperience.value = cloneHomeExperience(settings)
	form.homeExperience = cloneHomeExperience(settings)
	selectedMainBannerImage.value = null
}

function cloneAppNavigation(settings: AppNavigationSettings): AppNavigationSettings {
	return JSON.parse(JSON.stringify(settings)) as AppNavigationSettings
}

function applyAppNavigation(settings: AppNavigationSettings) {
	savedAppNavigation.value = cloneAppNavigation(settings)
	form.appNavigation = cloneAppNavigation(settings)
}

async function loadSettings() {
	const res = await api.get<SiteBrandingSettings>('/api/admin/branding')
	if (res.success) {
		applySettings(res.data)
	} else {
		errorMessage.value = res.error.message
	}

	const authRes = await api.get<AuthLoginSettings>('/api/admin/auth-login-settings')
	if (authRes.success) {
		applyAuthSettings(authRes.data)
	} else {
		errorMessage.value = authRes.error.message
	}

	const botAuthRes = await api.get<AdminTelegramBotAuthSettingsPayload>(
		'/api/admin/telegram-bot-auth',
	)
	if (botAuthRes.success) {
		applyTelegramBotAuthSettings(botAuthRes.data)
	} else {
		errorMessage.value = botAuthRes.error.message
	}

	const testAccessRes = await api.get<AdminTestAccessSettingsPayload>(
		'/api/admin/test-access-settings',
	)
	if (testAccessRes.success) {
		applyTestAccessSettings(testAccessRes.data)
	} else {
		errorMessage.value = testAccessRes.error.message
	}

	const guestContentAccessRes = await api.get<GuestContentAccessSettings>(
		'/api/admin/guest-content-access-settings',
	)
	if (guestContentAccessRes.success) {
		applyGuestContentAccessSettings(guestContentAccessRes.data)
	} else {
		errorMessage.value = guestContentAccessRes.error.message
	}

	const runtimeRes = await api.get<AdminRuntimeSettings>('/api/admin/runtime-settings')
	if (runtimeRes.success) {
		applyRuntimeSettings(runtimeRes.data)
	} else {
		errorMessage.value = runtimeRes.error.message
	}

	const homeExperienceRes = await api.get<HomeExperienceSettings>('/api/admin/home-experience')
	if (homeExperienceRes.success) {
		applyHomeExperience(homeExperienceRes.data)
	} else {
		errorMessage.value = homeExperienceRes.error.message
	}

	const appNavigationRes = await api.get<AppNavigationSettings>('/api/admin/app-navigation')
	if (appNavigationRes.success) {
		applyAppNavigation(appNavigationRes.data)
	} else {
		errorMessage.value = appNavigationRes.error.message
	}
}

async function loadMaterialTypeOptions() {
	const res = await api.get<MaterialTypeOption[]>('/api/admin/material-types')
	if (res.success) {
		materialTypeOptions.value = res.data
	}
}

async function loadImages() {
	mediaLoading.value = true
	const query = new URLSearchParams({
		limit: '24',
		type: getExpectedMediaType(),
		sortBy: 'updatedAt',
		sortDir: 'desc',
	})
	if (search.value.trim()) query.set('search', search.value.trim())

	const res = await api.get<CursorPaginatedResponse<AdminMediaLibraryItem>>(
		`/api/admin/media-library?${query.toString()}`,
	)
	if (res.success) {
		images.value = res.data.items
	} else {
		errorMessage.value = res.error.message
	}
	mediaLoading.value = false
}

async function initializePage() {
	loading.value = true
	resetMessages()
	await Promise.all([loadSettings(), loadMaterialTypeOptions()])
	loading.value = false
}

function selectLogo(item: AdminMediaLibraryItem) {
	resetMessages()
	form.homeLogoMediaKey = item.key
	form.homeLogoEnabled = true
}

function selectMediaItem(item: AdminMediaLibraryItem) {
	resetMessages()
	const expectedType = getExpectedMediaType()
	if (item.type !== expectedType) {
		errorMessage.value = expectedType === 'video' ? 'Выберите видео' : 'Выберите изображение'
		return
	}
	if (mediaTarget.value.type === 'logo') {
		selectLogo(item)
		return
	}
	if (mediaTarget.value.type === 'mainBanner') {
		form.homeExperience.mainBanner.mediaKey = item.key
		selectedMainBannerImage.value = item
		return
	}
	if (mediaTarget.value.type === 'banner') {
		const banner = form.homeExperience.banners[mediaTarget.value.index]
		if (banner) banner.mediaKey = item.key
		return
	}
	if (mediaTarget.value.type === 'story') {
		const story = form.homeExperience.stories[mediaTarget.value.index]
		if (story) story.mediaKey = item.key
		return
	}
	if (mediaTarget.value.type === 'section') {
		const section = form.homeExperience.sections[mediaTarget.value.index]
		if (section) section.mediaKey = item.key
		return
	}
	if (mediaTarget.value.type === 'centerButton') {
		form.appNavigation.menu.centerButton.imageKey = item.key
		return
	}
	const block =
		form.homeExperience.customPages[mediaTarget.value.pageIndex]?.blocks[
			mediaTarget.value.blockIndex
		]
	if (block) block.mediaKey = item.key
}

function clearLogo() {
	resetMessages()
	form.homeLogoMediaKey = null
}

async function uploadLogoFile(file: File | null | undefined) {
	if (!file || logoUploading.value) return
	resetMessages()
	if (!file.type.startsWith('image/')) {
		errorMessage.value = 'Выберите изображение'
		return
	}

	logoUploading.value = true
	logoUploadProgress.value = 0
	const result = await mediaUpload.uploadFile(file, {
		bucket: 'media',
		onProgress: (progress) => {
			logoUploadProgress.value = progress.percent
		},
	})
	if (result.success) {
		const item: AdminMediaLibraryItem = {
			key: result.data.path,
			name: file.name,
			title: file.name,
			url: result.data.url,
			type: result.data.mediaType,
			size: result.data.size,
			lastModified: new Date(),
			note: null,
			folderId: null,
		}
		images.value = [item, ...images.value.filter((image) => image.key !== item.key)]
		selectLogo(item)
		successMessage.value = 'Логотип загружен'
	} else {
		errorMessage.value = result.error.message
	}
	logoUploading.value = false
	logoUploadProgress.value = null
	if (logoUploadInput.value) logoUploadInput.value.value = ''
}

function openLogoUploadDialog() {
	logoUploadInput.value?.click()
}

function handleLogoUploadChange(event: Event) {
	const target = event.target as HTMLInputElement | null
	void uploadLogoFile(target?.files?.[0] ?? null)
}

function getImageTitle(mediaKey: string | null) {
	if (!mediaKey) return 'Не выбрано'
	const item = images.value.find((image) => image.key === mediaKey)
	return item?.title || item?.name || mediaKey
}

function getCurrentPageBlock() {
	if (mediaTarget.value.type !== 'pageBlock') return null
	return (
		form.homeExperience.customPages[mediaTarget.value.pageIndex]?.blocks[
			mediaTarget.value.blockIndex
		] ?? null
	)
}

function getExpectedMediaType() {
	if (mediaTarget.value.type === 'centerButton') return 'image'
	const block = getCurrentPageBlock()
	return block?.kind === 'video' ? 'video' : 'image'
}

const mediaTargetLabel = computed(() => {
	if (mediaTarget.value.type === 'logo') return 'логотип'
	if (mediaTarget.value.type === 'mainBanner') return 'главный баннер'
	if (mediaTarget.value.type === 'banner') return `плашка ${mediaTarget.value.index + 1}`
	if (mediaTarget.value.type === 'story') return `сторис ${mediaTarget.value.index + 1}`
	if (mediaTarget.value.type === 'section') return `раздел ${mediaTarget.value.index + 1}`
	if (mediaTarget.value.type === 'centerButton') return 'центральная кнопка меню'
	return `блок ${mediaTarget.value.blockIndex + 1}`
})

function createBanner(): HomeBannerItem {
	const index = form.homeExperience.banners.length + 1
	return {
		id: `banner-${Date.now()}-${index}`,
		title: 'Новая плашка',
		subtitle: '',
		backgroundColor: '#242424',
		textColor: '#ffffff',
		mediaKey: null,
		mediaUrl: null,
		actionKind: 'internal',
		internalPath: '/app',
		externalUrl: '',
		requiresAuth: false,
		storiesEnabled: false,
	}
}

function createStory(): HomeStoryItem {
	const index = form.homeExperience.stories.length + 1
	return {
		id: `story-${Date.now()}-${index}`,
		title: 'Новый сторис',
		text: '',
		layout: 'text',
		backgroundColor: '#141414',
		textColor: '#ffffff',
		mediaKey: null,
		mediaUrl: null,
		durationMs: 5000,
	}
}

function createSection(): HomeSectionItem {
	const index = form.homeExperience.sections.length + 1
	return {
		id: `section-${Date.now()}-${index}`,
		title: 'Новый раздел',
		subtitle: '',
		backgroundColor: '#242424',
		textColor: '#ffffff',
		mediaKey: null,
		mediaUrl: null,
		icon: 'spark',
		visualMode: 'color',
		textMode: 'visible',
		actionKind: 'internal',
		internalPath: materialPageOptions.value[0]?.value ?? '/app/content/courses',
		externalUrl: '',
		requiresAuth: true,
	}
}

function createCustomPage(): HomeCustomPage {
	const index = form.homeExperience.customPages.length + 1
	return {
		id: `custom-page-${Date.now()}-${index}`,
		slug: `page-${index}`,
		title: 'Новая страница',
		backgroundColor: '#141414',
		textColor: '#ffffff',
		blocks: [createCustomPageBlock('heading')],
	}
}

function createCustomPageBlock(kind: HomeCustomPageBlock['kind'] = 'text'): HomeCustomPageBlock {
	const index = Date.now()
	return {
		id: `block-${index}`,
		kind,
		title: kind === 'heading' ? 'Заголовок' : '',
		text: kind === 'text' ? 'Текст блока' : '',
		mediaKey: null,
		mediaUrl: null,
		buttonLabel: kind === 'button' ? 'Открыть' : '',
		buttonUrl: '',
		backgroundColor: '#242424',
		textColor: '#ffffff',
		borderRadius: 24,
		size: 'md',
	}
}

function addBanner() {
	resetMessages()
	form.homeExperience.banners.push(createBanner())
}

function removeBanner(index: number) {
	resetMessages()
	if (form.homeExperience.banners.length <= 1) return
	form.homeExperience.banners.splice(index, 1)
	mediaTarget.value = { type: 'logo' }
}

function addStory() {
	resetMessages()
	form.homeExperience.stories.push(createStory())
}

function addSection() {
	resetMessages()
	form.homeExperience.sections.push(createSection())
}

function removeSection(index: number) {
	resetMessages()
	if (form.homeExperience.sections.length <= 1) return
	form.homeExperience.sections.splice(index, 1)
	mediaTarget.value = { type: 'logo' }
}

function addCustomPage() {
	resetMessages()
	form.homeExperience.customPages.push(createCustomPage())
}

function removeCustomPage(index: number) {
	resetMessages()
	form.homeExperience.customPages.splice(index, 1)
	mediaTarget.value = { type: 'logo' }
}

function addPageBlock(pageIndex: number, kind: HomeCustomPageBlock['kind']) {
	resetMessages()
	form.homeExperience.customPages[pageIndex]?.blocks.push(createCustomPageBlock(kind))
}

function removePageBlock(pageIndex: number, blockIndex: number) {
	resetMessages()
	const blocks = form.homeExperience.customPages[pageIndex]?.blocks
	if (!blocks) return
	blocks.splice(blockIndex, 1)
	mediaTarget.value = { type: 'logo' }
}

function removeStory(index: number) {
	resetMessages()
	if (form.homeExperience.stories.length <= 1) return
	form.homeExperience.stories.splice(index, 1)
	mediaTarget.value = { type: 'logo' }
}

function addMenuItem() {
	resetMessages()
	form.appNavigation.menu.items.push({
		id: `menu-${Date.now()}`,
		label: 'Новая вкладка',
		icon: 'spark',
		path: '/app',
		requiresAuth: false,
		requiresAccess: false,
	})
}

function removeMenuItem(index: number) {
	resetMessages()
	if (form.appNavigation.menu.items.length <= 1) return
	form.appNavigation.menu.items.splice(index, 1)
}

function moveMenuItem(index: number, direction: -1 | 1) {
	resetMessages()
	const items = form.appNavigation.menu.items
	const target = index + direction
	if (target < 0 || target >= items.length) return
	const [item] = items.splice(index, 1)
	items.splice(target, 0, item)
}

function toggleHeaderBlock(block: AppNavigationSettings['header']['order'][number]) {
	resetMessages()
	const order = form.appNavigation.header.order
	const position = order.indexOf(block)
	if (position >= 0) {
		order.splice(position, 1)
	} else {
		order.push(block)
	}
}

function moveHeaderBlock(index: number, direction: -1 | 1) {
	resetMessages()
	const order = form.appNavigation.header.order
	const target = index + direction
	if (target < 0 || target >= order.length) return
	const [block] = order.splice(index, 1)
	order.splice(target, 0, block)
}

function clearCenterButtonImage() {
	resetMessages()
	form.appNavigation.menu.centerButton.imageKey = null
}

function clearMainBannerImage() {
	resetMessages()
	form.homeExperience.mainBanner.mediaKey = null
	selectedMainBannerImage.value = null
}

function clearBannerImage(index: number) {
	resetMessages()
	const banner = form.homeExperience.banners[index]
	if (banner) banner.mediaKey = null
}

function clearStoryImage(index: number) {
	resetMessages()
	const story = form.homeExperience.stories[index]
	if (story) story.mediaKey = null
}

function clearSectionImage(index: number) {
	resetMessages()
	const section = form.homeExperience.sections[index]
	if (section) section.mediaKey = null
}

function clearPageBlockImage(pageIndex: number, blockIndex: number) {
	resetMessages()
	const block = form.homeExperience.customPages[pageIndex]?.blocks[blockIndex]
	if (block) block.mediaKey = null
}

async function saveSettings() {
	if (saving.value) return
	resetMessages()
	saving.value = true

	if (enabledLoginMethods.value.length === 0) {
		errorMessage.value = 'Оставьте хотя бы один способ входа'
		saving.value = false
		return
	}
	if (!enabledLoginMethods.value.some((method) => method.value === form.defaultMethod)) {
		form.defaultMethod = enabledLoginMethods.value[0]?.value as AuthLoginSettings['defaultMethod']
	}

	const runtimePayload: {
		customDomain: string | null
		telegramBotToken?: string | null
		maxBotToken?: string | null
		maxApiUrl: string
	} = {
		customDomain: form.customDomain.trim() || null,
		maxApiUrl: form.maxApiUrl.trim(),
	}
	if (clearTelegramToken.value) {
		runtimePayload.telegramBotToken = null
	} else if (form.telegramBotToken.trim()) {
		runtimePayload.telegramBotToken = form.telegramBotToken.trim()
	}
	if (clearMaxToken.value) {
		runtimePayload.maxBotToken = null
	} else if (form.maxBotToken.trim()) {
		runtimePayload.maxBotToken = form.maxBotToken.trim()
	}
	const homeExperiencePayload = {
		...form.homeExperience,
		mainBanner: {
			mediaKey: form.homeExperience.mainBanner.mediaKey,
			alt: form.homeExperience.mainBanner.alt,
		},
		stories: form.homeExperience.stories.map((story) => ({
			...story,
			mediaUrl: null,
			overlays: story.overlays.map((overlay) => ({ ...overlay, mediaUrl: null })),
		})),
		highlights: form.homeExperience.highlights.map((highlight) => ({
			...highlight,
			stories: highlight.stories.map((story) => ({
				...story,
				mediaUrl: null,
				overlays: story.overlays.map((overlay) => ({ ...overlay, mediaUrl: null })),
			})),
		})),
	}

	const [
		brandingRes,
		authRes,
		botAuthRes,
		testAccessRes,
		guestContentAccessRes,
		runtimeRes,
		homeExperienceRes,
		appNavigationRes,
	] = await Promise.all([
		api.put<SiteBrandingSettings>('/api/admin/branding', {
			clubName: form.clubName.trim(),
			homeLogoEnabled: form.homeLogoEnabled,
			homeLogoMediaKey: form.homeLogoMediaKey,
			buttonBackgroundColor: form.buttonBackgroundColor,
			appBackgroundColor: form.appBackgroundColor,
			appSurfaceColor: form.appSurfaceColor,
			appTextColor: form.appTextColor,
			appAccentColor: form.appAccentColor,
		}),
		api.put<AuthLoginSettings>('/api/admin/auth-login-settings', {
			passwordEnabled: form.passwordEnabled,
			telegramCodeEnabled: form.telegramCodeEnabled,
			maxCodeEnabled: form.maxCodeEnabled,
			defaultMethod: form.defaultMethod,
			botAuthEnabled: form.botAuthEnabled,
		}),
		api.put<AdminTelegramBotAuthSettingsPayload>('/api/admin/telegram-bot-auth', {
			botHandle: form.botHandle,
			noAccessText: form.noAccessText,
			codeMessageText: form.codeMessageText,
			subscriptionButtonLabel: form.subscriptionButtonLabel,
			subscriptionButtonUrl: form.subscriptionButtonUrl,
			openAppButtonLabel: form.openAppButtonLabel,
			ownerHandle: form.ownerHandle,
		}),
		api.put<AdminTestAccessSettingsPayload>('/api/admin/test-access-settings', {
			enabled: form.testAccessEnabled,
			days: form.testAccessDays,
		}),
		api.put<GuestContentAccessSettings>('/api/admin/guest-content-access-settings', {
			level: form.guestContentAccessLevel,
		}),
		api.put<AdminRuntimeSettings>('/api/admin/runtime-settings', runtimePayload),
		api.put<HomeExperienceSettings>('/api/admin/home-experience', homeExperiencePayload),
		api.put<AppNavigationSettings>('/api/admin/app-navigation', form.appNavigation),
	])

	if (
		brandingRes.success &&
		authRes.success &&
		botAuthRes.success &&
		testAccessRes.success &&
		guestContentAccessRes.success &&
		runtimeRes.success &&
		homeExperienceRes.success &&
		appNavigationRes.success
	) {
		applySettings(brandingRes.data)
		applyAuthSettings(authRes.data)
		applyTelegramBotAuthSettings(botAuthRes.data)
		applyTestAccessSettings(testAccessRes.data)
		applyGuestContentAccessSettings(guestContentAccessRes.data)
		applyRuntimeSettings(runtimeRes.data)
		applyHomeExperience(homeExperienceRes.data)
		applyAppNavigation(appNavigationRes.data)
		successMessage.value = 'Настройки сохранены'
		previewVersion.value += 1
	} else {
		errorMessage.value =
			(brandingRes.success ? null : brandingRes.error.message) ||
			(authRes.success ? null : authRes.error.message) ||
			(botAuthRes.success ? null : botAuthRes.error.message) ||
			(testAccessRes.success ? null : testAccessRes.error.message) ||
			(guestContentAccessRes.success ? null : guestContentAccessRes.error.message) ||
			(runtimeRes.success ? null : runtimeRes.error.message) ||
			(homeExperienceRes.success ? null : homeExperienceRes.error.message) ||
			(appNavigationRes.success ? null : appNavigationRes.error.message) ||
			'Не удалось сохранить настройки'
	}

	saving.value = false
}

async function checkDomain() {
	if (checkingDomain.value) return
	resetMessages()
	checkingDomain.value = true
	const res = await api.post<CustomDomainStatus>('/api/admin/runtime-settings/check-domain', {
		customDomain: form.customDomain.trim() || null,
	})
	if (res.success) {
		savedRuntimeSettings.value = {
			...(savedRuntimeSettings.value ?? {
				customDomain: form.customDomain.trim() || null,
				telegramBotTokenSet: false,
				maxBotTokenSet: false,
				maxApiUrl: form.maxApiUrl,
			}),
			customDomainStatus: res.data,
		}
	} else {
		errorMessage.value = res.error.message
	}
	checkingDomain.value = false
}

async function provisionDomain() {
	if (provisioningDomain.value) return
	resetMessages()
	provisioningDomain.value = true
	const domain = form.customDomain.trim() || null
	const res = await api.post<DomainProvisionResult>(
		'/api/admin/runtime-settings/provision-domain',
		{
			customDomain: domain,
		},
	)
	if (res.success) {
		provisionResult.value = res.data
		savedRuntimeSettings.value = {
			...(savedRuntimeSettings.value ?? {
				customDomain: domain,
				telegramBotTokenSet: false,
				maxBotTokenSet: false,
				maxApiUrl: form.maxApiUrl,
			}),
			customDomain: res.data.domain,
			customDomainStatus: res.data.dns,
		}
		successMessage.value = res.data.status === 'connected' ? 'Домен подключён' : res.data.message
	} else {
		errorMessage.value = res.error.message
	}
	provisioningDomain.value = false
}

watch(enabledLoginMethods, (methods) => {
	if (methods.length === 0) return
	if (!methods.some((method) => method.value === form.defaultMethod)) {
		form.defaultMethod = methods[0].value as AuthLoginSettings['defaultMethod']
	}
})

onMounted(() => {
	void initializePage()
})

watch(mediaTarget, () => {
	if (!loading.value && activeTab.value === 'media') void loadImages()
})

watch(activeTab, (tab) => {
	if (!loading.value && tab === 'media') void loadImages()
})

watch(
	() => props.mode,
	() => {
		if (!settingsTabs.value.some((tab) => tab.key === activeTab.value)) {
			activeTab.value = settingsTabs.value[0]?.key ?? 'access'
		}
	},
)
</script>

<template>
	<div class="space-y-6 p-6">
		<div class="flex flex-wrap items-end justify-between gap-4">
			<div>
				<h1 class="text-2xl font-bold text-gray-900 dark:text-white">{{ pageTitle }}</h1>
			</div>
			<button
				type="button"
				class="btn-primary"
				:disabled="saving || !hasChanges"
				@click="saveSettings"
			>
				{{ saving ? 'Сохраняю...' : 'Сохранить' }}
			</button>
		</div>

		<div
			v-if="errorMessage"
			class="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-300"
		>
			{{ errorMessage }}
		</div>
		<div
			v-if="successMessage"
			class="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300"
		>
			{{ successMessage }}
		</div>

		<div v-if="loading" class="rounded-[30px] border border-white/10 bg-white/60 p-6 text-sm text-gray-500 dark:bg-white/[0.04] dark:text-gray-400">
			Загружаю настройки...
		</div>

		<div v-else :class="props.mode === 'design' ? 'design-workspace' : 'space-y-5'">
			<div :class="props.mode === 'design' ? 'design-editor-panel space-y-5' : 'space-y-5'">
			<div class="sticky top-0 z-20 -mx-1 overflow-x-auto border-b border-white/10 bg-slate-950/95 px-1 pb-3 pt-1 backdrop-blur">
				<div class="flex min-w-max gap-2">
					<button
						v-for="tab in settingsTabs"
						:key="tab.key"
						type="button"
						class="rounded-2xl border px-4 py-2 text-sm font-semibold transition"
						:class="
							activeTab === tab.key
								? 'settings-tab-active'
								: 'border-white/10 bg-white/[0.04] text-gray-300 hover:bg-white/[0.07] hover:text-white'
						"
						:aria-selected="activeTab === tab.key"
						@click="activeTab = tab.key"
					>
						{{ tab.label }}
					</button>
				</div>
			</div>

			<section
				v-if="activeTab === 'brand' || activeTab === 'access' || activeTab === 'domain'"
				class="rounded-[30px] border border-gray-200/70 bg-white/75 p-5 shadow-[0_18px_50px_rgba(15,23,42,0.08)] dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
			>
				<template v-if="activeTab === 'brand'">
				<div class="flex items-start justify-between gap-4">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Главная</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Логотип</h2>
					</div>
					<button
						type="button"
						class="relative inline-flex h-11 w-36 items-center justify-between rounded-full border px-1 transition"
						:class="form.homeLogoEnabled ? 'border-emerald-400/30 bg-emerald-400/15' : 'border-white/10 bg-white/[0.04]'"
						:aria-pressed="form.homeLogoEnabled"
						@click="form.homeLogoEnabled = !form.homeLogoEnabled"
					>
						<span
							class="h-8 w-8 rounded-full bg-white transition"
							:class="form.homeLogoEnabled ? 'translate-x-24 bg-emerald-300' : 'translate-x-0 bg-white/30'"
						/>
						<span
							class="pointer-events-none absolute left-0 right-0 text-center text-sm font-medium"
							:class="form.homeLogoEnabled ? 'pr-8 text-emerald-100' : 'pl-8 text-gray-200'"
						>
							{{ form.homeLogoEnabled ? 'Включён' : 'Выключен' }}
						</span>
					</button>
				</div>

				<label class="mt-5 block">
					<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Название клуба</span>
					<input
						v-model="form.clubName"
						type="text"
						maxlength="80"
						class="mt-2 w-full rounded-2xl border border-gray-200/70 bg-white/70 px-4 py-3 text-sm font-medium text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-slate-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-white"
						placeholder="Community Club"
					/>
				</label>

				<div class="mt-5 rounded-[26px] border border-slate-900/10 bg-[#141414] p-5 dark:border-white/10">
					<div class="flex min-h-[156px] items-center justify-center">
						<img
							v-if="form.homeLogoEnabled && previewLogoUrl"
							:src="previewLogoUrl"
							:alt="selectedTitle || 'Логотип клуба'"
							width="512"
							height="512"
							loading="lazy"
							decoding="async"
							class="max-h-28 max-w-[260px] object-contain"
						/>
						<div
							v-else-if="form.homeLogoEnabled"
							class="flex w-full max-w-[260px] items-center justify-center gap-3 rounded-[24px] border border-white/[0.14] bg-white/[0.06] px-5 py-6 text-slate-100"
						>
							<span class="grid h-10 w-10 rotate-45 grid-cols-2 gap-1.5" aria-hidden="true">
								<span class="rounded-lg border border-white/20 bg-white/[0.12]" />
								<span class="rounded-lg border border-white/20 bg-slate-300/20" />
								<span class="rounded-lg border border-white/20 bg-slate-300/20" />
								<span class="rounded-lg border border-white/20 bg-white/[0.12]" />
							</span>
							<span class="text-[11px] font-bold uppercase tracking-[0.16em]">Логотип клуба</span>
						</div>
						<div v-else class="rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4 text-sm text-white/60">
							Логотип скрыт
						</div>
					</div>
				</div>

				<div class="mt-5 space-y-3">
					<div class="rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]">
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Выбрано</p>
						<p class="mt-1 truncate text-sm font-medium text-gray-900 dark:text-white">
							{{ selectedTitle || (form.homeLogoMediaKey ? form.homeLogoMediaKey : 'Заглушка') }}
						</p>
					</div>
					<div class="flex flex-wrap gap-2">
						<input
							ref="logoUploadInput"
							type="file"
							accept="image/*"
							class="hidden"
							@change="handleLogoUploadChange"
						/>
						<button type="button" class="btn-primary" :disabled="logoUploading" @click="openLogoUploadDialog">
							{{ logoUploading ? `Загрузка ${logoUploadProgress ?? 0}%` : 'Загрузить' }}
						</button>
						<button type="button" class="btn-secondary" @click="openMediaPicker({ type: 'logo' })">
							Выбрать
						</button>
						<button type="button" class="btn-secondary" :disabled="!form.homeLogoMediaKey" @click="clearLogo">
							Убрать
						</button>
						<NuxtLink to="/media" class="btn-secondary">Медиатека</NuxtLink>
					</div>
				</div>

				<div class="mt-6 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<div class="flex flex-wrap items-center justify-between gap-4">
						<div>
							<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Цвета</p>
							<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Оформление приложения</h3>
						</div>
					</div>
					<div class="mt-4 grid gap-3 sm:grid-cols-2">
						<label
							v-for="field in colorFields"
							:key="field.key"
							class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]"
						>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">{{ field.label }}</span>
							<span class="flex items-center gap-3">
								<input
									v-model="form[field.key]"
									type="color"
									class="h-9 w-12 cursor-pointer rounded-xl border-0 bg-transparent p-0"
									:aria-label="field.label"
								/>
								<span class="w-20 font-mono text-sm text-gray-600 dark:text-gray-300">{{ form[field.key] }}</span>
							</span>
						</label>
					</div>
					<div class="mt-4 rounded-2xl p-4" :style="{ backgroundColor: form.appBackgroundColor, color: form.appTextColor }">
						<div class="rounded-2xl p-4" :style="{ backgroundColor: form.appSurfaceColor }">
							<p class="text-sm font-semibold" :style="{ color: form.appAccentColor }">Превью</p>
							<p class="mt-1 text-sm">Карточка приложения</p>
						</div>
						<button
							type="button"
							class="mt-3 rounded-2xl px-5 py-3 text-sm font-semibold shadow-[0_14px_32px_rgba(15,23,42,0.18)] transition active:scale-[0.98]"
							:style="buttonPreviewStyle"
						>
							Открыть
						</button>
					</div>
				</div>

				</template>

				<div
					v-if="activeTab === 'access'"
					class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
				>
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Вход</p>
						<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Способы входа</h3>
					</div>
					<div class="mt-4 grid gap-3">
						<label class="flex cursor-pointer items-center justify-between gap-4 rounded-2xl border border-gray-200/70 bg-white/70 px-4 py-3 text-sm font-medium text-gray-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-gray-200">
							<span>Email и пароль</span>
							<input v-model="form.passwordEnabled" type="checkbox" class="glass-check" />
						</label>
						<label class="flex cursor-pointer items-center justify-between gap-4 rounded-2xl border border-gray-200/70 bg-white/70 px-4 py-3 text-sm font-medium text-gray-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-gray-200">
							<span>Код в Telegram</span>
							<input v-model="form.telegramCodeEnabled" type="checkbox" class="glass-check" />
						</label>
						<label class="flex cursor-pointer items-center justify-between gap-4 rounded-2xl border border-gray-200/70 bg-white/70 px-4 py-3 text-sm font-medium text-gray-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-gray-200">
							<span>Код в MAX</span>
							<input v-model="form.maxCodeEnabled" type="checkbox" class="glass-check" />
						</label>
						<label class="flex cursor-pointer items-center justify-between gap-4 rounded-2xl border border-gray-200/70 bg-white/70 px-4 py-3 text-sm font-medium text-gray-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-gray-200">
							<span>Вход через бота (Telegram)</span>
							<input v-model="form.botAuthEnabled" type="checkbox" class="glass-check" />
						</label>
					</div>

					<div
						v-if="form.botAuthEnabled"
						class="mt-4 rounded-2xl border border-gray-200/70 bg-white/70 p-4 dark:border-white/10 dark:bg-white/[0.04]"
					>
						<p class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">
							Telegram-бот для входа
						</p>
						<div class="mt-3 grid gap-3">
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Имя бота (handle, без @)</span>
								<input v-model="form.botHandle" type="text" class="glass-input mt-2" placeholder="my_club_bot" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Сообщение «нет доступа»</span>
								<textarea v-model="form.noAccessText" class="glass-input mt-2 min-h-16 resize-y" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Шаблон кода входа (используйте {code})</span>
								<textarea v-model="form.codeMessageText" class="glass-input mt-2 min-h-16 resize-y" />
							</label>
							<div class="grid gap-3 md:grid-cols-2">
								<label>
									<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Кнопка «Оплатить подписку»</span>
									<input v-model="form.subscriptionButtonLabel" type="text" class="glass-input mt-2" />
								</label>
								<label>
									<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Ссылка кнопки</span>
									<input v-model="form.subscriptionButtonUrl" type="text" class="glass-input mt-2" placeholder="https://…" />
								</label>
							</div>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Кнопка «Открыть приложение»</span>
								<input v-model="form.openAppButtonLabel" type="text" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Аккаунт владельца для связи (handle, без @)</span>
								<input v-model="form.ownerHandle" type="text" class="glass-input mt-2" placeholder="my_account" />
								<span class="mt-1 block text-xs text-gray-400 dark:text-gray-500">Ссылка «Написать …» внизу страницы входа.</span>
							</label>
							<p class="text-xs text-gray-400 dark:text-gray-500">
								Токен бота задаётся в разделе «Runtime» (поле «Telegram bot token»). Уведомления в Telegram включаются в профиле пользователя.
							</p>
						</div>
					</div>
					<div class="mt-4">
						<label class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">По умолчанию</label>
						<select v-model="form.defaultMethod" class="glass-input mt-2">
							<option
								v-for="method in enabledLoginMethods"
								:key="method.value"
								:value="method.value"
							>
								{{ method.label }}
							</option>
						</select>
					</div>
				</div>

				<div
					v-if="activeTab === 'access'"
					class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
				>
					<div class="flex flex-wrap items-start justify-between gap-3">
						<div>
							<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Тестовый вход</p>
							<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Пробный доступ</h3>
						</div>
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.testAccessEnabled" type="checkbox" class="glass-check" />
							<span>{{ form.testAccessEnabled ? 'Включён' : 'Выключен' }}</span>
						</label>
					</div>
					<label class="mt-4 block">
						<span class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">Срок доступа, дней</span>
						<input
							v-model.number="form.testAccessDays"
							type="number"
							min="1"
							max="365"
							class="glass-input mt-2"
						/>
					</label>
				</div>

				<div
					v-if="activeTab === 'access'"
					class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
				>
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Материалы</p>
						<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Уровень закрытости для неучастников</h3>
						<p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Участники клуба всегда видят весь контент.</p>
					</div>
					<div class="mt-4 grid gap-2">
						<label class="flex cursor-pointer items-start gap-3 rounded-2xl border border-gray-200/70 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.04]">
							<input v-model="form.guestContentAccessLevel" value="sections" type="radio" class="mt-1" />
							<span><span class="block text-sm font-semibold text-gray-800 dark:text-white">Закрыть разделы целиком</span><span class="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">Гость увидит предложение вступить в клуб до списка материалов.</span></span>
						</label>
						<label class="flex cursor-pointer items-start gap-3 rounded-2xl border border-gray-200/70 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.04]">
							<input v-model="form.guestContentAccessLevel" value="cards" type="radio" class="mt-1" />
							<span><span class="block text-sm font-semibold text-gray-800 dark:text-white">Закрыть карточки</span><span class="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">Список виден, а открытие карточки приводит к форме доступа.</span></span>
						</label>
						<label class="flex cursor-pointer items-start gap-3 rounded-2xl border border-gray-200/70 bg-white/70 p-3 dark:border-white/10 dark:bg-white/[0.04]">
							<input v-model="form.guestContentAccessLevel" value="preview" type="radio" class="mt-1" />
							<span><span class="block text-sm font-semibold text-gray-800 dark:text-white">Открывать карточки с ограничениями</span><span class="mt-0.5 block text-xs text-gray-500 dark:text-gray-400">Настройте показ, размытие или замок для каждого блока в редакторе материала.</span></span>
						</label>
					</div>
				</div>

				<div
					v-if="activeTab === 'domain'"
					class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
				>
					<div class="flex flex-wrap items-start justify-between gap-3">
						<div>
							<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Домен</p>
							<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Адрес клуба</h3>
						</div>
						<div v-if="domainStatus" class="text-right text-xs">
							<p class="font-semibold" :class="domainStatusClass">{{ domainStatus.message }}</p>
							<p class="mt-1 text-gray-400 dark:text-gray-500">
								{{ new Date(domainStatus.checkedAt).toLocaleString('ru-RU') }}
							</p>
						</div>
					</div>
					<div class="mt-4 flex flex-col gap-3 sm:flex-row">
						<input
							v-model="form.customDomain"
							type="text"
							class="glass-input"
							placeholder="club.example.com"
							autocomplete="off"
						/>
						<button type="button" class="btn-secondary shrink-0" :disabled="checkingDomain" @click="checkDomain">
							{{ checkingDomain ? 'Проверяю...' : 'Проверить' }}
						</button>
						<button
							type="button"
							class="btn-primary shrink-0"
							:disabled="provisioningDomain || !form.customDomain.trim()"
							@click="provisionDomain"
						>
							{{ provisioningDomain ? 'Подключаю...' : 'Подключить' }}
						</button>
					</div>
					<div v-if="domainStatus?.domain" class="mt-4 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 text-xs text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-400">
						<p>Ожидаемый хост: {{ domainStatus.dns.expectedHost || '—' }}</p>
						<p class="mt-1">Адреса домена: {{ domainStatus.dns.domainAddresses.join(', ') || '—' }}</p>
						<p class="mt-1">CNAME: {{ domainStatus.dns.cnames.join(', ') || '—' }}</p>
					</div>
					<div
						v-if="provisionResult"
						class="mt-4 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 text-xs text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-400"
					>
						<p class="font-semibold" :class="provisionStatusClass">{{ provisionResult.message }}</p>
						<p class="mt-2">
							HTTPS: {{ provisionResult.https.ok ? 'отвечает' : provisionResult.https.message }}
						</p>
						<p v-if="provisionResult.caddy?.validate" class="mt-1">
							Проверка Caddy: {{ provisionResult.caddy.validate.ok ? 'успешно' : 'ошибка' }}
						</p>
						<p v-if="provisionResult.caddy?.reload" class="mt-1">
							Перезагрузка Caddy: {{ provisionResult.caddy.reload.ok ? 'успешно' : 'ошибка' }}
						</p>
					</div>
				</div>

				<div
					v-if="activeTab === 'access'"
					class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
				>
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Мессенджеры</p>
						<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Токены ботов</h3>
					</div>
					<div class="mt-4 grid gap-4">
						<div class="space-y-2">
							<div class="flex items-center justify-between gap-3">
								<label class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">Telegram</label>
								<span class="text-xs" :class="savedRuntimeSettings?.telegramBotTokenSet ? 'text-emerald-600 dark:text-emerald-300' : 'text-gray-400'">
									{{ savedRuntimeSettings?.telegramBotTokenSet ? 'Токен сохранён' : 'Токен не задан' }}
								</span>
							</div>
							<input
								v-model="form.telegramBotToken"
								type="password"
								class="glass-input"
								placeholder="Новый токен"
								autocomplete="new-password"
								:disabled="clearTelegramToken"
							/>
							<label class="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
								<input v-model="clearTelegramToken" type="checkbox" class="glass-check" />
								<span>Убрать токен Telegram</span>
							</label>
						</div>

						<div class="space-y-2">
							<div class="flex items-center justify-between gap-3">
								<label class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">MAX</label>
								<span class="text-xs" :class="savedRuntimeSettings?.maxBotTokenSet ? 'text-emerald-600 dark:text-emerald-300' : 'text-gray-400'">
									{{ savedRuntimeSettings?.maxBotTokenSet ? 'Токен сохранён' : 'Токен не задан' }}
								</span>
							</div>
							<input
								v-model="form.maxBotToken"
								type="password"
								class="glass-input"
								placeholder="Новый токен"
								autocomplete="new-password"
								:disabled="clearMaxToken"
							/>
							<label class="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
								<input v-model="clearMaxToken" type="checkbox" class="glass-check" />
								<span>Убрать токен MAX</span>
							</label>
							<input
								v-model="form.maxApiUrl"
								type="url"
								class="glass-input"
								placeholder="https://platform-api.max.ru"
								autocomplete="off"
							/>
						</div>
					</div>
				</div>
			</section>

			<section
				v-else
				class="rounded-[30px] border border-gray-200/70 bg-white/75 p-5 shadow-[0_18px_50px_rgba(15,23,42,0.08)] dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
			>
				<template v-if="activeTab === 'home'">
				<div>
					<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Главная</p>
					<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Главный баннер</h2>
				</div>

				<div class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<div class="aspect-[1697/927] overflow-hidden rounded-2xl bg-gray-100 dark:bg-white/[0.04]">
						<img
							v-if="mainBannerPreviewUrl"
							:src="mainBannerPreviewUrl"
							:alt="form.homeExperience.mainBanner.alt"
							class="h-full w-full object-cover"
						/>
						<div
							v-else
							class="flex h-full items-center justify-center px-4 text-center text-sm text-gray-500 dark:text-gray-400"
						>
							Изображение не выбрано
						</div>
					</div>
					<div class="mt-4 flex flex-wrap items-center justify-between gap-3">
						<div class="min-w-0">
							<p class="truncate text-sm font-medium text-gray-900 dark:text-white">
								{{ getImageTitle(form.homeExperience.mainBanner.mediaKey) }}
							</p>
							<p class="mt-1 text-xs text-gray-400 dark:text-gray-500">Изображение главного баннера</p>
						</div>
						<div class="flex flex-wrap gap-2">
							<button
								type="button"
								class="btn-secondary"
								aria-label="Выбрать изображение главного баннера"
								@click="openMediaPicker({ type: 'mainBanner' })"
							>
								{{ form.homeExperience.mainBanner.mediaKey ? 'Заменить' : 'Выбрать' }}
							</button>
							<button
								type="button"
								class="btn-secondary"
								:disabled="!form.homeExperience.mainBanner.mediaKey"
								aria-label="Убрать изображение главного баннера"
								@click="clearMainBannerImage"
							>
								Убрать
							</button>
						</div>
					</div>
				</div>

				<div class="mt-6 flex flex-wrap items-end justify-between gap-3">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Главная</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Плашки</h2>
					</div>
					<button type="button" class="btn-secondary" @click="addBanner">+ Плашка</button>
				</div>

				<div class="mt-5 grid gap-4">
					<div class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
						<label>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Форма плашек</span>
							<select v-model="form.homeExperience.bannerShape" class="glass-input mt-2">
								<option v-for="option in bannerShapeOptions" :key="option.value" :value="option.value">
									{{ option.label }}
								</option>
							</select>
						</label>
					</div>
					<div
						v-for="(banner, index) in form.homeExperience.banners"
						:key="banner.id"
						class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
					>
						<div class="flex flex-wrap items-start justify-between gap-3">
							<div class="min-w-0">
								<p class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">
									Плашка {{ index + 1 }}
								</p>
								<p class="mt-1 truncate text-sm font-semibold text-gray-900 dark:text-white">
									{{ banner.title || 'Без названия' }}
								</p>
							</div>
							<button
								type="button"
								class="btn-secondary"
								:disabled="form.homeExperience.banners.length <= 1"
								@click="removeBanner(index)"
							>
								Убрать
							</button>
						</div>

						<div class="mt-4 grid gap-3 md:grid-cols-2">
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Название</span>
								<input v-model="banner.title" type="text" maxlength="80" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Подпись</span>
								<input v-model="banner.subtitle" type="text" maxlength="120" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Действие</span>
								<select v-model="banner.actionKind" class="glass-input mt-2">
									<option v-for="option in actionOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
							</label>
							<label v-if="banner.actionKind === 'internal'">
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Страница</span>
								<select v-model="banner.internalPath" class="glass-input mt-2">
									<option v-for="option in pageOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
							</label>
							<label v-else-if="banner.actionKind === 'external'">
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Ссылка</span>
								<input v-model="banner.externalUrl" type="url" class="glass-input mt-2" placeholder="https://example.com" />
							</label>
							<label v-else class="flex items-end">
								<span class="rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 text-sm text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-400">
									Открывает сторисы
								</span>
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Фон</span>
								<input v-model="banner.backgroundColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст</span>
								<input v-model="banner.textColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
							</label>
						</div>

						<div class="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]">
							<div class="min-w-0">
								<p class="text-sm font-medium text-gray-900 dark:text-white">
									{{ getImageTitle(banner.mediaKey) }}
								</p>
								<p class="mt-1 text-xs text-gray-400 dark:text-gray-500">Картинка: 1080 x 1080</p>
							</div>
							<div class="flex flex-wrap gap-2">
								<button type="button" class="btn-secondary" @click="openMediaPicker({ type: 'banner', index })">
									Выбрать
								</button>
								<button type="button" class="btn-secondary" :disabled="!banner.mediaKey" @click="clearBannerImage(index)">
									Убрать
								</button>
							</div>
						</div>

						<label class="mt-4 flex cursor-pointer items-center justify-between gap-4 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 text-sm font-medium text-gray-700 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-200">
							<span>Закрыть до входа</span>
							<input v-model="banner.requiresAuth" type="checkbox" class="glass-check" />
						</label>
					</div>
				</div>

				</template>

				<template v-else-if="activeTab === 'sections'">
				<div class="flex flex-wrap items-end justify-between gap-3">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Разделы</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Нижняя сетка</h2>
					</div>
					<button type="button" class="btn-secondary" @click="addSection">+ Раздел</button>
				</div>

				<div class="mt-4 grid gap-3 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<label>
						<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Сетка</span>
						<select v-model="form.homeExperience.sectionLayout" class="glass-input mt-2">
							<option v-for="option in sectionLayoutOptions" :key="option.value" :value="option.value">
								{{ option.label }}
							</option>
						</select>
					</label>

					<div
						class="admin-section-preview"
						:class="`admin-section-preview-${form.homeExperience.sectionLayout}`"
					>
						<div
							v-for="(section, index) in form.homeExperience.sections"
							:key="section.id"
							class="admin-section-preview-tile"
							:class="`admin-section-preview-tile-${index}`"
							:style="{ backgroundColor: section.backgroundColor, color: section.textColor }"
						>
							<img
								v-if="section.visualMode === 'image' && section.mediaKey"
								:src="images.find((item) => item.key === section.mediaKey)?.url"
								:alt="section.title"
								class="admin-section-preview-image"
							/>
							<span v-if="section.textMode === 'visible'">{{ section.title }}</span>
						</div>
					</div>
				</div>

				<div class="mt-5 grid gap-4">
					<div
						v-for="(section, index) in form.homeExperience.sections"
						:key="section.id"
						class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
					>
						<div class="flex flex-wrap items-start justify-between gap-3">
							<div>
								<p class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">
									Раздел {{ index + 1 }}
								</p>
								<p class="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
									{{ section.title || 'Без названия' }}
								</p>
							</div>
							<button
								type="button"
								class="btn-secondary"
								:disabled="form.homeExperience.sections.length <= 1"
								@click="removeSection(index)"
							>
								Убрать
							</button>
						</div>

						<div class="mt-4 grid gap-3 md:grid-cols-2">
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Название</span>
								<input v-model="section.title" type="text" maxlength="80" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Подпись</span>
								<input v-model="section.subtitle" type="text" maxlength="120" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Вид</span>
								<select v-model="section.visualMode" class="glass-input mt-2">
									<option value="color">Цвет</option>
									<option value="icon">Цвет и иконка</option>
									<option value="image">Картинка</option>
								</select>
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст</span>
								<select v-model="section.textMode" class="glass-input mt-2">
									<option value="visible">Показывать</option>
									<option value="hidden">Скрыть</option>
								</select>
							</label>
							<label v-if="section.visualMode === 'icon'">
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Иконка</span>
								<select v-model="section.icon" class="glass-input mt-2">
									<option v-for="option in iconOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Действие</span>
								<select v-model="section.actionKind" class="glass-input mt-2">
									<option value="internal">Страница приложения</option>
									<option value="external">Внешняя ссылка</option>
								</select>
							</label>
							<label v-if="section.actionKind === 'internal'">
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Страница</span>
								<select v-model="section.internalPath" class="glass-input mt-2">
									<option v-for="option in pageOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
							</label>
							<label v-else>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Ссылка</span>
								<input v-model="section.externalUrl" type="url" class="glass-input mt-2" placeholder="https://example.com" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Фон</span>
								<input v-model="section.backgroundColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст</span>
								<input v-model="section.textColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
							</label>
						</div>

						<div class="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]">
							<div class="min-w-0">
								<p class="text-sm font-medium text-gray-900 dark:text-white">
									{{ getImageTitle(section.mediaKey) }}
								</p>
								<p class="mt-1 text-xs text-gray-400 dark:text-gray-500">Картинка: 1080 x 1080</p>
							</div>
							<div class="flex flex-wrap gap-2">
								<button type="button" class="btn-secondary" @click="openMediaPicker({ type: 'section', index })">
									Выбрать
								</button>
								<button type="button" class="btn-secondary" :disabled="!section.mediaKey" @click="clearSectionImage(index)">
									Убрать
								</button>
							</div>
						</div>
					</div>
				</div>

				</template>

<template v-else-if="activeTab === 'stories'">
					<div class="flex flex-wrap items-end justify-between gap-3">
						<div>
							<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">О клубе</p>
							<div class="mt-2 flex flex-wrap items-baseline gap-x-3 gap-y-1">
								<h2 class="text-xl font-semibold text-gray-900 dark:text-white">Хайлайты</h2>
								<p class="text-xs text-gray-400 dark:text-gray-500">Размер изображения: 1080 × 1920 px</p>
							</div>
						</div>
					</div>
					<div class="mt-5">
						<AdminHighlightsEditor v-model="form.homeExperience" />
					</div>
				</template>

				<template v-else-if="activeTab === 'pages'">
				<div class="flex flex-wrap items-end justify-between gap-3">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Страницы</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Кастомные страницы</h2>
					</div>
					<button type="button" class="btn-secondary" @click="addCustomPage">+ Страница</button>
				</div>

				<div class="mt-5 grid gap-4">
					<div
						v-for="(page, pageIndex) in form.homeExperience.customPages"
						:key="page.id"
						class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
					>
						<div class="flex flex-wrap items-start justify-between gap-3">
							<div>
								<p class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">
									/app/page/{{ page.slug || 'page' }}
								</p>
								<p class="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
									{{ page.title || 'Без названия' }}
								</p>
							</div>
							<button type="button" class="btn-secondary" @click="removeCustomPage(pageIndex)">
								Убрать
							</button>
						</div>

						<div class="mt-4 grid gap-3 md:grid-cols-2">
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Название</span>
								<input v-model="page.title" type="text" maxlength="100" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Адрес</span>
								<input v-model="page.slug" type="text" maxlength="80" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Фон страницы</span>
								<input v-model="page.backgroundColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст страницы</span>
								<input v-model="page.textColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
							</label>
						</div>

						<div class="mt-4 flex flex-wrap gap-2">
							<button type="button" class="btn-secondary" @click="addPageBlock(pageIndex, 'heading')">+ Заголовок</button>
							<button type="button" class="btn-secondary" @click="addPageBlock(pageIndex, 'text')">+ Текст</button>
							<button type="button" class="btn-secondary" @click="addPageBlock(pageIndex, 'image')">+ Картинка</button>
							<button type="button" class="btn-secondary" @click="addPageBlock(pageIndex, 'video')">+ Видео</button>
							<button type="button" class="btn-secondary" @click="addPageBlock(pageIndex, 'button')">+ Кнопка</button>
						</div>

						<div class="mt-4 grid gap-3">
							<div
								v-for="(block, blockIndex) in page.blocks"
								:key="block.id"
								class="rounded-2xl border border-gray-200/70 bg-white/60 p-3 dark:border-white/10 dark:bg-white/[0.03]"
							>
								<div class="flex flex-wrap items-center justify-between gap-3">
									<p class="text-sm font-semibold text-gray-900 dark:text-white">
										Блок {{ blockIndex + 1 }}
									</p>
									<button type="button" class="btn-secondary" @click="removePageBlock(pageIndex, blockIndex)">
										Убрать
									</button>
								</div>
								<div class="mt-3 grid gap-3 md:grid-cols-2">
									<label>
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Тип</span>
										<select v-model="block.kind" class="glass-input mt-2">
											<option value="heading">Заголовок</option>
											<option value="text">Текст</option>
											<option value="image">Картинка</option>
											<option value="video">Видео</option>
											<option value="button">Кнопка</option>
										</select>
									</label>
									<label>
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Размер</span>
										<select v-model="block.size" class="glass-input mt-2">
											<option value="sm">Малый</option>
											<option value="md">Средний</option>
											<option value="lg">Большой</option>
										</select>
									</label>
									<label>
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Заголовок</span>
										<input v-model="block.title" type="text" maxlength="120" class="glass-input mt-2" />
									</label>
									<label v-if="block.kind === 'button'">
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Ссылка кнопки</span>
										<input v-model="block.buttonUrl" type="url" class="glass-input mt-2" placeholder="https://example.com" />
									</label>
									<label v-if="block.kind === 'button'">
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст кнопки</span>
										<input v-model="block.buttonLabel" type="text" maxlength="80" class="glass-input mt-2" />
									</label>
									<label v-if="block.kind === 'text'" class="md:col-span-2">
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст</span>
										<textarea v-model="block.text" maxlength="2000" class="glass-input mt-2 min-h-24 resize-y" />
									</label>
									<label>
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Подложка</span>
										<input v-model="block.backgroundColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
									</label>
									<label>
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Текст</span>
										<input v-model="block.textColor" type="color" class="mt-2 h-11 w-full rounded-2xl border-0 bg-transparent p-0" />
									</label>
									<label>
										<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Скругление</span>
										<input v-model.number="block.borderRadius" type="number" min="0" max="40" class="glass-input mt-2" />
									</label>
								</div>
								<div
									v-if="block.kind === 'image' || block.kind === 'video'"
									class="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]"
								>
									<p class="min-w-0 truncate text-sm font-medium text-gray-900 dark:text-white">
										{{ getImageTitle(block.mediaKey) }}
									</p>
									<div class="flex flex-wrap gap-2">
										<button type="button" class="btn-secondary" @click="openMediaPicker({ type: 'pageBlock', pageIndex, blockIndex })">
											Выбрать
										</button>
										<button type="button" class="btn-secondary" :disabled="!block.mediaKey" @click="clearPageBlockImage(pageIndex, blockIndex)">
											Убрать
										</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				</template>

				<template v-else-if="activeTab === 'header'">
				<div class="flex flex-wrap items-end justify-between gap-3">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Навигация</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Шапка</h2>
					</div>
					<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
						<input v-model="form.appNavigation.header.enabled" type="checkbox" class="glass-check" />
						<span>{{ form.appNavigation.header.enabled ? 'Показывать' : 'Скрыта' }}</span>
					</label>
				</div>

				<div class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<label class="flex cursor-pointer items-center justify-between gap-4 text-sm font-medium text-gray-700 dark:text-gray-200">
						<span>Показывать на всех страницах</span>
						<input v-model="form.appNavigation.header.showOnAllPages" type="checkbox" class="glass-check" />
					</label>
					<p class="mt-2 text-xs text-gray-400 dark:text-gray-500">
						На главной шапка показывается всегда. При включении она появляется и на остальных страницах приложения.
					</p>
				</div>

				<div class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<div class="flex flex-wrap items-center justify-between gap-3">
						<div>
							<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Блоки</p>
							<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Порядок блоков шапки</h3>
						</div>
						<div class="flex flex-wrap gap-2">
							<button
								v-for="option in headerBlockOptions"
								:key="option.value"
								type="button"
								class="btn-secondary"
								@click="toggleHeaderBlock(option.value)"
							>
								{{ form.appNavigation.header.order.includes(option.value) ? '✓ ' : '+ ' }}{{ option.label }}
							</button>
						</div>
					</div>
					<div class="mt-4 grid gap-2">
						<div
							v-for="(block, index) in form.appNavigation.header.order"
							:key="block"
							class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-4 py-3 dark:border-white/10 dark:bg-white/[0.04]"
						>
							<p class="text-sm font-semibold text-gray-900 dark:text-white">
								{{ headerBlockOptions.find((option) => option.value === block)?.label ?? block }}
							</p>
							<div class="flex gap-2">
								<button type="button" class="btn-secondary" :disabled="index === 0" @click="moveHeaderBlock(index, -1)">
									↑
								</button>
								<button
									type="button"
									class="btn-secondary"
									:disabled="index === form.appNavigation.header.order.length - 1"
									@click="moveHeaderBlock(index, 1)"
								>
									↓
								</button>
							</div>
						</div>
						<p v-if="form.appNavigation.header.order.length === 0" class="text-sm text-gray-400 dark:text-gray-500">
							Добавьте хотя бы один блок
						</p>
						<div class="mt-4 grid gap-3 md:grid-cols-2">
							<label v-if="form.appNavigation.header.order.includes('logo')">
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Логотип</span>
								<select v-model="form.appNavigation.header.logoMode" class="glass-input mt-2">
									<option value="image">Картинка из брендинга</option>
									<option value="text">Название клуба</option>
								</select>
							</label>
							<label v-if="form.appNavigation.header.order.includes('name')">
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Имя</span>
								<select v-model="form.appNavigation.header.nameMode" class="glass-input mt-2">
									<option value="user">Имя пользователя</option>
									<option value="club">Название клуба</option>
								</select>
							</label>
						</div>
					</div>
				</div>

				</template>

				<template v-else-if="activeTab === 'menu'">
				<div class="flex flex-wrap items-end justify-between gap-3">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Навигация</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Нижнее меню</h2>
					</div>
					<button type="button" class="btn-secondary" @click="addMenuItem">+ Вкладка</button>
				</div>

				<div class="mt-5 grid gap-4">
					<div
						v-for="(item, index) in form.appNavigation.menu.items"
						:key="item.id"
						class="rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]"
					>
						<div class="flex flex-wrap items-start justify-between gap-3">
							<div class="min-w-0">
								<p class="text-xs uppercase tracking-[0.16em] text-gray-400 dark:text-gray-500">
									Вкладка {{ index + 1 }}
								</p>
								<p class="mt-1 truncate text-sm font-semibold text-gray-900 dark:text-white">
									{{ item.label || 'Без названия' }}
								</p>
							</div>
							<div class="flex flex-wrap gap-2">
								<button type="button" class="btn-secondary" :disabled="index === 0" @click="moveMenuItem(index, -1)">
									↑
								</button>
								<button
									type="button"
									class="btn-secondary"
									:disabled="index === form.appNavigation.menu.items.length - 1"
									@click="moveMenuItem(index, 1)"
								>
									↓
								</button>
								<button
									type="button"
									class="btn-secondary"
									:disabled="form.appNavigation.menu.items.length <= 1"
									@click="removeMenuItem(index)"
								>
									Убрать
								</button>
							</div>
						</div>

						<div class="mt-4 grid gap-3 md:grid-cols-2">
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Название</span>
								<input v-model="item.label" type="text" maxlength="30" class="glass-input mt-2" />
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Иконка</span>
								<select v-model="item.icon" class="glass-input mt-2">
									<option v-for="option in menuIconOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
							</label>
							<label>
								<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Страница</span>
								<select v-model="item.path" class="glass-input mt-2">
									<option v-for="option in pageOptions" :key="option.value" :value="option.value">
										{{ option.label }}
									</option>
								</select>
							</label>
							<div class="flex flex-wrap items-end gap-4">
								<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
									<input v-model="item.requiresAuth" type="checkbox" class="glass-check" />
									<span>Только для вошедших</span>
								</label>
								<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
									<input v-model="item.requiresAccess" type="checkbox" class="glass-check" />
									<span>Только с доступом</span>
								</label>
							</div>
						</div>
					</div>
				</div>

				<div class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<div class="flex flex-wrap items-center justify-between gap-3">
						<div>
							<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Кнопка посередине</p>
							<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Центральная кнопка</h3>
						</div>
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.appNavigation.menu.centerButton.enabled" type="checkbox" class="glass-check" />
							<span>{{ form.appNavigation.menu.centerButton.enabled ? 'Включена' : 'Выключена' }}</span>
						</label>
					</div>
					<div class="mt-4 grid gap-3 md:grid-cols-2">
						<label>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Иконка</span>
							<select v-model="form.appNavigation.menu.centerButton.icon" class="glass-input mt-2">
								<option v-for="option in menuIconOptions" :key="option.value" :value="option.value">
									{{ option.label }}
								</option>
							</select>
						</label>
						<label>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Действие</span>
							<select v-model="form.appNavigation.menu.centerButton.actionPath" class="glass-input mt-2">
								<option v-for="option in pageOptions" :key="option.value" :value="option.value">
									{{ option.label }}
								</option>
							</select>
						</label>
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.appNavigation.menu.centerButton.glowEnabled" type="checkbox" class="glass-check" />
							<span>Свечение</span>
						</label>
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.appNavigation.menu.centerButton.pressEffectEnabled" type="checkbox" class="glass-check" />
							<span>Эффект нажатия</span>
						</label>
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.appNavigation.menu.centerButton.requiresAuth" type="checkbox" class="glass-check" />
							<span>Только для вошедших</span>
						</label>
					</div>
					<div
						class="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 dark:border-white/10 dark:bg-white/[0.03]"
					>
						<div class="min-w-0">
							<p class="text-sm font-medium text-gray-900 dark:text-white">
								{{ getImageTitle(form.appNavigation.menu.centerButton.imageKey) }}
							</p>
							<p class="mt-1 text-xs text-gray-400 dark:text-gray-500">Картинка кнопки (заменит иконку)</p>
						</div>
						<div class="flex flex-wrap gap-2">
							<button type="button" class="btn-secondary" @click="openMediaPicker({ type: 'centerButton' })">
								Выбрать
							</button>
							<button
								type="button"
								class="btn-secondary"
								:disabled="!form.appNavigation.menu.centerButton.imageKey"
								@click="clearCenterButtonImage"
							>
								Убрать
							</button>
						</div>
					</div>
				</div>

				<div class="mt-5 rounded-[26px] border border-gray-200/70 bg-white/60 p-4 dark:border-white/10 dark:bg-white/[0.03]">
					<div>
						<p class="text-xs uppercase tracking-[0.18em] text-gray-400 dark:text-gray-500">Оформление</p>
						<h3 class="mt-1 text-base font-semibold text-gray-900 dark:text-white">Цвета и форма</h3>
					</div>
					<div class="mt-4 grid gap-3 sm:grid-cols-2">
						<label class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Фон меню</span>
							<span class="flex items-center gap-3">
								<input v-model="form.appNavigation.menu.backgroundColor" type="color" class="h-9 w-12 cursor-pointer rounded-xl border-0 bg-transparent p-0" aria-label="Фон меню" />
								<span class="w-20 font-mono text-sm text-gray-600 dark:text-gray-300">{{ form.appNavigation.menu.backgroundColor }}</span>
							</span>
						</label>
						<label class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
							<span class="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
								<input v-model="menuBorderVisible" type="checkbox" class="glass-check" />
								<span>Обводка меню</span>
							</span>
							<span class="flex items-center gap-3">
								<input v-model="menuBorderColorValue" type="color" class="h-9 w-12 cursor-pointer rounded-xl border-0 bg-transparent p-0" :disabled="!menuBorderVisible" aria-label="Обводка меню" />
								<span class="w-20 font-mono text-sm text-gray-600 dark:text-gray-300">{{ menuBorderVisible ? form.appNavigation.menu.borderColor : 'убрана' }}</span>
							</span>
						</label>
						<label class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
							<span class="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
								<input v-model="menuIconStrokeVisible" type="checkbox" class="glass-check" />
								<span>Обводка иконок</span>
							</span>
							<span class="flex items-center gap-3">
								<input v-model="menuIconStrokeColorValue" type="color" class="h-9 w-12 cursor-pointer rounded-xl border-0 bg-transparent p-0" :disabled="!menuIconStrokeVisible" aria-label="Обводка иконок" />
								<span class="w-20 font-mono text-sm text-gray-600 dark:text-gray-300">{{ menuIconStrokeVisible ? form.appNavigation.menu.iconStrokeColor : 'убрана' }}</span>
							</span>
						</label>
						<label class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Активная иконка</span>
							<span class="flex items-center gap-3">
								<input v-model="form.appNavigation.menu.activeIconColor" type="color" class="h-9 w-12 cursor-pointer rounded-xl border-0 bg-transparent p-0" aria-label="Активная иконка" />
								<span class="w-20 font-mono text-sm text-gray-600 dark:text-gray-300">{{ form.appNavigation.menu.activeIconColor }}</span>
							</span>
						</label>
						<label class="flex items-center justify-between gap-3 rounded-2xl border border-gray-200/70 bg-white/70 px-3 py-2 dark:border-white/10 dark:bg-white/[0.04]">
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Неактивная иконка</span>
							<span class="flex items-center gap-3">
								<input v-model="form.appNavigation.menu.inactiveIconColor" type="color" class="h-9 w-12 cursor-pointer rounded-xl border-0 bg-transparent p-0" aria-label="Неактивная иконка" />
								<span class="w-20 font-mono text-sm text-gray-600 dark:text-gray-300">{{ form.appNavigation.menu.inactiveIconColor }}</span>
							</span>
						</label>
					</div>
					<div class="mt-4 flex flex-wrap gap-4">
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.appNavigation.menu.iconGlowEnabled" type="checkbox" class="glass-check" />
							<span>Свечение иконок</span>
						</label>
						<label class="flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
							<input v-model="form.appNavigation.menu.iconHighlightEnabled" type="checkbox" class="glass-check" />
							<span>Выделение активной иконки</span>
						</label>
					</div>
					<div class="mt-4 grid gap-3 md:grid-cols-3">
						<label>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Скругление меню</span>
							<input v-model.number="form.appNavigation.menu.borderRadius" type="number" min="0" max="40" class="glass-input mt-2" :disabled="menuFlushMode" />
						</label>
						<label>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Отступ снизу</span>
							<input v-model.number="form.appNavigation.menu.marginBottom" type="number" min="0" max="40" class="glass-input mt-2" :disabled="menuFlushMode" />
						</label>
						<label>
							<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Отступ по бокам</span>
							<input v-model.number="form.appNavigation.menu.marginSide" type="number" min="0" max="32" class="glass-input mt-2" :disabled="menuFlushMode" />
						</label>
					</div>
					<label class="mt-4 flex cursor-pointer items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
						<input v-model="menuFlushMode" type="checkbox" class="glass-check" />
						<span>Слитно (без отступов и скругления)</span>
					</label>
					<label class="mt-4 block">
						<span class="text-sm font-medium text-gray-700 dark:text-gray-200">Активная вкладка при старте</span>
						<select v-model="form.appNavigation.menu.startActivePath" class="glass-input mt-2">
							<option v-for="option in pageOptions" :key="option.value" :value="option.value">
								{{ option.label }}
							</option>
						</select>
					</label>
				</div>

				</template>

				<template v-else>
				<div class="flex flex-wrap items-end justify-between gap-3">
					<div>
						<p class="text-xs uppercase tracking-[0.22em] text-gray-400 dark:text-gray-500">Медиа</p>
						<h2 class="mt-2 text-xl font-semibold text-gray-900 dark:text-white">Медиа</h2>
					</div>
					<form class="flex min-w-[260px] flex-1 gap-2 sm:max-w-md" @submit.prevent="loadImages">
						<input
							v-model="search"
							type="search"
							class="glass-input"
							placeholder="Поиск"
						/>
						<button type="submit" class="btn-secondary shrink-0" :disabled="mediaLoading">
							Найти
						</button>
					</form>
				</div>
				<div class="mt-3 rounded-2xl border border-gray-200/70 bg-white/60 px-4 py-3 text-sm text-gray-500 dark:border-white/10 dark:bg-white/[0.03] dark:text-gray-400">
					Выбор: {{ mediaTargetLabel }}
				</div>

				<div v-if="mediaLoading" class="py-10 text-center text-sm text-gray-500 dark:text-gray-400">
					Загружаю медиа...
				</div>
				<div
					v-else-if="images.length === 0"
					class="mt-5 rounded-3xl border border-dashed border-gray-200 px-4 py-10 text-center text-sm text-gray-500 dark:border-white/10 dark:text-gray-400"
				>
					Медиа не найдены.
				</div>
				<div v-else class="mt-5 grid gap-4 sm:grid-cols-2 2xl:grid-cols-3">
					<button
						v-for="item in images"
						:key="item.key"
						type="button"
						class="group overflow-hidden rounded-[26px] border bg-white text-left transition hover:-translate-y-0.5 hover:shadow-[0_20px_50px_rgba(15,23,42,0.12)] dark:bg-black/20 dark:hover:bg-white/[0.03]"
						:class="
							item.key === selectedMediaKey
								? 'border-primary-400/70 ring-2 ring-primary-300/30 dark:border-primary-300/70 dark:ring-primary-300/20'
								: 'border-gray-200/80 dark:border-white/10'
						"
						@click="selectMediaItem(item)"
					>
						<div class="aspect-[16/10] overflow-hidden bg-gray-100 dark:bg-white/[0.04]">
							<img
								v-if="item.type === 'image'"
								:src="item.url"
								:alt="item.title || item.name"
								class="h-full w-full object-cover"
							/>
							<div
								v-else
								class="flex h-full w-full items-center justify-center bg-black/10 text-sm font-semibold text-gray-500 dark:bg-white/[0.03] dark:text-gray-300"
							>
								{{ item.type === 'video' ? 'Видео' : 'Файл' }}
							</div>
						</div>
						<div class="space-y-1 px-4 py-3">
							<p class="truncate text-sm font-medium text-gray-900 dark:text-white">
								{{ item.title || item.name }}
							</p>
							<p class="truncate text-xs text-gray-500 dark:text-gray-400">{{ item.name }}</p>
						</div>
					</button>
				</div>
				</template>
			</section>
			</div>

			<aside v-if="props.mode === 'design'" class="design-preview-panel">
				<div class="design-preview-header">
					<div>
						<p>Предпросмотр</p>
						<strong>Приложение</strong>
					</div>
					<button type="button" @click="previewVersion += 1">Обновить</button>
				</div>
				<div class="design-preview-devices">
					<label>
						<span>Устройство</span>
						<select v-model="selectedPreviewDeviceId" aria-label="Размер предпросмотра">
							<optgroup
								v-for="group in previewDeviceGroups"
								:key="group.label"
								:label="group.label"
							>
								<option
									v-for="device in group.devices"
									:key="device.id"
									:value="device.id"
								>
									{{ device.label }} · {{ device.width }} x {{ device.height }}
								</option>
							</optgroup>
						</select>
					</label>
					<p>{{ selectedPreviewDevice.width }} x {{ selectedPreviewDevice.height }} CSS px</p>
				</div>
				<a
					v-if="isDesktopPreview"
					:href="appPreviewSrc"
					target="_blank"
					rel="noopener"
					class="design-preview-open-link"
				>
					Открыть в браузере
				</a>
				<div class="design-device-stage">
					<div class="design-phone-frame-shell" :style="appPreviewStyle">
						<div class="design-phone-frame" :class="{ 'is-desktop': isDesktopPreview }">
							<div v-if="isDesktopPreview" class="design-desktop-bar">
								<span />
								<span />
								<span />
							</div>
							<template v-else>
								<div class="design-phone-speaker" />
								<div class="design-phone-button left" />
								<div class="design-phone-button right" />
							</template>
							<iframe
								:key="previewVersion"
								:src="appPreviewSrc"
								title="Предпросмотр приложения"
								class="design-phone-frame-iframe"
							/>
						</div>
					</div>
				</div>
			</aside>
		</div>
	</div>
</template>

<style scoped>
.settings-tab-active {
	background: rgba(71, 85, 105, 0.64);
	border-color: rgba(203, 213, 225, 0.36);
	color: #ffffff;
	box-shadow: 0 12px 30px rgba(15, 23, 42, 0.24);
}

.design-workspace {
	display: grid;
	grid-template-columns: minmax(0, 1fr) minmax(22rem, 28rem);
	gap: 1.25rem;
	align-items: start;
}

.design-editor-panel {
	min-width: 0;
}

.design-preview-panel {
	position: sticky;
	top: 1rem;
	display: flex;
	min-width: 0;
	flex-direction: column;
	gap: 0.85rem;
}

.design-preview-header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 1rem;
	border: 1px solid rgba(255, 255, 255, 0.1);
	border-radius: 1.45rem;
	background: rgba(15, 23, 42, 0.74);
	padding: 0.9rem 1rem;
}

.design-preview-header p {
	color: rgb(148 163 184);
	font-size: 0.68rem;
	font-weight: 700;
	letter-spacing: 0.18em;
	text-transform: uppercase;
}

.design-preview-header strong {
	display: block;
	margin-top: 0.18rem;
	color: #fff;
	font-size: 0.98rem;
}

.design-preview-header button {
	border: 1px solid rgba(255, 255, 255, 0.12);
	border-radius: 999px;
	background: rgba(255, 255, 255, 0.06);
	padding: 0.55rem 0.82rem;
	color: rgb(226 232 240);
	font-size: 0.82rem;
	font-weight: 700;
	transition: background 0.16s ease, color 0.16s ease;
}

.design-preview-header button:hover {
	background: rgba(255, 255, 255, 0.12);
	color: #fff;
}

.design-preview-devices {
	display: flex;
	align-items: end;
	justify-content: space-between;
	gap: 0.75rem;
}

.design-preview-devices label {
	display: flex;
	min-width: 0;
	flex: 1;
	flex-direction: column;
	gap: 0.35rem;
}

.design-preview-devices span {
	color: rgb(148 163 184);
	font-size: 0.66rem;
	font-weight: 800;
	letter-spacing: 0.16em;
	text-transform: uppercase;
}

.design-preview-devices select {
	width: 100%;
	min-width: 0;
	border: 1px solid rgba(255, 255, 255, 0.14);
	border-radius: 1rem;
	background: rgba(15, 23, 42, 0.84);
	padding: 0.72rem 0.85rem;
	color: #fff;
	font-size: 0.86rem;
	font-weight: 800;
	outline: none;
}

.design-preview-devices select:focus {
	border-color: rgba(226, 232, 240, 0.42);
}

.design-preview-devices p {
	flex: 0 0 auto;
	color: rgb(148 163 184);
	font-size: 0.74rem;
	font-weight: 700;
	white-space: nowrap;
}

.design-preview-open-link {
	display: inline-flex;
	align-items: center;
	justify-content: center;
	align-self: flex-start;
	border: 1px solid rgba(226, 232, 240, 0.2);
	border-radius: 999px;
	background: rgba(255, 255, 255, 0.07);
	padding: 0.62rem 0.95rem;
	color: #fff;
	font-size: 0.82rem;
	font-weight: 800;
	text-decoration: none;
	transition: background 0.16s ease, border-color 0.16s ease;
}

.design-preview-open-link:hover {
	border-color: rgba(226, 232, 240, 0.36);
	background: rgba(255, 255, 255, 0.12);
}

.design-device-stage {
	overflow: hidden;
	padding: 0.15rem 0.15rem 0.8rem;
}

.design-phone-frame-shell {
	width: var(--preview-display-width);
	height: var(--preview-display-height);
	margin: 0 auto;
}

.design-phone-frame {
	position: relative;
	box-sizing: content-box;
	overflow: hidden;
	width: var(--preview-width);
	border: 1px solid rgba(255, 255, 255, 0.2);
	border-radius: 2.35rem;
	background:
		linear-gradient(145deg, rgba(255, 255, 255, 0.16), transparent 24%),
		#050505;
	padding: 2.15rem 0.7rem 0.82rem;
	box-shadow:
		0 24px 80px rgba(0, 0, 0, 0.34),
		inset 0 0 0 0.55rem rgba(255, 255, 255, 0.04);
	transform: scale(var(--preview-scale));
	transform-origin: top left;
}

.design-phone-frame.is-desktop {
	border-radius: 1rem;
	padding: 2rem 0 0;
}

.design-desktop-bar {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	display: flex;
	gap: 0.42rem;
	align-items: center;
	height: 2rem;
	padding-left: 0.78rem;
	border-bottom: 1px solid rgba(255, 255, 255, 0.08);
	background: rgba(15, 23, 42, 0.82);
}

.design-desktop-bar span {
	width: 0.46rem;
	height: 0.46rem;
	border-radius: 999px;
	background: rgba(226, 232, 240, 0.34);
}

.design-phone-speaker {
	position: absolute;
	top: 0.82rem;
	left: 50%;
	width: 5.6rem;
	height: 0.42rem;
	transform: translateX(-50%);
	border-radius: 999px;
	background: rgba(255, 255, 255, 0.14);
	box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.45);
}

.design-phone-button {
	position: absolute;
	width: 0.18rem;
	border-radius: 999px;
	background: rgba(255, 255, 255, 0.18);
}

.design-phone-button.left {
	top: 7.8rem;
	left: -0.16rem;
	height: 4.2rem;
}

.design-phone-button.right {
	top: 10.4rem;
	right: -0.16rem;
	height: 5.4rem;
}

.design-phone-frame-iframe {
	display: block;
	width: var(--preview-width);
	height: var(--preview-height);
	border: 0;
	border-radius: 1.75rem;
	background: #141414;
}

.design-phone-frame.is-desktop .design-phone-frame-iframe {
	border-radius: 0 0 0.9rem 0.9rem;
}

@media (max-width: 1180px) {
	.design-workspace {
		grid-template-columns: minmax(0, 1fr);
	}

	.design-preview-panel {
		position: static;
	}
}

@media (max-width: 640px) {
	.design-preview-devices {
		align-items: stretch;
		flex-direction: column;
	}

	.design-preview-devices p {
		white-space: normal;
	}
}

.admin-section-preview {
	display: grid;
	width: min(100%, 30rem);
	gap: 0.65rem;
}

.admin-section-preview-featured {
	grid-template-columns: repeat(2, minmax(0, 1fr));
	grid-template-rows: 9rem 4.6rem 12.7rem;
}

.admin-section-preview-equalOneRow {
	grid-template-columns: repeat(4, minmax(0, 1fr));
}

.admin-section-preview-equalTwoRows {
	grid-template-columns: repeat(2, minmax(0, 1fr));
}

.admin-section-preview-tile {
	position: relative;
	display: flex;
	min-height: 4rem;
	align-items: flex-end;
	overflow: hidden;
	border: 1px solid rgba(255, 255, 255, 0.12);
	border-radius: 0.9rem;
	padding: 0.62rem;
	box-shadow:
		inset 0 1px 0 rgba(255, 255, 255, 0.1),
		0 12px 24px rgba(0, 0, 0, 0.22);
}

.admin-section-preview-featured .admin-section-preview-tile-0 {
	grid-column: 1;
	grid-row: span 2;
}

.admin-section-preview-featured .admin-section-preview-tile-3 {
	grid-column: 1 / -1;
}

.admin-section-preview-equalOneRow .admin-section-preview-tile {
	aspect-ratio: 1 / 1;
	min-height: 0;
}

.admin-section-preview-image {
	position: absolute;
	inset: 0;
	z-index: 0;
	width: 100%;
	height: 100%;
	object-fit: cover;
}

.admin-section-preview-tile::after {
	position: absolute;
	inset: 0;
	z-index: 1;
	content: "";
	background:
		radial-gradient(circle at 14% 92%, rgba(255, 255, 255, 0.13), transparent 38%),
		radial-gradient(circle at 86% 16%, rgba(212, 45, 47, 0.25), transparent 42%),
		linear-gradient(180deg, rgba(0, 0, 0, 0.04), rgba(0, 0, 0, 0.32));
}

.admin-section-preview-tile span {
	position: relative;
	z-index: 2;
	font-size: 0.82rem;
	font-weight: 760;
	line-height: 1.05;
	overflow-wrap: anywhere;
}

.admin-section-preview-featured .admin-section-preview-tile-0 span {
	font-size: 1.2rem;
}
</style>
