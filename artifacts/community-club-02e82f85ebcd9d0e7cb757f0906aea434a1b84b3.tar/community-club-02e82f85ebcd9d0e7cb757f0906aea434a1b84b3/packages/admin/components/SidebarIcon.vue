<script setup lang="ts">
defineProps<{ name: string }>()
</script>

<template>
	<span class="inline-flex items-center justify-center">
		<!-- Dashboard / grid -->
		<svg v-if="name === 'dashboard'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
		</svg>

		<!-- Users -->
		<svg v-else-if="name === 'users'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
		</svg>

		<!-- Chart / analytics -->
		<svg v-else-if="name === 'chart'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
		</svg>

		<!-- Activity -->
		<svg v-else-if="name === 'activity'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 13h4l3-7 4 14 3-7h2" />
		</svg>

		<!-- Calendar -->
		<svg v-else-if="name === 'calendar'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
		</svg>

		<!-- Support -->
		<svg v-else-if="name === 'support'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636A9 9 0 105.636 18.364L3 21l2.636-2.636A9 9 0 0018.364 5.636z" />
		</svg>

		<!-- Chat -->
		<svg v-else-if="name === 'chat'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h6m-8 8 3-3h9a4 4 0 004-4V8a4 4 0 00-4-4H7a4 4 0 00-4 4v5a4 4 0 004 4" />
		</svg>

		<!-- Book -->
		<svg v-else-if="name === 'book'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
		</svg>

		<!-- Bell -->
		<svg v-else-if="name === 'bell'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
		</svg>

		<!-- Feed / newspaper -->
		<svg v-else-if="name === 'feed'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h9l5 5v11a2 2 0 01-2 2z" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 3v5h5M8 13h8M8 17h5M8 9h3" />
		</svg>

		<!-- Media / photo stack -->
		<svg v-else-if="name === 'media'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2V7z" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 13l2.5-2.5a1.5 1.5 0 012.121 0L16 14" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 9h.01" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 10h2a2 2 0 012 2v6a2 2 0 01-2 2H10a2 2 0 01-2-2v-2" />
		</svg>

		<!-- Tag -->
		<svg v-else-if="name === 'tag'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
		</svg>

		<!-- Payments / card -->
		<svg v-else-if="name === 'payments'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8h18M5 5h14a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 15h4" />
		</svg>

		<!-- Document -->
		<svg v-else-if="name === 'document'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 3h7l5 5v13H7a2 2 0 01-2-2V5a2 2 0 012-2z" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 3v5h5M8 13h8M8 17h5" />
		</svg>

		<!-- Design / palette -->
		<svg v-else-if="name === 'design'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 20.5a8.5 8.5 0 117.9-5.35 1.75 1.75 0 01-1.63 1.1h-1.62a1.5 1.5 0 00-1.06 2.56l.25.25a.85.85 0 01-.46 1.43c-1.08.01-2.2.01-3.38.01Z" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7.8 11.2h.01M10.2 7.9h.01M14 7.9h.01M16.4 11.2h.01" />
		</svg>

		<!-- Settings -->
		<svg v-else-if="name === 'settings'" class="h-full w-full" fill="none" stroke="currentColor" viewBox="0 0 24 24">
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.757.426 1.757 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.757-2.924 1.757-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.757-.426-1.757-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.607 2.296.07 2.572-1.065z" />
			<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
		</svg>
	</span>
</template>
