const localHostnames = new Set(['localhost', '127.0.0.1', '::1'])

export default defineNuxtPlugin(() => {
	const config = useRuntimeConfig()
	if (!localHostnames.has(window.location.hostname)) {
		const publicConfig = config.public as { apiUrl?: string }
		publicConfig.apiUrl = ''
	}
})
