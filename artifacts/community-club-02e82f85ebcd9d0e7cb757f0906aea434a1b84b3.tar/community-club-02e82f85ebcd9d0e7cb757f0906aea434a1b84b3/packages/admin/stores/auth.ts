import { defineStore } from 'pinia'

interface AdminUser {
	authUuid: string
	email: string
	role: string
	fullName: string | null
	chatAdminBadge: boolean
	adminPermissions: string[] | null
}

export const useAuthStore = defineStore('auth', () => {
	const token = ref<string | null>(null)
	const user = ref<AdminUser | null>(null)
	const isLoggedIn = computed(() => !!user.value)

	function init() {
		token.value = null
		if (import.meta.client) localStorage.removeItem('admin_token')
	}

	function getCookie(name: string) {
		if (!import.meta.client) return null
		const match = document.cookie
			.split('; ')
			.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
		return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
	}

	async function login(email: string, password: string): Promise<{ ok: boolean; error?: string }> {
		const config = useRuntimeConfig()
		const csrfToken = getCookie('csrf_token')
		const res = await fetch(`${config.public.apiUrl}/api/auth/login`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
			},
			body: JSON.stringify({ email, password }),
			credentials: 'include',
		})
		const json = await res.json()
		if (!json.success) return { ok: false, error: json.error?.message ?? 'Ошибка авторизации' }

		token.value = null
		if (import.meta.client) localStorage.removeItem('admin_token')

		const meResult = await fetchMe()
		if (!meResult.ok) {
			logout()
			return meResult
		}
		return { ok: true }
	}

	async function fetchMe(): Promise<{ ok: boolean; error?: string }> {
		const config = useRuntimeConfig()
		const res = await fetch(`${config.public.apiUrl}/api/auth/me`, {
			credentials: 'include',
		})
		const json = await res.json()
		if (!json.success) return { ok: false, error: 'Не удалось получить профиль' }

		const u = json.data
		if (!['admin', 'superadmin'].includes(u.role)) {
			return { ok: false, error: 'Нет прав администратора' }
		}
		user.value = {
			authUuid: u.authUuid,
			email: u.email,
			role: u.role,
			fullName: u.fullName,
			chatAdminBadge: Boolean(u.chatAdminBadge),
			adminPermissions: Array.isArray(u.adminPermissions) ? u.adminPermissions : null,
		}
		return { ok: true }
	}

	function logout() {
		const config = useRuntimeConfig()
		const csrfToken = getCookie('csrf_token')
		void fetch(`${config.public.apiUrl}/api/auth/logout`, {
			method: 'POST',
			credentials: 'include',
			headers: csrfToken ? { 'X-CSRF-Token': csrfToken } : undefined,
		}).catch(() => undefined)
		token.value = null
		user.value = null
		if (import.meta.client) localStorage.removeItem('admin_token')
		navigateTo('/login')
	}

	return { token, user, isLoggedIn, init, login, fetchMe, logout }
})
