import type { ApiResponse } from '@community-club/shared/types'
import { useAuthStore } from '~/stores/auth'
import { getUploadProgressPercent } from '../utils/upload-progress'

type AdminMediaUploadBucket = 'media' | 'avatars' | 'chat'

export type AdminMediaUploadResult = {
	path: string
	bucket: string
	size: number | null
	contentType: string
	mediaType: 'image' | 'video' | 'audio' | 'document'
	url: string
}

type AdminMediaUploadOptions = {
	bucket?: AdminMediaUploadBucket
	folderId?: number | null
	onProgress?: (progress: AdminMediaUploadProgress) => void
}

export type AdminMediaUploadProgress = {
	loaded: number
	total: number | null
	percent: number
}

type AdminMediaUploadRoute = 'multipart' | 'raw' | 'chunked'
type AdminMediaUploadRouteReason = 'video-mime' | 'size-threshold' | 'multipart' | 'chunked'

type ParsedUploadResponse<T = AdminMediaUploadResult> = {
	result: ApiResponse<T>
	status: number
	emptyBody: boolean
}

type ChunkedUploadInitResult = {
	uploadId: string
	chunkSize: number
	totalChunks: number
	receivedChunks: number[]
}

type ChunkedUploadPartResult = {
	uploadId: string
	index: number
	size: number
	receivedCount: number
	totalChunks: number
}

const RAW_UPLOAD_THRESHOLD_BYTES = 32 * 1024 * 1024
const CHUNKED_UPLOAD_CHUNK_BYTES = 8 * 1024 * 1024
const CHUNKED_UPLOAD_CONCURRENCY = 4
const CHUNKED_UPLOAD_MAX_ATTEMPTS = 8

function isRussianText(value: string) {
	return /[А-Яа-яЁё]/.test(value)
}

function normalizeUploadError(params: {
	status: number
	code?: string
	message?: string
}) {
	if (params.code === 'UNAUTHORIZED' || params.status === 401) {
		return 'Сессия истекла. Войдите снова.'
	}

	if (params.status === 403) {
		return 'Недостаточно прав для загрузки файла.'
	}

	if (params.status === 413 || params.code === 'UPLOAD_TOO_LARGE') {
		return params.message && isRussianText(params.message)
			? params.message
			: 'Файл слишком большой. Выберите файл меньшего размера.'
	}

	if (params.code === 'UPLOAD_BUSY') {
		return params.message && isRussianText(params.message)
			? params.message
			: 'Очередь загрузки заполнена. Попробуйте чуть позже.'
	}

	if (params.status === 408 || params.status === 502 || params.status === 504) {
		return 'Загрузка прервалась. Попробуйте ещё раз.'
	}

	if (params.status >= 500) {
		return 'Системная ошибка. Обратитесь в поддержку.'
	}

	if (params.message && isRussianText(params.message)) {
		return params.message
	}

	return 'Не удалось загрузить файл. Попробуйте ещё раз.'
}

function parseUploadResponseText<T = AdminMediaUploadResult>(
	status: number,
	text: string,
): ParsedUploadResponse<T> {
	if (!text.trim()) {
		return {
			status,
			emptyBody: true,
			result: {
				success: false,
				error: {
					code: status === 413 ? 'UPLOAD_TOO_LARGE' : 'UPLOAD_ERROR',
					message: normalizeUploadError({ status }),
				},
			},
		}
	}

	try {
		const data = JSON.parse(text) as ApiResponse<T>
		if (!data.success) {
			data.error.message = normalizeUploadError({
				status,
				code: data.error.code,
				message: data.error.message,
			})
		}
		return { result: data, status, emptyBody: false }
	} catch {
		return {
			status,
			emptyBody: false,
			result: {
				success: false,
				error: {
					code: 'UPLOAD_ERROR',
					message: normalizeUploadError({ status }),
				},
			},
		}
	}
}

async function parseUploadResponse<T = AdminMediaUploadResult>(
	response: Response,
): Promise<ParsedUploadResponse<T>> {
	return parseUploadResponseText<T>(response.status, await response.text())
}

function shouldUseRawUpload(file: File) {
	return file.type.startsWith('video/') || file.size > RAW_UPLOAD_THRESHOLD_BYTES
}

function getUploadRoute(file: File): AdminMediaUploadRoute {
	return shouldUseRawUpload(file) ? 'chunked' : 'multipart'
}

function getUploadRouteReason(file: File): AdminMediaUploadRouteReason {
	if (shouldUseRawUpload(file)) return 'chunked'
	return 'multipart'
}

function createUploadTraceId() {
	if (import.meta.client && typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
		return crypto.randomUUID()
	}
	return `${Date.now()}-${Math.random().toString(16).slice(2)}`
}

function getNowMs() {
	return typeof performance !== 'undefined' ? performance.now() : Date.now()
}

export function useAdminMediaUpload() {
	const config = useRuntimeConfig()
	const baseUrl = config.public.apiUrl

	function getCookie(name: string) {
		if (!import.meta.client) return null
		const match = document.cookie
			.split('; ')
			.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
		return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
	}

	function getAuthHeaders() {
		const csrfToken = getCookie('csrf_token')
		return csrfToken ? { 'X-CSRF-Token': csrfToken } : undefined
	}

	function sleep(ms: number) {
		return new Promise<void>((resolve) => window.setTimeout(resolve, ms))
	}

	async function waitForOnline() {
		if (!import.meta.client || typeof navigator === 'undefined' || navigator.onLine !== false) {
			return
		}

		await new Promise<void>((resolve) => {
			window.addEventListener('online', () => resolve(), { once: true })
		})
	}

	function isRetriableUploadFailure(upload: ParsedUploadResponse<unknown>) {
		if (upload.status === 0) return true
		if ([408, 429, 500, 502, 503, 504].includes(upload.status)) return true
		return !upload.result.success && upload.result.error.code === 'UPLOAD_READ_ERROR'
	}

	async function sendUploadRequest<T = AdminMediaUploadResult>(params: {
		url: string
		headers?: Record<string, string>
		body: XMLHttpRequestBodyInit
		onProgress?: (progress: AdminMediaUploadProgress) => void
	}): Promise<ParsedUploadResponse<T>> {
		if (!import.meta.client || typeof XMLHttpRequest === 'undefined') {
			const response = await fetch(params.url, {
				method: 'POST',
				headers: params.headers,
				body: params.body,
				credentials: 'include',
			})
			return parseUploadResponse<T>(response)
		}

		return new Promise((resolve, reject) => {
			const xhr = new XMLHttpRequest()
			xhr.open('POST', params.url, true)
			xhr.withCredentials = true

			for (const [name, value] of Object.entries(params.headers ?? {})) {
				xhr.setRequestHeader(name, value)
			}

			xhr.upload.onprogress = (event) => {
				params.onProgress?.({
					loaded: event.loaded,
					total: event.lengthComputable ? event.total : null,
					percent: getUploadProgressPercent(
						event.loaded,
						event.lengthComputable ? event.total : null,
					),
				})
			}

			xhr.onload = () => {
				resolve(parseUploadResponseText<T>(xhr.status, String(xhr.responseText ?? '')))
			}
			xhr.onerror = () => reject(new Error('Network upload error'))
			xhr.onabort = () => reject(new Error('Upload aborted'))
			xhr.ontimeout = () => reject(new Error('Upload timeout'))
			xhr.send(params.body)
		})
	}

	async function sendJsonUploadRequest<T>(url: string, payload: Record<string, unknown>) {
		const response = await fetch(url, {
			method: 'POST',
			headers: {
				...(getAuthHeaders() ?? {}),
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(payload),
			credentials: 'include',
		})
		return parseUploadResponse<T>(response)
	}

	async function sendUploadTrace(payload: {
		traceId: string
		stage: 'started' | 'finished' | 'network_error'
		route: AdminMediaUploadRoute
		routeReason: AdminMediaUploadRouteReason
		fileName: string
		fileSize: number
		fileType: string
		bucket?: AdminMediaUploadBucket
		folderId?: number | null
		rawThresholdBytes: number
		responseStatus?: number | null
		responseEmptyBody?: boolean | null
		success?: boolean
		errorCode?: string
		errorMessage?: string
		durationMs?: number
	}) {
		if (!import.meta.client) return

		const controller = new AbortController()
		const timeoutId = window.setTimeout(() => controller.abort(), 2500)
		try {
			await fetch(`${baseUrl}/api/media/upload/trace`, {
				method: 'POST',
				headers: {
					...(getAuthHeaders() ?? {}),
					'Content-Type': 'application/json',
				},
				body: JSON.stringify(payload),
				credentials: 'include',
				keepalive: true,
				signal: controller.signal,
			})
		} catch {
			// Диагностическая запись не должна ломать саму загрузку.
		} finally {
			window.clearTimeout(timeoutId)
		}
	}

	async function uploadMultipartFile(
		file: File,
		options: AdminMediaUploadOptions,
		traceId: string,
	): Promise<ParsedUploadResponse> {
		const formData = new FormData()
		formData.append('file', file)
		formData.append('traceId', traceId)
		if (options.bucket) {
			formData.append('bucket', options.bucket)
		}
		if (options.folderId != null) {
			formData.append('folderId', String(options.folderId))
		}

		return sendUploadRequest({
			url: `${baseUrl}/api/media/upload`,
			headers: getAuthHeaders(),
			body: formData,
			onProgress: options.onProgress,
		})
	}

	async function uploadRawFile(
		file: File,
		options: AdminMediaUploadOptions,
		traceId: string,
	): Promise<ParsedUploadResponse> {
		const query = new URLSearchParams({ fileName: file.name })
		query.set('traceId', traceId)
		if (options.bucket) {
			query.set('bucket', options.bucket)
		}
		if (options.folderId != null) {
			query.set('folderId', String(options.folderId))
		}

		return sendUploadRequest({
			url: `${baseUrl}/api/media/upload/raw?${query.toString()}`,
			headers: {
				...(getAuthHeaders() ?? {}),
				'Content-Type': file.type || 'application/octet-stream',
			},
			body: file,
			onProgress: options.onProgress,
		})
	}

	async function abortChunkedUpload(uploadId: string) {
		await fetch(`${baseUrl}/api/media/upload/chunk/${encodeURIComponent(uploadId)}`, {
			method: 'DELETE',
			headers: getAuthHeaders(),
			credentials: 'include',
		}).catch(() => undefined)
	}

	async function uploadChunkWithRetry(params: {
		uploadId: string
		index: number
		chunk: Blob
		onChunkProgress: (loaded: number) => void
	}) {
		let lastError: Error | null = null

		for (let attempt = 1; attempt <= CHUNKED_UPLOAD_MAX_ATTEMPTS; attempt++) {
			await waitForOnline()
			let canRetry = true

			try {
				const upload = await sendUploadRequest<ChunkedUploadPartResult>({
					url: `${baseUrl}/api/media/upload/chunk/${encodeURIComponent(params.uploadId)}/part/${
						params.index
					}`,
					headers: {
						...(getAuthHeaders() ?? {}),
						'Content-Type': 'application/octet-stream',
					},
					body: params.chunk,
					onProgress: (progress) => params.onChunkProgress(progress.loaded),
				})

				if (upload.result.success) {
					params.onChunkProgress(params.chunk.size)
					return upload.result.data
				}

				lastError = new Error(upload.result.error.message)
				if (!isRetriableUploadFailure(upload)) {
					canRetry = false
					throw lastError
				}
			} catch (error) {
				lastError = error instanceof Error ? error : new Error('Chunk upload failed')
				if (!canRetry || attempt >= CHUNKED_UPLOAD_MAX_ATTEMPTS) {
					throw lastError
				}
			}

			params.onChunkProgress(0)
			await waitForOnline()
			await sleep(Math.min(1000 * 2 ** (attempt - 1), 10000))
		}

		throw lastError ?? new Error('Chunk upload failed')
	}

	async function uploadChunkedFile(
		file: File,
		options: AdminMediaUploadOptions,
		traceId: string,
	): Promise<ParsedUploadResponse> {
		options.onProgress?.({
			loaded: 0,
			total: file.size,
			percent: 0,
		})

		const init = await sendJsonUploadRequest<ChunkedUploadInitResult>(
			`${baseUrl}/api/media/upload/chunk/init`,
			{
				fileName: file.name,
				fileSize: file.size,
				contentType: file.type || 'application/octet-stream',
				bucket: options.bucket,
				folderId: options.folderId ?? null,
				chunkSize: CHUNKED_UPLOAD_CHUNK_BYTES,
				traceId,
			},
		)

		if (!init.result.success) {
			return init as ParsedUploadResponse<AdminMediaUploadResult>
		}

		const { uploadId, chunkSize, totalChunks } = init.result.data
		const committedBytes = Array.from({ length: totalChunks }, () => 0)
		const activeBytes = Array.from({ length: totalChunks }, () => 0)

		const reportProgress = () => {
			const loaded =
				committedBytes.reduce((sum, value) => sum + value, 0) +
				activeBytes.reduce((sum, value) => sum + value, 0)
			options.onProgress?.({
				loaded,
				total: file.size,
				percent: getUploadProgressPercent(loaded, file.size),
			})
		}

		let nextIndex = 0
		const uploadNextChunk = async () => {
			while (nextIndex < totalChunks) {
				const index = nextIndex
				nextIndex += 1
				const start = index * chunkSize
				const end = Math.min(start + chunkSize, file.size)
				const chunk = file.slice(start, end)

				await uploadChunkWithRetry({
					uploadId,
					index,
					chunk,
					onChunkProgress: (loaded) => {
						activeBytes[index] = Math.min(loaded, chunk.size)
						reportProgress()
					},
				})

				activeBytes[index] = 0
				committedBytes[index] = chunk.size
				reportProgress()
			}
		}

		try {
			await Promise.all(
				Array.from({ length: Math.min(CHUNKED_UPLOAD_CONCURRENCY, totalChunks) }, () =>
					uploadNextChunk(),
				),
			)
		} catch (error) {
			await abortChunkedUpload(uploadId)
			throw error
		}

		const complete = await sendJsonUploadRequest<AdminMediaUploadResult>(
			`${baseUrl}/api/media/upload/chunk/${encodeURIComponent(uploadId)}/complete`,
			{ traceId },
		)

		if (complete.result.success) {
			options.onProgress?.({
				loaded: file.size,
				total: file.size,
				percent: 100,
			})
		}

		return complete
	}

	async function uploadFile(
		file: File,
		options: AdminMediaUploadOptions = {},
	): Promise<ApiResponse<AdminMediaUploadResult>> {
		const traceId = createUploadTraceId()
		const route = getUploadRoute(file)
		const routeReason = getUploadRouteReason(file)
		const startedAt = getNowMs()
		const baseTracePayload = {
			traceId,
			route,
			routeReason,
			fileName: file.name,
			fileSize: file.size,
			fileType: file.type || 'application/octet-stream',
			bucket: options.bucket,
			folderId: options.folderId,
			rawThresholdBytes: RAW_UPLOAD_THRESHOLD_BYTES,
		}

		await sendUploadTrace({ ...baseTracePayload, stage: 'started' })

		try {
			const upload =
				route === 'chunked'
					? await uploadChunkedFile(file, options, traceId)
					: route === 'raw'
						? await uploadRawFile(file, options, traceId)
						: await uploadMultipartFile(file, options, traceId)
			const result = upload.result

			if (!result.success && result.error.code === 'UNAUTHORIZED') {
				useAuthStore().logout()
			}

			await sendUploadTrace({
				...baseTracePayload,
				stage: 'finished',
				responseStatus: upload.status,
				responseEmptyBody: upload.emptyBody,
				success: result.success,
				errorCode: result.success ? undefined : result.error.code,
				errorMessage: result.success ? undefined : result.error.message,
				durationMs: Math.round(getNowMs() - startedAt),
			})

			return result
		} catch (error) {
			await sendUploadTrace({
				...baseTracePayload,
				stage: 'network_error',
				success: false,
				errorCode: 'NETWORK_ERROR',
				errorMessage: error instanceof Error ? error.message : 'Unknown upload error',
				durationMs: Math.round(getNowMs() - startedAt),
			})

			return {
				success: false,
				error: {
					code: 'NETWORK_ERROR',
					message: 'Ошибка сети. Проверьте подключение и попробуйте ещё раз.',
				},
			}
		}
	}

	return { uploadFile }
}
