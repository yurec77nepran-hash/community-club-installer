import type { WSServerMessage } from '@community-club/shared/types'

export function useAdminWebSocket() {
	const config = useRuntimeConfig()
	const ws = ref<WebSocket | null>(null)
	const isConnected = ref(false)
	const handlers = new Map<string, Set<(data: WSServerMessage) => void>>()
	const joinedRooms = new Map<string, Record<string, unknown>>()
	const queuedMessages: Array<Record<string, unknown>> = []
	let reconnectTimer: ReturnType<typeof setTimeout> | null = null
	let shouldReconnect = true

	function flushMessages() {
		if (ws.value?.readyState !== WebSocket.OPEN) return

		for (const payload of joinedRooms.values()) {
			ws.value.send(JSON.stringify(payload))
		}

		while (queuedMessages.length > 0) {
			const payload = queuedMessages.shift()
			if (payload) {
				ws.value.send(JSON.stringify(payload))
			}
		}
	}

	function connect() {
		if (ws.value?.readyState === WebSocket.OPEN || ws.value?.readyState === WebSocket.CONNECTING)
			return

		shouldReconnect = true
		const wsUrl = config.public.apiUrl.replace(/^http/, 'ws')
		ws.value = new WebSocket(`${wsUrl}/ws`)

		ws.value.onopen = () => {
			isConnected.value = true
			if (reconnectTimer) {
				clearTimeout(reconnectTimer)
				reconnectTimer = null
			}
			flushMessages()
		}

		ws.value.onclose = () => {
			isConnected.value = false
			ws.value = null
			if (!shouldReconnect) return
			reconnectTimer = setTimeout(connect, 3000)
		}

		ws.value.onmessage = (event) => {
			try {
				const msg = JSON.parse(event.data) as WSServerMessage
				const typeHandlers = handlers.get(msg.type)
				if (!typeHandlers) return
				for (const handler of typeHandlers) {
					handler(msg)
				}
			} catch {}
		}
	}

	function send(data: Record<string, unknown>) {
		if (data.type === 'join_room' && data.chatId != null) {
			joinedRooms.set(String(data.chatId), data)
		}
		if (data.type === 'leave_room' && data.chatId != null) {
			joinedRooms.delete(String(data.chatId))
		}

		if (ws.value?.readyState === WebSocket.OPEN) {
			ws.value.send(JSON.stringify(data))
			return
		}

		if (data.type !== 'join_room' && data.type !== 'leave_room') {
			queuedMessages.push(data)
		}

		if (!ws.value || ws.value.readyState === WebSocket.CLOSED) {
			connect()
		}
	}

	function on(type: string, handler: (data: WSServerMessage) => void) {
		if (!handlers.has(type)) handlers.set(type, new Set())
		handlers.get(type)?.add(handler)
		return () => handlers.get(type)?.delete(handler)
	}

	function disconnect() {
		shouldReconnect = false
		if (reconnectTimer) {
			clearTimeout(reconnectTimer)
			reconnectTimer = null
		}
		ws.value?.close()
		ws.value = null
	}

	return { connect, send, on, disconnect, isConnected }
}
