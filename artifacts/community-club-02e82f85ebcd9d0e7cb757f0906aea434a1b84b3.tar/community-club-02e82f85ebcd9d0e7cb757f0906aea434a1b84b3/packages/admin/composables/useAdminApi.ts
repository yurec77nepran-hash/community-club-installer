import type { ApiResponse } from '@community-club/shared/types'
import { useAuthStore } from '~/stores/auth'

function isRussianText(value: string) {
	return /[А-Яа-яЁё]/.test(value)
}

function normalizeAdminErrorMessage(params: { status: number; code?: string; message?: string }) {
	if (params.status >= 500) {
		return 'Системная ошибка. Обратитесь в поддержку.'
	}

	if (params.code === 'UNAUTHORIZED') {
		return 'Сессия истекла. Войдите снова.'
	}

	if (params.code === 'FORBIDDEN') {
		return 'Недостаточно прав для этого действия.'
	}

	if (params.message && isRussianText(params.message)) {
		return params.message
	}

	return 'Не удалось выполнить действие. Попробуйте ещё раз.'
}

export function useAdminApi() {
	const config = useRuntimeConfig()
	const baseUrl = config.public.apiUrl
	const requestBaseUrl =
		import.meta.client && !['localhost', '127.0.0.1'].includes(window.location.hostname)
			? ''
			: baseUrl

	function getCookie(name: string) {
		if (!import.meta.client) return null
		const match = document.cookie
			.split('; ')
			.find((part) => part.startsWith(`${encodeURIComponent(name)}=`))
		return match ? decodeURIComponent(match.split('=').slice(1).join('=')) : null
	}

	async function request<T>(path: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
		const headers: Record<string, string> = {
			'Content-Type': 'application/json',
			...(options.headers as Record<string, string>),
		}

		const method = options.method ?? 'GET'
		if (method !== 'GET' && method !== 'HEAD') {
			const csrfToken = getCookie('csrf_token')
			if (csrfToken) headers['X-CSRF-Token'] = csrfToken
		}

		let response: Response
		try {
			response = await fetch(`${requestBaseUrl}${path}`, {
				...options,
				headers,
				credentials: 'include',
			})
		} catch {
			return {
				success: false,
				error: {
					code: 'NETWORK_ERROR',
					message: 'Ошибка сети. Проверьте подключение и попробуйте ещё раз.',
				},
			} as ApiResponse<T>
		}

		if (response.status === 401) {
			const auth = useAuthStore()
			auth.logout()
			return {
				success: false,
				error: { code: 'UNAUTHORIZED', message: 'Сессия истекла' },
			} as ApiResponse<T>
		}

		try {
			const data = (await response.json()) as ApiResponse<T>
			if (!data.success) {
				data.error.message = normalizeAdminErrorMessage({
					status: response.status,
					code: data.error.code,
					message: data.error.message,
				})
			}
			return data
		} catch {
			return {
				success: false,
				error: { code: 'SYSTEM_ERROR', message: 'Системная ошибка. Обратитесь в поддержку.' },
			} as ApiResponse<T>
		}
	}

	return {
		get: <T>(path: string) => request<T>(path),
		post: <T>(path: string, body?: unknown) =>
			request<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined }),
		put: <T>(path: string, body?: unknown) =>
			request<T>(path, { method: 'PUT', body: body ? JSON.stringify(body) : undefined }),
		patch: <T>(path: string, body?: unknown) =>
			request<T>(path, { method: 'PATCH', body: body ? JSON.stringify(body) : undefined }),
		delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
	}
}
