const STORAGE_KEY = 'admin_dark'

const isDark = ref(true)

export function useDarkMode() {
	function toggle() {
		isDark.value = true
		apply()
		localStorage.setItem(STORAGE_KEY, '1')
	}

	function apply() {
		document.documentElement.classList.add('dark')
	}

	function init() {
		isDark.value = true
		apply()
		localStorage.setItem(STORAGE_KEY, '1')
	}

	return { isDark, toggle, init }
}
