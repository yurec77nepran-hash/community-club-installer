export const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥'] as const
export type ReactionEmoji = (typeof REACTIONS)[number]

export const FEED_AUDIENCES = {
	club: 'Участники',
} as const

export const MATERIAL_TYPES = {
	courses: 'Уроки',
	streams: 'Эфиры',
	checklists: 'Шаблоны',
	other: 'Инструменты',
	experts: 'От экспертов',
} as const

export const ERROR_CODES = {
	UNAUTHORIZED: 'UNAUTHORIZED',
	FORBIDDEN: 'FORBIDDEN',
	NOT_FOUND: 'NOT_FOUND',
	VALIDATION_ERROR: 'VALIDATION_ERROR',
	SUBSCRIPTION_REQUIRED: 'SUBSCRIPTION_REQUIRED',
	RATE_LIMITED: 'RATE_LIMITED',
	INTERNAL_ERROR: 'INTERNAL_ERROR',
} as const
