import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const schemaPath = new URL('./schema/materials.ts', import.meta.url)
const performanceBootstrapPath = new URL(
	'../../../api/src/lib/performance-bootstrap.ts',
	import.meta.url,
)
const adminRoutePath = new URL('../../../api/src/routes/admin.ts', import.meta.url)

describe('materials schema cleanup', () => {
	test('does not keep old external import identifiers in runtime schema or admin payloads', async () => {
		const removedColumn = ['legacy', ['supa', 'base'].join(''), 'id'].join('_')
		const removedProperty = ['legacy', ['Supa', 'base'].join(''), 'Id'].join('')
		const files = await Promise.all([
			readFile(schemaPath, 'utf8'),
			readFile(performanceBootstrapPath, 'utf8'),
			readFile(adminRoutePath, 'utf8'),
		])

		for (const file of files) {
			expect(file).not.toContain(removedColumn)
			expect(file).not.toContain(removedProperty)
		}
	})
})
