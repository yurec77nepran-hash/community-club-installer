import { boolean, date, numeric, pgTable, serial, text, timestamp, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import type { z } from 'zod'
import { users } from './users'

export const payments = pgTable('payments', {
	id: serial('id').primaryKey(),
	userAuthUuid: uuid('user_auth_uuid').references(() => users.authUuid),
	email: text('email'),
	phone: text('phone'),
	// Тариф
	tarrif: text('tarrif'),
	dateStart: date('date_start'),
	dateFinish: date('date_finish'),
	// CloudPayments
	cpSubscriptionId: text('cp_subscription_id'),
	cpAccountId: text('cp_account_id'),
	cpToken: text('cp_token'),
	paymentProvider: text('payment_provider', {
		enum: ['cloudpayments', 'prodamus', 'yookassa', 'tochka'],
	}),
	amount: numeric('amount'),
	autoPayment: boolean('auto_payment').default(true).notNull(),
	// Прочее
	noAutopodpiska: boolean('no_autopodpiska').default(false).notNull(),
	zarub: boolean('zarub').default(false).notNull(),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

export const paymentSelectSchema = createSelectSchema(payments)
export const paymentInsertSchema = createInsertSchema(payments)

export type Payment = z.infer<typeof paymentSelectSchema>
export type NewPayment = z.infer<typeof paymentInsertSchema>
