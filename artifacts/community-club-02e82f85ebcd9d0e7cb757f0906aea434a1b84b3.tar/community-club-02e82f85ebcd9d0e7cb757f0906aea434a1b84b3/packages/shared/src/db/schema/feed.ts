import {
	bigint,
	bigserial,
	boolean,
	index,
	jsonb,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { httpUrlSchema } from '../../validators/common'
import { users } from './users'

export const feedAudienceValues = ['club'] as const
export type FeedAudience = (typeof feedAudienceValues)[number]

export const feedMediaTypeValues = ['image', 'video'] as const
export type FeedMediaType = (typeof feedMediaTypeValues)[number]

export const feedPosts = pgTable(
	'feed_posts',
	{
		id: bigserial('id', { mode: 'number' }).primaryKey(),
		authorAuthUuid: uuid('author_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		audience: text('audience', { enum: feedAudienceValues }).notNull(),
		emoji: text('emoji'),
		content: text('content').notNull(),
		buttonLabel: text('button_label'),
		buttonUrl: text('button_url'),
		notifyAll: boolean('notify_all').default(false).notNull(),
		media: jsonb('media')
			.$type<
				Array<{
					type: FeedMediaType
					path: string
					url: string | null
					name: string | null
					size: number | null
					width: number | null
					height: number | null
					durationSeconds: number | null
				}>
			>()
			.default([]),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('feed_posts_audience_created_idx').on(table.audience, table.createdAt, table.id),
		index('feed_posts_author_idx').on(table.authorAuthUuid, table.createdAt),
	],
)

export const feedPostDrafts = pgTable(
	'feed_post_drafts',
	{
		id: bigserial('id', { mode: 'number' }).primaryKey(),
		authorAuthUuid: uuid('author_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		audience: text('audience', { enum: feedAudienceValues }).notNull(),
		content: text('content').notNull().default(''),
		buttonLabel: text('button_label'),
		buttonUrl: text('button_url'),
		notifyAll: boolean('notify_all').default(false).notNull(),
		media: jsonb('media')
			.$type<
				Array<{
					type: FeedMediaType
					path: string
					url: string | null
					name: string | null
					size: number | null
					width: number | null
					height: number | null
					durationSeconds: number | null
				}>
			>()
			.default([]),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('feed_post_drafts_author_audience_idx').on(table.authorAuthUuid, table.audience),
		index('feed_post_drafts_author_updated_idx').on(table.authorAuthUuid, table.updatedAt),
	],
)

export const feedPostReactions = pgTable(
	'feed_post_reactions',
	{
		id: serial('id').primaryKey(),
		postId: bigint('post_id', { mode: 'number' })
			.references(() => feedPosts.id, { onDelete: 'cascade' })
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		emoji: text('emoji').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('feed_post_reaction_unique').on(table.postId, table.userAuthUuid, table.emoji),
		index('feed_post_reactions_post_idx').on(table.postId, table.createdAt),
		index('feed_post_reactions_user_idx').on(table.userAuthUuid, table.createdAt),
	],
)

export const feedPostSelectSchema = createSelectSchema(feedPosts)
export const feedPostInsertSchema = createInsertSchema(feedPosts, {
	audience: z.enum(feedAudienceValues),
	content: z.string().trim().min(1).max(20000),
	buttonLabel: z.string().trim().max(80).nullable().optional(),
	buttonUrl: httpUrlSchema.nullable().optional(),
	notifyAll: z.boolean().optional(),
	media: z
		.array(
			z.object({
				type: z.enum(feedMediaTypeValues),
				path: z.string().min(1),
				url: httpUrlSchema.nullable().optional(),
				name: z.string().nullable().optional(),
				size: z.number().int().nullable().optional(),
				width: z.number().int().nullable().optional(),
				height: z.number().int().nullable().optional(),
				durationSeconds: z.number().int().nullable().optional(),
			}),
		)
		.max(10)
		.optional(),
})

export const feedPostReactionSelectSchema = createSelectSchema(feedPostReactions)
export const feedPostDraftSelectSchema = createSelectSchema(feedPostDrafts)

export type FeedPost = z.infer<typeof feedPostSelectSchema>
export type NewFeedPost = z.infer<typeof feedPostInsertSchema>
export type FeedPostReaction = z.infer<typeof feedPostReactionSelectSchema>
export type FeedPostDraft = z.infer<typeof feedPostDraftSelectSchema>
