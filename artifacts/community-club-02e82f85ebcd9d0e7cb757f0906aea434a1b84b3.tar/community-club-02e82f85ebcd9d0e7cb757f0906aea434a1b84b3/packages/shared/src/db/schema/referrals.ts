import { numeric, pgTable, serial, text, timestamp, uuid } from 'drizzle-orm/pg-core'
import { createSelectSchema } from 'drizzle-zod'
import type { z } from 'zod'
import { users } from './users'

export const referrals = pgTable('referrals', {
	id: serial('id').primaryKey(),
	referrerUuid: uuid('referrer_uuid')
		.references(() => users.authUuid)
		.notNull(),
	referredUuid: uuid('referred_uuid')
		.references(() => users.authUuid)
		.notNull(),
	status: text('status', { enum: ['pending', 'paid', 'bonus_credited'] })
		.default('pending')
		.notNull(),
	bonusAmount: numeric('bonus_amount'),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
})

export const referralSelectSchema = createSelectSchema(referrals)
export type Referral = z.infer<typeof referralSelectSchema>
