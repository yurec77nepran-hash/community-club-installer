import { relations } from 'drizzle-orm'
import { channelPosts, channelReactions } from './channels'
import {
	chatMembers,
	chatNotificationSettings,
	chats,
	messageMentions,
	messageReactions,
	messages,
} from './chats'
import { feedPostDrafts, feedPostReactions, feedPosts } from './feed'
import { materialCommentReactions, materialComments } from './material-comments'
import { materialFavorites } from './material-favorites'
import { materials } from './materials'
import { payments } from './payments'
import { pushCampaignRuns, pushCampaigns } from './push-campaigns'
import { pushNotifications } from './push-notifications'
import { pushSubscriptions } from './push-subscriptions'
import { referrals } from './referrals'
import { scheduledChatMessages } from './scheduled-chat-messages'
import {
	telegramBroadcastDeliveries,
	telegramBroadcasts,
	telegramContacts,
} from './telegram-broadcasts'
import { users } from './users'

// Users relations
export const usersRelations = relations(users, ({ one, many }) => ({
	payment: one(payments, {
		fields: [users.authUuid],
		references: [payments.userAuthUuid],
	}),
	messages: many(messages),
	chatMemberships: many(chatMembers),
	chatNotificationSettings: many(chatNotificationSettings),
	pushSubscriptions: many(pushSubscriptions),
	pushNotifications: many(pushNotifications),
	pushCampaigns: many(pushCampaigns),
	materialComments: many(materialComments),
	materialCommentReactions: many(materialCommentReactions),
	materialFavorites: many(materialFavorites),
	feedPosts: many(feedPosts),
	feedPostDrafts: many(feedPostDrafts),
	feedPostReactions: many(feedPostReactions),
	scheduledChatMessages: many(scheduledChatMessages),
	telegramContacts: many(telegramContacts),
	telegramBroadcasts: many(telegramBroadcasts),
}))

export const telegramContactsRelations = relations(telegramContacts, ({ one, many }) => ({
	user: one(users, {
		fields: [telegramContacts.userAuthUuid],
		references: [users.authUuid],
	}),
	deliveries: many(telegramBroadcastDeliveries),
}))

export const telegramBroadcastsRelations = relations(telegramBroadcasts, ({ one, many }) => ({
	createdBy: one(users, {
		fields: [telegramBroadcasts.createdByAuthUuid],
		references: [users.authUuid],
	}),
	deliveries: many(telegramBroadcastDeliveries),
}))

export const telegramBroadcastDeliveriesRelations = relations(
	telegramBroadcastDeliveries,
	({ one }) => ({
		broadcast: one(telegramBroadcasts, {
			fields: [telegramBroadcastDeliveries.broadcastId],
			references: [telegramBroadcasts.id],
		}),
		contact: one(telegramContacts, {
			fields: [telegramBroadcastDeliveries.contactId],
			references: [telegramContacts.id],
		}),
	}),
)

// Payments relations
export const paymentsRelations = relations(payments, ({ one }) => ({
	user: one(users, {
		fields: [payments.userAuthUuid],
		references: [users.authUuid],
	}),
}))

// Chats relations
export const chatsRelations = relations(chats, ({ many }) => ({
	messages: many(messages),
	members: many(chatMembers),
	notificationSettings: many(chatNotificationSettings),
	scheduledMessages: many(scheduledChatMessages),
}))

export const scheduledChatMessagesRelations = relations(scheduledChatMessages, ({ one }) => ({
	chat: one(chats, {
		fields: [scheduledChatMessages.chatId],
		references: [chats.id],
	}),
	author: one(users, {
		fields: [scheduledChatMessages.authorAuthUuid],
		references: [users.authUuid],
	}),
}))

// Messages relations
export const messagesRelations = relations(messages, ({ one, many }) => ({
	chat: one(chats, {
		fields: [messages.chatId],
		references: [chats.id],
	}),
	author: one(users, {
		fields: [messages.userAuthUuid],
		references: [users.authUuid],
	}),
	reactions: many(messageReactions),
	mentions: many(messageMentions),
	replyTo: one(messages, {
		fields: [messages.replyToId],
		references: [messages.id],
		relationName: 'replies',
	}),
}))

export const messageMentionsRelations = relations(messageMentions, ({ one }) => ({
	message: one(messages, {
		fields: [messageMentions.messageId],
		references: [messages.id],
	}),
	user: one(users, {
		fields: [messageMentions.mentionedUserAuthUuid],
		references: [users.authUuid],
	}),
}))

// Message reactions relations
export const messageReactionsRelations = relations(messageReactions, ({ one }) => ({
	message: one(messages, {
		fields: [messageReactions.messageId],
		references: [messages.id],
	}),
	user: one(users, {
		fields: [messageReactions.userAuthUuid],
		references: [users.authUuid],
	}),
}))

// Chat members relations
export const chatMembersRelations = relations(chatMembers, ({ one }) => ({
	chat: one(chats, {
		fields: [chatMembers.chatId],
		references: [chats.id],
	}),
	user: one(users, {
		fields: [chatMembers.userAuthUuid],
		references: [users.authUuid],
	}),
}))

export const chatNotificationSettingsRelations = relations(chatNotificationSettings, ({ one }) => ({
	chat: one(chats, {
		fields: [chatNotificationSettings.chatId],
		references: [chats.id],
	}),
	user: one(users, {
		fields: [chatNotificationSettings.userAuthUuid],
		references: [users.authUuid],
	}),
}))

// Channel posts relations
export const channelPostsRelations = relations(channelPosts, ({ one, many }) => ({
	author: one(users, {
		fields: [channelPosts.authorAuthUuid],
		references: [users.authUuid],
	}),
	reactions: many(channelReactions),
}))

// Channel reactions relations
export const channelReactionsRelations = relations(channelReactions, ({ one }) => ({
	post: one(channelPosts, {
		fields: [channelReactions.postId],
		references: [channelPosts.id],
	}),
	user: one(users, {
		fields: [channelReactions.userAuthUuid],
		references: [users.authUuid],
	}),
}))

export const materialsRelations = relations(materials, ({ many }) => ({
	comments: many(materialComments),
	favorites: many(materialFavorites),
}))

export const materialFavoritesRelations = relations(materialFavorites, ({ one }) => ({
	material: one(materials, {
		fields: [materialFavorites.materialId],
		references: [materials.id],
	}),
	user: one(users, {
		fields: [materialFavorites.userAuthUuid],
		references: [users.authUuid],
	}),
}))

export const materialCommentsRelations = relations(materialComments, ({ one, many }) => ({
	material: one(materials, {
		fields: [materialComments.materialId],
		references: [materials.id],
	}),
	author: one(users, {
		fields: [materialComments.userAuthUuid],
		references: [users.authUuid],
	}),
	parent: one(materialComments, {
		fields: [materialComments.parentCommentId],
		references: [materialComments.id],
		relationName: 'material_comment_replies',
	}),
	replies: many(materialComments, {
		relationName: 'material_comment_replies',
	}),
	reactions: many(materialCommentReactions),
}))

export const materialCommentReactionsRelations = relations(materialCommentReactions, ({ one }) => ({
	comment: one(materialComments, {
		fields: [materialCommentReactions.commentId],
		references: [materialComments.id],
	}),
	user: one(users, {
		fields: [materialCommentReactions.userAuthUuid],
		references: [users.authUuid],
	}),
}))

export const feedPostsRelations = relations(feedPosts, ({ one, many }) => ({
	author: one(users, {
		fields: [feedPosts.authorAuthUuid],
		references: [users.authUuid],
	}),
	reactions: many(feedPostReactions),
}))

export const feedPostDraftsRelations = relations(feedPostDrafts, ({ one }) => ({
	author: one(users, {
		fields: [feedPostDrafts.authorAuthUuid],
		references: [users.authUuid],
	}),
}))

export const feedPostReactionsRelations = relations(feedPostReactions, ({ one }) => ({
	post: one(feedPosts, {
		fields: [feedPostReactions.postId],
		references: [feedPosts.id],
	}),
	user: one(users, {
		fields: [feedPostReactions.userAuthUuid],
		references: [users.authUuid],
	}),
}))

// Push subscriptions relations
export const pushSubscriptionsRelations = relations(pushSubscriptions, ({ one }) => ({
	user: one(users, {
		fields: [pushSubscriptions.userAuthUuid],
		references: [users.authUuid],
	}),
}))

export const pushNotificationsRelations = relations(pushNotifications, ({ one }) => ({
	user: one(users, {
		fields: [pushNotifications.userAuthUuid],
		references: [users.authUuid],
	}),
}))

export const pushCampaignsRelations = relations(pushCampaigns, ({ one, many }) => ({
	createdBy: one(users, {
		fields: [pushCampaigns.createdByAuthUuid],
		references: [users.authUuid],
	}),
	runs: many(pushCampaignRuns),
}))

export const pushCampaignRunsRelations = relations(pushCampaignRuns, ({ one }) => ({
	campaign: one(pushCampaigns, {
		fields: [pushCampaignRuns.campaignId],
		references: [pushCampaigns.id],
	}),
}))

// Referrals relations
export const referralsRelations = relations(referrals, ({ one }) => ({
	referrer: one(users, {
		fields: [referrals.referrerUuid],
		references: [users.authUuid],
		relationName: 'referrer',
	}),
	referred: one(users, {
		fields: [referrals.referredUuid],
		references: [users.authUuid],
		relationName: 'referred',
	}),
}))
