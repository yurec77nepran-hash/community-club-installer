import { sql } from 'drizzle-orm'
import {
	bigint,
	bigserial,
	boolean,
	index,
	integer,
	jsonb,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

type ChatSettings = {
	allowMemberMessages?: boolean
	allowAttachments?: boolean
	allowReactions?: boolean
	slowModeSeconds?: number
	welcomeText?: string | null
}

// Чаты
export const chats = pgTable('chats', {
	id: serial('id').primaryKey(),
	slug: text('slug').unique().notNull(),
	name: text('name').notNull(),
	type: text('type', { enum: ['chat', 'channel'] })
		.default('chat')
		.notNull(),
	accessRole: text('access_role', { enum: ['all'] }).notNull(),
	isEnabled: boolean('is_enabled').default(true).notNull(),
	avatarUrl: text('avatar_url'),
	description: text('description'),
	settings: jsonb('settings').$type<ChatSettings>().default(sql`'{}'::jsonb`).notNull(),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

// Сообщения
export const messages = pgTable(
	'messages',
	{
		id: bigserial('id', { mode: 'number' }).primaryKey(),
		chatId: integer('chat_id')
			.references(() => chats.id)
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		content: text('content'),
		replyToId: bigint('reply_to_id', { mode: 'number' }),
		clientMessageId: text('client_message_id'),
		messageType: text('message_type', {
			enum: ['text', 'image', 'video', 'voice', 'audio', 'document', 'link'],
		})
			.default('text')
			.notNull(),
		attachmentUrl: text('attachment_url'),
		attachmentName: text('attachment_name'),
		attachmentSize: bigint('attachment_size', { mode: 'number' }),
		linkPreview: jsonb('link_preview').$type<{
			title?: string
			description?: string
			image?: string
			url?: string
		}>(),
		isDeleted: boolean('is_deleted').default(false).notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('messages_chat_id_id_idx').on(table.chatId, table.id),
		index('messages_chat_id_deleted_id_idx').on(table.chatId, table.isDeleted, table.id),
		index('messages_user_client_message_idx').on(table.userAuthUuid, table.clientMessageId),
	],
)

// Реакции на сообщения
export const messageReactions = pgTable(
	'message_reactions',
	{
		id: serial('id').primaryKey(),
		messageId: bigint('message_id', { mode: 'number' })
			.references(() => messages.id, { onDelete: 'cascade' })
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		emoji: text('emoji').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('msg_reaction_unique').on(table.messageId, table.userAuthUuid, table.emoji),
		index('message_reactions_message_id_idx').on(table.messageId),
	],
)

// Участники чатов
export const chatMembers = pgTable(
	'chat_members',
	{
		id: serial('id').primaryKey(),
		chatId: integer('chat_id')
			.references(() => chats.id)
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		role: text('role', { enum: ['member', 'admin', 'superadmin'] })
			.default('member')
			.notNull(),
		status: text('status', { enum: ['active', 'muted', 'banned'] })
			.default('active')
			.notNull(),
		statusLabel: text('status_label'),
		mutedUntil: timestamp('muted_until', { withTimezone: true }),
		lastReadMessageId: bigint('last_read_message_id', { mode: 'number' }),
		unreadMessageCount: integer('unread_message_count').default(0).notNull(),
		unreadMentionCount: integer('unread_mention_count').default(0).notNull(),
		joinedAt: timestamp('joined_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('chat_member_unique').on(table.chatId, table.userAuthUuid),
		index('chat_members_chat_id_role_idx').on(table.chatId, table.role),
	],
)

export const chatNotificationSettings = pgTable(
	'chat_notification_settings',
	{
		id: serial('id').primaryKey(),
		chatId: integer('chat_id')
			.references(() => chats.id, { onDelete: 'cascade' })
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid, { onDelete: 'cascade' })
			.notNull(),
		isEnabled: boolean('is_enabled').default(true).notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('chat_notification_settings_user_chat_unique').on(table.userAuthUuid, table.chatId),
		index('chat_notification_settings_chat_enabled_idx').on(table.chatId, table.isEnabled),
		index('chat_notification_settings_user_idx').on(table.userAuthUuid),
	],
)

export const messageMentions = pgTable(
	'message_mentions',
	{
		id: serial('id').primaryKey(),
		messageId: bigint('message_id', { mode: 'number' })
			.references(() => messages.id, { onDelete: 'cascade' })
			.notNull(),
		mentionedUserAuthUuid: uuid('mentioned_user_auth_uuid')
			.references(() => users.authUuid, { onDelete: 'cascade' })
			.notNull(),
		displayName: text('display_name').notNull(),
		startOffset: integer('start_offset').notNull(),
		endOffset: integer('end_offset').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('message_mention_unique').on(
			table.messageId,
			table.mentionedUserAuthUuid,
			table.startOffset,
			table.endOffset,
		),
		index('message_mentions_message_id_idx').on(table.messageId),
		index('message_mentions_user_idx').on(table.mentionedUserAuthUuid, table.messageId),
	],
)

// Схемы
export const chatSelectSchema = createSelectSchema(chats)
export const messageSelectSchema = createSelectSchema(messages)
export const messageInsertSchema = createInsertSchema(messages, {
	content: z.string().max(4000).optional(),
})
export const chatMemberSelectSchema = createSelectSchema(chatMembers)
export const chatNotificationSettingsSelectSchema = createSelectSchema(chatNotificationSettings)
export const messageMentionSelectSchema = createSelectSchema(messageMentions)

export type Chat = z.infer<typeof chatSelectSchema>
export type Message = z.infer<typeof messageSelectSchema>
export type NewMessage = z.infer<typeof messageInsertSchema>
export type ChatMember = z.infer<typeof chatMemberSelectSchema>
export type ChatNotificationSettings = z.infer<typeof chatNotificationSettingsSelectSchema>
export type MessageMention = z.infer<typeof messageMentionSelectSchema>
