import { pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const events = pgTable('events', {
	id: serial('id').primaryKey(),
	title: text('title').notNull(),
	description: text('description'),
	imageUrl: text('image_url'),
	eventDate: timestamp('event_date', { withTimezone: true }).notNull(),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
})

export const eventSelectSchema = createSelectSchema(events)
export const eventInsertSchema = createInsertSchema(events, {
	title: z.string().min(1).max(300),
})

export type Event = z.infer<typeof eventSelectSchema>
export type NewEvent = z.infer<typeof eventInsertSchema>
