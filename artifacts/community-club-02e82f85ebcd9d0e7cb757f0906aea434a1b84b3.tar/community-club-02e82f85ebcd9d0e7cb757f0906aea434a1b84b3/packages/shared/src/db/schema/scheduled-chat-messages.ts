import {
	bigint,
	index,
	integer,
	jsonb,
	pgTable,
	serial,
	text,
	timestamp,
	uuid,
} from 'drizzle-orm/pg-core'
import { chats } from './chats'
import { users } from './users'

export const scheduledChatMessages = pgTable(
	'scheduled_chat_messages',
	{
		id: serial('id').primaryKey(),
		chatId: integer('chat_id')
			.references(() => chats.id, { onDelete: 'cascade' })
			.notNull(),
		authorAuthUuid: uuid('author_auth_uuid')
			.references(() => users.authUuid, { onDelete: 'cascade' })
			.notNull(),
		content: text('content').notNull(),
		mentions: jsonb('mentions')
			.$type<
				Array<{
					userAuthUuid: string
					displayName: string
					start: number
					end: number
				}>
			>()
			.default([]),
		scheduledAt: timestamp('scheduled_at', { withTimezone: true }).notNull(),
		status: text('status', {
			enum: ['scheduled', 'processing', 'sent', 'cancelled', 'failed'],
		})
			.default('scheduled')
			.notNull(),
		errorMessage: text('error_message'),
		sentMessageId: bigint('sent_message_id', { mode: 'number' }),
		processingStartedAt: timestamp('processing_started_at', { withTimezone: true }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('scheduled_chat_messages_chat_scheduled_idx').on(
			table.chatId,
			table.status,
			table.scheduledAt,
		),
		index('scheduled_chat_messages_due_idx').on(table.status, table.scheduledAt),
		index('scheduled_chat_messages_author_idx').on(table.authorAuthUuid, table.createdAt),
	],
)
