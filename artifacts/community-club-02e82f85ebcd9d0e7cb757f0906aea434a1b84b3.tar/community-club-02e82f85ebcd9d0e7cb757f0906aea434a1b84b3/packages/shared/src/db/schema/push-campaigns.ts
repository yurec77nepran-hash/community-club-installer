import {
	boolean,
	date,
	index,
	integer,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { safeNavigationUrlSchema } from '../../validators/common'
import { users } from './users'

export const pushCampaigns = pgTable(
	'push_campaigns',
	{
		id: serial('id').primaryKey(),
		name: text('name').notNull(),
		kind: text('kind', { enum: ['one_time', 'billing_relative'] }).notNull(),
		status: text('status', {
			enum: ['draft', 'scheduled', 'active', 'paused', 'processing', 'completed', 'failed'],
		})
			.default('draft')
			.notNull(),
		audience: text('audience', {
			enum: ['all', 'active'],
		})
			.default('all')
			.notNull(),
		title: text('title').notNull(),
		body: text('body').notNull(),
		url: text('url'),
		offsetDays: integer('offset_days').array().default([]).notNull(),
		sendAt: timestamp('send_at', { withTimezone: true }),
		isEnabled: boolean('is_enabled').default(true).notNull(),
		lastRunAt: timestamp('last_run_at', { withTimezone: true }),
		processingStartedAt: timestamp('processing_started_at', { withTimezone: true }),
		lastRunSent: integer('last_run_sent').default(0).notNull(),
		lastRunFailed: integer('last_run_failed').default(0).notNull(),
		lastRunAudienceSize: integer('last_run_audience_size').default(0).notNull(),
		lastError: text('last_error'),
		createdByAuthUuid: uuid('created_by_auth_uuid').references(() => users.authUuid),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		kindStatusIdx: index('push_campaigns_kind_status_idx').on(table.kind, table.status),
		enabledIdx: index('push_campaigns_enabled_idx').on(table.isEnabled, table.kind),
		sendAtIdx: index('push_campaigns_send_at_idx').on(table.sendAt),
	}),
)

export const pushCampaignRuns = pgTable(
	'push_campaign_runs',
	{
		id: serial('id').primaryKey(),
		campaignId: integer('campaign_id')
			.references(() => pushCampaigns.id, { onDelete: 'cascade' })
			.notNull(),
		runKey: text('run_key').notNull(),
		scheduledFor: date('scheduled_for').notNull(),
		offsetDays: integer('offset_days'),
		status: text('status', { enum: ['processing', 'completed', 'failed'] })
			.default('processing')
			.notNull(),
		audienceSize: integer('audience_size').default(0).notNull(),
		subscriptionCount: integer('subscription_count').default(0).notNull(),
		sentCount: integer('sent_count').default(0).notNull(),
		failedCount: integer('failed_count').default(0).notNull(),
		errorMessage: text('error_message'),
		startedAt: timestamp('started_at', { withTimezone: true }).defaultNow().notNull(),
		completedAt: timestamp('completed_at', { withTimezone: true }),
	},
	(table) => ({
		campaignRunUnique: uniqueIndex('push_campaign_runs_unique').on(table.campaignId, table.runKey),
		campaignRunIdx: index('push_campaign_runs_campaign_idx').on(table.campaignId, table.startedAt),
	}),
)

export const pushCampaignSelectSchema = createSelectSchema(pushCampaigns)
export const pushCampaignInsertSchema = createInsertSchema(pushCampaigns, {
	name: z.string().min(1).max(120),
	title: z.string().min(1).max(120),
	body: z.string().min(1).max(2000),
	url: safeNavigationUrlSchema.nullable().optional(),
	offsetDays: z.array(z.number().int().min(-30).max(30)).max(16),
})

export const pushCampaignRunSelectSchema = createSelectSchema(pushCampaignRuns)
export const pushCampaignRunInsertSchema = createInsertSchema(pushCampaignRuns)

export type PushCampaign = z.infer<typeof pushCampaignSelectSchema>
export type NewPushCampaign = z.infer<typeof pushCampaignInsertSchema>
export type PushCampaignRun = z.infer<typeof pushCampaignRunSelectSchema>
export type NewPushCampaignRun = z.infer<typeof pushCampaignRunInsertSchema>
