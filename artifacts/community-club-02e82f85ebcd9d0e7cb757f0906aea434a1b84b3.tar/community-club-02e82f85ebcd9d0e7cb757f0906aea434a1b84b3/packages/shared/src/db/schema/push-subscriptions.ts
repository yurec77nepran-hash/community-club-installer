import {
	index,
	integer,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { httpsUrlSchema } from '../../validators/common'
import { users } from './users'

export const pushSubscriptions = pgTable(
	'push_subscriptions',
	{
		id: serial('id').primaryKey(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		endpoint: text('endpoint').notNull(),
		p256dh: text('p256dh').notNull(),
		auth: text('auth').notNull(),
		userAgent: text('user_agent'),
		platform: text('platform'),
		deviceLabel: text('device_label'),
		permission: text('permission'),
		expirationTime: timestamp('expiration_time', { withTimezone: true }),
		lastSeenAt: timestamp('last_seen_at', { withTimezone: true }).defaultNow().notNull(),
		lastSuccessAt: timestamp('last_success_at', { withTimezone: true }),
		lastFailureAt: timestamp('last_failure_at', { withTimezone: true }),
		failureCount: integer('failure_count').default(0).notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('push_subscriptions_endpoint_unique').on(table.endpoint),
		index('push_subscriptions_user_last_seen_idx').on(table.userAuthUuid, table.lastSeenAt),
	],
)

export const pushSubscriptionSelectSchema = createSelectSchema(pushSubscriptions)
export const pushSubscriptionInsertSchema = createInsertSchema(pushSubscriptions, {
	endpoint: httpsUrlSchema,
	p256dh: z.string().min(1),
	auth: z.string().min(1),
})

export type PushSubscription = z.infer<typeof pushSubscriptionSelectSchema>
export type NewPushSubscription = z.infer<typeof pushSubscriptionInsertSchema>
