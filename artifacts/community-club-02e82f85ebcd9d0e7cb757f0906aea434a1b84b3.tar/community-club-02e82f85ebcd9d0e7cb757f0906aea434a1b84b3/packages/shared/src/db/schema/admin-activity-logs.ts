import { bigserial, index, jsonb, pgTable, text, timestamp, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

export const adminActivityLogs = pgTable(
	'admin_activity_logs',
	{
		id: bigserial('id', { mode: 'number' }).primaryKey(),
		actorAuthUuid: uuid('actor_auth_uuid').references(() => users.authUuid, {
			onDelete: 'set null',
		}),
		actorName: text('actor_name'),
		actorEmail: text('actor_email'),
		action: text('action').notNull(),
		entityType: text('entity_type').notNull(),
		entityId: text('entity_id'),
		summary: text('summary').notNull(),
		details: jsonb('details').$type<Record<string, unknown> | null>().default(null),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('admin_activity_logs_created_idx').on(table.createdAt),
		index('admin_activity_logs_actor_idx').on(table.actorAuthUuid),
		index('admin_activity_logs_entity_idx').on(table.entityType, table.entityId),
	],
)

export const adminActivityLogsSelectSchema = createSelectSchema(adminActivityLogs)
export const adminActivityLogsInsertSchema = createInsertSchema(adminActivityLogs, {
	action: z.string().trim().min(1).max(80),
	entityType: z.string().trim().min(1).max(80),
	entityId: z.string().trim().max(255).nullable().optional(),
	summary: z.string().trim().min(1).max(500),
})

export type AdminActivityLog = z.infer<typeof adminActivityLogsSelectSchema>
export type NewAdminActivityLog = z.infer<typeof adminActivityLogsInsertSchema>
