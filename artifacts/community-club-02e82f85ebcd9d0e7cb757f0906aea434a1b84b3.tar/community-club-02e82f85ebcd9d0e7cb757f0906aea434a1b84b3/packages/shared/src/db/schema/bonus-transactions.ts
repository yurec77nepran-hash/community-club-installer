import { index, integer, pgTable, serial, text, timestamp, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

export const bonusTransactions = pgTable(
	'bonus_transactions',
	{
		id: serial('id').primaryKey(),
		userAuthUuid: uuid('user_auth_uuid')
			.notNull()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		amount: integer('amount').notNull(),
		source: text('source').notNull(),
		description: text('description').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('bonus_transactions_user_created_idx').on(table.userAuthUuid, table.createdAt),
		index('bonus_transactions_source_idx').on(table.source),
	],
)

export const bonusTransactionsSelectSchema = createSelectSchema(bonusTransactions)
export const bonusTransactionsInsertSchema = createInsertSchema(bonusTransactions, {
	amount: z.number().int(),
	source: z.string().trim().min(1).max(80),
	description: z.string().trim().min(1).max(255),
})

export type BonusTransaction = z.infer<typeof bonusTransactionsSelectSchema>
export type NewBonusTransaction = z.infer<typeof bonusTransactionsInsertSchema>
