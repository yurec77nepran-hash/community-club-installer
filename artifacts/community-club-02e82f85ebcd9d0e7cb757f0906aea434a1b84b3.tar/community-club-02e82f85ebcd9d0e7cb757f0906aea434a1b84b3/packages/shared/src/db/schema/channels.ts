import {
	bigint,
	bigserial,
	boolean,
	jsonb,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

export const channelPosts = pgTable('channel_posts', {
	id: bigserial('id', { mode: 'number' }).primaryKey(),
	authorAuthUuid: uuid('author_auth_uuid')
		.references(() => users.authUuid)
		.notNull(),
	content: text('content').notNull(),
	attachments: jsonb('attachments')
		.$type<Array<{ type: string; url: string; name: string; size: number }>>()
		.default([]),
	isPinned: boolean('is_pinned').default(false).notNull(),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

export const channelReactions = pgTable(
	'channel_reactions',
	{
		id: serial('id').primaryKey(),
		postId: bigint('post_id', { mode: 'number' })
			.references(() => channelPosts.id, { onDelete: 'cascade' })
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid)
			.notNull(),
		emoji: text('emoji').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('channel_reaction_unique').on(table.postId, table.userAuthUuid, table.emoji),
	],
)

export const channelPostSelectSchema = createSelectSchema(channelPosts)
export const channelPostInsertSchema = createInsertSchema(channelPosts, {
	content: z.string().min(1).max(10000),
})

export type ChannelPost = z.infer<typeof channelPostSelectSchema>
export type NewChannelPost = z.infer<typeof channelPostInsertSchema>
