import {
	integer,
	jsonb,
	numeric,
	pgTable,
	serial,
	text,
	timestamp,
	uuid,
} from 'drizzle-orm/pg-core'
import { createSelectSchema } from 'drizzle-zod'
import type { z } from 'zod'

export const paymentLogs = pgTable('payment_logs', {
	id: serial('id').primaryKey(),
	event: text('event').notNull(),
	userAuthUuid: uuid('user_auth_uuid'),
	email: text('email'),
	phone: text('phone'),
	subscriptionId: text('subscription_id'),
	orderId: text('order_id'),
	amount: numeric('amount'),
	tariff: text('tariff'),
	status: text('status'),
	errorMessage: text('error_message'),
	rawData: jsonb('raw_data'),
	webhookType: text('webhook_type'),
	idempotencyKey: text('idempotency_key').unique(),
	paymentDate: timestamp('payment_date', { withTimezone: true }),
	nextPaymentDate: timestamp('next_payment_date', { withTimezone: true }),
	processingTimeMs: integer('processing_time_ms'),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
})

export const paymentLogSelectSchema = createSelectSchema(paymentLogs)
export type PaymentLog = z.infer<typeof paymentLogSelectSchema>
