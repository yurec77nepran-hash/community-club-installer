import {
	index,
	integer,
	jsonb,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import type {
	TelegramBroadcastButton,
	TelegramBroadcastMedia,
} from '../../utils/telegram-broadcast-content'
import { users } from './users'

export const telegramContacts = pgTable(
	'telegram_contacts',
	{
		id: serial('id').primaryKey(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid, { onDelete: 'cascade' })
			.notNull(),
		botUsername: text('bot_username').notNull(),
		telegramUserId: text('telegram_user_id').notNull(),
		telegramUsername: text('telegram_username'),
		sourceCreatedAt: timestamp('source_created_at', { withTimezone: true }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		botUserUnique: uniqueIndex('telegram_contacts_bot_user_unique').on(
			table.botUsername,
			table.telegramUserId,
		),
		userIdx: index('telegram_contacts_user_idx').on(table.userAuthUuid),
		telegramUserIdx: index('telegram_contacts_telegram_user_idx').on(table.telegramUserId),
	}),
)

export const telegramBroadcasts = pgTable(
	'telegram_broadcasts',
	{
		id: serial('id').primaryKey(),
		name: text('name').notNull(),
		botUsername: text('bot_username').notNull(),
		botUsernames: text('bot_usernames').array().notNull(),
		deliveryMode: text('delivery_mode', { enum: ['all', 'unique'] })
			.default('all')
			.notNull(),
		preferredBotUsername: text('preferred_bot_username'),
		body: text('body').notNull(),
		buttons: jsonb('buttons').$type<TelegramBroadcastButton[]>().default([]).notNull(),
		media: jsonb('media').$type<TelegramBroadcastMedia | null>(),
		status: text('status', {
			enum: ['scheduled', 'processing', 'paused', 'completed', 'failed', 'cancelled'],
		})
			.default('scheduled')
			.notNull(),
		sendAt: timestamp('send_at', { withTimezone: true }).notNull(),
		processingStartedAt: timestamp('processing_started_at', { withTimezone: true }),
		audienceSize: integer('audience_size').default(0).notNull(),
		sentCount: integer('sent_count').default(0).notNull(),
		failedCount: integer('failed_count').default(0).notNull(),
		lastError: text('last_error'),
		createdByAuthUuid: uuid('created_by_auth_uuid').references(() => users.authUuid),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		statusSendAtIdx: index('telegram_broadcasts_status_send_at_idx').on(table.status, table.sendAt),
	}),
)

export const telegramBroadcastDeliveries = pgTable(
	'telegram_broadcast_deliveries',
	{
		id: serial('id').primaryKey(),
		broadcastId: integer('broadcast_id')
			.references(() => telegramBroadcasts.id, { onDelete: 'cascade' })
			.notNull(),
		contactId: integer('contact_id')
			.references(() => telegramContacts.id, { onDelete: 'cascade' })
			.notNull(),
		status: text('status', { enum: ['pending', 'processing', 'sent', 'failed'] })
			.default('pending')
			.notNull(),
		errorMessage: text('error_message'),
		sentAt: timestamp('sent_at', { withTimezone: true }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		broadcastContactUnique: uniqueIndex('telegram_broadcast_deliveries_unique').on(
			table.broadcastId,
			table.contactId,
		),
		broadcastStatusIdx: index('telegram_broadcast_deliveries_status_idx').on(
			table.broadcastId,
			table.status,
		),
	}),
)
