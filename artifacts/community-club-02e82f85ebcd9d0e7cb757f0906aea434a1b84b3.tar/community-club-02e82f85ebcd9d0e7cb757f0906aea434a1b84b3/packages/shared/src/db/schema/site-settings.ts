import { pgTable, text, timestamp } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const siteSettings = pgTable('site_settings', {
	key: text('key').primaryKey(),
	value: text('value').notNull().default(''),
	updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

export const siteSettingsSelectSchema = createSelectSchema(siteSettings)
export const siteSettingsInsertSchema = createInsertSchema(siteSettings, {
	key: z.string().trim().min(1).max(120),
	value: z.string().max(2048).optional(),
})

export type SiteSettingsRow = z.infer<typeof siteSettingsSelectSchema>
export type NewSiteSettingsRow = z.infer<typeof siteSettingsInsertSchema>
