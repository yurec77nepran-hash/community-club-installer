import {
	index,
	integer,
	jsonb,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { users } from './users'

export const messengerProviders = ['telegram', 'vk', 'max'] as const
export type MessengerProvider = (typeof messengerProviders)[number]

export const messengerConnections = pgTable(
	'messenger_connections',
	{
		id: serial('id').primaryKey(),
		provider: text('provider', { enum: messengerProviders }).notNull(),
		externalId: text('external_id').notNull(),
		label: text('label').notNull(),
		encryptedToken: text('encrypted_token').notNull(),
		config: jsonb('config').$type<Record<string, string>>().default({}).notNull(),
		webhookSecret: text('webhook_secret'),
		isActive: integer('is_active').default(1).notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		providerExternalUnique: uniqueIndex('messenger_connections_provider_external_unique').on(
			table.provider,
			table.externalId,
		),
	}),
)

export const messengerContacts = pgTable(
	'messenger_contacts',
	{
		id: serial('id').primaryKey(),
		connectionId: integer('connection_id')
			.references(() => messengerConnections.id, { onDelete: 'cascade' })
			.notNull(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid, { onDelete: 'cascade' })
			.notNull(),
		externalUserId: text('external_user_id').notNull(),
		displayName: text('display_name'),
		username: text('username'),
		consentStatus: text('consent_status', { enum: ['active', 'revoked'] })
			.default('active')
			.notNull(),
		profile: jsonb('profile').$type<Record<string, unknown>>().default({}).notNull(),
		lastSeenAt: timestamp('last_seen_at', { withTimezone: true }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		connectionExternalUserUnique: uniqueIndex('messenger_contacts_connection_user_unique').on(
			table.connectionId,
			table.externalUserId,
		),
		userIdx: index('messenger_contacts_user_idx').on(table.userAuthUuid),
		activeIdx: index('messenger_contacts_active_idx').on(table.connectionId, table.consentStatus),
	}),
)

export const messengerBroadcasts = pgTable(
	'messenger_broadcasts',
	{
		id: serial('id').primaryKey(),
		name: text('name').notNull(),
		connectionIds: integer('connection_ids').array().notNull(),
		body: text('body').notNull(),
		status: text('status', {
			enum: ['scheduled', 'processing', 'paused', 'completed', 'failed', 'cancelled'],
		})
			.default('scheduled')
			.notNull(),
		sendAt: timestamp('send_at', { withTimezone: true }).notNull(),
		processingStartedAt: timestamp('processing_started_at', { withTimezone: true }),
		audienceSize: integer('audience_size').default(0).notNull(),
		sentCount: integer('sent_count').default(0).notNull(),
		failedCount: integer('failed_count').default(0).notNull(),
		lastError: text('last_error'),
		createdByAuthUuid: uuid('created_by_auth_uuid').references(() => users.authUuid, {
			onDelete: 'set null',
		}),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		statusSendAtIdx: index('messenger_broadcasts_status_send_at_idx').on(
			table.status,
			table.sendAt,
		),
	}),
)

export const messengerBroadcastDeliveries = pgTable(
	'messenger_broadcast_deliveries',
	{
		id: serial('id').primaryKey(),
		broadcastId: integer('broadcast_id')
			.references(() => messengerBroadcasts.id, { onDelete: 'cascade' })
			.notNull(),
		contactId: integer('contact_id')
			.references(() => messengerContacts.id, { onDelete: 'cascade' })
			.notNull(),
		status: text('status', { enum: ['pending', 'processing', 'sent', 'failed'] })
			.default('pending')
			.notNull(),
		errorMessage: text('error_message'),
		sentAt: timestamp('sent_at', { withTimezone: true }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => ({
		broadcastContactUnique: uniqueIndex('messenger_broadcast_deliveries_unique').on(
			table.broadcastId,
			table.contactId,
		),
		broadcastStatusIdx: index('messenger_broadcast_deliveries_status_idx').on(
			table.broadcastId,
			table.status,
		),
	}),
)
