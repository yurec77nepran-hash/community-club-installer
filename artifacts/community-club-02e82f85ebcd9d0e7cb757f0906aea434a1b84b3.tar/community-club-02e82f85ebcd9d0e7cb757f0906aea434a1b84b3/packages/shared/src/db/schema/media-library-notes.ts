import { index, integer, pgTable, text, timestamp, uniqueIndex, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { mediaLibraryFolders } from './media-library-folders'
import { users } from './users'

export const mediaLibraryNotes = pgTable(
	'media_library_notes',
	{
		key: text('key').primaryKey(),
		title: text('title').notNull().default(''),
		note: text('note').notNull().default(''),
		folderId: integer('folder_id').references(() => mediaLibraryFolders.id, {
			onDelete: 'set null',
		}),
		createdByAuthUuid: uuid('created_by_auth_uuid').references(() => users.authUuid),
		updatedByAuthUuid: uuid('updated_by_auth_uuid').references(() => users.authUuid),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('media_library_notes_updated_idx').on(table.updatedAt),
		uniqueIndex('media_library_notes_key_unique').on(table.key),
	],
)

export const mediaLibraryNoteSelectSchema = createSelectSchema(mediaLibraryNotes)
export const mediaLibraryNoteInsertSchema = createInsertSchema(mediaLibraryNotes, {
	key: z.string().min(1),
	title: z.string().max(255),
	note: z.string().max(2000),
})

export type MediaLibraryNote = z.infer<typeof mediaLibraryNoteSelectSchema>
export type NewMediaLibraryNote = z.infer<typeof mediaLibraryNoteInsertSchema>
