import { index, integer, pgTable, text, timestamp, uniqueIndex, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { mediaLibraryFolders } from './media-library-folders'
import { users } from './users'

export const mediaLibraryPreferences = pgTable(
	'media_library_preferences',
	{
		authUuid: uuid('auth_uuid')
			.primaryKey()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		viewMode: text('view_mode', { enum: ['cards', 'list'] })
			.notNull()
			.default('cards'),
		sortBy: text('sort_by', { enum: ['updatedAt', 'title', 'size', 'type'] })
			.notNull()
			.default('updatedAt'),
		sortDir: text('sort_dir', { enum: ['asc', 'desc'] })
			.notNull()
			.default('desc'),
		typeFilter: text('type_filter', {
			enum: ['all', 'image', 'video', 'audio', 'document'],
		})
			.notNull()
			.default('all'),
		searchQuery: text('search_query').notNull().default(''),
		folderId: integer('folder_id').references(() => mediaLibraryFolders.id, {
			onDelete: 'set null',
		}),
		pickerViewMode: text('picker_view_mode', { enum: ['cards', 'list'] })
			.notNull()
			.default('cards'),
		pickerSortBy: text('picker_sort_by', { enum: ['updatedAt', 'title', 'size', 'type'] })
			.notNull()
			.default('updatedAt'),
		pickerSortDir: text('picker_sort_dir', { enum: ['asc', 'desc'] })
			.notNull()
			.default('desc'),
		pickerTypeFilter: text('picker_type_filter', {
			enum: ['all', 'image', 'video', 'audio', 'document'],
		})
			.notNull()
			.default('all'),
		pickerSearchQuery: text('picker_search_query').notNull().default(''),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('media_library_preferences_updated_idx').on(table.updatedAt),
		uniqueIndex('media_library_preferences_auth_uuid_unique').on(table.authUuid),
	],
)

export const mediaLibraryPreferencesSelectSchema = createSelectSchema(mediaLibraryPreferences)
export const mediaLibraryPreferencesInsertSchema = createInsertSchema(mediaLibraryPreferences, {
	viewMode: z.enum(['cards', 'list']).optional(),
	sortBy: z.enum(['updatedAt', 'title', 'size', 'type']).optional(),
	sortDir: z.enum(['asc', 'desc']).optional(),
	typeFilter: z.enum(['all', 'image', 'video', 'audio', 'document']).optional(),
	searchQuery: z.string().max(200).optional(),
	pickerViewMode: z.enum(['cards', 'list']).optional(),
	pickerSortBy: z.enum(['updatedAt', 'title', 'size', 'type']).optional(),
	pickerSortDir: z.enum(['asc', 'desc']).optional(),
	pickerTypeFilter: z.enum(['all', 'image', 'video', 'audio', 'document']).optional(),
	pickerSearchQuery: z.string().max(200).optional(),
})

export type MediaLibraryPreferences = z.infer<typeof mediaLibraryPreferencesSelectSchema>
export type NewMediaLibraryPreferences = z.infer<typeof mediaLibraryPreferencesInsertSchema>
