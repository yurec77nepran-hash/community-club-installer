import {
	boolean,
	index,
	integer,
	pgTable,
	serial,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { materials } from './materials'
import { users } from './users'

export const materialMediaProgress = pgTable(
	'material_media_progress',
	{
		id: serial('id').primaryKey(),
		userAuthUuid: uuid('user_auth_uuid')
			.notNull()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		materialId: integer('material_id')
			.notNull()
			.references(() => materials.id, { onDelete: 'cascade' }),
		mediaFileIndex: integer('media_file_index').notNull().default(0),
		positionSeconds: integer('position_seconds').notNull().default(0),
		durationSeconds: integer('duration_seconds'),
		completed: boolean('completed').notNull().default(false),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('material_media_progress_user_material_unique').on(
			table.userAuthUuid,
			table.materialId,
			table.mediaFileIndex,
		),
		index('material_media_progress_user_updated_idx').on(table.userAuthUuid, table.updatedAt),
		index('material_media_progress_material_idx').on(table.materialId),
		index('material_media_progress_user_material_updated_idx').on(
			table.userAuthUuid,
			table.materialId,
			table.updatedAt,
		),
	],
)
