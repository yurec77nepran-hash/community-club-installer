import { integer, numeric, pgTable, text, timestamp } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import type { z } from 'zod'

export const pricingMatrix = pgTable('pricing_matrix', {
	role: text('role', { enum: ['club'] }).primaryKey(),
	demoFirstMonthPrice: numeric('demo_first_month_price').notNull(),
	demoDays: integer('demo_days').default(0).notNull(),
	activeMonthPrice: numeric('active_month_price').notNull(),
	formerMonthPrice: numeric('former_month_price').notNull(),
	externalFirstMonthPrice: numeric('external_first_month_price').notNull(),
	externalMonthPrice: numeric('external_month_price').notNull(),
	active90DaysPrice: numeric('active_90_days_price').notNull(),
	former90DaysPrice: numeric('former_90_days_price').notNull(),
	external90DaysPrice: numeric('external_90_days_price').notNull(),
	active365DaysPrice: numeric('active_365_days_price').notNull(),
	former365DaysPrice: numeric('former_365_days_price').notNull(),
	external365DaysPrice: numeric('external_365_days_price').notNull(),
	foreignDemoFirstMonthPrice: numeric('foreign_demo_first_month_price').notNull(),
	foreignActiveMonthPrice: numeric('foreign_active_month_price').notNull(),
	foreignFormerMonthPrice: numeric('foreign_former_month_price').notNull(),
	foreignExternalFirstMonthPrice: numeric('foreign_external_first_month_price').notNull(),
	foreignExternalMonthPrice: numeric('foreign_external_month_price').notNull(),
	foreignActive90DaysPrice: numeric('foreign_active_90_days_price').notNull(),
	foreignFormer90DaysPrice: numeric('foreign_former_90_days_price').notNull(),
	foreignExternal90DaysPrice: numeric('foreign_external_90_days_price').notNull(),
	foreignActive365DaysPrice: numeric('foreign_active_365_days_price').notNull(),
	foreignFormer365DaysPrice: numeric('foreign_former_365_days_price').notNull(),
	foreignExternal365DaysPrice: numeric('foreign_external_365_days_price').notNull(),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

export const pricingMatrixSelectSchema = createSelectSchema(pricingMatrix)
export const pricingMatrixInsertSchema = createInsertSchema(pricingMatrix)

export type PricingMatrix = z.infer<typeof pricingMatrixSelectSchema>
export type NewPricingMatrix = z.infer<typeof pricingMatrixInsertSchema>
