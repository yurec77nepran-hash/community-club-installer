import { index, pgTable, text, timestamp } from 'drizzle-orm/pg-core'

export const materialTypes = pgTable(
	'material_types',
	{
		key: text('key').primaryKey(),
		label: text('label').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [index('material_types_label_idx').on(table.label)],
)
