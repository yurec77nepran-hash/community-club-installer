import {
	bigint,
	boolean,
	index,
	integer,
	pgTable,
	serial,
	text,
	timestamp,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const mediaTypes = ['video', 'audio', 'image', 'text', 'document'] as const
export type MediaType = (typeof mediaTypes)[number]

export const materials = pgTable(
	'materials',
	{
		id: serial('id').primaryKey(),
		type: text('type').notNull(),
		title: text('title').notNull(),
		telegramPostUrl: text('telegram_post_url'),
		imageUrl: text('image_url'),
		videoCoverUrl: text('video_cover_url'),
		shortDescription: text('short_description'),
		fullDescription: text('full_description'),
		subsection: text('subsection'),
		active: boolean('active').default(true).notNull(),
		commentsEnabled: boolean('comments_enabled').default(false).notNull(),
		// Медиаконтент (новые поля для PWA)
		mediaType: text('media_type', { enum: mediaTypes }),
		storagePath: text('storage_path'),
		durationSeconds: integer('duration_seconds'),
		fileSizeBytes: bigint('file_size_bytes', { mode: 'number' }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('materials_active_type_created_idx').on(table.active, table.type, table.createdAt),
		index('materials_active_created_id_idx').on(table.active, table.createdAt, table.id),
		index('materials_active_type_subsection_created_idx').on(
			table.active,
			table.type,
			table.subsection,
			table.createdAt,
		),
	],
)

export const materialSelectSchema = createSelectSchema(materials)
export const materialInsertSchema = createInsertSchema(materials, {
	title: z.string().min(1).max(500),
	type: z.string().min(1),
})

export type Material = z.infer<typeof materialSelectSchema>
export type NewMaterial = z.infer<typeof materialInsertSchema>
