import { bigserial, index, pgTable, text, timestamp, uniqueIndex, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

export const mediaLibraryFolders = pgTable(
	'media_library_folders',
	{
		id: bigserial('id', { mode: 'number' }).primaryKey(),
		name: text('name').notNull(),
		createdByAuthUuid: uuid('created_by_auth_uuid').references(() => users.authUuid),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('media_library_folders_name_unique').on(table.name),
		index('media_library_folders_created_idx').on(table.createdAt),
	],
)

export const mediaLibraryFolderSelectSchema = createSelectSchema(mediaLibraryFolders)
export const mediaLibraryFolderInsertSchema = createInsertSchema(mediaLibraryFolders, {
	name: z.string().trim().min(1).max(120),
})

export type MediaLibraryFolder = z.infer<typeof mediaLibraryFolderSelectSchema>
export type NewMediaLibraryFolder = z.infer<typeof mediaLibraryFolderInsertSchema>
