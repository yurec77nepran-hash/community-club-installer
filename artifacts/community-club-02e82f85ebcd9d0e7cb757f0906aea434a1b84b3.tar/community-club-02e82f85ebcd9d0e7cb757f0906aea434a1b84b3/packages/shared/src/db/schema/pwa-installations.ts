import { sql } from 'drizzle-orm'
import { check, integer, pgTable, text, timestamp, uuid } from 'drizzle-orm/pg-core'
import { users } from './users'

export const pwaInstallations = pgTable(
	'pwa_installations',
	{
		userAuthUuid: uuid('user_auth_uuid')
			.primaryKey()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		firstLaunchedAt: timestamp('first_launched_at', { withTimezone: true }).defaultNow().notNull(),
		lastLaunchedAt: timestamp('last_launched_at', { withTimezone: true }).defaultNow().notNull(),
		launchCount: integer('launch_count').default(1).notNull(),
		userAgent: text('user_agent'),
		platform: text('platform'),
		deviceLabel: text('device_label'),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [check('pwa_installations_launch_count_positive', sql`${table.launchCount} > 0`)],
)

export type PwaInstallation = typeof pwaInstallations.$inferSelect
export type NewPwaInstallation = typeof pwaInstallations.$inferInsert
