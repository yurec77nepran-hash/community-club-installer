import { index, integer, pgTable, serial, timestamp, uniqueIndex, uuid } from 'drizzle-orm/pg-core'
import { materials } from './materials'
import { users } from './users'

export const materialFavorites = pgTable(
	'material_favorites',
	{
		id: serial('id').primaryKey(),
		userAuthUuid: uuid('user_auth_uuid')
			.notNull()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		materialId: integer('material_id')
			.notNull()
			.references(() => materials.id, { onDelete: 'cascade' }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('material_favorites_user_material_unique').on(table.userAuthUuid, table.materialId),
		index('material_favorites_user_created_idx').on(table.userAuthUuid, table.createdAt),
		index('material_favorites_material_idx').on(table.materialId),
	],
)
