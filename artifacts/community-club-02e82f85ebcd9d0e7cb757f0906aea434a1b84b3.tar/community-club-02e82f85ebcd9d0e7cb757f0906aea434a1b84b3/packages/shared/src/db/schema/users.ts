import {
	bigserial,
	boolean,
	integer,
	jsonb,
	pgTable,
	text,
	timestamp,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const userRoles = ['user', 'admin', 'superadmin'] as const
export type UserRole = (typeof userRoles)[number]

export const users = pgTable('users', {
	id: bigserial('id', { mode: 'number' }).primaryKey(),
	authUuid: uuid('auth_uuid')
		.unique()
		.notNull()
		.$defaultFn(() => crypto.randomUUID()),
	email: text('email').unique(),
	phone: text('phone'),
	passwordHash: text('password_hash'),
	authType: text('auth_type', { enum: ['email', 'phone'] }),
	username: text('username').unique(),
	avatarUrl: text('avatar_url'),
	fullName: text('full_name'),
	firstName: text('first_name'),
	city: text('city'),
	socialAccount: text('social_account'),
	socialLinks: text('social_links').array(),
	telegramChatId: text('telegram_chat_id'),
	telegramUsername: text('telegram_username'),
	telegramNotificationsEnabled: boolean('telegram_notifications_enabled').default(false).notNull(),
	maxMessengerUserId: text('max_messenger_user_id'),
	workPlace: text('work_place'),
	manicurePrice: text('manicure_price'),
	pedicurePrice: text('pedicure_price'),
	monthlyIncome: text('monthly_income'),
	expectations: text('expectations').array(),
	otherExpectation: text('other_expectation'),
	gameRole: text('game_role'),
	chatAdminBadge: boolean('chat_admin_badge').default(false).notNull(),
	adminPermissions: jsonb('admin_permissions').$type<string[] | null>().default(null),
	points: integer('points').default(0).notNull(),
	bonusBalance: integer('bonus_balance').default(0).notNull(),
	role: text('role', { enum: userRoles }).default('user').notNull(),
	firstEntry: boolean('first_entry').default(false).notNull(),
	onboardingSeen: boolean('onboarding_seen').default(true).notNull(),
	createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
})

export const userSelectSchema = createSelectSchema(users).omit({ passwordHash: true })
export const userInsertSchema = createInsertSchema(users, {
	email: z.string().email().optional(),
	phone: z.string().min(10).optional(),
	username: z.string().min(2).max(32).optional(),
}).omit({ passwordHash: true })
export const userUpdateSchema = userInsertSchema
	.partial()
	.omit({ id: true, authUuid: true, createdAt: true })

export type User = z.infer<typeof userSelectSchema>
export type NewUser = z.infer<typeof userInsertSchema>
export type UserUpdate = z.infer<typeof userUpdateSchema>
