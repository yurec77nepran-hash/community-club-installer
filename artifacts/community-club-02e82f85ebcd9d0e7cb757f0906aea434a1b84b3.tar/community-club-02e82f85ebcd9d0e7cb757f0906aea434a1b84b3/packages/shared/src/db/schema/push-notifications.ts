import { bigserial, index, jsonb, pgTable, text, timestamp, uuid } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

export const pushNotifications = pgTable(
	'push_notifications',
	{
		id: bigserial('id', { mode: 'number' }).primaryKey(),
		userAuthUuid: uuid('user_auth_uuid')
			.references(() => users.authUuid, { onDelete: 'cascade' })
			.notNull(),
		title: text('title').notNull(),
		body: text('body').notNull(),
		url: text('url'),
		context: text('context').default('generic').notNull(),
		payload: jsonb('payload').$type<Record<string, unknown> | null>().default(null),
		deliveredAt: timestamp('delivered_at', { withTimezone: true }),
		readAt: timestamp('read_at', { withTimezone: true }),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('push_notifications_user_created_idx').on(table.userAuthUuid, table.createdAt),
		index('push_notifications_user_read_idx').on(table.userAuthUuid, table.readAt),
	],
)

export const pushNotificationSelectSchema = createSelectSchema(pushNotifications)
export const pushNotificationInsertSchema = createInsertSchema(pushNotifications, {
	title: z.string().trim().min(1).max(160),
	body: z.string().trim().min(1).max(2000),
	url: z.string().trim().max(2048).nullable().optional(),
	context: z.string().trim().min(1).max(120).optional(),
})

export type PushNotification = z.infer<typeof pushNotificationSelectSchema>
export type NewPushNotification = z.infer<typeof pushNotificationInsertSchema>
