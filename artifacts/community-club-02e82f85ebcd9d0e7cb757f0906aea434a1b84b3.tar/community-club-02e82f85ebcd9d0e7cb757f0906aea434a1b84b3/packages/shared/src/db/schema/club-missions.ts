import {
	boolean,
	index,
	integer,
	pgTable,
	serial,
	text,
	timestamp,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { users } from './users'

export const clubMissions = pgTable(
	'club_missions',
	{
		id: serial('id').primaryKey(),
		userAuthUuid: uuid('user_auth_uuid').references(() => users.authUuid, { onDelete: 'cascade' }),
		slug: text('slug').notNull(),
		name: text('name').notNull(),
		points: integer('points').notNull(),
		type: text('type', { enum: ['one-time', 'repeatable'] }).notNull(),
		completedAt: timestamp('completed_at', { withTimezone: true }),
		active: boolean('active').default(true).notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('club_missions_user_idx').on(table.userAuthUuid),
		index('club_missions_slug_idx').on(table.slug),
	],
)

export const clubMissionsSelectSchema = createSelectSchema(clubMissions)
export const clubMissionsInsertSchema = createInsertSchema(clubMissions, {
	slug: z.string().trim().min(1).max(120),
	name: z.string().trim().min(1).max(255),
	points: z.number().int().nonnegative(),
})

export type ClubMission = z.infer<typeof clubMissionsSelectSchema>
export type NewClubMission = z.infer<typeof clubMissionsInsertSchema>
