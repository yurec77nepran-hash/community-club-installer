import {
	boolean,
	index,
	integer,
	pgTable,
	serial,
	text,
	timestamp,
	uniqueIndex,
	uuid,
} from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { materials } from './materials'
import { users } from './users'

export const materialComments = pgTable(
	'material_comments',
	{
		id: serial('id').primaryKey(),
		materialId: integer('material_id')
			.notNull()
			.references(() => materials.id, { onDelete: 'cascade' }),
		userAuthUuid: uuid('user_auth_uuid')
			.notNull()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		parentCommentId: integer('parent_comment_id'),
		content: text('content').notNull(),
		isDeleted: boolean('is_deleted').default(false).notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
		updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		index('material_comments_material_created_idx').on(table.materialId, table.createdAt, table.id),
		index('material_comments_parent_idx').on(table.parentCommentId),
		index('material_comments_user_idx').on(table.userAuthUuid, table.createdAt),
	],
)

export const materialCommentReactions = pgTable(
	'material_comment_reactions',
	{
		id: serial('id').primaryKey(),
		commentId: integer('comment_id')
			.notNull()
			.references(() => materialComments.id, { onDelete: 'cascade' }),
		userAuthUuid: uuid('user_auth_uuid')
			.notNull()
			.references(() => users.authUuid, { onDelete: 'cascade' }),
		emoji: text('emoji').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex('material_comment_reaction_unique').on(
			table.commentId,
			table.userAuthUuid,
			table.emoji,
		),
		index('material_comment_reactions_comment_idx').on(table.commentId),
		index('material_comment_reactions_user_idx').on(table.userAuthUuid, table.createdAt),
	],
)

export const materialCommentSelectSchema = createSelectSchema(materialComments)
export const materialCommentInsertSchema = createInsertSchema(materialComments)
export const materialCommentReactionSelectSchema = createSelectSchema(materialCommentReactions)
export const materialCommentReactionInsertSchema = createInsertSchema(materialCommentReactions)
