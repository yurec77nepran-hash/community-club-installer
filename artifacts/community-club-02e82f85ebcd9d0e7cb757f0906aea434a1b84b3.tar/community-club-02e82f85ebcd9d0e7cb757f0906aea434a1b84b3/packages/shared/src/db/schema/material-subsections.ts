import { index, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core'

export const materialSubsections = pgTable(
	'material_subsections',
	{
		id: serial('id').primaryKey(),
		title: text('title').notNull(),
		createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
	},
	(table) => [index('material_subsections_title_idx').on(table.title)],
)
