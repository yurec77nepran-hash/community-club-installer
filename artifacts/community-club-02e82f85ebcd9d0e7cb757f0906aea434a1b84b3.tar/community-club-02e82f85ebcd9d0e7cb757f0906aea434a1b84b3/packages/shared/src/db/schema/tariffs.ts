import { boolean, integer, numeric, pgTable, serial, text } from 'drizzle-orm/pg-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const tariffs = pgTable('tariffs', {
	id: serial('id').primaryKey(),
	name: text('name').notNull(),
	slug: text('slug').unique().notNull(),
	role: text('role', { enum: ['club'] }).notNull(),
	tier: integer('tier').default(1).notNull(),
	durationDays: integer('duration_days').notNull(),
	price: numeric('price').notNull(),
	priceFirst: numeric('price_first'),
	isDiscount: boolean('is_discount').default(false).notNull(),
	discountPrice: numeric('discount_price'),
	foreignDiscountPrice: numeric('foreign_discount_price'),
	demoDays: integer('demo_days').default(0).notNull(),
	cpSubscriptionId: text('cp_subscription_id'),
	description: text('description'),
	isActive: boolean('is_active').default(true).notNull(),
	sortOrder: integer('sort_order').default(0).notNull(),
})

export const tariffSelectSchema = createSelectSchema(tariffs)
export const tariffInsertSchema = createInsertSchema(tariffs, {
	name: z.string().min(1),
	slug: z.string().min(1).max(50),
	price: z.string().regex(/^\d+(\.\d{1,2})?$/),
})

export type Tariff = z.infer<typeof tariffSelectSchema>
export type NewTariff = z.infer<typeof tariffInsertSchema>
