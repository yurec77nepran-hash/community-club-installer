import { z } from 'zod'

const HTTP_PROTOCOLS = new Set(['http:', 'https:'])
const HTTPS_PROTOCOLS = new Set(['https:'])
const APP_PATH_ORIGIN = 'https://community.local'
const urlStringSchema = z.string().trim().max(2048).url()

function hasUrlProtocol(value: string, allowedProtocols: ReadonlySet<string>) {
	try {
		return allowedProtocols.has(new URL(value).protocol)
	} catch {
		return false
	}
}

export function isHttpUrl(value: string) {
	return hasUrlProtocol(value, HTTP_PROTOCOLS)
}

export function isHttpsUrl(value: string) {
	return hasUrlProtocol(value, HTTPS_PROTOCOLS)
}

export function isSafeAppPath(value: string) {
	const trimmed = value.trim()
	if (!trimmed.startsWith('/') || trimmed.startsWith('//') || trimmed.includes('\\')) {
		return false
	}

	try {
		const url = new URL(trimmed, APP_PATH_ORIGIN)
		return (
			url.origin === APP_PATH_ORIGIN && (url.pathname === '/' || url.pathname.startsWith('/app'))
		)
	} catch {
		return false
	}
}

export const httpUrlSchema = urlStringSchema.refine(
	isHttpUrl,
	'Используйте ссылку с http или https',
)

export const httpsUrlSchema = urlStringSchema.refine(isHttpsUrl, 'Используйте ссылку с https')

export const safeNavigationUrlSchema = z
	.string()
	.trim()
	.max(2048)
	.refine(
		(value) => isHttpUrl(value) || isSafeAppPath(value),
		'Используйте корректную ссылку или путь внутри приложения',
	)

export const paginationSchema = z.object({
	page: z.coerce.number().int().min(1).default(1),
	pageSize: z.coerce.number().int().min(1).max(100).default(20),
})

export const cursorPaginationSchema = z.object({
	cursor: z.string().optional(),
	limit: z.coerce.number().int().min(1).max(100).default(50),
})

export const idSchema = z.object({
	id: z.coerce.number().int().positive(),
})

export const uuidSchema = z.object({
	uuid: z.string().uuid(),
})

export const searchSchema = z.object({
	q: z.string().min(1).max(200),
})

export type Pagination = z.infer<typeof paginationSchema>
export type CursorPagination = z.infer<typeof cursorPaginationSchema>
