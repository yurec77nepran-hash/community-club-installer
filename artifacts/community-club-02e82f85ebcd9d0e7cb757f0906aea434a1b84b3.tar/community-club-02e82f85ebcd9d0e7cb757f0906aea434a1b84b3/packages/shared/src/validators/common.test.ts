import { describe, expect, test } from 'bun:test'
import { httpUrlSchema, isSafeAppPath, safeNavigationUrlSchema } from './common'

describe('shared URL validators', () => {
	test('accepts only http and https URLs for externally opened links', () => {
		expect(httpUrlSchema.safeParse('https://example.com/page').success).toBe(true)
		expect(httpUrlSchema.safeParse('http://localhost:3000/media/file.jpg').success).toBe(true)
		expect(httpUrlSchema.safeParse('javascript:alert(1)').success).toBe(false)
		expect(httpUrlSchema.safeParse('data:text/html,hi').success).toBe(false)
		expect(httpUrlSchema.safeParse('ftp://example.com/file').success).toBe(false)
	})

	test('allows notification targets only as safe app paths or http links', () => {
		expect(safeNavigationUrlSchema.safeParse('/app/chats/2?messageId=42').success).toBe(true)
		expect(safeNavigationUrlSchema.safeParse('https://example.com/app').success).toBe(true)
		expect(safeNavigationUrlSchema.safeParse('javascript:alert(1)').success).toBe(false)
		expect(safeNavigationUrlSchema.safeParse('//evil.example/app').success).toBe(false)
		expect(safeNavigationUrlSchema.safeParse('/admin').success).toBe(false)
	})

	test('keeps app-path normalization strict', () => {
		expect(isSafeAppPath('/')).toBe(true)
		expect(isSafeAppPath('/app/feed')).toBe(true)
		expect(isSafeAppPath('/\\evil')).toBe(false)
	})
})
