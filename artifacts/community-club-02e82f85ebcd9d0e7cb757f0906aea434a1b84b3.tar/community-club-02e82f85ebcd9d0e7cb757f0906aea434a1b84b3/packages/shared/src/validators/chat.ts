import { z } from 'zod'
import { httpUrlSchema } from './common'

export const mentionPayloadSchema = z.object({
	userAuthUuid: z.string().uuid(),
	displayName: z.string().trim().min(1).max(120),
	start: z.number().int().min(0),
	end: z.number().int().min(1),
})

export const sendMessageSchema = z.object({
	chatId: z.number().int().positive(),
	content: z.string().max(4000).optional(),
	replyToId: z.number().int().positive().optional(),
	clientMessageId: z.string().trim().min(1).max(128).optional(),
	mentions: z.array(mentionPayloadSchema).max(10).optional(),
	messageType: z
		.enum(['text', 'image', 'video', 'voice', 'audio', 'document', 'link'])
		.default('text'),
	attachmentUrl: httpUrlSchema.optional(),
	attachmentName: z.string().optional(),
	attachmentSize: z.number().optional(),
})

export const editMessageSchema = z.object({
	chatId: z.number().int().positive(),
	messageId: z.number().int().positive(),
	content: z.string().max(4000),
	mentions: z.array(mentionPayloadSchema).max(10).optional(),
})

export const muteUserSchema = z.object({
	duration: z.enum(['1h', '24h', '7d', 'forever']).optional(),
})

export const chatNotificationSettingsSchema = z.object({
	enabled: z.boolean(),
})

export const chatSettingsSchema = z.object({
	allowMemberMessages: z.boolean().default(true),
	allowAttachments: z.boolean().default(true),
	allowReactions: z.boolean().default(true),
	slowModeSeconds: z.coerce.number().int().min(0).max(3600).default(0),
	welcomeText: z.string().trim().max(500).nullable().default(null),
})

export const adminChatInputSchema = z.object({
	name: z.string().trim().min(2).max(120),
	slug: z
		.string()
		.trim()
		.min(2)
		.max(80)
		.regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Используйте латиницу, цифры и дефисы'),
	type: z.enum(['chat', 'channel']).default('chat'),
	accessRole: z.literal('all').default('all'),
	isEnabled: z.boolean().default(true),
	avatarUrl: httpUrlSchema.nullable().or(z.literal('')).optional(),
	description: z.string().trim().max(500).nullable().or(z.literal('')).optional(),
	settings: chatSettingsSchema.default({}),
})

export const createChannelPostSchema = z.object({
	content: z.string().min(1).max(10000),
	attachments: z
		.array(
			z.object({
				type: z.string(),
				url: httpUrlSchema,
				name: z.string(),
				size: z.number(),
			}),
		)
		.optional(),
})

export const createScheduledMessageSchema = z.object({
	content: z.string().trim().min(1).max(4000),
	scheduledAt: z.string().datetime(),
	mentions: z.array(mentionPayloadSchema).max(10).optional(),
})

export type SendMessage = z.infer<typeof sendMessageSchema>
export type EditMessage = z.infer<typeof editMessageSchema>
export type MentionPayload = z.infer<typeof mentionPayloadSchema>
export type MuteUser = z.infer<typeof muteUserSchema>
export type ChatNotificationSettingsInput = z.infer<typeof chatNotificationSettingsSchema>
export type ChatSettingsInput = z.infer<typeof chatSettingsSchema>
export type AdminChatInput = z.infer<typeof adminChatInputSchema>
export type CreateChannelPost = z.infer<typeof createChannelPostSchema>
export type CreateScheduledMessage = z.infer<typeof createScheduledMessageSchema>
