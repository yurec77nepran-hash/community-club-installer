import { z } from 'zod'

export const pwaLaunchMetadataSchema = z
	.object({
		userAgent: z.string().trim().min(1).max(1000).optional(),
		platform: z.string().trim().min(1).max(120).optional(),
		deviceLabel: z.string().trim().min(1).max(160).optional(),
	})
	.strict()

export type PwaLaunchMetadata = z.infer<typeof pwaLaunchMetadataSchema>
