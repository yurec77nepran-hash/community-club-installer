import { z } from 'zod'

export const phoneSchema = z
	.string()
	.trim()
	.regex(/^\+7\d{10}$/, 'Формат: +79XXXXXXXXX')

export const loginSchema = z.object({
	email: z.string().trim().toLowerCase().email('Неверный формат email'),
	password: z.string().min(6, 'Минимум 6 символов'),
})

export const authCodeChannelSchema = z.enum(['telegram', 'max'])

export const authCodeRequestSchema = z.object({
	email: z.string().email('Неверный формат email'),
	channel: authCodeChannelSchema,
})

export const authCodeVerifySchema = authCodeRequestSchema.extend({
	code: z
		.string()
		.trim()
		.regex(/^\d{6}$/, 'Введите 6 цифр'),
})

export const telegramBotVerifySchema = z.object({
	code: z
		.string()
		.trim()
		.regex(/^\d{6}$/, 'Введите 6 цифр'),
})

export const registerSchema = z.object({
	email: z.string().trim().toLowerCase().email('Неверный формат email'),
	password: z.string().min(6, 'Минимум 6 символов'),
	fullName: z.string().min(2, 'Введите имя').max(100),
})

export const changePasswordSchema = z.object({
	currentPassword: z.string().optional(),
	newPassword: z.string().min(6, 'Минимум 6 символов'),
})

export const forgotPasswordSchema = z.object({
	email: z.string().email('Неверный формат email'),
})

export const sendAccessPasswordSchema = z.object({
	email: z.string().email('Неверный формат email'),
	channel: z.enum(['email', 'telegram']),
})

export const entryCheckSchema = z.object({
	email: z.string().email('Неверный формат email'),
})

export const resetPasswordSchema = z.object({
	token: z.string().min(16, 'Некорректный токен'),
	newPassword: z.string().min(6, 'Минимум 6 символов'),
})

export type Login = z.infer<typeof loginSchema>
export type AuthCodeRequest = z.infer<typeof authCodeRequestSchema>
export type AuthCodeVerify = z.infer<typeof authCodeVerifySchema>
export type Register = z.infer<typeof registerSchema>
export type ChangePassword = z.infer<typeof changePasswordSchema>
export type ForgotPassword = z.infer<typeof forgotPasswordSchema>
export type SendAccessPassword = z.infer<typeof sendAccessPasswordSchema>
export type ResetPassword = z.infer<typeof resetPasswordSchema>
export type EntryCheck = z.infer<typeof entryCheckSchema>
