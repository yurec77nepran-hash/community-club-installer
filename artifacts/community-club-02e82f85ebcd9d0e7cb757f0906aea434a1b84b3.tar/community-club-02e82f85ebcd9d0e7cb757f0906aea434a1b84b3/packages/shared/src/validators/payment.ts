import { z } from 'zod'

export const checkDiscountSchema = z.object({
	email: z.string().email('Неверный формат email'),
})

export type CheckDiscount = z.infer<typeof checkDiscountSchema>
