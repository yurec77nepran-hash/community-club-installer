import { describe, expect, test } from 'bun:test'
import { loginSchema, registerSchema } from './auth'

describe('shared auth validators', () => {
	test('accepts login with email and password without a phone', () => {
		// Given
		const payload = { email: '  Member@Example.COM  ', password: 'secret123' }

		// When
		const result = loginSchema.safeParse(payload)

		// Then
		expect(result.success).toBe(true)
		if (result.success) expect(result.data.email).toBe('member@example.com')
	})

	test('rejects login with phone and password without an email', () => {
		// Given
		const payload = { phone: '+79991234567', password: 'secret123' }

		// When
		const result = loginSchema.safeParse(payload)

		// Then
		expect(result.success).toBe(false)
	})

	test('accepts registration with email, full name, and password without a phone', () => {
		// Given
		const payload = {
			email: '  New-Member@Example.COM  ',
			fullName: 'New Member',
			password: 'secret123',
		}

		// When
		const result = registerSchema.safeParse(payload)

		// Then
		expect(result.success).toBe(true)
		if (result.success) expect(result.data.email).toBe('new-member@example.com')
	})

	test('rejects registration with phone, full name, and password without an email', () => {
		// Given
		const payload = {
			phone: '+79991234567',
			fullName: 'New Member',
			password: 'secret123',
		}

		// When
		const result = registerSchema.safeParse(payload)

		// Then
		expect(result.success).toBe(false)
	})
})
