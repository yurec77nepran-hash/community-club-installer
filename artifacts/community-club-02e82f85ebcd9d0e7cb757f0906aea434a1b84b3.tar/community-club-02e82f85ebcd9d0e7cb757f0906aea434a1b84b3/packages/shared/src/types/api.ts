export interface ApiSuccess<T> {
	success: true
	data: T
}

export interface ApiError {
	success: false
	error: {
		code: string
		message: string
		details?: Array<{ path: string; message: string }>
	}
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError

export interface PwaLaunchStatusResponse {
	readonly hasStandaloneLaunch: boolean
	readonly firstLaunchedAt: string | null
	readonly lastLaunchedAt: string | null
	readonly launchCount: number
	readonly userAgent: string | null
	readonly platform: string | null
	readonly deviceLabel: string | null
}

export interface PaginatedResponse<T> {
	items: T[]
	total: number
	page: number
	pageSize: number
	hasMore: boolean
}

export interface CursorPaginatedResponse<T> {
	items: T[]
	nextCursor: string | null
}

export interface MaterialPlaybackProgressPayload {
	mediaFileIndex?: number | null
	positionSeconds: number
	durationSeconds: number | null
	completed: boolean
	updatedAt: string | Date | null
}

export interface ChatUserProfile {
	userAuthUuid: string
	fullName: string | null
	username: string | null
	avatarUrl: string | null
	chatAdminBadge: boolean
	socialLinks: string[]
	status: null
	badges: []
}

export interface CheckDiscountResponse {
	source: 'db_user' | 'new'
	role: ClubTariffRole | null
	pricingContext: PricingContext
	showPriceFirst: boolean
}

export type ClubEntryStatus = 'member_requires_password' | 'purchase_required'
export type ClubTariffRole = 'club'
export type PricingContext = 'intro' | 'active' | 'former' | 'external'
export type PaymentCardType = 'russian' | 'foreign'
export type PaymentBillingMode = 'recurrent' | 'one_time'
export type PaymentRecurrentInterval = 'tariff' | 'Day' | 'Week' | 'Month'
export type PasswordDeliveryChannel = 'email' | 'telegram'
export type AuthLoginMethod = 'password' | 'telegram' | 'max'
export type PaymentProviderCode = 'cloudpayments' | 'prodamus' | 'yookassa' | 'tochka'

export interface PaymentCheckoutLinkResponse {
	checkoutUrl: string
	firstAmount: number
	regularAmount: number
	cardType: PaymentCardType
	recurrentEnabled: boolean
}

export interface PaymentProviderWebhookInfo {
	label: string
	url: string
}

export interface PaymentProviderConnection {
	provider: PaymentProviderCode
	label: string
	enabled: boolean
	connected: boolean
	isActive: boolean
	webhooks: PaymentProviderWebhookInfo[]
	fields: Record<string, string | boolean>
	secretFields: Record<string, boolean>
	diagnostics?: {
		lastWebhookAt: string | null
		lastSuccessAt: string | null
		lastFailureAt: string | null
		lastStatus: string | null
		lastErrorMessage: string | null
	}
}

export interface PaymentCheckoutSettings {
	foreignCardsEnabled: boolean
	billingMode: PaymentBillingMode
	recurrentInterval: PaymentRecurrentInterval
	recurrentPeriod: number
	recurrentMaxPeriods: number | null
	recurrentStartDelayDays: number | null
	requisitesEnabled: boolean
	requisitesName: string
	requisitesTaxId: string
	requisitesRegistrationId: string
	requisitesAddress: string
	manualPaymentEnabled: boolean
}

export interface AdminPaymentProviderSettings {
	activeProvider: PaymentProviderCode
	checkout: PaymentCheckoutSettings
	providers: PaymentProviderConnection[]
	manualPaymentEnabled: boolean
}

export interface AdminPaymentProviderSettingsPayload {
	activeProvider: PaymentProviderCode
	checkout?: PaymentCheckoutSettings
	providers: Array<{
		provider: PaymentProviderCode
		enabled: boolean
		fields: Record<string, string | boolean | null>
		secretFields?: Record<string, string | null | undefined>
	}>
	manualPaymentEnabled?: boolean
}

export interface PaymentTariffOffer {
	id: string
	name: string
	slug: string
	role: ClubTariffRole
	durationDays: number
	price: string
	priceFirst: string | null
	discountPrice: string | null
	foreignDiscountPrice: string | null
	demoDays: number
	description: string | null
	isActive: boolean
	sortOrder: number
	tier: 1 | 2 | 3
	pricingContext: PricingContext
}

export interface ClubEntryResolution {
	status: ClubEntryStatus
	email: string
	source: 'db_user' | 'new'
	message: string
	role: ClubTariffRole
	tariffTier: 1 | 2 | 3
	pricingContext: PricingContext
	isParticipant: boolean
	userExists: boolean
	hasPassword: boolean
	firstEntry: boolean
	showPriceFirst: boolean
	fullName: string | null
	phone: string | null
}

export interface SendAccessPasswordResponse {
	message: string
	channel: PasswordDeliveryChannel
}

export interface AuthLoginSettings {
	passwordEnabled: boolean
	telegramCodeEnabled: boolean
	maxCodeEnabled: boolean
	defaultMethod: AuthLoginMethod
	botAuthEnabled: boolean
}

export type AdminAuthLoginSettingsPayload = AuthLoginSettings

export interface TelegramBotAuthSettings {
	botHandle: string
	noAccessText: string
	codeMessageText: string
	subscriptionButtonLabel: string
	subscriptionButtonUrl: string
	openAppButtonLabel: string
	ownerHandle: string
}

export type AdminTelegramBotAuthSettingsPayload = TelegramBotAuthSettings

export interface TestAccessSettings {
	enabled: boolean
	days: number
}

export type AdminTestAccessSettingsPayload = TestAccessSettings

export type GuestContentAccessLevel = 'sections' | 'cards' | 'preview'
export type GuestContentBlockAccess = 'visible' | 'blurred' | 'locked'

export interface GuestContentAccessSettings {
	level: GuestContentAccessLevel
}

export type AdminGuestContentAccessSettingsPayload = GuestContentAccessSettings

export interface MaterialGuestAccess {
	cover: GuestContentBlockAccess
	description: GuestContentBlockAccess
	link: GuestContentBlockAccess
}

export interface MaterialVideoChapter {
	time: number
	description: string
}

export interface MaterialVideoChapters {
	collapsible: boolean
	items: MaterialVideoChapter[]
}

export interface ReferralProgramSettings {
	enabled: boolean
	description: string
}

export type AdminReferralProgramSettingsPayload = ReferralProgramSettings

export interface ReferralProgramStatsItem {
	id: number
	status: 'pending' | 'paid' | 'bonus_credited'
	createdAt: string | Date
	referred: {
		authUuid: string
		fullName: string | null
		email: string | null
	} | null
}

export interface ReferralProgramMyResponse {
	enabled: boolean
	description: string
	referralCode: string
	referralLink: string
	totalReferred: number
	totalPaid: number
	totalBonus: number
	referrals: ReferralProgramStatsItem[]
}

export interface AdminReferralProgramAnalyticsResponse {
	totals: {
		referrals: number
		paid: number
		pending: number
		referrers: number
		totalBonus: number
	}
	daily: Array<{
		day: string
		referrals: number
		paid: number
	}>
	topReferrers: Array<{
		authUuid: string
		fullName: string | null
		email: string | null
		referrals: number
		paid: number
		totalBonus: number
		lastReferralAt: string | Date
	}>
}

export type LegalDocumentKey = 'privacy' | 'personalData' | 'oferta' | 'requisites' | 'cookie'

export interface LegalDocumentItem {
	key: LegalDocumentKey
	title: string
	linkLabel: string
	noticeText?: string
	enabled: boolean
	body: string
}

export interface LegalDocumentsSettings {
	documents: LegalDocumentItem[]
}

export type AdminLegalDocumentsSettingsPayload = LegalDocumentsSettings

export interface AuthCodeRequestResponse {
	message: string
	channel: Exclude<AuthLoginMethod, 'password'>
	expiresIn: number
}

export type CustomDomainStatusCode = 'not_configured' | 'connected' | 'pending' | 'error'
export type DomainProvisionStatusCode = 'connected' | 'pending' | 'disabled' | 'error'

export interface CustomDomainStatus {
	status: CustomDomainStatusCode
	domain: string | null
	checkedAt: string
	message: string
	dns: {
		expectedHost: string | null
		cnames: string[]
		domainAddresses: string[]
		expectedAddresses: string[]
		cnameMatches: boolean
		addressMatches: boolean
	}
}

export interface DomainProvisionCommandResult {
	ok: boolean
	command: string
	exitCode: number | null
	output: string
}

export interface DomainProvisionResult {
	status: DomainProvisionStatusCode
	domain: string | null
	checkedAt: string
	message: string
	dns: CustomDomainStatus
	caddy?: {
		validate?: DomainProvisionCommandResult
		reload?: DomainProvisionCommandResult
	}
	https: {
		ok: boolean
		status: number | null
		message: string
	}
}

export interface RuntimeSettings {
	customDomain: string | null
	telegramBotTokenSet: boolean
	maxBotTokenSet: boolean
	maxApiUrl: string
}

export interface AdminRuntimeSettings extends RuntimeSettings {
	customDomainStatus: CustomDomainStatus
}

export interface AdminRuntimeSettingsPayload {
	customDomain: string | null
	telegramBotToken?: string | null
	maxBotToken?: string | null
	maxApiUrl: string
}

export interface SupportThreadSummary {
	chatId: number
	slug: string
	name: string
	createdAt: string | Date
	user: {
		authUuid: string
		email: string | null
		phone: string | null
		fullName: string | null
		avatarUrl: string | null
		role: string
	}
	lastMessage: {
		id: number
		content: string | null
		messageType: string
		createdAt: string | Date
		userAuthUuid: string
	} | null
}

export interface SupportThreadContext {
	user: {
		authUuid: string
		email: string | null
		phone: string | null
		fullName: string | null
		avatarUrl: string | null
		role: string
		city: string | null
		workPlace: string | null
		createdAt: string | Date
	}
	payment: {
		tarrif: string | null
		dateStart: string | Date | null
		dateFinish: string | Date | null
		amount: string | null
		autoPayment: boolean
		paymentProvider: 'cloudpayments' | 'prodamus' | 'yookassa' | 'tochka' | null
	} | null
	paymentLogs: Array<{
		id: number
		event: string
		amount: string | null
		status: string | null
		tariff: string | null
		paymentDate: string | Date | null
		nextPaymentDate: string | Date | null
		createdAt: string | Date
	}>
	stats: {
		totalMessages: number
		userMessages: number
		firstUserMessageAt: string | Date | null
		lastUserMessageAt: string | Date | null
	}
}

export interface MentionCandidate {
	userAuthUuid: string
	fullName: string | null
	username: string | null
	avatarUrl: string | null
	role: string
	displayName: string
}

export interface ChatListItem {
	id: number
	slug: string
	name: string
	type: 'chat' | 'channel'
	accessRole: 'all'
	isEnabled: boolean
	avatarUrl: string | null
	description: string | null
	settings: ChatSettings
	createdAt: string | Date
	updatedAt: string | Date
	lastReadMessageId: number | null
	unreadMessageCount: number
	unreadMentionCount: number
}

export interface ChatSettings {
	allowMemberMessages: boolean
	allowAttachments: boolean
	allowReactions: boolean
	slowModeSeconds: number
	welcomeText: string | null
}

export interface AdminChatItem {
	id: number
	slug: string
	name: string
	type: 'chat' | 'channel'
	accessRole: 'all'
	isEnabled: boolean
	avatarUrl: string | null
	description: string | null
	settings: ChatSettings
	createdAt: string | Date
	updatedAt: string | Date
	membersCount: number
	messagesCount: number
}

export interface ScheduledChatMessageItem {
	id: number
	chatId: number
	content: string
	scheduledAt: string | Date
	status: 'scheduled' | 'processing' | 'sent' | 'cancelled' | 'failed'
	errorMessage: string | null
	createdAt: string | Date
	author: {
		authUuid: string
		fullName: string | null
		username: string | null
		avatarUrl: string | null
		role: string
	}
}

export interface HomeSnapshotMaterial {
	id: number
	type: string
	title: string
	imageUrl: string | null
	shortDescription: string | null
	fullDescription: string | null
	subsection: string | null
	active: boolean
	mediaType: string | null
	durationSeconds: number | null
	fileSizeBytes: number | null
	createdAt: string | Date
	accessible: boolean
	accessMessage: string | null
}

export interface HomeSnapshot {
	chats: ChatListItem[]
	recentMaterials: CursorPaginatedResponse<HomeSnapshotMaterial>
	unreadMentionsTotal: number
}

export interface MaterialCommentAuthor {
	authUuid: string
	fullName: string | null
	username: string | null
	avatarUrl: string | null
	role: string
}

export interface MaterialCommentReaction {
	id: number
	commentId: number
	userAuthUuid: string
	emoji: string
	createdAt: string | Date
}

export interface MaterialCommentItem {
	id: number
	materialId: number
	parentCommentId: number | null
	content: string
	isDeleted: boolean
	createdAt: string | Date
	updatedAt: string | Date
	author: MaterialCommentAuthor
	reactions: MaterialCommentReaction[]
	replies: MaterialCommentItem[]
}

export interface MaterialCommentFeedItem {
	id: number
	materialId: number
	materialType: string
	materialTitle: string
	parentCommentId: number | null
	content: string
	createdAt: string | Date
	author: MaterialCommentAuthor
	reactions: MaterialCommentReaction[]
	repliesCount: number
}

export interface FeedMediaItem {
	type: 'image' | 'video'
	path: string
	url: string | null
	name: string | null
	size: number | null
	width: number | null
	height: number | null
	durationSeconds: number | null
}

export interface FeedReactionSummary {
	emoji: string
	count: number
	reactedByMe: boolean
}

export interface FeedPostAuthor {
	authUuid: string
	fullName: string | null
	username: string | null
	avatarUrl: string | null
	role: string
}

export interface FeedPostItem {
	id: number
	audience: 'club'
	content: string
	contentHtml: string
	buttonLabel: string | null
	buttonUrl: string | null
	notifyAll: boolean
	media: FeedMediaItem[]
	createdAt: string | Date
	author: FeedPostAuthor | null
	reactions: FeedReactionSummary[]
}

export interface FeedPostDraftItem {
	id: number
	audience: 'club'
	content: string
	buttonLabel: string | null
	buttonUrl: string | null
	notifyAll: boolean
	media: FeedMediaItem[]
	createdAt: string | Date
	updatedAt: string | Date
}

export interface AdminMediaLibraryItem {
	key: string
	name: string
	title: string
	url: string
	type: 'image' | 'video' | 'audio' | 'document'
	size: number | null
	lastModified: string | Date | null
	note: string | null
	folderId: number | null
}

export interface AdminMediaLibraryFolder {
	id: number
	name: string
	itemsCount: number
	createdAt: string | Date
}

export type AdminMediaLibraryPreferenceScope = 'library' | 'materialPicker'

export interface AdminMediaLibraryPreferencesPayload {
	viewMode: 'cards' | 'list'
	sortBy: 'updatedAt' | 'title' | 'size' | 'type'
	sortDir: 'asc' | 'desc'
	typeFilter: 'all' | 'image' | 'video' | 'audio' | 'document'
	searchQuery: string
	folderId: number | null
}

export interface AdminSiteBrandingSettingsPayload {
	clubName: string
	homeLogoEnabled: boolean
	homeLogoMediaKey: string | null
	buttonBackgroundColor: string
	appBackgroundColor: string
	appSurfaceColor: string
	appTextColor: string
	appAccentColor: string
}

export interface SiteBrandingSettings extends AdminSiteBrandingSettingsPayload {
	homeLogoUrl: string | null
}

export type HomeBannerActionKind = 'stories' | 'internal' | 'external'
export type HomeStoryLayout = 'text' | 'image' | 'imageText'
export type HomeBannerShape = 'rounded' | 'circle'
export type HomeSectionGridLayout = 'featured' | 'equalOneRow' | 'equalTwoRows'
export type HomeSectionVisualMode = 'color' | 'icon' | 'image'
export type HomeSectionTextMode = 'visible' | 'hidden'
export type HomeCustomPageBlockKind = 'heading' | 'text' | 'image' | 'video' | 'button'

export interface HomeStoryItem {
	id: string
	title: string
	text: string
	layout: HomeStoryLayout
	backgroundColor: string
	textColor: string
	mediaKey: string | null
	mediaUrl: string | null
	durationMs: number
	imageScale: number
	imageX: number
	imageY: number
	overlays: HomeStoryOverlay[]
}

export type HomeStoryOverlayType = 'text' | 'image' | 'button'

export type HomeStoryButtonAction = 'none' | 'link' | 'section'

export type HomeStorySection =
	| 'materials'
	| 'chats'
	| 'channel'
	| 'feed'
	| 'calendar'
	| 'profile'
	| 'payment'
	| 'support'
	| ''

export interface HomeStoryOverlay {
	id: string
	type: HomeStoryOverlayType
	x: number
	y: number
	width: number
	text: string
	textColor: string
	fontSize: number
	align: 'left' | 'center' | 'right'
	mediaKey: string | null
	mediaUrl: string | null
	borderRadius: number
	opacity: number
	label: string
	backgroundColor: string
	borderColor: string | null
	borderWidth: number
	action: HomeStoryButtonAction
	linkUrl: string
	section: HomeStorySection
}

export interface HomeHighlightItem {
	id: string
	title: string
	stories: HomeStoryItem[]
}

export interface HomeBannerItem {
	id: string
	title: string
	subtitle: string
	backgroundColor: string
	textColor: string
	mediaKey: string | null
	mediaUrl: string | null
	actionKind: HomeBannerActionKind
	internalPath: string
	externalUrl: string
	requiresAuth: boolean
	storiesEnabled: boolean
}

export interface HomeMainBanner {
	mediaKey: string | null
	mediaUrl: string | null
	alt: string
}

export interface HomeSectionItem {
	id: string
	title: string
	subtitle: string
	backgroundColor: string
	textColor: string
	mediaKey: string | null
	mediaUrl: string | null
	icon: string
	visualMode: HomeSectionVisualMode
	textMode: HomeSectionTextMode
	actionKind: 'internal' | 'external'
	internalPath: string
	externalUrl: string
	requiresAuth: boolean
}

export interface HomeCustomPageBlock {
	id: string
	kind: HomeCustomPageBlockKind
	title: string
	text: string
	mediaKey: string | null
	mediaUrl: string | null
	buttonLabel: string
	buttonUrl: string
	backgroundColor: string
	textColor: string
	borderRadius: number
	size: 'sm' | 'md' | 'lg'
}

export interface HomeCustomPage {
	id: string
	slug: string
	title: string
	backgroundColor: string
	textColor: string
	blocks: HomeCustomPageBlock[]
}

export interface HomeExperienceSettings {
	mainBanner: HomeMainBanner
	banners: HomeBannerItem[]
	bannerShape: HomeBannerShape
	stories: HomeStoryItem[]
	highlights: HomeHighlightItem[]
	sectionLayout: HomeSectionGridLayout
	sections: HomeSectionItem[]
	customPages: HomeCustomPage[]
}

export type AppHeaderBlock = 'logo' | 'avatar' | 'name' | 'notifications'

export type AppMenuIcon =
	| 'home'
	| 'feed'
	| 'calendar'
	| 'cube'
	| 'book'
	| 'wrench'
	| 'user'
	| 'bell'
	| 'support'
	| 'info'
	| 'chats'
	| 'materials'
	| 'spark'
	| 'play'
	| 'check'
	| 'video'

export interface AppHeaderSettings {
	enabled: boolean
	showOnAllPages: boolean
	order: AppHeaderBlock[]
	logoMode: 'image' | 'text'
	nameMode: 'user' | 'club'
}

export interface AppMenuItem {
	id: string
	label: string
	icon: AppMenuIcon
	path: string
	requiresAuth: boolean
	requiresAccess: boolean
}

export interface AppMenuCenterButton {
	enabled: boolean
	icon: AppMenuIcon
	imageKey: string | null
	imageUrl: string | null
	glowEnabled: boolean
	pressEffectEnabled: boolean
	actionPath: string
	requiresAuth: boolean
}

export interface AppMenuSettings {
	items: AppMenuItem[]
	centerButton: AppMenuCenterButton
	backgroundColor: string
	borderColor: string | null
	borderRadius: number
	marginBottom: number
	marginSide: number
	iconStrokeColor: string | null
	iconGlowEnabled: boolean
	iconHighlightEnabled: boolean
	activeIconColor: string
	inactiveIconColor: string
	startActivePath: string
}

export interface AppNavigationSettings {
	header: AppHeaderSettings
	menu: AppMenuSettings
}

export interface AdminActivityLogItem {
	id: number
	actorAuthUuid: string | null
	actorName: string | null
	actorEmail: string | null
	action: string
	entityType: string
	entityId: string | null
	summary: string
	details: Record<string, unknown> | null
	createdAt: string | Date
}

export interface AdminTelegramBroadcastBot {
	username: string
	label: string
}

export interface AdminTelegramContact {
	id: number
	botUsername: string
	telegramUserId: string
	telegramUsername: string | null
}

export interface AdminTelegramBroadcast {
	id: number
	name: string
	botUsername: string
	botUsernames: string[]
	deliveryMode: 'all' | 'unique'
	preferredBotUsername: string | null
	body: string
	buttons: import('../utils/telegram-broadcast-content').TelegramBroadcastButton[]
	media: import('../utils/telegram-broadcast-content').TelegramBroadcastMedia | null
	status: 'scheduled' | 'processing' | 'paused' | 'completed' | 'failed' | 'cancelled'
	sendAt: string | Date
	audienceSize: number
	sentCount: number
	failedCount: number
	lastError: string | null
	createdAt: string | Date
}

export interface AdminTelegramBroadcastAudience {
	contacts: number
	uniqueUsers: number
	overlapUsers: number
}
