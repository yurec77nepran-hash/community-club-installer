import type { Message, MessageMention } from '../db/schema/chats'

export type ChatMessageWithMeta = Message & {
	author: {
		fullName: string | null
		avatarUrl: string | null
		username: string | null
		chatAdminBadge: boolean
	}
	replyTo?: {
		id: number
		userAuthUuid: string
		content: string | null
		messageType: Message['messageType']
		attachmentName: string | null
		author: {
			fullName: string | null
			username: string | null
		} | null
	} | null
	reactions: Array<{
		id: number
		messageId: number
		userAuthUuid: string
		emoji: string
		createdAt: Date
	}>
	mentions: MessageMention[]
}

export type WSServerMessage =
	| { type: 'room_joined'; chatId: number }
	| { type: 'pong'; ts: number }
	| { type: 'new_message'; message: ChatMessageWithMeta }
	| { type: 'message_ack'; clientMessageId: string | null; message: ChatMessageWithMeta }
	| { type: 'message_updated'; message: ChatMessageWithMeta }
	| { type: 'message_deleted'; messageId: number; chatId: number }
	| { type: 'typing'; chatId: number; userId: string; expiresAt: number }
	| { type: 'presence'; chatId: number; onlineCount: number }
	| {
			type: 'reaction_update'
			messageId: number
			userId: string
			emoji: string
			action: 'added' | 'removed'
	  }
	| { type: 'error'; message: string; code?: string; clientMessageId?: string | null }
