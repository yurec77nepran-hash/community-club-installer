export interface MentionPayload {
	userAuthUuid: string
	displayName: string
	start: number
	end: number
}
