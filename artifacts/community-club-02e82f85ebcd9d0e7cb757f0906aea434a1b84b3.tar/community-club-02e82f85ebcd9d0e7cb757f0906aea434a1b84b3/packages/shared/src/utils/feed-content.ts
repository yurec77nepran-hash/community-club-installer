function escapeHtml(value: string) {
	return value
		.replaceAll('&', '&amp;')
		.replaceAll('<', '&lt;')
		.replaceAll('>', '&gt;')
		.replaceAll('"', '&quot;')
		.replaceAll("'", '&#39;')
}

function restoreAllowedTags(value: string) {
	return value.replace(/&lt;(\/?)(strong|b|em|i|u|s)&gt;/g, '<$1$2>')
}

function autolinkText(value: string) {
	return value.replace(
		/(https?:\/\/[^\s<]+)/g,
		(url) =>
			`<a href="${url}" target="_blank" rel="noopener noreferrer" class="feed-inline-link">${url}</a>`,
	)
}

export function renderFeedContentHtml(content: string) {
	const escaped = escapeHtml(content)
	const restored = restoreAllowedTags(escaped)
	const withBreaks = restored.replace(/\r\n|\r|\n/g, '<br>')
	return withBreaks
		.split(/(<[^>]+>)/g)
		.map((chunk) => (chunk.startsWith('<') ? chunk : autolinkText(chunk)))
		.join('')
}

export function stripFeedFormatting(content: string) {
	return content
		.replace(/<\/?(strong|b|em|i|u|s)>/gi, '')
		.replace(/https?:\/\/[^\s<]+/g, (url) => url)
		.replace(/\s+/g, ' ')
		.trim()
}

export function buildFeedExcerpt(content: string, maxLength = 140) {
	const plain = stripFeedFormatting(content)
	if (plain.length <= maxLength) return plain
	return `${plain.slice(0, Math.max(0, maxLength - 1)).trimEnd()}…`
}
