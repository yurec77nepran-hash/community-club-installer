export type TelegramBroadcastButtonColor = 'default' | 'primary' | 'success' | 'danger'
export type TelegramBroadcastMediaType = 'image' | 'video' | 'audio' | 'document'

export interface TelegramBroadcastButton {
	id: string
	text: string
	url: string
	color: TelegramBroadcastButtonColor
}

export interface TelegramBroadcastMedia {
	path: string
	name: string
	type: TelegramBroadcastMediaType
}

const allowedTags = new Set([
	'b',
	'strong',
	'i',
	'em',
	'u',
	's',
	'strike',
	'del',
	'code',
	'pre',
	'blockquote',
	'tg-spoiler',
	'a',
])

function escapeHtml(value: string) {
	return value
		.replaceAll('&', '&amp;')
		.replaceAll('<', '&lt;')
		.replaceAll('>', '&gt;')
		.replaceAll('"', '&quot;')
		.replaceAll("'", '&#39;')
}

function normalizeEditorBlocks(value: string) {
	return value
		.replace(/\r\n?|\n/g, '\n')
		.replace(/<br\s*\/?\s*>/gi, '\n')
		.replace(/<\/div>\s*<div[^>]*>/gi, '\n')
		.replace(/<\/p>\s*<p[^>]*>/gi, '\n')
		.replace(/<\/?(?:div|p)[^>]*>/gi, '')
}

function isSafeLink(value: string) {
	try {
		const url = new URL(value)
		return ['https:', 'http:', 'tg:', 'mailto:'].includes(url.protocol)
	} catch {
		return false
	}
}

function linkHref(attributes: string) {
	const match = attributes.match(/\bhref\s*=\s*(["'])(.*?)\1/i)
	const href = match?.[2]?.trim()
	return href && isSafeLink(href) ? href : null
}

/** Keeps only formatting understood by Telegram's HTML parse mode. */
export function sanitizeTelegramBroadcastHtml(value: string) {
	const source = normalizeEditorBlocks(value).trim()
	let result = ''
	let cursor = 0
	const stack: string[] = []
	const tagPattern = /<\s*(\/?)\s*([a-z][\w-]*)([^>]*)>/gi

	for (const match of source.matchAll(tagPattern)) {
		const index = match.index ?? 0
		result += escapeHtml(source.slice(cursor, index))
		cursor = index + match[0].length
		const closing = Boolean(match[1])
		const tag = match[2].toLowerCase()
		if (!allowedTags.has(tag)) {
			// Неизвестные теги — удаляем, оставляя содержимое
			continue
		}

		if (closing) {
			if (stack.at(-1) === tag) {
				stack.pop()
				result += `</${tag}>`
			}
			continue
		}

		if (tag === 'a') {
			const href = linkHref(match[3])
			if (!href) continue
			result += `<a href="${escapeHtml(href)}">`
		} else {
			result += `<${tag}>`
		}
		stack.push(tag)
	}

	result += escapeHtml(source.slice(cursor))
	while (stack.length) result += `</${stack.pop()}>`
	return result.replace(/\n{3,}/g, '\n\n').trim()
}

export function telegramBroadcastPlainText(value: string) {
	return sanitizeTelegramBroadcastHtml(value)
		.replace(/<[^>]+>/g, '')
		.replaceAll('&amp;', '&')
		.replaceAll('&lt;', '<')
		.replaceAll('&gt;', '>')
		.replaceAll('&quot;', '"')
		.replaceAll('&#39;', "'")
}
