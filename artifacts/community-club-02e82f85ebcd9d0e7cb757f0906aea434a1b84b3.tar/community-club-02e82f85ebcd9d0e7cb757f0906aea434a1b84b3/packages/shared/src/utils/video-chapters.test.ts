import { describe, expect, test } from 'bun:test'
import {
	formatVideoChapterTime,
	normalizeVideoChapters,
	parseVideoChapterTime,
} from './video-chapters'

describe('video chapters', () => {
	test('parses and formats the editor time format', () => {
		expect(parseVideoChapterTime('05:30')).toBe(330)
		expect(parseVideoChapterTime('5:75')).toBeNull()
		expect(formatVideoChapterTime(330)).toBe('05:30')
	})

	test('keeps only playable chapters', () => {
		expect(
			normalizeVideoChapters({
				collapsible: true,
				items: [
					{ time: 10, description: 'Вступление' },
					{ time: -1, description: 'Не попадёт в ответ' },
				],
			}),
		).toEqual({ collapsible: true, items: [{ time: 10, description: 'Вступление' }] })
	})
})
