import type { MaterialVideoChapters } from '../types'

export function formatVideoChapterTime(seconds: number) {
	const safeSeconds = Math.max(0, Math.floor(Number.isFinite(seconds) ? seconds : 0))
	return `${Math.floor(safeSeconds / 60)
		.toString()
		.padStart(2, '0')}:${(safeSeconds % 60).toString().padStart(2, '0')}`
}

export function parseVideoChapterTime(value: string) {
	const match = /^(\d{1,3}):([0-5]\d)$/.exec(value.trim())
	if (!match) return null
	return Number(match[1]) * 60 + Number(match[2])
}

export function normalizeVideoChapters(value: unknown): MaterialVideoChapters | undefined {
	if (!value || typeof value !== 'object') return undefined
	const raw = value as Partial<MaterialVideoChapters>
	if (!Array.isArray(raw.items)) return undefined

	return {
		collapsible: raw.collapsible === true,
		items: raw.items.flatMap((item) => {
			if (!item || typeof item !== 'object') return []
			const chapter = item as { time?: unknown; description?: unknown }
			const time = Number(chapter.time)
			const description = typeof chapter.description === 'string' ? chapter.description.trim() : ''
			return Number.isFinite(time) && time >= 0 && description
				? [{ time: Math.floor(time), description }]
				: []
		}),
	}
}
