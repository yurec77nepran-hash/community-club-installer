import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const configPath = new URL('./drizzle.config.ts', import.meta.url)

describe('drizzle config', () => {
	test('loads schema through the explicit barrel file instead of the whole folder', async () => {
		const config = await readFile(configPath, 'utf8')

		expect(config).toContain("schema: '../shared/src/db/schema/index.ts'")
		expect(config).not.toContain("schema: '../shared/src/db/schema'")
	})
})
