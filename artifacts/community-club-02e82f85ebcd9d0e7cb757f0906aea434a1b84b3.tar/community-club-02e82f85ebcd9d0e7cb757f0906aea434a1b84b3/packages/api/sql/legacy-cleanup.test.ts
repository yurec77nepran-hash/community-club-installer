import { describe, expect, test } from 'bun:test'
import { readFile, readdir } from 'node:fs/promises'

const sqlDir = new URL('./', import.meta.url)

describe('sql legacy cleanup', () => {
	test('does not keep removed integration columns in sql bootstraps', async () => {
		const removedIntegration = ['get', 'course'].join('')
		const removedColumn = `${removedIntegration}_found`
		const entries = await readdir(sqlDir)
		const sqlFiles = entries.filter((entry) => entry.endsWith('.sql'))

		for (const fileName of sqlFiles) {
			const file = await readFile(new URL(fileName, sqlDir), 'utf8')

			expect(file.toLowerCase()).not.toContain(removedIntegration)
			expect(file.toLowerCase()).not.toContain(removedColumn)
		}
	})
})
