-- Телефон — основной идентификатор входа; один номер = один аккаунт.
-- Частичный индекс: NULL и пустые значения не учитываются.
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique_idx
	ON users (phone)
	WHERE phone IS NOT NULL AND btrim(phone) <> '';