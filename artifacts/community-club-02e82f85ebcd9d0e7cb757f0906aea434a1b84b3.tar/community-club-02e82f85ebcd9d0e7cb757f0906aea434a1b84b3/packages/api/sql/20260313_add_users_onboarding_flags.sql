ALTER TABLE users
	ADD COLUMN IF NOT EXISTS first_entry boolean NOT NULL DEFAULT false;
