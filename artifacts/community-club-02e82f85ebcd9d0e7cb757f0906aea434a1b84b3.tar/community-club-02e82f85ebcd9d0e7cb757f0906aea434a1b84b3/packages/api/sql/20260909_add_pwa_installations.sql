CREATE TABLE IF NOT EXISTS pwa_installations (
	user_auth_uuid uuid PRIMARY KEY REFERENCES users(auth_uuid) ON DELETE CASCADE,
	first_launched_at timestamptz NOT NULL DEFAULT now(),
	last_launched_at timestamptz NOT NULL DEFAULT now(),
	launch_count integer NOT NULL DEFAULT 1,
	user_agent text,
	platform text,
	device_label text,
	created_at timestamptz NOT NULL DEFAULT now(),
	updated_at timestamptz NOT NULL DEFAULT now(),
	CONSTRAINT pwa_installations_launch_count_positive CHECK (launch_count > 0)
);
