import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { requestId } from 'hono/request-id'
import { secureHeaders } from 'hono/secure-headers'
import { env } from './config/env'
import type { ClubAccessMap } from './lib/materials-access'
import { getPerformanceMetricsSnapshot } from './lib/performance-metrics'
import { authMiddleware } from './middleware/auth'
import { csrfMiddleware } from './middleware/csrf'
import { errorHandler } from './middleware/error-handler'
import { getQueueStats, queueMiddleware } from './middleware/queue'
import { rateLimit } from './middleware/rate-limit'
import { readOnlyMiddleware } from './middleware/read-only'
import { requestProfiler } from './middleware/request-profiler'
import { adminRoutes } from './routes/admin'
import { adminMessengerBroadcastRoutes } from './routes/admin-messenger-broadcasts'
import { adminNotificationRoutes } from './routes/admin-notifications'
import { adminTelegramBroadcastRoutes } from './routes/admin-telegram-broadcasts'
import { adminUserMessengerRoutes } from './routes/admin-user-messengers'
import { authRoutes } from './routes/auth'
import { channelRoutes } from './routes/channels'
import { chatRoutes } from './routes/chats'
import { demoAccessRoutes } from './routes/demo-access'
import { eventRoutes } from './routes/events'
import { feedRoutes } from './routes/feed'
import { homeRoutes } from './routes/home'
import { materialRoutes } from './routes/materials'
import { mediaRoutes } from './routes/media'
import { messengerWebhookRoutes } from './routes/messenger-webhooks'
import { paymentRoutes } from './routes/payments'
import { pushRoutes } from './routes/push'
import { pwaRoutes } from './routes/pwa'
import { referralRoutes } from './routes/referrals'
import { siteSettingsRoutes } from './routes/site-settings'
import { supportRoutes } from './routes/support'
import { telegramRoutes } from './routes/telegram'
import { userRoutes } from './routes/users'

// Типы контекста Hono
export type AppEnv = {
	Variables: {
		userId: string
		userEmail: string | null
		userRole: string
		adminPermissions: string[] | null
		userContentSections: string[]
		clubAccess: ClubAccessMap
		hasActiveSubscription: boolean
	}
}

const app = new Hono<AppEnv>()

function getUrlOrigin(value: string): string | null {
	try {
		return new URL(value).origin
	} catch {
		return null
	}
}

const corsOrigins = Array.from(
	new Set([env.APP_URL, env.ADMIN_URL].map(getUrlOrigin).filter((origin) => origin !== null)),
)

// Глобальные middleware
app.use('*', requestId())
app.use('*', secureHeaders())
app.use(
	'*',
	cors({
		origin: corsOrigins,
		credentials: true,
		allowHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token'],
		allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
	}),
)

// Глобальный лимит держим мягким: мобильные сети часто сажают много клиентов за один NAT.
app.use('/api/*', rateLimit({ windowMs: 60_000, max: 600, keyPrefix: 'rl:global' }))
app.use('/api/*', csrfMiddleware)

// Read-only режим для staging: mutation-эндпоинты закрыты, кроме login/refresh/logout.
app.use('/api/*', readOnlyMiddleware)

// Очередь запросов — защита от перегрузки
app.use('/api/*', queueMiddleware())
app.use('/api/*', requestProfiler)

// Error handler
app.onError(errorHandler)

// Health check
app.get('/health', (c) =>
	c.json({
		status: 'ok',
		timestamp: Date.now(),
	}),
)

app.get('/metrics', authMiddleware, (c) => {
	const role = c.get('userRole')
	if (role !== 'admin' && role !== 'superadmin') {
		return c.json(
			{ success: false, error: { code: 'FORBIDDEN', message: 'Недостаточно прав доступа' } },
			403,
		)
	}

	return c.json({
		status: 'ok',
		timestamp: Date.now(),
		queue: getQueueStats(),
		performance: getPerformanceMetricsSnapshot(),
	})
})

// Routes
app.route('/api/auth', authRoutes)
app.route('/api/auth', demoAccessRoutes)
app.route('/api/users', userRoutes)
app.route('/api/home', homeRoutes)
app.route('/api/materials', materialRoutes)
app.route('/api/chats', chatRoutes)
app.route('/api/channels', channelRoutes)
app.route('/api/feed', feedRoutes)
app.route('/api/support', supportRoutes)
app.route('/api/telegram', telegramRoutes)
app.route('/api/messenger-webhooks', messengerWebhookRoutes)
app.route('/api/payments', paymentRoutes)
app.route('/api/media', mediaRoutes)
app.route('/api/push', pushRoutes)
app.route('/api/pwa', pwaRoutes)
app.route('/api/site-settings', siteSettingsRoutes)
app.route('/api/admin', adminRoutes)
app.route('/api/admin/notifications', adminNotificationRoutes)
app.route('/api/admin/broadcasts', adminMessengerBroadcastRoutes)
app.route('/api/admin/telegram-broadcasts', adminTelegramBroadcastRoutes)
app.route('/api/admin/users', adminUserMessengerRoutes)
app.route('/api/events', eventRoutes)
app.route('/api/referrals', referralRoutes)

// 404
app.notFound((c) =>
	c.json(
		{
			success: false,
			error: { code: 'NOT_FOUND', message: 'Страница или маршрут не найдены' },
		},
		404,
	),
)

export { app }
