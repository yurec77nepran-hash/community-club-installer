import { readFile } from 'node:fs/promises'
import { telegramContacts, users } from '@community-club/shared'
import { inArray, sql } from 'drizzle-orm'
import { db, queryClient } from '../db/client'
import { parseTelegramImportDump } from '../lib/telegram-import'

const sourcePath = Bun.argv[2]
if (!sourcePath) throw new Error('Usage: bun run src/scripts/import-telegram-users.ts <dump.sql>')

const rows = parseTelegramImportDump(await readFile(sourcePath, 'utf8'))
if (!rows.length) throw new Error('No supported Telegram contacts found in dump')

const telegramUserIds = [...new Set(rows.map((row) => row.telegramUserId))]
const existing = new Map<string, string>()
for (const row of await queryClient.unsafe<{ telegram_user_id: string; user_auth_uuid: string }[]>(
	'SELECT telegram_user_id, user_auth_uuid FROM telegram_contacts',
)) {
	existing.set(row.telegram_user_id, row.user_auth_uuid)
}
for (const row of await queryClient.unsafe<{ telegram_chat_id: string; auth_uuid: string }[]>(
	'SELECT telegram_chat_id, auth_uuid FROM users WHERE telegram_chat_id IS NOT NULL',
)) {
	if (!existing.has(row.telegram_chat_id)) existing.set(row.telegram_chat_id, row.auth_uuid)
}

const newUsers = telegramUserIds
	.filter((telegramUserId) => !existing.has(telegramUserId))
	.map((telegramUserId) => ({ authUuid: crypto.randomUUID(), telegramUserId }))
for (const user of newUsers) existing.set(user.telegramUserId, user.authUuid)

const contactsToImport = rows.map((row) => {
	const userAuthUuid = existing.get(row.telegramUserId)
	if (!userAuthUuid)
		throw new Error(`User mapping is missing for Telegram ID ${row.telegramUserId}`)
	return {
		userAuthUuid,
		botUsername: row.botUsername,
		telegramUserId: row.telegramUserId,
		sourceCreatedAt: row.sourceCreatedAt,
	}
})

await db.transaction(async (tx) => {
	if (newUsers.length) {
		await tx.insert(users).values(
			newUsers.map(({ authUuid }) => ({
				authUuid,
				authType: null,
				firstEntry: false,
				onboardingSeen: true,
			})),
		)
	}
	await tx.insert(telegramContacts).values(contactsToImport).onConflictDoNothing()
})

const [contacts] = await db.execute<{ count: number }>(sql`
	SELECT count(*)::integer AS count
	FROM telegram_contacts
	WHERE ${inArray(telegramContacts.telegramUserId, telegramUserIds)}
`)
console.log(
	JSON.stringify({
		sourceRows: rows.length,
		newUsers: newUsers.length,
		importedContacts: contacts?.count ?? 0,
	}),
)
