import { createMiddleware } from 'hono/factory'
import type { AppEnv } from '../app'

/**
 * Семафор-очередь: ограничивает количество одновременно обрабатываемых запросов.
 * Когда лимит достигнут, новые запросы встают в очередь и ждут.
 * Если очередь тоже переполнена — отвечаем 503.
 */
class RequestQueue {
	private running = 0
	private queue: (() => void)[] = []

	constructor(
		private maxConcurrent: number,
		private maxQueue: number,
		private timeoutMs: number,
	) {}

	async acquire(): Promise<boolean> {
		if (this.running < this.maxConcurrent) {
			this.running++
			return true
		}

		if (this.queue.length >= this.maxQueue) {
			return false // очередь переполнена
		}

		// Ставим в очередь с таймаутом
		return new Promise<boolean>((resolve) => {
			const timer = setTimeout(() => {
				const idx = this.queue.indexOf(cb)
				if (idx !== -1) this.queue.splice(idx, 1)
				resolve(false)
			}, this.timeoutMs)

			const cb = () => {
				clearTimeout(timer)
				this.running++
				resolve(true)
			}
			this.queue.push(cb)
		})
	}

	release() {
		this.running--
		if (this.queue.length > 0) {
			const next = this.queue.shift()
			next?.()
		}
	}

	get stats() {
		return { running: this.running, queued: this.queue.length }
	}
}

// Разделяем read и mutation трафик, чтобы быстрые чтения не стояли за записями.
const apiReadQueue = new RequestQueue(150, 1000, 5000)

const apiMutationQueue = new RequestQueue(60, 400, 15000)

// Отдельная очередь для тяжёлых операций (загрузка файлов)
const uploadQueue = new RequestQueue(
	5, // макс 5 одновременных загрузок
	20, // макс 20 в очереди
	60000, // таймаут 60 сек (файлы большие)
)

export function queueMiddleware() {
	return createMiddleware<AppEnv>(async (c, next) => {
		const isReadRequest = c.req.method === 'GET' || c.req.method === 'HEAD'
		const queue = isReadRequest ? apiReadQueue : apiMutationQueue
		const acquired = await queue.acquire()
		if (!acquired) {
			return c.json(
				{
					success: false,
					error: {
						code: 'SERVICE_BUSY',
						message: 'Сервер перегружен, попробуйте через несколько секунд',
					},
				},
				503,
			)
		}
		try {
			await next()
		} finally {
			queue.release()
		}
	})
}

export function uploadQueueMiddleware() {
	return createMiddleware<AppEnv>(async (c, next) => {
		const acquired = await uploadQueue.acquire()
		if (!acquired) {
			return c.json(
				{
					success: false,
					error: { code: 'UPLOAD_BUSY', message: 'Очередь загрузки заполнена, подождите' },
				},
				503,
			)
		}
		try {
			await next()
		} finally {
			uploadQueue.release()
		}
	})
}

/** Статистика очередей для /health */
export function getQueueStats() {
	const read = apiReadQueue.stats
	const mutation = apiMutationQueue.stats
	return {
		api: {
			running: read.running + mutation.running,
			queued: read.queued + mutation.queued,
		},
		apiRead: read,
		apiMutation: mutation,
		upload: uploadQueue.stats,
	}
}
