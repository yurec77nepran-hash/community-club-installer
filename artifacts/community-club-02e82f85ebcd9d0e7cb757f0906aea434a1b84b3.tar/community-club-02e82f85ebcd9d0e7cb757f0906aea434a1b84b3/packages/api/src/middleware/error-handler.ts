import type { ErrorHandler } from 'hono'
import { HTTPException } from 'hono/http-exception'
import { ZodError } from 'zod'
import { logger } from '../lib/logger'

export const errorHandler: ErrorHandler = (err, c) => {
	if (err instanceof HTTPException) {
		const normalizedMessage =
			err.status >= 500
				? 'Системная ошибка. Обратитесь в поддержку.'
				: err.message && err.message !== 'Error'
					? err.message
					: 'Не удалось выполнить запрос. Попробуйте ещё раз.'
		return c.json(
			{ success: false, error: { code: 'HTTP_ERROR', message: normalizedMessage } },
			err.status,
		)
	}

	if (err instanceof ZodError) {
		return c.json(
			{
				success: false,
				error: {
					code: 'VALIDATION_ERROR',
					message: 'Проверьте заполненные поля и попробуйте ещё раз',
					details: err.errors.map((e) => ({
						path: e.path.join('.'),
						message: e.message,
					})),
				},
			},
			400,
		)
	}

	logger.error({ err }, 'Unhandled error')
	return c.json(
		{
			success: false,
			error: { code: 'INTERNAL_ERROR', message: 'Системная ошибка. Обратитесь в поддержку.' },
		},
		500,
	)
}
