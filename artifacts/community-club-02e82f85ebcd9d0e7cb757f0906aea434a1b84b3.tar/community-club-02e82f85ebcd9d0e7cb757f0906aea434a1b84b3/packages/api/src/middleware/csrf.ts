import { getCookie } from 'hono/cookie'
import { createMiddleware } from 'hono/factory'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { validateBrowserMutation } from '../lib/csrf-security'

function getUrlOrigin(value: string) {
	try {
		return new URL(value).origin
	} catch {
		return null
	}
}

const allowedOrigins = Array.from(
	new Set(
		[env.APP_URL, env.ADMIN_URL]
			.map(getUrlOrigin)
			.filter((origin): origin is string => Boolean(origin)),
	),
)

export const csrfMiddleware = createMiddleware<AppEnv>(async (c, next) => {
	const result = validateBrowserMutation({
		method: c.req.method,
		path: c.req.path,
		hasCookieAuth: Boolean(getCookie(c, 'access_token') || getCookie(c, 'refresh_token')),
		origin: c.req.header('origin') ?? null,
		referer: c.req.header('referer') ?? null,
		csrfCookie: getCookie(c, 'csrf_token') ?? null,
		csrfHeader: c.req.header('x-csrf-token') ?? null,
		allowedOrigins,
	})

	if (!result.ok) {
		return c.json(
			{
				success: false,
				error: {
					code: 'CSRF_REJECTED',
					message: 'Сессия устарела. Обновите страницу и попробуйте ещё раз.',
				},
			},
			403,
		)
	}

	await next()
})
