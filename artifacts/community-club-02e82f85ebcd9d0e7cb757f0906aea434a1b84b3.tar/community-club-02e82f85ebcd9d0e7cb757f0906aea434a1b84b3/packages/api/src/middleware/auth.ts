import { users } from '@community-club/shared'
import { eq } from 'drizzle-orm'
import { getCookie } from 'hono/cookie'
import { createMiddleware } from 'hono/factory'
import { jwtVerify } from 'jose'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db } from '../db/client'
import { setAuthCookies } from '../lib/auth-session'
import { resolveAccessTokenSource } from '../lib/auth-token-source'
import { buildClubAccessMap } from '../lib/materials-access'
import { findLatestPaymentForAccess, hasActiveDateFinish } from '../lib/subscription-access'

const secret = new TextEncoder().encode(env.JWT_SECRET)

export const authMiddleware = createMiddleware<AppEnv>(async (c, next) => {
	const header = c.req.header('Authorization')
	const headerToken = header?.startsWith('Bearer ') ? header.slice(7) : null
	const cookieToken = getCookie(c, 'access_token')
	const cookieRefreshToken = getCookie(c, 'refresh_token')
	const token = resolveAccessTokenSource({ cookieToken, headerToken })

	if (!token) {
		return c.json(
			{ success: false, error: { code: 'UNAUTHORIZED', message: 'Нужна авторизация' } },
			401,
		)
	}

	try {
		const { payload } = await jwtVerify(token, secret)
		const userId = payload.sub as string

		// Получаем актуальную роль из БД
		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, userId),
			columns: {
				role: true,
				email: true,
				adminPermissions: true,
			},
		})

		if (!user) {
			return c.json(
				{ success: false, error: { code: 'UNAUTHORIZED', message: 'Пользователь не найден' } },
				401,
			)
		}

		const payment = await findLatestPaymentForAccess({
			userAuthUuid: userId,
			email: user.email ?? null,
		})
		const isAdmin = user.role === 'admin' || user.role === 'superadmin'

		c.set('userId', userId)
		c.set('userEmail', user.email ?? null)
		c.set('userRole', user.role)
		c.set('adminPermissions', user.adminPermissions ?? null)
		c.set('userContentSections', [])
		c.set('clubAccess', buildClubAccessMap())
		c.set('hasActiveSubscription', isAdmin || hasActiveDateFinish(payment?.dateFinish ?? null))
		await next()
		if (token === cookieToken && cookieRefreshToken && c.res.status < 400) {
			setAuthCookies(c, { accessToken: cookieToken, refreshToken: cookieRefreshToken })
		}
	} catch {
		return c.json(
			{ success: false, error: { code: 'UNAUTHORIZED', message: 'Сессия недействительна' } },
			401,
		)
	}
})

// Middleware для проверки роли admin/superadmin
export const adminMiddleware = createMiddleware<AppEnv>(async (c, next) => {
	const role = c.get('userRole')
	if (role !== 'admin' && role !== 'superadmin') {
		return c.json(
			{ success: false, error: { code: 'FORBIDDEN', message: 'Недостаточно прав доступа' } },
			403,
		)
	}

	if (role === 'admin') {
		const permissions = c.get('adminPermissions')
		if (permissions !== null) {
			const needed = getAdminPermissionForRequestPath(c.req.path)
			if (!permissions.includes(needed)) {
				return c.json(
					{ success: false, error: { code: 'FORBIDDEN', message: 'Раздел недоступен' } },
					403,
				)
			}
		}
	}

	await next()
})

export function getAdminPermissionForRequestPath(path: string) {
	if (path.startsWith('/api/admin-notifications') || path.startsWith('/api/push')) {
		return 'notifications'
	}
	if (path.startsWith('/api/support')) return 'support'
	if (path.startsWith('/api/events')) return 'events'
	if (path.startsWith('/api/media')) return 'media'
	if (path.startsWith('/api/channels')) return 'feed'

	const normalized = path.replace(/^\/api\/admin\/?/, '')
	const first = normalized.split('/')[0] || ''
	if (first === 'user-actions') return 'userActions'
	if (first.startsWith('user')) return 'users'
	if (first === 'support') return 'support'
	if (first === 'events') return 'events'
	if (first.startsWith('material')) return 'materials'
	if (first.startsWith('media')) return 'media'
	if (first === 'chats') return 'chats'
	if (first === 'payment-providers' || first === 'payments' || first === 'payment-logs') {
		return 'payments'
	}
	if (first === 'legal-documents') return 'documents'
	if (['branding', 'runtime-settings', 'auth-login-settings', 'domain'].includes(first)) {
		return 'settings'
	}
	if (first === 'activity-logs') return 'staffActions'
	if (first.startsWith('feed')) return 'feed'
	if (first === 'replies') return 'replies'
	if (first === 'tariffs') return 'tariffs'
	if (first === 'notifications') return 'notifications'
	if (first === 'stats' || first === '') {
		return 'analytics'
	}
	return 'settings'
}

export const activeSubscriptionMiddleware = createMiddleware<AppEnv>(async (c, next) => {
	const role = c.get('userRole')
	if (role === 'admin' || role === 'superadmin' || c.get('hasActiveSubscription')) {
		await next()
		return
	}

	return c.json(
		{
			success: false,
			error: {
				code: 'SUBSCRIPTION_EXPIRED',
				message: 'Подписка закончилась. Продлите доступ, чтобы продолжить.',
			},
		},
		403,
	)
})
