import { createMiddleware } from 'hono/factory'
import type { AppEnv } from '../app'
import { redis } from '../lib/redis'

interface RateLimitOptions {
	windowMs: number
	max: number
	keyPrefix?: string
}

export function rateLimit(options: RateLimitOptions) {
	const { windowMs, max, keyPrefix = 'rl' } = options
	const windowSec = Math.ceil(windowMs / 1000)

	return createMiddleware<AppEnv>(async (c, next) => {
		const forwardedFor = c.req.header('x-forwarded-for')?.split(',')[0]?.trim()
		const identifier = c.get('userId') ?? c.req.header('x-real-ip') ?? forwardedFor ?? 'anon'
		const key = `${keyPrefix}:${identifier}`

		const current = await redis.incr(key)
		if (current === 1) {
			await redis.expire(key, windowSec)
		}

		c.header('X-RateLimit-Limit', String(max))
		c.header('X-RateLimit-Remaining', String(Math.max(0, max - current)))

		if (current > max) {
			return c.json(
				{
					success: false,
					error: {
						code: 'RATE_LIMITED',
						message: 'Слишком много запросов. Попробуйте ещё раз чуть позже.',
					},
				},
				429,
			)
		}

		await next()
	})
}
