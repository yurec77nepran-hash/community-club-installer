import type { MiddlewareHandler } from 'hono'
import { env } from '../config/env'
import { logger } from '../lib/logger'
import { recordHttpMetric } from '../lib/performance-metrics'

export const requestProfiler: MiddlewareHandler = async (c, next) => {
	const startedAt = performance.now()
	await next()
	const path = new URL(c.req.url).pathname
	const durationMs = Math.round(performance.now() - startedAt)
	recordHttpMetric({
		method: c.req.method,
		path,
		status: c.res.status,
		durationMs,
	})
	if (durationMs < env.SLOW_HTTP_REQUEST_MS) return

	logger.warn(
		{
			method: c.req.method,
			path,
			status: c.res.status,
			durationMs,
			userId: c.get('userId'),
			requestId: c.get('requestId'),
		},
		'Slow HTTP request detected',
	)
}
