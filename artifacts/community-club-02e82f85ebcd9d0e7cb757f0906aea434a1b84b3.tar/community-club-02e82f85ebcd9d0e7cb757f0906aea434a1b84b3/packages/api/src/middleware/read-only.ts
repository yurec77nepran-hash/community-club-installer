import { createMiddleware } from 'hono/factory'
import type { AppEnv } from '../app'
import { env } from '../config/env'

const READ_ONLY_ALLOWED_MUTATIONS = new Set([
	'POST /api/auth/login',
	'POST /api/auth/refresh',
	'POST /api/auth/logout',
])

export const readOnlyMiddleware = createMiddleware<AppEnv>(async (c, next) => {
	if (!env.APP_READ_ONLY) {
		await next()
		return
	}

	const method = c.req.method.toUpperCase()
	if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
		await next()
		return
	}

	const key = `${method} ${new URL(c.req.url).pathname}`
	if (READ_ONLY_ALLOWED_MUTATIONS.has(key)) {
		await next()
		return
	}

	return c.json(
		{
			success: false,
			error: {
				code: 'READ_ONLY_MODE',
				message: 'Стенд работает в режиме только для чтения. Изменения данных отключены.',
			},
		},
		403,
	)
})
