import { describe, expect, test } from 'bun:test'
import { getAdminPermissionForRequestPath } from './auth'

describe('admin permission routing', () => {
	test('routes admin chat settings to the chats permission', () => {
		expect(getAdminPermissionForRequestPath('/api/admin/chats')).toBe('chats')
		expect(getAdminPermissionForRequestPath('/api/admin/chats/1')).toBe('chats')
	})

	test('routes user action feed to the userActions permission', () => {
		expect(getAdminPermissionForRequestPath('/api/admin/user-actions')).toBe('userActions')
	})

	test('routes legal documents to the documents permission', () => {
		expect(getAdminPermissionForRequestPath('/api/admin/legal-documents')).toBe('documents')
	})
})
