import { z } from 'zod'

const envSchema = z.object({
	// Database
	DATABASE_URL: z.string(),

	// Redis
	REDIS_URL: z.string().default('redis://localhost:6379'),

	// JWT Auth
	JWT_SECRET: z.string().min(32),
	JWT_EXPIRES_IN: z.string().default('1h'),
	JWT_REFRESH_EXPIRES_IN: z.string().default('30d'),

	// S3 Storage (Garage)
	S3_ENDPOINT: z.string().default('http://garage:3900'),
	S3_REGION: z.string().default('garage'),
	S3_ACCESS_KEY: z.string().default(''),
	S3_SECRET_KEY: z.string().default(''),
	S3_BUCKET_MEDIA: z.string().default('media'),
	S3_BUCKET_CHAT: z.string().default('chat-attachments'),
	S3_BUCKET_AVATARS: z.string().default('avatars'),
	S3_PUBLIC_URL: z.string().default(''),

	// CloudPayments
	CLOUDPAYMENTS_PUBLIC_ID: z.string().default(''),
	CLOUDPAYMENTS_API_SECRET: z.string().default(''),

	// Push (VAPID)
	VAPID_PUBLIC_KEY: z.string().default(''),
	VAPID_PRIVATE_KEY: z.string().default(''),
	VAPID_EMAIL: z.string().default('mailto:admin@example.com'),

	// Email
	MAIL_PROVIDER: z.enum(['log', 'smtp']).default('log'),
	MAIL_FROM_EMAIL: z.string().default('noreply@mail.example.com'),
	MAIL_FROM_NAME: z.string().default('Community Club'),
	MAIL_REPLY_TO: z.string().default(''),
	SMTP_HOST: z.string().default('localhost'),
	SMTP_PORT: z.coerce.number().int().positive().default(587),
	SMTP_SECURE: z
		.enum(['true', 'false'])
		.default('false')
		.transform((value) => value === 'true'),
	SMTP_USER: z.string().default(''),
	SMTP_PASSWORD: z.string().default(''),
	SMTP_ALLOW_INVALID_CERTS: z
		.enum(['true', 'false'])
		.default('false')
		.transform((value) => value === 'true'),

	// Telegram
	TELEGRAM_BOT_TOKEN: z.string().default(''),
	TELEGRAM_AUDIO_BOT_TOKEN: z.string().default(''),
	TELEGRAM_BROADCAST_BOTS: z.string().default(''),
	SUPPORT_TELEGRAM_CHAT_ID: z.string().default(''),
	TELEGRAM_SOCKS5_PROXY: z.string().default(''),
	TELEGRAM_SYNC_WEBHOOK: z
		.enum(['true', 'false'])
		.default('false')
		.transform((value) => value === 'true'),

	// MAX messenger
	MAX_BOT_TOKEN: z.string().default(''),
	MAX_API_URL: z.string().default('https://platform-api2.max.ru'),

	// App
	APP_URL: z.string().default('http://localhost:3000'),
	API_URL: z.string().default('http://localhost:3001'),
	ADMIN_URL: z.string().default('http://localhost:3002/admin'),
	PORT: z.coerce.number().default(3001),
	APP_READ_ONLY: z
		.enum(['true', 'false'])
		.default('false')
		.transform((value) => value === 'true'),

	// Custom domain provisioning through host Caddy.
	DOMAIN_PROVISION_ENABLED: z
		.enum(['true', 'false'])
		.default('false')
		.transform((value) => value === 'true'),
	DOMAIN_PROVISION_CONFIG_PATH: z
		.string()
		.default('/etc/caddy/conf.d/community-club-domains.caddy'),
	DOMAIN_PROVISION_VALIDATE_COMMAND: z
		.string()
		.default('caddy validate --config /etc/caddy/Caddyfile'),
	DOMAIN_PROVISION_RELOAD_COMMAND: z.string().default('systemctl reload caddy'),
	DOMAIN_PROVISION_WEB_PORT: z.coerce.number().int().positive().default(3000),
	DOMAIN_PROVISION_API_PORT: z.coerce.number().int().positive().default(3001),
	DOMAIN_PROVISION_ADMIN_PORT: z.coerce.number().int().positive().default(3002),
	DOMAIN_PROVISION_MEDIA_PORT: z.coerce.number().int().positive().default(3902),
	DOMAIN_PROVISION_SMOKE_TIMEOUT_MS: z.coerce.number().int().positive().default(20000),
	DOMAIN_PROVISION_HELPER_URL: z.string().default(''),
	DOMAIN_PROVISION_HELPER_TOKEN: z.string().default(''),

	// Environment
	NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
	SLOW_DB_QUERY_MS: z.coerce.number().int().positive().default(250),
	SLOW_HTTP_REQUEST_MS: z.coerce.number().int().positive().default(800),
})

export type Env = z.infer<typeof envSchema>

function parseEnv(): Env {
	const result = envSchema.safeParse(Bun.env)
	if (!result.success) {
		console.error('Invalid environment variables:')
		for (const issue of result.error.issues) {
			console.error(`  ${issue.path.join('.')}: ${issue.message}`)
		}
		process.exit(1)
	}
	return result.data
}

export const env = parseEnv()
