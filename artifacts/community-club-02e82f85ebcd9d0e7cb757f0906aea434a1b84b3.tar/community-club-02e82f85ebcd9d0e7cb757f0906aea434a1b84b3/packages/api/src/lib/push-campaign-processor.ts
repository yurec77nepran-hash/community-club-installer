import { pushCampaignRuns, pushCampaigns } from '@community-club/shared'
import { and, asc, desc, eq, lte, or, sql } from 'drizzle-orm'
import { db } from '../db/client'
import { logger } from './logger'
import { getBillingTargetDateForOffset } from './push-campaign-processor-utils'
import { sendPushToUsers } from './push-notifications'

const PROCESSOR_INTERVAL_MS = 60_000
const PROCESSING_STALE_MS = 15 * 60_000
const AUDIENCE_FETCH_LIMIT = 20_000
const USER_CHUNK_SIZE = 200

let started = false
let tickRunning = false

type CampaignRecord = typeof pushCampaigns.$inferSelect

function chunk<T>(items: T[], size: number) {
	const result: T[][] = []
	for (let index = 0; index < items.length; index += size) {
		result.push(items.slice(index, index + size))
	}
	return result
}

function getMoscowDateString(date = new Date()) {
	return new Intl.DateTimeFormat('en-CA', {
		timeZone: 'Europe/Moscow',
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
	}).format(date)
}

function getRunKey(scheduledFor: string, offsetDays: number | null) {
	return `${scheduledFor}:${offsetDays == null ? 'one_time' : offsetDays}`
}

async function resolveAudienceUserIds(params: {
	audience: CampaignRecord['audience']
	billingTargetDate?: string
}) {
	const billingDateClause = params.billingTargetDate
		? sql`AND p.date_finish = ${params.billingTargetDate}`
		: sql``
	let audienceClause = sql``

	switch (params.audience) {
		case 'active':
			audienceClause = sql`AND p.date_finish IS NOT NULL AND p.date_finish >= ${getMoscowDateString()}`
			break
		default:
			audienceClause = sql``
	}

	const rows = await db.execute<{ user_auth_uuid: string }>(sql`
		SELECT DISTINCT u.auth_uuid AS user_auth_uuid
		FROM users u
		LEFT JOIN payments p ON p.user_auth_uuid = u.auth_uuid
		WHERE 1 = 1
		${billingDateClause}
		${audienceClause}
		ORDER BY u.auth_uuid
		LIMIT ${AUDIENCE_FETCH_LIMIT}
	`)

	return rows.map((row) => row.user_auth_uuid)
}

async function createRun(params: {
	campaignId: number
	scheduledFor: string
	offsetDays: number | null
}) {
	const runKey = getRunKey(params.scheduledFor, params.offsetDays)

	const inserted = await db
		.insert(pushCampaignRuns)
		.values({
			campaignId: params.campaignId,
			runKey,
			scheduledFor: params.scheduledFor,
			offsetDays: params.offsetDays,
			status: 'processing',
		})
		.onConflictDoNothing()
		.returning({ id: pushCampaignRuns.id })

	return inserted[0]?.id ?? null
}

async function finalizeRun(params: {
	runId: number
	status: 'completed' | 'failed'
	audienceSize: number
	subscriptionCount: number
	sentCount: number
	failedCount: number
	errorMessage?: string | null
}) {
	await db
		.update(pushCampaignRuns)
		.set({
			status: params.status,
			audienceSize: params.audienceSize,
			subscriptionCount: params.subscriptionCount,
			sentCount: params.sentCount,
			failedCount: params.failedCount,
			errorMessage: params.errorMessage ?? null,
			completedAt: new Date(),
		})
		.where(eq(pushCampaignRuns.id, params.runId))
}

async function updateCampaignAfterRun(params: {
	campaignId: number
	status: CampaignRecord['status']
	audienceSize: number
	sentCount: number
	failedCount: number
	errorMessage?: string | null
}) {
	await db
		.update(pushCampaigns)
		.set({
			status: params.status,
			lastRunAt: new Date(),
			lastRunAudienceSize: params.audienceSize,
			lastRunSent: params.sentCount,
			lastRunFailed: params.failedCount,
			lastError: params.errorMessage ?? null,
			processingStartedAt: null,
			updatedAt: new Date(),
		})
		.where(eq(pushCampaigns.id, params.campaignId))
}

async function executeCampaignRun(params: {
	campaign: CampaignRecord
	scheduledFor: string
	offsetDays: number | null
	billingTargetDate?: string
}) {
	const runId = await createRun({
		campaignId: params.campaign.id,
		scheduledFor: params.scheduledFor,
		offsetDays: params.offsetDays,
	})
	if (!runId) return

	const userIds = await resolveAudienceUserIds({
		audience: params.campaign.audience,
		billingTargetDate: params.billingTargetDate,
	})

	let sentCount = 0
	let failedCount = 0
	let subscriptionCount = 0

	for (const userChunk of chunk(userIds, USER_CHUNK_SIZE)) {
		const stats = await sendPushToUsers({
			userIds: userChunk,
			title: params.campaign.title,
			body: params.campaign.body,
			url: params.campaign.url ?? undefined,
			context: `campaign:${params.campaign.id}`,
		})
		sentCount += stats.sent
		failedCount += stats.failed
		subscriptionCount += stats.subscriptions
	}

	const runStatus = failedCount > 0 && sentCount === 0 ? 'failed' : 'completed'

	await finalizeRun({
		runId,
		status: runStatus,
		audienceSize: userIds.length,
		subscriptionCount,
		sentCount,
		failedCount,
		errorMessage: failedCount > 0 && sentCount === 0 ? 'Все отправки завершились ошибкой' : null,
	})

	await updateCampaignAfterRun({
		campaignId: params.campaign.id,
		status: params.campaign.kind === 'one_time' ? 'completed' : 'active',
		audienceSize: userIds.length,
		sentCount,
		failedCount,
		errorMessage: failedCount > 0 && sentCount === 0 ? 'Все отправки завершились ошибкой' : null,
	})
}

async function processOneTimeCampaign(campaign: CampaignRecord) {
	await db
		.update(pushCampaigns)
		.set({
			status: 'processing',
			processingStartedAt: new Date(),
			updatedAt: new Date(),
		})
		.where(eq(pushCampaigns.id, campaign.id))

	try {
		await executeCampaignRun({
			campaign,
			scheduledFor: getMoscowDateString(),
			offsetDays: null,
		})
	} catch (error) {
		const message = error instanceof Error ? error.message : 'Не удалось отправить push-кампанию'
		await updateCampaignAfterRun({
			campaignId: campaign.id,
			status: 'failed',
			audienceSize: 0,
			sentCount: 0,
			failedCount: 0,
			errorMessage: message,
		})
		logger.error(
			{ err: error, campaignId: campaign.id },
			'Failed to process one-time push campaign',
		)
	}
}

async function processRecurringCampaign(campaign: CampaignRecord) {
	const scheduledFor = getMoscowDateString()
	const offsets = Array.from(
		new Set((campaign.offsetDays ?? []).filter((value) => Number.isInteger(value))),
	)

	for (const offsetDays of offsets) {
		const billingTargetDate = getBillingTargetDateForOffset(scheduledFor, offsetDays)
		const runId = await createRun({
			campaignId: campaign.id,
			scheduledFor,
			offsetDays,
		})
		if (!runId) continue

		try {
			const userIds = await resolveAudienceUserIds({
				audience: campaign.audience,
				billingTargetDate,
			})

			let sentCount = 0
			let failedCount = 0
			let subscriptionCount = 0

			for (const userChunk of chunk(userIds, USER_CHUNK_SIZE)) {
				const stats = await sendPushToUsers({
					userIds: userChunk,
					title: campaign.title,
					body: campaign.body,
					url: campaign.url ?? undefined,
					context: `campaign:${campaign.id}:offset:${offsetDays}`,
				})
				sentCount += stats.sent
				failedCount += stats.failed
				subscriptionCount += stats.subscriptions
			}

			await finalizeRun({
				runId,
				status: failedCount > 0 && sentCount === 0 ? 'failed' : 'completed',
				audienceSize: userIds.length,
				subscriptionCount,
				sentCount,
				failedCount,
				errorMessage:
					failedCount > 0 && sentCount === 0 ? 'Все отправки завершились ошибкой' : null,
			})

			await updateCampaignAfterRun({
				campaignId: campaign.id,
				status: 'active',
				audienceSize: userIds.length,
				sentCount,
				failedCount,
				errorMessage:
					failedCount > 0 && sentCount === 0 ? 'Все отправки завершились ошибкой' : null,
			})
		} catch (error) {
			const message =
				error instanceof Error ? error.message : 'Не удалось обработать регулярную push-кампанию'
			await finalizeRun({
				runId,
				status: 'failed',
				audienceSize: 0,
				subscriptionCount: 0,
				sentCount: 0,
				failedCount: 0,
				errorMessage: message,
			})
			await updateCampaignAfterRun({
				campaignId: campaign.id,
				status: 'active',
				audienceSize: 0,
				sentCount: 0,
				failedCount: 0,
				errorMessage: message,
			})
			logger.error(
				{ err: error, campaignId: campaign.id, offsetDays },
				'Failed to process recurring push campaign',
			)
		}
	}
}

async function releaseStaleProcessingCampaigns() {
	const staleBefore = new Date(Date.now() - PROCESSING_STALE_MS)
	await db
		.update(pushCampaigns)
		.set({
			status: sql`CASE WHEN kind = 'one_time' THEN 'scheduled' ELSE 'active' END`,
			processingStartedAt: null,
			updatedAt: new Date(),
		})
		.where(
			and(
				eq(pushCampaigns.status, 'processing'),
				lte(pushCampaigns.processingStartedAt, staleBefore),
			),
		)
}

async function processCampaignTick() {
	if (tickRunning) return
	tickRunning = true

	try {
		await releaseStaleProcessingCampaigns()

		const dueOneTime = await db.query.pushCampaigns.findMany({
			where: and(
				eq(pushCampaigns.kind, 'one_time'),
				eq(pushCampaigns.isEnabled, true),
				or(
					and(eq(pushCampaigns.status, 'scheduled'), lte(pushCampaigns.sendAt, new Date())),
					eq(pushCampaigns.status, 'processing'),
				),
			),
			orderBy: [asc(pushCampaigns.sendAt)],
			limit: 10,
		})

		for (const campaign of dueOneTime) {
			await processOneTimeCampaign(campaign)
		}

		const recurring = await db.query.pushCampaigns.findMany({
			where: and(
				eq(pushCampaigns.kind, 'billing_relative'),
				eq(pushCampaigns.isEnabled, true),
				or(eq(pushCampaigns.status, 'active'), eq(pushCampaigns.status, 'processing')),
			),
			orderBy: [desc(pushCampaigns.updatedAt)],
			limit: 50,
		})

		for (const campaign of recurring) {
			await processRecurringCampaign(campaign)
		}
	} catch (error) {
		logger.error({ err: error }, 'Push campaign processor tick failed')
	} finally {
		tickRunning = false
	}
}

export function startPushCampaignProcessor() {
	if (started) return
	started = true
	void processCampaignTick()
	setInterval(() => {
		void processCampaignTick()
	}, PROCESSOR_INTERVAL_MS)
	logger.info({ intervalMs: PROCESSOR_INTERVAL_MS }, 'Push campaign processor started')
}
