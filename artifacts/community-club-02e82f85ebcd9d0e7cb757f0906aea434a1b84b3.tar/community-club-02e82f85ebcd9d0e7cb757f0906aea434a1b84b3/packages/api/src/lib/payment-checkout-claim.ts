import type { PaymentCheckoutSession } from './payment-checkout-session'

const CHECKOUT_PAYMENT_FRESHNESS_SKEW_MS = 30_000

type CheckoutPaymentLike = {
	tarrif: string | null
	amount: string | number | null
	createdAt: string | Date | null
	updatedAt: string | Date | null
}

type CheckoutPaymentLogLike = {
	orderId: string | null
	status: string | null
	createdAt: string | Date | null
}

function toTime(value: string | Date | null | undefined) {
	if (!value) return null
	const date = value instanceof Date ? value : new Date(value)
	const time = date.getTime()
	return Number.isFinite(time) ? time : null
}

export function toPaymentMinorUnits(value: unknown) {
	const parsed = Number(String(value ?? '').replace(',', '.'))
	if (!Number.isFinite(parsed)) return null
	return Math.round(parsed * 100)
}

export function paymentMatchesCheckoutSession(params: {
	session: PaymentCheckoutSession
	payment: CheckoutPaymentLike | null
	paymentLog: CheckoutPaymentLogLike | null
}) {
	const { session, payment, paymentLog } = params
	if (!payment || !paymentLog) return false
	if (!session.invoiceId || paymentLog.orderId !== session.invoiceId) return false
	if (paymentLog.status !== 'success') return false
	if (payment.tarrif !== session.tariffSlug) return false

	const expectedAmount = toPaymentMinorUnits(session.amount)
	const actualAmount = toPaymentMinorUnits(payment.amount)
	if (expectedAmount == null || actualAmount == null || expectedAmount !== actualAmount) {
		return false
	}

	const sessionCreatedAt = Number(session.createdAt)
	if (!Number.isFinite(sessionCreatedAt) || sessionCreatedAt <= 0) return false

	const paymentFreshTime = Math.max(toTime(payment.updatedAt) ?? 0, toTime(payment.createdAt) ?? 0)
	if (paymentFreshTime + CHECKOUT_PAYMENT_FRESHNESS_SKEW_MS < sessionCreatedAt) {
		return false
	}

	const logCreatedAt = toTime(paymentLog.createdAt)
	if (
		logCreatedAt != null &&
		logCreatedAt + CHECKOUT_PAYMENT_FRESHNESS_SKEW_MS < sessionCreatedAt
	) {
		return false
	}

	return true
}
