import { describe, expect, test } from 'bun:test'
import { buildManagedCaddyDomainConfig, smokeCheckHttps } from './domain-provisioning'

const validResponses = new Map<string, Response>([
	[
		'https://club.example.com/health',
		Response.json({ status: 'ok' }, { headers: { 'Content-Type': 'application/json' } }),
	],
	[
		'https://club.example.com/',
		new Response('<script type="module" src="/_nuxt/entry.js"></script>', {
			headers: { 'Content-Type': 'text/html' },
		}),
	],
	[
		'https://club.example.com/_nuxt/entry.js',
		new Response('console.log("ready")', {
			headers: { 'Content-Type': 'text/javascript; charset=utf-8' },
		}),
	],
	[
		'https://club.example.com/pwa-manifest',
		Response.json(
			{ name: 'Community Club', start_url: '/' },
			{ headers: { 'Content-Type': 'application/manifest+json' } },
		),
	],
])

function buildFetch(overrides = new Map<string, Response>()) {
	return async (input: string | URL | Request) => {
		const url = input instanceof Request ? input.url : String(input)
		const response = overrides.get(url) ?? validResponses.get(url)
		if (!response) throw new Error(`Unexpected URL: ${url}`)
		return response.clone()
	}
}

describe('domain provisioning', () => {
	test('builds a managed Caddy config for the custom domain', () => {
		const config = buildManagedCaddyDomainConfig('Club.Example.COM/')

		expect(config).toContain('club.example.com {')
		expect(config).toContain('reverse_proxy 127.0.0.1:3000')
		expect(config).toContain('reverse_proxy 127.0.0.1:3001')
		expect(config).toContain('reverse_proxy 127.0.0.1:3002')
		expect(config).toContain('reverse_proxy 127.0.0.1:3902')
		expect(config).toContain('request_body')
		expect(config).toContain('max_size 3GB')
		expect(config).toContain('flush_interval -1')
		expect(config).toMatch(/handle \{\s+reverse_proxy 127\.0\.0\.1:3000\s+\}/)
		expect(config).not.toContain('reverse_proxy / 127.0.0.1:3000')
	})

	test('rejects unsafe domain values before writing Caddy config', () => {
		expect(() => buildManagedCaddyDomainConfig('example.com; rm -rf /')).toThrow()
		expect(() => buildManagedCaddyDomainConfig('localhost')).toThrow()
	})

	test('accepts a domain only when health, Nuxt asset, and manifest are valid', async () => {
		const result = await smokeCheckHttps('club.example.com', buildFetch())

		expect(result).toEqual({ ok: true, status: 200, message: 'HTTPS отвечает' })
	})

	test('rejects an empty successful health response from Caddy', async () => {
		const result = await smokeCheckHttps(
			'club.example.com',
			buildFetch(new Map([['https://club.example.com/health', new Response('', { status: 200 })]])),
		)

		expect(result.ok).toBe(false)
		expect(result.message).toContain('/health')
	})

	test('rejects a Nuxt bundle without a JavaScript content type', async () => {
		const result = await smokeCheckHttps(
			'club.example.com',
			buildFetch(
				new Map([['https://club.example.com/_nuxt/entry.js', new Response('', { status: 200 })]]),
			),
		)

		expect(result.ok).toBe(false)
		expect(result.message).toContain('JavaScript')
	})

	test('rejects an empty successful PWA manifest response from Caddy', async () => {
		const result = await smokeCheckHttps(
			'club.example.com',
			buildFetch(
				new Map([['https://club.example.com/pwa-manifest', new Response('', { status: 200 })]]),
			),
		)

		expect(result.ok).toBe(false)
		expect(result.message).toContain('manifest')
	})
})
