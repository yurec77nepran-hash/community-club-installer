import { queryClient } from '../db/client'
import { DEFAULT_MATERIAL_TYPE_ENTRIES, LEGACY_MATERIAL_TYPE_ALIASES } from './material-types'

function sqlText(value: string) {
	return `'${value.replace(/'/g, "''")}'`
}

const defaultMaterialTypeBootstrapQueries = [
	`INSERT INTO material_types (key, label)
	VALUES ${DEFAULT_MATERIAL_TYPE_ENTRIES.map(
		(item) => `(${sqlText(item.key)}, ${sqlText(item.label)})`,
	).join(', ')}
	ON CONFLICT (key) DO NOTHING`,
	...Object.entries(LEGACY_MATERIAL_TYPE_ALIASES).flatMap(([legacyKey, canonicalKey]) => [
		`UPDATE materials SET type = ${sqlText(canonicalKey)} WHERE type = ${sqlText(legacyKey)}`,
		`DELETE FROM material_types WHERE key = ${sqlText(legacyKey)}`,
	]),
]

const performanceBootstrapQueries = [
	'ALTER TABLE materials ADD COLUMN IF NOT EXISTS video_cover_url text',
	'ALTER TABLE materials ADD COLUMN IF NOT EXISTS telegram_post_url text',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS game_role text',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS chat_admin_badge boolean NOT NULL DEFAULT false',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS social_links text[]',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS telegram_chat_id text',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS telegram_username text',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS telegram_notifications_enabled boolean NOT NULL DEFAULT false',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS max_messenger_user_id text',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS bonus_balance integer NOT NULL DEFAULT 0',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS admin_permissions jsonb DEFAULT null',
	'ALTER TABLE users ADD COLUMN IF NOT EXISTS onboarding_seen boolean NOT NULL DEFAULT true',
	'CREATE TABLE IF NOT EXISTS material_subsections (id serial PRIMARY KEY, title text NOT NULL, created_at timestamptz NOT NULL DEFAULT now())',
	'CREATE INDEX IF NOT EXISTS material_subsections_title_idx ON material_subsections (title)',
	'CREATE TABLE IF NOT EXISTS material_types (key text PRIMARY KEY, label text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now())',
	'CREATE INDEX IF NOT EXISTS material_types_label_idx ON material_types (label)',
	...defaultMaterialTypeBootstrapQueries,
	`CREATE TABLE IF NOT EXISTS bonus_transactions (
		id serial PRIMARY KEY,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		amount integer NOT NULL,
		source text NOT NULL,
		description text NOT NULL,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	'CREATE INDEX IF NOT EXISTS bonus_transactions_user_created_idx ON bonus_transactions (user_auth_uuid, created_at)',
	'CREATE INDEX IF NOT EXISTS bonus_transactions_source_idx ON bonus_transactions (source)',
	`CREATE TABLE IF NOT EXISTS club_missions (
		id serial PRIMARY KEY,
		user_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE CASCADE,
		slug text NOT NULL,
		name text NOT NULL,
		points integer NOT NULL,
		type text NOT NULL,
		completed_at timestamptz,
		active boolean NOT NULL DEFAULT true,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	'CREATE INDEX IF NOT EXISTS club_missions_user_idx ON club_missions (user_auth_uuid)',
	'CREATE INDEX IF NOT EXISTS club_missions_slug_idx ON club_missions (slug)',
	'CREATE INDEX IF NOT EXISTS payments_user_auth_uuid_idx ON payments (user_auth_uuid)',
	'CREATE INDEX IF NOT EXISTS payments_user_latest_idx ON payments (user_auth_uuid, updated_at DESC, date_finish DESC, created_at DESC, id DESC) WHERE user_auth_uuid IS NOT NULL',
	'CREATE INDEX IF NOT EXISTS payments_user_date_finish_idx ON payments (user_auth_uuid, date_finish)',
	'CREATE INDEX IF NOT EXISTS payments_email_date_finish_idx ON payments (email, date_finish)',
	'CREATE INDEX IF NOT EXISTS payments_cp_subscription_id_idx ON payments (cp_subscription_id)',
	'CREATE INDEX IF NOT EXISTS payments_date_finish_idx ON payments (date_finish)',
	'ALTER TABLE payment_logs ADD COLUMN IF NOT EXISTS idempotency_key text',
	'CREATE UNIQUE INDEX IF NOT EXISTS payment_logs_idempotency_key_unique ON payment_logs (idempotency_key) WHERE idempotency_key IS NOT NULL',
	'CREATE INDEX IF NOT EXISTS payment_logs_status_created_idx ON payment_logs (status, created_at DESC)',
	`CREATE TABLE IF NOT EXISTS push_subscriptions (
		id serial PRIMARY KEY,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		endpoint text NOT NULL,
		p256dh text NOT NULL,
		auth text NOT NULL,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS user_agent text',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS platform text',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS device_label text',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS permission text',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS expiration_time timestamptz',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS last_seen_at timestamptz NOT NULL DEFAULT now()',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS last_success_at timestamptz',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS last_failure_at timestamptz',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS failure_count integer NOT NULL DEFAULT 0',
	'ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now()',
	`DELETE FROM push_subscriptions
	WHERE id IN (
		SELECT id FROM (
			SELECT
				id,
				row_number() OVER (
					PARTITION BY endpoint
					ORDER BY COALESCE(updated_at, last_seen_at, created_at) DESC NULLS LAST, id DESC
				) AS duplicate_rank
			FROM push_subscriptions
		) ranked
		WHERE duplicate_rank > 1
	)`,
	'CREATE UNIQUE INDEX IF NOT EXISTS push_subscriptions_endpoint_unique ON push_subscriptions (endpoint)',
	'CREATE INDEX IF NOT EXISTS push_subscriptions_user_auth_uuid_idx ON push_subscriptions (user_auth_uuid)',
	'CREATE INDEX IF NOT EXISTS push_subscriptions_user_last_seen_idx ON push_subscriptions (user_auth_uuid, last_seen_at DESC)',
	`CREATE TABLE IF NOT EXISTS push_notifications (
		id bigserial PRIMARY KEY,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		title text NOT NULL,
		body text NOT NULL,
		url text,
		context text NOT NULL DEFAULT 'generic',
		payload jsonb DEFAULT null,
		delivered_at timestamptz,
		read_at timestamptz,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	'CREATE INDEX IF NOT EXISTS push_notifications_user_created_idx ON push_notifications (user_auth_uuid, created_at DESC)',
	'CREATE INDEX IF NOT EXISTS push_notifications_user_read_idx ON push_notifications (user_auth_uuid, read_at)',
	'CREATE INDEX IF NOT EXISTS events_event_date_idx ON events (event_date)',
	'CREATE INDEX IF NOT EXISTS users_role_idx ON users (role)',
	'CREATE INDEX IF NOT EXISTS users_email_idx ON users (email)',
	'CREATE INDEX IF NOT EXISTS users_created_at_idx ON users (created_at DESC)',
	'CREATE INDEX IF NOT EXISTS chat_members_user_chat_idx ON chat_members (user_auth_uuid, chat_id)',
	'CREATE INDEX IF NOT EXISTS chat_members_user_unread_messages_idx ON chat_members (user_auth_uuid, unread_message_count)',
	'CREATE INDEX IF NOT EXISTS chat_members_user_unread_mentions_idx ON chat_members (user_auth_uuid, unread_mention_count)',
	'CREATE INDEX IF NOT EXISTS messages_chat_deleted_created_idx ON messages (chat_id, is_deleted, created_at DESC, id DESC)',
	'CREATE INDEX IF NOT EXISTS message_mentions_user_message_idx ON message_mentions (mentioned_user_auth_uuid, message_id)',
	'CREATE INDEX IF NOT EXISTS materials_active_type_created_id_idx ON materials (active, type, created_at DESC, id DESC)',
	'CREATE INDEX IF NOT EXISTS materials_active_type_subsection_idx ON materials (active, type, subsection)',
	`CREATE TABLE IF NOT EXISTS material_media_progress (
		id serial PRIMARY KEY,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		material_id integer NOT NULL REFERENCES materials(id) ON DELETE CASCADE,
		media_file_index integer NOT NULL DEFAULT 0,
		position_seconds integer NOT NULL DEFAULT 0,
		duration_seconds integer,
		completed boolean NOT NULL DEFAULT false,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	'ALTER TABLE material_media_progress ADD COLUMN IF NOT EXISTS media_file_index integer NOT NULL DEFAULT 0',
	'DROP INDEX IF EXISTS material_media_progress_user_material_unique',
	'CREATE UNIQUE INDEX IF NOT EXISTS material_media_progress_user_material_unique ON material_media_progress (user_auth_uuid, material_id, media_file_index)',
	'CREATE INDEX IF NOT EXISTS material_media_progress_user_updated_idx ON material_media_progress (user_auth_uuid, updated_at)',
	'CREATE INDEX IF NOT EXISTS material_media_progress_material_idx ON material_media_progress (material_id)',
	'CREATE INDEX IF NOT EXISTS material_media_progress_user_material_updated_idx ON material_media_progress (user_auth_uuid, material_id, updated_at)',
	`CREATE TABLE IF NOT EXISTS admin_activity_logs (
		id bigserial PRIMARY KEY,
		actor_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
		actor_name text,
		actor_email text,
		action text NOT NULL,
		entity_type text NOT NULL,
		entity_id text,
		summary text NOT NULL,
		details jsonb DEFAULT null,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	'CREATE INDEX IF NOT EXISTS admin_activity_logs_created_idx ON admin_activity_logs (created_at DESC)',
	'CREATE INDEX IF NOT EXISTS admin_activity_logs_actor_idx ON admin_activity_logs (actor_auth_uuid)',
	'CREATE INDEX IF NOT EXISTS admin_activity_logs_entity_idx ON admin_activity_logs (entity_type, entity_id)',
]

export async function ensurePerformanceArtifacts() {
	for (const query of performanceBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
