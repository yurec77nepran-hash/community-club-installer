import { payments, users } from '@community-club/shared'
import { and, desc, eq, gte, or, sql } from 'drizzle-orm'
import { db } from '../db/client'
import { invalidateUserAccessCaches } from './cache-invalidation'
import {
	DEMO_ACCESS_TARIFF,
	classifyDemoAccessPayments,
	getDemoAccessWindow,
	normalizeDemoAccessEmail,
} from './demo-access'
import { loadTestAccessSettings } from './site-settings'
import { getMoscowDateString } from './subscription-access'

type DemoAccessIdentity =
	| { readonly kind: 'guest'; readonly email: string; readonly password: string }
	| { readonly kind: 'current'; readonly userAuthUuid: string }

type DemoAccessUser = {
	readonly authUuid: string
	readonly email: string | null
	readonly role: 'user' | 'admin' | 'superadmin'
}

type DemoAccessActivationResult =
	| { readonly kind: 'success'; readonly user: DemoAccessUser; readonly paymentCreated: boolean }
	| { readonly kind: 'disabled' }
	| { readonly kind: 'auth-error' }
	| { readonly kind: 'active-subscription' }
	| { readonly kind: 'user-not-found' }

export async function activateDemoAccess(
	identity: DemoAccessIdentity,
): Promise<DemoAccessActivationResult> {
	const settings = await loadTestAccessSettings()
	if (!settings.enabled) return { kind: 'disabled' }

	const activation = await db.transaction(async (tx): Promise<DemoAccessActivationResult> => {
		const currentUser =
			identity.kind === 'current'
				? await tx.query.users.findFirst({ where: eq(users.authUuid, identity.userAuthUuid) })
				: null
		if (identity.kind === 'current' && !currentUser?.email) return { kind: 'user-not-found' }

		const email = normalizeDemoAccessEmail(
			identity.kind === 'guest' ? identity.email : (currentUser?.email ?? ''),
		)
		await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${email}, 0))`)

		let user =
			identity.kind === 'guest'
				? await tx.query.users.findFirst({ where: eq(users.email, email) })
				: await tx.query.users.findFirst({ where: eq(users.authUuid, identity.userAuthUuid) })

		if (identity.kind === 'guest' && !user) {
			const passwordHash = await Bun.password.hash(identity.password, {
				algorithm: 'bcrypt',
				cost: 12,
			})
			const [created] = await tx
				.insert(users)
				.values({
					email,
					passwordHash,
					authType: 'email',
					role: 'user',
					firstEntry: true,
					onboardingSeen: false,
				})
				.onConflictDoNothing({ target: users.email })
				.returning()
			user = created ?? (await tx.query.users.findFirst({ where: eq(users.email, email) }))
		}
		if (!user?.email) return { kind: 'user-not-found' }

		if (identity.kind === 'guest') {
			if (user.role === 'admin' || user.role === 'superadmin' || !user.passwordHash) {
				return { kind: 'auth-error' }
			}
			const valid = await Bun.password.verify(identity.password, user.passwordHash)
			if (!valid) return { kind: 'auth-error' }
		}

		if (user.role === 'admin' || user.role === 'superadmin') {
			return {
				kind: 'success',
				user: { authUuid: user.authUuid, email: user.email, role: user.role },
				paymentCreated: false,
			}
		}

		const now = new Date()
		const today = getMoscowDateString(now)
		const relevantPayments = await tx.query.payments.findMany({
			where: and(
				or(eq(payments.userAuthUuid, user.authUuid), eq(payments.email, email)),
				gte(payments.dateFinish, today),
			),
			orderBy: [desc(payments.dateFinish), desc(payments.updatedAt), desc(payments.createdAt)],
		})
		const paymentClassification = classifyDemoAccessPayments(relevantPayments, today)
		if (paymentClassification === 'demo-active') {
			return {
				kind: 'success',
				user: { authUuid: user.authUuid, email: user.email, role: user.role },
				paymentCreated: false,
			}
		}
		if (paymentClassification === 'paid-active') return { kind: 'active-subscription' }

		await tx.insert(payments).values({
			userAuthUuid: user.authUuid,
			email,
			tarrif: DEMO_ACCESS_TARIFF,
			...getDemoAccessWindow(now, settings.days),
			amount: '0',
			autoPayment: false,
			noAutopodpiska: true,
		})

		return {
			kind: 'success',
			user: { authUuid: user.authUuid, email: user.email, role: user.role },
			paymentCreated: true,
		}
	})

	if (activation.kind === 'success' && activation.paymentCreated) {
		await invalidateUserAccessCaches(activation.user.authUuid)
	}
	return activation
}
