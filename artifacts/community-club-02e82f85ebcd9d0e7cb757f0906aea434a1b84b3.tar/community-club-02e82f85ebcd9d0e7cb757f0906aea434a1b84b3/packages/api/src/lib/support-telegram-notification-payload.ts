import type { TelegramSendMessageOptions } from './telegram'

const MEDIA_MESSAGE_TYPES = new Set(['image', 'video', 'voice', 'audio', 'document'])
const TELEGRAM_TEXT_LIMIT = 3900

function escapeTelegramHtml(value: string) {
	return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

function limitTelegramText(value: string, maxLength = TELEGRAM_TEXT_LIMIT) {
	const normalized = value.trim()
	if (normalized.length <= maxLength) return normalized
	return `${normalized.slice(0, maxLength - 1).trimEnd()}…`
}

function getSupportMessagePreview(params: { content: string; messageType: string }) {
	if (MEDIA_MESSAGE_TYPES.has(params.messageType)) return 'Есть вложение'
	return params.content.trim() || 'Новое сообщение'
}

export function buildSupportAdminDialogUrl(params: {
	appUrl: string
	chatId: number
	messageId: number
}) {
	const url = new URL(
		'/admin/support',
		params.appUrl.endsWith('/') ? params.appUrl : `${params.appUrl}/`,
	)
	url.searchParams.set('chatId', String(params.chatId))
	url.searchParams.set('messageId', String(params.messageId))
	return url.toString()
}

export function buildSupportTelegramNotificationPayload(params: {
	authorName: string
	authorEmail?: string | null
	content: string
	messageType: string
	adminDialogUrl: string
}): { text: string; replyMarkup: NonNullable<TelegramSendMessageOptions['replyMarkup']> } {
	const lines = [
		'<b>Новое сообщение в поддержку</b>',
		'',
		`<b>От:</b> ${escapeTelegramHtml(params.authorName.trim() || 'Участница')}`,
	]
	const email = params.authorEmail?.trim()
	if (email) {
		lines.push(`<b>Email:</b> ${escapeTelegramHtml(email)}`)
	}
	lines.push(
		'',
		'<b>Сообщение:</b>',
		escapeTelegramHtml(
			limitTelegramText(
				getSupportMessagePreview({
					content: params.content,
					messageType: params.messageType,
				}),
			),
		),
	)

	return {
		text: lines.join('\n'),
		replyMarkup: {
			inline_keyboard: [[{ text: 'Открыть диалог', url: params.adminDialogUrl }]],
		},
	}
}
