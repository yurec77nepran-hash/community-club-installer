import { pwaInstallations } from '@community-club/shared'
import type { PwaLaunchMetadata } from '@community-club/shared'
import { eq, sql } from 'drizzle-orm'
import type { Database } from '../db/client'

type PwaDatabase = Pick<Database, 'insert' | 'query'>

export type PwaLaunchRecord = {
	readonly firstLaunchedAt: Date
	readonly lastLaunchedAt: Date
	readonly launchCount: number
	readonly userAgent: string | null
	readonly platform: string | null
	readonly deviceLabel: string | null
}

export type RecordPwaLaunchInput = {
	readonly userAuthUuid: string
	readonly metadata: PwaLaunchMetadata
	readonly now: Date
}

export interface PwaLaunchHistoryStore {
	findByUser(userAuthUuid: string): Promise<PwaLaunchRecord | null>
	recordLaunch(input: Omit<RecordPwaLaunchInput, 'now'>): Promise<PwaLaunchRecord>
}

class PwaLaunchPersistenceError extends Error {
	constructor() {
		super('PostgreSQL did not return the recorded PWA launch')
		this.name = 'PwaLaunchPersistenceError'
	}
}

const selectedLaunchFields = {
	firstLaunchedAt: pwaInstallations.firstLaunchedAt,
	lastLaunchedAt: pwaInstallations.lastLaunchedAt,
	launchCount: pwaInstallations.launchCount,
	userAgent: pwaInstallations.userAgent,
	platform: pwaInstallations.platform,
	deviceLabel: pwaInstallations.deviceLabel,
} as const

export function buildPwaLaunchUpsert(database: PwaDatabase, input: RecordPwaLaunchInput) {
	return database
		.insert(pwaInstallations)
		.values({
			userAuthUuid: input.userAuthUuid,
			firstLaunchedAt: input.now,
			lastLaunchedAt: input.now,
			launchCount: 1,
			userAgent: input.metadata.userAgent ?? null,
			platform: input.metadata.platform ?? null,
			deviceLabel: input.metadata.deviceLabel ?? null,
			createdAt: input.now,
			updatedAt: input.now,
		})
		.onConflictDoUpdate({
			target: pwaInstallations.userAuthUuid,
			set: {
				lastLaunchedAt: input.now,
				launchCount: sql`${pwaInstallations.launchCount} + 1`,
				userAgent: input.metadata.userAgent ?? null,
				platform: input.metadata.platform ?? null,
				deviceLabel: input.metadata.deviceLabel ?? null,
				updatedAt: input.now,
			},
		})
		.returning(selectedLaunchFields)
}

export function createPwaLaunchHistoryStore(database: PwaDatabase): PwaLaunchHistoryStore {
	return {
		async findByUser(userAuthUuid) {
			return (
				(await database.query.pwaInstallations.findFirst({
					where: eq(pwaInstallations.userAuthUuid, userAuthUuid),
					columns: {
						firstLaunchedAt: true,
						lastLaunchedAt: true,
						launchCount: true,
						userAgent: true,
						platform: true,
						deviceLabel: true,
					},
				})) ?? null
			)
		},
		async recordLaunch(input) {
			const [record] = await buildPwaLaunchUpsert(database, { ...input, now: new Date() })
			if (!record) {
				throw new PwaLaunchPersistenceError()
			}
			return record
		},
	}
}
