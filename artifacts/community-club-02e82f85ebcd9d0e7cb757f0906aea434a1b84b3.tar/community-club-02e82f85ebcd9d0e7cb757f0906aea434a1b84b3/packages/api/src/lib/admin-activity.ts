import { adminActivityLogs, users } from '@community-club/shared'
import { eq } from 'drizzle-orm'
import { db } from '../db/client'

type Primitive = string | number | boolean | null

function normalizeValue(value: unknown): Primitive | Primitive[] | Record<string, unknown> | null {
	if (value === undefined) return null
	if (value === null) return null
	if (Array.isArray(value)) return value as Primitive[]
	if (typeof value === 'object') return value as Record<string, unknown>
	if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
		return value
	}
	return String(value)
}

export function buildChangedFields(
	before: Record<string, unknown> | null | undefined,
	after: Record<string, unknown> | null | undefined,
) {
	if (!before && !after) return {}
	const keys = new Set([...Object.keys(before ?? {}), ...Object.keys(after ?? {})])
	const changed: Record<string, { before: unknown; after: unknown }> = {}

	for (const key of keys) {
		const previous = before?.[key]
		const next = after?.[key]
		if (JSON.stringify(previous) === JSON.stringify(next)) continue
		changed[key] = {
			before: normalizeValue(previous),
			after: normalizeValue(next),
		}
	}

	return changed
}

export async function appendAdminActivityLog(params: {
	actorAuthUuid: string
	action: string
	entityType: string
	entityId?: string | number | null
	summary: string
	details?: Record<string, unknown> | null
}) {
	const actor = await db.query.users.findFirst({
		where: eq(users.authUuid, params.actorAuthUuid),
		columns: {
			authUuid: true,
			fullName: true,
			email: true,
		},
	})

	await db.insert(adminActivityLogs).values({
		actorAuthUuid: params.actorAuthUuid,
		actorName: actor?.fullName ?? null,
		actorEmail: actor?.email ?? null,
		action: params.action,
		entityType: params.entityType,
		entityId: params.entityId != null ? String(params.entityId) : null,
		summary: params.summary,
		details: params.details ?? null,
	})
}
