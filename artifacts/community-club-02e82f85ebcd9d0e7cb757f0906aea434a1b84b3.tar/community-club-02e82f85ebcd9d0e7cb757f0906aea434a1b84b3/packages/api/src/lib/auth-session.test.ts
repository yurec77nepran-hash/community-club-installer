import { describe, expect, test } from 'bun:test'
import { Hono } from 'hono'
import { AUTH_COOKIE_MAX_AGE_SECONDS } from './refresh-sessions'

describe('auth session cookies', () => {
	test('sets auth cookies with a browser-accepted max age', async () => {
		Bun.env.DATABASE_URL ??= 'postgres://user:pass@localhost:5432/db'
		Bun.env.JWT_SECRET ??= 'test-secret-test-secret-test-secret-1234'

		const { setAuthCookies } = await import('./auth-session')
		const app = new Hono()
		app.get('/', (c) => {
			setAuthCookies(c, { accessToken: 'access', refreshToken: 'refresh' })
			return c.text('ok')
		})

		const response = await app.request('https://example.com/')
		const setCookie =
			(response.headers as Headers & { getSetCookie?: () => string[] })
				.getSetCookie?.()
				.join('\n') ??
			response.headers.get('set-cookie') ??
			''

		expect(response.status).toBe(200)
		expect(setCookie).toContain(`Max-Age=${AUTH_COOKIE_MAX_AGE_SECONDS}`)
		expect(setCookie).not.toContain('Max-Age=315360000')
	})
})
