import { invalidateCachedNamespace, invalidateCachedValue } from './server-cache'

export async function invalidateHomeContentCaches() {
	await Promise.all([
		invalidateCachedNamespace('home:recent-feed'),
		invalidateCachedNamespace('materials:list'),
		invalidateCachedNamespace('materials:subsections'),
	])
}

export async function invalidateUserAccessCaches(userId: string) {
	await Promise.all([
		invalidateCachedValue('users:me', userId),
		invalidateCachedValue('payments:subscription', userId),
		invalidateCachedNamespace('home:recent-feed'),
	])
}
