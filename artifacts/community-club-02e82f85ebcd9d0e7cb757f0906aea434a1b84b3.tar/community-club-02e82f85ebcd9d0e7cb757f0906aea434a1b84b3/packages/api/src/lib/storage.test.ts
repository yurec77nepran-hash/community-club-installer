import { describe, expect, test } from 'bun:test'
import {
	extractMaterialStorageKey,
	findPreviewStoredMediaFile,
	findPrimaryStoredMediaFile,
	isStoredMediaFileDownloadable,
	parseStoredMediaFiles,
} from './storage'

describe('storage media metadata', () => {
	test('parseStoredMediaFiles preserves downloadable flag', () => {
		const files = parseStoredMediaFiles(
			JSON.stringify([
				{
					path: 'materials/podcasts/test.ogg',
					type: 'audio',
					displayName: 'Аудио 1',
					downloadable: true,
				},
			]),
		)

		expect(files).toHaveLength(1)
		expect(files[0]).toMatchObject({
			path: 'materials/podcasts/test.ogg',
			type: 'audio',
			displayName: 'Аудио 1',
			downloadable: true,
		})
	})

	test('findPrimaryStoredMediaFile returns matching file and index', () => {
		const match = findPrimaryStoredMediaFile(
			JSON.stringify([
				{ path: 'materials/image.jpg', type: 'image' },
				{ path: 'materials/video.mp4', type: 'video', downloadable: true },
				{ path: 'materials/file.pdf', type: 'document' },
			]),
			'video',
		)

		expect(match).toEqual({
			index: 1,
			file: {
				path: 'materials/video.mp4',
				type: 'video',
				downloadable: true,
			},
		})
	})

	test('uses an external URL as the primary video source', () => {
		const storagePath = JSON.stringify([{ url: 'https://example.test/video.mp4', type: 'video' }])

		expect(findPrimaryStoredMediaFile(storagePath, 'video')).toMatchObject({
			index: 0,
			file: { url: 'https://example.test/video.mp4', type: 'video' },
		})
		expect(extractMaterialStorageKey(storagePath, 'video')).toBe('https://example.test/video.mp4')
	})

	test('findPreviewStoredMediaFile prefers image file from material bundle', () => {
		const file = findPreviewStoredMediaFile(
			JSON.stringify([
				{ path: 'materials/manual.pdf', type: 'document' },
				{ path: 'materials/cover.jpg', type: 'image' },
			]),
			'document',
		)

		expect(file).toEqual({ path: 'materials/cover.jpg', type: 'image' })
	})

	test('findPreviewStoredMediaFile supports legacy image material path', () => {
		const file = findPreviewStoredMediaFile('materials/legacy-cover.jpg', 'image')

		expect(file).toEqual({ path: 'materials/legacy-cover.jpg' })
	})

	test('legacy media without downloadable flag stays downloadable', () => {
		const [legacyFile] = parseStoredMediaFiles('materials/legacy/file.pdf')

		expect(isStoredMediaFileDownloadable(legacyFile)).toBe(true)
	})

	test('explicit downloadable false stays disabled', () => {
		const [file] = parseStoredMediaFiles(
			JSON.stringify([
				{ path: 'materials/legacy/file.pdf', type: 'document', downloadable: false },
			]),
		)

		expect(isStoredMediaFileDownloadable(file)).toBe(false)
	})
})
