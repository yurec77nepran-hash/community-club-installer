import { queryClient } from '../db/client'

const feedBootstrapQueries = [
	`CREATE TABLE IF NOT EXISTS feed_posts (
		id bigserial PRIMARY KEY,
		author_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		audience text NOT NULL,
		emoji text,
		content text NOT NULL,
		button_label text,
		button_url text,
		notify_all boolean NOT NULL DEFAULT false,
		media jsonb NOT NULL DEFAULT '[]'::jsonb,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	`CREATE TABLE IF NOT EXISTS feed_post_drafts (
		id bigserial PRIMARY KEY,
		author_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		audience text NOT NULL,
		content text NOT NULL DEFAULT '',
		button_label text,
		button_url text,
		notify_all boolean NOT NULL DEFAULT false,
		media jsonb NOT NULL DEFAULT '[]'::jsonb,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	`CREATE TABLE IF NOT EXISTS feed_post_reactions (
		id serial PRIMARY KEY,
		post_id bigint NOT NULL REFERENCES feed_posts(id) ON DELETE CASCADE,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		emoji text NOT NULL,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	'CREATE INDEX IF NOT EXISTS feed_posts_audience_created_idx ON feed_posts (audience, created_at DESC, id DESC)',
	'CREATE INDEX IF NOT EXISTS feed_posts_author_idx ON feed_posts (author_auth_uuid, created_at DESC)',
	'DROP INDEX IF EXISTS feed_post_drafts_author_audience_unique',
	'CREATE INDEX IF NOT EXISTS feed_post_drafts_author_audience_idx ON feed_post_drafts (author_auth_uuid, audience)',
	'CREATE INDEX IF NOT EXISTS feed_post_drafts_author_updated_idx ON feed_post_drafts (author_auth_uuid, updated_at DESC)',
	'CREATE UNIQUE INDEX IF NOT EXISTS feed_post_reaction_unique ON feed_post_reactions (post_id, user_auth_uuid, emoji)',
	'CREATE INDEX IF NOT EXISTS feed_post_reactions_post_idx ON feed_post_reactions (post_id, created_at DESC)',
	'CREATE INDEX IF NOT EXISTS feed_post_reactions_user_idx ON feed_post_reactions (user_auth_uuid, created_at DESC)',
	"UPDATE feed_posts SET audience = 'club' WHERE audience <> 'club'",
	"UPDATE feed_post_drafts SET audience = 'club' WHERE audience <> 'club'",
]

export async function ensureFeedArtifacts() {
	for (const query of feedBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
