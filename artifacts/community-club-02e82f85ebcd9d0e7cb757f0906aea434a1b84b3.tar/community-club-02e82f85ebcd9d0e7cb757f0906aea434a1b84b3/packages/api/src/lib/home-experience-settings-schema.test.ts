import { describe, expect, test } from 'bun:test'
import { homeExperienceSettingsSchema } from './home-experience-settings-schema'
import { getDefaultHomeExperienceSettings } from './site-settings'

describe('home experience request schema', () => {
	test('normalizes the main banner when a legacy PUT payload omits it', () => {
		const legacyPayload = getDefaultHomeExperienceSettings()
		Reflect.deleteProperty(legacyPayload, 'mainBanner')

		const parsed = homeExperienceSettingsSchema.parse(legacyPayload)

		expect(parsed.mainBanner).toEqual(getDefaultHomeExperienceSettings().mainBanner)
	})

	test('accepts zero or five highlights but rejects six', () => {
		// Given: a valid home settings fixture with uniquely identified highlights.
		const defaults = getDefaultHomeExperienceSettings()
		const highlights = Array.from({ length: 6 }, (_, index) => ({
			id: `highlight-${index + 1}`,
			title: `Highlight ${index + 1}`,
			stories: [defaults.stories[0]],
		}))

		// When: the request contains the supported boundary counts.
		const emptyHighlights = homeExperienceSettingsSchema.safeParse({
			...defaults,
			highlights: [],
		})
		const fiveHighlights = homeExperienceSettingsSchema.safeParse({
			...defaults,
			highlights: highlights.slice(0, 5),
		})
		const sixHighlights = homeExperienceSettingsSchema.safeParse({
			...defaults,
			highlights,
		})

		// Then: zero and five are accepted, while six is outside the contract.
		expect(emptyHighlights.success).toBe(true)
		expect(fiveHighlights.success).toBe(true)
		expect(sixHighlights.success).toBe(false)
	})

	test('rejects a highlight with no stories', () => {
		// Given: a valid home settings fixture with an empty highlight story list.
		const defaults = getDefaultHomeExperienceSettings()

		// When: the request contains that highlight.
		const parsed = homeExperienceSettingsSchema.safeParse({
			...defaults,
			highlights: [{ id: 'highlight-empty', title: 'Empty', stories: [] }],
		})

		// Then: the highlight is rejected because every highlight needs a story.
		expect(parsed.success).toBe(false)
	})
})
