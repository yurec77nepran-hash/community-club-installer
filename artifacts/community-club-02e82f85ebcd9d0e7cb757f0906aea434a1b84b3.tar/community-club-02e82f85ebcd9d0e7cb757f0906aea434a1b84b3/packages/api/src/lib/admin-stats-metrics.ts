export function asCount(value: string | number | null | undefined) {
	return Number(value ?? 0)
}

export function percentChange(
	current: string | number | null | undefined,
	previous: string | number | null | undefined,
) {
	const currentValue = Number(current ?? 0)
	const previousValue = Number(previous ?? 0)

	if (previousValue <= 0) return currentValue > 0 ? 100 : 0

	return Math.round(((currentValue - previousValue) / previousValue) * 100)
}
