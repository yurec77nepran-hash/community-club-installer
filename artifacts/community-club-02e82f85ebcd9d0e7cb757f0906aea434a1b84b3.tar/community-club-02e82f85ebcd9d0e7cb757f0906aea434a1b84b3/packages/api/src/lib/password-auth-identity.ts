export function createPasswordAuthIdentity(email: string) {
	return {
		email: email.trim().toLowerCase(),
		authType: 'email',
	} as const
}
