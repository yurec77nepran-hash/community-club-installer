import {
	type MessengerProvider,
	messengerConnections,
	messengerContacts,
	users,
} from '@community-club/shared'
import { and, eq } from 'drizzle-orm'
import { db } from '../db/client'

type MessengerProfile = {
	externalUserId: string
	displayName?: string | null
	username?: string | null
	profile?: Record<string, unknown>
}

export async function upsertMessengerContact(params: {
	connectionId: number
	provider: MessengerProvider
	profile: MessengerProfile
	consentStatus?: 'active' | 'revoked'
}) {
	const existing = await db.query.messengerContacts.findFirst({
		where: and(
			eq(messengerContacts.connectionId, params.connectionId),
			eq(messengerContacts.externalUserId, params.profile.externalUserId),
		),
	})
	const values = {
		displayName: params.profile.displayName?.trim() || null,
		username: params.profile.username?.trim().replace(/^@/, '') || null,
		profile: params.profile.profile ?? {},
		consentStatus: params.consentStatus ?? 'active',
		lastSeenAt: new Date(),
		updatedAt: new Date(),
	}
	if (existing) {
		const [contact] = await db
			.update(messengerContacts)
			.set(values)
			.where(eq(messengerContacts.id, existing.id))
			.returning()
		return contact
	}

	const [user] = await db
		.insert(users)
		.values({
			fullName: values.displayName,
			...(params.provider === 'max' ? { maxMessengerUserId: params.profile.externalUserId } : {}),
		})
		.returning({ authUuid: users.authUuid })
	const [contact] = await db
		.insert(messengerContacts)
		.values({
			connectionId: params.connectionId,
			userAuthUuid: user.authUuid,
			externalUserId: params.profile.externalUserId,
			...values,
		})
		.returning()
	return contact
}

export async function getUserMessengerContacts(userAuthUuid: string) {
	return db
		.select({
			id: messengerContacts.id,
			provider: messengerConnections.provider,
			connectionLabel: messengerConnections.label,
			externalUserId: messengerContacts.externalUserId,
			displayName: messengerContacts.displayName,
			username: messengerContacts.username,
			consentStatus: messengerContacts.consentStatus,
			lastSeenAt: messengerContacts.lastSeenAt,
		})
		.from(messengerContacts)
		.innerJoin(messengerConnections, eq(messengerConnections.id, messengerContacts.connectionId))
		.where(eq(messengerContacts.userAuthUuid, userAuthUuid))
}
