import { sql } from 'drizzle-orm'
import { db } from '../db/client'

export async function ensureTelegramBroadcastArtifacts() {
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS telegram_contacts (
			id serial PRIMARY KEY,
			user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
			bot_username text NOT NULL,
			telegram_user_id text NOT NULL,
			telegram_username text,
			source_created_at timestamptz,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE UNIQUE INDEX IF NOT EXISTS telegram_contacts_bot_user_unique
		ON telegram_contacts (bot_username, telegram_user_id)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS telegram_contacts_user_idx ON telegram_contacts (user_auth_uuid)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS telegram_contacts_telegram_user_idx ON telegram_contacts (telegram_user_id)
	`)
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS telegram_broadcasts (
			id serial PRIMARY KEY,
			name text NOT NULL,
			bot_username text NOT NULL,
			body text NOT NULL,
			status text NOT NULL DEFAULT 'scheduled',
			send_at timestamptz NOT NULL,
			processing_started_at timestamptz,
			audience_size integer NOT NULL DEFAULT 0,
			sent_count integer NOT NULL DEFAULT 0,
			failed_count integer NOT NULL DEFAULT 0,
			last_error text,
			created_by_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS telegram_broadcasts_status_send_at_idx
		ON telegram_broadcasts (status, send_at)
	`)
	await db.execute(sql`
		ALTER TABLE telegram_broadcasts
		ADD COLUMN IF NOT EXISTS bot_usernames text[]
	`)
	await db.execute(sql`
		UPDATE telegram_broadcasts
		SET bot_usernames = ARRAY[bot_username]
		WHERE bot_usernames IS NULL
	`)
	await db.execute(sql`
		ALTER TABLE telegram_broadcasts
		ALTER COLUMN bot_usernames SET NOT NULL,
		ALTER COLUMN bot_usernames SET DEFAULT ARRAY[]::text[]
	`)
	await db.execute(sql`
			ALTER TABLE telegram_broadcasts
			ADD COLUMN IF NOT EXISTS delivery_mode text NOT NULL DEFAULT 'all',
			ADD COLUMN IF NOT EXISTS preferred_bot_username text,
			ADD COLUMN IF NOT EXISTS buttons jsonb NOT NULL DEFAULT '[]'::jsonb,
			ADD COLUMN IF NOT EXISTS media jsonb
		`)
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS telegram_broadcast_deliveries (
			id serial PRIMARY KEY,
			broadcast_id integer NOT NULL REFERENCES telegram_broadcasts(id) ON DELETE CASCADE,
			contact_id integer NOT NULL REFERENCES telegram_contacts(id) ON DELETE CASCADE,
			status text NOT NULL DEFAULT 'pending',
			error_message text,
			sent_at timestamptz,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE UNIQUE INDEX IF NOT EXISTS telegram_broadcast_deliveries_unique
		ON telegram_broadcast_deliveries (broadcast_id, contact_id)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS telegram_broadcast_deliveries_status_idx
		ON telegram_broadcast_deliveries (broadcast_id, status)
	`)
}
