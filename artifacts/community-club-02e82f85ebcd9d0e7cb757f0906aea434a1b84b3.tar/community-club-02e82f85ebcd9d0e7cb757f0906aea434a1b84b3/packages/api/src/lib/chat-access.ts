import { chatMembers, chats } from '@community-club/shared'
import { and, eq } from 'drizzle-orm'
import { db } from '../db/client'
import { canAccessByRole, canAccessRegularChat } from './chat-access-policy'
import { isChatManager } from './chat-settings'

type UserRole = 'user' | 'admin' | 'superadmin'
type ChatRecord = typeof chats.$inferSelect
type ChatMemberRecord = typeof chatMembers.$inferSelect

const CHAT_CACHE_TTL_MS = 60_000
const CHAT_MEMBER_CACHE_TTL_MS = 5_000
const ACCESSIBLE_CHATS_CACHE_TTL_MS = 30_000

const chatCache = new Map<number, { expiresAt: number; value: ChatRecord | null }>()
const chatMemberCache = new Map<string, { expiresAt: number; value: ChatMemberRecord | null }>()
const accessibleChatsCache = new Map<string, { expiresAt: number; value: ChatRecord[] }>()

export function getSupportChatSlug(userId: string) {
	return `support:${userId}`
}

export function isSupportChatSlug(slug: string) {
	return slug.startsWith('support:')
}

function getMemberCacheKey(chatId: number, userId: string) {
	return `${chatId}:${userId}`
}

async function getChatById(chatId: number) {
	const cached = chatCache.get(chatId)
	if (cached && cached.expiresAt > Date.now()) {
		return cached.value
	}

	const chat =
		(await db.query.chats.findFirst({
			where: eq(chats.id, chatId),
		})) ?? null

	chatCache.set(chatId, {
		expiresAt: Date.now() + CHAT_CACHE_TTL_MS,
		value: chat,
	})

	return chat
}

async function getChatMember(chatId: number, userId: string) {
	const cacheKey = getMemberCacheKey(chatId, userId)
	const cached = chatMemberCache.get(cacheKey)
	if (cached && cached.expiresAt > Date.now()) {
		return cached.value
	}

	const member =
		(await db.query.chatMembers.findFirst({
			where: and(eq(chatMembers.chatId, chatId), eq(chatMembers.userAuthUuid, userId)),
		})) ?? null

	chatMemberCache.set(cacheKey, {
		expiresAt: Date.now() + CHAT_MEMBER_CACHE_TTL_MS,
		value: member,
	})

	return member
}

function setChatMemberCache(chatId: number, userId: string, member: ChatMemberRecord | null) {
	chatMemberCache.set(getMemberCacheKey(chatId, userId), {
		expiresAt: Date.now() + CHAT_MEMBER_CACHE_TTL_MS,
		value: member,
	})
}

export async function getAccessibleChatsForRole(userRole: UserRole) {
	const cached = accessibleChatsCache.get(userRole)
	if (cached && cached.expiresAt > Date.now()) {
		return cached.value
	}

	const items = await db.query.chats.findMany({
		where: and(eq(chats.type, 'chat'), eq(chats.isEnabled, true)),
		orderBy: (fields, { asc }) => [asc(fields.id)],
	})

	const filtered = items.filter(
		(chat) => !isSupportChatSlug(chat.slug) && canAccessByRole(userRole, chat.accessRole),
	)
	accessibleChatsCache.set(userRole, {
		expiresAt: Date.now() + ACCESSIBLE_CHATS_CACHE_TTL_MS,
		value: filtered,
	})
	return filtered
}

export function clearChatAccessCaches(chatId?: number) {
	accessibleChatsCache.clear()
	if (chatId != null) {
		chatCache.delete(chatId)
		for (const key of Array.from(chatMemberCache.keys())) {
			if (key.startsWith(`${chatId}:`)) chatMemberCache.delete(key)
		}
		return
	}
	chatCache.clear()
	chatMemberCache.clear()
}

export async function ensureChatAccess(params: {
	chatId: number
	userId: string
	userRole: UserRole
}) {
	const chat = await getChatById(params.chatId)

	if (!chat || chat.type !== 'chat') {
		return { ok: false as const, code: 'NOT_FOUND', message: 'Чат не найден' }
	}

	const member = await getChatMember(params.chatId, params.userId)

	if (member?.status === 'banned') {
		return { ok: false as const, code: 'FORBIDDEN', message: 'Доступ к чату закрыт' }
	}

	const isSupportChat = isSupportChatSlug(chat.slug)
	if (!isSupportChat && !chat.isEnabled && !isChatManager(params.userRole, member?.role)) {
		return { ok: false as const, code: 'NOT_FOUND', message: 'Чат не найден' }
	}

	const hasAccess = isSupportChat
		? params.userRole === 'admin' ||
			params.userRole === 'superadmin' ||
			!!member ||
			chat.slug === getSupportChatSlug(params.userId)
		: canAccessRegularChat({
				userRole: params.userRole,
				accessRole: chat.accessRole,
				memberRole: member?.role,
			})
	if (!hasAccess) {
		return { ok: false as const, code: 'FORBIDDEN', message: 'Доступ к чату закрыт' }
	}

	if (!member) {
		await db
			.insert(chatMembers)
			.values({
				chatId: params.chatId,
				userAuthUuid: params.userId,
				role: params.userRole === 'admin' || params.userRole === 'superadmin' ? 'admin' : 'member',
			})
			.onConflictDoNothing()
	}

	const actualMember = member ?? (await getChatMember(params.chatId, params.userId))
	setChatMemberCache(params.chatId, params.userId, actualMember ?? null)

	return {
		ok: true as const,
		chat,
		member: actualMember ?? null,
	}
}
