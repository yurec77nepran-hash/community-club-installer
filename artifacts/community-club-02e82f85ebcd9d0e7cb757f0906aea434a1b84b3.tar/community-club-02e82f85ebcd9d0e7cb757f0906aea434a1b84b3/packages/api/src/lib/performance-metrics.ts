type MetricSample = {
	durationMs: number
	at: number
	isError: boolean
}

type MetricBucket = {
	samples: MetricSample[]
}

type MetricSummary = {
	key: string
	count: number
	errorCount: number
	avgMs: number
	p95Ms: number
	p99Ms: number
	maxMs: number
}

const DEFAULT_WINDOW_MS = 10 * 60 * 1000
const DEFAULT_MAX_SAMPLES = 300
const PATH_PLACEHOLDER_PATTERNS = [
	/\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b/gi,
	/\b[0-9]+\b/g,
]

function cleanupSamples(
	samples: MetricSample[],
	now: number,
	windowMs: number,
	maxSamples: number,
) {
	const validFrom = now - windowMs
	const filtered = samples.filter((sample) => sample.at >= validFrom)
	if (filtered.length <= maxSamples) return filtered
	return filtered.slice(filtered.length - maxSamples)
}

function getPercentile(sortedValues: number[], percentile: number) {
	if (sortedValues.length === 0) return 0
	const index = Math.min(
		sortedValues.length - 1,
		Math.max(0, Math.ceil((percentile / 100) * sortedValues.length) - 1),
	)
	return sortedValues[index] ?? 0
}

function summarizeBucket(key: string, bucket: MetricBucket): MetricSummary {
	const durations = bucket.samples
		.map((sample) => sample.durationMs)
		.sort((left, right) => left - right)
	const errorCount = bucket.samples.reduce((acc, sample) => acc + (sample.isError ? 1 : 0), 0)

	const totalDuration = durations.reduce((acc, value) => acc + value, 0)
	return {
		key,
		count: bucket.samples.length,
		errorCount,
		avgMs: durations.length > 0 ? Math.round(totalDuration / durations.length) : 0,
		p95Ms: getPercentile(durations, 95),
		p99Ms: getPercentile(durations, 99),
		maxMs: durations[durations.length - 1] ?? 0,
	}
}

function normalizePath(path: string) {
	let normalized = path
	for (const pattern of PATH_PLACEHOLDER_PATTERNS) {
		normalized = normalized.replace(pattern, ':id')
	}
	return normalized
}

class WindowedMetrics {
	private readonly buckets = new Map<string, MetricBucket>()

	constructor(
		private readonly windowMs = DEFAULT_WINDOW_MS,
		private readonly maxSamples = DEFAULT_MAX_SAMPLES,
	) {}

	record(key: string, durationMs: number, isError = false) {
		const now = Date.now()
		const bucket = this.buckets.get(key) ?? {
			samples: [],
		}

		bucket.samples.push({ durationMs, at: now, isError })
		bucket.samples = cleanupSamples(bucket.samples, now, this.windowMs, this.maxSamples)
		this.buckets.set(key, bucket)
		this.compact(now)
	}

	snapshot(limit = 10) {
		const now = Date.now()
		this.compact(now)
		const summaries = Array.from(this.buckets.entries())
			.map(([key, bucket]) => summarizeBucket(key, bucket))
			.sort((left, right) => right.p95Ms - left.p95Ms)
		return summaries.slice(0, limit)
	}

	private compact(now: number) {
		for (const [key, bucket] of this.buckets.entries()) {
			bucket.samples = cleanupSamples(bucket.samples, now, this.windowMs, this.maxSamples)
			if (bucket.samples.length === 0) {
				this.buckets.delete(key)
				continue
			}
			this.buckets.set(key, bucket)
		}
	}
}

const httpMetrics = new WindowedMetrics()
const dbMetrics = new WindowedMetrics()

export function recordHttpMetric(params: {
	method: string
	path: string
	durationMs: number
	status: number
}) {
	httpMetrics.record(
		`${params.method.toUpperCase()} ${normalizePath(params.path)}`,
		params.durationMs,
		params.status >= 500,
	)
}

export function recordDbMetric(params: {
	name: string
	durationMs: number
	isError?: boolean
}) {
	dbMetrics.record(params.name, params.durationMs, params.isError ?? false)
}

export function getPerformanceMetricsSnapshot() {
	return {
		windowMs: DEFAULT_WINDOW_MS,
		http: httpMetrics.snapshot(),
		db: dbMetrics.snapshot(),
	}
}
