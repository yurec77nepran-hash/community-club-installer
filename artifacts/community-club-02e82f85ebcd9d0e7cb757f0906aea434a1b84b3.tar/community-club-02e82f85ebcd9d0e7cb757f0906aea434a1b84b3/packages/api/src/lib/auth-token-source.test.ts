import { describe, expect, test } from 'bun:test'
import { resolveAccessTokenSource } from './auth-token-source'

describe('resolveAccessTokenSource', () => {
	test('prefers httpOnly cookie access token over stale Authorization header', () => {
		expect(
			resolveAccessTokenSource({
				cookieToken: 'fresh-cookie-token',
				headerToken: 'stale-header-token',
			}),
		).toBe('fresh-cookie-token')
		expect(resolveAccessTokenSource({ cookieToken: null, headerToken: 'api-client-token' })).toBe(
			'api-client-token',
		)
	})
})
