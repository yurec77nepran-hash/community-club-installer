import { queryClient } from '../db/client'

const referralBootstrapQueries = [
	`CREATE TABLE IF NOT EXISTS referrals (
		id serial PRIMARY KEY,
		referrer_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		referred_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		status text NOT NULL DEFAULT 'pending',
		bonus_amount numeric,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	"ALTER TABLE referrals ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending'",
	'ALTER TABLE referrals ADD COLUMN IF NOT EXISTS bonus_amount numeric',
	'ALTER TABLE referrals ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now()',
	'CREATE INDEX IF NOT EXISTS referrals_referred_uuid_idx ON referrals (referred_uuid)',
	'CREATE INDEX IF NOT EXISTS referrals_referrer_uuid_idx ON referrals (referrer_uuid)',
	'CREATE INDEX IF NOT EXISTS referrals_created_at_idx ON referrals (created_at DESC)',
]

export async function ensureReferralArtifacts() {
	for (const query of referralBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
