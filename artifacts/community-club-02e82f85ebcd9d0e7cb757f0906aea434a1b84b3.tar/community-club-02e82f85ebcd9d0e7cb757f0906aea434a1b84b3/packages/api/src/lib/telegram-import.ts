export type TelegramImportRow = {
	sourceTable: string
	botUsername: string
	telegramUserId: string
	sourceCreatedAt: Date | null
}

const sourceBots: Record<string, string> = {
	Gorsky_Chatbot: 'gorsky_chatbot',
	OlegGorsky_bot: 'oleggorsky_bot',
	proproconf_bot: 'proproconf_bot',
}

export function parseTelegramImportDump(source: string): TelegramImportRow[] {
	const rows: TelegramImportRow[] = []
	let sourceTable: string | null = null
	for (const line of source.split(/\r?\n/)) {
		const copyMatch = line.match(
			/^COPY public\.(?:"([^"]+)"|([a-z0-9_]+)) \(id, created_at, user_id\) FROM stdin;$/,
		)
		if (copyMatch) {
			sourceTable = copyMatch[1] ?? copyMatch[2]
			continue
		}
		if (line === '\\.') {
			sourceTable = null
			continue
		}
		if (!sourceTable || !sourceBots[sourceTable]) continue

		const [, createdAt, telegramUserId] = line.split('\t')
		if (!/^\d{1,20}$/.test(telegramUserId ?? '')) continue
		const parsedDate = createdAt ? new Date(createdAt) : null
		rows.push({
			sourceTable,
			botUsername: sourceBots[sourceTable],
			telegramUserId,
			sourceCreatedAt: parsedDate && !Number.isNaN(parsedDate.getTime()) ? parsedDate : null,
		})
	}
	return rows
}
