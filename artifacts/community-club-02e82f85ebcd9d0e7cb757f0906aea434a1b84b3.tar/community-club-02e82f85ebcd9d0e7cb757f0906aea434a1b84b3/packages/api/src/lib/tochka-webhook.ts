const TOCHKA_WEBHOOK_PUBLIC_KEY_URL = 'https://enter.tochka.com/doc/openapi/static/keys/public'
const PUBLIC_KEY_CACHE_MS = 6 * 60 * 60 * 1000

let cachedPublicKey: { value: JsonWebKey; expiresAt: number } | null = null

function decodeJwtPart(value: string) {
	try {
		const normalized = value.replace(/-/g, '+').replace(/_/g, '/')
		const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=')
		const parsed = JSON.parse(Buffer.from(padded, 'base64').toString('utf8'))
		return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null
	} catch {
		return null
	}
}

function decodeBase64Url(value: string) {
	const normalized = value.replace(/-/g, '+').replace(/_/g, '/')
	return Uint8Array.from(
		Buffer.from(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '='), 'base64'),
	)
}

export async function verifyTochkaWebhookJwt(token: string, publicKey: JsonWebKey) {
	const [encodedHeader, encodedPayload, encodedSignature, ...extra] = token.trim().split('.')
	if (!encodedHeader || !encodedPayload || !encodedSignature || extra.length) return null

	const header = decodeJwtPart(encodedHeader)
	const payload = decodeJwtPart(encodedPayload)
	if (header?.alg !== 'RS256' || !payload) return null

	try {
		const key = await crypto.subtle.importKey(
			'jwk',
			publicKey,
			{ name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
			false,
			['verify'],
		)
		const isValid = await crypto.subtle.verify(
			'RSASSA-PKCS1-v1_5',
			key,
			decodeBase64Url(encodedSignature),
			new TextEncoder().encode(`${encodedHeader}.${encodedPayload}`),
		)
		return isValid ? payload : null
	} catch {
		return null
	}
}

async function loadTochkaWebhookPublicKey(force = false) {
	if (!force && cachedPublicKey && cachedPublicKey.expiresAt > Date.now()) {
		return cachedPublicKey.value
	}

	const response = await fetch(TOCHKA_WEBHOOK_PUBLIC_KEY_URL, {
		signal: AbortSignal.timeout(10_000),
	})
	if (!response.ok) throw new Error(`Tochka public key returned HTTP ${response.status}`)
	const value = (await response.json()) as JsonWebKey
	if (value.kty !== 'RSA' || !value.n || !value.e) throw new Error('Tochka public key is invalid')

	cachedPublicKey = { value, expiresAt: Date.now() + PUBLIC_KEY_CACHE_MS }
	return value
}

export async function decodeVerifiedTochkaWebhook(token: string) {
	try {
		const publicKey = await loadTochkaWebhookPublicKey()
		const payload = await verifyTochkaWebhookJwt(token, publicKey)
		if (payload) return payload
		return verifyTochkaWebhookJwt(token, await loadTochkaWebhookPublicKey(true))
	} catch {
		return null
	}
}
