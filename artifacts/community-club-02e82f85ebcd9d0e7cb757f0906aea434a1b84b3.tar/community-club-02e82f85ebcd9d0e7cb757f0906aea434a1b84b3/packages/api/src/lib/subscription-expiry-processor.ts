import { paymentLogs, payments, users } from '@community-club/shared'
import { and, eq, isNotNull, lt } from 'drizzle-orm'
import { db } from '../db/client'
import { invalidateUserAccessCaches } from './cache-invalidation'
import { logger } from './logger'
import { isSubscriptionExpiredByMoscowDate } from './subscription-expiry-utils'

const PROCESSOR_INTERVAL_MS = 60 * 60_000
const EXPIRE_BATCH_SIZE = 500

let started = false
let tickRunning = false

function getMoscowDateString(date = new Date()) {
	return new Intl.DateTimeFormat('en-CA', {
		timeZone: 'Europe/Moscow',
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
	}).format(date)
}

async function expirePaymentAccess(params: {
	payment: typeof payments.$inferSelect
	todayMoscow: string
}) {
	const userAuthUuid = params.payment.userAuthUuid
	if (!userAuthUuid) return false
	if (!isSubscriptionExpiredByMoscowDate(params.payment.dateFinish, params.todayMoscow))
		return false

	const idempotencyKey = `subscription-expiry:${userAuthUuid}:${params.payment.dateFinish}`

	await db.transaction(async (tx) => {
		await tx
			.update(payments)
			.set({
				tarrif: null,
				dateStart: null,
				dateFinish: null,
				cpSubscriptionId: null,
				cpAccountId: null,
				cpToken: null,
				paymentProvider: null,
				amount: null,
				autoPayment: false,
				noAutopodpiska: true,
			})
			.where(eq(payments.id, params.payment.id))

		await tx
			.update(users)
			.set({
				role: 'user',
				updatedAt: new Date(),
			})
			.where(eq(users.authUuid, userAuthUuid))

		await tx
			.insert(paymentLogs)
			.values({
				event: 'subscription_expired',
				userAuthUuid,
				email: params.payment.email,
				phone: params.payment.phone,
				subscriptionId: params.payment.cpSubscriptionId,
				tariff: params.payment.tarrif,
				status: 'success',
				webhookType: 'system',
				idempotencyKey,
			})
			.onConflictDoNothing()
	})

	await invalidateUserAccessCaches(userAuthUuid)

	return true
}

async function processSubscriptionExpiryTick() {
	if (tickRunning) return
	tickRunning = true

	try {
		const todayMoscow = getMoscowDateString()
		const expiredPayments = await db.query.payments.findMany({
			where: and(isNotNull(payments.userAuthUuid), lt(payments.dateFinish, todayMoscow)),
			orderBy: (fields, { asc }) => [asc(fields.dateFinish), asc(fields.id)],
			limit: EXPIRE_BATCH_SIZE,
		})

		let expiredCount = 0
		for (const payment of expiredPayments) {
			const expired = await expirePaymentAccess({ payment, todayMoscow })
			if (expired) expiredCount++
		}

		if (expiredCount > 0) {
			logger.info({ expiredCount }, 'Expired subscriptions processed')
		}
	} catch (error) {
		logger.error({ err: error }, 'Subscription expiry processor tick failed')
	} finally {
		tickRunning = false
	}
}

export function startSubscriptionExpiryProcessor() {
	if (started) return
	started = true
	void processSubscriptionExpiryTick()
	setInterval(() => {
		void processSubscriptionExpiryTick()
	}, PROCESSOR_INTERVAL_MS)
	logger.info({ intervalMs: PROCESSOR_INTERVAL_MS }, 'Subscription expiry processor started')
}
