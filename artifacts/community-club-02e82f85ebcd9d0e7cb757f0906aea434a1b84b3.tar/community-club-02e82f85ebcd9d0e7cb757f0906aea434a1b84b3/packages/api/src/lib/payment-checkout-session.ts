import { nanoid } from 'nanoid'
import { redis } from './redis'

const CHECKOUT_SESSION_TTL_SECONDS = 48 * 60 * 60
const CHECKOUT_SESSION_PREFIX = 'payment:checkout-session:'

export type PaymentCheckoutSession = {
	userAuthUuid: string
	email: string | null
	invoiceId: string
	tariffSlug: string
	amount: number
	createdAt: number
}

function sessionKey(token: string) {
	return `${CHECKOUT_SESSION_PREFIX}${token}`
}

export async function createPaymentCheckoutSession(
	session: Omit<PaymentCheckoutSession, 'createdAt'>,
) {
	const token = nanoid(48)
	const payload: PaymentCheckoutSession = {
		...session,
		createdAt: Date.now(),
	}

	await redis.set(sessionKey(token), JSON.stringify(payload), 'EX', CHECKOUT_SESSION_TTL_SECONDS)
	return token
}

export async function readPaymentCheckoutSession(token: string) {
	const raw = await redis.get(sessionKey(token))
	if (!raw) return null

	try {
		const parsed = JSON.parse(raw) as Partial<PaymentCheckoutSession>
		if (!parsed.userAuthUuid || !parsed.invoiceId || !parsed.tariffSlug) return null
		return {
			userAuthUuid: String(parsed.userAuthUuid),
			email: parsed.email ? String(parsed.email) : null,
			invoiceId: String(parsed.invoiceId),
			tariffSlug: String(parsed.tariffSlug),
			amount: Number(parsed.amount ?? 0),
			createdAt: Number(parsed.createdAt ?? 0),
		} satisfies PaymentCheckoutSession
	} catch {
		return null
	}
}

export async function consumePaymentCheckoutSession(token: string) {
	await redis.del(sessionKey(token))
}
