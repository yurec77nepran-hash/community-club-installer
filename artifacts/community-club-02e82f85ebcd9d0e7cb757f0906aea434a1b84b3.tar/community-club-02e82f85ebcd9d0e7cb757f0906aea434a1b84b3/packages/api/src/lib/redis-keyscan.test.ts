import { describe, expect, test } from 'bun:test'
import { deleteRedisKeysByPattern } from './redis-keyscan'

describe('deleteRedisKeysByPattern', () => {
	test('deletes matching keys through SCAN batches without using KEYS', async () => {
		const scanCalls: string[] = []
		const deleted: string[] = []
		const client = {
			async scan(cursor: string) {
				scanCalls.push(cursor)
				if (cursor === '0') {
					return ['7', ['refresh:user:one', 'refresh:user:two']] as [string, string[]]
				}
				return ['0', ['refresh:user:three']] as [string, string[]]
			},
			async del(...keys: string[]) {
				deleted.push(...keys)
				return keys.length
			},
		}

		const count = await deleteRedisKeysByPattern(client, 'refresh:user:*')

		expect(count).toBe(3)
		expect(scanCalls).toEqual(['0', '7'])
		expect(deleted).toEqual(['refresh:user:one', 'refresh:user:two', 'refresh:user:three'])
	})
})
