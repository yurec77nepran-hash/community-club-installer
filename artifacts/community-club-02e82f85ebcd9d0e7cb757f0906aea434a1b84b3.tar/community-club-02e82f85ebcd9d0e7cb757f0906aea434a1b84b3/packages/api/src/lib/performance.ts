import { env } from '../config/env'
import { logger } from './logger'
import { recordDbMetric } from './performance-metrics'

function truncateText(value: string, maxLength: number) {
	if (value.length <= maxLength) return value
	return `${value.slice(0, maxLength)}...`
}

export async function measureDbOperation<T>(
	name: string,
	meta: Record<string, unknown>,
	run: () => Promise<T>,
) {
	const startedAt = performance.now()
	try {
		const result = await run()
		const durationMs = Math.round(performance.now() - startedAt)
		recordDbMetric({ name, durationMs })
		if (durationMs >= env.SLOW_DB_QUERY_MS) {
			logger.warn(
				{
					name,
					durationMs,
					...meta,
				},
				'Slow DB operation detected',
			)
		}
		return result
	} catch (err) {
		const durationMs = Math.round(performance.now() - startedAt)
		recordDbMetric({ name, durationMs, isError: true })
		logger.error(
			{
				err,
				name,
				durationMs,
				...meta,
			},
			'DB operation failed',
		)
		throw err
	}
}

export function logSlowSql(params: {
	query: string
	params: unknown[]
	durationMs: number
	error?: boolean
}) {
	recordDbMetric({
		name: `sql:${truncateText(params.query.replace(/\s+/g, ' ').trim(), 120)}`,
		durationMs: params.durationMs,
		isError: params.error ?? false,
	})

	if (params.durationMs < env.SLOW_DB_QUERY_MS) return

	logger.warn(
		{
			durationMs: params.durationMs,
			query: truncateText(params.query.replace(/\s+/g, ' ').trim(), 800),
			paramsPreview: truncateText(JSON.stringify(params.params).slice(0, 800), 800),
		},
		'Slow SQL query detected',
	)
}
