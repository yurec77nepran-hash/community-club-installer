const MAX_WS_PAYLOAD_BYTES = 64 * 1024

function parseCookieHeader(header: string | null) {
	const cookies = new Map<string, string>()
	if (!header) return cookies

	for (const part of header.split(';')) {
		const [name, ...rest] = part.trim().split('=')
		if (!name || rest.length === 0) continue
		cookies.set(name, decodeURIComponent(rest.join('=')))
	}

	return cookies
}

function normalizeOrigin(value: string | null | undefined) {
	if (!value) return null
	try {
		return new URL(value).origin
	} catch {
		return null
	}
}

export function extractWsAuthToken(req: Request) {
	const authorization = req.headers.get('authorization')
	if (authorization?.startsWith('Bearer ')) {
		const token = authorization.slice(7).trim()
		return token || null
	}

	const cookies = parseCookieHeader(req.headers.get('cookie'))
	return cookies.get('access_token') ?? null
}

export function isAllowedWsOrigin(origin: string | null, allowedOrigins: string[]) {
	const normalizedOrigin = normalizeOrigin(origin)
	if (!normalizedOrigin) return true
	const allowed = new Set(
		allowedOrigins.map(normalizeOrigin).filter((value): value is string => Boolean(value)),
	)
	return allowed.has(normalizedOrigin)
}

export function isWsPayloadWithinLimit(
	raw: string | Buffer | Uint8Array,
	maxBytes = MAX_WS_PAYLOAD_BYTES,
) {
	if (typeof raw === 'string') return Buffer.byteLength(raw) <= maxBytes
	return raw.byteLength <= maxBytes
}
