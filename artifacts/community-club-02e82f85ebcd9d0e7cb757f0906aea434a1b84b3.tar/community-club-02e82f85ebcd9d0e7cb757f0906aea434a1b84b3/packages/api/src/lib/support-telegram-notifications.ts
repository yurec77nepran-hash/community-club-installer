import { env } from '../config/env'
import { isSupportChatSlug } from './chat-access'
import { logger } from './logger'
import { getAppBaseUrl, loadRuntimeSettings } from './site-settings'
import {
	buildSupportAdminDialogUrl,
	buildSupportTelegramNotificationPayload,
} from './support-telegram-notification-payload'
import { sendTelegramMessage } from './telegram'

type UserRole = 'user' | 'admin' | 'superadmin'

function shouldNotifySupportTelegram(params: {
	chatSlug: string
	authorRole: UserRole
}) {
	if (!isSupportChatSlug(params.chatSlug)) return false
	return params.authorRole !== 'admin' && params.authorRole !== 'superadmin'
}

export async function sendSupportTelegramNotification(params: {
	chat: {
		id: number
		slug: string
	}
	messageId: number
	authorRole: UserRole
	authorName: string
	authorEmail?: string | null
	content: string
	messageType: string
}) {
	if (
		!shouldNotifySupportTelegram({
			chatSlug: params.chat.slug,
			authorRole: params.authorRole,
		})
	) {
		return
	}

	const runtimeSettings = await loadRuntimeSettings()
	if (!runtimeSettings.telegramBotToken || !env.SUPPORT_TELEGRAM_CHAT_ID) return

	try {
		const payload = buildSupportTelegramNotificationPayload({
			authorName: params.authorName,
			authorEmail: params.authorEmail,
			content: params.content,
			messageType: params.messageType,
			adminDialogUrl: buildSupportAdminDialogUrl({
				appUrl: await getAppBaseUrl(),
				chatId: params.chat.id,
				messageId: params.messageId,
			}),
		})

		await sendTelegramMessage(env.SUPPORT_TELEGRAM_CHAT_ID, payload.text, {
			parseMode: 'HTML',
			replyMarkup: payload.replyMarkup,
		})
	} catch (err) {
		logger.warn(
			{
				err,
				chatId: params.chat.id,
				messageId: params.messageId,
			},
			'Failed to send support Telegram notification',
		)
	}
}
