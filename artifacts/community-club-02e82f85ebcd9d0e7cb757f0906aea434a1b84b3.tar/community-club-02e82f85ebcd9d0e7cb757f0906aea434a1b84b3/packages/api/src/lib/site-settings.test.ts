import { describe, expect, test } from 'bun:test'
import {
	buildSiteBrandingSettings,
	getDefaultAppNavigationSettings,
	getDefaultAuthLoginSettings,
	getDefaultGuestContentAccessSettings,
	getDefaultHomeExperienceSettings,
	getDefaultLegalDocumentsSettings,
	getDefaultSiteBrandingSettings,
	getDefaultTelegramBotAuthSettings,
	getDefaultTestAccessSettings,
	normalizeAppNavigationSettingsPayload,
	normalizeAuthLoginSettingsPayload,
	normalizeGuestContentAccessSettingsPayload,
	normalizeHomeExperienceSettingsPayload,
	normalizeLegalDocumentsSettingsPayload,
	normalizeSiteBrandingSettingsPayload,
	normalizeTelegramBotAuthSettingsPayload,
	normalizeTestAccessSettingsPayload,
	parseStoredAuthLoginSettings,
	parseStoredGuestContentAccessSettings,
	parseStoredHomeExperienceSettings,
	parseStoredLegalDocumentsSettings,
	parseStoredSiteBrandingSettings,
	parseStoredTestAccessSettings,
	withMediaUrls,
} from './site-settings'

describe('guest content access settings', () => {
	test('defaults to closed cards and accepts only supported levels', () => {
		expect(getDefaultGuestContentAccessSettings()).toEqual({ level: 'cards' })
		expect(normalizeGuestContentAccessSettingsPayload({ level: 'preview' })).toEqual({
			level: 'preview',
		})
		expect(normalizeGuestContentAccessSettingsPayload({ level: 'unknown' } as never)).toEqual({
			level: 'cards',
		})
		expect(
			parseStoredGuestContentAccessSettings([
				{ key: 'guest_content_access', value: '{"level":"sections"}' },
			]),
		).toEqual({ level: 'sections' })
	})
})

describe('app navigation settings', () => {
	test('keeps four default menu tabs and a center button', () => {
		const settings = getDefaultAppNavigationSettings()

		expect(settings.header).toEqual({
			enabled: true,
			showOnAllPages: false,
			order: ['logo', 'name', 'notifications', 'avatar'],
			logoMode: 'image',
			nameMode: 'club',
		})
		expect(settings.menu.items.map((item) => item.path)).toEqual([
			'/app/content/checklists',
			'/app/content/courses',
			'/app/content/other',
			'/app/profile',
		])
		expect(settings.menu.centerButton.enabled).toBe(true)
		expect(settings.menu.backgroundColor).toBe('#101012')
	})

	test('normalizes colors, nulls removed borders, clamps numbers and dedupes header blocks', () => {
		const settings = normalizeAppNavigationSettingsPayload({
			header: {
				enabled: true,
				showOnAllPages: true,
				order: ['avatar', 'avatar', 'logo', 'unknown' as never, 'name'],
				logoMode: 'text',
				nameMode: 'club',
			},
			menu: {
				items: [
					{
						id: 'custom',
						label: ' Поддержка ',
						icon: 'support' as never,
						path: '/app/support',
						requiresAuth: true,
						requiresAccess: false,
					},
				],
				centerButton: {
					enabled: true,
					icon: 'spark' as never,
					imageKey: ' media/btn.png ',
					imageUrl: null,
					glowEnabled: false,
					pressEffectEnabled: true,
					actionPath: 'https://external.example',
					requiresAuth: true,
				},
				backgroundColor: ' #101820 ',
				borderColor: '',
				borderRadius: 999,
				marginBottom: -4,
				marginSide: 50,
				iconStrokeColor: null,
				iconGlowEnabled: true,
				iconHighlightEnabled: false,
				activeIconColor: '#ffffff',
				inactiveIconColor: 'not-a-color',
				startActivePath: '/app',
			},
		} as never)

		expect(settings.header.order).toEqual(['avatar', 'logo', 'name'])
		expect(settings.header.showOnAllPages).toBe(true)
		expect(settings.header.logoMode).toBe('text')
		expect(settings.header.nameMode).toBe('club')
		expect(settings.menu.items).toHaveLength(1)
		expect(settings.menu.items[0]).toMatchObject({
			label: 'Поддержка',
			icon: 'support',
			path: '/app/support',
			requiresAuth: true,
		})
		expect(settings.menu.centerButton).toMatchObject({
			enabled: true,
			imageKey: 'media/btn.png',
			actionPath: '/app',
			requiresAuth: true,
		})
		expect(settings.menu.backgroundColor).toBe('#101820')
		expect(settings.menu.borderColor).toBeNull()
		expect(settings.menu.borderRadius).toBe(40)
		expect(settings.menu.marginBottom).toBe(0)
		expect(settings.menu.marginSide).toBe(32)
		expect(settings.menu.activeIconColor).toBe('#ffffff')
		expect(settings.menu.inactiveIconColor).toBe('#d3c4ad')
	})

	test('falls back to defaults when the stored payload is empty or malformed', () => {
		expect(normalizeAppNavigationSettingsPayload({} as never)).toEqual(
			getDefaultAppNavigationSettings(),
		)
	})
})

describe('legacy material routes', () => {
	test('migrates saved home and menu links to the current material catalogue', () => {
		const home = getDefaultHomeExperienceSettings()
		home.sections[0].internalPath = '/app/materials?type=experts&section=experts'
		expect(normalizeHomeExperienceSettingsPayload(home).sections[0].internalPath).toBe(
			'/app/content/experts',
		)

		const menu = getDefaultAppNavigationSettings()
		menu.menu.items[0].path = '/app/materials?type=streams&section=streams'
		expect(normalizeAppNavigationSettingsPayload(menu).menu.items[0]?.path).toBe(
			'/app/content/streams',
		)
	})
})

describe('home stories', () => {
	test('keeps the full image scale range for repositioning', () => {
		const settings = getDefaultHomeExperienceSettings()
		settings.stories[0].imageScale = 0.1
		expect(normalizeHomeExperienceSettingsPayload(settings).stories[0]?.imageScale).toBe(0.1)
	})
})

describe('home highlights', () => {
	test('normalizes legacy stored highlights to the first five in order', () => {
		// Given: twelve uniquely identified legacy highlights with one valid story each.
		const defaults = getDefaultHomeExperienceSettings()
		const highlights = Array.from({ length: 12 }, (_, index) => ({
			id: `legacy-highlight-${index + 1}`,
			title: `Legacy highlight ${index + 1}`,
			stories: [defaults.stories[0]],
		}))

		// When: the stored payload is normalized.
		const normalized = normalizeHomeExperienceSettingsPayload({
			...defaults,
			highlights,
		})

		// Then: only the first five legacy entries remain, preserving their order.
		expect(normalized.highlights).toHaveLength(5)
		expect(normalized.highlights.map((highlight) => highlight.id)).toEqual([
			'legacy-highlight-1',
			'legacy-highlight-2',
			'legacy-highlight-3',
			'legacy-highlight-4',
			'legacy-highlight-5',
		])
	})

	test('derives highlight story mediaUrl from mediaKey and discards stale input URL', () => {
		// Given: a highlight story with a media key and an obsolete stored URL.
		const defaults = getDefaultHomeExperienceSettings()
		const story = {
			...defaults.stories[0],
			mediaKey: ' highlights/story.webp ',
			mediaUrl: 'https://stale.example/story.webp',
		}

		// When: the payload is normalized and public media URLs are resolved.
		const normalized = normalizeHomeExperienceSettingsPayload({
			...defaults,
			highlights: [{ id: 'highlight-media', title: 'Media', stories: [story] }],
		})
		const resolved = withMediaUrls(normalized)

		// Then: the stale URL is removed before resolving the canonical URL.
		expect(normalized.highlights[0]?.stories[0]?.mediaUrl).toBeNull()
		expect(resolved.highlights[0]?.stories[0]?.mediaUrl).toEndWith('/media/highlights/story.webp')
	})
})

describe('home main banner', () => {
	test('provides an accessible database-backed banner by default', () => {
		expect(getDefaultHomeExperienceSettings().mainBanner).toEqual({
			mediaKey: null,
			mediaUrl: null,
			alt: 'Club App — клуб цифровых решений',
		})
	})

	test('adds the default banner when legacy stored settings do not contain it', () => {
		const legacySettings = getDefaultHomeExperienceSettings()
		Reflect.deleteProperty(legacySettings, 'mainBanner')

		expect(
			parseStoredHomeExperienceSettings([
				{ key: 'home_experience', value: JSON.stringify(legacySettings) },
			]).mainBanner,
		).toEqual(getDefaultHomeExperienceSettings().mainBanner)
	})

	test('persists only the media key and derives the public URL for reads', () => {
		const settings = getDefaultHomeExperienceSettings()
		settings.mainBanner = {
			mediaKey: ' home/main-banner.webp ',
			mediaUrl: 'https://stale.example/main-banner.webp',
			alt: ' Главный баннер клуба ',
		}

		const normalized = normalizeHomeExperienceSettingsPayload(settings)

		expect(normalized.mainBanner).toEqual({
			mediaKey: 'home/main-banner.webp',
			mediaUrl: null,
			alt: 'Главный баннер клуба',
		})
		expect(withMediaUrls(normalized).mainBanner.mediaUrl).toEndWith('/media/home/main-banner.webp')
	})
})

describe('site branding settings', () => {
	test('uses the template logo placeholder by default', () => {
		expect(getDefaultSiteBrandingSettings()).toEqual({
			clubName: 'Club App',
			homeLogoEnabled: true,
			homeLogoMediaKey: null,
			buttonBackgroundColor: '#e2ad2f',
			appBackgroundColor: '#090a0d',
			appSurfaceColor: '#121318',
			appTextColor: '#f7f2e8',
			appAccentColor: '#e2ad2f',
		})
	})

	test('parses stored values, trims the selected media key, and keeps valid colors', () => {
		expect(
			parseStoredSiteBrandingSettings([
				{ key: 'club_name', value: ' Beauty Club ' },
				{ key: 'home_logo_enabled', value: 'false' },
				{ key: 'home_logo_media_key', value: ' media/logo.png ' },
				{ key: 'button_background_color', value: ' #d8b4fe ' },
				{ key: 'app_background_color', value: ' #101820 ' },
			]),
		).toEqual({
			clubName: 'Beauty Club',
			homeLogoEnabled: false,
			homeLogoMediaKey: 'media/logo.png',
			buttonBackgroundColor: '#d8b4fe',
			appBackgroundColor: '#101820',
			appSurfaceColor: '#121318',
			appTextColor: '#f7f2e8',
			appAccentColor: '#e2ad2f',
		})
	})

	test('normalizes blank media keys and invalid button colors to defaults', () => {
		expect(
			normalizeSiteBrandingSettingsPayload({
				clubName: '   ',
				homeLogoEnabled: true,
				homeLogoMediaKey: '   ',
				buttonBackgroundColor: 'not-a-color',
				appBackgroundColor: 'bad',
				appSurfaceColor: 'bad',
				appTextColor: 'bad',
				appAccentColor: 'bad',
			}),
		).toEqual({
			clubName: 'Club App',
			homeLogoEnabled: true,
			homeLogoMediaKey: null,
			buttonBackgroundColor: '#e2ad2f',
			appBackgroundColor: '#090a0d',
			appSurfaceColor: '#121318',
			appTextColor: '#f7f2e8',
			appAccentColor: '#e2ad2f',
		})
	})

	test('returns a logo URL only when the logo is enabled and selected', () => {
		expect(
			buildSiteBrandingSettings(
				{
					clubName: 'Beauty Club',
					homeLogoEnabled: true,
					homeLogoMediaKey: 'media/logo.png',
					buttonBackgroundColor: '#d8b4fe',
					appBackgroundColor: '#141414',
					appSurfaceColor: '#242424',
					appTextColor: '#f4f4f5',
					appAccentColor: '#d42d2f',
				},
				'https://cdn.example.com/logo.png',
			),
		).toEqual({
			clubName: 'Beauty Club',
			homeLogoEnabled: true,
			homeLogoMediaKey: 'media/logo.png',
			buttonBackgroundColor: '#d8b4fe',
			appBackgroundColor: '#141414',
			appSurfaceColor: '#242424',
			appTextColor: '#f4f4f5',
			appAccentColor: '#d42d2f',
			homeLogoUrl: 'https://cdn.example.com/logo.png',
		})

		expect(
			buildSiteBrandingSettings(
				{
					clubName: 'Beauty Club',
					homeLogoEnabled: false,
					homeLogoMediaKey: 'media/logo.png',
					buttonBackgroundColor: '#d8b4fe',
					appBackgroundColor: '#141414',
					appSurfaceColor: '#242424',
					appTextColor: '#f4f4f5',
					appAccentColor: '#d42d2f',
				},
				'https://cdn.example.com/logo.png',
			),
		).toEqual({
			clubName: 'Beauty Club',
			homeLogoEnabled: false,
			homeLogoMediaKey: 'media/logo.png',
			buttonBackgroundColor: '#d8b4fe',
			appBackgroundColor: '#141414',
			appSurfaceColor: '#242424',
			appTextColor: '#f4f4f5',
			appAccentColor: '#d42d2f',
			homeLogoUrl: null,
		})
	})
})

describe('auth login settings', () => {
	test('keeps password login enabled by default', () => {
		expect(getDefaultAuthLoginSettings()).toEqual({
			passwordEnabled: true,
			telegramCodeEnabled: true,
			maxCodeEnabled: false,
			defaultMethod: 'password',
			botAuthEnabled: false,
		})
	})

	test('parses enabled messenger methods and a matching default method', () => {
		expect(
			parseStoredAuthLoginSettings([
				{ key: 'auth_login_password_enabled', value: 'false' },
				{ key: 'auth_login_telegram_code_enabled', value: 'true' },
				{ key: 'auth_login_max_code_enabled', value: 'true' },
				{ key: 'auth_login_default_method', value: 'max' },
			]),
		).toEqual({
			passwordEnabled: false,
			telegramCodeEnabled: true,
			maxCodeEnabled: true,
			defaultMethod: 'max',
			botAuthEnabled: false,
		})
	})

	test('falls back to the first enabled method and never disables every login method', () => {
		expect(
			normalizeAuthLoginSettingsPayload({
				passwordEnabled: false,
				telegramCodeEnabled: true,
				maxCodeEnabled: false,
				defaultMethod: 'password',
			}),
		).toEqual({
			passwordEnabled: false,
			telegramCodeEnabled: true,
			maxCodeEnabled: false,
			defaultMethod: 'telegram',
			botAuthEnabled: false,
		})

		expect(
			normalizeAuthLoginSettingsPayload({
				passwordEnabled: false,
				telegramCodeEnabled: false,
				maxCodeEnabled: false,
				defaultMethod: 'max',
			}),
		).toEqual({
			passwordEnabled: true,
			telegramCodeEnabled: false,
			maxCodeEnabled: false,
			defaultMethod: 'password',
			botAuthEnabled: false,
		})
	})

	test('allows the Telegram bot as the only login method', () => {
		expect(
			normalizeAuthLoginSettingsPayload({
				passwordEnabled: false,
				telegramCodeEnabled: false,
				maxCodeEnabled: false,
				defaultMethod: 'telegram',
				botAuthEnabled: true,
			}),
		).toEqual({
			passwordEnabled: false,
			telegramCodeEnabled: false,
			maxCodeEnabled: false,
			defaultMethod: 'telegram',
			botAuthEnabled: true,
		})
	})
})

describe('test access settings', () => {
	test('keeps test access enabled by default', () => {
		expect(getDefaultTestAccessSettings()).toEqual({
			enabled: true,
			days: 7,
		})
	})

	test('parses stored settings and clamps days', () => {
		expect(
			parseStoredTestAccessSettings([
				{ key: 'test_access', value: JSON.stringify({ enabled: false, days: 14 }) },
			]),
		).toEqual({
			enabled: false,
			days: 14,
		})

		expect(normalizeTestAccessSettingsPayload({ enabled: true, days: 500 })).toEqual({
			enabled: true,
			days: 365,
		})
	})
})

describe('legal document settings', () => {
	test('keeps all required documents and normalizes stored overrides', () => {
		const defaults = getDefaultLegalDocumentsSettings()

		expect(defaults.documents.map((document) => document.key)).toEqual([
			'privacy',
			'personalData',
			'oferta',
			'requisites',
			'cookie',
		])

		expect(
			parseStoredLegalDocumentsSettings([
				{
					key: 'legal_documents',
					value: JSON.stringify({
						documents: [
							{
								key: 'privacy',
								title: ' Новая политика ',
								linkLabel: ' политикой ',
								enabled: false,
								body: ' Текст ',
							},
						],
					}),
				},
			]).documents[0],
		).toEqual({
			key: 'privacy',
			title: 'Новая политика',
			linkLabel: 'политикой',
			enabled: false,
			body: 'Текст',
		})

		expect(normalizeLegalDocumentsSettingsPayload({ documents: [] }).documents).toHaveLength(5)
	})
})

describe('telegram bot auth settings', () => {
	test('keeps sensible defaults and normalizes the bot handle', () => {
		const defaults = getDefaultTelegramBotAuthSettings()
		expect(defaults.botHandle).toBe('')
		expect(defaults.codeMessageText).toContain('{code}')

		const normalized = normalizeTelegramBotAuthSettingsPayload({
			botHandle: '@my_club_bot ',
			noAccessText: '',
			codeMessageText: '',
			subscriptionButtonLabel: '',
			subscriptionButtonUrl: '   ',
			openAppButtonLabel: '',
		})
		expect(normalized.botHandle).toBe('my_club_bot')
		expect(normalized.noAccessText).toBe(defaults.noAccessText)
		expect(normalized.subscriptionButtonUrl).toBe('')
	})
})
