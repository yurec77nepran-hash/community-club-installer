export function isSafeInternalReturnPath(value: string) {
	const path = value.trim()
	if (!path.startsWith('/')) return false
	if (path.startsWith('//')) return false
	if (path.includes('\\')) return false

	try {
		const decoded = decodeURIComponent(path)
		if (decoded.startsWith('//') || decoded.includes('\\')) return false
	} catch {
		return false
	}

	return true
}

export function buildInternalReturnUrl(
	path: string | undefined,
	fallback: string,
	baseUrl: string,
) {
	const safePath = path?.trim() && isSafeInternalReturnPath(path) ? path.trim() : fallback
	return new URL(safePath, baseUrl)
}
