export type ChatUserRole = 'user' | 'admin' | 'superadmin'
export type ChatAccessRole = 'all'
export type ChatMemberRole = 'member' | 'admin' | 'superadmin'

export function canAccessByRole(userRole: ChatUserRole, accessRole: ChatAccessRole): boolean {
	void accessRole
	if (userRole === 'admin' || userRole === 'superadmin') {
		return true
	}

	return userRole === 'user'
}

export function canUseChatMemberOverride(memberRole: ChatMemberRole | null | undefined): boolean {
	return memberRole === 'member' || memberRole === 'admin' || memberRole === 'superadmin'
}

export function canAccessRegularChat(params: {
	userRole: ChatUserRole
	accessRole: ChatAccessRole
	memberRole: ChatMemberRole | null | undefined
}): boolean {
	return (
		canAccessByRole(params.userRole, params.accessRole) ||
		canUseChatMemberOverride(params.memberRole)
	)
}

export function getRolesForChatAccess(accessRole: ChatAccessRole): ChatUserRole[] {
	void accessRole
	return ['user', 'admin', 'superadmin']
}
