import { describe, expect, test } from 'bun:test'
import { buildClubAccessMap, hasTypeAccess } from './materials-access'

describe('club material access', () => {
	test('does not split members by material section flags', () => {
		expect(buildClubAccessMap()).toEqual({})
	})

	test('allows all published material sections for active members', () => {
		const base = {
			userRole: 'user',
			contentSections: [],
			clubAccess: {},
		}

		expect(hasTypeAccess({ ...base, type: 'courses' })).toBe(true)
		expect(hasTypeAccess({ ...base, type: 'streams' })).toBe(true)
		expect(hasTypeAccess({ ...base, type: 'other' })).toBe(true)
	})
})
