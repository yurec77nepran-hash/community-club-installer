import type { PaymentCheckoutSettings } from '@community-club/shared/types'

type CloudPaymentsInterval = 'Day' | 'Week' | 'Month'

export function buildTariffRecurrentConfig(durationDays: number, regularAmount: number) {
	if (durationDays === 365) return { interval: 'Month' as const, period: 12, amount: regularAmount }
	if (durationDays === 90) return { interval: 'Month' as const, period: 3, amount: regularAmount }
	if (durationDays === 30) return { interval: 'Month' as const, period: 1, amount: regularAmount }
	if (durationDays === 7) return { interval: 'Week' as const, period: 1, amount: regularAmount }

	return { interval: 'Day' as const, period: durationDays, amount: regularAmount }
}

function addDays(base: Date, days: number) {
	const next = new Date(base)
	next.setUTCDate(next.getUTCDate() + days)
	return next
}

export function buildCloudPaymentsRecurrentConfig(params: {
	settings: PaymentCheckoutSettings
	durationDays: number
	firstAccessDays: number
	regularAmount: number
	now?: Date
}) {
	const byTariff = buildTariffRecurrentConfig(params.durationDays, params.regularAmount)
	const interval =
		params.settings.recurrentInterval === 'tariff'
			? byTariff.interval
			: (params.settings.recurrentInterval as CloudPaymentsInterval)
	const period =
		params.settings.recurrentInterval === 'tariff'
			? byTariff.period
			: Math.max(1, Math.trunc(params.settings.recurrentPeriod || 1))
	const startDelayDays =
		params.settings.recurrentStartDelayDays == null
			? params.firstAccessDays
			: Math.max(1, Math.trunc(params.settings.recurrentStartDelayDays))
	const recurrent: Record<string, string | number> = {
		interval,
		period,
		amount: params.regularAmount,
		startDate: addDays(params.now ?? new Date(), startDelayDays).toISOString(),
	}

	if (params.settings.recurrentMaxPeriods && params.settings.recurrentMaxPeriods > 0) {
		recurrent.maxPeriods = Math.trunc(params.settings.recurrentMaxPeriods)
	}

	return recurrent
}
