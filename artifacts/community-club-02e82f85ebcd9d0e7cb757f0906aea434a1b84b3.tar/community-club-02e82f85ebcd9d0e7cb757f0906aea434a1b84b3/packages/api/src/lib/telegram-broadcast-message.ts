import {
	type TelegramBroadcastButton,
	type TelegramBroadcastMediaType,
	telegramBroadcastPlainText,
} from '@community-club/shared'
import {
	type TelegramInlineKeyboardButton,
	postJsonWithToken,
	requestText,
	sendTelegramMessageWithToken,
} from './telegram'

const telegramMethodByMediaType: Record<TelegramBroadcastMediaType, string> = {
	image: 'sendPhoto',
	video: 'sendVideo',
	audio: 'sendAudio',
	document: 'sendDocument',
}

const telegramMediaFieldByType: Record<TelegramBroadcastMediaType, string> = {
	image: 'photo',
	video: 'video',
	audio: 'audio',
	document: 'document',
}

function createInlineKeyboard(buttons: TelegramBroadcastButton[]) {
	if (!buttons.length) return undefined
	const inlineKeyboard: TelegramInlineKeyboardButton[][] = buttons.map((button) => [
		{
			text: button.text,
			url: button.url,
			...(button.color === 'default' ? {} : { style: button.color }),
		},
	])
	return { inline_keyboard: inlineKeyboard }
}

export async function sendTelegramBroadcastMessage(params: {
	token: string
	chatId: string
	body: string
	buttons: TelegramBroadcastButton[]
	media: { type: TelegramBroadcastMediaType; url: string } | null
}) {
	const replyMarkup = createInlineKeyboard(params.buttons)
	const useCaption =
		Boolean(params.media && params.body) && telegramBroadcastPlainText(params.body).length <= 1024
	if (params.media) {
		await postJsonWithToken(params.token, telegramMethodByMediaType[params.media.type], {
			chat_id: params.chatId,
			[telegramMediaFieldByType[params.media.type]]: params.media.url,
			...(useCaption
				? { caption: params.body, parse_mode: 'HTML', reply_markup: replyMarkup }
				: params.body
					? {}
					: { reply_markup: replyMarkup }),
		})
	}
	if (params.body && !useCaption) {
		await sendTelegramMessageWithToken(params.token, params.chatId, params.body, {
			parseMode: 'HTML',
			replyMarkup,
		})
	}
}

export async function findTelegramChatIdByUsername(token: string, username: string) {
	const raw = await requestText(
		`https://api.telegram.org/bot${token}/getUpdates?allowed_updates=${encodeURIComponent(
			JSON.stringify(['message']),
		)}`,
	)
	const payload = JSON.parse(raw) as {
		ok?: boolean
		result?: Array<{ message?: { chat?: { id?: number }; from?: { username?: string } } }>
	}
	if (!payload.ok) return null
	const message = payload.result?.find(
		(item) => item.message?.from?.username?.toLowerCase() === username.toLowerCase(),
	)?.message
	return message?.chat?.id ? String(message.chat.id) : null
}
