type CloudPaymentsWebhookBody = Record<string, unknown> & {
	AccountId?: string
	Amount?: string | number
	InvoiceId?: string
	SubscriptionId?: string
	TransactionId?: string | number
}

type WebhookAmountValidationResult =
	| { ok: true; expectedMinor: number | null; receivedMinor: number | null }
	| { ok: false; expectedMinor: number; receivedMinor: number }

function cleanPart(value: unknown) {
	const normalized = String(value ?? '').trim()
	return normalized || null
}

export function buildCloudPaymentsIdempotencyKey(event: string, body: CloudPaymentsWebhookBody) {
	const transactionId = cleanPart(body.TransactionId)
	if (transactionId) {
		return `cloudpayments:${event}:transaction:${transactionId}`
	}

	const subscriptionId = cleanPart(body.SubscriptionId)
	const invoiceId = cleanPart(body.InvoiceId)
	if (subscriptionId && invoiceId) {
		const amount = cleanPart(body.Amount) ?? 'unknown'
		return `cloudpayments:${event}:subscription:${subscriptionId}:invoice:${invoiceId}:amount:${amount}`
	}

	const accountId = cleanPart(body.AccountId)
	if (accountId && invoiceId) {
		return `cloudpayments:${event}:account:${accountId}:invoice:${invoiceId}`
	}

	return null
}

export function normalizeMinorUnits(value: unknown) {
	const parsed = Number(String(value ?? '').replace(',', '.'))
	if (!Number.isFinite(parsed)) return null
	return Math.round(parsed * 100)
}

export function validateWebhookAmount(params: {
	expected: unknown
	received: unknown
}): WebhookAmountValidationResult {
	const expectedMinor = normalizeMinorUnits(params.expected)
	const receivedMinor = normalizeMinorUnits(params.received)

	if (expectedMinor == null || receivedMinor == null) {
		return { ok: true, expectedMinor, receivedMinor }
	}

	if (expectedMinor !== receivedMinor) {
		return { ok: false, expectedMinor, receivedMinor }
	}

	return { ok: true, expectedMinor, receivedMinor }
}

function maskEmail(value: string) {
	const [local, domain] = value.split('@')
	if (!local || !domain) return '[redacted]'
	return `${local.slice(0, 1)}***@${domain}`
}

function maskPhone(value: string) {
	const digits = value.replace(/\D/g, '')
	if (digits.length < 6) return '[redacted]'
	const prefix = value.startsWith('+') ? `+${digits.slice(0, 2)}` : digits.slice(0, 2)
	return `${prefix}***${digits.slice(-2)}`
}

function isSensitiveKey(key: string) {
	const normalized = key.toLowerCase()
	return (
		normalized.includes('token') ||
		normalized.includes('secret') ||
		normalized.includes('password') ||
		normalized.includes('cryptogram') ||
		normalized.includes('authorization') ||
		normalized.includes('signature')
	)
}

function redactValue(key: string, value: unknown, depth: number): unknown {
	if (isSensitiveKey(key)) return '[redacted]'
	if (typeof value === 'string' && key.toLowerCase().includes('email')) return maskEmail(value)
	if (typeof value === 'string' && key.toLowerCase().includes('phone')) return maskPhone(value)
	if (!value || typeof value !== 'object' || depth >= 5) return value

	if (Array.isArray(value)) {
		return value.map((item) => redactValue(key, item, depth + 1))
	}

	return redactPaymentWebhookPayload(value as Record<string, unknown>, depth + 1)
}

export function redactPaymentWebhookPayload(
	payload: Record<string, unknown>,
	depth = 0,
): Record<string, unknown> {
	return Object.fromEntries(
		Object.entries(payload).map(([key, value]) => [key, redactValue(key, value, depth)]),
	)
}
