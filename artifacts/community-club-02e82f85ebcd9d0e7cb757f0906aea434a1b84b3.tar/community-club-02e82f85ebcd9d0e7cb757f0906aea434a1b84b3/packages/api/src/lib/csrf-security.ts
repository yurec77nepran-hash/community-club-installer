const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS'])

type BrowserMutationValidation = {
	method: string
	path: string
	hasCookieAuth: boolean
	origin: string | null
	referer: string | null
	csrfCookie: string | null
	csrfHeader: string | null
	allowedOrigins: string[]
}

type BrowserMutationValidationResult =
	| {
			ok: true
			reason:
				| 'safe_method'
				| 'no_cookie_auth'
				| 'trusted_auth_refresh'
				| 'service_worker_path'
				| 'csrf_token'
	  }
	| { ok: false; reason: 'untrusted_origin' | 'missing_csrf' }

function normalizeOrigin(value: string | null | undefined) {
	if (!value) return null
	try {
		return new URL(value).origin
	} catch {
		return null
	}
}

function normalizeAllowedOrigins(values: string[]) {
	return new Set(values.map(normalizeOrigin).filter((origin): origin is string => Boolean(origin)))
}

function sameToken(left: string | null, right: string | null) {
	return Boolean(left && right && left.length >= 24 && left === right)
}

function isTrustedRefreshFallbackPath(path: string) {
	return path === '/api/auth/refresh'
}

function isServiceWorkerFallbackPath(path: string) {
	return path === '/api/push/subscribe'
}

export function validateBrowserMutation(
	params: BrowserMutationValidation,
): BrowserMutationValidationResult {
	if (SAFE_METHODS.has(params.method.toUpperCase())) {
		return { ok: true, reason: 'safe_method' }
	}

	const allowed = normalizeAllowedOrigins(params.allowedOrigins)
	const requestOrigin = normalizeOrigin(params.origin)
	const refererOrigin = normalizeOrigin(params.referer)
	const browserOrigin = requestOrigin ?? refererOrigin

	if (browserOrigin && !allowed.has(browserOrigin)) {
		return { ok: false, reason: 'untrusted_origin' }
	}

	if (!params.hasCookieAuth) {
		return { ok: true, reason: 'no_cookie_auth' }
	}

	if (sameToken(params.csrfCookie, params.csrfHeader)) {
		return { ok: true, reason: 'csrf_token' }
	}

	if (browserOrigin && isTrustedRefreshFallbackPath(params.path)) {
		return { ok: true, reason: 'trusted_auth_refresh' }
	}

	if (isServiceWorkerFallbackPath(params.path) && (!browserOrigin || allowed.has(browserOrigin))) {
		return { ok: true, reason: 'service_worker_path' }
	}

	return { ok: false, reason: 'missing_csrf' }
}
