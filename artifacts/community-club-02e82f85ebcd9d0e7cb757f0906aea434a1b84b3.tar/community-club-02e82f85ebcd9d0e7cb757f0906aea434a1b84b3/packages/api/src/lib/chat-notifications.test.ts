import { describe, expect, test } from 'bun:test'
import { buildChatPushNotificationPayload } from './chat-notification-payload'

describe('buildChatPushNotificationPayload', () => {
	const baseParams = {
		chatName: 'Чат клуба',
		authorName: 'Олег',
		content: 'Посмотрите новый разбор',
		messageType: 'text',
		attachmentName: null,
		url: '/app/chats/1?messageId=42',
	}

	test('builds a clear payload for a regular chat message', () => {
		expect(buildChatPushNotificationPayload({ ...baseParams, kind: 'message' })).toEqual({
			title: 'Чат клуба',
			body: 'Олег: Посмотрите новый разбор',
			url: '/app/chats/1?messageId=42',
		})
	})

	test('includes the source message when a user receives a reply', () => {
		expect(
			buildChatPushNotificationPayload({
				...baseParams,
				kind: 'replyToYou',
				replyPreview: 'А где найти чек-лист?',
			}),
		).toEqual({
			title: 'Ответ на ваше сообщение в чате «Чат клуба»',
			body: 'Олег: ответ на «А где найти чек-лист?». Посмотрите новый разбор',
			url: '/app/chats/1?messageId=42',
		})
	})

	test('shows reply context for other chat members too', () => {
		expect(
			buildChatPushNotificationPayload({
				...baseParams,
				kind: 'reply',
				replyPreview: 'А где найти чек-лист?',
			}).title,
		).toBe('Ответ в чате «Чат клуба»')
	})

	test('keeps attachment-only messages readable', () => {
		expect(
			buildChatPushNotificationPayload({
				...baseParams,
				kind: 'mention',
				content: '',
				messageType: 'voice',
			}),
		).toEqual({
			title: 'Вас упомянули в чате «Чат клуба»',
			body: 'Олег: Голосовое сообщение',
			url: '/app/chats/1?messageId=42',
		})
	})
})
