import { describe, expect, test } from 'bun:test'
import { parsePhpFormData, signProdamusPayload, verifyProdamusSignature } from './prodamus'

describe('Prodamus signature', () => {
	const secret = 'test-secret-key'

	test('signs and verifies sorted stringified payloads', () => {
		const left = {
			order_id: 123,
			payment_status: 'success',
			products: [{ quantity: 1, name: 'Тариф / клуб', price: 1500 }],
		}
		const right = {
			products: [{ price: '1500', name: 'Тариф / клуб', quantity: '1' }],
			payment_status: 'success',
			order_id: '123',
		}

		const signature = signProdamusPayload(left, secret)

		expect(signProdamusPayload(right, secret)).toBe(signature)
		expect(verifyProdamusSignature({ payload: right, signature, secret })).toBe(true)
		expect(
			verifyProdamusSignature({ payload: right, signature: signature.toUpperCase(), secret }),
		).toBe(true)
		expect(
			verifyProdamusSignature({ payload: right, signature: `sha256=${signature}`, secret }),
		).toBe(true)
	})

	test('rejects changed payloads', () => {
		const payload = { order_id: '123', sum: '1500.00' }
		const signature = signProdamusPayload(payload, secret)

		expect(
			verifyProdamusSignature({
				payload: { ...payload, sum: '1.00' },
				signature,
				secret,
			}),
		).toBe(false)
	})

	test('rejects verification when the secret is not configured', () => {
		const payload = { order_id: '123', sum: '1500.00' }
		const signature = signProdamusPayload(payload, secret)

		expect(verifyProdamusSignature({ payload, signature, secret: '' })).toBe(false)
	})

	test('parses php-style form arrays and supports flat signature fallback', () => {
		const entries: [string, string][] = [
			['order_id', '123'],
			['products[0][name]', 'Gold'],
			['products[0][price]', '5000'],
			['products[0][quantity]', '1'],
		]
		const nested = parsePhpFormData(entries)
		const flat = Object.fromEntries(entries)
		const flatSignature = signProdamusPayload(flat, secret)

		expect(nested).toEqual({
			order_id: '123',
			products: [{ name: 'Gold', price: '5000', quantity: '1' }],
		})
		expect(verifyProdamusSignature({ payload: nested, signature: flatSignature, secret })).toBe(
			false,
		)
		expect(
			verifyProdamusSignature({
				payload: nested,
				flatPayload: flat,
				signature: flatSignature,
				secret,
			}),
		).toBe(true)
	})
})
