import { sql } from 'drizzle-orm'
import { db } from '../db/client'

export async function ensurePushCampaignArtifacts() {
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS push_campaigns (
			id serial PRIMARY KEY,
			name text NOT NULL,
			kind text NOT NULL,
			status text NOT NULL DEFAULT 'draft',
			audience text NOT NULL DEFAULT 'all',
			title text NOT NULL,
			body text NOT NULL,
			url text,
			offset_days integer[] NOT NULL DEFAULT '{}',
			send_at timestamptz,
			is_enabled boolean NOT NULL DEFAULT true,
			last_run_at timestamptz,
			processing_started_at timestamptz,
			last_run_sent integer NOT NULL DEFAULT 0,
			last_run_failed integer NOT NULL DEFAULT 0,
			last_run_audience_size integer NOT NULL DEFAULT 0,
			last_error text,
			created_by_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)

	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS push_campaign_runs (
			id serial PRIMARY KEY,
			campaign_id integer NOT NULL REFERENCES push_campaigns(id) ON DELETE CASCADE,
			run_key text NOT NULL,
			scheduled_for date NOT NULL,
			offset_days integer,
			status text NOT NULL DEFAULT 'processing',
			audience_size integer NOT NULL DEFAULT 0,
			subscription_count integer NOT NULL DEFAULT 0,
			sent_count integer NOT NULL DEFAULT 0,
			failed_count integer NOT NULL DEFAULT 0,
			error_message text,
			started_at timestamptz NOT NULL DEFAULT now(),
			completed_at timestamptz
		)
	`)

	await db.execute(sql`
		CREATE UNIQUE INDEX IF NOT EXISTS push_campaign_runs_unique
		ON push_campaign_runs (campaign_id, run_key)
	`)

	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS push_campaign_runs_campaign_idx
		ON push_campaign_runs (campaign_id, started_at DESC)
	`)

	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS push_campaigns_kind_status_idx
		ON push_campaigns (kind, status)
	`)

	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS push_campaigns_enabled_idx
		ON push_campaigns (is_enabled, kind)
	`)

	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS push_campaigns_send_at_idx
		ON push_campaigns (send_at)
	`)

	await db.execute(sql`
		UPDATE push_campaigns
		SET audience = CASE
			WHEN audience LIKE 'active_%' THEN 'active'
			ELSE 'all'
		END
		WHERE audience NOT IN ('all', 'active')
	`)

	await db.execute(sql`
		INSERT INTO push_campaigns (
			name,
			kind,
			status,
			audience,
			title,
			body,
			url,
			offset_days,
			is_enabled
		)
		SELECT
			'Напоминание о списании',
			'billing_relative',
			'active',
			'all',
			'Скоро продление клуба',
			'Проверьте карту для автосписания, чтобы доступ не прерывался.',
			'/app/payment',
			ARRAY[5, 3, 2, 1, 0],
			true
		WHERE NOT EXISTS (
			SELECT 1
			FROM push_campaigns
			WHERE kind = 'billing_relative'
				AND name = 'Напоминание о списании'
		)
	`)
}
