import { describe, expect, test } from 'bun:test'
import { validateBrowserMutation } from './csrf-security'

const allowedOrigins = ['https://club.example.com', 'https://club.example.com/admin']

describe('browser mutation CSRF guard', () => {
	test('allows safe methods without CSRF checks', () => {
		expect(
			validateBrowserMutation({
				method: 'GET',
				path: '/api/users/me',
				hasCookieAuth: true,
				origin: null,
				referer: null,
				csrfCookie: null,
				csrfHeader: null,
				allowedOrigins,
			}).ok,
		).toBe(true)
	})

	test('rejects cookie-auth mutations from an untrusted origin', () => {
		expect(
			validateBrowserMutation({
				method: 'POST',
				path: '/api/users/me',
				hasCookieAuth: true,
				origin: 'https://evil.example.net',
				referer: null,
				csrfCookie: 'token',
				csrfHeader: 'token',
				allowedOrigins,
			}).ok,
		).toBe(false)
	})

	test('allows cookie-auth mutations with a matching double-submit token', () => {
		expect(
			validateBrowserMutation({
				method: 'PATCH',
				path: '/api/users/me',
				hasCookieAuth: true,
				origin: null,
				referer: null,
				csrfCookie: 'csrf-token-with-enough-entropy',
				csrfHeader: 'csrf-token-with-enough-entropy',
				allowedOrigins,
			}).ok,
		).toBe(true)
	})

	test('requires a double-submit token for ordinary trusted-origin mutations', () => {
		expect(
			validateBrowserMutation({
				method: 'POST',
				path: '/api/users/me',
				hasCookieAuth: true,
				origin: 'https://club.example.com',
				referer: null,
				csrfCookie: null,
				csrfHeader: null,
				allowedOrigins,
			}).ok,
		).toBe(false)
	})

	test('allows trusted refresh fallback so old cookie sessions can mint a CSRF cookie', () => {
		expect(
			validateBrowserMutation({
				method: 'POST',
				path: '/api/auth/refresh',
				hasCookieAuth: true,
				origin: 'https://club.example.com',
				referer: null,
				csrfCookie: null,
				csrfHeader: null,
				allowedOrigins,
			}).ok,
		).toBe(true)
	})

	test('allows service-worker initiated push resubscribe without document cookie access', () => {
		expect(
			validateBrowserMutation({
				method: 'POST',
				path: '/api/push/subscribe',
				hasCookieAuth: true,
				origin: null,
				referer: null,
				csrfCookie: null,
				csrfHeader: null,
				allowedOrigins,
			}).ok,
		).toBe(true)
	})

	test('rejects unsafe browser requests from untrusted origins even without cookies', () => {
		expect(
			validateBrowserMutation({
				method: 'POST',
				path: '/api/auth/login',
				hasCookieAuth: false,
				origin: 'https://evil.example.net',
				referer: null,
				csrfCookie: null,
				csrfHeader: null,
				allowedOrigins,
			}).ok,
		).toBe(false)
	})
})
