import { describe, expect, test } from 'bun:test'
import { resolveScheduledMessageDate } from './scheduled-chat-message-utils'

describe('resolveScheduledMessageDate', () => {
	test('accepts future timestamps', () => {
		const result = resolveScheduledMessageDate('2026-04-22T10:05:00.000Z', {
			now: new Date('2026-04-22T10:00:00.000Z'),
		})

		expect(result.ok).toBe(true)
		if (result.ok) {
			expect(result.value.toISOString()).toBe('2026-04-22T10:05:00.000Z')
		}
	})

	test('rejects past timestamps', () => {
		const result = resolveScheduledMessageDate('2026-04-22T09:59:59.000Z', {
			now: new Date('2026-04-22T10:00:00.000Z'),
		})

		expect(result.ok).toBe(false)
		if (!result.ok) {
			expect(result.message).toBe('Дата отправки уже прошла')
		}
	})
})
