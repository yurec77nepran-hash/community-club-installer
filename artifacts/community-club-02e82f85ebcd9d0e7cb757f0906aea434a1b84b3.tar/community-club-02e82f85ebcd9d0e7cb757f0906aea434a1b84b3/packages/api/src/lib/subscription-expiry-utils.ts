export function isSubscriptionExpiredByMoscowDate(
	dateFinish: string | Date | null | undefined,
	todayMoscow: string,
) {
	if (!dateFinish) return false

	const dateOnly =
		dateFinish instanceof Date ? dateFinish.toISOString().slice(0, 10) : String(dateFinish).trim()

	if (!/^\d{4}-\d{2}-\d{2}$/.test(dateOnly)) return false

	return dateOnly < todayMoscow
}
