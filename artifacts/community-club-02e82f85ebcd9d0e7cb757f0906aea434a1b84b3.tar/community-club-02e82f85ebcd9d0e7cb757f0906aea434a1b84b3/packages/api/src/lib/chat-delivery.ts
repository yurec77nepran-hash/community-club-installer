import type { MentionPayload } from '@community-club/shared'
import { messages, users } from '@community-club/shared'
import { and, desc, eq } from 'drizzle-orm'
import { db } from '../db/client'
import { ensureChatAccess } from './chat-access'
import {
	createMessageMentions,
	ensureUnreadRecipientMemberships,
	incrementUnreadMessages,
	loadMessageWithMeta,
	normalizeMentions,
} from './chat-mentions'
import {
	sendChatMessagePushNotifications,
	sendChatMessageTelegramNotifications,
} from './chat-notifications'
import { isChatManager, normalizeChatSettings } from './chat-settings'
import { sendSupportTelegramNotification } from './support-telegram-notifications'

type UserRole = Parameters<typeof ensureChatAccess>[0]['userRole']

function getChatPushUrl(chat: { slug: string; id: number }, messageId: number) {
	const path = chat.slug.startsWith('support') ? '/app/support' : `/app/chats/${chat.id}`
	return `${path}?messageId=${messageId}`
}

function getReplyPreview(message: {
	content: string | null
	messageType: string
	attachmentName: string | null
}) {
	const content = message.content?.trim()
	if (content) return content

	switch (message.messageType) {
		case 'voice':
			return 'Голосовое сообщение'
		case 'image':
			return 'Фото'
		case 'video':
			return 'Видео'
		case 'audio':
			return 'Аудио'
		case 'document':
			return message.attachmentName || 'Файл'
		default:
			return 'Сообщение'
	}
}

export async function deliverChatMessage(params: {
	chatId: number
	userId: string
	userRole: UserRole
	content: string
	replyToId?: number | null
	clientMessageId?: string | null
	messageType: 'text' | 'image' | 'video' | 'voice' | 'audio' | 'document' | 'link'
	attachmentUrl?: string | null
	attachmentName?: string | null
	attachmentSize?: number | null
	mentions?: MentionPayload[]
}) {
	const access = await ensureChatAccess({
		chatId: params.chatId,
		userId: params.userId,
		userRole: params.userRole,
	})
	if (!access.ok) {
		return {
			ok: false as const,
			code: access.code,
			message: access.message,
			status: access.code === 'NOT_FOUND' ? 404 : 403,
		}
	}

	if (access.member?.status === 'muted') {
		return {
			ok: false as const,
			code: 'FORBIDDEN',
			message: 'Вы временно не можете писать в этот чат',
			status: 403,
		}
	}

	const settings = normalizeChatSettings(access.chat.settings)
	const canManage = isChatManager(params.userRole, access.member?.role)
	if (!canManage && !settings.allowMemberMessages) {
		return {
			ok: false as const,
			code: 'FORBIDDEN',
			message: 'Сообщения в этом чате сейчас закрыты',
			status: 403,
		}
	}
	if (!canManage && params.messageType !== 'text' && !settings.allowAttachments) {
		return {
			ok: false as const,
			code: 'FORBIDDEN',
			message: 'Вложения в этом чате отключены',
			status: 403,
		}
	}
	if (!canManage && settings.slowModeSeconds > 0) {
		const latestOwnMessage = await db.query.messages.findFirst({
			where: and(
				eq(messages.chatId, params.chatId),
				eq(messages.userAuthUuid, params.userId),
				eq(messages.isDeleted, false),
			),
			columns: { createdAt: true },
			orderBy: [desc(messages.createdAt)],
		})
		const latestAt = latestOwnMessage ? new Date(latestOwnMessage.createdAt).getTime() : 0
		const waitMs = latestAt + settings.slowModeSeconds * 1000 - Date.now()
		if (waitMs > 0) {
			return {
				ok: false as const,
				code: 'RATE_LIMITED',
				message: `Следующее сообщение можно отправить через ${Math.ceil(waitMs / 1000)} сек.`,
				status: 429,
			}
		}
	}

	const normalizedContent = params.content.slice(0, 4000).trimEnd()
	const normalizedAttachmentUrl =
		typeof params.attachmentUrl === 'string' ? params.attachmentUrl.slice(0, 2048) : null
	if (!normalizedContent && !normalizedAttachmentUrl) {
		return {
			ok: false as const,
			code: 'BAD_REQUEST',
			message: 'Сообщение не может быть пустым',
			status: 400,
		}
	}

	const clientMessageId = params.clientMessageId?.trim().slice(0, 128) || null
	const mentions = await normalizeMentions({
		chatId: params.chatId,
		userId: params.userId,
		userRole: params.userRole,
		content: normalizedContent,
		mentions: params.mentions,
	})

	if (clientMessageId) {
		const existing = await db.query.messages.findFirst({
			where: and(
				eq(messages.chatId, params.chatId),
				eq(messages.userAuthUuid, params.userId),
				eq(messages.clientMessageId, clientMessageId),
			),
		})
		if (existing) {
			const existingMessage = await loadMessageWithMeta(existing.id)
			if (existingMessage) {
				return {
					ok: true as const,
					duplicate: true,
					message: existingMessage,
					access,
				}
			}
		}
	}

	const [savedMessage] = await db
		.insert(messages)
		.values({
			chatId: params.chatId,
			userAuthUuid: params.userId,
			content: normalizedContent,
			replyToId: params.replyToId ?? null,
			clientMessageId,
			messageType: params.messageType,
			attachmentUrl: normalizedAttachmentUrl,
			attachmentName: params.attachmentName?.slice(0, 255) ?? null,
			attachmentSize: params.attachmentSize ?? null,
		})
		.returning()

	await ensureUnreadRecipientMemberships({
		chatId: params.chatId,
		authorUserId: params.userId,
		messageId: savedMessage.id,
	})
	await createMessageMentions({
		chatId: params.chatId,
		messageId: savedMessage.id,
		authorUserId: params.userId,
		mentions: mentions.map((mention) => ({
			mentionedUserAuthUuid: mention.mentionedUserAuthUuid,
			displayName: mention.displayName,
			startOffset: mention.startOffset,
			endOffset: mention.endOffset,
		})),
	})
	await incrementUnreadMessages({
		chatId: params.chatId,
		authorUserId: params.userId,
	})

	const fullMessage = await loadMessageWithMeta(savedMessage.id)
	const author = await db.query.users.findFirst({
		where: eq(users.authUuid, params.userId),
		columns: {
			fullName: true,
			username: true,
			email: true,
		},
	})

	const replyTarget =
		params.replyToId == null
			? null
			: await db.query.messages.findFirst({
					where: and(
						eq(messages.id, params.replyToId),
						eq(messages.chatId, params.chatId),
						eq(messages.isDeleted, false),
					),
					columns: {
						userAuthUuid: true,
						content: true,
						messageType: true,
						attachmentName: true,
					},
				})

	const replyTargetUserId =
		replyTarget?.userAuthUuid && replyTarget.userAuthUuid !== params.userId
			? replyTarget.userAuthUuid
			: null

	const mentionTargets = mentions
		.map((mention) => mention.mentionedUserAuthUuid)
		.filter((mentionedUserId) => mentionedUserId !== params.userId)

	void sendChatMessagePushNotifications({
		chat: access.chat,
		authorUserId: params.userId,
		authorName: author?.fullName ?? author?.username ?? 'Участник',
		content: normalizedContent,
		messageType: params.messageType,
		attachmentName: params.attachmentName,
		replyPreview: replyTarget ? getReplyPreview(replyTarget) : null,
		replyTargetUserId,
		mentionTargetUserIds: mentionTargets,
		url: getChatPushUrl(access.chat, savedMessage.id),
	})
	void sendChatMessageTelegramNotifications({
		chat: access.chat,
		authorUserId: params.userId,
		authorName: author?.fullName ?? author?.username ?? 'Участник',
		content: normalizedContent,
		messageType: params.messageType,
		attachmentName: params.attachmentName,
		replyTargetUserId,
		mentionTargetUserIds: mentionTargets,
		url: getChatPushUrl(access.chat, savedMessage.id),
	})
	void sendSupportTelegramNotification({
		chat: access.chat,
		messageId: savedMessage.id,
		authorRole: params.userRole,
		authorName: author?.fullName ?? author?.username ?? 'Участница',
		authorEmail: author?.email ?? null,
		content: normalizedContent,
		messageType: params.messageType,
	})

	return {
		ok: true as const,
		duplicate: false,
		message: fullMessage ?? savedMessage,
		access,
	}
}
