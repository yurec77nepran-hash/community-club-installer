import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto'
import { env } from '../config/env'

const PREFIX = 'enc:v1:'

function getKey() {
	return createHash('sha256').update(env.JWT_SECRET).digest()
}

export function encryptSecret(value: string) {
	const normalized = value.trim()
	if (!normalized) return ''
	if (normalized.startsWith(PREFIX)) return normalized

	const iv = randomBytes(12)
	const cipher = createCipheriv('aes-256-gcm', getKey(), iv)
	const encrypted = Buffer.concat([cipher.update(normalized, 'utf8'), cipher.final()])
	const tag = cipher.getAuthTag()
	return `${PREFIX}${Buffer.concat([iv, tag, encrypted]).toString('base64url')}`
}

export function decryptSecret(value: string | null | undefined) {
	const raw = value?.trim() ?? ''
	if (!raw) return ''
	if (!raw.startsWith(PREFIX)) return raw

	try {
		const payload = Buffer.from(raw.slice(PREFIX.length), 'base64url')
		const iv = payload.subarray(0, 12)
		const tag = payload.subarray(12, 28)
		const encrypted = payload.subarray(28)
		const decipher = createDecipheriv('aes-256-gcm', getKey(), iv)
		decipher.setAuthTag(tag)
		return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8')
	} catch {
		return ''
	}
}
