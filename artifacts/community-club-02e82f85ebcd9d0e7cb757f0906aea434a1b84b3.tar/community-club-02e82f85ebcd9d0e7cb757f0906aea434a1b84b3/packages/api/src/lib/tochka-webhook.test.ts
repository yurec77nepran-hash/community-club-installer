import { describe, expect, test } from 'bun:test'
import { generateKeyPairSync, sign } from 'node:crypto'
import { verifyTochkaWebhookJwt } from './tochka-webhook'

function encode(value: Record<string, unknown>) {
	return Buffer.from(JSON.stringify(value)).toString('base64url')
}

describe('Tochka webhook JWT', () => {
	test('accepts a valid RS256 webhook and rejects a modified payload', async () => {
		const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 })
		const header = encode({ alg: 'RS256', typ: 'JWT' })
		const payload = encode({ event: 'acquiringInternetPayment', operationId: 'operation-1' })
		const signature = sign('RSA-SHA256', Buffer.from(`${header}.${payload}`), privateKey).toString(
			'base64url',
		)
		const token = `${header}.${payload}.${signature}`
		const key = publicKey.export({ format: 'jwk' })

		expect(await verifyTochkaWebhookJwt(token, key)).toEqual({
			event: 'acquiringInternetPayment',
			operationId: 'operation-1',
		})
		expect(
			await verifyTochkaWebhookJwt(
				`${header}.${encode({ operationId: 'other' })}.${signature}`,
				key,
			),
		).toBeNull()
	})
})
