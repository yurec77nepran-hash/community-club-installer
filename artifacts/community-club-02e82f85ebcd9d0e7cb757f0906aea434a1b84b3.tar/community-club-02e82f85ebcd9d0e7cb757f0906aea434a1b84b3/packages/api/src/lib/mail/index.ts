import nodemailer from 'nodemailer'
import { env } from '../../config/env'
import { logger } from '../logger'
import { type MailTemplate, renderMailTemplate } from './templates'

type SendMailParams = {
	to: string
	subject: string
	html: string
	text: string
}

let transporter: nodemailer.Transporter | null = null

function getFromAddress() {
	return env.MAIL_FROM_NAME ? `${env.MAIL_FROM_NAME} <${env.MAIL_FROM_EMAIL}>` : env.MAIL_FROM_EMAIL
}

function getTransporter() {
	if (transporter) {
		return transporter
	}

	if (!env.SMTP_HOST || !env.SMTP_USER || !env.SMTP_PASSWORD) {
		throw new Error('SMTP_HOST, SMTP_USER and SMTP_PASSWORD are required when MAIL_PROVIDER=smtp')
	}

	transporter = nodemailer.createTransport({
		host: env.SMTP_HOST,
		port: env.SMTP_PORT,
		secure: env.SMTP_SECURE,
		auth: {
			user: env.SMTP_USER,
			pass: env.SMTP_PASSWORD,
		},
		tls: env.SMTP_ALLOW_INVALID_CERTS ? { rejectUnauthorized: false } : undefined,
	})

	return transporter
}

async function sendWithSmtp(params: SendMailParams) {
	const mailer = getTransporter()
	await mailer.sendMail({
		from: getFromAddress(),
		to: params.to,
		replyTo: env.MAIL_REPLY_TO || undefined,
		subject: params.subject,
		html: params.html,
		text: params.text,
	})
}

export async function sendMail(params: SendMailParams) {
	if (env.MAIL_PROVIDER === 'smtp') {
		await sendWithSmtp(params)
		return
	}

	logger.info(
		{
			to: params.to,
			subject: params.subject,
			provider: env.MAIL_PROVIDER,
		},
		'Mail provider is in log mode; email not sent externally',
	)
}

export async function sendTemplateEmail(to: string, template: MailTemplate) {
	const rendered = renderMailTemplate(template)
	await sendMail({
		to,
		subject: rendered.subject,
		html: rendered.html,
		text: rendered.text,
	})
}
