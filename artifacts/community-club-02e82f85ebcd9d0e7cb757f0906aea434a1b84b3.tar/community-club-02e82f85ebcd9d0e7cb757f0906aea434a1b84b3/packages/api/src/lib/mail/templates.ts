export type MailTemplate =
	| {
			type: 'password-reset'
			resetUrl: string
			fullName?: string | null
	  }
	| {
			type: 'password-changed'
			fullName?: string | null
	  }
	| {
			type: 'welcome'
			fullName?: string | null
	  }

export function renderMailTemplate(template: MailTemplate) {
	switch (template.type) {
		case 'password-reset': {
			const title = 'Сброс пароля'
			const subject = 'Сброс пароля в Community Club'
			const greeting = template.fullName ? `Здравствуйте, ${template.fullName}!` : 'Здравствуйте!'
			const html = `
				<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#111827">
					<h1 style="font-size:24px;margin:0 0 16px">${title}</h1>
					<p style="margin:0 0 12px">${greeting}</p>
					<p style="margin:0 0 12px">Мы получили запрос на сброс пароля для вашего аккаунта Community Club.</p>
					<p style="margin:0 0 20px">Нажмите на кнопку ниже, чтобы задать новый пароль. Ссылка действует 1 час.</p>
					<p style="margin:0 0 24px">
						<a href="${template.resetUrl}" style="display:inline-block;background:#7c3aed;color:#ffffff;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:600">
							Сбросить пароль
						</a>
					</p>
					<p style="margin:0 0 8px;font-size:14px;color:#4b5563">Если кнопка не открывается, используйте ссылку:</p>
					<p style="margin:0 0 12px;font-size:14px;word-break:break-all">
						<a href="${template.resetUrl}" style="color:#7c3aed">${template.resetUrl}</a>
					</p>
					<p style="margin:24px 0 0;font-size:13px;color:#6b7280">Если вы не запрашивали сброс, просто проигнорируйте это письмо.</p>
				</div>
			`
			const text = `${greeting}\n\nМы получили запрос на сброс пароля для вашего аккаунта Community Club.\n\nОткройте ссылку, чтобы задать новый пароль. Ссылка действует 1 час:\n${template.resetUrl}\n\nЕсли вы не запрашивали сброс, просто проигнорируйте это письмо.`

			return { subject, html, text }
		}

		case 'password-changed': {
			const subject = 'Пароль Community Club изменён'
			const greeting = template.fullName ? `Здравствуйте, ${template.fullName}!` : 'Здравствуйте!'
			const html = `
				<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#111827">
					<h1 style="font-size:24px;margin:0 0 16px">Пароль изменён</h1>
					<p style="margin:0 0 12px">${greeting}</p>
					<p style="margin:0 0 12px">Пароль для вашего аккаунта Community Club был успешно изменён.</p>
					<p style="margin:0 0 12px">Если это были не вы, срочно свяжитесь с администратором и смените пароль ещё раз.</p>
				</div>
			`
			const text = `${greeting}\n\nПароль для вашего аккаунта Community Club был успешно изменён.\nЕсли это были не вы, срочно свяжитесь с администратором и смените пароль ещё раз.`

			return { subject, html, text }
		}

		case 'welcome': {
			const greeting = template.fullName ? `Здравствуйте, ${template.fullName}!` : 'Здравствуйте!'
			const subject = 'Добро пожаловать в Community Club'
			const html = `
				<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#111827">
					<h1 style="font-size:24px;margin:0 0 16px">Добро пожаловать</h1>
					<p style="margin:0 0 12px">${greeting}</p>
					<p style="margin:0 0 12px">Ваш аккаунт Community Club успешно создан.</p>
					<p style="margin:0 0 12px">Теперь вы можете входить в клуб, пользоваться материалами, чатами и оплатой подписки.</p>
				</div>
			`
			const text = `${greeting}\n\nВаш аккаунт Community Club успешно создан.\nТеперь вы можете входить в клуб, пользоваться материалами, чатами и оплатой подписки.`

			return { subject, html, text }
		}
	}
}
