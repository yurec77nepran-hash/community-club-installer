type ChatPushNotificationKind = 'message' | 'reply' | 'replyToYou' | 'mention'

function getMessagePreview(params: {
	content: string
	messageType: string
	attachmentName?: string | null
}) {
	const content = params.content.trim()
	if (content) return content.slice(0, 120)

	switch (params.messageType) {
		case 'image':
			return 'Фото'
		case 'video':
			return 'Видео'
		case 'voice':
			return 'Голосовое сообщение'
		case 'audio':
			return 'Аудио'
		case 'document':
			return params.attachmentName?.trim() || 'Файл'
		case 'link':
			return 'Ссылка'
		default:
			return 'Новое сообщение'
	}
}

function limitPreview(value: string, maxLength = 120) {
	const normalized = value.replace(/\s+/g, ' ').trim()
	if (normalized.length <= maxLength) return normalized
	return `${normalized.slice(0, maxLength - 1).trimEnd()}…`
}

export function buildChatPushNotificationPayload(params: {
	kind: ChatPushNotificationKind
	chatName: string
	authorName: string
	content: string
	messageType: string
	attachmentName?: string | null
	replyPreview?: string | null
	url: string
}) {
	const messagePreview = limitPreview(
		getMessagePreview({
			content: params.content,
			messageType: params.messageType,
			attachmentName: params.attachmentName,
		}),
	)
	const replyPreview = params.replyPreview ? limitPreview(params.replyPreview, 72) : ''

	const title =
		params.kind === 'replyToYou'
			? `Ответ на ваше сообщение в чате «${params.chatName}»`
			: params.kind === 'reply'
				? `Ответ в чате «${params.chatName}»`
				: params.kind === 'mention'
					? `Вас упомянули в чате «${params.chatName}»`
					: params.chatName

	return {
		title,
		body: replyPreview
			? `${params.authorName}: ответ на «${replyPreview}». ${messagePreview}`
			: `${params.authorName}: ${messagePreview}`,
		url: params.url,
	}
}
