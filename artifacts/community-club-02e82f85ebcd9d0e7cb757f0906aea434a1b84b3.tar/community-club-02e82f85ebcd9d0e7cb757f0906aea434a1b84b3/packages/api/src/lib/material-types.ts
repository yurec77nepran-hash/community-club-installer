import { MATERIAL_TYPES } from '@community-club/shared'

export const DEFAULT_MATERIAL_TYPE_ENTRIES = Object.entries(MATERIAL_TYPES).map(([key, label]) => ({
	key,
	label,
}))

const defaultTypeLabels = new Map(
	DEFAULT_MATERIAL_TYPE_ENTRIES.map((item) => [item.key, item.label]),
)

export const LEGACY_MATERIAL_TYPE_ALIASES: Record<string, string> = {
	kursy: 'courses',
	efiry: 'streams',
	'chek-listy': 'checklists',
	prochee: 'other',
}

const defaultTypeLabelAliases = new Map<string, string>([
	['курсы', 'courses'],
	['эфиры', 'streams'],
	['чек-листы', 'checklists'],
	['чек листы', 'checklists'],
	['прочее', 'other'],
])

function normalizeLabelAlias(value: string) {
	return value
		.trim()
		.toLowerCase()
		.replace(/[‐‑‒–—]/g, '-')
		.replace(/\s+/g, ' ')
}

export function normalizeMaterialTypeKey(value: string) {
	const normalized = value.trim()
	return LEGACY_MATERIAL_TYPE_ALIASES[normalized] ?? normalized
}

export function getMaterialTypeQueryKeys(value: string) {
	const canonicalKey = normalizeMaterialTypeKey(value)
	const keys = new Set([canonicalKey])
	for (const [legacyKey, mappedKey] of Object.entries(LEGACY_MATERIAL_TYPE_ALIASES)) {
		if (mappedKey === canonicalKey) {
			keys.add(legacyKey)
		}
	}
	return [...keys]
}

export function getDefaultMaterialTypeLabel(key: string) {
	return defaultTypeLabels.get(normalizeMaterialTypeKey(key)) ?? null
}

export function buildMaterialTypeKey(label: string) {
	const defaultKey = defaultTypeLabelAliases.get(normalizeLabelAlias(label))
	if (defaultKey) return defaultKey

	const baseKey =
		label
			.trim()
			.toLowerCase()
			.replace(/[а-яё]/g, (char) => {
				const map: Record<string, string> = {
					а: 'a',
					б: 'b',
					в: 'v',
					г: 'g',
					д: 'd',
					е: 'e',
					ё: 'e',
					ж: 'zh',
					з: 'z',
					и: 'i',
					й: 'y',
					к: 'k',
					л: 'l',
					м: 'm',
					н: 'n',
					о: 'o',
					п: 'p',
					р: 'r',
					с: 's',
					т: 't',
					у: 'u',
					ф: 'f',
					х: 'h',
					ц: 'ts',
					ч: 'ch',
					ш: 'sh',
					щ: 'sch',
					ъ: '',
					ы: 'y',
					ь: '',
					э: 'e',
					ю: 'yu',
					я: 'ya',
				}
				return map[char] ?? char
			})
			.replace(/[^a-z0-9]+/g, '-')
			.replace(/^-+|-+$/g, '')
			.replace(/-{2,}/g, '-') || 'material-type'

	return baseKey
}
