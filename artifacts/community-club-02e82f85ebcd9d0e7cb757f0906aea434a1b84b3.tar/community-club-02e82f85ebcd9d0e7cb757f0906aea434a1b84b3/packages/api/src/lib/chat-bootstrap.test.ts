import { describe, expect, test } from 'bun:test'
import { DEFAULT_CLUB_CHAT } from './chat-bootstrap'

describe('chat bootstrap', () => {
	test('defines the default enabled club chat seed', () => {
		expect(DEFAULT_CLUB_CHAT).toMatchObject({
			slug: 'club-chat',
			name: 'Чат клуба',
			type: 'chat',
			accessRole: 'all',
			isEnabled: true,
		})
	})
})
