import { getMoscowDateString, hasActiveDateFinish } from './subscription-access'

export const DEMO_ACCESS_DAYS = 7
export const DEMO_ACCESS_TARIFF = 'demo-7-days'

export function normalizeDemoAccessEmail(email: string) {
	return email.trim().toLowerCase()
}

export function getDemoAccessWindow(now = new Date(), days = DEMO_ACCESS_DAYS) {
	return {
		dateStart: getMoscowDateString(now),
		dateFinish: getMoscowDateString(new Date(now.getTime() + days * 24 * 60 * 60 * 1000)),
	}
}

export function isActiveDemoAccess(
	payment: { tarrif: string | null; dateFinish: string | Date | null } | null,
	today = getMoscowDateString(),
) {
	return payment?.tarrif === DEMO_ACCESS_TARIFF && hasActiveDateFinish(payment.dateFinish, today)
}

export function classifyDemoAccessPayments(
	payments: readonly {
		readonly tarrif: string | null
		readonly dateFinish: string | Date | null
	}[],
	today = getMoscowDateString(),
) {
	let hasActiveDemo = false
	for (const payment of payments) {
		if (!hasActiveDateFinish(payment.dateFinish, today)) continue
		if (payment.tarrif !== DEMO_ACCESS_TARIFF) return 'paid-active' as const
		hasActiveDemo = true
	}
	return hasActiveDemo ? ('demo-active' as const) : ('eligible' as const)
}
