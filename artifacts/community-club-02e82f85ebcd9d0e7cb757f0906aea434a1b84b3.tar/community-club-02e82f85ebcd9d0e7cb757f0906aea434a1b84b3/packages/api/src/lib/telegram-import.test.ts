import { expect, test } from 'bun:test'
import { parseTelegramImportDump } from './telegram-import'

test('parses known Telegram bot COPY blocks without merging overlaps', () => {
	const rows =
		parseTelegramImportDump(`COPY public."Gorsky_Chatbot" (id, created_at, user_id) FROM stdin;
1\t2026-01-01 10:00:00+00\t42
\\.
COPY public.proproconf_bot (id, created_at, user_id) FROM stdin;
2\t2026-01-02 10:00:00+00\t42
\\.`)
	expect(rows).toEqual([
		expect.objectContaining({ botUsername: 'gorsky_chatbot', telegramUserId: '42' }),
		expect.objectContaining({ botUsername: 'proproconf_bot', telegramUserId: '42' }),
	])
})
