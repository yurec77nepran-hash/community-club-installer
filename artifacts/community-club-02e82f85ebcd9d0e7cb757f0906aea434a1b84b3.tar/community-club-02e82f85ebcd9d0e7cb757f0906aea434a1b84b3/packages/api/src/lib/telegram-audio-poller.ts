import { env } from '../config/env'
import { processTelegramUpdate } from '../routes/telegram'
import { logger } from './logger'
import { redis } from './redis'
import { getTelegramUpdates, getTelegramWebhookInfo } from './telegram'

const TELEGRAM_AUDIO_OFFSET_KEY = 'telegram:audio:last_update_id'
const POLL_INTERVAL_MS = 5000
let pollerStarted = false
let pollInFlight = false

async function getNextOffset() {
	const raw = await redis.get(TELEGRAM_AUDIO_OFFSET_KEY)
	const parsed = Number(raw ?? '0')
	return Number.isFinite(parsed) ? parsed : 0
}

async function saveNextOffset(offset: number) {
	await redis.set(TELEGRAM_AUDIO_OFFSET_KEY, String(offset))
}

async function runTelegramAudioPollTick() {
	if (pollInFlight) return
	pollInFlight = true
	try {
		const webhookInfo = await getTelegramWebhookInfo({ botKind: 'audio' })
		const activeWebhookUrl = String(webhookInfo?.result?.url ?? '').trim()
		if (activeWebhookUrl) {
			return
		}

		const offset = await getNextOffset()
		const updates = await getTelegramUpdates({ offset, timeout: 0 }, { botKind: 'audio' })
		const items = Array.isArray(updates?.result) ? updates.result : []
		for (const item of items) {
			await processTelegramUpdate(item)
			await saveNextOffset(Number(item.update_id ?? 0) + 1)
		}
	} catch (error) {
		logger.warn({ err: error }, 'Telegram audio poll tick failed')
	} finally {
		pollInFlight = false
	}
}

export function startTelegramAudioPoller() {
	if (!env.TELEGRAM_AUDIO_BOT_TOKEN) return
	if (pollerStarted) return
	pollerStarted = true
	void runTelegramAudioPollTick()
	setInterval(() => {
		void runTelegramAudioPollTick()
	}, POLL_INTERVAL_MS)
	logger.info({ intervalMs: POLL_INTERVAL_MS }, 'Telegram audio poller started')
}
