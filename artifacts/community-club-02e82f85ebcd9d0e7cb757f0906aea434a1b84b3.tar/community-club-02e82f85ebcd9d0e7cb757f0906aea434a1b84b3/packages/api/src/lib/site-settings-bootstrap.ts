import { queryClient } from '../db/client'
import { LEGACY_MATERIAL_TYPE_ALIASES } from './material-types'

function sqlText(value: string) {
	return `'${value.replace(/'/g, "''")}'`
}

const siteSettingsBootstrapQueries = [
	`CREATE TABLE IF NOT EXISTS site_settings (
		key text PRIMARY KEY,
		value text NOT NULL DEFAULT '',
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	"ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS value text NOT NULL DEFAULT ''",
	'ALTER TABLE site_settings ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now()',
	'CREATE INDEX IF NOT EXISTS site_settings_updated_idx ON site_settings (updated_at DESC)',
	...Object.entries(LEGACY_MATERIAL_TYPE_ALIASES).map(
		([legacyKey, canonicalKey]) =>
			`UPDATE site_settings
			 SET value = replace(value, ${sqlText(`/app/content/${legacyKey}`)}, ${sqlText(`/app/content/${canonicalKey}`)}),
				 updated_at = now()
			 WHERE key = 'home_experience'
			   AND value LIKE ${sqlText(`%/app/content/${legacyKey}%`)}`,
	),
]

export async function ensureSiteSettingsArtifacts() {
	for (const query of siteSettingsBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
