import { deleteCookie, setCookie } from 'hono/cookie'
import { SignJWT } from 'jose'
import { nanoid } from 'nanoid'
import { env } from '../config/env'
import { redis } from './redis'
import {
	AUTH_COOKIE_MAX_AGE_SECONDS,
	SESSION_MAX_AGE_SECONDS,
	storeRefreshSession,
} from './refresh-sessions'

const jwtSecret = new TextEncoder().encode(env.JWT_SECRET)

function isSecureRequest(c: Parameters<typeof setCookie>[0]) {
	const forwardedProto = c.req.header('x-forwarded-proto')?.split(',')[0]?.trim().toLowerCase()
	if (forwardedProto === 'https') return true
	try {
		return new URL(c.req.url).protocol === 'https:'
	} catch {
		return env.APP_URL.startsWith('https://')
	}
}

export function setAuthCookies(
	c: Parameters<typeof setCookie>[0],
	params: { accessToken: string; refreshToken: string },
) {
	const secure = isSecureRequest(c)
	const csrfToken = nanoid(40)
	setCookie(c, 'access_token', params.accessToken, {
		httpOnly: true,
		secure,
		sameSite: 'Lax',
		path: '/',
		maxAge: AUTH_COOKIE_MAX_AGE_SECONDS,
	})
	setCookie(c, 'refresh_token', params.refreshToken, {
		httpOnly: true,
		secure,
		sameSite: 'Lax',
		path: '/',
		maxAge: AUTH_COOKIE_MAX_AGE_SECONDS,
	})
	setCookie(c, 'csrf_token', csrfToken, {
		httpOnly: false,
		secure,
		sameSite: 'Lax',
		path: '/',
		maxAge: AUTH_COOKIE_MAX_AGE_SECONDS,
	})
}

export function clearAuthCookies(c: Parameters<typeof deleteCookie>[0]) {
	deleteCookie(c, 'access_token', { path: '/' })
	deleteCookie(c, 'refresh_token', { path: '/' })
	deleteCookie(c, 'csrf_token', { path: '/' })
}

export function publicSessionData(tokens: { expiresAt: number }) {
	return { expiresAt: tokens.expiresAt }
}

export async function generateTokens(userId: string, email: string, role: string) {
	const now = Math.floor(Date.now() / 1000)

	const accessToken = await new SignJWT({ sub: userId, email, role })
		.setProtectedHeader({ alg: 'HS256' })
		.setIssuedAt(now)
		.setExpirationTime(now + SESSION_MAX_AGE_SECONDS)
		.sign(jwtSecret)

	const refreshToken = await new SignJWT({ sub: userId, type: 'refresh' })
		.setProtectedHeader({ alg: 'HS256' })
		.setIssuedAt(now)
		.setExpirationTime(now + SESSION_MAX_AGE_SECONDS)
		.sign(jwtSecret)

	await storeRefreshSession(redis, userId, refreshToken)

	return {
		accessToken,
		refreshToken,
		expiresAt: now + SESSION_MAX_AGE_SECONDS,
	}
}
