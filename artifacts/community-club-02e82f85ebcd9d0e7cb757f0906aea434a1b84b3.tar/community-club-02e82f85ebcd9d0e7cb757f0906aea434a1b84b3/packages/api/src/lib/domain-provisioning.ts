import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import type { DomainProvisionResult } from '@community-club/shared/types'
import { env } from '../config/env'
import { checkCustomDomainStatus, normalizeCustomDomain } from './site-settings'

type CommandResult = {
	ok: boolean
	command: string
	exitCode: number | null
	output: string
}

export function buildManagedCaddyDomainConfig(domain: string) {
	const normalizedDomain = normalizeCustomDomain(domain)
	if (!normalizedDomain) {
		throw new Error('Некорректный домен')
	}

	const webPort = env.DOMAIN_PROVISION_WEB_PORT
	const apiPort = env.DOMAIN_PROVISION_API_PORT
	const adminPort = env.DOMAIN_PROVISION_ADMIN_PORT
	const mediaPort = env.DOMAIN_PROVISION_MEDIA_PORT

	return `# Managed by Community Club admin. Do not edit manually.
${normalizedDomain} {
	encode zstd gzip

	request_body {
		max_size 3GB
	}

	handle /api/* {
		reverse_proxy 127.0.0.1:${apiPort} {
			header_up X-Real-IP {remote_host}
			header_up X-Forwarded-For {remote_host}
			header_up X-Forwarded-Proto {scheme}
		}
	}

	handle /health {
		reverse_proxy 127.0.0.1:${apiPort}
	}

	handle /admin* {
		reverse_proxy 127.0.0.1:${adminPort}
	}

	handle /media/* {
		uri strip_prefix /media
		reverse_proxy 127.0.0.1:${mediaPort} {
			header_up Host media
			flush_interval -1
		}
	}

	handle /avatars/* {
		uri strip_prefix /avatars
		reverse_proxy 127.0.0.1:${mediaPort} {
			header_up Host avatars
			flush_interval -1
		}
	}

	handle /chat-media/* {
		uri strip_prefix /chat-media
		reverse_proxy 127.0.0.1:${mediaPort} {
			header_up Host chat-attachments
			flush_interval -1
		}
	}

	handle {
		reverse_proxy 127.0.0.1:${webPort}
	}
}
`
}

function parseCommandLine(command: string): string[] {
	const trimmed = command.trim()
	if (!trimmed) return []

	const parts: string[] = []
	let current = ''
	let quote: '"' | "'" | null = null

	for (const char of trimmed) {
		if ((char === '"' || char === "'") && quote === null) {
			quote = char
			continue
		}
		if (char === quote) {
			quote = null
			continue
		}
		if (/\s/.test(char) && quote === null) {
			if (current) {
				parts.push(current)
				current = ''
			}
			continue
		}
		current += char
	}

	if (current) parts.push(current)
	return parts
}

async function runCommand(command: string): Promise<CommandResult> {
	const args = parseCommandLine(command)
	if (args.length === 0) {
		return { ok: true, command, exitCode: 0, output: '' }
	}

	const proc = Bun.spawn(args, {
		stdout: 'pipe',
		stderr: 'pipe',
		env: Bun.env,
	})
	const [stdout, stderr, exitCode] = await Promise.all([
		new Response(proc.stdout).text(),
		new Response(proc.stderr).text(),
		proc.exited,
	])
	const output = [stdout, stderr].filter(Boolean).join('\n').trim()

	return {
		ok: exitCode === 0,
		command: args.join(' '),
		exitCode,
		output: output.slice(0, 4000),
	}
}

async function readExistingManagedConfig(configPath: string) {
	try {
		return await readFile(configPath, 'utf8')
	} catch {
		return null
	}
}

async function restoreManagedConfig(configPath: string, previousContent: string | null) {
	if (previousContent == null) {
		await rm(configPath, { force: true })
		return
	}
	await writeFile(configPath, previousContent, { mode: 0o644 })
}

async function writeManagedConfig(domain: string) {
	const configPath = env.DOMAIN_PROVISION_CONFIG_PATH
	const tempPath = `${configPath}.tmp-${process.pid}-${Date.now()}`
	const content = buildManagedCaddyDomainConfig(domain)
	const previousContent = await readExistingManagedConfig(configPath)

	await mkdir(dirname(configPath), { recursive: true })
	await writeFile(tempPath, content, { mode: 0o644 })
	await rename(tempPath, configPath)

	return { configPath, previousContent }
}

async function provisionThroughHelper(domain: string, content: string) {
	try {
		const response = await fetch(env.DOMAIN_PROVISION_HELPER_URL, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				Authorization: `Bearer ${env.DOMAIN_PROVISION_HELPER_TOKEN}`,
			},
			body: JSON.stringify({ domain, content }),
		})
		const text = await response.text()
		const data = text
			? (JSON.parse(text) as {
					ok: boolean
					error?: string
					validate?: CommandResult
					reload?: CommandResult
				})
			: { ok: false, error: 'empty_helper_response' }

		return {
			ok: response.ok && data.ok,
			error: data.error,
			validate: data.validate ?? null,
			reload: data.reload ?? null,
		}
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error ? error.message : 'Caddy helper недоступен',
			validate: null,
			reload: null,
		}
	}
}

type FetchResponse = (input: string | URL | Request, init?: RequestInit) => Promise<Response>

export async function smokeCheckHttps(domain: string, fetchResponse: FetchResponse = fetch) {
	const controller = new AbortController()
	const timeout = setTimeout(() => controller.abort(), env.DOMAIN_PROVISION_SMOKE_TIMEOUT_MS)
	const origin = `https://${domain}`

	try {
		const healthResponse = await fetchResponse(`${origin}/health`, {
			signal: controller.signal,
			headers: { accept: 'application/json' },
		})
		if (!healthResponse.ok) {
			return {
				ok: false,
				status: healthResponse.status,
				message: `/health вернул статус ${healthResponse.status}`,
			}
		}
		const health = (await healthResponse.json().catch(() => null)) as { status?: unknown } | null
		if (health?.status !== 'ok') {
			return {
				ok: false,
				status: healthResponse.status,
				message: '/health вернул некорректный ответ',
			}
		}

		const pageResponse = await fetchResponse(`${origin}/`, { signal: controller.signal })
		const page = await pageResponse.text()
		const assetPath = page.match(/["']([^"']*\/_nuxt\/[^"']+\.js(?:\?[^"']*)?)["']/)?.[1]
		if (!pageResponse.ok || !assetPath) {
			return {
				ok: false,
				status: pageResponse.status,
				message: 'Главная страница не содержит Nuxt JavaScript',
			}
		}

		const assetResponse = await fetchResponse(new URL(assetPath, origin), {
			signal: controller.signal,
		})
		const asset = await assetResponse.arrayBuffer()
		const assetType = assetResponse.headers.get('content-type')?.toLowerCase() ?? ''
		if (!assetResponse.ok || asset.byteLength === 0 || !assetType.includes('javascript')) {
			return {
				ok: false,
				status: assetResponse.status,
				message: 'Nuxt JavaScript не загрузился корректно',
			}
		}

		const manifestResponse = await fetchResponse(`${origin}/pwa-manifest`, {
			signal: controller.signal,
			headers: { accept: 'application/manifest+json' },
		})
		const manifestType = manifestResponse.headers.get('content-type')?.toLowerCase() ?? ''
		const manifest = (await manifestResponse.json().catch(() => null)) as {
			name?: unknown
			start_url?: unknown
		} | null
		if (
			!manifestResponse.ok ||
			!manifestType.includes('application/manifest+json') ||
			typeof manifest?.name !== 'string' ||
			typeof manifest.start_url !== 'string'
		) {
			return {
				ok: false,
				status: manifestResponse.status,
				message: 'PWA manifest не загрузился корректно',
			}
		}

		return { ok: true, status: healthResponse.status, message: 'HTTPS отвечает' }
	} catch (error) {
		return {
			ok: false,
			status: null,
			message: error instanceof Error ? error.message : 'HTTPS недоступен',
		}
	} finally {
		clearTimeout(timeout)
	}
}

export async function provisionCustomDomain(
	domain: string | null | undefined,
): Promise<DomainProvisionResult> {
	const normalizedDomain = normalizeCustomDomain(domain)
	const checkedAt = new Date().toISOString()

	if (!normalizedDomain) {
		return {
			status: 'error',
			domain: null,
			checkedAt,
			message: 'Укажите корректный домен',
			dns: await checkCustomDomainStatus(domain),
			https: { ok: false, status: null, message: 'Домен не указан' },
		}
	}

	const dns = await checkCustomDomainStatus(normalizedDomain)
	if (dns.status !== 'connected') {
		return {
			status: 'pending',
			domain: normalizedDomain,
			checkedAt,
			message: 'DNS ещё не указывает на этот сервер',
			dns,
			https: { ok: false, status: null, message: 'HTTPS проверяется после DNS' },
		}
	}

	if (!env.DOMAIN_PROVISION_ENABLED) {
		return {
			status: 'disabled',
			domain: normalizedDomain,
			checkedAt,
			message: 'Автоподключение домена не включено на сервере',
			dns,
			https: { ok: false, status: null, message: 'Сервер не разрешает менять Caddy из админки' },
		}
	}

	if (env.DOMAIN_PROVISION_HELPER_URL && env.DOMAIN_PROVISION_HELPER_TOKEN) {
		const content = buildManagedCaddyDomainConfig(normalizedDomain)
		const helper = await provisionThroughHelper(normalizedDomain, content)
		if (!helper.ok) {
			return {
				status: 'error',
				domain: normalizedDomain,
				checkedAt,
				message:
					helper.validate?.ok === false
						? 'Caddy не принял конфигурацию'
						: 'Caddy не перезагрузился',
				dns,
				caddy: {
					...(helper.validate ? { validate: helper.validate } : {}),
					...(helper.reload ? { reload: helper.reload } : {}),
				},
				https: {
					ok: false,
					status: null,
					message:
						helper.error ??
						helper.reload?.output ??
						helper.validate?.output ??
						'Ошибка Caddy helper',
				},
			}
		}

		const https = await smokeCheckHttps(normalizedDomain)
		return {
			status: https.ok ? 'connected' : 'error',
			domain: normalizedDomain,
			checkedAt,
			message: https.ok
				? 'Домен подключён, HTTPS отвечает'
				: 'Caddy обновлён, но HTTPS ещё не отвечает',
			dns,
			caddy: {
				...(helper.validate ? { validate: helper.validate } : {}),
				...(helper.reload ? { reload: helper.reload } : {}),
			},
			https,
		}
	}

	let writtenConfig: { configPath: string; previousContent: string | null }
	try {
		writtenConfig = await writeManagedConfig(normalizedDomain)
	} catch (error) {
		return {
			status: 'error',
			domain: normalizedDomain,
			checkedAt,
			message: 'Не удалось записать конфигурацию Caddy',
			dns,
			https: {
				ok: false,
				status: null,
				message: error instanceof Error ? error.message : 'Ошибка записи',
			},
		}
	}

	const validation = await runCommand(env.DOMAIN_PROVISION_VALIDATE_COMMAND)
	if (!validation.ok) {
		await restoreManagedConfig(writtenConfig.configPath, writtenConfig.previousContent)
		return {
			status: 'error',
			domain: normalizedDomain,
			checkedAt,
			message: 'Caddy не принял конфигурацию',
			dns,
			caddy: {
				validate: validation,
			},
			https: { ok: false, status: null, message: validation.output || 'Ошибка проверки Caddy' },
		}
	}

	const reload = await runCommand(env.DOMAIN_PROVISION_RELOAD_COMMAND)
	if (!reload.ok) {
		return {
			status: 'error',
			domain: normalizedDomain,
			checkedAt,
			message: 'Caddy не перезагрузился',
			dns,
			caddy: {
				validate: validation,
				reload,
			},
			https: { ok: false, status: null, message: reload.output || 'Ошибка перезагрузки Caddy' },
		}
	}

	const https = await smokeCheckHttps(normalizedDomain)

	return {
		status: https.ok ? 'connected' : 'error',
		domain: normalizedDomain,
		checkedAt,
		message: https.ok
			? 'Домен подключён, HTTPS отвечает'
			: 'Caddy обновлён, но HTTPS ещё не отвечает',
		dns,
		caddy: {
			validate: validation,
			reload,
		},
		https,
	}
}
