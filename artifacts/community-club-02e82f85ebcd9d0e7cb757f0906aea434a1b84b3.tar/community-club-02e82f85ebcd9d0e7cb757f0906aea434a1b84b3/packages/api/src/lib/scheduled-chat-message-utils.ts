export function resolveScheduledMessageDate(
	value: string,
	options?: {
		now?: Date
	},
) {
	const date = new Date(value)
	if (Number.isNaN(date.getTime())) {
		return { ok: false as const, message: 'Некорректная дата отправки' }
	}

	const now = options?.now ?? new Date()
	if (date.getTime() <= now.getTime()) {
		return { ok: false as const, message: 'Дата отправки уже прошла' }
	}

	return { ok: true as const, value: date }
}
