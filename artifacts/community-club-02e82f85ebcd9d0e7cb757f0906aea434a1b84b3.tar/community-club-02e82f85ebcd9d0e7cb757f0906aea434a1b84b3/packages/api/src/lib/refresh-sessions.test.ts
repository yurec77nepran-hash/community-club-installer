import { describe, expect, test } from 'bun:test'
import {
	AUTH_COOKIE_MAX_AGE_SECONDS,
	SESSION_MAX_AGE_SECONDS,
	claimRefreshSessionRotation,
	getRefreshSessionKey,
	parseRotatedRefreshSession,
	resolveRefreshTokenSource,
	serializeRotatedRefreshSession,
	storeRefreshSession,
	waitForRefreshRotationResult,
} from './refresh-sessions'

describe('refresh session rotation helpers', () => {
	test('keeps browser cookie lifetime inside RFC 6265bis while server session stays long', () => {
		expect(AUTH_COOKIE_MAX_AGE_SECONDS).toBeLessThan(400 * 24 * 60 * 60)
		expect(SESSION_MAX_AGE_SECONDS).toBeGreaterThan(AUTH_COOKIE_MAX_AGE_SECONDS)
	})

	test('uses stable Redis keys and stores active sessions without token bodies', async () => {
		const calls: unknown[][] = []
		const client = {
			async get() {
				return null
			},
			async eval() {
				return ['missing']
			},
			async set(...args: Array<string | number>) {
				calls.push(args)
				return 'OK'
			},
		}

		await storeRefreshSession(client, 'user-1', 'refresh-token-abcdef1234567890')

		expect(getRefreshSessionKey('user-1', 'refresh-token-abcdef1234567890')).toBe(
			'refresh:user-1:abcdef1234567890',
		)
		expect(calls[0]?.[1]).toBe('active')
	})

	test('claims active refresh token rotation atomically through Redis script', async () => {
		const evalCalls: unknown[][] = []
		const client = {
			async get() {
				return null
			},
			async set() {
				return 'OK'
			},
			async eval(...args: Array<string | number>) {
				evalCalls.push(args)
				return ['claimed']
			},
		}

		const result = await claimRefreshSessionRotation(client, 'refresh:user:old', 'claim-1')

		expect(result).toEqual({ status: 'claimed' })
		expect(evalCalls[0]).toContain('pending:')
		expect(evalCalls[0]).toContain('active')
		expect(evalCalls[0]).toContain('1')
	})

	test('returns rotated tokens for a concurrent refresh request', async () => {
		const tokens = {
			accessToken: 'access',
			refreshToken: 'refresh',
			expiresAt: 123,
		}
		const client = {
			async get() {
				return serializeRotatedRefreshSession(tokens)
			},
			async set() {
				return 'OK'
			},
			async eval() {
				return ['rotated', serializeRotatedRefreshSession(tokens)]
			},
		}

		expect(parseRotatedRefreshSession(serializeRotatedRefreshSession(tokens))).toEqual(tokens)
		expect(await claimRefreshSessionRotation(client, 'refresh:user:old')).toEqual({
			status: 'rotated',
			tokens,
		})
		expect(await waitForRefreshRotationResult(client, 'refresh:user:old', 10)).toEqual(tokens)
	})

	test('prefers httpOnly cookie refresh token over stale body token', () => {
		expect(
			resolveRefreshTokenSource({
				cookieToken: 'fresh-cookie-token',
				bodyToken: 'stale-local-storage-token',
			}),
		).toBe('fresh-cookie-token')
		expect(resolveRefreshTokenSource({ cookieToken: null, bodyToken: 'legacy-body-token' })).toBe(
			'legacy-body-token',
		)
	})
})
