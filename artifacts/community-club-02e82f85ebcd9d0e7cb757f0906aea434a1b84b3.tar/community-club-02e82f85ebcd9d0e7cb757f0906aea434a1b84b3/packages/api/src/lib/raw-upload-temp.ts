import { randomUUID } from 'node:crypto'
import { createWriteStream } from 'node:fs'
import { mkdir, unlink } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Readable, Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'

export class UploadBodyTooLargeError extends Error {
	constructor(
		readonly bytesRead: number,
		readonly maxBytes: number,
	) {
		super('Upload body exceeds limit')
		this.name = 'UploadBodyTooLargeError'
	}
}

export type TempUploadFile = {
	path: string
	size: number
}

function getChunkSize(chunk: unknown) {
	if (typeof chunk === 'string') return Buffer.byteLength(chunk)
	if (chunk instanceof Uint8Array) return chunk.byteLength
	return 0
}

export async function writeUploadBodyToTempFile(params: {
	body: ReadableStream<Uint8Array>
	maxBytes: number
}): Promise<TempUploadFile> {
	const uploadDir = join(tmpdir(), 'community-club-uploads')
	await mkdir(uploadDir, { recursive: true })

	const tempPath = join(uploadDir, `${Date.now()}-${randomUUID()}.upload`)
	let bytesRead = 0

	const limitStream = new Transform({
		transform(chunk, _encoding, callback) {
			bytesRead += getChunkSize(chunk)
			if (bytesRead > params.maxBytes) {
				callback(new UploadBodyTooLargeError(bytesRead, params.maxBytes))
				return
			}
			callback(null, chunk)
		},
	})

	try {
		await pipeline(
			Readable.fromWeb(params.body as Parameters<typeof Readable.fromWeb>[0]),
			limitStream,
			createWriteStream(tempPath),
		)
		return { path: tempPath, size: bytesRead }
	} catch (error) {
		await unlink(tempPath).catch(() => undefined)
		throw error
	}
}
