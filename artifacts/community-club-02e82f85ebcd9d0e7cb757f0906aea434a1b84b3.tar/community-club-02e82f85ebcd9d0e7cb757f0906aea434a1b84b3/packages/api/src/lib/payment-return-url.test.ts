import { describe, expect, test } from 'bun:test'
import { buildInternalReturnUrl, isSafeInternalReturnPath } from './payment-return-url'

describe('payment return urls', () => {
	test('allows only same-origin internal return paths', () => {
		expect(isSafeInternalReturnPath('/app/payment')).toBe(true)
		expect(isSafeInternalReturnPath('/app/payment?checkout=success')).toBe(true)
		expect(isSafeInternalReturnPath('https://evil.example/app')).toBe(false)
		expect(isSafeInternalReturnPath('//evil.example/app')).toBe(false)
		expect(isSafeInternalReturnPath('/%2fevil.example/app')).toBe(false)
		expect(isSafeInternalReturnPath('/\\evil.example\\app')).toBe(false)
		expect(isSafeInternalReturnPath('app/payment')).toBe(false)
	})

	test('falls back when return path is unsafe', () => {
		const url = buildInternalReturnUrl('//evil.example/app', '/app/payment', 'https://club.example')

		expect(url.toString()).toBe('https://club.example/app/payment')
	})
})
