import { queryClient } from '../db/client'

const matrixColumns = `
	role,
	demo_first_month_price,
	demo_days,
	active_month_price,
	former_month_price,
	external_first_month_price,
	external_month_price,
	active_90_days_price,
	former_90_days_price,
	external_90_days_price,
	active_365_days_price,
	former_365_days_price,
	external_365_days_price,
	foreign_demo_first_month_price,
	foreign_active_month_price,
	foreign_former_month_price,
	foreign_external_first_month_price,
	foreign_external_month_price,
	foreign_active_90_days_price,
	foreign_former_90_days_price,
	foreign_external_90_days_price,
	foreign_active_365_days_price,
	foreign_former_365_days_price,
	foreign_external_365_days_price
`

const pricingMatrixBootstrapQueries = [
	`CREATE TABLE IF NOT EXISTS pricing_matrix (
		role text PRIMARY KEY,
		demo_first_month_price numeric NOT NULL,
		demo_days integer NOT NULL DEFAULT 0,
		active_month_price numeric NOT NULL,
		former_month_price numeric NOT NULL,
		external_first_month_price numeric NOT NULL,
		external_month_price numeric NOT NULL,
		active_90_days_price numeric NOT NULL,
		former_90_days_price numeric NOT NULL,
		external_90_days_price numeric NOT NULL,
		active_365_days_price numeric NOT NULL,
		former_365_days_price numeric NOT NULL,
		external_365_days_price numeric NOT NULL,
		foreign_demo_first_month_price numeric NOT NULL,
		foreign_active_month_price numeric NOT NULL,
		foreign_former_month_price numeric NOT NULL,
		foreign_external_first_month_price numeric NOT NULL,
		foreign_external_month_price numeric NOT NULL,
		foreign_active_90_days_price numeric NOT NULL,
		foreign_former_90_days_price numeric NOT NULL,
		foreign_external_90_days_price numeric NOT NULL,
		foreign_active_365_days_price numeric NOT NULL,
		foreign_former_365_days_price numeric NOT NULL,
		foreign_external_365_days_price numeric NOT NULL,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	`INSERT INTO pricing_matrix (${matrixColumns})
	SELECT
		'club',
		demo_first_month_price,
		0,
		active_month_price,
		former_month_price,
		external_first_month_price,
		external_month_price,
		active_90_days_price,
		former_90_days_price,
		external_90_days_price,
		active_365_days_price,
		former_365_days_price,
		external_365_days_price,
		foreign_demo_first_month_price,
		foreign_active_month_price,
		foreign_former_month_price,
		foreign_external_first_month_price,
		foreign_external_month_price,
		foreign_active_90_days_price,
		foreign_former_90_days_price,
		foreign_external_90_days_price,
		foreign_active_365_days_price,
		foreign_former_365_days_price,
		foreign_external_365_days_price
	FROM pricing_matrix
	WHERE role IS NOT NULL
	ORDER BY CASE role WHEN 'club' THEN 0 ELSE 1 END
	LIMIT 1
	ON CONFLICT (role) DO NOTHING`,
	`INSERT INTO pricing_matrix (${matrixColumns})
	SELECT
		'club',
		3990,
		0,
		3990,
		3990,
		3990,
		3990,
		7990,
		7990,
		7990,
		13990,
		13990,
		13990,
		3990,
		3990,
		3990,
		3990,
		3990,
		7990,
		7990,
		7990,
		13990,
		13990,
		13990
	WHERE NOT EXISTS (SELECT 1 FROM pricing_matrix WHERE role = 'club')`,
	`DELETE FROM pricing_matrix WHERE role <> 'club'`,
]

export async function ensurePricingMatrixArtifacts() {
	for (const query of pricingMatrixBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
