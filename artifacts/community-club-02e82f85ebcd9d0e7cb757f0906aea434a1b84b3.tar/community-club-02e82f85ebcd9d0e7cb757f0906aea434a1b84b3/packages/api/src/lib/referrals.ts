import { bonusTransactions, referrals, users } from '@community-club/shared'
import type {
	AdminReferralProgramAnalyticsResponse,
	ReferralProgramMyResponse,
} from '@community-club/shared/types'
import { and, eq, gte, inArray, lte, sql } from 'drizzle-orm'
import { db } from '../db/client'
import { getAppBaseUrl, loadReferralProgramSettings } from './site-settings'

const PAID_REFERRAL_STATUSES = new Set(['paid', 'bonus_credited'])

export function buildReferralCode(authUuid: string) {
	return authUuid.replace(/-/g, '').slice(0, 10)
}

function normalizeReferralCode(code: string) {
	return code
		.trim()
		.replace(/^\/?(?:r|ref)\//, '')
		.replace(/-/g, '')
		.toLowerCase()
}

async function resolveReferrerUuid(code: string) {
	const normalized = normalizeReferralCode(code)
	if (!/^[a-f0-9]{10,32}$/.test(normalized)) return null

	const rows = await db
		.select({ authUuid: users.authUuid })
		.from(users)
		.where(sql`replace(${users.authUuid}::text, '-', '') LIKE ${`${normalized}%`}`)
		.limit(2)

	return rows.length === 1 ? rows[0].authUuid : null
}

export async function applyReferralCode(params: {
	code: string | null | undefined
	userAuthUuid: string
}) {
	const settings = await loadReferralProgramSettings()
	if (!settings.enabled || !params.code) return

	const referrerUuid = await resolveReferrerUuid(params.code)
	if (!referrerUuid || referrerUuid === params.userAuthUuid) return

	const existing = await db.query.referrals.findFirst({
		where: eq(referrals.referredUuid, params.userAuthUuid),
	})
	if (existing) return

	await db.insert(referrals).values({
		referrerUuid,
		referredUuid: params.userAuthUuid,
		status: 'pending',
	})
}

export async function markReferralPaid(params: {
	userAuthUuid: string
	amount: string | number | null | undefined
	paymentLogId: number | null
}) {
	const amount = Math.round(Number(params.amount ?? 0) * 0.1)
	if (!Number.isFinite(amount) || amount <= 0 || !params.paymentLogId) return

	await db.transaction(async (tx) => {
		const referral = await tx.query.referrals.findFirst({
			where: eq(referrals.referredUuid, params.userAuthUuid),
		})
		if (!referral) return

		const source = `referral:${params.paymentLogId}`
		const alreadyCredited = await tx.query.bonusTransactions.findFirst({
			where: eq(bonusTransactions.source, source),
		})
		if (alreadyCredited) return

		await tx.insert(bonusTransactions).values({
			userAuthUuid: referral.referrerUuid,
			amount,
			source,
			description: '10% от оплаты приглашённого участника',
		})
		await tx
			.update(users)
			.set({ bonusBalance: sql`${users.bonusBalance} + ${amount}`, updatedAt: new Date() })
			.where(eq(users.authUuid, referral.referrerUuid))
		await tx
			.update(referrals)
			.set({
				status: 'bonus_credited',
				bonusAmount: sql`coalesce(${referrals.bonusAmount}, 0) + ${amount}`,
			})
			.where(eq(referrals.id, referral.id))
	})
}

export async function loadMyReferralProgram(
	userAuthUuid: string,
): Promise<ReferralProgramMyResponse> {
	const [settings, appBaseUrl] = await Promise.all([loadReferralProgramSettings(), getAppBaseUrl()])
	const items = await db.select().from(referrals).where(eq(referrals.referrerUuid, userAuthUuid))
	const referredUuids = items.map((item) => item.referredUuid)
	const referredUsers =
		referredUuids.length > 0
			? await db
					.select({
						authUuid: users.authUuid,
						fullName: users.fullName,
						email: users.email,
					})
					.from(users)
					.where(inArray(users.authUuid, referredUuids))
			: []
	const referredByUuid = new Map(referredUsers.map((user) => [user.authUuid, user]))

	return {
		enabled: settings.enabled,
		description: settings.description,
		referralCode: buildReferralCode(userAuthUuid),
		referralLink: `${appBaseUrl.replace(/\/$/, '')}/${buildReferralCode(userAuthUuid)}`,
		totalReferred: items.length,
		totalPaid: items.filter((item) => PAID_REFERRAL_STATUSES.has(item.status)).length,
		totalBonus: items.reduce((sum, item) => sum + Number(item.bonusAmount ?? 0), 0),
		referrals: items.map((item) => ({
			id: item.id,
			status: item.status,
			createdAt: item.createdAt,
			referred: referredByUuid.get(item.referredUuid) ?? null,
		})),
	}
}

export async function loadReferralAnalytics(params: {
	from: Date
	to: Date
}): Promise<AdminReferralProgramAnalyticsResponse> {
	const items = await db
		.select()
		.from(referrals)
		.where(and(gte(referrals.createdAt, params.from), lte(referrals.createdAt, params.to)))

	const referrerUuids = Array.from(new Set(items.map((item) => item.referrerUuid)))
	const referrers =
		referrerUuids.length > 0
			? await db
					.select({
						authUuid: users.authUuid,
						fullName: users.fullName,
						email: users.email,
					})
					.from(users)
					.where(inArray(users.authUuid, referrerUuids))
			: []
	const referrerByUuid = new Map(referrers.map((user) => [user.authUuid, user]))
	const daily = new Map<string, { day: string; referrals: number; paid: number }>()
	const byReferrer = new Map<
		string,
		{ authUuid: string; referrals: number; paid: number; totalBonus: number; lastReferralAt: Date }
	>()

	for (const item of items) {
		const day = item.createdAt.toISOString().slice(0, 10)
		const dayBucket = daily.get(day) ?? { day, referrals: 0, paid: 0 }
		dayBucket.referrals += 1
		if (PAID_REFERRAL_STATUSES.has(item.status)) dayBucket.paid += 1
		daily.set(day, dayBucket)

		const bucket = byReferrer.get(item.referrerUuid) ?? {
			authUuid: item.referrerUuid,
			referrals: 0,
			paid: 0,
			totalBonus: 0,
			lastReferralAt: item.createdAt,
		}
		bucket.referrals += 1
		if (PAID_REFERRAL_STATUSES.has(item.status)) bucket.paid += 1
		bucket.totalBonus += Number(item.bonusAmount ?? 0)
		if (item.createdAt > bucket.lastReferralAt) bucket.lastReferralAt = item.createdAt
		byReferrer.set(item.referrerUuid, bucket)
	}

	const paid = items.filter((item) => PAID_REFERRAL_STATUSES.has(item.status)).length

	return {
		totals: {
			referrals: items.length,
			paid,
			pending: items.length - paid,
			referrers: referrerUuids.length,
			totalBonus: items.reduce((sum, item) => sum + Number(item.bonusAmount ?? 0), 0),
		},
		daily: Array.from(daily.values()).sort((a, b) => a.day.localeCompare(b.day)),
		topReferrers: Array.from(byReferrer.values())
			.sort((a, b) => b.referrals - a.referrals || b.paid - a.paid)
			.slice(0, 20)
			.map((item) => {
				const user = referrerByUuid.get(item.authUuid)
				return {
					...item,
					fullName: user?.fullName ?? null,
					email: user?.email ?? null,
				}
			}),
	}
}

export async function loadReferralDetails(referrerUuid: string) {
	const [referrer, items] = await Promise.all([
		db.query.users.findFirst({ where: eq(users.authUuid, referrerUuid) }),
		db.select().from(referrals).where(eq(referrals.referrerUuid, referrerUuid)),
	])
	const referredUuids = items.map((item) => item.referredUuid)
	const referredUsers = referredUuids.length
		? await db
				.select({ authUuid: users.authUuid, fullName: users.fullName, email: users.email })
				.from(users)
				.where(inArray(users.authUuid, referredUuids))
		: []
	const byUuid = new Map(referredUsers.map((user) => [user.authUuid, user]))
	const paid = items.filter((item) => PAID_REFERRAL_STATUSES.has(item.status)).length

	return {
		referrer: referrer
			? { authUuid: referrer.authUuid, fullName: referrer.fullName, email: referrer.email }
			: null,
		totalReferred: items.length,
		totalPaid: paid,
		totalBonus: items.reduce((sum, item) => sum + Number(item.bonusAmount ?? 0), 0),
		referrals: items.map((item) => ({
			id: item.id,
			status: item.status,
			createdAt: item.createdAt,
			referred: byUuid.get(item.referredUuid) ?? null,
		})),
	}
}
