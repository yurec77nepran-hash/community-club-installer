export type MediaUploadRoute = 'multipart' | 'raw' | 'chunked'
export type MediaUploadBucketParam = 'media' | 'avatars' | 'chat'

function isAdminRole(role: string | null | undefined) {
	return role === 'admin' || role === 'superadmin'
}

export function normalizeMediaUploadBucketParam(
	bucketParam: string | null | undefined,
): { ok: true; bucketParam: MediaUploadBucketParam } | { ok: false } {
	const normalized = bucketParam?.trim() || 'media'
	if (normalized === 'media' || normalized === 'avatars' || normalized === 'chat') {
		return { ok: true, bucketParam: normalized }
	}
	return { ok: false }
}

export function getMediaUploadBucketAccess(params: {
	bucketParam: string | null | undefined
	userRole: string | null | undefined
	uploadRoute: MediaUploadRoute
}):
	| { ok: true; bucketParam: MediaUploadBucketParam }
	| { ok: false; status: 400 | 403; code: 'VALIDATION_ERROR' | 'FORBIDDEN'; message: string } {
	const normalized = normalizeMediaUploadBucketParam(params.bucketParam)
	if (!normalized.ok) {
		return {
			ok: false,
			status: 400,
			code: 'VALIDATION_ERROR',
			message: 'Некорректное место загрузки',
		}
	}

	if (normalized.bucketParam === 'media' && !isAdminRole(params.userRole)) {
		return {
			ok: false,
			status: 403,
			code: 'FORBIDDEN',
			message: 'Недостаточно прав для загрузки в медиатеку',
		}
	}

	if (normalized.bucketParam === 'chat' && params.uploadRoute !== 'chunked') {
		return {
			ok: false,
			status: 403,
			code: 'FORBIDDEN',
			message: 'Загрузите файл через чат',
		}
	}

	return { ok: true, bucketParam: normalized.bucketParam }
}
