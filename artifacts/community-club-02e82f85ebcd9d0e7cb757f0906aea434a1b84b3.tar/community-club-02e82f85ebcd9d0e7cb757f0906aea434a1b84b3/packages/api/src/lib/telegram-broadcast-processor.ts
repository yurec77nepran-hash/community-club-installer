import { telegramBroadcastDeliveries, telegramBroadcasts } from '@community-club/shared'
import { and, eq, lte, sql } from 'drizzle-orm'
import { env } from '../config/env'
import { db } from '../db/client'
import { logger } from './logger'
import { resolvePublicFileUrl } from './storage'
import { createTelegramBroadcastDeliveries } from './telegram-broadcast-audience'
import { getTelegramBroadcastBot } from './telegram-broadcast-bots'
import { sendTelegramBroadcastMessage } from './telegram-broadcast-message'

const PROCESSOR_INTERVAL_MS = 60_000
const PROCESSING_STALE_MS = 15 * 60_000
const SEND_INTERVAL_MS = 40

let started = false
let running = false

async function refreshBroadcastStats(broadcastId: number) {
	const [stats] = await db.execute<{
		audience_size: number
		sent_count: number
		failed_count: number
	}>(sql`
		SELECT
			count(*)::integer AS audience_size,
			count(*) FILTER (WHERE status = 'sent')::integer AS sent_count,
			count(*) FILTER (WHERE status = 'failed')::integer AS failed_count
		FROM telegram_broadcast_deliveries
		WHERE broadcast_id = ${broadcastId}
	`)
	return stats ?? { audience_size: 0, sent_count: 0, failed_count: 0 }
}

async function finishBroadcast(broadcastId: number) {
	const stats = await refreshBroadcastStats(broadcastId)
	const status = stats.audience_size > 0 && stats.sent_count === 0 ? 'failed' : 'completed'
	await db
		.update(telegramBroadcasts)
		.set({
			status,
			audienceSize: stats.audience_size,
			sentCount: stats.sent_count,
			failedCount: stats.failed_count,
			lastError: status === 'failed' ? 'Все отправки завершились ошибкой' : null,
			processingStartedAt: null,
			updatedAt: new Date(),
		})
		.where(eq(telegramBroadcasts.id, broadcastId))
}

async function sendPendingDeliveries(params: {
	broadcastId: number
	body: string
	buttons: typeof telegramBroadcasts.$inferSelect.buttons
	media: typeof telegramBroadcasts.$inferSelect.media
}) {
	while (true) {
		const pending = await db.execute<{
			id: number
			telegram_user_id: string
			bot_username: string
		}>(sql`
			SELECT d.id, c.telegram_user_id, c.bot_username
			FROM telegram_broadcast_deliveries d
			JOIN telegram_contacts c ON c.id = d.contact_id
			WHERE d.broadcast_id = ${params.broadcastId} AND d.status = 'pending'
			ORDER BY d.id
			LIMIT 1
		`)
		const delivery = pending[0]
		if (!delivery) return

		const claimed = await db
			.update(telegramBroadcastDeliveries)
			.set({ status: 'processing', updatedAt: new Date() })
			.where(
				and(
					eq(telegramBroadcastDeliveries.id, delivery.id),
					eq(telegramBroadcastDeliveries.status, 'pending'),
				),
			)
			.returning({ id: telegramBroadcastDeliveries.id })
		if (!claimed[0]) continue

		try {
			const bot = getTelegramBroadcastBot(delivery.bot_username)
			if (!bot) throw new Error('Бот не настроен')
			const mediaUrl = params.media
				? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, params.media.path)
				: null
			if (params.media && !mediaUrl) throw new Error('Файл вложения не найден')
			await sendTelegramBroadcastMessage({
				token: bot.token,
				chatId: delivery.telegram_user_id,
				body: params.body,
				buttons: params.buttons,
				media: params.media
					? {
							type: params.media.type,
							url: mediaUrl,
						}
					: null,
			})
			await db
				.update(telegramBroadcastDeliveries)
				.set({ status: 'sent', sentAt: new Date(), errorMessage: null, updatedAt: new Date() })
				.where(eq(telegramBroadcastDeliveries.id, delivery.id))
		} catch (error) {
			const message = error instanceof Error ? error.message.slice(0, 1000) : 'Telegram send failed'
			await db
				.update(telegramBroadcastDeliveries)
				.set({ status: 'failed', errorMessage: message, updatedAt: new Date() })
				.where(eq(telegramBroadcastDeliveries.id, delivery.id))
		}
		await Bun.sleep(SEND_INTERVAL_MS)
	}
}

async function processBroadcast(broadcast: typeof telegramBroadcasts.$inferSelect) {
	const botUsernames = broadcast.botUsernames.length
		? broadcast.botUsernames
		: [broadcast.botUsername]
	if (botUsernames.some((botUsername) => !getTelegramBroadcastBot(botUsername))) {
		throw new Error('В рассылке выбран ненастроенный бот')
	}
	await createTelegramBroadcastDeliveries({
		broadcastId: broadcast.id,
		botUsernames,
		deliveryMode: broadcast.deliveryMode,
		preferredBotUsername: broadcast.preferredBotUsername,
	})
	await sendPendingDeliveries({
		broadcastId: broadcast.id,
		body: broadcast.body,
		buttons: broadcast.buttons,
		media: broadcast.media,
	})
	await finishBroadcast(broadcast.id)
}

async function tick() {
	if (running) return
	running = true
	try {
		const staleBefore = new Date(Date.now() - PROCESSING_STALE_MS)
		const staleBeforeIso = staleBefore.toISOString()
		// ponytail: Telegram has no idempotency key; a process crash after send may cause one retry.
		await db.execute(sql`
			UPDATE telegram_broadcast_deliveries
			SET status = 'pending', updated_at = now()
			WHERE status = 'processing' AND updated_at < ${staleBeforeIso}
		`)
		await db
			.update(telegramBroadcasts)
			.set({ status: 'scheduled', processingStartedAt: null, updatedAt: new Date() })
			.where(
				and(
					eq(telegramBroadcasts.status, 'processing'),
					lte(telegramBroadcasts.processingStartedAt, staleBefore),
				),
			)

		const due = await db.query.telegramBroadcasts.findFirst({
			where: and(
				eq(telegramBroadcasts.status, 'scheduled'),
				lte(telegramBroadcasts.sendAt, new Date()),
			),
			orderBy: (table, { asc }) => [asc(table.sendAt)],
		})
		if (!due) return

		const claimed = await db
			.update(telegramBroadcasts)
			.set({ status: 'processing', processingStartedAt: new Date(), updatedAt: new Date() })
			.where(and(eq(telegramBroadcasts.id, due.id), eq(telegramBroadcasts.status, 'scheduled')))
			.returning()
		if (claimed[0]) await processBroadcast(claimed[0])
	} catch (error) {
		logger.error({ err: error }, 'Telegram broadcast processor failed')
	} finally {
		running = false
	}
}

export function startTelegramBroadcastProcessor() {
	if (started) return
	started = true
	void tick()
	setInterval(() => void tick(), PROCESSOR_INTERVAL_MS).unref?.()
}
