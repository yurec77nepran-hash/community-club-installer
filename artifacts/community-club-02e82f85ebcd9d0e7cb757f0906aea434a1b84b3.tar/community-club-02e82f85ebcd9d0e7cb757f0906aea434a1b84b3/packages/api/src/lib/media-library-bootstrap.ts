import { queryClient } from '../db/client'

const mediaLibraryBootstrapQueries = [
	`CREATE TABLE IF NOT EXISTS media_library_notes (
		key text PRIMARY KEY,
		title text NOT NULL DEFAULT '',
		note text NOT NULL DEFAULT '',
		folder_id integer,
		created_by_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
		updated_by_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	`CREATE TABLE IF NOT EXISTS media_library_folders (
		id bigserial PRIMARY KEY,
		name text NOT NULL,
		created_by_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	`CREATE TABLE IF NOT EXISTS media_library_preferences (
		auth_uuid uuid PRIMARY KEY REFERENCES users(auth_uuid) ON DELETE CASCADE,
		view_mode text NOT NULL DEFAULT 'cards',
		sort_by text NOT NULL DEFAULT 'updatedAt',
		sort_dir text NOT NULL DEFAULT 'desc',
		type_filter text NOT NULL DEFAULT 'all',
		search_query text NOT NULL DEFAULT '',
		folder_id integer REFERENCES media_library_folders(id) ON DELETE SET NULL,
		picker_view_mode text NOT NULL DEFAULT 'cards',
		picker_sort_by text NOT NULL DEFAULT 'updatedAt',
		picker_sort_dir text NOT NULL DEFAULT 'desc',
		picker_type_filter text NOT NULL DEFAULT 'all',
		picker_search_query text NOT NULL DEFAULT '',
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	"ALTER TABLE media_library_notes ADD COLUMN IF NOT EXISTS title text NOT NULL DEFAULT ''",
	"ALTER TABLE media_library_notes ADD COLUMN IF NOT EXISTS note text NOT NULL DEFAULT ''",
	'ALTER TABLE media_library_notes ADD COLUMN IF NOT EXISTS folder_id integer REFERENCES media_library_folders(id) ON DELETE SET NULL',
	"ALTER TABLE media_library_preferences ADD COLUMN IF NOT EXISTS picker_view_mode text NOT NULL DEFAULT 'cards'",
	"ALTER TABLE media_library_preferences ADD COLUMN IF NOT EXISTS picker_sort_by text NOT NULL DEFAULT 'updatedAt'",
	"ALTER TABLE media_library_preferences ADD COLUMN IF NOT EXISTS picker_sort_dir text NOT NULL DEFAULT 'desc'",
	"ALTER TABLE media_library_preferences ADD COLUMN IF NOT EXISTS picker_type_filter text NOT NULL DEFAULT 'all'",
	"ALTER TABLE media_library_preferences ADD COLUMN IF NOT EXISTS picker_search_query text NOT NULL DEFAULT ''",
	'CREATE UNIQUE INDEX IF NOT EXISTS media_library_notes_key_unique ON media_library_notes (key)',
	'CREATE INDEX IF NOT EXISTS media_library_notes_updated_idx ON media_library_notes (updated_at DESC)',
	'CREATE INDEX IF NOT EXISTS media_library_notes_folder_idx ON media_library_notes (folder_id)',
	'CREATE UNIQUE INDEX IF NOT EXISTS media_library_folders_name_unique ON media_library_folders (name)',
	'CREATE INDEX IF NOT EXISTS media_library_folders_created_idx ON media_library_folders (created_at DESC)',
	'CREATE INDEX IF NOT EXISTS media_library_preferences_updated_idx ON media_library_preferences (updated_at DESC)',
]

export async function ensureMediaLibraryArtifacts() {
	for (const query of mediaLibraryBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
