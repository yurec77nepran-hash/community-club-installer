import { createHash } from 'node:crypto'
import { request as httpsRequest } from 'node:https'
import { URL } from 'node:url'
import { SocksProxyAgent } from 'socks-proxy-agent'
import { env } from '../config/env'
import { logger } from '../lib/logger'
import { getAppBaseUrl, loadRuntimeSettings } from './site-settings'

const telegramAgent = env.TELEGRAM_SOCKS5_PROXY
	? new SocksProxyAgent(env.TELEGRAM_SOCKS5_PROXY)
	: undefined

export interface TelegramInlineKeyboardButton {
	text: string
	url?: string
	style?: 'primary' | 'success' | 'danger'
	callback_data?: string
	copy_text?: {
		text: string
	}
}

export interface TelegramSendMessageOptions {
	parseMode?: 'HTML' | 'MarkdownV2'
	replyMarkup?: {
		inline_keyboard: TelegramInlineKeyboardButton[][]
	}
}

export type TelegramBotKind = 'main' | 'audio'

export function requestText(url: string, options?: { method?: 'GET' | 'POST'; body?: string }) {
	return new Promise<string>((resolve, reject) => {
		const target = new URL(url)
		const req = httpsRequest(
			{
				protocol: target.protocol,
				hostname: target.hostname,
				port: target.port || 443,
				path: `${target.pathname}${target.search}`,
				method: options?.method ?? 'GET',
				headers: options?.body
					? {
							'content-type': 'application/json',
							'content-length': Buffer.byteLength(options.body),
						}
					: undefined,
				agent: telegramAgent,
			},
			(res) => {
				let raw = ''
				res.setEncoding('utf8')
				res.on('data', (chunk) => {
					raw += chunk
				})
				res.on('end', () => {
					if ((res.statusCode ?? 500) < 200 || (res.statusCode ?? 500) >= 300) {
						reject(new Error(`Telegram request failed: ${res.statusCode} ${raw}`))
						return
					}
					resolve(raw)
				})
			},
		)

		req.on('error', reject)
		if (options?.body) {
			req.write(options.body)
		}
		req.end()
	})
}

function requestBuffer(url: string) {
	return new Promise<Buffer>((resolve, reject) => {
		const target = new URL(url)
		const req = httpsRequest(
			{
				protocol: target.protocol,
				hostname: target.hostname,
				port: target.port || 443,
				path: `${target.pathname}${target.search}`,
				method: 'GET',
				agent: telegramAgent,
			},
			(res) => {
				const chunks: Buffer[] = []
				res.on('data', (chunk) => {
					chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
				})
				res.on('end', () => {
					if ((res.statusCode ?? 500) < 200 || (res.statusCode ?? 500) >= 300) {
						reject(new Error(`Telegram file download failed: ${res.statusCode}`))
						return
					}
					resolve(Buffer.concat(chunks))
				})
			},
		)
		req.on('error', reject)
		req.end()
	})
}

async function getTelegramBotToken(botKind: TelegramBotKind = 'main') {
	if (botKind === 'audio') return env.TELEGRAM_AUDIO_BOT_TOKEN
	const settings = await loadRuntimeSettings()
	return settings.telegramBotToken || env.TELEGRAM_BOT_TOKEN
}

async function buildTelegramApiUrl(path: string, botKind: TelegramBotKind = 'main') {
	const token = await getTelegramBotToken(botKind)
	if (!token) {
		throw new Error(`TELEGRAM_${botKind === 'audio' ? 'AUDIO_' : ''}BOT_TOKEN is not configured`)
	}
	return `https://api.telegram.org/bot${token}/${path}`
}

async function buildTelegramFileUrl(filePath: string, botKind: TelegramBotKind = 'main') {
	const token = await getTelegramBotToken(botKind)
	if (!token) {
		throw new Error(`TELEGRAM_${botKind === 'audio' ? 'AUDIO_' : ''}BOT_TOKEN is not configured`)
	}
	return `https://api.telegram.org/file/bot${token}/${filePath}`
}

async function postJson(path: string, payload: unknown, options?: { botKind?: TelegramBotKind }) {
	const raw = await requestText(await buildTelegramApiUrl(path, options?.botKind), {
		method: 'POST',
		body: JSON.stringify(payload),
	})

	const parsed = raw ? JSON.parse(raw) : null
	if (parsed && typeof parsed === 'object' && 'ok' in parsed && parsed.ok === false) {
		const description =
			'description' in parsed && typeof parsed.description === 'string'
				? parsed.description
				: 'unknown error'
		throw new Error(`Telegram request failed: ${description}`)
	}

	return parsed
}

export async function postJsonWithToken(token: string, path: string, payload: unknown) {
	const raw = await requestText(`https://api.telegram.org/bot${token}/${path}`, {
		method: 'POST',
		body: JSON.stringify(payload),
	})
	const parsed = raw ? JSON.parse(raw) : null
	if (parsed && typeof parsed === 'object' && 'ok' in parsed && parsed.ok === false) {
		const description =
			'description' in parsed && typeof parsed.description === 'string'
				? parsed.description
				: 'unknown error'
		throw new Error(`Telegram request failed: ${description}`)
	}
	return parsed
}

async function getJson(path: string, options?: { botKind?: TelegramBotKind }) {
	const raw = await requestText(await buildTelegramApiUrl(path, options?.botKind))
	const parsed = raw ? JSON.parse(raw) : null
	if (parsed && typeof parsed === 'object' && 'ok' in parsed && parsed.ok === false) {
		const description =
			'description' in parsed && typeof parsed.description === 'string'
				? parsed.description
				: 'unknown error'
		throw new Error(`Telegram request failed: ${description}`)
	}

	return parsed
}

export function getTelegramWebhookSecret() {
	return createHash('sha256').update(env.JWT_SECRET).digest('hex').slice(0, 32)
}

export async function ensureTelegramWebhook() {
	if (!env.TELEGRAM_SYNC_WEBHOOK) return
	const token = await getTelegramBotToken('main')
	if (!token) return
	const appUrl = await getAppBaseUrl()
	if (!appUrl.startsWith('https://')) {
		logger.warn('Telegram webhook sync skipped: APP_URL is not https')
		return
	}

	const url = `${appUrl.replace(/\/$/, '')}/api/telegram/webhook`
	const secretToken = getTelegramWebhookSecret()

	try {
		await postJson('setWebhook', {
			url,
			secret_token: secretToken,
			allowed_updates: ['message', 'callback_query'],
			drop_pending_updates: false,
		})
	} catch (error) {
		logger.warn({ err: error }, 'Failed to sync Telegram webhook')
	}
}

export async function getTelegramWebhookInfo(options?: { botKind?: TelegramBotKind }) {
	return getJson('getWebhookInfo', options) as Promise<{
		result?: { url?: string | null; pending_update_count?: number }
	}>
}

export async function getTelegramUpdates(
	params?: { offset?: number; timeout?: number },
	options?: { botKind?: TelegramBotKind },
) {
	const search = new URLSearchParams()
	if (typeof params?.offset === 'number') {
		search.set('offset', String(params.offset))
	}
	if (typeof params?.timeout === 'number') {
		search.set('timeout', String(params.timeout))
	}
	search.set('allowed_updates', JSON.stringify(['message', 'callback_query']))
	return getJson(`getUpdates?${search.toString()}`, options) as Promise<{
		result?: Array<{ update_id: number; message?: unknown; callback_query?: unknown }>
	}>
}

export async function sendTelegramMessage(
	chatId: string,
	text: string,
	options?: TelegramSendMessageOptions & { botKind?: TelegramBotKind },
) {
	return postJson(
		'sendMessage',
		{
			chat_id: chatId,
			text,
			parse_mode: options?.parseMode,
			reply_markup: options?.replyMarkup,
		},
		{ botKind: options?.botKind },
	)
}

export async function sendTelegramMessageWithToken(
	token: string,
	chatId: string,
	text: string,
	options?: TelegramSendMessageOptions,
) {
	return postJsonWithToken(token, 'sendMessage', {
		chat_id: chatId,
		text,
		parse_mode: options?.parseMode,
		reply_markup: options?.replyMarkup,
	})
}

export async function editTelegramMessage(
	chatId: string,
	messageId: number,
	text: string,
	options?: TelegramSendMessageOptions & { botKind?: TelegramBotKind },
) {
	return postJson(
		'editMessageText',
		{
			chat_id: chatId,
			message_id: messageId,
			text,
			parse_mode: options?.parseMode,
			reply_markup: options?.replyMarkup,
		},
		{ botKind: options?.botKind },
	)
}

export async function deleteTelegramMessage(
	chatId: string,
	messageId: number,
	options?: { botKind?: TelegramBotKind },
) {
	return postJson(
		'deleteMessage',
		{
			chat_id: chatId,
			message_id: messageId,
		},
		options,
	)
}

export async function answerTelegramCallbackQuery(
	callbackQueryId: string,
	text?: string,
	options?: { botKind?: TelegramBotKind },
) {
	return postJson(
		'answerCallbackQuery',
		{
			callback_query_id: callbackQueryId,
			text,
		},
		options,
	)
}

export async function downloadTelegramFile(
	fileId: string,
	options?: { botKind?: TelegramBotKind },
) {
	const response = (await getJson(`getFile?file_id=${encodeURIComponent(fileId)}`, options)) as {
		result?: { file_path?: string }
	}
	const filePath = response?.result?.file_path?.trim()
	if (!filePath) {
		throw new Error('Telegram file path not found')
	}

	const buffer = await requestBuffer(await buildTelegramFileUrl(filePath, options?.botKind))

	return { filePath, buffer }
}
