import { z } from 'zod'
import { env } from '../config/env'

const telegramBroadcastBotSchema = z.object({
	username: z.string().trim().min(1).max(128),
	label: z.string().trim().min(1).max(128),
	token: z.string().trim().min(1),
})

export type TelegramBroadcastBot = z.infer<typeof telegramBroadcastBotSchema>
export type PublicTelegramBroadcastBot = Omit<TelegramBroadcastBot, 'token'>

function normalizeUsername(value: string) {
	return value.trim().replace(/^@/, '').toLowerCase()
}

function loadBots(): TelegramBroadcastBot[] {
	if (!env.TELEGRAM_BROADCAST_BOTS.trim()) return []
	const parsed = z
		.array(telegramBroadcastBotSchema)
		.safeParse(JSON.parse(env.TELEGRAM_BROADCAST_BOTS))
	if (!parsed.success) throw new Error('TELEGRAM_BROADCAST_BOTS has an invalid format')

	const bots = parsed.data.map((bot) => ({ ...bot, username: normalizeUsername(bot.username) }))
	if (new Set(bots.map((bot) => bot.username)).size !== bots.length) {
		throw new Error('TELEGRAM_BROADCAST_BOTS contains duplicate usernames')
	}
	return bots
}

export function getTelegramBroadcastBots(): TelegramBroadcastBot[] {
	return loadBots()
}

export function getPublicTelegramBroadcastBots(): PublicTelegramBroadcastBot[] {
	return loadBots().map(({ token: _token, ...bot }) => bot)
}

export function getTelegramBroadcastBot(username: string) {
	return loadBots().find((bot) => bot.username === normalizeUsername(username)) ?? null
}

export { normalizeUsername as normalizeTelegramBotUsername }
