import { createHmac, timingSafeEqual } from 'node:crypto'

export type ProdamusPayload = Record<string, unknown>

export function parsePhpFormData(entries: [string, string][]): ProdamusPayload {
	const result: ProdamusPayload = {}

	for (const [key, value] of entries) {
		const match = key.match(/^([^[]+)((?:\[[^\]]*\])*)$/)
		if (!match) {
			result[key] = value
			continue
		}

		const root = match[1] ?? ''
		const brackets = match[2]
		if (!root) continue

		if (!brackets) {
			result[root] = value
			continue
		}

		const indices = Array.from(brackets.matchAll(/\[([^\]]*)\]/g)).map((item) => item[1] ?? '')
		if (indices.length === 0) {
			result[root] = value
			continue
		}

		if (!(root in result)) {
			result[root] = isNumericIndex(indices[0]) ? [] : {}
		}

		let target = result[root]
		for (let index = 0; index < indices.length; index += 1) {
			const currentIndex = indices[index] ?? ''
			const nextIndex = indices[index + 1]
			const isLast = index === indices.length - 1

			if (Array.isArray(target)) {
				const arrayIndex = currentIndex === '' ? target.length : Number(currentIndex)
				if (isLast) {
					target[arrayIndex] = value
					continue
				}
				if (target[arrayIndex] === undefined) {
					target[arrayIndex] = isNumericIndex(nextIndex) ? [] : {}
				}
				target = target[arrayIndex]
				continue
			}

			if (!target || typeof target !== 'object') break
			const objectTarget = target as ProdamusPayload
			if (isLast) {
				objectTarget[currentIndex] = value
				continue
			}
			if (objectTarget[currentIndex] === undefined) {
				objectTarget[currentIndex] = isNumericIndex(nextIndex) ? [] : {}
			}
			target = objectTarget[currentIndex]
		}
	}

	return result
}

function isNumericIndex(value: string | undefined) {
	return value !== undefined && value !== '' && /^\d+$/.test(value)
}

function normalizeForProdamus(value: unknown): unknown {
	if (Array.isArray(value)) return value.map(normalizeForProdamus)
	if (value && typeof value === 'object') {
		return Object.fromEntries(
			Object.entries(value as ProdamusPayload)
				.filter(([, item]) => item !== undefined)
				.sort(([left], [right]) => left.localeCompare(right))
				.map(([key, item]) => [key, normalizeForProdamus(item)]),
		)
	}
	return value == null ? '' : String(value)
}

function toProdamusJson(payload: unknown) {
	return JSON.stringify(normalizeForProdamus(payload)).replace(/\//g, '\\/')
}

function normalizeSignature(signature: string | undefined) {
	const trimmed = String(signature ?? '')
		.trim()
		.toLowerCase()
	if (!trimmed) return ''
	return trimmed.startsWith('sha256=') ? trimmed.slice('sha256='.length).trim() : trimmed
}

function safeSignatureEqual(left: string, right: string) {
	const leftBuffer = Buffer.from(left)
	const rightBuffer = Buffer.from(right)
	return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer)
}

export function signProdamusPayload(payload: unknown, secret: string) {
	return createHmac('sha256', secret).update(toProdamusJson(payload), 'utf-8').digest('hex')
}

function withoutSignatureFields(payload: unknown): unknown {
	if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return payload
	return Object.fromEntries(
		Object.entries(payload as ProdamusPayload).filter(
			([key]) => !['sign', 'signature'].includes(key.toLowerCase()),
		),
	)
}

export function verifyProdamusSignature(params: {
	payload: unknown
	signature: string | undefined
	secret: string
	flatPayload?: unknown
}) {
	if (!params.secret) return false
	const signature = normalizeSignature(params.signature)
	if (!/^[0-9a-f]{64}$/.test(signature)) return false

	const expected = signProdamusPayload(withoutSignatureFields(params.payload), params.secret)
	if (safeSignatureEqual(signature, expected)) return true

	if (params.flatPayload) {
		const flatExpected = signProdamusPayload(
			withoutSignatureFields(params.flatPayload),
			params.secret,
		)
		return safeSignatureEqual(signature, flatExpected)
	}

	return false
}
