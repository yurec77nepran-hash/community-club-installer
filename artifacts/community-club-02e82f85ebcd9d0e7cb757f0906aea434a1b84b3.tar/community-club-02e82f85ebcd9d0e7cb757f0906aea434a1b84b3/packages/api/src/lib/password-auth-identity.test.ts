import { describe, expect, test } from 'bun:test'
import { createPasswordAuthIdentity } from './password-auth-identity'

describe('password auth identity', () => {
	test('builds a normalized email identity for login and registration', () => {
		const rawEmail = ' Member@Example.COM '

		const identity = createPasswordAuthIdentity(rawEmail)

		expect(identity).toEqual({
			email: 'member@example.com',
			authType: 'email',
		})
	})
})
