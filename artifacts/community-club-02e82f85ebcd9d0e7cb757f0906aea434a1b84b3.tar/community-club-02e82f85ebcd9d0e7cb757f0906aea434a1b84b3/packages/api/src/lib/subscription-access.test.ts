import { describe, expect, test } from 'bun:test'
import { hasActiveDateFinish, normalizeDateFinish } from './subscription-access'

describe('subscription access', () => {
	test('normalizes date_finish values to date-only strings', () => {
		expect(normalizeDateFinish('2026-05-22')).toBe('2026-05-22')
		expect(normalizeDateFinish('2026-05-22T18:30:00.000Z')).toBe('2026-05-22')
		expect(normalizeDateFinish(null)).toBeNull()
		expect(normalizeDateFinish('bad-date')).toBeNull()
	})

	test('keeps access active through the finish date', () => {
		expect(hasActiveDateFinish('2026-05-22', '2026-05-22')).toBe(true)
		expect(hasActiveDateFinish('2026-05-21', '2026-05-22')).toBe(false)
		expect(hasActiveDateFinish('2026-05-23', '2026-05-22')).toBe(true)
	})
})
