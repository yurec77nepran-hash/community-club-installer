import { describe, expect, test } from 'bun:test'
import { paymentMatchesCheckoutSession, toPaymentMinorUnits } from './payment-checkout-claim'
import type { PaymentCheckoutSession } from './payment-checkout-session'

const session: PaymentCheckoutSession = {
	userAuthUuid: 'user-1',
	email: 'paid@example.com',
	invoiceId: 'club-active-30d:invoice-1',
	tariffSlug: 'club-active-30d',
	amount: 1990,
	createdAt: Date.parse('2026-05-26T10:00:00.000Z'),
}

const payment = {
	tarrif: 'club-active-30d',
	amount: '1990.00',
	createdAt: new Date('2026-05-26T10:00:04.000Z'),
	updatedAt: new Date('2026-05-26T10:00:04.000Z'),
}

const paymentLog = {
	orderId: 'club-active-30d:invoice-1',
	status: 'success',
	createdAt: new Date('2026-05-26T10:00:03.000Z'),
}

describe('payment checkout claim guard', () => {
	test('accepts a fresh successful webhook for the exact checkout invoice', () => {
		expect(paymentMatchesCheckoutSession({ session, payment, paymentLog })).toBe(true)
	})

	test('rejects an old active payment for the same email without a fresh checkout webhook', () => {
		expect(
			paymentMatchesCheckoutSession({
				session,
				payment: {
					...payment,
					createdAt: new Date('2026-05-01T10:00:00.000Z'),
					updatedAt: new Date('2026-05-01T10:00:00.000Z'),
				},
				paymentLog,
			}),
		).toBe(false)
	})

	test('rejects mismatched invoice, tariff, amount, or failed webhook', () => {
		expect(
			paymentMatchesCheckoutSession({
				session,
				payment,
				paymentLog: { ...paymentLog, orderId: 'other-invoice' },
			}),
		).toBe(false)
		expect(
			paymentMatchesCheckoutSession({
				session,
				payment: { ...payment, tarrif: 'club-active-90d' },
				paymentLog,
			}),
		).toBe(false)
		expect(
			paymentMatchesCheckoutSession({
				session,
				payment: { ...payment, amount: '1.00' },
				paymentLog,
			}),
		).toBe(false)
		expect(
			paymentMatchesCheckoutSession({
				session,
				payment,
				paymentLog: { ...paymentLog, status: 'failed' },
			}),
		).toBe(false)
	})

	test('normalizes decimal amounts to minor units', () => {
		expect(toPaymentMinorUnits('1990.00')).toBe(199000)
		expect(toPaymentMinorUnits('1990,50')).toBe(199050)
		expect(toPaymentMinorUnits('not-money')).toBeNull()
	})
})
