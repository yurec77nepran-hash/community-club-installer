import { type MessengerProvider, messengerConnections } from '@community-club/shared'
import { eq } from 'drizzle-orm'
import { env } from '../config/env'
import { db } from '../db/client'
import { decryptSecret } from './secret-vault'
import { requestText, sendTelegramMessageWithToken } from './telegram'

export type MessengerConnection = typeof messengerConnections.$inferSelect

export const messengerCapabilities: Record<
	MessengerProvider,
	{ html: boolean; linkButtons: boolean; media: boolean }
> = {
	telegram: { html: true, linkButtons: true, media: true },
	vk: { html: false, linkButtons: true, media: false },
	max: { html: true, linkButtons: true, media: false },
}

export async function getMessengerConnection(id: number) {
	return db.query.messengerConnections.findFirst({
		where: eq(messengerConnections.id, id),
	})
}

function token(connection: MessengerConnection) {
	const value = decryptSecret(connection.encryptedToken)
	if (!value) throw new Error('Токен подключения не задан')
	return value
}

function maxApiUrl(connection: MessengerConnection) {
	return (connection.config.apiUrl || env.MAX_API_URL || 'https://platform-api2.max.ru').replace(
		/\/$/,
		'',
	)
}

async function vkRequest(method: string, params: Record<string, string>) {
	const response = await fetch(`https://api.vk.ru/method/${method}`, {
		method: 'POST',
		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body: new URLSearchParams({ ...params, v: '5.199' }),
	})
	const body = (await response.json().catch(() => null)) as {
		response?: unknown
		error?: { error_msg?: string }
	} | null
	if (!response.ok || body?.error) throw new Error(body?.error?.error_msg || 'VK API недоступен')
	return body?.response
}

async function maxRequest(connection: MessengerConnection, path: string, body?: unknown) {
	const response = await fetch(`${maxApiUrl(connection)}${path}`, {
		method: body ? 'POST' : 'GET',
		headers: {
			Authorization: token(connection),
			...(body ? { 'Content-Type': 'application/json' } : {}),
		},
		...(body ? { body: JSON.stringify(body) } : {}),
	})
	const result = await response.json().catch(() => null)
	if (!response.ok) throw new Error(`MAX API: ${response.status}`)
	return result
}

export async function verifyMessengerConnection(params: {
	provider: MessengerProvider
	token: string
	externalId?: string
	apiUrl?: string
}) {
	if (params.provider === 'telegram') {
		const result = JSON.parse(
			await requestText(`https://api.telegram.org/bot${params.token}/getMe`),
		) as { ok?: boolean; result?: { username?: string; first_name?: string } }
		if (!result.ok || !result.result?.username) throw new Error('Telegram не подтвердил токен')
		return {
			externalId: result.result.username.toLowerCase(),
			label: result.result.first_name || result.result.username,
		}
	}

	if (params.provider === 'vk') {
		const groupId = params.externalId?.replace(/^club/, '').trim()
		if (!groupId) throw new Error('Укажите ID VK-сообщества')
		const response = (await vkRequest('groups.getById', {
			group_id: groupId,
			access_token: params.token,
		})) as Array<{ id?: number; name?: string }>
		const group = response?.[0]
		if (!group?.id) throw new Error('VK-сообщество не найдено')
		return { externalId: String(group.id), label: group.name || `VK-сообщество ${group.id}` }
	}

	const connection = {
		config: { apiUrl: params.apiUrl || 'https://platform-api2.max.ru' },
		encryptedToken: params.token,
	} as MessengerConnection
	const result = (await maxRequest(connection, '/me')) as {
		user_id?: number
		username?: string
		first_name?: string
		name?: string
	}
	if (!result?.user_id) throw new Error('MAX не подтвердил токен')
	return {
		externalId: String(result.user_id),
		label: result.first_name || result.name || result.username || `MAX-бот ${result.user_id}`,
	}
}

export async function sendMessengerText(params: {
	connection: MessengerConnection
	recipientId: string
	body: string
	plainText: string
}) {
	if (params.connection.provider === 'telegram') {
		return sendTelegramMessageWithToken(token(params.connection), params.recipientId, params.body, {
			parseMode: 'HTML',
		})
	}
	if (params.connection.provider === 'vk') {
		return vkRequest('messages.send', {
			access_token: token(params.connection),
			user_id: params.recipientId,
			message: params.plainText,
			random_id: crypto.randomUUID(),
		})
	}
	return maxRequest(
		params.connection,
		`/messages?user_id=${encodeURIComponent(params.recipientId)}`,
		{
			text: params.body,
			format: 'html',
		},
	)
}

export async function subscribeMaxWebhook(connection: MessengerConnection) {
	const secret = connection.webhookSecret
	if (!secret) throw new Error('Секрет MAX webhook не задан')
	const url = `${env.APP_URL.replace(/\/$/, '')}/api/messenger-webhooks/max/${connection.id}`
	return maxRequest(connection, '/subscriptions', {
		url,
		update_types: ['message_created', 'bot_started', 'bot_stopped'],
		secret,
	})
}
