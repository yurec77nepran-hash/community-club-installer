import { type ChatSettings, chatSettingsSchema } from '@community-club/shared'

type UserRole = 'user' | 'admin' | 'superadmin'

export const defaultChatSettings: ChatSettings = {
	allowMemberMessages: true,
	allowAttachments: true,
	allowReactions: true,
	slowModeSeconds: 0,
	welcomeText: null,
}

export function normalizeChatSettings(value: unknown): ChatSettings {
	const parsed = chatSettingsSchema.safeParse(value ?? {})
	if (!parsed.success) return defaultChatSettings
	return {
		...defaultChatSettings,
		...parsed.data,
		welcomeText: parsed.data.welcomeText?.trim() || null,
	}
}

export function isChatManager(userRole: UserRole, memberRole?: string | null) {
	return (
		userRole === 'admin' ||
		userRole === 'superadmin' ||
		memberRole === 'admin' ||
		memberRole === 'superadmin'
	)
}
