import { describe, expect, test } from 'bun:test'
import { isSubscriptionExpiredByMoscowDate } from './subscription-expiry-utils'

describe('isSubscriptionExpiredByMoscowDate', () => {
	test('expires on the day after dateFinish in Moscow calendar time', () => {
		expect(isSubscriptionExpiredByMoscowDate('2026-04-28', '2026-04-29')).toBe(true)
		expect(isSubscriptionExpiredByMoscowDate('2026-04-29', '2026-04-29')).toBe(false)
	})

	test('ignores empty or invalid dates', () => {
		expect(isSubscriptionExpiredByMoscowDate(null, '2026-04-29')).toBe(false)
		expect(isSubscriptionExpiredByMoscowDate('not-a-date', '2026-04-29')).toBe(false)
	})
})
