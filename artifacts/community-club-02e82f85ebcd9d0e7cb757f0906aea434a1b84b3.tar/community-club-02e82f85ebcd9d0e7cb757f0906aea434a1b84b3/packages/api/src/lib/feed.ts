import {
	type FeedAudience,
	type FeedPostItem,
	buildFeedExcerpt,
	feedPostReactions,
	feedPosts,
	renderFeedContentHtml,
	users,
} from '@community-club/shared'
import { and, desc, eq, inArray, lt } from 'drizzle-orm'
import { db } from '../db/client'
import { resolveAvatarUrl, resolvePublicFileUrl } from './storage'

const CLUB_AUDIENCES: FeedAudience[] = ['club']

type FeedPostRecord = Awaited<ReturnType<typeof loadFeedPostsRaw>>[number]

export function getFeedAudienceForUserRole(userRole: string): FeedAudience {
	void userRole
	return 'club'
}

export function canAccessFeedAudience(params: { userRole: string; audience: FeedAudience }) {
	void params
	return true
}

function mapFeedMedia(
	items:
		| Array<{
				type: 'image' | 'video'
				path: string
				url: string | null
				name: string | null
				size: number | null
				width: number | null
				height: number | null
				durationSeconds: number | null
		  }>
		| null
		| undefined,
) {
	return (items ?? []).map((item) => ({
		...item,
		url: item.url ?? resolvePublicFileUrl('media', item.path),
	}))
}

function buildReactionSummary(
	reactions: Array<{ emoji: string; userAuthUuid: string }>,
	currentUserId: string,
) {
	const map = new Map<string, { count: number; reactedByMe: boolean }>()
	for (const reaction of reactions) {
		const current = map.get(reaction.emoji) ?? { count: 0, reactedByMe: false }
		current.count += 1
		if (reaction.userAuthUuid === currentUserId) {
			current.reactedByMe = true
		}
		map.set(reaction.emoji, current)
	}

	return Array.from(map.entries()).map(([emoji, value]) => ({
		emoji,
		count: value.count,
		reactedByMe: value.reactedByMe,
	}))
}

function mapFeedPostItem(item: FeedPostRecord, currentUserId: string): FeedPostItem {
	return {
		id: item.id,
		audience: item.audience,
		content: item.content,
		contentHtml: renderFeedContentHtml(item.content),
		buttonLabel: item.buttonLabel,
		buttonUrl: item.buttonUrl,
		notifyAll: item.notifyAll,
		media: mapFeedMedia(item.media),
		createdAt: item.createdAt,
		author: item.author
			? {
					...item.author,
					avatarUrl: resolveAvatarUrl(item.author.avatarUrl),
				}
			: null,
		reactions: buildReactionSummary(item.reactions, currentUserId),
	}
}

async function loadFeedPostsRaw(params: {
	audience: FeedAudience
	cursor?: string
	limit: number
}) {
	const conditions = [inArray(feedPosts.audience, CLUB_AUDIENCES)]
	if (params.cursor) {
		conditions.push(lt(feedPosts.id, Number(params.cursor)))
	}

	return db.query.feedPosts.findMany({
		where: and(...conditions),
		orderBy: [desc(feedPosts.id)],
		limit: params.limit + 1,
		with: {
			author: {
				columns: {
					authUuid: true,
					fullName: true,
					username: true,
					avatarUrl: true,
					role: true,
				},
			},
			reactions: {
				columns: {
					emoji: true,
					userAuthUuid: true,
				},
			},
		},
	})
}

export async function loadFeedPage(params: {
	audience: FeedAudience
	cursor?: string
	limit: number
	currentUserId: string
}) {
	const items = await loadFeedPostsRaw(params)
	const hasMore = items.length > params.limit
	const data = hasMore ? items.slice(0, params.limit) : items
	return {
		items: data.map((item) => mapFeedPostItem(item, params.currentUserId)),
		nextCursor: hasMore && data.length > 0 ? String(data[data.length - 1].id) : null,
	}
}

export async function loadFeedPostById(params: { postId: number; currentUserId: string }) {
	const post = await db.query.feedPosts.findFirst({
		where: eq(feedPosts.id, params.postId),
		with: {
			author: {
				columns: {
					authUuid: true,
					fullName: true,
					username: true,
					avatarUrl: true,
					role: true,
				},
			},
			reactions: {
				columns: {
					emoji: true,
					userAuthUuid: true,
				},
			},
		},
	})

	return post ? mapFeedPostItem(post, params.currentUserId) : null
}

export async function loadFeedAudienceTargetUserIds(audience: FeedAudience) {
	void audience
	const roles = ['user'] as const

	const rows = await db.query.users.findMany({
		where: inArray(users.role, roles),
		columns: {
			authUuid: true,
		},
	})

	return rows.map((item) => item.authUuid)
}

export function buildFeedPushPayload(params: {
	audience: FeedAudience
	content: string
}) {
	void params.audience
	return {
		title: 'Новая публикация',
		body: buildFeedExcerpt(params.content, 120) || 'Откройте ленту, чтобы посмотреть публикацию.',
		url: '/app/feed',
	}
}
