import { describe, expect, test } from 'bun:test'
import { buildCloudPaymentsRecurrentConfig } from './cloudpayments-recurrent'

const baseSettings = {
	foreignCardsEnabled: true,
	billingMode: 'recurrent' as const,
	recurrentInterval: 'tariff' as const,
	recurrentPeriod: 1,
	recurrentMaxPeriods: null,
	recurrentStartDelayDays: null,
	requisitesEnabled: true,
	requisitesName: '',
	requisitesTaxId: '',
	requisitesRegistrationId: '',
	requisitesAddress: '',
}

describe('buildCloudPaymentsRecurrentConfig', () => {
	test('uses tariff schedule and starts after paid access by default', () => {
		expect(
			buildCloudPaymentsRecurrentConfig({
				settings: baseSettings,
				durationDays: 30,
				firstAccessDays: 7,
				regularAmount: 1990,
				now: new Date('2026-08-09T10:00:00.000Z'),
			}),
		).toEqual({
			interval: 'Month',
			period: 1,
			amount: 1990,
			startDate: '2026-08-16T10:00:00.000Z',
		})
	})

	test('allows admin custom period, start delay and max periods', () => {
		expect(
			buildCloudPaymentsRecurrentConfig({
				settings: {
					...baseSettings,
					recurrentInterval: 'Week',
					recurrentPeriod: 2,
					recurrentMaxPeriods: 6,
					recurrentStartDelayDays: 1,
				},
				durationDays: 30,
				firstAccessDays: 30,
				regularAmount: 3000,
				now: new Date('2026-08-09T10:00:00.000Z'),
			}),
		).toEqual({
			interval: 'Week',
			period: 2,
			amount: 3000,
			startDate: '2026-08-10T10:00:00.000Z',
			maxPeriods: 6,
		})
	})
})
