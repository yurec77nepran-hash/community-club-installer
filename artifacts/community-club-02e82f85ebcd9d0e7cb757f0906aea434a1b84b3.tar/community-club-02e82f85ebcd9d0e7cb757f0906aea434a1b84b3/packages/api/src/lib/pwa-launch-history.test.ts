import { describe, expect, test } from 'bun:test'
import * as schema from '@community-club/shared'
import { drizzle } from 'drizzle-orm/postgres-js'
import { buildPwaLaunchUpsert } from './pwa-launch-history'

describe('PWA launch history query', () => {
	test('uses one PostgreSQL upsert to increment repeated launches atomically', () => {
		// Given
		const database = drizzle.mock({ schema })

		// When
		const query = buildPwaLaunchUpsert(database, {
			userAuthUuid: '11111111-1111-4111-8111-111111111111',
			metadata: { platform: 'Android' },
			now: new Date('2026-09-09T10:00:00.000Z'),
		})
		const generated = query.toSQL()

		// Then
		expect(generated.sql).toContain('on conflict ("user_auth_uuid") do update')
		expect(generated.sql).toContain('"launch_count" = "pwa_installations"."launch_count" + 1')
		expect(generated.sql).toContain('returning')
	})
})
