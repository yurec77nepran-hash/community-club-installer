import { randomUUID } from 'node:crypto'
import { createReadStream, createWriteStream } from 'node:fs'
import { mkdir, readFile, readdir, rename, rm, stat, unlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, join } from 'node:path'
import { Readable, Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { UploadBodyTooLargeError } from './raw-upload-temp'

export type ChunkedUploadMetadata = {
	uploadId: string
	userId: string
	fileName: string
	fileSize: number
	contentType: string
	bucketParam: string | null
	folderIdRaw: string | null
	chunkSize: number
	totalChunks: number
	traceId: string | null
	createdAt: string
	updatedAt: string
}

export type ChunkedUploadSession = {
	metadata: ChunkedUploadMetadata
	dir: string
}

const CHUNKED_UPLOAD_ROOT = join(tmpdir(), 'community-club-chunk-uploads')
const UPLOAD_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

function assertSafeUploadId(uploadId: string) {
	if (!UPLOAD_ID_PATTERN.test(uploadId)) {
		throw new Error('Invalid upload id')
	}
}

function getUploadDir(uploadId: string) {
	assertSafeUploadId(uploadId)
	return join(CHUNKED_UPLOAD_ROOT, uploadId)
}

function getMetadataPath(uploadId: string) {
	return join(getUploadDir(uploadId), 'metadata.json')
}

function getChunksDir(uploadId: string) {
	return join(getUploadDir(uploadId), 'chunks')
}

function getChunkPath(uploadId: string, index: number) {
	return join(getChunksDir(uploadId), `${index}.part`)
}

function getTempChunkPath(uploadId: string, index: number) {
	return join(getChunksDir(uploadId), `${index}.${randomUUID()}.tmp`)
}

function getChunkSize(chunk: unknown) {
	if (typeof chunk === 'string') return Buffer.byteLength(chunk)
	if (chunk instanceof Uint8Array) return chunk.byteLength
	return 0
}

function getExpectedChunkSize(metadata: ChunkedUploadMetadata, index: number) {
	if (index < 0 || index >= metadata.totalChunks) {
		throw new Error('Invalid chunk index')
	}
	const start = index * metadata.chunkSize
	return Math.min(metadata.chunkSize, metadata.fileSize - start)
}

async function writeMetadata(metadata: ChunkedUploadMetadata) {
	await writeFile(getMetadataPath(metadata.uploadId), JSON.stringify(metadata, null, 2))
}

export async function createChunkedUploadSession(params: {
	userId: string
	fileName: string
	fileSize: number
	contentType: string
	bucketParam: string | null
	folderIdRaw: string | null
	chunkSize: number
	traceId: string | null
}) {
	if (!Number.isInteger(params.fileSize) || params.fileSize <= 0) {
		throw new Error('Invalid file size')
	}
	if (!Number.isInteger(params.chunkSize) || params.chunkSize <= 0) {
		throw new Error('Invalid chunk size')
	}

	const uploadId = randomUUID()
	const now = new Date().toISOString()
	const metadata: ChunkedUploadMetadata = {
		uploadId,
		userId: params.userId,
		fileName: params.fileName,
		fileSize: params.fileSize,
		contentType: params.contentType || 'application/octet-stream',
		bucketParam: params.bucketParam,
		folderIdRaw: params.folderIdRaw,
		chunkSize: params.chunkSize,
		totalChunks: Math.ceil(params.fileSize / params.chunkSize),
		traceId: params.traceId,
		createdAt: now,
		updatedAt: now,
	}

	await mkdir(getChunksDir(uploadId), { recursive: true })
	await writeMetadata(metadata)

	return { metadata, dir: getUploadDir(uploadId) }
}

export async function readChunkedUploadSession(uploadId: string): Promise<ChunkedUploadSession> {
	const metadata = JSON.parse(
		await readFile(getMetadataPath(uploadId), 'utf8'),
	) as ChunkedUploadMetadata
	return { metadata, dir: getUploadDir(uploadId) }
}

export async function writeChunkedUploadPart(params: {
	metadata: ChunkedUploadMetadata
	index: number
	body: ReadableStream<Uint8Array>
}) {
	const expectedSize = getExpectedChunkSize(params.metadata, params.index)
	const tempPath = getTempChunkPath(params.metadata.uploadId, params.index)
	const finalPath = getChunkPath(params.metadata.uploadId, params.index)
	let bytesRead = 0

	const limitStream = new Transform({
		transform(chunk, _encoding, callback) {
			bytesRead += getChunkSize(chunk)
			if (bytesRead > expectedSize) {
				callback(new UploadBodyTooLargeError(bytesRead, expectedSize))
				return
			}
			callback(null, chunk)
		},
	})

	try {
		await pipeline(
			Readable.fromWeb(params.body as Parameters<typeof Readable.fromWeb>[0]),
			limitStream,
			createWriteStream(tempPath),
		)

		if (bytesRead !== expectedSize) {
			throw new Error('Chunk size mismatch')
		}

		await rename(tempPath, finalPath)
		params.metadata.updatedAt = new Date().toISOString()
		await writeMetadata(params.metadata)
		return { size: bytesRead }
	} catch (error) {
		await unlink(tempPath).catch(() => undefined)
		throw error
	}
}

export async function listReceivedChunkIndexes(uploadId: string) {
	const entries = await readdir(getChunksDir(uploadId)).catch(() => [])
	return entries
		.map((entry) => {
			if (!entry.endsWith('.part')) return null
			const parsed = Number.parseInt(basename(entry, '.part'), 10)
			return Number.isInteger(parsed) && parsed >= 0 ? parsed : null
		})
		.filter((value): value is number => value != null)
		.sort((a, b) => a - b)
}

export async function assertChunkedUploadComplete(metadata: ChunkedUploadMetadata) {
	let totalSize = 0
	for (let index = 0; index < metadata.totalChunks; index++) {
		const chunkStat = await stat(getChunkPath(metadata.uploadId, index)).catch(() => null)
		if (!chunkStat) {
			throw new Error(`Missing chunk ${index}`)
		}
		const expectedSize = getExpectedChunkSize(metadata, index)
		if (chunkStat.size !== expectedSize) {
			throw new Error(`Invalid chunk ${index} size`)
		}
		totalSize += chunkStat.size
	}
	if (totalSize !== metadata.fileSize) {
		throw new Error('Invalid assembled upload size')
	}
}

export function createChunkedUploadReadStream(metadata: ChunkedUploadMetadata) {
	return Readable.from(
		(async function* () {
			for (let index = 0; index < metadata.totalChunks; index++) {
				const stream = createReadStream(getChunkPath(metadata.uploadId, index))
				for await (const chunk of stream) {
					yield chunk
				}
			}
		})(),
	)
}

export async function deleteChunkedUploadSession(uploadId: string) {
	await rm(getUploadDir(uploadId), { recursive: true, force: true })
}

export async function pruneExpiredChunkedUploadSessions(params: { maxAgeMs: number; now?: Date }) {
	const now = params.now ?? new Date()
	const entries = await readdir(CHUNKED_UPLOAD_ROOT).catch(() => [])
	let deleted = 0

	for (const entry of entries) {
		if (!UPLOAD_ID_PATTERN.test(entry)) continue

		const uploadId = entry
		try {
			const { metadata } = await readChunkedUploadSession(uploadId)
			const updatedAt = new Date(metadata.updatedAt || metadata.createdAt).getTime()
			if (!Number.isFinite(updatedAt) || now.getTime() - updatedAt <= params.maxAgeMs) {
				continue
			}
			await deleteChunkedUploadSession(uploadId)
			deleted++
		} catch {
			await rm(getUploadDir(uploadId), { recursive: true, force: true }).catch(() => undefined)
			deleted++
		}
	}

	return { deleted }
}
