import { Readable } from 'node:stream'
import {
	AbortMultipartUploadCommand,
	CompleteMultipartUploadCommand,
	CreateMultipartUploadCommand,
	DeleteObjectCommand,
	GetObjectCommand,
	PutObjectCommand,
	type PutObjectCommandInput,
	S3Client,
	UploadPartCommand,
} from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'
import {
	type GuestContentBlockAccess,
	type MaterialGuestAccess,
	type MaterialVideoChapters,
	normalizeVideoChapters,
} from '@community-club/shared'
import { env } from '../config/env'

export const s3 = new S3Client({
	endpoint: env.S3_ENDPOINT,
	region: env.S3_REGION,
	credentials: {
		accessKeyId: env.S3_ACCESS_KEY,
		secretAccessKey: env.S3_SECRET_KEY,
	},
	forcePathStyle: true,
	requestChecksumCalculation: 'WHEN_REQUIRED',
})

type UploadFileBody = ArrayBuffer | Buffer | Uint8Array | Readable | ReadableStream<Uint8Array>

const MULTIPART_UPLOAD_THRESHOLD_BYTES = 128 * 1024 * 1024
const MULTIPART_UPLOAD_PART_BYTES = 32 * 1024 * 1024

function normalizeUploadBody(body: UploadFileBody): PutObjectCommandInput['Body'] {
	if (body instanceof ArrayBuffer) {
		return new Uint8Array(body)
	}
	if (body instanceof ReadableStream) {
		return Readable.fromWeb(body) as PutObjectCommandInput['Body']
	}
	return body as PutObjectCommandInput['Body']
}

function isStreamUploadBody(body: UploadFileBody): body is Readable | ReadableStream<Uint8Array> {
	return body instanceof Readable || body instanceof ReadableStream
}

function toNodeReadable(body: Readable | ReadableStream<Uint8Array>) {
	if (body instanceof ReadableStream) {
		return Readable.fromWeb(body as Parameters<typeof Readable.fromWeb>[0])
	}
	return body
}

async function uploadMultipartFile(params: {
	bucket: string
	key: string
	body: Readable | ReadableStream<Uint8Array>
	contentType: string
	contentLength: number
}) {
	const createResponse = await s3.send(
		new CreateMultipartUploadCommand({
			Bucket: params.bucket,
			Key: params.key,
			ContentType: params.contentType,
		}),
	)
	const uploadId = createResponse.UploadId
	if (!uploadId) throw new Error('S3 multipart upload id is missing')

	const completedParts: Array<{ ETag: string; PartNumber: number }> = []
	let partNumber = 1
	let bufferedChunks: Buffer[] = []
	let bufferedBytes = 0

	const uploadPart = async (body: Buffer) => {
		const response = await s3.send(
			new UploadPartCommand({
				Bucket: params.bucket,
				Key: params.key,
				UploadId: uploadId,
				PartNumber: partNumber,
				Body: body,
				ContentLength: body.byteLength,
			}),
		)
		if (!response.ETag) throw new Error(`S3 multipart part ${partNumber} ETag is missing`)
		completedParts.push({ ETag: response.ETag, PartNumber: partNumber })
		partNumber += 1
	}

	try {
		for await (const chunk of toNodeReadable(params.body)) {
			const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
			bufferedChunks.push(buffer)
			bufferedBytes += buffer.byteLength

			while (bufferedBytes >= MULTIPART_UPLOAD_PART_BYTES) {
				const joinedBuffer = Buffer.concat(bufferedChunks, bufferedBytes)
				await uploadPart(joinedBuffer.subarray(0, MULTIPART_UPLOAD_PART_BYTES))
				const restBody = joinedBuffer.subarray(MULTIPART_UPLOAD_PART_BYTES)
				bufferedChunks = restBody.byteLength > 0 ? [restBody] : []
				bufferedBytes = restBody.byteLength
			}
		}

		if (bufferedBytes > 0 || params.contentLength === 0) {
			await uploadPart(Buffer.concat(bufferedChunks, bufferedBytes))
		}

		await s3.send(
			new CompleteMultipartUploadCommand({
				Bucket: params.bucket,
				Key: params.key,
				UploadId: uploadId,
				MultipartUpload: { Parts: completedParts },
			}),
		)
	} catch (error) {
		await s3
			.send(
				new AbortMultipartUploadCommand({
					Bucket: params.bucket,
					Key: params.key,
					UploadId: uploadId,
				}),
			)
			.catch(() => {})
		throw error
	}
}

/** Загрузить файл в S3 */
export async function uploadFile(
	bucket: string,
	key: string,
	body: UploadFileBody,
	contentType: string,
	contentLength?: number | null,
): Promise<{ key: string; bucket: string }> {
	if (
		contentLength != null &&
		contentLength >= MULTIPART_UPLOAD_THRESHOLD_BYTES &&
		isStreamUploadBody(body)
	) {
		await uploadMultipartFile({ bucket, key, body, contentType, contentLength })
		return { key, bucket }
	}

	await s3.send(
		new PutObjectCommand({
			Bucket: bucket,
			Key: key,
			Body: normalizeUploadBody(body),
			ContentType: contentType,
			...(contentLength != null ? { ContentLength: contentLength } : {}),
		}),
	)
	return { key, bucket }
}

/** Получить signed URL для приватного файла (временная ссылка) */
export async function getSignedFileUrl(
	bucket: string,
	key: string,
	expiresIn = 900,
): Promise<string> {
	const command = new GetObjectCommand({ Bucket: bucket, Key: key })
	const signedUrl = await getSignedUrl(s3, command, { expiresIn })

	if (!env.S3_PUBLIC_URL) {
		return signedUrl
	}

	const internalUrl = new URL(signedUrl)
	const publicUrl = new URL(env.S3_PUBLIC_URL)
	const bucketPrefix = `/${bucket}`

	internalUrl.protocol = publicUrl.protocol
	internalUrl.username = publicUrl.username
	internalUrl.password = publicUrl.password
	internalUrl.hostname = publicUrl.hostname
	internalUrl.port = publicUrl.port

	if (
		internalUrl.pathname === bucketPrefix ||
		internalUrl.pathname.startsWith(`${bucketPrefix}/`)
	) {
		const publicBasePath = publicUrl.pathname.replace(/\/$/, '')
		internalUrl.pathname = `${publicBasePath}${internalUrl.pathname.slice(bucketPrefix.length)}`
	}

	return internalUrl.toString()
}

/** Получить публичный URL файла (через Garage web endpoint или Caddy proxy) */
export function getPublicUrl(bucket: string, key: string): string {
	if (env.S3_PUBLIC_URL) {
		if (bucket === env.S3_BUCKET_CHAT) {
			return `${env.S3_PUBLIC_URL.replace(/\/media$/, '/chat-media')}/${key}`
		}
		// Caddy проксирует media.domain.com → garage:3902
		// Garage web endpoint отдаёт файлы из бакета по ключу
		return `${env.S3_PUBLIC_URL}/${key}`
	}
	// Fallback: прямой S3 path-style URL
	return `${env.S3_ENDPOINT}/${bucket}/${key}`
}

function isAbsoluteUrl(value: string): boolean {
	return /^https?:\/\//i.test(value)
}

function getUrlOrigin(rawUrl: string | null | undefined): string | null {
	if (!rawUrl) return null
	try {
		return new URL(rawUrl).origin
	} catch {
		return null
	}
}

function tryExtractLegacyMediaKey(value: string): string | null {
	if (!isAbsoluteUrl(value)) return null

	try {
		const url = new URL(value)
		const appOrigin = getUrlOrigin(env.APP_URL)
		if (appOrigin && url.origin !== appOrigin) return null

		const pathname = url.pathname.replace(/\/+$/, '')
		if (!pathname.startsWith('/media/')) return null

		const key = pathname.slice('/media/'.length)
		return key ? normalizeStorageKey(key) : null
	} catch {
		return null
	}
}

function getAvatarProxyUrl(key: string): string {
	const appOrigin = getUrlOrigin(env.APP_URL)
	if (!appOrigin) {
		return `/api/media/avatar/${encodeURIComponent(key)}`
	}
	return `${appOrigin}/api/media/avatar/${encodeURIComponent(key)}`
}

function normalizeStorageKey(key: string): string {
	return key.replace(/^\/+/, '').replace(/^[^/]+\/+/, (prefix) => {
		const bucketPrefix = prefix.replace(/\/+$/, '')
		if (
			bucketPrefix === env.S3_BUCKET_MEDIA ||
			bucketPrefix === env.S3_BUCKET_CHAT ||
			bucketPrefix === env.S3_BUCKET_AVATARS
		) {
			return ''
		}

		return prefix
	})
}

export function resolvePublicFileUrl(
	bucket: string,
	value: string | null | undefined,
): string | null {
	if (!value) return null
	if (isAbsoluteUrl(value)) {
		const legacyMediaKey = tryExtractLegacyMediaKey(value)
		if (legacyMediaKey) {
			return bucket === env.S3_BUCKET_AVATARS
				? getAvatarProxyUrl(legacyMediaKey)
				: getPublicUrl(bucket, legacyMediaKey)
		}
		return value
	}

	const normalizedKey = normalizeStorageKey(value)
	if (!normalizedKey) return null

	if (bucket === env.S3_BUCKET_AVATARS) {
		return getAvatarProxyUrl(normalizedKey)
	}

	return getPublicUrl(bucket, normalizedKey)
}

export function resolveAvatarUrl(value: string | null | undefined): string | null {
	if (!value) return null
	if (value.startsWith('emoji:')) return value
	return resolvePublicFileUrl(env.S3_BUCKET_AVATARS, value)
}

export type StoredMediaFile = {
	path?: string
	type?: string
	url?: string
	displayName?: string
	downloadable?: boolean
	guestAccess?: GuestContentBlockAccess
	chapters?: MaterialVideoChapters
}

const defaultMaterialGuestAccess: MaterialGuestAccess = {
	cover: 'visible',
	description: 'visible',
	link: 'visible',
}

function normalizeGuestBlockAccess(value: unknown): GuestContentBlockAccess {
	return value === 'blurred' || value === 'locked' ? value : 'visible'
}

export function parseMaterialGuestAccess(value: string | null | undefined): MaterialGuestAccess {
	if (!value) return { ...defaultMaterialGuestAccess }
	try {
		const parsed = JSON.parse(value) as { guestAccess?: Partial<MaterialGuestAccess> }
		return {
			cover: normalizeGuestBlockAccess(parsed.guestAccess?.cover),
			description: normalizeGuestBlockAccess(parsed.guestAccess?.description),
			link: normalizeGuestBlockAccess(parsed.guestAccess?.link),
		}
	} catch {
		return { ...defaultMaterialGuestAccess }
	}
}

export function isStoredMediaFileDownloadable(file: StoredMediaFile | null | undefined): boolean {
	if (!file) return false
	return file.downloadable !== false
}

export function parseStoredMediaFiles(value: string | null | undefined): StoredMediaFile[] {
	if (!value) return []

	try {
		const parsed = JSON.parse(value) as unknown
		if (Array.isArray(parsed)) {
			return parsed
				.filter((item): item is StoredMediaFile => typeof item === 'object' && item !== null)
				.map((file) => ({ ...file, chapters: normalizeVideoChapters(file.chapters) }))
		}
		if (typeof parsed === 'object' && parsed !== null && Array.isArray(parsed.files)) {
			return parsed.files
				.filter((item): item is StoredMediaFile => typeof item === 'object' && item !== null)
				.map((file) => ({ ...file, chapters: normalizeVideoChapters(file.chapters) }))
		}
	} catch {}

	return [{ path: value }]
}

export function findPrimaryStoredMediaFile(
	value: string | null | undefined,
	mediaType?: string | null,
): { index: number; file: StoredMediaFile } | null {
	const files = parseStoredMediaFiles(value)
	if (files.length === 0) return null
	const hasUsableSource = (file: StoredMediaFile) => Boolean(file.path || file.url)

	const matchingIndex =
		files.findIndex((file) => hasUsableSource(file) && file.type === mediaType) >= 0
			? files.findIndex((file) => hasUsableSource(file) && file.type === mediaType)
			: files.findIndex(hasUsableSource)

	if (matchingIndex < 0) return null

	const file = files[matchingIndex]
	if (!file || !hasUsableSource(file)) return null

	return { index: matchingIndex, file }
}

export function findPreviewStoredMediaFile(
	value: string | null | undefined,
	mediaType?: string | null,
): StoredMediaFile | null {
	const files = parseStoredMediaFiles(value)
	if (files.length === 0) return null

	const hasUsablePath = (file: StoredMediaFile | null | undefined) =>
		Boolean(file?.path || file?.url)
	const imageFile = files.find((file) => file.type === 'image' && hasUsablePath(file))
	if (imageFile) return imageFile

	if (mediaType === 'image') {
		return files.find((file) => hasUsablePath(file)) ?? null
	}

	return null
}

export function extractMaterialStorageKey(
	value: string | null | undefined,
	mediaType?: string | null,
): string | null {
	const files = parseStoredMediaFiles(value)
	const matchingFile =
		files.find((file) => (file.path || file.url) && file.type === mediaType) ??
		files.find((file) => file.path || file.url)
	const source = matchingFile?.path ?? matchingFile?.url

	if (!source) {
		return null
	}

	if (isAbsoluteUrl(source)) {
		return source
	}

	return normalizeStorageKey(source)
}

/** Удалить файл из S3 */
export async function deleteFile(bucket: string, key: string): Promise<void> {
	await s3.send(new DeleteObjectCommand({ Bucket: bucket, Key: key }))
}

/** Определить бакет по типу медиа */
export function getBucketForMediaType(mediaType: string): string {
	switch (mediaType) {
		case 'video':
		case 'audio':
		case 'image':
		case 'document':
		case 'text':
			return env.S3_BUCKET_MEDIA
		default:
			return env.S3_BUCKET_MEDIA
	}
}
