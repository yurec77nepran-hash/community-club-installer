import { describe, expect, test } from 'bun:test'
import {
	assertChunkedUploadComplete,
	createChunkedUploadReadStream,
	createChunkedUploadSession,
	deleteChunkedUploadSession,
	listReceivedChunkIndexes,
	pruneExpiredChunkedUploadSessions,
	writeChunkedUploadPart,
} from './chunked-upload-temp'

function createBody(value: string) {
	return new ReadableStream<Uint8Array>({
		start(controller) {
			controller.enqueue(new TextEncoder().encode(value))
			controller.close()
		},
	})
}

async function readStream(stream: NodeJS.ReadableStream) {
	const chunks: Buffer[] = []
	for await (const chunk of stream) {
		chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
	}
	return Buffer.concat(chunks).toString('utf8')
}

describe('chunked upload temp storage', () => {
	test('writes chunks and reads them back in order', async () => {
		const { metadata } = await createChunkedUploadSession({
			userId: 'user-1',
			fileName: 'video.mp4',
			fileSize: 11,
			contentType: 'video/mp4',
			bucketParam: 'media',
			folderIdRaw: null,
			chunkSize: 4,
			traceId: 'trace-1',
		})

		try {
			await writeChunkedUploadPart({ metadata, index: 1, body: createBody('o wo') })
			await writeChunkedUploadPart({ metadata, index: 0, body: createBody('hell') })
			await writeChunkedUploadPart({ metadata, index: 2, body: createBody('rld') })

			expect(await listReceivedChunkIndexes(metadata.uploadId)).toEqual([0, 1, 2])
			await assertChunkedUploadComplete(metadata)
			expect(await readStream(createChunkedUploadReadStream(metadata))).toBe('hello world')
		} finally {
			await deleteChunkedUploadSession(metadata.uploadId)
		}
	})

	test('rejects a chunk with an unexpected size', async () => {
		const { metadata } = await createChunkedUploadSession({
			userId: 'user-1',
			fileName: 'video.mp4',
			fileSize: 8,
			contentType: 'video/mp4',
			bucketParam: 'media',
			folderIdRaw: null,
			chunkSize: 4,
			traceId: 'trace-1',
		})

		try {
			await expect(
				writeChunkedUploadPart({ metadata, index: 0, body: createBody('abc') }),
			).rejects.toThrow()
		} finally {
			await deleteChunkedUploadSession(metadata.uploadId)
		}
	})

	test('prunes expired incomplete sessions from temporary storage', async () => {
		const { metadata } = await createChunkedUploadSession({
			userId: 'user-1',
			fileName: 'video.mp4',
			fileSize: 8,
			contentType: 'video/mp4',
			bucketParam: 'media',
			folderIdRaw: null,
			chunkSize: 4,
			traceId: 'trace-1',
		})

		const result = await pruneExpiredChunkedUploadSessions({
			maxAgeMs: -1,
			now: new Date(),
		})

		expect(result.deleted).toBeGreaterThanOrEqual(1)
		await expect(listReceivedChunkIndexes(metadata.uploadId)).resolves.toEqual([])
	})
})
