import { describe, expect, test } from 'bun:test'
import { getBillingTargetDateForOffset } from './push-campaign-processor-utils'

describe('getBillingTargetDateForOffset', () => {
	test('positive offsets target future billing dates', () => {
		expect(getBillingTargetDateForOffset('2026-04-29', 5)).toBe('2026-05-04')
		expect(getBillingTargetDateForOffset('2026-04-29', 1)).toBe('2026-04-30')
	})

	test('zero offset targets today', () => {
		expect(getBillingTargetDateForOffset('2026-04-29', 0)).toBe('2026-04-29')
	})
})
