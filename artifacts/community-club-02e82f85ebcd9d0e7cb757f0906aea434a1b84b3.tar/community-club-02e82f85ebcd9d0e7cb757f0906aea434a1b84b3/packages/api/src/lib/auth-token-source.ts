export function resolveAccessTokenSource(params: {
	cookieToken?: string | null
	headerToken?: string | null
}) {
	return params.cookieToken || params.headerToken || null
}
