import { describe, expect, test } from 'bun:test'
import {
	canAccessRegularChat,
	canUseChatMemberOverride,
	getRolesForChatAccess,
} from './chat-access-policy'

describe('chat access policy', () => {
	test('allows a regular participant into club chats', () => {
		expect(
			canAccessRegularChat({
				userRole: 'user',
				accessRole: 'all',
				memberRole: null,
			}),
		).toBe(true)
	})

	test('allows an active member row to keep access to a regular chat', () => {
		expect(canUseChatMemberOverride('member')).toBe(true)
	})

	test('keeps admin member overrides working', () => {
		expect(canUseChatMemberOverride('admin')).toBe(true)
		expect(canUseChatMemberOverride('superadmin')).toBe(true)
	})

	test('includes club roles in chat push audience', () => {
		expect(getRolesForChatAccess('all')).toEqual(['user', 'admin', 'superadmin'])
	})
})
