import { describe, expect, test } from 'bun:test'
import { getMediaUploadBucketAccess } from './media-upload-access'

describe('media upload bucket access', () => {
	test('requires an admin role for media library uploads', () => {
		expect(
			getMediaUploadBucketAccess({
				bucketParam: 'media',
				userRole: 'member',
				uploadRoute: 'multipart',
			}),
		).toMatchObject({ ok: false, status: 403 })
		expect(
			getMediaUploadBucketAccess({
				bucketParam: null,
				userRole: 'member',
				uploadRoute: 'raw',
			}),
		).toMatchObject({ ok: false, status: 403 })
		expect(
			getMediaUploadBucketAccess({
				bucketParam: 'media',
				userRole: 'admin',
				uploadRoute: 'raw',
			}),
		).toEqual({ ok: true, bucketParam: 'media' })
	})

	test('keeps avatar uploads available to active members', () => {
		expect(
			getMediaUploadBucketAccess({
				bucketParam: 'avatars',
				userRole: 'member',
				uploadRoute: 'multipart',
			}),
		).toEqual({ ok: true, bucketParam: 'avatars' })
	})

	test('allows chat uploads only through chunked sessions', () => {
		expect(
			getMediaUploadBucketAccess({
				bucketParam: 'chat',
				userRole: 'member',
				uploadRoute: 'chunked',
			}),
		).toEqual({ ok: true, bucketParam: 'chat' })
		expect(
			getMediaUploadBucketAccess({
				bucketParam: 'chat',
				userRole: 'member',
				uploadRoute: 'raw',
			}),
		).toMatchObject({ ok: false, status: 403 })
	})

	test('rejects unknown upload targets', () => {
		expect(
			getMediaUploadBucketAccess({
				bucketParam: 'unknown',
				userRole: 'admin',
				uploadRoute: 'multipart',
			}),
		).toMatchObject({ ok: false, status: 400 })
	})
})
