import { describe, expect, test } from 'bun:test'
import { percentChange } from './admin-stats-metrics'

describe('admin stats metrics', () => {
	test('calculates period growth without division by zero', () => {
		expect(percentChange(150, 100)).toBe(50)
		expect(percentChange(75, 100)).toBe(-25)
		expect(percentChange(10, 0)).toBe(100)
		expect(percentChange(0, 0)).toBe(0)
	})
})
