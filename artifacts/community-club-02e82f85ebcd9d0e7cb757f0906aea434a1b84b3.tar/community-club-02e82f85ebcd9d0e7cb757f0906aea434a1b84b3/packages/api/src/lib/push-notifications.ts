import { pushNotifications, pushSubscriptions } from '@community-club/shared'
import { eq, inArray } from 'drizzle-orm'
import webPush from 'web-push'
import { env } from '../config/env'
import { db } from '../db/client'
import { logger } from './logger'

let vapidInitialized = false

function ensureVapid() {
	if (!vapidInitialized && env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY) {
		webPush.setVapidDetails(env.VAPID_EMAIL, env.VAPID_PUBLIC_KEY, env.VAPID_PRIVATE_KEY)
		vapidInitialized = true
	}
	return vapidInitialized
}

function chunk<T>(items: T[], size: number) {
	const result: T[][] = []
	for (let index = 0; index < items.length; index += size) {
		result.push(items.slice(index, index + size))
	}
	return result
}

function isExpiredSubscriptionError(err: unknown) {
	const statusCode = (err as { statusCode?: number })?.statusCode
	return statusCode === 404 || statusCode === 410
}

async function createInboxNotifications(params: {
	userIds: string[]
	title: string
	body: string
	url?: string
	context: string
	payload: Record<string, unknown>
}) {
	const rows: Array<{ id: number; userAuthUuid: string }> = []
	for (const userIdBatch of chunk(params.userIds, 200)) {
		const inserted = await db
			.insert(pushNotifications)
			.values(
				userIdBatch.map((userId) => ({
					userAuthUuid: userId,
					title: params.title,
					body: params.body,
					url: params.url ?? null,
					context: params.context,
					payload: params.payload,
				})),
			)
			.returning({ id: pushNotifications.id, userAuthUuid: pushNotifications.userAuthUuid })
		rows.push(...inserted)
	}

	return new Map(rows.map((row) => [row.userAuthUuid, row.id]))
}

export async function sendPushToUsers(params: {
	userIds: string[]
	title: string
	body: string
	url?: string
	icon?: string
	badge?: string
	context?: string
	skipInbox?: boolean
}) {
	const context = params.context ?? 'generic'
	const uniqueUserIds = Array.from(new Set(params.userIds.filter(Boolean)))
	if (!uniqueUserIds.length) {
		logger.info({ title: params.title, context }, 'Push skipped: no target users')
		return { targetUsers: 0, subscriptions: 0, sent: 0, failed: 0 }
	}

	const basePayload = {
		title: params.title,
		body: params.body,
		url: params.url,
		icon: params.icon ?? '/icons/icon-192x192.png',
		badge: params.badge ?? '/icons/icon-192x192.png',
		context,
	}
	let notificationIds = new Map<string, number>()
	if (!params.skipInbox) {
		notificationIds = await createInboxNotifications({
			userIds: uniqueUserIds,
			title: params.title,
			body: params.body,
			url: params.url,
			context,
			payload: basePayload,
		})
	}

	if (!ensureVapid()) {
		logger.warn(
			{ title: params.title, targetUsers: uniqueUserIds.length, context },
			'Push skipped: VAPID is not configured',
		)
		return { targetUsers: uniqueUserIds.length, subscriptions: 0, sent: 0, failed: 0 }
	}

	const subscriptions = await db.query.pushSubscriptions.findMany({
		where: inArray(pushSubscriptions.userAuthUuid, uniqueUserIds),
	})

	if (!subscriptions.length) {
		logger.info(
			{ title: params.title, targetUsers: uniqueUserIds.length, context },
			'Push skipped: no subscriptions found',
		)
		return { targetUsers: uniqueUserIds.length, subscriptions: 0, sent: 0, failed: 0 }
	}

	let sent = 0
	let failed = 0
	const deliveredNotificationIds = new Set<number>()

	for (const subscriptionBatch of chunk(subscriptions, 25)) {
		const results = await Promise.allSettled(
			subscriptionBatch.map(async (sub) => {
				try {
					const notificationId = notificationIds.get(sub.userAuthUuid)
					const payload = JSON.stringify({
						...basePayload,
						notificationId,
					})
					await webPush.sendNotification(
						{
							endpoint: sub.endpoint,
							keys: { p256dh: sub.p256dh, auth: sub.auth },
						},
						payload,
					)
					await db
						.update(pushSubscriptions)
						.set({
							lastSuccessAt: new Date(),
							lastFailureAt: null,
							failureCount: 0,
							updatedAt: new Date(),
						})
						.where(eq(pushSubscriptions.id, sub.id))
					if (notificationId != null) deliveredNotificationIds.add(notificationId)
					return { ok: true as const, sub }
				} catch (err) {
					if (isExpiredSubscriptionError(err)) {
						await db.delete(pushSubscriptions).where(eq(pushSubscriptions.id, sub.id))
					} else {
						await db
							.update(pushSubscriptions)
							.set({
								lastFailureAt: new Date(),
								failureCount: (sub.failureCount ?? 0) + 1,
								updatedAt: new Date(),
							})
							.where(eq(pushSubscriptions.id, sub.id))
					}
					logger.warn({ err, subscriptionId: sub.id, context }, 'Failed to send push')
					return { ok: false as const, sub }
				}
			}),
		)

		for (const result of results) {
			if (result.status === 'fulfilled' && result.value.ok) {
				sent++
				continue
			}
			failed++
		}
	}

	if (deliveredNotificationIds.size > 0) {
		await db
			.update(pushNotifications)
			.set({ deliveredAt: new Date() })
			.where(inArray(pushNotifications.id, Array.from(deliveredNotificationIds)))
	}

	logger.info(
		{
			context,
			title: params.title,
			targetUsers: uniqueUserIds.length,
			subscriptions: subscriptions.length,
			sent,
			failed,
		},
		'Push delivery finished',
	)

	return {
		targetUsers: uniqueUserIds.length,
		subscriptions: subscriptions.length,
		sent,
		failed,
	}
}
