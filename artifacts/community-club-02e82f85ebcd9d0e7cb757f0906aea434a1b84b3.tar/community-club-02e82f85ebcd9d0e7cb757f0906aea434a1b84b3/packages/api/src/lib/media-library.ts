import { ListObjectsV2Command } from '@aws-sdk/client-s3'
import {
	mediaLibraryFolders,
	mediaLibraryNotes,
	mediaLibraryPreferences,
} from '@community-club/shared'
import type {
	AdminMediaLibraryFolder,
	AdminMediaLibraryItem,
	AdminMediaLibraryPreferenceScope,
	AdminMediaLibraryPreferencesPayload,
} from '@community-club/shared/types'
import { and, asc, eq, inArray, isNull, sql } from 'drizzle-orm'
import { env } from '../config/env'
import { db } from '../db/client'
import { getPublicUrl, s3 } from './storage'

const IMAGE_EXTENSIONS = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif', 'heic', 'heif'])
const VIDEO_EXTENSIONS = new Set(['mp4', 'mov', 'm4v', 'webm'])
const AUDIO_EXTENSIONS = new Set(['ogg', 'oga', 'mp3', 'm4a', 'aac', 'wav', 'flac', 'opus'])
const DOCUMENT_EXTENSIONS = new Set([
	'pdf',
	'doc',
	'docx',
	'xls',
	'xlsx',
	'ppt',
	'pptx',
	'txt',
	'rtf',
	'zip',
	'rar',
	'7z',
])

type AdminMediaType = AdminMediaLibraryItem['type']
type AdminMediaFilter = AdminMediaType | 'all'
type AdminMediaSortBy = AdminMediaLibraryPreferencesPayload['sortBy']
type AdminMediaSortDir = AdminMediaLibraryPreferencesPayload['sortDir']
type AdminMediaPreferenceScope = AdminMediaLibraryPreferenceScope

export class MediaLibraryStorageUnavailableError extends Error {
	readonly cause: unknown

	constructor(cause: unknown) {
		super('Media library storage is unavailable')
		this.name = 'MediaLibraryStorageUnavailableError'
		this.cause = cause
	}
}

export function isMediaLibraryStorageUnavailableError(
	error: unknown,
): error is MediaLibraryStorageUnavailableError {
	return error instanceof MediaLibraryStorageUnavailableError
}

async function listMediaBucket(command: ListObjectsV2Command) {
	try {
		return await s3.send(command)
	} catch (error) {
		throw new MediaLibraryStorageUnavailableError(error)
	}
}

function inferMediaTypeFromKey(key: string): AdminMediaType | null {
	const extension = key.split('.').pop()?.trim().toLowerCase()
	if (!extension) return null
	if (IMAGE_EXTENSIONS.has(extension)) return 'image'
	if (VIDEO_EXTENSIONS.has(extension)) return 'video'
	if (AUDIO_EXTENSIONS.has(extension)) return 'audio'
	if (DOCUMENT_EXTENSIONS.has(extension)) return 'document'
	return null
}

function decodeObjectName(key: string) {
	const raw = key.split('/').pop() || key
	try {
		return decodeURIComponent(raw)
	} catch {
		return raw
	}
}

function decodeOffsetCursor(cursor: string | undefined): number {
	if (!cursor) return 0
	try {
		const parsed = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8')) as {
			offset?: number
		}
		return typeof parsed.offset === 'number' && parsed.offset > 0 ? parsed.offset : 0
	} catch {
		return 0
	}
}

function encodeOffsetCursor(offset: number): string {
	return Buffer.from(JSON.stringify({ offset }), 'utf8').toString('base64url')
}

function buildDefaultAudioTitle(index: number): string {
	return `Аудио ${index}`
}

function getDefaultMediaLibraryPreferences(): AdminMediaLibraryPreferencesPayload {
	return {
		viewMode: 'cards',
		sortBy: 'updatedAt',
		sortDir: 'desc',
		typeFilter: 'all',
		searchQuery: '',
		folderId: null,
	}
}

function normalizeFolderName(value: string) {
	return value.trim().replace(/\s+/g, ' ')
}

function sortMediaItems(
	items: AdminMediaLibraryItem[],
	sortBy: AdminMediaSortBy,
	sortDir: AdminMediaSortDir,
) {
	const direction = sortDir === 'asc' ? 1 : -1
	return [...items].sort((left, right) => {
		if (sortBy === 'updatedAt') {
			const leftTime = left.lastModified ? new Date(left.lastModified).getTime() : 0
			const rightTime = right.lastModified ? new Date(right.lastModified).getTime() : 0
			return (leftTime - rightTime) * direction
		}

		if (sortBy === 'size') {
			return ((left.size ?? 0) - (right.size ?? 0)) * direction
		}

		if (sortBy === 'type') {
			return (
				left.type.localeCompare(right.type, 'ru', {
					sensitivity: 'base',
					numeric: true,
				}) * direction
			)
		}

		return (
			left.title.localeCompare(right.title, 'ru', {
				sensitivity: 'base',
				numeric: true,
			}) * direction
		)
	})
}

export async function loadAdminMediaLibraryPage(params: {
	cursor?: string
	limit: number
	type?: AdminMediaFilter
	search?: string
	folderId?: number | null
	sortBy?: AdminMediaSortBy
	sortDir?: AdminMediaSortDir
}) {
	const limit = Math.min(Math.max(params.limit, 1), 60)
	const allItems: AdminMediaLibraryItem[] = []
	let continuationToken = undefined as string | undefined

	do {
		const response = await listMediaBucket(
			new ListObjectsV2Command({
				Bucket: env.S3_BUCKET_MEDIA,
				MaxKeys: 1000,
				ContinuationToken: continuationToken,
			}),
		)

		for (const object of response.Contents ?? []) {
			const key = object.Key?.trim()
			if (!key) continue

			const type = inferMediaTypeFromKey(key)
			if (!type) continue
			if (params.type && params.type !== 'all' && type !== params.type) continue

			allItems.push({
				key,
				name: decodeObjectName(key),
				url: getPublicUrl(env.S3_BUCKET_MEDIA, key),
				type,
				size: typeof object.Size === 'number' ? object.Size : null,
				lastModified: object.LastModified?.toISOString?.() ?? null,
				note: null,
				title: decodeObjectName(key),
				folderId: null,
			})
		}

		continuationToken = response.IsTruncated
			? (response.NextContinuationToken ?? undefined)
			: undefined
	} while (continuationToken)

	const keys = allItems.map((item) => item.key)
	const notes =
		keys.length > 0
			? await db.query.mediaLibraryNotes.findMany({
					where: inArray(mediaLibraryNotes.key, keys),
					columns: { key: true, title: true, note: true, folderId: true },
				})
			: []
	const noteMap = new Map(notes.map((item) => [item.key, item]))
	const defaultAudioTitles = new Map(
		allItems
			.filter((item) => item.type === 'audio')
			.map((item, index) => [item.key, buildDefaultAudioTitle(index + 1)]),
	)
	const normalizedSearch = params.search?.trim().toLowerCase() ?? ''

	const enrichedItems = allItems.map((item) => ({
		...item,
		title:
			noteMap.get(item.key)?.title?.trim() ||
			(item.type === 'audio' ? defaultAudioTitles.get(item.key) : item.name) ||
			item.name,
		note: noteMap.get(item.key)?.note ?? null,
		folderId: noteMap.get(item.key)?.folderId ?? null,
	}))

	const filteredByFolder = enrichedItems.filter((item) =>
		params.folderId == null ? item.folderId == null : item.folderId === params.folderId,
	)
	const filteredBySearch = normalizedSearch
		? filteredByFolder.filter((item) => {
				const title = item.title?.toLowerCase() ?? ''
				const note = item.note?.toLowerCase() ?? ''
				const name = item.name.toLowerCase()
				return (
					title.includes(normalizedSearch) ||
					note.includes(normalizedSearch) ||
					name.includes(normalizedSearch)
				)
			})
		: filteredByFolder

	const sortedItems = sortMediaItems(
		filteredBySearch,
		params.sortBy ?? 'updatedAt',
		params.sortDir ?? 'desc',
	)
	const offset = decodeOffsetCursor(params.cursor)
	const pagedItems = sortedItems.slice(offset, offset + limit)
	const nextCursor = offset + limit < sortedItems.length ? encodeOffsetCursor(offset + limit) : null

	return {
		items: pagedItems,
		nextCursor,
	}
}

export async function findAdminMediaLibraryItemByKey(
	key: string,
): Promise<AdminMediaLibraryItem | null> {
	const normalizedKey = key.trim()
	if (!normalizedKey) return null

	const response = await listMediaBucket(
		new ListObjectsV2Command({
			Bucket: env.S3_BUCKET_MEDIA,
			Prefix: normalizedKey,
			MaxKeys: 1,
		}),
	)
	const object = response.Contents?.find((item) => item.Key === normalizedKey)
	if (!object) return null

	const type = inferMediaTypeFromKey(normalizedKey)
	if (!type) return null

	const note = await db.query.mediaLibraryNotes.findFirst({
		where: eq(mediaLibraryNotes.key, normalizedKey),
		columns: { title: true, note: true, folderId: true },
	})
	const name = decodeObjectName(normalizedKey)

	return {
		key: normalizedKey,
		name,
		url: getPublicUrl(env.S3_BUCKET_MEDIA, normalizedKey),
		type,
		size: typeof object.Size === 'number' ? object.Size : null,
		lastModified: object.LastModified?.toISOString?.() ?? null,
		note: note?.note ?? null,
		title: note?.title?.trim() || name,
		folderId: note?.folderId ?? null,
	}
}

export async function upsertMediaLibraryNote(params: {
	key: string
	title: string
	note: string
	userId: string
}) {
	const existing = await db.query.mediaLibraryNotes.findFirst({
		where: eq(mediaLibraryNotes.key, params.key),
		columns: { key: true, folderId: true },
	})

	if (existing) {
		const [updated] = await db
			.update(mediaLibraryNotes)
			.set({
				title: params.title,
				note: params.note,
				updatedByAuthUuid: params.userId,
				updatedAt: new Date(),
			})
			.where(eq(mediaLibraryNotes.key, params.key))
			.returning()
		return updated
	}

	const [created] = await db
		.insert(mediaLibraryNotes)
		.values({
			key: params.key,
			title: params.title,
			note: params.note,
			createdByAuthUuid: params.userId,
			updatedByAuthUuid: params.userId,
		})
		.returning()

	return created
}

export async function loadMediaLibraryFolders(): Promise<AdminMediaLibraryFolder[]> {
	const folders = await db.query.mediaLibraryFolders.findMany({
		orderBy: [asc(mediaLibraryFolders.name)],
	})

	const counts = await db
		.select({
			folderId: mediaLibraryNotes.folderId,
			itemsCount: sql<number>`count(*)::int`,
		})
		.from(mediaLibraryNotes)
		.where(sql`${mediaLibraryNotes.folderId} IS NOT NULL`)
		.groupBy(mediaLibraryNotes.folderId)

	const countsMap = new Map(counts.map((item) => [item.folderId, item.itemsCount]))

	return folders.map((folder) => ({
		id: folder.id,
		name: folder.name,
		itemsCount: countsMap.get(folder.id) ?? 0,
		createdAt: folder.createdAt,
	}))
}

export async function createMediaLibraryFolder(params: { name: string; userId: string }) {
	const normalizedName = normalizeFolderName(params.name)
	const existing = await db.query.mediaLibraryFolders.findFirst({
		where: sql`lower(${mediaLibraryFolders.name}) = lower(${normalizedName})`,
		columns: { id: true, name: true, createdAt: true },
	})
	if (existing) {
		return {
			id: existing.id,
			name: existing.name,
			itemsCount: 0,
			createdAt: existing.createdAt,
		} satisfies AdminMediaLibraryFolder
	}

	const [created] = await db
		.insert(mediaLibraryFolders)
		.values({
			name: normalizedName,
			createdByAuthUuid: params.userId,
		})
		.returning()

	return {
		id: created.id,
		name: created.name,
		itemsCount: 0,
		createdAt: created.createdAt,
	} satisfies AdminMediaLibraryFolder
}

export async function deleteMediaLibraryFolder(folderId: number) {
	await db
		.update(mediaLibraryNotes)
		.set({ folderId: null })
		.where(eq(mediaLibraryNotes.folderId, folderId))
	const [deleted] = await db
		.delete(mediaLibraryFolders)
		.where(eq(mediaLibraryFolders.id, folderId))
		.returning({ id: mediaLibraryFolders.id, name: mediaLibraryFolders.name })
	return deleted ?? null
}

export async function moveMediaLibraryItem(params: {
	key: string
	folderId: number | null
	userId: string
}) {
	const existing = await db.query.mediaLibraryNotes.findFirst({
		where: eq(mediaLibraryNotes.key, params.key),
		columns: { key: true },
	})

	if (existing) {
		const [updated] = await db
			.update(mediaLibraryNotes)
			.set({
				folderId: params.folderId,
				updatedByAuthUuid: params.userId,
				updatedAt: new Date(),
			})
			.where(eq(mediaLibraryNotes.key, params.key))
			.returning()
		return updated
	}

	const [created] = await db
		.insert(mediaLibraryNotes)
		.values({
			key: params.key,
			title: '',
			note: '',
			folderId: params.folderId,
			createdByAuthUuid: params.userId,
			updatedByAuthUuid: params.userId,
		})
		.returning()

	return created
}

export async function loadMediaLibraryPreferences(
	userId: string,
	scope: AdminMediaPreferenceScope = 'library',
) {
	const existing = await db.query.mediaLibraryPreferences.findFirst({
		where: eq(mediaLibraryPreferences.authUuid, userId),
		columns: {
			viewMode: true,
			sortBy: true,
			sortDir: true,
			typeFilter: true,
			searchQuery: true,
			folderId: true,
			pickerViewMode: true,
			pickerSortBy: true,
			pickerSortDir: true,
			pickerTypeFilter: true,
			pickerSearchQuery: true,
		},
	})

	if (!existing) {
		return getDefaultMediaLibraryPreferences()
	}

	if (scope === 'materialPicker') {
		return {
			viewMode: existing.pickerViewMode,
			sortBy: existing.pickerSortBy,
			sortDir: existing.pickerSortDir,
			typeFilter: existing.pickerTypeFilter,
			searchQuery: existing.pickerSearchQuery,
			folderId: null,
		} satisfies AdminMediaLibraryPreferencesPayload
	}

	return {
		viewMode: existing.viewMode,
		sortBy: existing.sortBy,
		sortDir: existing.sortDir,
		typeFilter: existing.typeFilter,
		searchQuery: existing.searchQuery,
		folderId: existing.folderId,
	} satisfies AdminMediaLibraryPreferencesPayload
}

export async function saveMediaLibraryPreferences(
	userId: string,
	payload: AdminMediaLibraryPreferencesPayload,
	scope: AdminMediaPreferenceScope = 'library',
) {
	const updatedAt = new Date()
	const normalizedSearch = payload.searchQuery.trim().slice(0, 200)
	const values =
		scope === 'materialPicker'
			? {
					authUuid: userId,
					pickerViewMode: payload.viewMode,
					pickerSortBy: payload.sortBy,
					pickerSortDir: payload.sortDir,
					pickerTypeFilter: payload.typeFilter,
					pickerSearchQuery: normalizedSearch,
					updatedAt,
				}
			: {
					authUuid: userId,
					viewMode: payload.viewMode,
					sortBy: payload.sortBy,
					sortDir: payload.sortDir,
					typeFilter: payload.typeFilter,
					searchQuery: normalizedSearch,
					folderId: payload.folderId,
					updatedAt,
				}

	const existing = await db.query.mediaLibraryPreferences.findFirst({
		where: eq(mediaLibraryPreferences.authUuid, userId),
		columns: { authUuid: true },
	})

	if (existing) {
		await db
			.update(mediaLibraryPreferences)
			.set(values)
			.where(eq(mediaLibraryPreferences.authUuid, userId))
		return values
	}

	await db.insert(mediaLibraryPreferences).values(values)
	return values
}

export async function clearMediaLibraryFolderPreference(folderId: number) {
	await db
		.update(mediaLibraryPreferences)
		.set({ folderId: null, updatedAt: new Date() })
		.where(eq(mediaLibraryPreferences.folderId, folderId))
}

export async function clearMediaLibraryItem(key: string) {
	await db.delete(mediaLibraryNotes).where(eq(mediaLibraryNotes.key, key))
}

export async function findMediaLibraryFolderById(folderId: number) {
	return db.query.mediaLibraryFolders.findFirst({
		where: eq(mediaLibraryFolders.id, folderId),
		columns: { id: true, name: true },
	})
}

export async function findMediaLibraryFolderByName(name: string) {
	const normalizedName = normalizeFolderName(name)
	return db.query.mediaLibraryFolders.findFirst({
		where: sql`lower(${mediaLibraryFolders.name}) = lower(${normalizedName})`,
		columns: { id: true, name: true },
	})
}

export async function mediaLibraryFolderExists(folderId: number | null | undefined) {
	if (folderId == null) return true
	const folder = await db.query.mediaLibraryFolders.findFirst({
		where: eq(mediaLibraryFolders.id, folderId),
		columns: { id: true },
	})
	return Boolean(folder)
}
