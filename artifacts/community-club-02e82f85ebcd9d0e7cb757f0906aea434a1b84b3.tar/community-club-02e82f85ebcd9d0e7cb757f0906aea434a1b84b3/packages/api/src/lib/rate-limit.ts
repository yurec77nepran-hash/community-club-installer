import { redis } from './redis'

export async function checkRedisRateLimit(params: {
	namespace: string
	key: string
	windowSeconds: number
	limit: number
}) {
	const redisKey = `ratelimit:${params.namespace}:${params.key}`
	const current = await redis.incr(redisKey)

	if (current === 1) {
		await redis.expire(redisKey, params.windowSeconds)
	}

	return current <= params.limit
}
