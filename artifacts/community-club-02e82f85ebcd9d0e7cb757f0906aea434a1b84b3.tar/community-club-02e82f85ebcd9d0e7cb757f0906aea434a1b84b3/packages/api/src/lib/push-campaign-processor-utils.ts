export function getBillingTargetDateForOffset(scheduledFor: string, offsetDays: number) {
	const targetDate = new Date(`${scheduledFor}T00:00:00+03:00`)
	targetDate.setDate(targetDate.getDate() + offsetDays)

	return new Intl.DateTimeFormat('en-CA', {
		timeZone: 'Europe/Moscow',
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
	}).format(targetDate)
}
