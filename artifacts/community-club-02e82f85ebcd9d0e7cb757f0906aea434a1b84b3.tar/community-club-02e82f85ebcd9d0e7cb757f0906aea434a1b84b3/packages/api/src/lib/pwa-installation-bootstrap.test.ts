import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const migrationUrl = new URL('../../sql/20260909_add_pwa_installations.sql', import.meta.url)

function normalizeSql(sql: string) {
	return sql.replace(/\s+/g, ' ').trim().replace(/;$/, '')
}

describe('PWA installation bootstrap', () => {
	test('matches the focused idempotent migration SQL', async () => {
		// Given
		Bun.env.DATABASE_URL = 'postgres://unused:unused@127.0.0.1:1/unused'
		Bun.env.JWT_SECRET = '01234567890123456789012345678901'
		const { PWA_INSTALLATIONS_DDL } = await import('./pwa-installation-bootstrap')
		const migrationSql = await readFile(migrationUrl, 'utf8')

		// When
		const bootstrapSql = normalizeSql(PWA_INSTALLATIONS_DDL)

		// Then
		expect(bootstrapSql).toBe(normalizeSql(migrationSql))
		expect(bootstrapSql).toContain('CREATE TABLE IF NOT EXISTS pwa_installations')
		expect(bootstrapSql).toContain('REFERENCES users(auth_uuid) ON DELETE CASCADE')
		expect(bootstrapSql).toContain('CHECK (launch_count > 0)')
		expect(bootstrapSql.match(/CREATE TABLE/gi)).toHaveLength(1)
	})
})
