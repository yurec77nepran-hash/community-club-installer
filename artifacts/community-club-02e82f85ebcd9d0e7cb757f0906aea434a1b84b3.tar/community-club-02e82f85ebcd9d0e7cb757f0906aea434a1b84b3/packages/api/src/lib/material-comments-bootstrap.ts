import { queryClient } from '../db/client'

const materialCommentsBootstrapQueries = [
	`DO $$
BEGIN
	IF NOT EXISTS (
		SELECT 1
		FROM information_schema.columns
		WHERE table_name = 'materials' AND column_name = 'comments_enabled'
	) THEN
		ALTER TABLE materials ADD COLUMN comments_enabled boolean NOT NULL DEFAULT false;
		UPDATE materials
		SET comments_enabled = true
		WHERE type IN ('streams', 'podcasts', 'movies', 'books', 'courses');
	END IF;
END $$;`,
	`CREATE TABLE IF NOT EXISTS material_comments (
		id serial PRIMARY KEY,
		material_id integer NOT NULL REFERENCES materials(id) ON DELETE CASCADE,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		parent_comment_id integer REFERENCES material_comments(id) ON DELETE CASCADE,
		content text NOT NULL,
		is_deleted boolean NOT NULL DEFAULT false,
		created_at timestamptz NOT NULL DEFAULT now(),
		updated_at timestamptz NOT NULL DEFAULT now()
	)`,
	`CREATE TABLE IF NOT EXISTS material_comment_reactions (
		id serial PRIMARY KEY,
		comment_id integer NOT NULL REFERENCES material_comments(id) ON DELETE CASCADE,
		user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
		emoji text NOT NULL,
		created_at timestamptz NOT NULL DEFAULT now()
	)`,
	'CREATE INDEX IF NOT EXISTS material_comments_material_created_idx ON material_comments (material_id, created_at, id)',
	'CREATE INDEX IF NOT EXISTS material_comments_parent_idx ON material_comments (parent_comment_id)',
	'CREATE INDEX IF NOT EXISTS material_comments_user_idx ON material_comments (user_auth_uuid, created_at)',
	'CREATE UNIQUE INDEX IF NOT EXISTS material_comment_reaction_unique ON material_comment_reactions (comment_id, user_auth_uuid, emoji)',
	'CREATE INDEX IF NOT EXISTS material_comment_reactions_comment_idx ON material_comment_reactions (comment_id)',
	'CREATE INDEX IF NOT EXISTS material_comment_reactions_user_idx ON material_comment_reactions (user_auth_uuid, created_at)',
]

export async function ensureMaterialCommentsArtifacts() {
	for (const query of materialCommentsBootstrapQueries) {
		await queryClient.unsafe(query)
	}
}
