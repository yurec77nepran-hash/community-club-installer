import { describe, expect, test } from 'bun:test'
import { isSuccessfulExternalPaymentStatus } from './payment-status'

describe('external payment status guard', () => {
	test('accepts only explicit successful Prodamus statuses', () => {
		expect(isSuccessfulExternalPaymentStatus('prodamus', { status: 'success' })).toBe(true)
		expect(isSuccessfulExternalPaymentStatus('prodamus', { status: 'paid' })).toBe(true)
		expect(isSuccessfulExternalPaymentStatus('prodamus', { status: '' })).toBe(false)
		expect(isSuccessfulExternalPaymentStatus('prodamus', { status: 'failed' })).toBe(false)
	})

	test('accepts verified YooKassa success signals', () => {
		expect(isSuccessfulExternalPaymentStatus('yookassa', { event: 'payment.succeeded' })).toBe(true)
		expect(isSuccessfulExternalPaymentStatus('yookassa', { status: 'succeeded' })).toBe(true)
		expect(isSuccessfulExternalPaymentStatus('yookassa', { paid: true })).toBe(true)
		expect(isSuccessfulExternalPaymentStatus('yookassa', { status: 'pending' })).toBe(false)
	})

	test('accepts Tochka approved operation status', () => {
		expect(isSuccessfulExternalPaymentStatus('tochka', { status: 'APPROVED' })).toBe(true)
		expect(isSuccessfulExternalPaymentStatus('tochka', { status: 'CREATED' })).toBe(false)
	})
})
