import { expect, test } from 'bun:test'
import { sanitizeTelegramBroadcastHtml, telegramBroadcastPlainText } from '@community-club/shared'

test('keeps Telegram formatting while dropping unsupported pasted HTML', () => {
	const html = sanitizeTelegramBroadcastHtml(
		'<div><b>Привет</b> <img src=x> <a href="https://clud.nepran-yuri.ru">клуб</a></div>',
	)
	expect(html).toBe('<b>Привет</b>  <a href="https://clud.nepran-yuri.ru">клуб</a>')
	expect(telegramBroadcastPlainText(html)).toBe('Привет  клуб')
})
