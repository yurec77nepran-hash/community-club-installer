import { messengerConnections } from '@community-club/shared'
import { sql } from 'drizzle-orm'
import { db } from '../db/client'
import { encryptSecret } from './secret-vault'
import { getTelegramBroadcastBots } from './telegram-broadcast-bots'

async function syncTelegramConnections() {
	for (const bot of getTelegramBroadcastBots()) {
		await db
			.insert(messengerConnections)
			.values({
				provider: 'telegram',
				externalId: bot.username,
				label: bot.label,
				encryptedToken: encryptSecret(bot.token),
				config: { username: bot.username },
			})
			.onConflictDoUpdate({
				target: [messengerConnections.provider, messengerConnections.externalId],
				set: {
					label: bot.label,
					encryptedToken: encryptSecret(bot.token),
					config: { username: bot.username },
					updatedAt: new Date(),
				},
			})
	}

	await db.execute(sql`
		INSERT INTO messenger_contacts (
			connection_id, user_auth_uuid, external_user_id, display_name, username, consent_status, profile, last_seen_at
		)
		SELECT
			connection.id,
			contact.user_auth_uuid,
			contact.telegram_user_id,
			null,
			contact.telegram_username,
			'active',
			jsonb_build_object('source', 'telegram_import', 'botUsername', contact.bot_username),
			contact.source_created_at
		FROM telegram_contacts contact
		JOIN messenger_connections connection
			ON connection.provider = 'telegram' AND connection.external_id = contact.bot_username
		ON CONFLICT (connection_id, external_user_id) DO UPDATE
		SET username = coalesce(excluded.username, messenger_contacts.username),
			updated_at = now()
	`)
}

export async function ensureMessengerBroadcastArtifacts() {
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS messenger_connections (
			id serial PRIMARY KEY,
			provider text NOT NULL,
			external_id text NOT NULL,
			label text NOT NULL,
			encrypted_token text NOT NULL,
			config jsonb NOT NULL DEFAULT '{}'::jsonb,
			webhook_secret text,
			is_active integer NOT NULL DEFAULT 1,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE UNIQUE INDEX IF NOT EXISTS messenger_connections_provider_external_unique
		ON messenger_connections (provider, external_id)
	`)
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS messenger_contacts (
			id serial PRIMARY KEY,
			connection_id integer NOT NULL REFERENCES messenger_connections(id) ON DELETE CASCADE,
			user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
			external_user_id text NOT NULL,
			display_name text,
			username text,
			consent_status text NOT NULL DEFAULT 'active',
			profile jsonb NOT NULL DEFAULT '{}'::jsonb,
			last_seen_at timestamptz,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE UNIQUE INDEX IF NOT EXISTS messenger_contacts_connection_user_unique
		ON messenger_contacts (connection_id, external_user_id)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS messenger_contacts_user_idx ON messenger_contacts (user_auth_uuid)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS messenger_contacts_active_idx
		ON messenger_contacts (connection_id, consent_status)
	`)
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS messenger_broadcasts (
			id serial PRIMARY KEY,
			name text NOT NULL,
			connection_ids integer[] NOT NULL,
			body text NOT NULL,
			status text NOT NULL DEFAULT 'scheduled',
			send_at timestamptz NOT NULL,
			processing_started_at timestamptz,
			audience_size integer NOT NULL DEFAULT 0,
			sent_count integer NOT NULL DEFAULT 0,
			failed_count integer NOT NULL DEFAULT 0,
			last_error text,
			created_by_auth_uuid uuid REFERENCES users(auth_uuid) ON DELETE SET NULL,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS messenger_broadcasts_status_send_at_idx
		ON messenger_broadcasts (status, send_at)
	`)
	await db.execute(sql`
		CREATE TABLE IF NOT EXISTS messenger_broadcast_deliveries (
			id serial PRIMARY KEY,
			broadcast_id integer NOT NULL REFERENCES messenger_broadcasts(id) ON DELETE CASCADE,
			contact_id integer NOT NULL REFERENCES messenger_contacts(id) ON DELETE CASCADE,
			status text NOT NULL DEFAULT 'pending',
			error_message text,
			sent_at timestamptz,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`)
	await db.execute(sql`
		CREATE UNIQUE INDEX IF NOT EXISTS messenger_broadcast_deliveries_unique
		ON messenger_broadcast_deliveries (broadcast_id, contact_id)
	`)
	await db.execute(sql`
		CREATE INDEX IF NOT EXISTS messenger_broadcast_deliveries_status_idx
		ON messenger_broadcast_deliveries (broadcast_id, status)
	`)
	await syncTelegramConnections()
}
