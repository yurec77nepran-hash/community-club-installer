import { describe, expect, test } from 'bun:test'
import { buildSupportTelegramNotificationPayload } from './support-telegram-notification-payload'

describe('buildSupportTelegramNotificationPayload', () => {
	test('builds an escaped text notification with an admin dialog button', () => {
		const payload = buildSupportTelegramNotificationPayload({
			authorName: 'Мария <Иванова>',
			authorEmail: 'maria@example.com',
			content: 'Здравствуйте, нужна помощь <с оплатой>',
			messageType: 'text',
			adminDialogUrl: 'https://example.com/admin/support?chatId=12&messageId=44',
		})

		expect(payload).toEqual({
			text:
				'<b>Новое сообщение в поддержку</b>\n\n' +
				'<b>От:</b> Мария &lt;Иванова&gt;\n' +
				'<b>Email:</b> maria@example.com\n\n' +
				'<b>Сообщение:</b>\nЗдравствуйте, нужна помощь &lt;с оплатой&gt;',
			replyMarkup: {
				inline_keyboard: [
					[
						{
							text: 'Открыть диалог',
							url: 'https://example.com/admin/support?chatId=12&messageId=44',
						},
					],
				],
			},
		})
	})

	test('uses attachment text for media messages', () => {
		const payload = buildSupportTelegramNotificationPayload({
			authorName: 'Ольга',
			authorEmail: null,
			content: 'подпись к файлу',
			messageType: 'image',
			adminDialogUrl: 'https://example.com/admin/support?chatId=15&messageId=51',
		})

		expect(payload.text).toContain('<b>Сообщение:</b>\nЕсть вложение')
		expect(payload.text).not.toContain('подпись к файлу')
	})
})
