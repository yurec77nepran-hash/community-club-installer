import { payments } from '@community-club/shared'
import { and, desc, eq, gte, or } from 'drizzle-orm'
import { db } from '../db/client'

export function getMoscowDateString(date = new Date()) {
	return new Intl.DateTimeFormat('en-CA', {
		timeZone: 'Europe/Moscow',
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
	}).format(date)
}

export function normalizeDateFinish(value: string | Date | null | undefined) {
	if (!value) return null
	const dateOnly =
		value instanceof Date ? value.toISOString().slice(0, 10) : String(value).slice(0, 10)
	if (!/^\d{4}-\d{2}-\d{2}$/.test(dateOnly)) return null
	return dateOnly
}

export function hasActiveDateFinish(
	value: string | Date | null | undefined,
	today = getMoscowDateString(),
) {
	const dateFinish = normalizeDateFinish(value)
	return Boolean(dateFinish && dateFinish >= today)
}

export async function findLatestPaymentForAccess(params: {
	userAuthUuid: string
	email: string | null
	activeOnly?: boolean
}) {
	const identityFilter = params.email
		? or(eq(payments.userAuthUuid, params.userAuthUuid), eq(payments.email, params.email))
		: eq(payments.userAuthUuid, params.userAuthUuid)
	const where = params.activeOnly
		? and(identityFilter, gte(payments.dateFinish, getMoscowDateString()))
		: identityFilter

	return db.query.payments.findFirst({
		where,
		orderBy: [desc(payments.dateFinish), desc(payments.updatedAt), desc(payments.createdAt)],
	})
}
