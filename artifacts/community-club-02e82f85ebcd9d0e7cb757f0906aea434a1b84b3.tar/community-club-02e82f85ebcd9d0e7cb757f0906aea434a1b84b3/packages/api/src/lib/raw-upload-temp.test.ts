import { describe, expect, test } from 'bun:test'
import { readFile, unlink } from 'node:fs/promises'
import { UploadBodyTooLargeError, writeUploadBodyToTempFile } from './raw-upload-temp'

function createBody(chunks: Uint8Array[]) {
	return new ReadableStream<Uint8Array>({
		start(controller) {
			for (const chunk of chunks) {
				controller.enqueue(chunk)
			}
			controller.close()
		},
	})
}

describe('writeUploadBodyToTempFile', () => {
	test('writes a web stream to a temp file and reports size', async () => {
		const first = new TextEncoder().encode('hello ')
		const second = new TextEncoder().encode('world')
		const result = await writeUploadBodyToTempFile({
			body: createBody([first, second]),
			maxBytes: 1024,
		})

		try {
			expect(result.size).toBe(11)
			expect(await readFile(result.path, 'utf8')).toBe('hello world')
		} finally {
			await unlink(result.path).catch(() => undefined)
		}
	})

	test('rejects body that exceeds limit', async () => {
		await expect(
			writeUploadBodyToTempFile({
				body: createBody([new Uint8Array(4), new Uint8Array(4)]),
				maxBytes: 7,
			}),
		).rejects.toBeInstanceOf(UploadBodyTooLargeError)
	})
})
