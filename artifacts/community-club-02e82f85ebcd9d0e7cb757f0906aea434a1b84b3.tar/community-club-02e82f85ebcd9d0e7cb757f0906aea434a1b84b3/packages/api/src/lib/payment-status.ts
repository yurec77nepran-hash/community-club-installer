type ExternalPaymentProvider = 'prodamus' | 'yookassa' | 'tochka'

const successfulExternalStatuses = new Set([
	'success',
	'paid',
	'completed',
	'approved',
	'succeeded',
])

export function isSuccessfulExternalPaymentStatus(
	provider: ExternalPaymentProvider,
	params: { event?: string | null; status?: string | null; paid?: string | boolean | null },
) {
	const event = String(params.event ?? '')
		.trim()
		.toLowerCase()
	const status = String(params.status ?? '')
		.trim()
		.toLowerCase()
	const paid =
		typeof params.paid === 'boolean'
			? params.paid
			: String(params.paid ?? '')
					.trim()
					.toLowerCase() === 'true'

	if (provider === 'yookassa') {
		return event === 'payment.succeeded' || status === 'succeeded' || paid
	}

	return successfulExternalStatuses.has(status)
}
