import { scheduledChatMessages } from '@community-club/shared'
import { and, asc, eq, lte, or } from 'drizzle-orm'
import { db } from '../db/client'
import { broadcastChatRoomEvent } from '../ws/handler'
import { deliverChatMessage } from './chat-delivery'
import { logger } from './logger'
import { resolveScheduledMessageDate } from './scheduled-chat-message-utils'

const PROCESSOR_INTERVAL_MS = 15_000
const CLAIM_STALE_MS = 2 * 60_000
const BATCH_SIZE = 20

let started = false
let tickRunning = false

async function claimDueScheduledMessages() {
	const staleThreshold = new Date(Date.now() - CLAIM_STALE_MS)
	const candidates = await db.query.scheduledChatMessages.findMany({
		where: and(
			or(
				eq(scheduledChatMessages.status, 'scheduled'),
				and(
					eq(scheduledChatMessages.status, 'processing'),
					lte(scheduledChatMessages.processingStartedAt, staleThreshold),
				),
			),
			lte(scheduledChatMessages.scheduledAt, new Date()),
		),
		orderBy: [asc(scheduledChatMessages.scheduledAt), asc(scheduledChatMessages.id)],
		limit: BATCH_SIZE,
	})

	const claimed = [] as typeof candidates
	for (const item of candidates) {
		const [updated] = await db
			.update(scheduledChatMessages)
			.set({
				status: 'processing',
				processingStartedAt: new Date(),
				errorMessage: null,
				updatedAt: new Date(),
			})
			.where(
				and(
					eq(scheduledChatMessages.id, item.id),
					or(
						eq(scheduledChatMessages.status, 'scheduled'),
						and(
							eq(scheduledChatMessages.status, 'processing'),
							lte(scheduledChatMessages.processingStartedAt, staleThreshold),
						),
					),
				),
			)
			.returning()

		if (updated) {
			claimed.push(updated)
		}
	}

	return claimed
}

async function processScheduledMessage(item: typeof scheduledChatMessages.$inferSelect) {
	const delivery = await deliverChatMessage({
		chatId: item.chatId,
		userId: item.authorAuthUuid,
		userRole: 'admin',
		content: item.content,
		messageType: 'text',
		mentions: item.mentions ?? [],
	})

	if (!delivery.ok) {
		await db
			.update(scheduledChatMessages)
			.set({
				status: 'failed',
				errorMessage: delivery.message,
				processingStartedAt: null,
				updatedAt: new Date(),
			})
			.where(eq(scheduledChatMessages.id, item.id))
		return
	}

	await db
		.update(scheduledChatMessages)
		.set({
			status: 'sent',
			errorMessage: null,
			sentMessageId: delivery.message.id,
			processingStartedAt: null,
			updatedAt: new Date(),
		})
		.where(eq(scheduledChatMessages.id, item.id))

	await broadcastChatRoomEvent(item.chatId, {
		type: 'new_message',
		message: delivery.message,
	})
}

async function tick() {
	if (tickRunning) return
	tickRunning = true

	try {
		const claimed = await claimDueScheduledMessages()
		for (const item of claimed) {
			try {
				await processScheduledMessage(item)
			} catch (error) {
				await db
					.update(scheduledChatMessages)
					.set({
						status: 'failed',
						errorMessage:
							error instanceof Error ? error.message : 'Не удалось отправить отложенное сообщение',
						processingStartedAt: null,
						updatedAt: new Date(),
					})
					.where(eq(scheduledChatMessages.id, item.id))
				logger.error(
					{ err: error, scheduledMessageId: item.id },
					'Failed to process scheduled chat message',
				)
			}
		}
	} finally {
		tickRunning = false
	}
}

export function startScheduledChatMessageProcessor() {
	if (started) return
	started = true

	void tick()
	setInterval(() => {
		void tick()
	}, PROCESSOR_INTERVAL_MS)

	logger.info('Scheduled chat message processor started')
}
