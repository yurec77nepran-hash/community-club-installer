import { logger } from './logger'
import { redis } from './redis'

type CacheEnvelope<T> = {
	value: T
	expiresAt: number
}

const inflightRequests = new Map<string, Promise<unknown>>()

function buildCacheKey(namespace: string, key: string) {
	return `cache:${namespace}:${key}`
}

function buildNamespacePattern(namespace: string) {
	return `cache:${namespace}:*`
}

export async function getCachedValue<T>(namespace: string, key: string) {
	const cacheKey = buildCacheKey(namespace, key)

	try {
		const raw = await redis.get(cacheKey)
		if (!raw) return null

		const parsed = JSON.parse(raw) as CacheEnvelope<T>
		if (!parsed || typeof parsed !== 'object' || parsed.expiresAt < Date.now()) {
			await redis.del(cacheKey)
			return null
		}

		return parsed.value
	} catch (err) {
		logger.warn({ err, namespace, key }, 'Failed to read server cache')
		return null
	}
}

export async function setCachedValue<T>(
	namespace: string,
	key: string,
	value: T,
	ttlSeconds: number,
) {
	try {
		await redis.set(
			buildCacheKey(namespace, key),
			JSON.stringify({
				value,
				expiresAt: Date.now() + ttlSeconds * 1000,
			} satisfies CacheEnvelope<T>),
			'EX',
			ttlSeconds,
		)
	} catch (err) {
		logger.warn({ err, namespace, key }, 'Failed to write server cache')
	}
}

export async function invalidateCachedValue(namespace: string, key: string) {
	try {
		await redis.del(buildCacheKey(namespace, key))
	} catch (err) {
		logger.warn({ err, namespace, key }, 'Failed to invalidate server cache')
	}
}

export async function invalidateCachedNamespace(namespace: string) {
	const pattern = buildNamespacePattern(namespace)
	let cursor = '0'

	try {
		do {
			const [nextCursor, keys] = await redis.scan(cursor, 'MATCH', pattern, 'COUNT', 100)
			cursor = nextCursor
			if (keys.length > 0) {
				await redis.del(...keys)
			}
		} while (cursor !== '0')
	} catch (err) {
		logger.warn({ err, namespace }, 'Failed to invalidate server cache namespace')
	}
}

export async function rememberCachedValue<T>(params: {
	namespace: string
	key: string
	ttlSeconds: number
	load: () => Promise<T>
}) {
	const cached = await getCachedValue<T>(params.namespace, params.key)
	if (cached !== null) {
		return cached
	}

	const inflightKey = `${params.namespace}:${params.key}`
	const existing = inflightRequests.get(inflightKey) as Promise<T> | undefined
	if (existing) {
		return existing
	}

	const promise = (async () => {
		const value = await params.load()
		await setCachedValue(params.namespace, params.key, value, params.ttlSeconds)
		return value
	})()

	inflightRequests.set(inflightKey, promise)

	try {
		return await promise
	} finally {
		inflightRequests.delete(inflightKey)
	}
}
