import { lookup, resolveCname } from 'node:dns/promises'
import { siteSettings } from '@community-club/shared'
import type {
	AdminAuthLoginSettingsPayload,
	AdminLegalDocumentsSettingsPayload,
	AdminReferralProgramSettingsPayload,
	AdminRuntimeSettings,
	AdminRuntimeSettingsPayload,
	AdminSiteBrandingSettingsPayload,
	AdminTelegramBotAuthSettingsPayload,
	AdminTestAccessSettingsPayload,
	AppHeaderBlock,
	AppMenuIcon,
	AppNavigationSettings,
	AuthLoginSettings,
	CustomDomainStatus,
	GuestContentAccessSettings,
	HomeBannerActionKind,
	HomeCustomPageBlockKind,
	HomeExperienceSettings,
	HomeHighlightItem,
	HomeSectionGridLayout,
	HomeSectionTextMode,
	HomeSectionVisualMode,
	HomeStoryButtonAction,
	HomeStoryItem,
	HomeStoryLayout,
	HomeStoryOverlay,
	HomeStoryOverlayType,
	HomeStorySection,
	LegalDocumentItem,
	LegalDocumentsSettings,
	ReferralProgramSettings,
	RuntimeSettings,
	SiteBrandingSettings,
	TelegramBotAuthSettings,
	TestAccessSettings,
} from '@community-club/shared/types'
import { inArray, sql } from 'drizzle-orm'
import { env } from '../config/env'
import { db } from '../db/client'
import { decryptSecret, encryptSecret } from './secret-vault'
import { resolvePublicFileUrl } from './storage'

export const SITE_SETTING_KEYS = {
	clubName: 'club_name',
	homeLogoEnabled: 'home_logo_enabled',
	homeLogoMediaKey: 'home_logo_media_key',
	buttonBackgroundColor: 'button_background_color',
	appBackgroundColor: 'app_background_color',
	appSurfaceColor: 'app_surface_color',
	appTextColor: 'app_text_color',
	appAccentColor: 'app_accent_color',
	authLoginPasswordEnabled: 'auth_login_password_enabled',
	authLoginTelegramCodeEnabled: 'auth_login_telegram_code_enabled',
	authLoginMaxCodeEnabled: 'auth_login_max_code_enabled',
	authLoginDefaultMethod: 'auth_login_default_method',
	authLoginBotEnabled: 'auth_login_bot_enabled',
	testAccess: 'test_access',
	telegramBotAuth: 'telegram_bot_auth',
	customDomain: 'custom_domain',
	telegramBotToken: 'telegram_bot_token',
	maxBotToken: 'max_bot_token',
	maxApiUrl: 'max_api_url',
	homeExperience: 'home_experience',
	legalDocuments: 'legal_documents',
	referralProgram: 'referral_program',
	appNavigation: 'app_navigation',
	guestContentAccess: 'guest_content_access',
} as const

const DEFAULT_BUTTON_BACKGROUND_COLOR = '#e2ad2f'
const DEFAULT_CLUB_NAME = 'Club App'
const DEFAULT_APP_BACKGROUND_COLOR = '#090a0d'
const DEFAULT_APP_SURFACE_COLOR = '#121318'
const DEFAULT_APP_TEXT_COLOR = '#f7f2e8'
const DEFAULT_APP_ACCENT_COLOR = '#e2ad2f'
const DEFAULT_TEST_ACCESS_DAYS = 7

type SiteSettingRowLike = {
	key: string
	value: string | null
}

const siteBrandingSettingKeys = [
	SITE_SETTING_KEYS.clubName,
	SITE_SETTING_KEYS.homeLogoEnabled,
	SITE_SETTING_KEYS.homeLogoMediaKey,
	SITE_SETTING_KEYS.buttonBackgroundColor,
	SITE_SETTING_KEYS.appBackgroundColor,
	SITE_SETTING_KEYS.appSurfaceColor,
	SITE_SETTING_KEYS.appTextColor,
	SITE_SETTING_KEYS.appAccentColor,
]

const authLoginSettingKeys = [
	SITE_SETTING_KEYS.authLoginPasswordEnabled,
	SITE_SETTING_KEYS.authLoginTelegramCodeEnabled,
	SITE_SETTING_KEYS.authLoginMaxCodeEnabled,
	SITE_SETTING_KEYS.authLoginDefaultMethod,
	SITE_SETTING_KEYS.authLoginBotEnabled,
]

const telegramBotAuthSettingKeys = [SITE_SETTING_KEYS.telegramBotAuth]

const testAccessSettingKeys = [SITE_SETTING_KEYS.testAccess]
const guestContentAccessSettingKeys = [SITE_SETTING_KEYS.guestContentAccess]

const runtimeSettingKeys = [
	SITE_SETTING_KEYS.customDomain,
	SITE_SETTING_KEYS.telegramBotToken,
	SITE_SETTING_KEYS.maxBotToken,
	SITE_SETTING_KEYS.maxApiUrl,
]

const homeExperienceSettingKeys = [SITE_SETTING_KEYS.homeExperience]
const legalDocumentsSettingKeys = [SITE_SETTING_KEYS.legalDocuments]
const referralProgramSettingKeys = [SITE_SETTING_KEYS.referralProgram]

const defaultLegalDocuments: LegalDocumentItem[] = [
	{
		key: 'privacy',
		title: 'Политика конфиденциальности',
		linkLabel: 'политикой конфиденциальности',
		enabled: true,
		body: `1. Общие положения

Настоящая политика описывает, какие персональные данные обрабатываются при использовании сайта и приложения клуба.

2. Какие данные обрабатываются

Имя, email, телефон, сведения об оплате, действия в приложении и технические данные, необходимые для работы сервиса.

3. Цели обработки

Предоставление доступа к клубу, обработка оплат, поддержка пользователей, отправка уведомлений и выполнение требований закона.

4. Контакты

По вопросам обработки данных напишите на info@example.com.`,
	},
	{
		key: 'personalData',
		title: 'Согласие на обработку персональных данных',
		linkLabel: 'согласием на обработку персональных данных',
		enabled: true,
		body: `Я даю согласие на обработку персональных данных, указанных в формах сайта и приложения клуба.

Согласие действует до его отзыва. Отозвать согласие можно письмом на info@example.com.`,
	},
	{
		key: 'oferta',
		title: 'Договор оферты',
		linkLabel: 'договором оферты',
		enabled: true,
		body: `1. Предмет договора

Исполнитель предоставляет доступ к материалам и сервисам клуба на условиях выбранного тарифа.

2. Акцепт оферты

Оплата тарифа означает согласие пользователя с условиями оферты.

3. Доступ

Доступ открывается после подтверждения оплаты и действует в течение оплаченного периода.

4. Возвраты и ответственность

Возвраты и ответственность сторон регулируются действующим законодательством Российской Федерации.`,
	},
	{
		key: 'requisites',
		title: 'Реквизиты',
		linkLabel: 'реквизитами',
		enabled: true,
		body: `Индивидуальный предприниматель
[ФИО или юрлицо]

ИНН: 000000000000
ОГРН: 000000000000000
Расчётный счёт: 00000000000000000000

Банк: Название банка
БИК: 000000000
Кор. счёт: 00000000000000000000

Email: info@example.com
Телефон: +7 000 000-00-00`,
	},
	{
		key: 'cookie',
		title: 'Политика cookie',
		linkLabel: 'политике cookie',
		noticeText: 'Сохраняем cookie для входа и стабильной работы клуба. Подробнее —',
		enabled: true,
		body: `Сохраняем cookie для входа и стабильной работы клуба.

Cookie помогают сохранять сессию, защищать формы и корректно открывать разделы приложения. Отключение cookie в браузере может нарушить работу входа и оплаты.`,
	},
]

export function getDefaultSiteBrandingSettings(): AdminSiteBrandingSettingsPayload {
	return {
		clubName: DEFAULT_CLUB_NAME,
		homeLogoEnabled: true,
		homeLogoMediaKey: null,
		buttonBackgroundColor: DEFAULT_BUTTON_BACKGROUND_COLOR,
		appBackgroundColor: DEFAULT_APP_BACKGROUND_COLOR,
		appSurfaceColor: DEFAULT_APP_SURFACE_COLOR,
		appTextColor: DEFAULT_APP_TEXT_COLOR,
		appAccentColor: DEFAULT_APP_ACCENT_COLOR,
	}
}

export function getDefaultHomeExperienceSettings(): HomeExperienceSettings {
	return {
		mainBanner: {
			mediaKey: null,
			mediaUrl: null,
			alt: 'Club App — клуб цифровых решений',
		},
		banners: [
			{
				id: 'about',
				title: 'О клубе',
				subtitle: 'Что внутри',
				backgroundColor: '#242424',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				actionKind: 'stories',
				internalPath: '/app',
				externalUrl: '',
				requiresAuth: false,
				storiesEnabled: true,
			},
			{
				id: 'chat',
				title: 'Чат',
				subtitle: 'Общение',
				backgroundColor: '#4a1f21',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				actionKind: 'internal',
				internalPath: '/app/chats',
				externalUrl: '',
				requiresAuth: true,
				storiesEnabled: false,
			},
			{
				id: 'support',
				title: 'Поддержка',
				subtitle: 'Помощь',
				backgroundColor: '#242424',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				actionKind: 'internal',
				internalPath: '/app/support',
				externalUrl: '',
				requiresAuth: true,
				storiesEnabled: false,
			},
			{
				id: 'referral',
				title: 'Рефералка',
				subtitle: 'Приглашения',
				backgroundColor: '#242424',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				actionKind: 'internal',
				internalPath: '/app/profile#referrals',
				externalUrl: '',
				requiresAuth: true,
				storiesEnabled: false,
			},
		],
		bannerShape: 'rounded',
		stories: [
			{
				id: 'story-1',
				title: 'О клубе',
				text: 'Закрытое пространство для материалов, встреч и общения.',
				layout: 'text',
				backgroundColor: '#141414',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				durationMs: 5000,
				imageScale: 1,
				imageX: 0,
				imageY: 0,
				overlays: [],
			},
			{
				id: 'story-2',
				title: 'Материалы',
				text: 'Новые эфиры, чек-листы, подкасты и подборки собраны внутри приложения.',
				layout: 'text',
				backgroundColor: '#2a1516',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				durationMs: 5000,
				imageScale: 1,
				imageX: 0,
				imageY: 0,
				overlays: [],
			},
			{
				id: 'story-3',
				title: 'Календарь',
				text: 'Следите за встречами и событиями клуба в одном месте.',
				layout: 'text',
				backgroundColor: '#1f2633',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				durationMs: 5000,
				imageScale: 1,
				imageX: 0,
				imageY: 0,
				overlays: [],
			},
			{
				id: 'story-4',
				title: 'Чат',
				text: 'Обсуждения и быстрые ответы доступны участникам клуба.',
				layout: 'text',
				backgroundColor: '#28211a',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				durationMs: 5000,
				imageScale: 1,
				imageX: 0,
				imageY: 0,
				overlays: [],
			},
			{
				id: 'story-5',
				title: 'Лента',
				text: 'Новости и объявления клуба появляются в ленте.',
				layout: 'text',
				backgroundColor: '#191919',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				durationMs: 5000,
				imageScale: 1,
				imageX: 0,
				imageY: 0,
				overlays: [],
			},
		],
		highlights: [],
		sectionLayout: 'featured',
		sections: [
			{
				id: 'templates',
				title: 'Шаблоны',
				subtitle: 'Готовые цифровые решения',
				backgroundColor: '#2a2035',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				icon: 'cube',
				visualMode: 'icon',
				textMode: 'visible',
				actionKind: 'internal',
				internalPath: '/app/content/checklists',
				externalUrl: '',
				requiresAuth: false,
			},
			{
				id: 'lessons',
				title: 'Уроки',
				subtitle: 'Вайбкодинг и продажи',
				backgroundColor: '#17283c',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				icon: 'book',
				visualMode: 'icon',
				textMode: 'visible',
				actionKind: 'internal',
				internalPath: '/app/content/courses',
				externalUrl: '',
				requiresAuth: false,
			},
			{
				id: 'tools',
				title: 'Инструменты',
				subtitle: 'Полезные инструменты',
				backgroundColor: '#372a12',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				icon: 'wrench',
				visualMode: 'icon',
				textMode: 'visible',
				actionKind: 'internal',
				internalPath: '/app/content/other',
				externalUrl: '',
				requiresAuth: false,
			},
			{
				id: 'streams',
				title: 'Эфиры',
				subtitle: 'Эфиры клуба',
				backgroundColor: '#3d1b29',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				icon: 'microphone',
				visualMode: 'icon',
				textMode: 'visible',
				actionKind: 'internal',
				internalPath: '/app/content/streams',
				externalUrl: '',
				requiresAuth: false,
			},
			{
				id: 'experts',
				title: 'От экспертов',
				subtitle: 'Шаблоны приглашённых экспертов',
				backgroundColor: '#133832',
				textColor: '#ffffff',
				mediaKey: null,
				mediaUrl: null,
				icon: 'star',
				visualMode: 'icon',
				textMode: 'visible',
				actionKind: 'internal',
				internalPath: '/app/content/experts',
				externalUrl: '',
				requiresAuth: false,
			},
		],
		customPages: [],
	}
}

function normalizeClubName(value: string | null | undefined): string {
	const normalized = value?.replace(/\s+/g, ' ').trim() ?? ''
	return normalized || DEFAULT_CLUB_NAME
}

function normalizeHexColor(
	value: string | null | undefined,
	fallback = DEFAULT_BUTTON_BACKGROUND_COLOR,
): string {
	const normalized = value?.trim().toLowerCase() ?? ''
	if (!/^#[0-9a-f]{6}$/.test(normalized)) return fallback
	return normalized
}

function normalizeHomeActionKind(value: unknown): HomeBannerActionKind {
	return value === 'stories' || value === 'external' || value === 'internal' ? value : 'internal'
}

function normalizeStoryLayout(value: unknown): HomeStoryLayout {
	return value === 'image' || value === 'imageText' || value === 'text' ? value : 'text'
}

function normalizeSectionLayout(value: unknown): HomeSectionGridLayout {
	return value === 'equalOneRow' || value === 'equalTwoRows' || value === 'featured'
		? value
		: 'featured'
}

function normalizeSectionVisualMode(value: unknown): HomeSectionVisualMode {
	return value === 'icon' || value === 'image' || value === 'color' ? value : 'color'
}

function normalizeSectionTextMode(value: unknown): HomeSectionTextMode {
	return value === 'hidden' || value === 'visible' ? value : 'visible'
}

function normalizeCustomPageBlockKind(value: unknown): HomeCustomPageBlockKind {
	return value === 'heading' ||
		value === 'text' ||
		value === 'image' ||
		value === 'video' ||
		value === 'button'
		? value
		: 'heading'
}

function normalizeSlug(value: unknown, fallback: string): string {
	const slug =
		typeof value === 'string'
			? value
					.trim()
					.toLowerCase()
					.replace(/[^a-z0-9-]+/g, '-')
					.replace(/^-+|-+$/g, '')
			: ''
	return (slug || fallback).slice(0, 80)
}

function normalizeHomePath(value: unknown, fallback = '/app'): string {
	const path = typeof value === 'string' ? value.trim() : ''
	if (!path.startsWith('/app')) return fallback
	const [pathname, query = ''] = path.split('?', 2)
	if (pathname === '/app/materials') {
		const type = new URLSearchParams(query).get('type') || 'checklists'
		return `/app/content/${encodeURIComponent(type)}`
	}
	return path.slice(0, 160)
}

function normalizeExternalUrl(value: unknown): string {
	const raw = typeof value === 'string' ? value.trim() : ''
	if (!raw) return ''
	try {
		const url = new URL(raw)
		if (url.protocol !== 'https:' && url.protocol !== 'http:') return ''
		return url.toString()
	} catch {
		return ''
	}
}

function normalizeBannerShape(value: unknown): HomeExperienceSettings['bannerShape'] {
	return value === 'circle' ? 'circle' : 'rounded'
}

function resolveStoryMediaUrls(story: HomeStoryItem): HomeStoryItem {
	return {
		...story,
		mediaUrl: story.mediaKey ? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, story.mediaKey) : null,
		overlays: story.overlays.map((overlay) =>
			overlay.type === 'image'
				? {
						...overlay,
						mediaUrl: overlay.mediaKey
							? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, overlay.mediaKey)
							: null,
					}
				: overlay,
		),
	}
}

export function withMediaUrls(settings: HomeExperienceSettings): HomeExperienceSettings {
	return {
		...settings,
		mainBanner: {
			...settings.mainBanner,
			mediaUrl: settings.mainBanner.mediaKey
				? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, settings.mainBanner.mediaKey)
				: null,
		},
		banners: settings.banners.map((item) => ({
			...item,
			mediaUrl: item.mediaKey ? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, item.mediaKey) : null,
		})),
		stories: settings.stories.map(resolveStoryMediaUrls),
		highlights: settings.highlights.map((highlight) => ({
			...highlight,
			stories: highlight.stories.map(resolveStoryMediaUrls),
		})),
		sections: settings.sections.map((item) => ({
			...item,
			mediaUrl: item.mediaKey ? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, item.mediaKey) : null,
		})),
		customPages: settings.customPages.map((page) => ({
			...page,
			blocks: page.blocks.map((block) => ({
				...block,
				mediaUrl: block.mediaKey ? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, block.mediaKey) : null,
			})),
		})),
	}
}

function clampNumber(value: unknown, min: number, max: number, fallback: number): number {
	const num = Number(value)
	return Number.isFinite(num) ? Math.min(Math.max(num, min), max) : fallback
}

const EMPTY_STORY_FALLBACK: HomeStoryItem = {
	id: 'story',
	title: 'История',
	text: '',
	layout: 'image',
	backgroundColor: '#141414',
	textColor: '#ffffff',
	mediaKey: null,
	mediaUrl: null,
	durationMs: 5000,
	imageScale: 1,
	imageX: 0,
	imageY: 0,
	overlays: [],
}

function normalizeStorySection(value: unknown): HomeStorySection {
	return value === 'materials' ||
		value === 'chats' ||
		value === 'channel' ||
		value === 'feed' ||
		value === 'calendar' ||
		value === 'profile' ||
		value === 'payment' ||
		value === 'support'
		? (value as HomeStorySection)
		: ''
}

function normalizeStoryOverlay(item: Partial<HomeStoryOverlay>, index: number): HomeStoryOverlay {
	const type: HomeStoryOverlayType =
		item.type === 'image' || item.type === 'button' ? item.type : 'text'
	const defaultWidth = type === 'text' ? 100 : type === 'button' ? 28 : 40
	return {
		id: String(item.id || `overlay-${index + 1}`).slice(0, 64),
		type,
		x: clampNumber(item.x, 0, 100, 0),
		y: clampNumber(item.y, 0, 100, 0),
		width: clampNumber(item.width, 5, 100, defaultWidth),
		text: String(item.text ?? '')
			.trim()
			.slice(0, 500),
		textColor: normalizeHexColor(item.textColor, '#ffffff'),
		fontSize: Math.round(clampNumber(item.fontSize, 12, 64, 18)),
		align: item.align === 'left' || item.align === 'right' ? item.align : 'center',
		mediaKey: item.mediaKey?.trim() || null,
		mediaUrl: null,
		borderRadius: Math.round(clampNumber(item.borderRadius, 0, 40, type === 'button' ? 12 : 0)),
		opacity: clampNumber(item.opacity, 0, 100, 100),
		label: String(item.label ?? '')
			.trim()
			.slice(0, 40),
		backgroundColor: normalizeHexColor(
			item.backgroundColor,
			type === 'button' ? '#e8b82f' : '#000000',
		),
		borderColor: item.borderColor?.trim() ? normalizeHexColor(item.borderColor, '#ffffff') : null,
		borderWidth: Math.round(clampNumber(item.borderWidth, 0, 8, 0)),
		action: item.action === 'link' || item.action === 'section' ? item.action : 'none',
		linkUrl: String(item.linkUrl ?? '')
			.trim()
			.slice(0, 2048),
		section: normalizeStorySection(item.section),
	}
}

function normalizeStoryItem(
	item: Partial<HomeStoryItem>,
	index: number,
	fallback: HomeStoryItem,
): HomeStoryItem {
	return {
		id: String(item.id || fallback.id || `story-${index + 1}`).slice(0, 64),
		title: String(item.title || fallback.title || 'История')
			.trim()
			.slice(0, 80),
		text: String(item.text ?? fallback.text ?? '')
			.trim()
			.slice(0, 500),
		layout: normalizeStoryLayout(item.layout),
		backgroundColor: normalizeHexColor(item.backgroundColor, fallback.backgroundColor),
		textColor: normalizeHexColor(item.textColor, fallback.textColor),
		mediaKey: item.mediaKey?.trim() || null,
		mediaUrl: null,
		durationMs: Math.round(clampNumber(item.durationMs, 2500, 15000, 5000)),
		imageScale: Math.round(clampNumber(item.imageScale, 0.1, 3, 1) * 100) / 100,
		imageX: clampNumber(item.imageX, -100, 100, 0),
		imageY: clampNumber(item.imageY, -100, 100, 0),
		overlays: Array.isArray(item.overlays)
			? item.overlays
					.slice(0, 20)
					.map((overlay, overlayIndex) => normalizeStoryOverlay(overlay, overlayIndex))
			: [],
	}
}

function normalizeHighlightItem(
	item: Partial<HomeHighlightItem>,
	index: number,
): HomeHighlightItem {
	const stories = Array.isArray(item.stories) ? item.stories : []
	return {
		id: String(item.id || `highlight-${index + 1}`).slice(0, 64),
		title: String(item.title ?? '')
			.trim()
			.slice(0, 80),
		stories: stories
			.slice(0, 20)
			.map((story, storyIndex) => normalizeStoryItem(story, storyIndex, EMPTY_STORY_FALLBACK)),
	}
}

export function normalizeHomeExperienceSettingsPayload(
	payload: Partial<HomeExperienceSettings>,
): HomeExperienceSettings {
	const defaults = getDefaultHomeExperienceSettings()
	const mainBannerSource = payload?.mainBanner ?? defaults.mainBanner
	const defaultPageBlock = {
		id: 'block-1',
		kind: 'heading' as const,
		title: 'Заголовок',
		text: '',
		mediaKey: null,
		mediaUrl: null,
		buttonLabel: '',
		buttonUrl: '',
		backgroundColor: '#242424',
		textColor: '#ffffff',
		borderRadius: 24,
		size: 'md' as const,
	}
	const bannersSource = Array.isArray(payload?.banners) ? payload.banners : defaults.banners
	const storiesSource = Array.isArray(payload?.stories) ? payload.stories : defaults.stories
	const highlightsSource = Array.isArray(payload?.highlights) ? payload.highlights : []
	const sectionsSource = Array.isArray(payload?.sections) ? payload.sections : defaults.sections
	const customPagesSource = Array.isArray(payload?.customPages)
		? payload.customPages
		: defaults.customPages

	const banners = bannersSource.slice(0, 12).map((item, index) => {
		const fallback = defaults.banners[index] ?? defaults.banners[0]
		const actionKind = normalizeHomeActionKind(item.actionKind)
		return {
			id: String(item.id || fallback.id || `banner-${index + 1}`).slice(0, 64),
			title: String(item.title || fallback.title || 'Раздел')
				.trim()
				.slice(0, 80),
			subtitle: String(item.subtitle ?? fallback.subtitle ?? '')
				.trim()
				.slice(0, 120),
			backgroundColor: normalizeHexColor(item.backgroundColor, fallback.backgroundColor),
			textColor: normalizeHexColor(item.textColor, fallback.textColor),
			mediaKey: item.mediaKey?.trim() || null,
			mediaUrl: null,
			actionKind,
			internalPath: normalizeHomePath(item.internalPath, fallback.internalPath),
			externalUrl: normalizeExternalUrl(item.externalUrl),
			requiresAuth: Boolean(item.requiresAuth),
			storiesEnabled: actionKind === 'stories' ? true : Boolean(item.storiesEnabled),
		}
	})

	const stories = storiesSource
		.slice(0, 20)
		.map((item, index) =>
			normalizeStoryItem(item, index, defaults.stories[index] ?? defaults.stories[0]),
		)

	const highlights = highlightsSource.slice(0, 5).map(normalizeHighlightItem)

	const sections = sectionsSource.slice(0, 12).map((item, index) => {
		const fallback = defaults.sections[index] ?? defaults.sections[0]
		const actionKind = item.actionKind === 'external' ? 'external' : 'internal'
		return {
			id: String(item.id || fallback.id || `section-${index + 1}`).slice(0, 64),
			title: String(item.title || fallback.title || 'Раздел')
				.trim()
				.slice(0, 80),
			subtitle: String(item.subtitle ?? fallback.subtitle ?? '')
				.trim()
				.slice(0, 120),
			backgroundColor: normalizeHexColor(item.backgroundColor, fallback.backgroundColor),
			textColor: normalizeHexColor(item.textColor, fallback.textColor),
			mediaKey: item.mediaKey?.trim() || null,
			mediaUrl: null,
			icon: String(item.icon || fallback.icon || 'spark')
				.trim()
				.slice(0, 32),
			visualMode: normalizeSectionVisualMode(item.visualMode),
			textMode: normalizeSectionTextMode(item.textMode),
			actionKind,
			internalPath: normalizeHomePath(item.internalPath, fallback.internalPath),
			externalUrl: normalizeExternalUrl(item.externalUrl),
			requiresAuth: Boolean(item.requiresAuth),
		}
	})

	const customPages = customPagesSource.slice(0, 20).map((page, pageIndex) => {
		const fallback = defaults.customPages[pageIndex] ?? {
			id: `custom-page-${pageIndex + 1}`,
			slug: `page-${pageIndex + 1}`,
			title: 'Страница',
			backgroundColor: '#141414',
			textColor: '#ffffff',
			blocks: [defaultPageBlock],
		}
		const blocksSource = Array.isArray(page.blocks) ? page.blocks : fallback.blocks
		return {
			id: String(page.id || fallback.id || `custom-page-${pageIndex + 1}`).slice(0, 64),
			slug: normalizeSlug(page.slug, fallback.slug || `page-${pageIndex + 1}`),
			title: String(page.title || fallback.title || 'Страница')
				.trim()
				.slice(0, 100),
			backgroundColor: normalizeHexColor(page.backgroundColor, fallback.backgroundColor),
			textColor: normalizeHexColor(page.textColor, fallback.textColor),
			blocks: blocksSource.slice(0, 40).map((block, blockIndex) => {
				const blockFallback = fallback.blocks[blockIndex] ?? fallback.blocks[0] ?? defaultPageBlock
				return {
					id: String(block.id || blockFallback.id || `block-${blockIndex + 1}`).slice(0, 64),
					kind: normalizeCustomPageBlockKind(block.kind),
					title: String(block.title ?? blockFallback.title ?? '')
						.trim()
						.slice(0, 120),
					text: String(block.text ?? blockFallback.text ?? '')
						.trim()
						.slice(0, 2000),
					mediaKey: block.mediaKey?.trim() || null,
					mediaUrl: null,
					buttonLabel: String(block.buttonLabel ?? blockFallback.buttonLabel ?? '')
						.trim()
						.slice(0, 80),
					buttonUrl: normalizeExternalUrl(block.buttonUrl),
					backgroundColor: normalizeHexColor(block.backgroundColor, blockFallback.backgroundColor),
					textColor: normalizeHexColor(block.textColor, blockFallback.textColor),
					borderRadius: Math.min(Math.max(Number(block.borderRadius) || 24, 0), 40),
					size: block.size === 'sm' || block.size === 'lg' ? block.size : 'md',
				}
			}),
		}
	})

	return {
		mainBanner: {
			mediaKey: mainBannerSource.mediaKey?.trim() || null,
			mediaUrl: null,
			alt:
				String(mainBannerSource.alt ?? '')
					.trim()
					.slice(0, 160) || defaults.mainBanner.alt,
		},
		banners: banners.length > 0 ? banners : defaults.banners,
		bannerShape: normalizeBannerShape(payload?.bannerShape),
		stories: stories.length > 0 ? stories : defaults.stories,
		highlights,
		sectionLayout: normalizeSectionLayout(payload?.sectionLayout),
		sections: sections.length > 0 ? sections : defaults.sections,
		customPages,
	}
}

export function parseStoredHomeExperienceSettings(
	rows: SiteSettingRowLike[],
): HomeExperienceSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.homeExperience)?.value
	if (!raw) return getDefaultHomeExperienceSettings()
	try {
		return normalizeHomeExperienceSettingsPayload(
			JSON.parse(raw) as Partial<HomeExperienceSettings>,
		)
	} catch {
		return getDefaultHomeExperienceSettings()
	}
}

export function normalizeSiteBrandingSettingsPayload(
	payload: AdminSiteBrandingSettingsPayload,
): AdminSiteBrandingSettingsPayload {
	const mediaKey = payload.homeLogoMediaKey?.trim() || null

	return {
		clubName: normalizeClubName(payload.clubName),
		homeLogoEnabled: Boolean(payload.homeLogoEnabled),
		homeLogoMediaKey: mediaKey,
		buttonBackgroundColor: normalizeHexColor(
			payload.buttonBackgroundColor,
			DEFAULT_BUTTON_BACKGROUND_COLOR,
		),
		appBackgroundColor: normalizeHexColor(payload.appBackgroundColor, DEFAULT_APP_BACKGROUND_COLOR),
		appSurfaceColor: normalizeHexColor(payload.appSurfaceColor, DEFAULT_APP_SURFACE_COLOR),
		appTextColor: normalizeHexColor(payload.appTextColor, DEFAULT_APP_TEXT_COLOR),
		appAccentColor: normalizeHexColor(payload.appAccentColor, DEFAULT_APP_ACCENT_COLOR),
	}
}

export function parseStoredSiteBrandingSettings(
	rows: SiteSettingRowLike[],
): AdminSiteBrandingSettingsPayload {
	const defaults = getDefaultSiteBrandingSettings()
	const values = new Map(rows.map((row) => [row.key, row.value ?? '']))
	const storedEnabled = values.get(SITE_SETTING_KEYS.homeLogoEnabled)
	const storedClubName = values.get(SITE_SETTING_KEYS.clubName)
	const storedMediaKey = values.get(SITE_SETTING_KEYS.homeLogoMediaKey)
	const storedButtonBackgroundColor = values.get(SITE_SETTING_KEYS.buttonBackgroundColor)
	const storedAppBackgroundColor = values.get(SITE_SETTING_KEYS.appBackgroundColor)
	const storedAppSurfaceColor = values.get(SITE_SETTING_KEYS.appSurfaceColor)
	const storedAppTextColor = values.get(SITE_SETTING_KEYS.appTextColor)
	const storedAppAccentColor = values.get(SITE_SETTING_KEYS.appAccentColor)

	return normalizeSiteBrandingSettingsPayload({
		clubName: storedClubName ?? defaults.clubName,
		homeLogoEnabled:
			storedEnabled == null ? defaults.homeLogoEnabled : storedEnabled.trim() !== 'false',
		homeLogoMediaKey: storedMediaKey ?? defaults.homeLogoMediaKey,
		buttonBackgroundColor: storedButtonBackgroundColor ?? defaults.buttonBackgroundColor,
		appBackgroundColor: storedAppBackgroundColor ?? defaults.appBackgroundColor,
		appSurfaceColor: storedAppSurfaceColor ?? defaults.appSurfaceColor,
		appTextColor: storedAppTextColor ?? defaults.appTextColor,
		appAccentColor: storedAppAccentColor ?? defaults.appAccentColor,
	})
}

export function buildSiteBrandingSettings(
	settings: AdminSiteBrandingSettingsPayload,
	logoUrl: string | null,
): SiteBrandingSettings {
	const normalized = normalizeSiteBrandingSettingsPayload(settings)

	return {
		...normalized,
		homeLogoUrl: normalized.homeLogoEnabled ? logoUrl : null,
	}
}

function buildLogoUrl(mediaKey: string | null): string | null {
	return mediaKey ? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, mediaKey) : null
}

function serializeSiteBrandingSettings(settings: AdminSiteBrandingSettingsPayload) {
	const normalized = normalizeSiteBrandingSettingsPayload(settings)

	return [
		{
			key: SITE_SETTING_KEYS.clubName,
			value: normalized.clubName,
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.homeLogoEnabled,
			value: normalized.homeLogoEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.homeLogoMediaKey,
			value: normalized.homeLogoMediaKey ?? '',
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.buttonBackgroundColor,
			value: normalized.buttonBackgroundColor,
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.appBackgroundColor,
			value: normalized.appBackgroundColor,
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.appSurfaceColor,
			value: normalized.appSurfaceColor,
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.appTextColor,
			value: normalized.appTextColor,
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.appAccentColor,
			value: normalized.appAccentColor,
			updatedAt: new Date(),
		},
	]
}

export function getDefaultAuthLoginSettings(): AuthLoginSettings {
	return {
		passwordEnabled: true,
		telegramCodeEnabled: true,
		maxCodeEnabled: false,
		defaultMethod: 'password',
		botAuthEnabled: false,
	}
}

function isEnabledSetting(value: string | null | undefined, fallback: boolean) {
	if (value == null) return fallback
	return value.trim() === 'true'
}

export function normalizeAuthLoginSettingsPayload(
	payload: AdminAuthLoginSettingsPayload,
): AuthLoginSettings {
	const passwordEnabled = Boolean(payload.passwordEnabled)
	const telegramCodeEnabled = Boolean(payload.telegramCodeEnabled)
	const maxCodeEnabled = Boolean(payload.maxCodeEnabled)
	const botAuthEnabled = Boolean(payload.botAuthEnabled)
	const enabledMethods = [
		passwordEnabled ? 'password' : null,
		telegramCodeEnabled || botAuthEnabled ? 'telegram' : null,
		maxCodeEnabled ? 'max' : null,
	].filter((method): method is AuthLoginSettings['defaultMethod'] => method !== null)

	return {
		passwordEnabled: enabledMethods.length === 0 ? true : passwordEnabled,
		telegramCodeEnabled,
		maxCodeEnabled,
		defaultMethod: enabledMethods.includes(payload.defaultMethod)
			? payload.defaultMethod
			: (enabledMethods[0] ?? 'password'),
		botAuthEnabled,
	}
}

export function parseStoredAuthLoginSettings(rows: SiteSettingRowLike[]): AuthLoginSettings {
	const defaults = getDefaultAuthLoginSettings()
	const values = new Map(rows.map((row) => [row.key, row.value ?? '']))
	const storedDefault = values.get(SITE_SETTING_KEYS.authLoginDefaultMethod)
	const defaultMethod =
		storedDefault === 'telegram' || storedDefault === 'max' || storedDefault === 'password'
			? storedDefault
			: defaults.defaultMethod

	return normalizeAuthLoginSettingsPayload({
		passwordEnabled: isEnabledSetting(
			values.get(SITE_SETTING_KEYS.authLoginPasswordEnabled),
			defaults.passwordEnabled,
		),
		telegramCodeEnabled: isEnabledSetting(
			values.get(SITE_SETTING_KEYS.authLoginTelegramCodeEnabled),
			defaults.telegramCodeEnabled,
		),
		maxCodeEnabled: isEnabledSetting(
			values.get(SITE_SETTING_KEYS.authLoginMaxCodeEnabled),
			defaults.maxCodeEnabled,
		),
		defaultMethod,
		botAuthEnabled: isEnabledSetting(
			values.get(SITE_SETTING_KEYS.authLoginBotEnabled),
			defaults.botAuthEnabled,
		),
	})
}

function serializeAuthLoginSettings(settings: AdminAuthLoginSettingsPayload) {
	const normalized = normalizeAuthLoginSettingsPayload(settings)

	return [
		{
			key: SITE_SETTING_KEYS.authLoginPasswordEnabled,
			value: normalized.passwordEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.authLoginTelegramCodeEnabled,
			value: normalized.telegramCodeEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.authLoginMaxCodeEnabled,
			value: normalized.maxCodeEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.authLoginDefaultMethod,
			value: normalized.defaultMethod,
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.authLoginBotEnabled,
			value: normalized.botAuthEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
	]
}

export function getDefaultTelegramBotAuthSettings(): TelegramBotAuthSettings {
	return {
		botHandle: '',
		noAccessText: 'У вас нет доступа на этот момент.',
		codeMessageText: 'Ваш код входа в клуб: {code}. Действует 10 минут.',
		subscriptionButtonLabel: 'Оплатить подписку',
		subscriptionButtonUrl: '',
		openAppButtonLabel: 'Открыть приложение',
		ownerHandle: '',
	}
}

export function normalizeTelegramBotAuthSettingsPayload(
	payload: AdminTelegramBotAuthSettingsPayload,
): TelegramBotAuthSettings {
	const fallback = getDefaultTelegramBotAuthSettings()
	return {
		botHandle: String(payload?.botHandle ?? '')
			.trim()
			.replace(/^@/, '')
			.slice(0, 64),
		noAccessText: String(payload?.noAccessText ?? '').trim() || fallback.noAccessText,
		codeMessageText: String(payload?.codeMessageText ?? '').trim() || fallback.codeMessageText,
		subscriptionButtonLabel:
			String(payload?.subscriptionButtonLabel ?? '').trim() || fallback.subscriptionButtonLabel,
		subscriptionButtonUrl: String(payload?.subscriptionButtonUrl ?? '')
			.trim()
			.slice(0, 2048),
		openAppButtonLabel:
			String(payload?.openAppButtonLabel ?? '').trim() || fallback.openAppButtonLabel,
		ownerHandle: String(payload?.ownerHandle ?? '')
			.trim()
			.replace(/^@/, '')
			.slice(0, 64),
	}
}

export function parseStoredTelegramBotAuthSettings(
	rows: SiteSettingRowLike[],
): TelegramBotAuthSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.telegramBotAuth)?.value
	if (!raw) return getDefaultTelegramBotAuthSettings()
	try {
		return normalizeTelegramBotAuthSettingsPayload(
			JSON.parse(raw) as AdminTelegramBotAuthSettingsPayload,
		)
	} catch {
		return getDefaultTelegramBotAuthSettings()
	}
}

export function getDefaultTestAccessSettings(): TestAccessSettings {
	return {
		enabled: true,
		days: DEFAULT_TEST_ACCESS_DAYS,
	}
}

export function getDefaultGuestContentAccessSettings(): GuestContentAccessSettings {
	return { level: 'cards' }
}

export function normalizeGuestContentAccessSettingsPayload(
	payload: GuestContentAccessSettings,
): GuestContentAccessSettings {
	return {
		level: payload?.level === 'sections' || payload?.level === 'preview' ? payload.level : 'cards',
	}
}

export function parseStoredGuestContentAccessSettings(
	rows: SiteSettingRowLike[],
): GuestContentAccessSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.guestContentAccess)?.value
	if (!raw) return getDefaultGuestContentAccessSettings()
	try {
		return normalizeGuestContentAccessSettingsPayload(JSON.parse(raw) as GuestContentAccessSettings)
	} catch {
		return getDefaultGuestContentAccessSettings()
	}
}

export function getDefaultReferralProgramSettings(): ReferralProgramSettings {
	return {
		enabled: true,
		description: 'Поделитесь ссылкой с теми, кому будет полезен клуб.',
	}
}

export function normalizeTestAccessSettingsPayload(
	payload: AdminTestAccessSettingsPayload,
): TestAccessSettings {
	const days = Number.isFinite(payload.days) ? Math.trunc(payload.days) : DEFAULT_TEST_ACCESS_DAYS
	return {
		enabled: Boolean(payload.enabled),
		days: Math.min(365, Math.max(1, days)),
	}
}

export function parseStoredTestAccessSettings(rows: SiteSettingRowLike[]): TestAccessSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.testAccess)?.value
	if (!raw) return getDefaultTestAccessSettings()
	try {
		return normalizeTestAccessSettingsPayload(JSON.parse(raw) as TestAccessSettings)
	} catch {
		return getDefaultTestAccessSettings()
	}
}

export function normalizeReferralProgramSettingsPayload(
	payload: AdminReferralProgramSettingsPayload,
): ReferralProgramSettings {
	const fallback = getDefaultReferralProgramSettings()
	const description = String(payload.description ?? '').trim() || fallback.description
	return {
		enabled: Boolean(payload.enabled),
		description: description.slice(0, 500),
	}
}

export function parseStoredReferralProgramSettings(
	rows: SiteSettingRowLike[],
): ReferralProgramSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.referralProgram)?.value
	if (!raw) return getDefaultReferralProgramSettings()
	try {
		return normalizeReferralProgramSettingsPayload(JSON.parse(raw) as ReferralProgramSettings)
	} catch {
		return getDefaultReferralProgramSettings()
	}
}

function normalizeLegalDocument(value: Partial<LegalDocumentItem>, fallback: LegalDocumentItem) {
	const title = value.title?.trim() || fallback.title
	const linkLabel = value.linkLabel?.trim() || fallback.linkLabel
	const noticeText = value.noticeText?.trim() || fallback.noticeText
	const body = value.body?.trim() || fallback.body

	const normalized: LegalDocumentItem = {
		key: fallback.key,
		title: title.slice(0, 160),
		linkLabel: linkLabel.slice(0, 120),
		enabled: typeof value.enabled === 'boolean' ? value.enabled : fallback.enabled,
		body: body.slice(0, 50_000),
	}

	if (noticeText) {
		normalized.noticeText = noticeText.slice(0, 500)
	}

	return normalized
}

export function getDefaultLegalDocumentsSettings(): LegalDocumentsSettings {
	return {
		documents: defaultLegalDocuments.map((document) => ({ ...document })),
	}
}

export function normalizeLegalDocumentsSettingsPayload(
	payload: AdminLegalDocumentsSettingsPayload,
): LegalDocumentsSettings {
	const stored = new Map(
		(payload.documents ?? []).map((document) => [document.key, document] as const),
	)

	return {
		documents: defaultLegalDocuments.map((document) =>
			normalizeLegalDocument(stored.get(document.key) ?? {}, document),
		),
	}
}

export function parseStoredLegalDocumentsSettings(
	rows: SiteSettingRowLike[],
): LegalDocumentsSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.legalDocuments)?.value
	if (!raw) return getDefaultLegalDocumentsSettings()
	try {
		return normalizeLegalDocumentsSettingsPayload(JSON.parse(raw) as LegalDocumentsSettings)
	} catch {
		return getDefaultLegalDocumentsSettings()
	}
}

export function normalizeCustomDomain(value: string | null | undefined): string | null {
	const normalized = value
		?.trim()
		.toLowerCase()
		.replace(/^https?:\/\//, '')
		.replace(/\/.*$/, '')
		.replace(/\.$/, '')
	if (!normalized) return null
	if (!/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(normalized)) {
		return null
	}
	return normalized
}

function normalizeUrl(value: string | null | undefined, fallback: string): string {
	const trimmed = value?.trim() || fallback
	try {
		const url = new URL(trimmed)
		if (url.protocol !== 'https:' && url.protocol !== 'http:') return fallback
		return url.toString().replace(/\/$/, '')
	} catch {
		return fallback
	}
}

function parseStoredRuntimeSettings(rows: SiteSettingRowLike[]): RuntimeSettings & {
	telegramBotToken: string
	maxBotToken: string
} {
	const values = new Map(rows.map((row) => [row.key, row.value ?? '']))
	const telegramBotToken = values.has(SITE_SETTING_KEYS.telegramBotToken)
		? decryptSecret(values.get(SITE_SETTING_KEYS.telegramBotToken))
		: env.TELEGRAM_BOT_TOKEN
	const maxBotToken = values.has(SITE_SETTING_KEYS.maxBotToken)
		? decryptSecret(values.get(SITE_SETTING_KEYS.maxBotToken))
		: env.MAX_BOT_TOKEN
	const maxApiUrl = normalizeUrl(values.get(SITE_SETTING_KEYS.maxApiUrl), env.MAX_API_URL)

	return {
		customDomain: normalizeCustomDomain(values.get(SITE_SETTING_KEYS.customDomain)),
		telegramBotToken,
		maxBotToken,
		maxApiUrl,
		telegramBotTokenSet: Boolean(telegramBotToken),
		maxBotTokenSet: Boolean(maxBotToken),
	}
}

async function loadStoredRuntimeSettings() {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, runtimeSettingKeys))

	return parseStoredRuntimeSettings(rows)
}

async function lookupAddresses(hostname: string) {
	try {
		const records = await lookup(hostname, { all: true })
		return Array.from(new Set(records.map((record) => record.address))).sort()
	} catch {
		return []
	}
}

async function lookupCnames(hostname: string) {
	try {
		return (await resolveCname(hostname))
			.map((item) => item.toLowerCase().replace(/\.$/, ''))
			.sort()
	} catch {
		return []
	}
}

export async function checkCustomDomainStatus(
	domain: string | null | undefined,
): Promise<CustomDomainStatus> {
	const normalizedDomain = normalizeCustomDomain(domain)
	const checkedAt = new Date().toISOString()
	const expectedHost = (() => {
		try {
			return new URL(env.APP_URL).hostname.toLowerCase()
		} catch {
			return null
		}
	})()

	if (!normalizedDomain) {
		return {
			status: 'not_configured',
			domain: null,
			checkedAt,
			message: 'Домен не указан',
			dns: {
				expectedHost,
				cnames: [],
				domainAddresses: [],
				expectedAddresses: [],
				cnameMatches: false,
				addressMatches: false,
			},
		}
	}

	const [cnames, domainAddresses, expectedAddresses] = await Promise.all([
		lookupCnames(normalizedDomain),
		lookupAddresses(normalizedDomain),
		expectedHost ? lookupAddresses(expectedHost) : Promise.resolve([]),
	])
	const cnameMatches = expectedHost ? cnames.includes(expectedHost) : false
	const addressMatches =
		expectedAddresses.length > 0 &&
		domainAddresses.some((address) => expectedAddresses.includes(address))
	const connected = cnameMatches || addressMatches

	return {
		status: connected ? 'connected' : 'pending',
		domain: normalizedDomain,
		checkedAt,
		message: connected
			? 'Домен указывает на текущий сервер'
			: 'DNS домена пока не указывает на текущий сервер',
		dns: {
			expectedHost,
			cnames,
			domainAddresses,
			expectedAddresses,
			cnameMatches,
			addressMatches,
		},
	}
}

export async function loadSiteBrandingSettings(): Promise<SiteBrandingSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, siteBrandingSettingKeys))

	const settings = parseStoredSiteBrandingSettings(rows)
	return buildSiteBrandingSettings(settings, buildLogoUrl(settings.homeLogoMediaKey))
}

export async function loadHomeExperienceSettings(): Promise<HomeExperienceSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, homeExperienceSettingKeys))

	return withMediaUrls(parseStoredHomeExperienceSettings(rows))
}

export async function saveHomeExperienceSettings(
	payload: HomeExperienceSettings,
): Promise<HomeExperienceSettings> {
	const normalized = normalizeHomeExperienceSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values([
			{
				key: SITE_SETTING_KEYS.homeExperience,
				value: JSON.stringify(normalized),
				updatedAt: new Date(),
			},
		])
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadHomeExperienceSettings()
}

const DEFAULT_APP_MENU_BACKGROUND_COLOR = '#101012'
const DEFAULT_APP_MENU_BORDER_COLOR = '#34312d'
const DEFAULT_APP_MENU_ACTIVE_ICON_COLOR = '#f0c75f'
const DEFAULT_APP_MENU_INACTIVE_ICON_COLOR = '#d3c4ad'

const ALL_HEADER_BLOCKS: AppHeaderBlock[] = ['logo', 'avatar', 'name', 'notifications']
const ALL_MENU_ICONS: AppMenuIcon[] = [
	'home',
	'feed',
	'calendar',
	'cube',
	'book',
	'wrench',
	'user',
	'bell',
	'support',
	'info',
	'chats',
	'materials',
	'spark',
	'play',
	'check',
	'video',
]

const appNavigationSettingKeys = [SITE_SETTING_KEYS.appNavigation]

export function getDefaultAppNavigationSettings(): AppNavigationSettings {
	return {
		header: {
			enabled: true,
			showOnAllPages: false,
			order: ['logo', 'name', 'notifications', 'avatar'],
			logoMode: 'image',
			nameMode: 'club',
		},
		menu: {
			items: [
				{
					id: 'materials',
					label: 'Шаблоны',
					icon: 'cube',
					path: '/app/content/checklists',
					requiresAuth: false,
					requiresAccess: true,
				},
				{
					id: 'calendar',
					label: 'Уроки',
					icon: 'book',
					path: '/app/content/courses',
					requiresAuth: false,
					requiresAccess: true,
				},
				{
					id: 'feed',
					label: 'Инструменты',
					icon: 'wrench',
					path: '/app/content/other',
					requiresAuth: false,
					requiresAccess: true,
				},
				{
					id: 'profile',
					label: 'Профиль',
					icon: 'user',
					path: '/app/profile',
					requiresAuth: true,
					requiresAccess: false,
				},
			],
			centerButton: {
				enabled: true,
				icon: 'spark',
				imageKey: null,
				imageUrl: null,
				glowEnabled: true,
				pressEffectEnabled: true,
				actionPath: '/app',
				requiresAuth: false,
			},
			backgroundColor: DEFAULT_APP_MENU_BACKGROUND_COLOR,
			borderColor: DEFAULT_APP_MENU_BORDER_COLOR,
			borderRadius: 40,
			marginBottom: 7,
			marginSide: 6,
			iconStrokeColor: null,
			iconGlowEnabled: true,
			iconHighlightEnabled: true,
			activeIconColor: DEFAULT_APP_MENU_ACTIVE_ICON_COLOR,
			inactiveIconColor: DEFAULT_APP_MENU_INACTIVE_ICON_COLOR,
			startActivePath: '/app',
		},
	}
}

function normalizeHeaderBlock(value: unknown): AppHeaderBlock {
	return ALL_HEADER_BLOCKS.includes(value as AppHeaderBlock) ? (value as AppHeaderBlock) : 'logo'
}

function normalizeMenuIcon(value: unknown): AppMenuIcon {
	return ALL_MENU_ICONS.includes(value as AppMenuIcon) ? (value as AppMenuIcon) : 'home'
}

function normalizeOptionalHexColor(value: unknown, fallback: string | null): string | null {
	if (value == null || value === '') return null
	const normalized = typeof value === 'string' ? value.trim() : ''
	return normalizeHexColor(normalized, fallback ?? DEFAULT_APP_MENU_BACKGROUND_COLOR)
}

export function normalizeAppNavigationSettingsPayload(
	payload: AppNavigationSettings,
): AppNavigationSettings {
	const defaults = getDefaultAppNavigationSettings()
	const headerSource = payload?.header ?? defaults.header
	const menuSource = payload?.menu ?? defaults.menu
	const itemsSource = Array.isArray(menuSource.items) ? menuSource.items : defaults.menu.items

	const order = Array.isArray(headerSource.order)
		? Array.from(new Set(headerSource.order.map((block) => normalizeHeaderBlock(block)))).slice(
				0,
				ALL_HEADER_BLOCKS.length,
			)
		: defaults.header.order

	const items = itemsSource.slice(0, 8).map((item, index) => {
		const fallback = defaults.menu.items[index] ?? defaults.menu.items[0]
		return {
			id: String(item.id || fallback.id || `menu-${index + 1}`).slice(0, 64),
			label: String(item.label || fallback.label || 'Вкладка')
				.trim()
				.slice(0, 30),
			icon: normalizeMenuIcon(item.icon),
			path: normalizeHomePath(item.path, fallback.path),
			requiresAuth: Boolean(item.requiresAuth),
			requiresAccess: Boolean(item.requiresAccess),
		}
	})
	const centerButton = menuSource.centerButton ?? defaults.menu.centerButton

	return {
		header: {
			enabled: Boolean(headerSource.enabled),
			showOnAllPages: Boolean(headerSource.showOnAllPages),
			order: order.length > 0 ? order : defaults.header.order,
			logoMode: headerSource.logoMode === 'text' ? 'text' : 'image',
			nameMode: headerSource.nameMode === 'club' ? 'club' : 'user',
		},
		menu: {
			items: items.length > 0 ? items : defaults.menu.items,
			centerButton: {
				enabled: Boolean(centerButton.enabled),
				icon: normalizeMenuIcon(centerButton.icon),
				imageKey: centerButton.imageKey?.trim() || null,
				imageUrl: null,
				glowEnabled: Boolean(centerButton.glowEnabled),
				pressEffectEnabled: Boolean(centerButton.pressEffectEnabled),
				actionPath: normalizeHomePath(centerButton.actionPath),
				requiresAuth: Boolean(centerButton.requiresAuth),
			},
			backgroundColor: normalizeHexColor(
				menuSource.backgroundColor,
				DEFAULT_APP_MENU_BACKGROUND_COLOR,
			),
			borderColor: normalizeOptionalHexColor(menuSource.borderColor, DEFAULT_APP_MENU_BORDER_COLOR),
			borderRadius: Math.min(Math.max(Number(menuSource.borderRadius) || 0, 0), 40),
			marginBottom: Math.min(Math.max(Number(menuSource.marginBottom) || 0, 0), 40),
			marginSide: Math.min(Math.max(Number(menuSource.marginSide) || 0, 0), 32),
			iconStrokeColor: normalizeOptionalHexColor(menuSource.iconStrokeColor, null),
			iconGlowEnabled: Boolean(menuSource.iconGlowEnabled),
			iconHighlightEnabled: Boolean(menuSource.iconHighlightEnabled),
			activeIconColor: normalizeHexColor(
				menuSource.activeIconColor,
				DEFAULT_APP_MENU_ACTIVE_ICON_COLOR,
			),
			inactiveIconColor: normalizeHexColor(
				menuSource.inactiveIconColor,
				DEFAULT_APP_MENU_INACTIVE_ICON_COLOR,
			),
			startActivePath: normalizeHomePath(menuSource.startActivePath, '/app'),
		},
	}
}

function parseStoredAppNavigationSettings(rows: SiteSettingRowLike[]): AppNavigationSettings {
	const raw = rows.find((row) => row.key === SITE_SETTING_KEYS.appNavigation)?.value
	if (!raw) return getDefaultAppNavigationSettings()
	try {
		return normalizeAppNavigationSettingsPayload(JSON.parse(raw) as AppNavigationSettings)
	} catch {
		return getDefaultAppNavigationSettings()
	}
}

function withAppNavigationMediaUrls(settings: AppNavigationSettings): AppNavigationSettings {
	return {
		...settings,
		menu: {
			...settings.menu,
			centerButton: {
				...settings.menu.centerButton,
				imageUrl: settings.menu.centerButton.imageKey
					? resolvePublicFileUrl(env.S3_BUCKET_MEDIA, settings.menu.centerButton.imageKey)
					: null,
			},
		},
	}
}

export async function loadAppNavigationSettings(): Promise<AppNavigationSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, appNavigationSettingKeys))

	return withAppNavigationMediaUrls(parseStoredAppNavigationSettings(rows))
}

export async function saveAppNavigationSettings(
	payload: AppNavigationSettings,
): Promise<AppNavigationSettings> {
	const normalized = normalizeAppNavigationSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values([
			{
				key: SITE_SETTING_KEYS.appNavigation,
				value: JSON.stringify(normalized),
				updatedAt: new Date(),
			},
		])
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadAppNavigationSettings()
}

export async function saveSiteBrandingSettings(
	payload: AdminSiteBrandingSettingsPayload,
): Promise<SiteBrandingSettings> {
	const values = serializeSiteBrandingSettings(payload)

	await db
		.insert(siteSettings)
		.values(values)
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadSiteBrandingSettings()
}

export async function loadAuthLoginSettings(): Promise<AuthLoginSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, authLoginSettingKeys))

	return parseStoredAuthLoginSettings(rows)
}

export async function loadTestAccessSettings(): Promise<TestAccessSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, testAccessSettingKeys))

	return parseStoredTestAccessSettings(rows)
}

export async function loadGuestContentAccessSettings(): Promise<GuestContentAccessSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, guestContentAccessSettingKeys))

	return parseStoredGuestContentAccessSettings(rows)
}

export async function loadTelegramBotAuthSettings(): Promise<TelegramBotAuthSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, telegramBotAuthSettingKeys))

	return parseStoredTelegramBotAuthSettings(rows)
}

export async function saveTelegramBotAuthSettings(
	payload: AdminTelegramBotAuthSettingsPayload,
): Promise<TelegramBotAuthSettings> {
	const normalized = normalizeTelegramBotAuthSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values([
			{
				key: SITE_SETTING_KEYS.telegramBotAuth,
				value: JSON.stringify(normalized),
				updatedAt: new Date(),
			},
		])
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadTelegramBotAuthSettings()
}

export async function loadLegalDocumentsSettings(): Promise<LegalDocumentsSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, legalDocumentsSettingKeys))

	return parseStoredLegalDocumentsSettings(rows)
}

export async function loadReferralProgramSettings(): Promise<ReferralProgramSettings> {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, referralProgramSettingKeys))

	return parseStoredReferralProgramSettings(rows)
}

export async function saveAuthLoginSettings(
	payload: AdminAuthLoginSettingsPayload,
): Promise<AuthLoginSettings> {
	const values = serializeAuthLoginSettings(payload)

	await db
		.insert(siteSettings)
		.values(values)
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadAuthLoginSettings()
}

export async function saveTestAccessSettings(
	payload: AdminTestAccessSettingsPayload,
): Promise<TestAccessSettings> {
	const normalized = normalizeTestAccessSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values([
			{
				key: SITE_SETTING_KEYS.testAccess,
				value: JSON.stringify(normalized),
				updatedAt: new Date(),
			},
		])
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadTestAccessSettings()
}

export async function saveGuestContentAccessSettings(
	payload: GuestContentAccessSettings,
): Promise<GuestContentAccessSettings> {
	const normalized = normalizeGuestContentAccessSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values({
			key: SITE_SETTING_KEYS.guestContentAccess,
			value: JSON.stringify(normalized),
			updatedAt: new Date(),
		})
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadGuestContentAccessSettings()
}

export async function saveReferralProgramSettings(
	payload: AdminReferralProgramSettingsPayload,
): Promise<ReferralProgramSettings> {
	const normalized = normalizeReferralProgramSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values([
			{
				key: SITE_SETTING_KEYS.referralProgram,
				value: JSON.stringify(normalized),
				updatedAt: new Date(),
			},
		])
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadReferralProgramSettings()
}

export async function saveLegalDocumentsSettings(
	payload: AdminLegalDocumentsSettingsPayload,
): Promise<LegalDocumentsSettings> {
	const normalized = normalizeLegalDocumentsSettingsPayload(payload)

	await db
		.insert(siteSettings)
		.values([
			{
				key: SITE_SETTING_KEYS.legalDocuments,
				value: JSON.stringify(normalized),
				updatedAt: new Date(),
			},
		])
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	return loadLegalDocumentsSettings()
}

export async function loadRuntimeSettings(): Promise<
	RuntimeSettings & { telegramBotToken: string; maxBotToken: string }
> {
	return loadStoredRuntimeSettings()
}

export async function loadAdminRuntimeSettings(): Promise<AdminRuntimeSettings> {
	const settings = await loadStoredRuntimeSettings()
	return {
		customDomain: settings.customDomain,
		telegramBotTokenSet: settings.telegramBotTokenSet,
		maxBotTokenSet: settings.maxBotTokenSet,
		maxApiUrl: settings.maxApiUrl,
		customDomainStatus: await checkCustomDomainStatus(settings.customDomain),
	}
}

export async function saveRuntimeSettings(
	payload: AdminRuntimeSettingsPayload,
): Promise<AdminRuntimeSettings> {
	const current = await loadStoredRuntimeSettings()
	const normalizedDomain = normalizeCustomDomain(payload.customDomain)
	const maxApiUrl = normalizeUrl(payload.maxApiUrl, env.MAX_API_URL)
	const values = [
		{
			key: SITE_SETTING_KEYS.customDomain,
			value: normalizedDomain ?? '',
			updatedAt: new Date(),
		},
		{
			key: SITE_SETTING_KEYS.maxApiUrl,
			value: maxApiUrl,
			updatedAt: new Date(),
		},
	]

	if (payload.telegramBotToken !== undefined) {
		values.push({
			key: SITE_SETTING_KEYS.telegramBotToken,
			value: encryptSecret(payload.telegramBotToken?.trim() || ''),
			updatedAt: new Date(),
		})
	}

	if (payload.maxBotToken !== undefined) {
		values.push({
			key: SITE_SETTING_KEYS.maxBotToken,
			value: encryptSecret(payload.maxBotToken?.trim() || ''),
			updatedAt: new Date(),
		})
	}

	await db
		.insert(siteSettings)
		.values(values)
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	const saved = await loadAdminRuntimeSettings()
	return {
		...saved,
		telegramBotTokenSet:
			payload.telegramBotToken === undefined
				? current.telegramBotTokenSet
				: Boolean(payload.telegramBotToken?.trim()),
		maxBotTokenSet:
			payload.maxBotToken === undefined
				? current.maxBotTokenSet
				: Boolean(payload.maxBotToken?.trim()),
	}
}

export async function getAppBaseUrl() {
	const settings = await loadStoredRuntimeSettings()
	return settings.customDomain ? `https://${settings.customDomain}` : env.APP_URL.replace(/\/$/, '')
}
