import { env } from '../config/env'
import { loadRuntimeSettings } from './site-settings'

export async function sendMaxMessage(userId: string, text: string) {
	const settings = await loadRuntimeSettings()
	const token = settings.maxBotToken || env.MAX_BOT_TOKEN
	if (!token) {
		throw new Error('MAX_BOT_TOKEN is not configured')
	}

	const search = new URLSearchParams({ user_id: userId })
	const apiUrl = (settings.maxApiUrl || env.MAX_API_URL).replace(/\/$/, '')
	const response = await fetch(`${apiUrl}/messages?${search}`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			Authorization: token,
		},
		body: JSON.stringify({
			text,
		}),
	})

	if (!response.ok) {
		const raw = await response.text().catch(() => '')
		throw new Error(`MAX request failed: ${response.status} ${raw}`)
	}

	return response.json().catch(() => null)
}
