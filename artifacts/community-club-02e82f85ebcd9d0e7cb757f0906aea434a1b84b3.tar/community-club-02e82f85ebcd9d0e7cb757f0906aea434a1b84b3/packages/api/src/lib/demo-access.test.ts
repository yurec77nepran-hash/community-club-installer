import { describe, expect, test } from 'bun:test'
import {
	DEMO_ACCESS_DAYS,
	DEMO_ACCESS_TARIFF,
	classifyDemoAccessPayments,
	getDemoAccessWindow,
	isActiveDemoAccess,
	normalizeDemoAccessEmail,
} from './demo-access'

describe('demo access', () => {
	test('normalizes guest and authenticated email to the same lock identity', () => {
		expect(normalizeDemoAccessEmail(' User@Example.COM ')).toBe('user@example.com')
	})

	test('creates a seven day access window', () => {
		const window = getDemoAccessWindow(new Date('2026-07-26T10:00:00Z'))

		expect(DEMO_ACCESS_DAYS).toBe(7)
		expect(window).toEqual({
			dateStart: '2026-07-26',
			dateFinish: '2026-08-02',
		})
	})

	test('creates a configured access window', () => {
		expect(getDemoAccessWindow(new Date('2026-07-26T10:00:00Z'), 14)).toEqual({
			dateStart: '2026-07-26',
			dateFinish: '2026-08-09',
		})
	})

	test('blocks another activation while demo access is active', () => {
		const payment = { tarrif: DEMO_ACCESS_TARIFF, dateFinish: '2026-09-08' }

		expect(isActiveDemoAccess(payment, '2026-09-08')).toBe(true)
	})

	test('allows another activation after demo access expires', () => {
		const payment = { tarrif: DEMO_ACCESS_TARIFF, dateFinish: '2026-09-07' }

		expect(isActiveDemoAccess(payment, '2026-09-08')).toBe(false)
	})

	test('does not treat another tariff as active demo access', () => {
		const payment = { tarrif: 'club-active-30d', dateFinish: '2026-09-08' }

		expect(isActiveDemoAccess(payment, '2026-09-08')).toBe(false)
	})

	test('classifies an active demo payment as idempotent demo access', () => {
		const payment = { tarrif: DEMO_ACCESS_TARIFF, dateFinish: '2026-09-08' }

		expect(classifyDemoAccessPayments([payment], '2026-09-08')).toBe('demo-active')
	})

	test('classifies an active paid payment as an existing subscription', () => {
		const payment = { tarrif: 'club-active-30d', dateFinish: '2026-09-08' }

		expect(classifyDemoAccessPayments([payment], '2026-09-08')).toBe('paid-active')
	})

	test('classifies expired or missing payments as eligible', () => {
		const expiredPayment = { tarrif: 'club-active-30d', dateFinish: '2026-09-07' }

		expect(classifyDemoAccessPayments([expiredPayment], '2026-09-08')).toBe('eligible')
		expect(classifyDemoAccessPayments([], '2026-09-08')).toBe('eligible')
	})

	test('prioritizes any active paid payment over active demo access', () => {
		const payments = [
			{ tarrif: DEMO_ACCESS_TARIFF, dateFinish: '2026-09-15' },
			{ tarrif: 'club-active-30d', dateFinish: '2026-09-10' },
		]

		expect(classifyDemoAccessPayments(payments, '2026-09-08')).toBe('paid-active')
	})
})
