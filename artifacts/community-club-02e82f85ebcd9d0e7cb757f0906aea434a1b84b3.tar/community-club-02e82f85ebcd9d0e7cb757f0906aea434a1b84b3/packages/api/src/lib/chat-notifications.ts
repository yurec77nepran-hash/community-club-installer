import { type UserRole, chatNotificationSettings, type chats } from '@community-club/shared'
import { and, eq } from 'drizzle-orm'
import { db, queryClient } from '../db/client'
import { ensureChatAccess, isSupportChatSlug } from './chat-access'
import { getRolesForChatAccess } from './chat-access-policy'
import { buildChatPushNotificationPayload } from './chat-notification-payload'
import { logger } from './logger'
import { sendPushToUsers } from './push-notifications'
import { sendTelegramMessage } from './telegram'

type ChatRecord = Pick<typeof chats.$inferSelect, 'id' | 'name' | 'slug' | 'accessRole'>

type PushRecipientRow = {
	userAuthUuid: string
}

function uniqueUserIds(userIds: string[]) {
	return Array.from(new Set(userIds.filter(Boolean)))
}

export async function getActivePushRecipientIds(params: {
	chat: ChatRecord
	authorUserId: string
	excludeUserIds?: string[]
}) {
	const excludedUserIds = uniqueUserIds([params.authorUserId, ...(params.excludeUserIds ?? [])])

	if (isSupportChatSlug(params.chat.slug)) {
		const rows = await queryClient<PushRecipientRow[]>`
			SELECT DISTINCT u.auth_uuid AS "userAuthUuid"
			FROM users u
			LEFT JOIN chat_members cm
				ON cm.chat_id = ${params.chat.id}
				AND cm.user_auth_uuid = u.auth_uuid
			LEFT JOIN chat_notification_settings cns
				ON cns.chat_id = ${params.chat.id}
				AND cns.user_auth_uuid = u.auth_uuid
			WHERE NOT (u.auth_uuid = ANY(${excludedUserIds}::uuid[]))
				AND (u.role IN ('admin', 'superadmin') OR cm.user_auth_uuid IS NOT NULL)
				AND COALESCE(cm.status, 'active') <> 'banned'
				AND COALESCE(cns.is_enabled, true) = true
		`

		return rows.map((row) => row.userAuthUuid)
	}

	const roles = getRolesForChatAccess(params.chat.accessRole)
	const isOpenClubChat = params.chat.slug === 'club-chat'
	const rows = await queryClient<PushRecipientRow[]>`
		SELECT DISTINCT u.auth_uuid AS "userAuthUuid"
		FROM users u
		LEFT JOIN chat_members cm
			ON cm.chat_id = ${params.chat.id}
			AND cm.user_auth_uuid = u.auth_uuid
		LEFT JOIN chat_notification_settings cns
			ON cns.chat_id = ${params.chat.id}
			AND cns.user_auth_uuid = u.auth_uuid
		WHERE NOT (u.auth_uuid = ANY(${excludedUserIds}::uuid[]))
			AND COALESCE(cm.status, 'active') <> 'banned'
			AND (u.role = ANY(${roles}::text[]) OR cm.role IN ('admin', 'superadmin'))
			AND COALESCE(cns.is_enabled, true) = true
			AND (
				${isOpenClubChat}
				OR
				u.role IN ('admin', 'superadmin')
				OR EXISTS (
					SELECT 1
					FROM payments p
					WHERE (p.user_auth_uuid = u.auth_uuid OR (u.email IS NOT NULL AND p.email = u.email))
						AND p.date_finish >= CURRENT_DATE
				)
			)
	`

	return rows.map((row) => row.userAuthUuid)
}

export async function filterActivePushRecipientIds(params: {
	chat: ChatRecord
	userIds: string[]
}) {
	const targetUserIds = uniqueUserIds(params.userIds)
	if (!targetUserIds.length) return []

	if (isSupportChatSlug(params.chat.slug)) {
		const rows = await queryClient<PushRecipientRow[]>`
			WITH target(user_auth_uuid) AS (
				SELECT DISTINCT unnest(${targetUserIds}::uuid[])
			)
			SELECT DISTINCT u.auth_uuid AS "userAuthUuid"
			FROM target t
			INNER JOIN users u
				ON u.auth_uuid = t.user_auth_uuid
			LEFT JOIN chat_members cm
				ON cm.chat_id = ${params.chat.id}
				AND cm.user_auth_uuid = u.auth_uuid
			LEFT JOIN chat_notification_settings cns
				ON cns.chat_id = ${params.chat.id}
				AND cns.user_auth_uuid = u.auth_uuid
			WHERE (u.role IN ('admin', 'superadmin') OR cm.user_auth_uuid IS NOT NULL)
				AND COALESCE(cm.status, 'active') <> 'banned'
				AND COALESCE(cns.is_enabled, true) = true
		`

		return rows.map((row) => row.userAuthUuid)
	}

	const roles = getRolesForChatAccess(params.chat.accessRole)
	const isOpenClubChat = params.chat.slug === 'club-chat'
	const rows = await queryClient<PushRecipientRow[]>`
		WITH target(user_auth_uuid) AS (
			SELECT DISTINCT unnest(${targetUserIds}::uuid[])
		)
		SELECT DISTINCT u.auth_uuid AS "userAuthUuid"
		FROM target t
		INNER JOIN users u
			ON u.auth_uuid = t.user_auth_uuid
		LEFT JOIN chat_members cm
			ON cm.chat_id = ${params.chat.id}
			AND cm.user_auth_uuid = u.auth_uuid
		LEFT JOIN chat_notification_settings cns
			ON cns.chat_id = ${params.chat.id}
			AND cns.user_auth_uuid = u.auth_uuid
		WHERE COALESCE(cm.status, 'active') <> 'banned'
			AND (u.role = ANY(${roles}::text[]) OR cm.role IN ('admin', 'superadmin'))
			AND COALESCE(cns.is_enabled, true) = true
			AND (
				${isOpenClubChat}
				OR
				u.role IN ('admin', 'superadmin')
				OR EXISTS (
					SELECT 1
					FROM payments p
					WHERE (p.user_auth_uuid = u.auth_uuid OR (u.email IS NOT NULL AND p.email = u.email))
						AND p.date_finish >= CURRENT_DATE
				)
			)
	`

	return rows.map((row) => row.userAuthUuid)
}

export async function getChatNotificationSettings(params: {
	chatId: number
	userId: string
	userRole: UserRole
}) {
	const access = await ensureChatAccess(params)
	if (!access.ok) {
		return { ok: false as const, code: access.code, message: access.message }
	}

	const setting = await db.query.chatNotificationSettings.findFirst({
		where: and(
			eq(chatNotificationSettings.chatId, params.chatId),
			eq(chatNotificationSettings.userAuthUuid, params.userId),
		),
		columns: {
			isEnabled: true,
		},
	})

	return {
		ok: true as const,
		enabled: setting?.isEnabled ?? true,
	}
}

export async function setChatNotificationSettings(params: {
	chatId: number
	userId: string
	userRole: UserRole
	enabled: boolean
}) {
	const access = await ensureChatAccess(params)
	if (!access.ok) {
		return { ok: false as const, code: access.code, message: access.message }
	}

	const now = new Date()
	await db
		.insert(chatNotificationSettings)
		.values({
			chatId: params.chatId,
			userAuthUuid: params.userId,
			isEnabled: params.enabled,
			updatedAt: now,
		})
		.onConflictDoUpdate({
			target: [chatNotificationSettings.userAuthUuid, chatNotificationSettings.chatId],
			set: {
				isEnabled: params.enabled,
				updatedAt: now,
			},
		})

	return {
		ok: true as const,
		enabled: params.enabled,
	}
}

export async function sendChatMessagePushNotifications(params: {
	chat: ChatRecord
	authorUserId: string
	authorName: string
	content: string
	messageType: string
	attachmentName?: string | null
	replyPreview?: string | null
	replyTargetUserId?: string | null
	mentionTargetUserIds?: string[]
	url: string
}) {
	const notifiedUserIds = new Set<string>()

	try {
		if (params.replyTargetUserId) {
			const replyTargets = await filterActivePushRecipientIds({
				chat: params.chat,
				userIds: [params.replyTargetUserId],
			})
			if (replyTargets.length > 0) {
				replyTargets.forEach((userId) => notifiedUserIds.add(userId))
				const payload = buildChatPushNotificationPayload({
					kind: 'replyToYou',
					chatName: params.chat.name,
					authorName: params.authorName,
					content: params.content,
					messageType: params.messageType,
					attachmentName: params.attachmentName,
					replyPreview: params.replyPreview,
					url: params.url,
				})
				await sendPushToUsers({
					userIds: replyTargets,
					...payload,
					context: 'chat.reply',
				})
			}
		}

		const mentionTargets = uniqueUserIds(
			(params.mentionTargetUserIds ?? []).filter(
				(userId) => userId !== params.authorUserId && !notifiedUserIds.has(userId),
			),
		)
		if (mentionTargets.length > 0) {
			const activeMentionTargets = await filterActivePushRecipientIds({
				chat: params.chat,
				userIds: mentionTargets,
			})
			if (activeMentionTargets.length > 0) {
				activeMentionTargets.forEach((userId) => notifiedUserIds.add(userId))
				const payload = buildChatPushNotificationPayload({
					kind: 'mention',
					chatName: params.chat.name,
					authorName: params.authorName,
					content: params.content,
					messageType: params.messageType,
					attachmentName: params.attachmentName,
					replyPreview: params.replyPreview,
					url: params.url,
				})
				await sendPushToUsers({
					userIds: activeMentionTargets,
					...payload,
					context: 'chat.mention',
				})
			}
		}

		const messageTargets = await getActivePushRecipientIds({
			chat: params.chat,
			authorUserId: params.authorUserId,
			excludeUserIds: Array.from(notifiedUserIds),
		})
		if (messageTargets.length > 0) {
			const payload = buildChatPushNotificationPayload({
				kind: params.replyPreview ? 'reply' : 'message',
				chatName: params.chat.name,
				authorName: params.authorName,
				content: params.content,
				messageType: params.messageType,
				attachmentName: params.attachmentName,
				replyPreview: params.replyPreview,
				url: params.url,
			})
			await sendPushToUsers({
				userIds: messageTargets,
				...payload,
				context: 'chat.message',
			})
		}
	} catch (err) {
		logger.warn(
			{ err, chatId: params.chat.id, authorUserId: params.authorUserId },
			'Failed to send chat push notifications',
		)
	}
}

type TelegramRecipientRow = {
	userAuthUuid: string
	telegramChatId: string
}

export async function sendChatMessageTelegramNotifications(params: {
	chat: ChatRecord
	authorUserId: string
	authorName: string
	content: string
	messageType: string
	attachmentName?: string | null
	replyTargetUserId?: string | null
	mentionTargetUserIds?: string[]
	url: string
}) {
	try {
		const candidates = new Set<string>()
		if (params.replyTargetUserId) candidates.add(params.replyTargetUserId)
		for (const userId of params.mentionTargetUserIds ?? []) {
			if (userId !== params.authorUserId) candidates.add(userId)
		}
		const allActive = await getActivePushRecipientIds({
			chat: params.chat,
			authorUserId: params.authorUserId,
		})
		for (const userId of allActive) candidates.add(userId)

		const userIds = Array.from(candidates).filter(Boolean)
		if (userIds.length === 0) return

		const rows = await queryClient<TelegramRecipientRow[]>`
			SELECT u.auth_uuid AS "userAuthUuid", u.telegram_chat_id AS "telegramChatId"
			FROM users u
			WHERE u.auth_uuid = ANY(${userIds}::uuid[])
				AND u.telegram_notifications_enabled = true
				AND u.telegram_chat_id IS NOT NULL
		`

		const attachmentSuffix = params.attachmentName ? `\n[вложение: ${params.attachmentName}]` : ''
		const text = `${params.chat.name}\n${params.authorName}: ${params.content.slice(0, 800)}${attachmentSuffix}`

		for (const row of rows) {
			await sendTelegramMessage(row.telegramChatId, text, {
				replyMarkup: {
					inline_keyboard: [[{ text: 'Открыть чат', url: params.url }]],
				},
			})
		}
	} catch (err) {
		logger.warn(
			{ err, chatId: params.chat.id, authorUserId: params.authorUserId },
			'Failed to send chat Telegram notifications',
		)
	}
}
