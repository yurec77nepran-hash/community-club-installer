import {
	type ChatListItem,
	type MentionCandidate,
	type MentionPayload,
	chatMembers,
	chats,
	messageMentions,
	messages,
	users,
} from '@community-club/shared'
import { and, eq, inArray, or, sql } from 'drizzle-orm'
import { db, queryClient } from '../db/client'
import { ensureChatAccess, getSupportChatSlug, isSupportChatSlug } from './chat-access'
import { getRolesForChatAccess } from './chat-access-policy'
import { normalizeChatSettings } from './chat-settings'
import { measureDbOperation } from './performance'
import { resolveAvatarUrl } from './storage'

type UserRole = 'user' | 'admin' | 'superadmin'
const MENTION_CANDIDATES_CACHE_TTL_MS = 30_000
const mentionCandidatesCache = new Map<string, { expiresAt: number; value: MentionCandidate[] }>()

function getDisplayName(candidate: Pick<MentionCandidate, 'fullName' | 'username'>) {
	return candidate.fullName?.trim() || candidate.username?.trim() || 'Пользователь'
}

function normalizeReplyPreview<
	T extends { replyTo?: ({ isDeleted?: boolean } & Record<string, unknown>) | null },
>(message: T) {
	if (!message.replyTo) return message
	if (message.replyTo.isDeleted) {
		return {
			...message,
			replyTo: null,
		}
	}
	const { isDeleted: _isDeleted, ...replyTo } = message.replyTo
	return {
		...message,
		replyTo,
	}
}

export async function getMentionCandidates(params: {
	chatId: number
	userId: string
	userRole: UserRole
}) {
	const access = await ensureChatAccess(params)
	if (!access.ok) {
		return { ok: false as const, code: access.code, message: access.message }
	}

	const cacheKey = isSupportChatSlug(access.chat.slug)
		? `support:${params.chatId}:${params.userRole}:${params.userId}`
		: `chat:${access.chat.accessRole}`
	const cached = mentionCandidatesCache.get(cacheKey)
	if (cached && cached.expiresAt > Date.now()) {
		return {
			ok: true as const,
			chat: access.chat,
			candidates: cached.value,
		}
	}

	let candidates: MentionCandidate[] = []

	if (isSupportChatSlug(access.chat.slug)) {
		const supportAdmins = await measureDbOperation(
			'chat.mentionCandidates.supportAdmins',
			{ chatId: params.chatId, userRole: params.userRole },
			() =>
				db.query.users.findMany({
					where: or(eq(users.role, 'admin'), eq(users.role, 'superadmin')),
					columns: {
						authUuid: true,
						fullName: true,
						username: true,
						avatarUrl: true,
						role: true,
					},
				}),
		)

		candidates = supportAdmins.map((user) => ({
			userAuthUuid: user.authUuid,
			fullName: user.fullName,
			username: user.username,
			avatarUrl: resolveAvatarUrl(user.avatarUrl),
			role: user.role,
			displayName: getDisplayName(user),
		}))

		if (params.userRole === 'admin' || params.userRole === 'superadmin') {
			const memberId = access.chat.slug.replace(getSupportChatSlug(''), '')
			const supportMember = await measureDbOperation(
				'chat.mentionCandidates.supportMember',
				{ chatId: params.chatId, memberId },
				() =>
					db.query.users.findFirst({
						where: eq(users.authUuid, memberId),
						columns: {
							authUuid: true,
							fullName: true,
							username: true,
							avatarUrl: true,
							role: true,
						},
					}),
			)

			if (supportMember) {
				candidates.push({
					userAuthUuid: supportMember.authUuid,
					fullName: supportMember.fullName,
					username: supportMember.username,
					avatarUrl: resolveAvatarUrl(supportMember.avatarUrl),
					role: supportMember.role,
					displayName: getDisplayName(supportMember),
				})
			}
		}
	} else {
		const roles = getRolesForChatAccess(access.chat.accessRole)
		const rows = await measureDbOperation(
			'chat.mentionCandidates.byRole',
			{ chatId: params.chatId, accessRole: access.chat.accessRole },
			() =>
				db.query.users.findMany({
					where: inArray(users.role, roles),
					columns: {
						authUuid: true,
						fullName: true,
						username: true,
						avatarUrl: true,
						role: true,
					},
				}),
		)

		candidates = rows.map((user) => ({
			userAuthUuid: user.authUuid,
			fullName: user.fullName,
			username: user.username,
			avatarUrl: resolveAvatarUrl(user.avatarUrl),
			role: user.role,
			displayName: getDisplayName(user),
		}))
	}

	const uniqueCandidates = new Map<string, MentionCandidate>()
	for (const candidate of candidates) {
		uniqueCandidates.set(candidate.userAuthUuid, candidate)
	}

	const resultCandidates = Array.from(uniqueCandidates.values()).sort((left, right) =>
		left.displayName.localeCompare(right.displayName, 'ru'),
	)
	mentionCandidatesCache.set(cacheKey, {
		expiresAt: Date.now() + MENTION_CANDIDATES_CACHE_TTL_MS,
		value: resultCandidates,
	})

	return {
		ok: true as const,
		chat: access.chat,
		candidates: resultCandidates,
	}
}

export async function normalizeMentions(params: {
	chatId: number
	userId: string
	userRole: UserRole
	content: string
	mentions: MentionPayload[] | undefined
}) {
	if (!params.mentions?.length) return []

	const candidateResult = await getMentionCandidates({
		chatId: params.chatId,
		userId: params.userId,
		userRole: params.userRole,
	})
	if (!candidateResult.ok) return []

	const candidateMap = new Map(
		candidateResult.candidates.map((candidate) => [candidate.userAuthUuid, candidate]),
	)
	const normalized = [] as (typeof messageMentions.$inferInsert)[]
	const dedupe = new Set<string>()

	for (const raw of params.mentions.slice(0, 10)) {
		const candidate = candidateMap.get(raw.userAuthUuid)
		if (!candidate) continue

		const startOffset = Math.max(0, Math.min(raw.start, params.content.length))
		const endOffset = Math.max(startOffset + 1, Math.min(raw.end, params.content.length))
		const displayName = raw.displayName.trim().slice(0, 120) || candidate.displayName
		const key = `${candidate.userAuthUuid}:${startOffset}:${endOffset}`
		if (dedupe.has(key)) continue

		dedupe.add(key)
		normalized.push({
			messageId: 0,
			mentionedUserAuthUuid: candidate.userAuthUuid,
			displayName,
			startOffset,
			endOffset,
		})
	}

	return normalized
}

export async function ensureUnreadRecipientMemberships(params: {
	chatId: number
	authorUserId: string
	messageId: number
}) {
	await measureDbOperation(
		'chat.ensureUnreadRecipientMemberships',
		{ chatId: params.chatId, messageId: params.messageId },
		() =>
			queryClient`
				WITH target_chat AS (
					SELECT id, access_role
					FROM chats
					WHERE id = ${params.chatId}
						AND type = 'chat'
						AND is_enabled = true
						AND slug NOT LIKE 'support:%'
				),
				previous_message AS (
					SELECT MAX(id)::bigint AS last_read_message_id
					FROM messages
					WHERE chat_id = ${params.chatId}
						AND is_deleted = false
						AND id < ${params.messageId}
				)
				INSERT INTO chat_members (
					chat_id,
					user_auth_uuid,
					role,
					status,
					last_read_message_id,
					unread_message_count,
					unread_mention_count
				)
				SELECT
					tc.id,
					u.auth_uuid,
					CASE WHEN u.role IN ('admin', 'superadmin') THEN 'admin' ELSE 'member' END,
					'active',
					pm.last_read_message_id,
					0,
					0
				FROM target_chat tc
				CROSS JOIN previous_message pm
				JOIN users u
					ON u.auth_uuid <> ${params.authorUserId}
					AND (
						u.role IN ('admin', 'superadmin')
						OR u.role = 'user'
					)
				ON CONFLICT (chat_id, user_auth_uuid) DO NOTHING
			`,
	)
}

export async function createMessageMentions(params: {
	chatId: number
	messageId: number
	authorUserId: string
	mentions: Array<Omit<typeof messageMentions.$inferInsert, 'messageId'>>
}) {
	if (!params.mentions.length) return []

	const inserted = await db
		.insert(messageMentions)
		.values(
			params.mentions.map((mention) => ({
				...mention,
				messageId: params.messageId,
			})),
		)
		.onConflictDoNothing()
		.returning()

	const affectedUserIds = Array.from(
		new Set(
			inserted
				.map((mention) => mention.mentionedUserAuthUuid)
				.filter((userId) => userId && userId !== params.authorUserId),
		),
	)

	if (affectedUserIds.length > 0) {
		await db
			.update(chatMembers)
			.set({
				unreadMentionCount: sql`${chatMembers.unreadMentionCount} + 1`,
			})
			.where(
				and(
					eq(chatMembers.chatId, params.chatId),
					inArray(chatMembers.userAuthUuid, affectedUserIds),
				),
			)
	}

	return inserted
}

export async function incrementUnreadMessages(params: {
	chatId: number
	authorUserId: string
}) {
	await db
		.update(chatMembers)
		.set({
			unreadMessageCount: sql`${chatMembers.unreadMessageCount} + 1`,
		})
		.where(
			and(
				eq(chatMembers.chatId, params.chatId),
				sql`${chatMembers.userAuthUuid} <> ${params.authorUserId}`,
			),
		)
}

export async function loadMessageWithMeta(messageId: number) {
	const message = await db.query.messages.findFirst({
		where: eq(messages.id, messageId),
		with: {
			reactions: true,
			mentions: true,
			author: {
				columns: { fullName: true, username: true, avatarUrl: true, chatAdminBadge: true },
			},
			replyTo: {
				columns: {
					id: true,
					userAuthUuid: true,
					content: true,
					messageType: true,
					attachmentName: true,
					isDeleted: true,
				},
				with: {
					author: {
						columns: { fullName: true, username: true },
					},
				},
			},
		},
	})

	if (!message) return null

	return normalizeReplyPreview({
		...message,
		author: message.author
			? {
					...message.author,
					avatarUrl: resolveAvatarUrl(message.author.avatarUrl),
				}
			: null,
	})
}

export async function markChatRead(params: {
	chatId: number
	userId: string
	latestMessageId?: number | null
}) {
	const nextLastReadMessageId = params.latestMessageId ?? 0
	const [row] = await queryClient<
		Array<{
			lastReadMessageId: number
			unreadMessageCount: number
			unreadMentionCount: number
		}>
	>`
		WITH next_read AS (
			SELECT GREATEST(COALESCE(last_read_message_id, 0), ${nextLastReadMessageId})::bigint AS last_read_message_id
			FROM chat_members
			WHERE chat_id = ${params.chatId}
				AND user_auth_uuid = ${params.userId}
		),
		unread_messages AS (
			SELECT COUNT(*)::int AS count
			FROM messages m
			CROSS JOIN next_read nr
			WHERE m.chat_id = ${params.chatId}
				AND m.is_deleted = false
				AND m.user_auth_uuid <> ${params.userId}
				AND m.id > nr.last_read_message_id
		),
		unread_mentions AS (
			SELECT COUNT(DISTINCT mm.message_id)::int AS count
			FROM message_mentions mm
			INNER JOIN messages m
				ON m.id = mm.message_id
			CROSS JOIN next_read nr
			WHERE mm.mentioned_user_auth_uuid = ${params.userId}
				AND m.chat_id = ${params.chatId}
				AND m.is_deleted = false
				AND m.user_auth_uuid <> ${params.userId}
				AND m.id > nr.last_read_message_id
		)
		UPDATE chat_members cm
		SET
			last_read_message_id = nr.last_read_message_id,
			unread_message_count = um.count,
			unread_mention_count = un.count
		FROM next_read nr, unread_messages um, unread_mentions un
		WHERE cm.chat_id = ${params.chatId}
			AND cm.user_auth_uuid = ${params.userId}
		RETURNING
			cm.last_read_message_id::int AS "lastReadMessageId",
			cm.unread_message_count::int AS "unreadMessageCount",
			cm.unread_mention_count::int AS "unreadMentionCount"
	`

	return (
		row ?? {
			lastReadMessageId: nextLastReadMessageId,
			unreadMessageCount: 0,
			unreadMentionCount: 0,
		}
	)
}

export async function getUnreadMentionCount(params: { chatId: number; userId: string }) {
	const member = await db.query.chatMembers.findFirst({
		where: and(eq(chatMembers.chatId, params.chatId), eq(chatMembers.userAuthUuid, params.userId)),
		columns: {
			unreadMentionCount: true,
		},
	})

	if (member) {
		return member.unreadMentionCount ?? 0
	}

	const [row] = await queryClient<{ count: number }[]>`
		SELECT COUNT(*)::int AS count
		FROM message_mentions mm
		INNER JOIN messages m
			ON m.id = mm.message_id
		LEFT JOIN chat_members cm
			ON cm.chat_id = m.chat_id
			AND cm.user_auth_uuid = ${params.userId}
		WHERE mm.mentioned_user_auth_uuid = ${params.userId}
			AND m.chat_id = ${params.chatId}
			AND m.is_deleted = false
			AND m.user_auth_uuid <> ${params.userId}
			AND m.id > COALESCE(cm.last_read_message_id, 0)
	`

	return row?.count ?? 0
}

export async function getChatListItemsForUser(params: {
	userId: string
	userRole: UserRole
}) {
	const canSeeAll = params.userRole === 'admin' || params.userRole === 'superadmin'

	const rows = await measureDbOperation(
		'chat.listItems',
		{ userId: params.userId, userRole: params.userRole },
		() =>
			queryClient<
				Array<{
					id: number
					slug: string
					name: string
					type: 'chat' | 'channel'
					accessRole: 'all'
					isEnabled: boolean
					avatarUrl: string | null
					description: string | null
					settings: unknown
					createdAt: Date
					updatedAt: Date
					lastReadMessageId: number | null
					unreadMessageCount: number
					unreadMentionCount: number
				}>
			>`
				SELECT
					c.id,
					c.slug,
					c.name,
					c.type,
					c.access_role AS "accessRole",
					c.is_enabled AS "isEnabled",
					c.avatar_url AS "avatarUrl",
					c.description,
					c.settings,
					c.created_at AS "createdAt",
					c.updated_at AS "updatedAt",
					cm.last_read_message_id::int AS "lastReadMessageId",
					COALESCE(cm.unread_message_count, 0)::int AS "unreadMessageCount",
					COALESCE(cm.unread_mention_count, 0)::int AS "unreadMentionCount"
				FROM chats c
				LEFT JOIN chat_members cm
					ON cm.chat_id = c.id
					AND cm.user_auth_uuid = ${params.userId}
				WHERE c.type = 'chat'
					AND c.is_enabled = true
					AND c.slug NOT LIKE 'support:%'
					AND COALESCE(cm.status, 'active') <> 'banned'
					AND (
						${canSeeAll}
						OR c.access_role = 'all'
						OR cm.user_auth_uuid IS NOT NULL
					)
				ORDER BY c.id ASC
			`,
	)

	return rows.map((row) => ({
		id: row.id,
		slug: row.slug,
		name: row.name,
		type: row.type,
		accessRole: row.accessRole,
		isEnabled: row.isEnabled,
		avatarUrl: resolveAvatarUrl(row.avatarUrl),
		description: row.description,
		settings: normalizeChatSettings(row.settings),
		createdAt: row.createdAt,
		updatedAt: row.updatedAt,
		lastReadMessageId: row.lastReadMessageId,
		unreadMessageCount: row.unreadMessageCount,
		unreadMentionCount: row.unreadMentionCount,
	}))
}
