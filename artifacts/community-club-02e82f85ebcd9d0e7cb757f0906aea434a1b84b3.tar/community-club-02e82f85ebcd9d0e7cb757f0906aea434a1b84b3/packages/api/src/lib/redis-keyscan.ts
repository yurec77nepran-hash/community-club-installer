type RedisScanClient = {
	scan: (
		cursor: string,
		matchKeyword: 'MATCH',
		pattern: string,
		countKeyword: 'COUNT',
		count: number,
	) => Promise<[string, string[]]>
	del: (...keys: string[]) => Promise<number>
}

export async function deleteRedisKeysByPattern(
	client: RedisScanClient,
	pattern: string,
	count = 100,
) {
	let cursor = '0'
	let deleted = 0

	do {
		const [nextCursor, keys] = await client.scan(cursor, 'MATCH', pattern, 'COUNT', count)
		cursor = nextCursor
		if (keys.length > 0) {
			deleted += await client.del(...keys)
		}
	} while (cursor !== '0')

	return deleted
}
