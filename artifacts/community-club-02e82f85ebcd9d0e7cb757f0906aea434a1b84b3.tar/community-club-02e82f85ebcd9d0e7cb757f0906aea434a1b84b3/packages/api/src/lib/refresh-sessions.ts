import { nanoid } from 'nanoid'

export type RefreshSessionTokens = {
	accessToken: string
	refreshToken: string
	expiresAt: number
}

type RedisRefreshSessionClient = {
	get: (key: string) => Promise<string | null>
	set: (...args: Array<string | number>) => Promise<unknown>
	eval: (script: string, numberOfKeys: number, ...args: string[]) => Promise<unknown>
}

const ACTIVE_REFRESH_VALUE = 'active'
const LEGACY_ACTIVE_REFRESH_VALUE = '1'
const PENDING_REFRESH_PREFIX = 'pending:'
const ROTATED_REFRESH_PREFIX = 'rotated:'

export const SESSION_MAX_AGE_SECONDS = 10 * 365 * 24 * 60 * 60
export const AUTH_COOKIE_MAX_AGE_SECONDS = 399 * 24 * 60 * 60
export const REFRESH_TOKEN_TTL_SECONDS = SESSION_MAX_AGE_SECONDS
export const REFRESH_ROTATION_GRACE_SECONDS = 15
export const REFRESH_ROTATION_WAIT_MS = 1_500
const REFRESH_ROTATION_POLL_MS = 75

const claimRefreshRotationScript = `
local raw = redis.call("GET", KEYS[1])
if not raw then
	return {"missing"}
end
if string.sub(raw, 1, string.len(ARGV[1])) == ARGV[1] then
	return {"rotated", raw}
end
if string.sub(raw, 1, string.len(ARGV[2])) == ARGV[2] then
	return {"pending"}
end
if raw == ARGV[3] or raw == ARGV[4] then
	redis.call("SET", KEYS[1], ARGV[2] .. ARGV[5], "EX", ARGV[6])
	return {"claimed"}
end
return {"missing"}
`

function sleep(ms: number) {
	return new Promise((resolve) => setTimeout(resolve, ms))
}

export function getRefreshSessionKey(userId: string, refreshToken: string) {
	return `refresh:${userId}:${refreshToken.slice(-16)}`
}

export function resolveRefreshTokenSource(params: {
	cookieToken?: string | null
	bodyToken?: string | null
}) {
	return params.cookieToken || params.bodyToken || null
}

export async function storeRefreshSession(
	client: RedisRefreshSessionClient,
	userId: string,
	refreshToken: string,
) {
	await client.set(
		getRefreshSessionKey(userId, refreshToken),
		ACTIVE_REFRESH_VALUE,
		'EX',
		REFRESH_TOKEN_TTL_SECONDS,
	)
}

export function serializeRotatedRefreshSession(tokens: RefreshSessionTokens) {
	return `${ROTATED_REFRESH_PREFIX}${JSON.stringify(tokens)}`
}

export function parseRotatedRefreshSession(value: string | null): RefreshSessionTokens | null {
	if (!value?.startsWith(ROTATED_REFRESH_PREFIX)) return null

	try {
		const parsed = JSON.parse(value.slice(ROTATED_REFRESH_PREFIX.length)) as RefreshSessionTokens
		if (
			typeof parsed.accessToken !== 'string' ||
			typeof parsed.refreshToken !== 'string' ||
			typeof parsed.expiresAt !== 'number'
		) {
			return null
		}
		return parsed
	} catch {
		return null
	}
}

function normalizeClaimResult(result: unknown) {
	if (!Array.isArray(result)) return { status: 'missing' as const }
	const [status, value] = result.map((item) => String(item))
	if (status === 'claimed') return { status: 'claimed' as const }
	if (status === 'pending') return { status: 'pending' as const }
	if (status === 'rotated') {
		return {
			status: 'rotated' as const,
			tokens: parseRotatedRefreshSession(value) ?? undefined,
		}
	}
	return { status: 'missing' as const }
}

export async function claimRefreshSessionRotation(
	client: RedisRefreshSessionClient,
	key: string,
	claimId = nanoid(16),
) {
	const result = await client.eval(
		claimRefreshRotationScript,
		1,
		key,
		ROTATED_REFRESH_PREFIX,
		PENDING_REFRESH_PREFIX,
		ACTIVE_REFRESH_VALUE,
		LEGACY_ACTIVE_REFRESH_VALUE,
		claimId,
		String(REFRESH_ROTATION_GRACE_SECONDS),
	)

	return normalizeClaimResult(result)
}

export async function storeRotatedRefreshSession(
	client: RedisRefreshSessionClient,
	key: string,
	tokens: RefreshSessionTokens,
) {
	await client.set(
		key,
		serializeRotatedRefreshSession(tokens),
		'EX',
		REFRESH_ROTATION_GRACE_SECONDS,
	)
}

export async function waitForRefreshRotationResult(
	client: RedisRefreshSessionClient,
	key: string,
	timeoutMs = REFRESH_ROTATION_WAIT_MS,
) {
	const deadline = Date.now() + timeoutMs

	while (Date.now() < deadline) {
		const tokens = parseRotatedRefreshSession(await client.get(key))
		if (tokens) return tokens
		await sleep(REFRESH_ROTATION_POLL_MS)
	}

	return null
}
