import { sql } from 'drizzle-orm'
import { db } from '../db/client'

export type TelegramBroadcastDeliveryMode = 'all' | 'unique'

function botList(botUsernames: string[]) {
	return sql`(${sql.join(
		botUsernames.map((botUsername) => sql`${botUsername}`),
		sql`, `,
	)})`
}

export async function getTelegramBroadcastAudience(botUsernames: string[]) {
	const [row] = await db.execute<{
		contacts: number
		unique_users: number
		overlap_users: number
	}>(sql`
		SELECT
			coalesce(sum(appearances), 0)::integer AS contacts,
			count(DISTINCT telegram_user_id)::integer AS unique_users,
			count(*) FILTER (WHERE appearances > 1)::integer AS overlap_users
		FROM (
			SELECT telegram_user_id, count(*) AS appearances
			FROM telegram_contacts
			WHERE bot_username IN ${botList(botUsernames)}
			GROUP BY telegram_user_id
		) contacts
	`)
	return {
		contacts: row?.contacts ?? 0,
		uniqueUsers: row?.unique_users ?? 0,
		overlapUsers: row?.overlap_users ?? 0,
	}
}

export async function createTelegramBroadcastDeliveries(params: {
	broadcastId: number
	botUsernames: string[]
	deliveryMode: TelegramBroadcastDeliveryMode
	preferredBotUsername: string | null
}) {
	const contacts = botList(params.botUsernames)
	const source =
		params.deliveryMode === 'all'
			? sql`
				SELECT id
				FROM telegram_contacts
				WHERE bot_username IN ${contacts}
			`
			: sql`
				SELECT DISTINCT ON (telegram_user_id) id
				FROM telegram_contacts
				WHERE bot_username IN ${contacts}
				ORDER BY telegram_user_id,
					CASE WHEN bot_username = ${params.preferredBotUsername} THEN 0 ELSE 1 END,
					bot_username
			`

	await db.execute(sql`
		INSERT INTO telegram_broadcast_deliveries (broadcast_id, contact_id)
		SELECT ${params.broadcastId}, id FROM (${source}) recipients
		ON CONFLICT (broadcast_id, contact_id) DO NOTHING
	`)
}
