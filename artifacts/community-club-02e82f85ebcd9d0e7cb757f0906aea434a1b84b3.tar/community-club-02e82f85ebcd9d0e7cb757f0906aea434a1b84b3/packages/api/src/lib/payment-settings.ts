import { paymentLogs, siteSettings } from '@community-club/shared'
import type {
	AdminPaymentProviderSettings,
	AdminPaymentProviderSettingsPayload,
	PaymentBillingMode,
	PaymentCheckoutSettings,
	PaymentProviderCode,
	PaymentProviderConnection,
} from '@community-club/shared/types'
import { desc, eq, inArray, sql } from 'drizzle-orm'
import { env } from '../config/env'
import { db } from '../db/client'
import { decryptSecret, encryptSecret } from './secret-vault'
import { getAppBaseUrl } from './site-settings'

const PAYMENT_PROVIDER_KEYS = {
	activeProvider: 'payment_active_provider',
	cloudpaymentsEnabled: 'payment_cloudpayments_enabled',
	cloudpaymentsPublicId: 'payment_cloudpayments_public_id',
	cloudpaymentsApiSecret: 'payment_cloudpayments_api_secret',
	prodamusEnabled: 'payment_prodamus_enabled',
	prodamusPaymentUrl: 'payment_prodamus_payment_url',
	prodamusSubscriptionId: 'payment_prodamus_subscription_id',
	prodamusSecretKey: 'payment_prodamus_secret_key',
	yookassaEnabled: 'payment_yookassa_enabled',
	yookassaShopId: 'payment_yookassa_shop_id',
	yookassaSecretKey: 'payment_yookassa_secret_key',
	tochkaEnabled: 'payment_tochka_enabled',
	tochkaCustomerCode: 'payment_tochka_customer_code',
	tochkaMerchantId: 'payment_tochka_merchant_id',
	tochkaClientId: 'payment_tochka_client_id',
	tochkaPaymentModes: 'payment_tochka_payment_modes',
	tochkaJwtToken: 'payment_tochka_jwt_token',
	foreignCardsEnabled: 'payment_foreign_cards_enabled',
	billingMode: 'payment_billing_mode',
	recurrentInterval: 'payment_recurrent_interval',
	recurrentPeriod: 'payment_recurrent_period',
	recurrentMaxPeriods: 'payment_recurrent_max_periods',
	recurrentStartDelayDays: 'payment_recurrent_start_delay_days',
	requisitesEnabled: 'payment_requisites_enabled',
	requisitesName: 'payment_requisites_name',
	requisitesTaxId: 'payment_requisites_tax_id',
	requisitesRegistrationId: 'payment_requisites_registration_id',
	requisitesAddress: 'payment_requisites_address',
	manualPaymentEnabled: 'payment_manual_enabled',
} as const

const paymentProviderSettingKeys = Object.values(PAYMENT_PROVIDER_KEYS)

type StoredPaymentProviderSettings = {
	activeProvider: PaymentProviderCode
	cloudpayments: {
		enabled: boolean
		publicId: string
		apiSecret: string
	}
	prodamus: {
		enabled: boolean
		paymentUrl: string
		subscriptionId: string
		secretKey: string
	}
	yookassa: {
		enabled: boolean
		shopId: string
		secretKey: string
	}
	tochka: {
		enabled: boolean
		customerCode: string
		merchantId: string
		clientId: string
		paymentModes: string
		jwtToken: string
	}
	checkout: PaymentCheckoutSettings
	manualPaymentEnabled: boolean
}

function isProvider(value: unknown): value is PaymentProviderCode {
	return (
		value === 'cloudpayments' || value === 'prodamus' || value === 'yookassa' || value === 'tochka'
	)
}

function normalizeBoolean(value: string | null | undefined, fallback = false) {
	if (value == null) return fallback
	return value.trim() === 'true'
}

function normalizeUrl(value: unknown) {
	const raw = String(value ?? '').trim()
	if (!raw) return ''
	try {
		const url = new URL(raw)
		if (url.protocol !== 'https:' && url.protocol !== 'http:') return ''
		return url.toString().replace(/\/$/, '')
	} catch {
		return ''
	}
}

function normalizeText(value: unknown, maxLength = 4096) {
	return String(value ?? '')
		.trim()
		.slice(0, maxLength)
}

function normalizeBillingMode(value: unknown): PaymentBillingMode {
	return value === 'one_time' ? 'one_time' : 'recurrent'
}

function normalizeRecurrentInterval(value: unknown): PaymentCheckoutSettings['recurrentInterval'] {
	return value === 'Day' || value === 'Week' || value === 'Month' ? value : 'tariff'
}

function normalizeInteger(value: unknown, fallback: number, min: number, max: number) {
	const numeric = Number(value)
	if (!Number.isFinite(numeric)) return fallback
	return Math.min(max, Math.max(min, Math.trunc(numeric)))
}

function normalizeNullableInteger(value: unknown, min: number, max: number) {
	const raw = String(value ?? '').trim()
	if (!raw) return null
	const numeric = Number(raw)
	if (!Number.isFinite(numeric)) return null
	return Math.min(max, Math.max(min, Math.trunc(numeric)))
}

function getStringField(fields: Record<string, string | boolean | null>, key: string) {
	const value = fields[key]
	return typeof value === 'string' ? value : ''
}

function parseStoredSettings(
	rows: Array<{ key: string; value: string | null }>,
): StoredPaymentProviderSettings {
	const values = new Map(rows.map((row) => [row.key, row.value ?? '']))
	const activeProvider = values.get(PAYMENT_PROVIDER_KEYS.activeProvider)

	return {
		activeProvider: isProvider(activeProvider) ? activeProvider : 'cloudpayments',
		cloudpayments: {
			enabled: normalizeBoolean(values.get(PAYMENT_PROVIDER_KEYS.cloudpaymentsEnabled), true),
			publicId:
				values.get(PAYMENT_PROVIDER_KEYS.cloudpaymentsPublicId)?.trim() ||
				env.CLOUDPAYMENTS_PUBLIC_ID,
			apiSecret:
				decryptSecret(values.get(PAYMENT_PROVIDER_KEYS.cloudpaymentsApiSecret)) ||
				env.CLOUDPAYMENTS_API_SECRET,
		},
		prodamus: {
			enabled: normalizeBoolean(values.get(PAYMENT_PROVIDER_KEYS.prodamusEnabled), false),
			paymentUrl: normalizeUrl(values.get(PAYMENT_PROVIDER_KEYS.prodamusPaymentUrl)),
			subscriptionId: values.get(PAYMENT_PROVIDER_KEYS.prodamusSubscriptionId)?.trim() || '',
			secretKey: decryptSecret(values.get(PAYMENT_PROVIDER_KEYS.prodamusSecretKey)),
		},
		yookassa: {
			enabled: normalizeBoolean(values.get(PAYMENT_PROVIDER_KEYS.yookassaEnabled), false),
			shopId: values.get(PAYMENT_PROVIDER_KEYS.yookassaShopId)?.trim() || '',
			secretKey: decryptSecret(values.get(PAYMENT_PROVIDER_KEYS.yookassaSecretKey)),
		},
		tochka: {
			enabled: normalizeBoolean(values.get(PAYMENT_PROVIDER_KEYS.tochkaEnabled), false),
			customerCode: values.get(PAYMENT_PROVIDER_KEYS.tochkaCustomerCode)?.trim() || '',
			merchantId: values.get(PAYMENT_PROVIDER_KEYS.tochkaMerchantId)?.trim() || '',
			clientId: values.get(PAYMENT_PROVIDER_KEYS.tochkaClientId)?.trim() || '',
			paymentModes: values.get(PAYMENT_PROVIDER_KEYS.tochkaPaymentModes)?.trim() || 'card,sbp',
			jwtToken: decryptSecret(values.get(PAYMENT_PROVIDER_KEYS.tochkaJwtToken)),
		},
		checkout: {
			foreignCardsEnabled: normalizeBoolean(
				values.get(PAYMENT_PROVIDER_KEYS.foreignCardsEnabled),
				false,
			),
			billingMode: normalizeBillingMode(values.get(PAYMENT_PROVIDER_KEYS.billingMode)),
			recurrentInterval: normalizeRecurrentInterval(
				values.get(PAYMENT_PROVIDER_KEYS.recurrentInterval),
			),
			recurrentPeriod: normalizeInteger(
				values.get(PAYMENT_PROVIDER_KEYS.recurrentPeriod),
				1,
				1,
				365,
			),
			recurrentMaxPeriods: normalizeNullableInteger(
				values.get(PAYMENT_PROVIDER_KEYS.recurrentMaxPeriods),
				1,
				120,
			),
			recurrentStartDelayDays: normalizeNullableInteger(
				values.get(PAYMENT_PROVIDER_KEYS.recurrentStartDelayDays),
				1,
				3650,
			),
			requisitesEnabled: normalizeBoolean(
				values.get(PAYMENT_PROVIDER_KEYS.requisitesEnabled),
				true,
			),
			requisitesName:
				values.get(PAYMENT_PROVIDER_KEYS.requisitesName)?.trim() || 'ИП [ФИО или юрлицо]',
			requisitesTaxId:
				values.get(PAYMENT_PROVIDER_KEYS.requisitesTaxId)?.trim() || 'ИНН 000000000000',
			requisitesRegistrationId:
				values.get(PAYMENT_PROVIDER_KEYS.requisitesRegistrationId)?.trim() || '',
			requisitesAddress:
				values.get(PAYMENT_PROVIDER_KEYS.requisitesAddress)?.trim() || 'город регистрации',
		},
		manualPaymentEnabled: normalizeBoolean(
			values.get(PAYMENT_PROVIDER_KEYS.manualPaymentEnabled),
			false,
		),
	}
}

async function loadStoredSettings() {
	const rows = await db
		.select({
			key: siteSettings.key,
			value: siteSettings.value,
		})
		.from(siteSettings)
		.where(inArray(siteSettings.key, paymentProviderSettingKeys))

	return parseStoredSettings(rows)
}

function buildProvider(params: {
	provider: PaymentProviderCode
	label: string
	enabled: boolean
	connected: boolean
	isActive: boolean
	fields: Record<string, string | boolean>
	secretFields: Record<string, boolean>
	webhooks: PaymentProviderConnection['webhooks']
	diagnostics?: PaymentProviderConnection['diagnostics']
}): PaymentProviderConnection {
	return params
}

async function loadProviderDiagnostics(provider: PaymentProviderCode) {
	const [lastWebhook, lastSuccess, lastFailure] = await Promise.all([
		db.query.paymentLogs.findFirst({
			where: eq(paymentLogs.webhookType, provider),
			orderBy: [desc(paymentLogs.createdAt)],
		}),
		db.query.paymentLogs.findFirst({
			where: sql`${paymentLogs.webhookType} = ${provider} and ${paymentLogs.status} = 'success'`,
			orderBy: [desc(paymentLogs.createdAt)],
		}),
		db.query.paymentLogs.findFirst({
			where: sql`${paymentLogs.webhookType} = ${provider} and ${paymentLogs.status} in ('failed', 'rejected', 'critical')`,
			orderBy: [desc(paymentLogs.createdAt)],
		}),
	])

	return {
		lastWebhookAt: lastWebhook?.createdAt?.toISOString() ?? null,
		lastSuccessAt: lastSuccess?.createdAt?.toISOString() ?? null,
		lastFailureAt: lastFailure?.createdAt?.toISOString() ?? null,
		lastStatus: lastWebhook?.status ?? null,
		lastErrorMessage: lastFailure?.errorMessage ?? null,
	}
}

export async function loadPaymentProviderSettings(): Promise<AdminPaymentProviderSettings> {
	const [
		settings,
		appBaseUrl,
		cloudpaymentsDiagnostics,
		prodamusDiagnostics,
		yookassaDiagnostics,
		tochkaDiagnostics,
	] = await Promise.all([
		loadStoredSettings(),
		getAppBaseUrl(),
		loadProviderDiagnostics('cloudpayments'),
		loadProviderDiagnostics('prodamus'),
		loadProviderDiagnostics('yookassa'),
		loadProviderDiagnostics('tochka'),
	])
	const baseUrl = appBaseUrl.replace(/\/$/, '')

	return {
		activeProvider: settings.activeProvider,
		checkout: settings.checkout,
		providers: [
			buildProvider({
				provider: 'cloudpayments',
				label: 'CloudPayments',
				enabled: settings.cloudpayments.enabled,
				connected: Boolean(settings.cloudpayments.publicId && settings.cloudpayments.apiSecret),
				isActive: settings.activeProvider === 'cloudpayments',
				fields: {
					publicId: settings.cloudpayments.publicId,
				},
				secretFields: {
					apiSecret: Boolean(settings.cloudpayments.apiSecret),
				},
				diagnostics: cloudpaymentsDiagnostics,
				webhooks: [
					{ label: 'Check', url: `${baseUrl}/api/payments/webhook/check` },
					{ label: 'Pay', url: `${baseUrl}/api/payments/webhook/pay` },
					{ label: 'Fail', url: `${baseUrl}/api/payments/webhook/fail` },
					{ label: 'Recurrent', url: `${baseUrl}/api/payments/webhook/recurrent` },
					{ label: 'Cancel', url: `${baseUrl}/api/payments/webhook/cancel` },
				],
			}),
			buildProvider({
				provider: 'prodamus',
				label: 'Продамус',
				enabled: settings.prodamus.enabled,
				connected: Boolean(settings.prodamus.paymentUrl && settings.prodamus.secretKey),
				isActive: settings.activeProvider === 'prodamus',
				fields: {
					paymentUrl: settings.prodamus.paymentUrl,
					subscriptionId: settings.prodamus.subscriptionId,
				},
				secretFields: {
					secretKey: Boolean(settings.prodamus.secretKey),
				},
				diagnostics: prodamusDiagnostics,
				webhooks: [{ label: 'Webhook', url: `${baseUrl}/api/payments/webhook/prodamus` }],
			}),
			buildProvider({
				provider: 'yookassa',
				label: 'ЮKassa',
				enabled: settings.yookassa.enabled,
				connected: Boolean(settings.yookassa.shopId && settings.yookassa.secretKey),
				isActive: settings.activeProvider === 'yookassa',
				fields: {
					shopId: settings.yookassa.shopId,
				},
				secretFields: {
					secretKey: Boolean(settings.yookassa.secretKey),
				},
				diagnostics: yookassaDiagnostics,
				webhooks: [{ label: 'Webhook', url: `${baseUrl}/api/payments/webhook/yookassa` }],
			}),
			buildProvider({
				provider: 'tochka',
				label: 'Точка Банк',
				enabled: settings.tochka.enabled,
				connected: Boolean(settings.tochka.customerCode && settings.tochka.jwtToken),
				isActive: settings.activeProvider === 'tochka',
				fields: {
					customerCode: settings.tochka.customerCode,
					merchantId: settings.tochka.merchantId,
					clientId: settings.tochka.clientId,
					paymentModes: settings.tochka.paymentModes,
				},
				secretFields: {
					jwtToken: Boolean(settings.tochka.jwtToken),
				},
				diagnostics: tochkaDiagnostics,
				webhooks: [{ label: 'Webhook', url: `${baseUrl}/api/payments/webhook/tochka` }],
			}),
		],
		manualPaymentEnabled: settings.manualPaymentEnabled,
	}
}

export async function savePaymentProviderSettings(
	payload: AdminPaymentProviderSettingsPayload,
): Promise<AdminPaymentProviderSettings> {
	const current = await loadStoredSettings()
	const byProvider = new Map(payload.providers.map((provider) => [provider.provider, provider]))
	const activeProvider = isProvider(payload.activeProvider)
		? payload.activeProvider
		: 'cloudpayments'
	const cloudpayments = byProvider.get('cloudpayments')
	const prodamus = byProvider.get('prodamus')
	const yookassa = byProvider.get('yookassa')
	const tochka = byProvider.get('tochka')
	const checkout = payload.checkout ?? current.checkout
	const values = [
		{
			key: PAYMENT_PROVIDER_KEYS.activeProvider,
			value: activeProvider,
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.cloudpaymentsEnabled,
			value: cloudpayments?.enabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.cloudpaymentsPublicId,
			value: normalizeText(getStringField(cloudpayments?.fields ?? {}, 'publicId')),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.prodamusEnabled,
			value: prodamus?.enabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.prodamusPaymentUrl,
			value: normalizeUrl(getStringField(prodamus?.fields ?? {}, 'paymentUrl')),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.prodamusSubscriptionId,
			value: normalizeText(getStringField(prodamus?.fields ?? {}, 'subscriptionId'), 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.yookassaEnabled,
			value: yookassa?.enabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.yookassaShopId,
			value: normalizeText(getStringField(yookassa?.fields ?? {}, 'shopId'), 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.tochkaEnabled,
			value: tochka?.enabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.tochkaCustomerCode,
			value: normalizeText(getStringField(tochka?.fields ?? {}, 'customerCode'), 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.tochkaMerchantId,
			value: normalizeText(getStringField(tochka?.fields ?? {}, 'merchantId'), 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.tochkaClientId,
			value: normalizeText(getStringField(tochka?.fields ?? {}, 'clientId'), 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.tochkaPaymentModes,
			value: normalizeText(getStringField(tochka?.fields ?? {}, 'paymentModes'), 255) || 'card,sbp',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.foreignCardsEnabled,
			value: checkout.foreignCardsEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.billingMode,
			value: normalizeBillingMode(checkout.billingMode),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.recurrentInterval,
			value: normalizeRecurrentInterval(checkout.recurrentInterval),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.recurrentPeriod,
			value: String(normalizeInteger(checkout.recurrentPeriod, 1, 1, 365)),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.recurrentMaxPeriods,
			value: normalizeNullableInteger(checkout.recurrentMaxPeriods, 1, 120)?.toString() ?? '',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.recurrentStartDelayDays,
			value: normalizeNullableInteger(checkout.recurrentStartDelayDays, 1, 3650)?.toString() ?? '',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.requisitesEnabled,
			value: checkout.requisitesEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.requisitesName,
			value: normalizeText(checkout.requisitesName, 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.requisitesTaxId,
			value: normalizeText(checkout.requisitesTaxId, 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.requisitesRegistrationId,
			value: normalizeText(checkout.requisitesRegistrationId, 255),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.requisitesAddress,
			value: normalizeText(checkout.requisitesAddress, 500),
			updatedAt: new Date(),
		},
		{
			key: PAYMENT_PROVIDER_KEYS.manualPaymentEnabled,
			value: payload.manualPaymentEnabled ? 'true' : 'false',
			updatedAt: new Date(),
		},
	]

	const cloudpaymentsSecret = cloudpayments?.secretFields?.apiSecret
	if (cloudpaymentsSecret !== undefined) {
		values.push({
			key: PAYMENT_PROVIDER_KEYS.cloudpaymentsApiSecret,
			value: encryptSecret(normalizeText(cloudpaymentsSecret)),
			updatedAt: new Date(),
		})
	}

	const prodamusSecret = prodamus?.secretFields?.secretKey
	if (prodamusSecret !== undefined) {
		values.push({
			key: PAYMENT_PROVIDER_KEYS.prodamusSecretKey,
			value: encryptSecret(normalizeText(prodamusSecret)),
			updatedAt: new Date(),
		})
	}

	const yookassaSecret = yookassa?.secretFields?.secretKey
	if (yookassaSecret !== undefined) {
		values.push({
			key: PAYMENT_PROVIDER_KEYS.yookassaSecretKey,
			value: encryptSecret(normalizeText(yookassaSecret)),
			updatedAt: new Date(),
		})
	}

	const tochkaSecret = tochka?.secretFields?.jwtToken
	if (tochkaSecret !== undefined) {
		values.push({
			key: PAYMENT_PROVIDER_KEYS.tochkaJwtToken,
			value: encryptSecret(normalizeText(tochkaSecret)),
			updatedAt: new Date(),
		})
	}

	await db
		.insert(siteSettings)
		.values(values)
		.onConflictDoUpdate({
			target: siteSettings.key,
			set: {
				value: sql`excluded.value`,
				updatedAt: sql`excluded.updated_at`,
			},
		})

	const saved = await loadPaymentProviderSettings()
	return {
		...saved,
		providers: saved.providers.map((provider) => {
			if (provider.provider === 'cloudpayments' && cloudpaymentsSecret === undefined) {
				return {
					...provider,
					secretFields: { apiSecret: Boolean(current.cloudpayments.apiSecret) },
				}
			}
			if (provider.provider === 'prodamus' && prodamusSecret === undefined) {
				return { ...provider, secretFields: { secretKey: Boolean(current.prodamus.secretKey) } }
			}
			if (provider.provider === 'yookassa' && yookassaSecret === undefined) {
				return { ...provider, secretFields: { secretKey: Boolean(current.yookassa.secretKey) } }
			}
			if (provider.provider === 'tochka' && tochkaSecret === undefined) {
				return { ...provider, secretFields: { jwtToken: Boolean(current.tochka.jwtToken) } }
			}
			return provider
		}),
	}
}

export async function loadPaymentProviderSecrets() {
	return loadStoredSettings()
}

export async function loadPaymentCheckoutSettings() {
	const settings = await loadStoredSettings()
	return {
		...settings.checkout,
		manualPaymentEnabled: settings.manualPaymentEnabled,
	}
}

export async function getActivePaymentProvider() {
	const settings = await loadStoredSettings()
	const provider = settings[settings.activeProvider]
	return {
		code: settings.activeProvider,
		enabled: provider.enabled,
		connected:
			settings.activeProvider === 'cloudpayments'
				? Boolean(settings.cloudpayments.publicId && settings.cloudpayments.apiSecret)
				: settings.activeProvider === 'prodamus'
					? Boolean(settings.prodamus.paymentUrl && settings.prodamus.secretKey)
					: settings.activeProvider === 'yookassa'
						? Boolean(settings.yookassa.shopId && settings.yookassa.secretKey)
						: Boolean(settings.tochka.customerCode && settings.tochka.jwtToken),
		settings: provider,
	}
}

export async function getCloudPaymentsCredentials() {
	const settings = await loadStoredSettings()
	return settings.cloudpayments
}
