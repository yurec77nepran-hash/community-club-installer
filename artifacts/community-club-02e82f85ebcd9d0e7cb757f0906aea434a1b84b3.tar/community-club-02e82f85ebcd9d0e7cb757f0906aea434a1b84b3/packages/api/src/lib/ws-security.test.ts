import { describe, expect, test } from 'bun:test'
import { extractWsAuthToken, isAllowedWsOrigin, isWsPayloadWithinLimit } from './ws-security'

describe('websocket security helpers', () => {
	test('extracts the token from cookies instead of the URL query', () => {
		const request = new Request('https://club.example.com/ws', {
			headers: { cookie: 'theme=dark; access_token=session-token; other=1' },
		})

		expect(extractWsAuthToken(request)).toBe('session-token')
	})

	test('keeps legacy bearer support but rejects query token transport', () => {
		const bearerRequest = new Request('https://club.example.com/ws', {
			headers: { authorization: 'Bearer bearer-token' },
		})
		const queryRequest = new Request('https://club.example.com/ws?token=query-token')

		expect(extractWsAuthToken(bearerRequest)).toBe('bearer-token')
		expect(extractWsAuthToken(queryRequest)).toBeNull()
	})

	test('accepts only configured browser origins', () => {
		expect(
			isAllowedWsOrigin('https://club.example.com', [
				'https://club.example.com',
				'https://admin.example.com',
			]),
		).toBe(true)
		expect(
			isAllowedWsOrigin('https://evil.example.net', [
				'https://club.example.com',
				'https://admin.example.com',
			]),
		).toBe(false)
	})

	test('bounds websocket message payload size before JSON parsing', () => {
		expect(isWsPayloadWithinLimit('x'.repeat(16), 16)).toBe(true)
		expect(isWsPayloadWithinLimit('x'.repeat(17), 16)).toBe(false)
		expect(isWsPayloadWithinLimit(new Uint8Array(17), 16)).toBe(false)
	})
})
