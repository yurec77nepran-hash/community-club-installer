import { spawn } from 'node:child_process'
import { createReadStream, createWriteStream } from 'node:fs'
import { mkdtemp, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { extname, join } from 'node:path'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'

type UploadFileBody = ArrayBuffer | Buffer | Uint8Array | Readable | ReadableStream<Uint8Array>

type PreparedVideoUpload = {
	body: Readable
	size: number
	optimized: boolean
	cleanup: () => Promise<void>
}

const FASTSTART_VIDEO_EXTENSIONS = new Set(['.mp4', '.mov', '.m4v'])
const FASTSTART_VIDEO_CONTENT_TYPES = new Set(['video/mp4', 'video/quicktime', 'video/x-m4v'])

function normalizeContentType(contentType: string | null | undefined) {
	return contentType?.split(';')[0]?.trim().toLowerCase() ?? ''
}

export function isFaststartVideoCandidate(
	fileName: string,
	contentType: string | null | undefined,
) {
	const extension = extname(fileName).toLowerCase()
	return (
		FASTSTART_VIDEO_EXTENSIONS.has(extension) ||
		FASTSTART_VIDEO_CONTENT_TYPES.has(normalizeContentType(contentType))
	)
}

async function writeBodyToFile(body: UploadFileBody, targetPath: string) {
	if (body instanceof ArrayBuffer) {
		await writeFile(targetPath, new Uint8Array(body))
		return
	}
	if (body instanceof Uint8Array) {
		await writeFile(targetPath, body)
		return
	}
	if (body instanceof ReadableStream) {
		await pipeline(
			Readable.fromWeb(body as Parameters<typeof Readable.fromWeb>[0]),
			createWriteStream(targetPath),
		)
		return
	}
	await pipeline(body, createWriteStream(targetPath))
}

function runFfmpegFaststart(inputPath: string, outputPath: string) {
	return new Promise<void>((resolve, reject) => {
		const ffmpeg = spawn(process.env.FFMPEG_PATH || 'ffmpeg', [
			'-hide_banner',
			'-loglevel',
			'error',
			'-y',
			'-i',
			inputPath,
			'-c',
			'copy',
			'-movflags',
			'+faststart',
			outputPath,
		])
		let stderr = ''

		ffmpeg.stderr.on('data', (chunk) => {
			stderr += String(chunk)
		})
		ffmpeg.on('error', reject)
		ffmpeg.on('close', (code) => {
			if (code === 0) {
				resolve()
				return
			}
			reject(new Error(stderr.trim() || `ffmpeg exited with code ${code}`))
		})
	})
}

export async function prepareVideoUploadForStreaming(params: {
	fileName: string
	body: UploadFileBody
	size: number | null
}): Promise<PreparedVideoUpload> {
	const tempDir = await mkdtemp(join(tmpdir(), 'community-club-video-faststart-'))
	const extension = extname(params.fileName).toLowerCase() || '.mp4'
	const inputPath = join(tempDir, `input${extension}`)
	const outputPath = join(tempDir, `output${extension}`)
	const cleanup = () => rm(tempDir, { recursive: true, force: true })

	await writeBodyToFile(params.body, inputPath)

	try {
		await runFfmpegFaststart(inputPath, outputPath)
		const outputStat = await stat(outputPath)
		return {
			body: createReadStream(outputPath),
			size: outputStat.size,
			optimized: true,
			cleanup,
		}
	} catch {
		return {
			body: createReadStream(inputPath),
			size: params.size ?? (await stat(inputPath)).size,
			optimized: false,
			cleanup,
		}
	}
}
