import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { GetObjectCommand } from '@aws-sdk/client-s3'
import { logger } from './logger'
import { s3, uploadFile } from './storage'

const PDF_CONTENT_TYPES = new Set(['application/pdf', 'application/x-pdf'])

export function isPdfUpload(fileName: string, contentType: string | null | undefined) {
	const normalizedType = contentType?.toLowerCase().trim()
	if (normalizedType && PDF_CONTENT_TYPES.has(normalizedType)) return true
	return fileName.toLowerCase().endsWith('.pdf')
}

export async function optimizePdfBuffer(params: {
	buffer: ArrayBuffer
	fileName: string
}): Promise<ArrayBuffer> {
	const tempDir = await mkdtemp(join(tmpdir(), 'community-club-pdf-'))
	const inputPath = join(tempDir, sanitizePdfFileName(params.fileName, 'input.pdf'))
	const outputPath = join(tempDir, 'optimized.pdf')

	try {
		await Bun.write(inputPath, params.buffer)

		const process = Bun.spawn([
			'qpdf',
			'--warning-exit-0',
			'--linearize',
			'--object-streams=generate',
			'--recompress-flate',
			'--compression-level=9',
			inputPath,
			outputPath,
		])

		const exitCode = await process.exited
		if (exitCode !== 0) {
			const stderr = await new Response(process.stderr).text()
			logger.warn(
				{ exitCode, fileName: params.fileName, stderr: stderr.slice(0, 1000) },
				'PDF optimization skipped: qpdf exited with non-zero status',
			)
			return params.buffer
		}

		const optimized = await readFile(outputPath)
		if (!optimized.byteLength) {
			logger.warn({ fileName: params.fileName }, 'PDF optimization skipped: empty output')
			return params.buffer
		}

		return optimized.buffer.slice(
			optimized.byteOffset,
			optimized.byteOffset + optimized.byteLength,
		) as ArrayBuffer
	} catch (error) {
		logger.warn({ err: error, fileName: params.fileName }, 'PDF optimization skipped')
		return params.buffer
	} finally {
		await rm(tempDir, { recursive: true, force: true }).catch(() => undefined)
	}
}

export async function optimizeStoredPdfObject(params: { bucket: string; key: string }) {
	const object = await s3.send(
		new GetObjectCommand({
			Bucket: params.bucket,
			Key: params.key,
		}),
	)

	if (!object.Body) {
		throw new Error('PDF object body is empty')
	}

	const contentType = object.ContentType ?? 'application/pdf'
	if (!isPdfUpload(params.key, contentType)) {
		throw new Error('Only PDF files can be optimized')
	}

	const sourceBuffer = await new Response(object.Body as BodyInit).arrayBuffer()
	const optimizedBuffer = await optimizePdfBuffer({
		buffer: sourceBuffer,
		fileName: params.key.split('/').pop() ?? 'document.pdf',
	})

	await uploadFile(params.bucket, params.key, optimizedBuffer, contentType)

	return {
		key: params.key,
		beforeSize: sourceBuffer.byteLength,
		afterSize: optimizedBuffer.byteLength,
		changed: !arrayBuffersEqual(sourceBuffer, optimizedBuffer),
	}
}

function sanitizePdfFileName(fileName: string, fallback: string) {
	const normalized = fileName.replace(/[^a-zA-Z0-9._-]/g, '_')
	return normalized.endsWith('.pdf') ? normalized : fallback
}

function arrayBuffersEqual(left: ArrayBuffer, right: ArrayBuffer) {
	if (left.byteLength !== right.byteLength) return false
	const leftView = new Uint8Array(left)
	const rightView = new Uint8Array(right)
	for (let index = 0; index < leftView.length; index += 1) {
		if (leftView[index] !== rightView[index]) return false
	}
	return true
}
