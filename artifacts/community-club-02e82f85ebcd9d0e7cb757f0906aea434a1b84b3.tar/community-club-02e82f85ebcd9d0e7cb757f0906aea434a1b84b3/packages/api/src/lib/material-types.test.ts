import { describe, expect, test } from 'bun:test'
import {
	buildMaterialTypeKey,
	getDefaultMaterialTypeLabel,
	getMaterialTypeQueryKeys,
	normalizeMaterialTypeKey,
} from './material-types'

describe('material type keys', () => {
	test('uses stable keys for default Russian material sections', () => {
		expect(buildMaterialTypeKey('Курсы')).toBe('courses')
		expect(buildMaterialTypeKey('Эфиры')).toBe('streams')
		expect(buildMaterialTypeKey('Чек-листы')).toBe('checklists')
		expect(buildMaterialTypeKey('Чек листы')).toBe('checklists')
		expect(buildMaterialTypeKey('Прочее')).toBe('other')
	})

	test('normalizes legacy transliterated default section keys', () => {
		expect(normalizeMaterialTypeKey('kursy')).toBe('courses')
		expect(normalizeMaterialTypeKey('efiry')).toBe('streams')
		expect(normalizeMaterialTypeKey('chek-listy')).toBe('checklists')
		expect(normalizeMaterialTypeKey('prochee')).toBe('other')
	})

	test('keeps custom section keys and resolves default labels', () => {
		expect(buildMaterialTypeKey('Записи клуба')).toBe('zapisi-kluba')
		expect(normalizeMaterialTypeKey('zapisi-kluba')).toBe('zapisi-kluba')
		expect(getDefaultMaterialTypeLabel('courses')).toBe('Курсы')
		expect(getDefaultMaterialTypeLabel('zapisi-kluba')).toBeNull()
	})

	test('builds query keys for canonical and legacy default sections', () => {
		expect(getMaterialTypeQueryKeys('courses')).toEqual(['courses', 'kursy'])
		expect(getMaterialTypeQueryKeys('zapisi-kluba')).toEqual(['zapisi-kluba'])
	})
})
