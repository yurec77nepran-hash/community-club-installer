import { queryClient } from '../db/client'
import { logger } from './logger'

export const DEFAULT_CLUB_CHAT = {
	slug: 'club-chat',
	name: 'Чат клуба',
	type: 'chat',
	accessRole: 'all',
	isEnabled: true,
	description: 'Общий чат участников клуба',
	settings: {
		allowMemberMessages: true,
		allowAttachments: true,
		allowReactions: true,
		slowModeSeconds: 0,
		welcomeText: null,
	},
} as const

export async function ensureChatSchemaArtifacts() {
	await queryClient`
		ALTER TABLE users
		ADD COLUMN IF NOT EXISTS first_entry boolean NOT NULL DEFAULT false
	`

	await queryClient`
		ALTER TABLE messages
		ADD COLUMN IF NOT EXISTS client_message_id text
	`

	await queryClient`
		ALTER TABLE chats
		ADD COLUMN IF NOT EXISTS is_enabled boolean NOT NULL DEFAULT true
	`

	await queryClient`
		ALTER TABLE chats
		ADD COLUMN IF NOT EXISTS avatar_url text
	`

	await queryClient`
		ALTER TABLE chats
		ADD COLUMN IF NOT EXISTS description text
	`

	await queryClient`
		ALTER TABLE chats
		ADD COLUMN IF NOT EXISTS settings jsonb NOT NULL DEFAULT '{}'::jsonb
	`

	await queryClient`
		ALTER TABLE chats
		ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now()
	`

	await queryClient`
		UPDATE chats
		SET access_role = 'all'
		WHERE access_role <> 'all'
	`

	await queryClient`
		INSERT INTO chats (
			slug,
			name,
			type,
			access_role,
			is_enabled,
			description,
			settings
		)
		VALUES (
			${DEFAULT_CLUB_CHAT.slug},
			${DEFAULT_CLUB_CHAT.name},
			${DEFAULT_CLUB_CHAT.type},
			${DEFAULT_CLUB_CHAT.accessRole},
			${DEFAULT_CLUB_CHAT.isEnabled},
			${DEFAULT_CLUB_CHAT.description},
			${JSON.stringify(DEFAULT_CLUB_CHAT.settings)}::jsonb
		)
		ON CONFLICT (slug) DO NOTHING
	`

	await queryClient`
		ALTER TABLE chat_members
		ADD COLUMN IF NOT EXISTS last_read_message_id bigint
	`

	await queryClient`
		ALTER TABLE chat_members
		ADD COLUMN IF NOT EXISTS unread_message_count integer NOT NULL DEFAULT 0
	`

	await queryClient`
		ALTER TABLE chat_members
		ADD COLUMN IF NOT EXISTS unread_mention_count integer NOT NULL DEFAULT 0
	`

	await queryClient`
		CREATE TABLE IF NOT EXISTS message_mentions (
			id serial PRIMARY KEY,
			message_id bigint NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
			mentioned_user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
			display_name text NOT NULL,
			start_offset integer NOT NULL,
			end_offset integer NOT NULL,
		created_at timestamptz NOT NULL DEFAULT now()
		)
	`

	await queryClient`
		CREATE TABLE IF NOT EXISTS scheduled_chat_messages (
			id serial PRIMARY KEY,
			chat_id integer NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
			author_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
			content text NOT NULL,
			mentions jsonb NOT NULL DEFAULT '[]'::jsonb,
			scheduled_at timestamptz NOT NULL,
			status text NOT NULL DEFAULT 'scheduled',
			error_message text,
			sent_message_id bigint,
			processing_started_at timestamptz,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`

	await queryClient`
		CREATE TABLE IF NOT EXISTS chat_notification_settings (
			id serial PRIMARY KEY,
			chat_id integer NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
			user_auth_uuid uuid NOT NULL REFERENCES users(auth_uuid) ON DELETE CASCADE,
			is_enabled boolean NOT NULL DEFAULT true,
			created_at timestamptz NOT NULL DEFAULT now(),
			updated_at timestamptz NOT NULL DEFAULT now()
		)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS messages_chat_id_id_idx
		ON messages (chat_id, id DESC)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS messages_chat_id_deleted_id_idx
		ON messages (chat_id, is_deleted, id DESC)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS messages_user_client_message_idx
		ON messages (user_auth_uuid, client_message_id)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS message_reactions_message_id_idx
		ON message_reactions (message_id)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS chat_members_chat_id_role_idx
		ON chat_members (chat_id, role)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS chats_enabled_type_idx
		ON chats (is_enabled, type)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS chat_members_user_unread_messages_idx
		ON chat_members (user_auth_uuid, unread_message_count)
	`

	await queryClient`
		CREATE UNIQUE INDEX IF NOT EXISTS message_mention_unique
		ON message_mentions (message_id, mentioned_user_auth_uuid, start_offset, end_offset)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS message_mentions_message_id_idx
		ON message_mentions (message_id)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS message_mentions_user_idx
		ON message_mentions (mentioned_user_auth_uuid, message_id)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS scheduled_chat_messages_chat_scheduled_idx
		ON scheduled_chat_messages (chat_id, status, scheduled_at)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS scheduled_chat_messages_due_idx
		ON scheduled_chat_messages (status, scheduled_at)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS scheduled_chat_messages_author_idx
		ON scheduled_chat_messages (author_auth_uuid, created_at DESC)
	`

	await queryClient`
		CREATE UNIQUE INDEX IF NOT EXISTS chat_notification_settings_user_chat_unique
		ON chat_notification_settings (user_auth_uuid, chat_id)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS chat_notification_settings_chat_enabled_idx
		ON chat_notification_settings (chat_id, is_enabled)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS chat_notification_settings_user_idx
		ON chat_notification_settings (user_auth_uuid)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS materials_active_type_created_idx
		ON materials (active, type, created_at DESC)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS materials_active_type_subsection_created_idx
		ON materials (active, type, subsection, created_at DESC)
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS materials_active_created_id_idx
		ON materials (active, created_at DESC, id DESC)
	`

	await queryClient`
		ALTER TABLE events
		ADD COLUMN IF NOT EXISTS image_url text
	`

	await queryClient`
		CREATE INDEX IF NOT EXISTS events_event_date_idx
		ON events (event_date)
	`

	logger.info('Realtime and content DB artifacts ensured')
}
