import Redis from 'ioredis'
import { env } from '../config/env'

export const redis = new Redis(env.REDIS_URL, {
	maxRetriesPerRequest: 3,
	retryStrategy(times) {
		if (times > 10) return null
		return Math.min(times * 200, 2000)
	},
})

// Отдельный клиент для pub/sub (subscriber не может выполнять другие команды)
export const redisSub = new Redis(env.REDIS_URL, {
	maxRetriesPerRequest: 3,
})

export const redisPub = new Redis(env.REDIS_URL, {
	maxRetriesPerRequest: 3,
})
