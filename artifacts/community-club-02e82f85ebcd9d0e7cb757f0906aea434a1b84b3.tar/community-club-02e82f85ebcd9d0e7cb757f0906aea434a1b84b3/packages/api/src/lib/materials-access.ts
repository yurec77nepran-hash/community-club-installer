export type ClubAccessMap = Record<string, boolean>

export function buildClubAccessMap(): ClubAccessMap {
	return {}
}

export function hasTypeAccess(params: {
	type: string
	userRole: string
	contentSections: string[]
	clubAccess?: ClubAccessMap
}) {
	void params
	return true
}

export function getMaterialsAccessScope(params: {
	userRole: string
	contentSections: string[]
	clubAccess?: ClubAccessMap
}) {
	void params
	return 'member'
}
