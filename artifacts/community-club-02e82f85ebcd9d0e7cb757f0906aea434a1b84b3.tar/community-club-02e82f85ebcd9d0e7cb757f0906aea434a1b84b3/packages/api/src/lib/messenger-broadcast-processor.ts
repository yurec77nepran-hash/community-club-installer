import {
	messengerBroadcastDeliveries,
	messengerBroadcasts,
	messengerConnections,
	telegramBroadcastPlainText,
} from '@community-club/shared'
import { and, eq, lte, sql } from 'drizzle-orm'
import { db } from '../db/client'
import { logger } from './logger'
import { sendMessengerText } from './messenger-channel'

const PROCESSOR_INTERVAL_MS = 15_000
let started = false
let running = false

async function refreshStats(id: number) {
	const [stats] = await db.execute<{
		audience_size: number
		sent_count: number
		failed_count: number
	}>(sql`
		SELECT count(*)::integer AS audience_size,
			count(*) FILTER (WHERE status = 'sent')::integer AS sent_count,
			count(*) FILTER (WHERE status = 'failed')::integer AS failed_count
		FROM messenger_broadcast_deliveries WHERE broadcast_id = ${id}
	`)
	return stats ?? { audience_size: 0, sent_count: 0, failed_count: 0 }
}

async function finish(id: number) {
	const stats = await refreshStats(id)
	await db
		.update(messengerBroadcasts)
		.set({
			status: stats.audience_size && !stats.sent_count ? 'failed' : 'completed',
			audienceSize: stats.audience_size,
			sentCount: stats.sent_count,
			failedCount: stats.failed_count,
			processingStartedAt: null,
			updatedAt: new Date(),
		})
		.where(eq(messengerBroadcasts.id, id))
}

async function createDeliveries(id: number, connectionIds: number[]) {
	await db.execute(sql`
		INSERT INTO messenger_broadcast_deliveries (broadcast_id, contact_id)
		SELECT ${id}, id FROM messenger_contacts
		WHERE connection_id IN (${sql.join(
			connectionIds.map((value) => sql`${value}`),
			sql`, `,
		)})
			AND consent_status = 'active'
		ON CONFLICT (broadcast_id, contact_id) DO NOTHING
	`)
}

async function processBroadcast(broadcast: typeof messengerBroadcasts.$inferSelect) {
	await createDeliveries(broadcast.id, broadcast.connectionIds)
	const plainText = telegramBroadcastPlainText(broadcast.body)
	while (true) {
		const current = await db.query.messengerBroadcasts.findFirst({
			columns: { status: true },
			where: eq(messengerBroadcasts.id, broadcast.id),
		})
		if (current?.status !== 'processing') return
		const [delivery] = await db.execute<{
			id: number
			external_user_id: string
			connection_id: number
		}>(sql`
			SELECT delivery.id, contact.external_user_id, contact.connection_id
			FROM messenger_broadcast_deliveries delivery
			JOIN messenger_contacts contact ON contact.id = delivery.contact_id
			WHERE delivery.broadcast_id = ${broadcast.id} AND delivery.status = 'pending'
			ORDER BY delivery.id LIMIT 1
		`)
		if (!delivery) break
		const [claimed] = await db
			.update(messengerBroadcastDeliveries)
			.set({ status: 'processing', updatedAt: new Date() })
			.where(
				and(
					eq(messengerBroadcastDeliveries.id, delivery.id),
					eq(messengerBroadcastDeliveries.status, 'pending'),
				),
			)
			.returning({ id: messengerBroadcastDeliveries.id })
		if (!claimed) continue
		let delayMs = 100
		try {
			const connection = await db.query.messengerConnections.findFirst({
				where: eq(messengerConnections.id, delivery.connection_id),
			})
			if (!connection || !connection.isActive) throw new Error('Подключение недоступно')
			delayMs = connection.provider === 'max' ? 500 : 100
			await sendMessengerText({
				connection,
				recipientId: delivery.external_user_id,
				body: broadcast.body,
				plainText,
			})
			await db
				.update(messengerBroadcastDeliveries)
				.set({ status: 'sent', sentAt: new Date(), updatedAt: new Date() })
				.where(eq(messengerBroadcastDeliveries.id, delivery.id))
		} catch (error) {
			const errorMessage = error instanceof Error ? error.message.slice(0, 1000) : 'Ошибка отправки'
			await db
				.update(messengerBroadcastDeliveries)
				.set({ status: 'failed', errorMessage, updatedAt: new Date() })
				.where(eq(messengerBroadcastDeliveries.id, delivery.id))
		}
		await Bun.sleep(delayMs)
	}
	await finish(broadcast.id)
}

async function tick() {
	if (running) return
	running = true
	try {
		const broadcast = await db.query.messengerBroadcasts.findFirst({
			where: and(
				eq(messengerBroadcasts.status, 'scheduled'),
				lte(messengerBroadcasts.sendAt, new Date()),
			),
			orderBy: (table, { asc }) => [asc(table.sendAt)],
		})
		if (!broadcast) return
		const [claimed] = await db
			.update(messengerBroadcasts)
			.set({ status: 'processing', processingStartedAt: new Date(), updatedAt: new Date() })
			.where(
				and(eq(messengerBroadcasts.id, broadcast.id), eq(messengerBroadcasts.status, 'scheduled')),
			)
			.returning()
		if (claimed) await processBroadcast(claimed)
	} catch (error) {
		logger.error({ err: error }, 'Messenger broadcast processor failed')
	} finally {
		running = false
	}
}

export function startMessengerBroadcastProcessor() {
	if (started) return
	started = true
	void tick()
	setInterval(() => void tick(), PROCESSOR_INTERVAL_MS).unref?.()
}
