import { describe, expect, test } from 'bun:test'
import {
	buildCloudPaymentsIdempotencyKey,
	redactPaymentWebhookPayload,
	validateWebhookAmount,
} from './payment-webhook-utils'

describe('buildCloudPaymentsIdempotencyKey', () => {
	test('uses transaction id as the strongest webhook identity', () => {
		expect(
			buildCloudPaymentsIdempotencyKey('pay', {
				AccountId: 'user-1',
				InvoiceId: 'tariff:user-1:1',
				TransactionId: 12345,
			}),
		).toBe('cloudpayments:pay:transaction:12345')
	})

	test('falls back to subscription and invoice data for recurrent events', () => {
		expect(
			buildCloudPaymentsIdempotencyKey('recurrent', {
				AccountId: 'user-1',
				InvoiceId: 'tariff:user-1:1',
				SubscriptionId: 'sub-1',
				Amount: 1990,
			}),
		).toBe('cloudpayments:recurrent:subscription:sub-1:invoice:tariff:user-1:1:amount:1990')
	})

	test('returns null when webhook has no stable identity', () => {
		expect(buildCloudPaymentsIdempotencyKey('pay', { AccountId: 'user-1' })).toBeNull()
	})
})

describe('validateWebhookAmount', () => {
	test('accepts equal decimal and integer amount representations', () => {
		expect(validateWebhookAmount({ expected: '1990.00', received: 1990 }).ok).toBe(true)
		expect(validateWebhookAmount({ expected: '19,90', received: '19.9' }).ok).toBe(true)
	})

	test('rejects mismatched payment amounts before granting access', () => {
		const result = validateWebhookAmount({ expected: '1990', received: '1' })
		expect(result.ok).toBe(false)
		expect(result.expectedMinor).toBe(199000)
		expect(result.receivedMinor).toBe(100)
	})
})

describe('redactPaymentWebhookPayload', () => {
	test('removes card tokens and masks personal contact data in logs', () => {
		const redacted = redactPaymentWebhookPayload({
			Token: 'card-token',
			CardCryptogramPacket: 'cryptogram',
			Email: 'person@example.com',
			Phone: '+79991234567',
			nested: { cpToken: 'nested-token', amount: 1990 },
		})

		expect(redacted.Token).toBe('[redacted]')
		expect(redacted.CardCryptogramPacket).toBe('[redacted]')
		expect(redacted.Email).toBe('p***@example.com')
		expect(redacted.Phone).toBe('+79***67')
		expect((redacted.nested as Record<string, unknown>).cpToken).toBe('[redacted]')
		expect((redacted.nested as Record<string, unknown>).amount).toBe(1990)
	})
})
