import { z } from 'zod'
import { getDefaultHomeExperienceSettings } from './site-settings'

const homeStoryOverlaySchema = z.object({
	id: z.string().max(64),
	type: z.enum(['text', 'image', 'button']),
	x: z.number().min(0).max(100),
	y: z.number().min(0).max(100),
	width: z.number().min(5).max(100),
	text: z.string().trim().max(500),
	textColor: z.string().max(32),
	fontSize: z.number().min(12).max(64),
	align: z.enum(['left', 'center', 'right']),
	mediaKey: z.string().max(1024).nullable(),
	mediaUrl: z.string().nullable().optional(),
	borderRadius: z.number().min(0).max(40),
	opacity: z.number().min(0).max(100),
	label: z.string().trim().max(40),
	backgroundColor: z.string().max(32),
	borderColor: z.string().max(32).nullable(),
	borderWidth: z.number().min(0).max(8),
	action: z.enum(['none', 'link', 'section']),
	linkUrl: z.string().max(2048),
	section: z.string().max(32),
})

const homeStorySchema = z.object({
	id: z.string().max(64),
	title: z.string().trim().max(80),
	text: z.string().trim().max(500),
	layout: z.enum(['text', 'image', 'imageText']),
	backgroundColor: z.string().max(32),
	textColor: z.string().max(32),
	mediaKey: z.string().max(1024).nullable(),
	mediaUrl: z.string().nullable().optional(),
	durationMs: z.number().min(2500).max(15000),
	imageScale: z.number().min(0.1).max(3).default(1),
	imageX: z.number().min(-100).max(100).default(0),
	imageY: z.number().min(-100).max(100).default(0),
	overlays: z.array(homeStoryOverlaySchema).max(20).default([]),
})

const homeHighlightSchema = z.object({
	id: z.string().max(64),
	title: z.string().trim().max(80),
	stories: z.array(homeStorySchema).min(1).max(20),
})

const homeBannerSchema = z.object({
	id: z.string().max(64),
	title: z.string().trim().max(80),
	subtitle: z.string().trim().max(120),
	backgroundColor: z.string().max(32),
	textColor: z.string().max(32),
	mediaKey: z.string().max(1024).nullable(),
	mediaUrl: z.string().nullable().optional(),
	actionKind: z.enum(['stories', 'internal', 'external']),
	internalPath: z.string().max(160),
	externalUrl: z.string().max(2048),
	requiresAuth: z.boolean(),
	storiesEnabled: z.boolean(),
})

const homeMainBannerSchema = z.object({
	mediaKey: z.string().max(1024).nullable(),
	mediaUrl: z.string().nullable().optional().default(null),
	alt: z.string().trim().min(1).max(160),
})

const homeSectionSchema = z.object({
	id: z.string().max(64),
	title: z.string().trim().max(80),
	subtitle: z.string().trim().max(120),
	backgroundColor: z.string().max(32),
	textColor: z.string().max(32),
	mediaKey: z.string().max(1024).nullable(),
	mediaUrl: z.string().nullable().optional(),
	icon: z.string().max(32),
	visualMode: z.enum(['color', 'icon', 'image']),
	textMode: z.enum(['visible', 'hidden']),
	actionKind: z.enum(['internal', 'external']),
	internalPath: z.string().max(160),
	externalUrl: z.string().max(2048),
	requiresAuth: z.boolean(),
})

const homeCustomPageBlockSchema = z.object({
	id: z.string().max(64),
	kind: z.enum(['heading', 'text', 'image', 'video', 'button']),
	title: z.string().trim().max(120),
	text: z.string().trim().max(2000),
	mediaKey: z.string().max(1024).nullable(),
	mediaUrl: z.string().nullable().optional(),
	buttonLabel: z.string().trim().max(80),
	buttonUrl: z.string().max(2048),
	backgroundColor: z.string().max(32),
	textColor: z.string().max(32),
	borderRadius: z.number().min(0).max(40),
	size: z.enum(['sm', 'md', 'lg']),
})

const homeCustomPageSchema = z.object({
	id: z.string().max(64),
	slug: z.string().trim().max(80),
	title: z.string().trim().max(100),
	backgroundColor: z.string().max(32),
	textColor: z.string().max(32),
	blocks: z.array(homeCustomPageBlockSchema).max(40),
})

export const homeExperienceSettingsSchema = z.object({
	mainBanner: homeMainBannerSchema.default(getDefaultHomeExperienceSettings().mainBanner),
	banners: z.array(homeBannerSchema).min(1).max(12),
	bannerShape: z.enum(['rounded', 'circle']).default('rounded'),
	stories: z.array(homeStorySchema).max(20).default([]),
	highlights: z.array(homeHighlightSchema).max(5).default([]),
	sectionLayout: z.enum(['featured', 'equalOneRow', 'equalTwoRows']),
	sections: z.array(homeSectionSchema).min(1).max(12),
	customPages: z.array(homeCustomPageSchema).max(20),
})
