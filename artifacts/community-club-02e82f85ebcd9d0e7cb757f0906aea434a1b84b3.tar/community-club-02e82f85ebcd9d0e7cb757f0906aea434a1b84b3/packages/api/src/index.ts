import { app } from './app'
import { env } from './config/env'
import { ensureChatSchemaArtifacts } from './lib/chat-bootstrap'
import { pruneExpiredChunkedUploadSessions } from './lib/chunked-upload-temp'
import { ensureFeedArtifacts } from './lib/feed-bootstrap'
import { logger } from './lib/logger'
import { ensureMaterialCommentsArtifacts } from './lib/material-comments-bootstrap'
import { ensureMediaLibraryArtifacts } from './lib/media-library-bootstrap'
import { ensureMessengerBroadcastArtifacts } from './lib/messenger-broadcast-bootstrap'
import { startMessengerBroadcastProcessor } from './lib/messenger-broadcast-processor'
import { ensurePerformanceArtifacts } from './lib/performance-bootstrap'
import { ensurePricingMatrixArtifacts } from './lib/pricing-matrix-bootstrap'
import { startPushCampaignProcessor } from './lib/push-campaign-processor'
import { ensurePushCampaignArtifacts } from './lib/push-campaigns-bootstrap'
import { ensurePwaInstallationArtifacts } from './lib/pwa-installation-bootstrap'
import { ensureReferralArtifacts } from './lib/referrals-bootstrap'
import { startScheduledChatMessageProcessor } from './lib/scheduled-chat-messages'
import { ensureSiteSettingsArtifacts } from './lib/site-settings-bootstrap'
import { startSubscriptionExpiryProcessor } from './lib/subscription-expiry-processor'
import { ensureTelegramWebhook } from './lib/telegram'
import { startTelegramAudioPoller } from './lib/telegram-audio-poller'
import { ensureTelegramBroadcastArtifacts } from './lib/telegram-broadcast-bootstrap'
import { startTelegramBroadcastProcessor } from './lib/telegram-broadcast-processor'
import {
	type WSData,
	handleWSClose,
	handleWSMessage,
	handleWSOpen,
	handleWSUpgrade,
	initRedisSubscriber,
} from './ws/handler'

const MAX_REQUEST_BODY_BYTES = 3 * 1024 * 1024 * 1024
const CHUNKED_UPLOAD_TEMP_MAX_AGE_MS = 24 * 60 * 60 * 1000

if (!env.APP_READ_ONLY) {
	await ensureChatSchemaArtifacts()
	await ensureFeedArtifacts()
	await ensureMaterialCommentsArtifacts()
	await ensureMediaLibraryArtifacts()
	await ensurePushCampaignArtifacts()
	await ensurePerformanceArtifacts()
	await ensurePricingMatrixArtifacts()
	await ensurePwaInstallationArtifacts()
	await ensureSiteSettingsArtifacts()
	await ensureReferralArtifacts()
	await ensureTelegramWebhook()
	await ensureTelegramBroadcastArtifacts()
	await ensureMessengerBroadcastArtifacts()

	// Инициализация Redis pub/sub для WebSocket
	initRedisSubscriber()
	startPushCampaignProcessor()
	startScheduledChatMessageProcessor()
	startSubscriptionExpiryProcessor()
	startTelegramAudioPoller()
	startTelegramBroadcastProcessor()
	startMessengerBroadcastProcessor()
	void pruneExpiredChunkedUploadSessions({ maxAgeMs: CHUNKED_UPLOAD_TEMP_MAX_AGE_MS }).catch(
		(error) => logger.warn({ err: error }, 'Chunked upload temp cleanup failed'),
	)
	setInterval(
		() =>
			void pruneExpiredChunkedUploadSessions({ maxAgeMs: CHUNKED_UPLOAD_TEMP_MAX_AGE_MS }).catch(
				(error) => logger.warn({ err: error }, 'Chunked upload temp cleanup failed'),
			),
		60 * 60 * 1000,
	).unref?.()
} else {
	logger.info(
		'API read-only mode enabled: startup writes, jobs, webhook sync, and websocket pub/sub are disabled',
	)
}

const server = Bun.serve({
	port: env.PORT,
	maxRequestBodySize: MAX_REQUEST_BODY_BYTES,
	fetch: async (req, server) => {
		// WebSocket upgrade
		if (req.url.includes('/ws')) {
			if (env.APP_READ_ONLY) {
				return new Response('Read-only staging does not support WebSocket connections', {
					status: 503,
				})
			}
			const auth = await handleWSUpgrade(req)
			if (!auth) {
				return new Response('Нужна авторизация', { status: 401 })
			}
			const wsData: WSData = {
				userId: auth.userId,
				userRole: auth.userRole,
				profile: auth.profile,
				connectionId: '',
				rooms: new Set<string>(),
				typingCooldownUntil: new Map(),
				accessCache: new Map(),
			}
			const success = server.upgrade(req, { data: wsData })
			if (success) return undefined
			return new Response('Системная ошибка. Обратитесь в поддержку.', { status: 500 })
		}

		// Hono HTTP
		return app.fetch(req)
	},
	websocket: {
		open: handleWSOpen,
		close: handleWSClose,
		message: handleWSMessage,
	},
})

logger.info(`API server running on http://localhost:${server.port}`)
