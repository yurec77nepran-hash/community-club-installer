import * as schema from '@community-club/shared'
import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import { env } from '../config/env'
import { logSlowSql } from '../lib/performance'

const queryClient = postgres(env.DATABASE_URL, {
	max: 20,
	idle_timeout: 20,
	connect_timeout: 10,
})

const originalUnsafe = queryClient.unsafe.bind(queryClient)

queryClient.unsafe = ((query: string, params?: unknown[], ...rest: unknown[]) => {
	const startedAt = performance.now()
	const result = originalUnsafe(query, params as never, ...(rest as []))

	if (result && typeof (result as Promise<unknown>).then === 'function') {
		void (result as Promise<unknown>)
			.then(() => {
				logSlowSql({
					query,
					params: Array.isArray(params) ? params : [],
					durationMs: Math.round(performance.now() - startedAt),
				})
			})
			.catch(() => {
				logSlowSql({
					query,
					params: Array.isArray(params) ? params : [],
					durationMs: Math.round(performance.now() - startedAt),
					error: true,
				})
			})
	}

	return result
}) as typeof queryClient.unsafe

export const db = drizzle(queryClient, { schema })
export { queryClient }
export type Database = typeof db
