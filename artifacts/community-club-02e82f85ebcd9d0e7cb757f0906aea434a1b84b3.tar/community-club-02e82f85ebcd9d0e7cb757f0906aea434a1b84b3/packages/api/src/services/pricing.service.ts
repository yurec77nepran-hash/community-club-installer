import { pricingMatrix } from '@community-club/shared'
import type { PaymentTariffOffer, PricingContext } from '@community-club/shared'
import { eq } from 'drizzle-orm'
import { db } from '../db/client'

type PricingRole = 'club'
type DurationKey = 30 | 90 | 365
const CLUB_PRICING_ROLE: PricingRole = 'club'

type PricingContextParams = {
	role: PricingRole
	firstEntry: boolean
	hasPaymentHistory: boolean
	hasActiveSubscription: boolean
}

function asMoney(value: unknown) {
	const numeric = Number(value ?? 0)
	if (!Number.isFinite(numeric) || numeric < 0) return '0'
	return String(Math.round(numeric * 100) / 100)
}

function resolveDurationName(durationDays: number) {
	if (durationDays === 30) return '30 дней'
	if (durationDays === 90) return '90 дней'
	if (durationDays === 365) return '12 месяцев'
	return `${durationDays} дней`
}

function pickRegularPrice(
	row: typeof pricingMatrix.$inferSelect,
	context: PricingContext,
	durationDays: DurationKey,
	cardType: 'russian' | 'foreign',
) {
	const suffix = cardType === 'foreign' ? 'foreign' : 'base'
	const map = {
		base: {
			active: {
				30: row.activeMonthPrice,
				90: row.active90DaysPrice,
				365: row.active365DaysPrice,
			},
			former: {
				30: row.formerMonthPrice,
				90: row.former90DaysPrice,
				365: row.former365DaysPrice,
			},
			external: {
				30: row.externalMonthPrice,
				90: row.external90DaysPrice,
				365: row.external365DaysPrice,
			},
			intro: {
				30: row.activeMonthPrice,
				90: row.active90DaysPrice,
				365: row.active365DaysPrice,
			},
		},
		foreign: {
			active: {
				30: row.foreignActiveMonthPrice,
				90: row.foreignActive90DaysPrice,
				365: row.foreignActive365DaysPrice,
			},
			former: {
				30: row.foreignFormerMonthPrice,
				90: row.foreignFormer90DaysPrice,
				365: row.foreignFormer365DaysPrice,
			},
			external: {
				30: row.foreignExternalMonthPrice,
				90: row.foreignExternal90DaysPrice,
				365: row.foreignExternal365DaysPrice,
			},
			intro: {
				30: row.foreignActiveMonthPrice,
				90: row.foreignActive90DaysPrice,
				365: row.foreignActive365DaysPrice,
			},
		},
	} as const

	return asMoney(map[suffix][context][durationDays])
}

function pickFirstPrice(
	row: typeof pricingMatrix.$inferSelect,
	context: PricingContext,
	durationDays: DurationKey,
	cardType: 'russian' | 'foreign',
) {
	if (durationDays !== 30) return null
	if (context === 'intro') {
		return asMoney(
			cardType === 'foreign' ? row.foreignDemoFirstMonthPrice : row.demoFirstMonthPrice,
		)
	}
	if (context === 'external') {
		return asMoney(
			cardType === 'foreign' ? row.foreignExternalFirstMonthPrice : row.externalFirstMonthPrice,
		)
	}
	return null
}

export function resolvePricingContext(params: PricingContextParams): PricingContext {
	void params.role
	void params.firstEntry
	if (params.hasActiveSubscription) return 'active'
	if (params.hasPaymentHistory) return 'former'
	return 'active'
}

export function shouldShowPriceFirst(context: PricingContext) {
	return context === 'external'
}

export async function getPricingMatrixByRole(role: PricingRole) {
	void role
	return db.query.pricingMatrix.findFirst({
		where: eq(pricingMatrix.role, CLUB_PRICING_ROLE),
	})
}

export async function getPricingMatrixMap() {
	const rows = await db.query.pricingMatrix.findMany({
		orderBy: (table, { asc }) => [asc(table.role)],
	})

	return {
		club: rows.find((item) => item.role === CLUB_PRICING_ROLE) ?? null,
	}
}

export function buildTariffOffers(params: {
	row: typeof pricingMatrix.$inferSelect
	role: PricingRole
	context: PricingContext
}) {
	const durations: DurationKey[] = [30, 90, 365]

	return durations.map((durationDays, index) => {
		const regularPrice = pickRegularPrice(params.row, params.context, durationDays, 'russian')
		const firstPrice = pickFirstPrice(params.row, params.context, durationDays, 'russian')

		const item: PaymentTariffOffer = {
			id: `club-${params.context}-${durationDays}`,
			name: `Клуб • ${resolveDurationName(durationDays)}`,
			slug: `club-${params.context}-${durationDays}d`,
			role: 'club',
			durationDays,
			price: regularPrice,
			priceFirst: params.context === 'external' ? firstPrice : null,
			discountPrice: null,
			foreignDiscountPrice: null,
			demoDays: 0,
			description: null,
			isActive: true,
			sortOrder: index,
			tier: params.context === 'external' ? 2 : 1,
			pricingContext: params.context,
		}

		return item
	})
}

export function resolveOfferAmount(params: {
	offer: PaymentTariffOffer
	cardType: 'russian' | 'foreign'
}) {
	void params.cardType

	if (params.offer.pricingContext === 'external') {
		const first = Number(params.offer.priceFirst ?? 0)
		return Number.isFinite(first) && first > 0 ? first : Number(params.offer.price)
	}

	return Number(params.offer.price ?? 0)
}
