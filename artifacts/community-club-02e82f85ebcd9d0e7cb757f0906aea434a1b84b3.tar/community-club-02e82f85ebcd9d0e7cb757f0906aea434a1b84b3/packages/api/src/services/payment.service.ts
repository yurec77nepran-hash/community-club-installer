import { timingSafeEqual } from 'node:crypto'
import { getCloudPaymentsCredentials } from '../lib/payment-settings'

const CP_API_URL = 'https://api.cloudpayments.ru'
const CP_REQUEST_TIMEOUT_MS = 10_000

export async function hasCloudPaymentsCredentials() {
	const credentials = await getCloudPaymentsCredentials()
	return Boolean(
		credentials.publicId &&
			credentials.apiSecret &&
			credentials.publicId !== 'placeholder' &&
			credentials.apiSecret !== 'placeholder',
	)
}

async function getAuthHeader(): Promise<string> {
	const credentials = await getCloudPaymentsCredentials()
	return `Basic ${btoa(`${credentials.publicId}:${credentials.apiSecret}`)}`
}

async function cpRequest<T>(path: string, body: Record<string, unknown>): Promise<T> {
	const response = await fetch(`${CP_API_URL}${path}`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			Authorization: await getAuthHeader(),
		},
		signal: AbortSignal.timeout(CP_REQUEST_TIMEOUT_MS),
		body: JSON.stringify(body),
	})
	const text = await response.text()

	try {
		return JSON.parse(text) as T
	} catch {
		return {
			Success: false,
			Message: text.trim() || `CloudPayments returned HTTP ${response.status}`,
			Model: {
				status: response.status,
				contentType: response.headers.get('content-type'),
				raw: text.slice(0, 1000),
			},
		} as T
	}
}

export interface CPResponse {
	Success: boolean
	Message: string | null
	Model?: unknown
}

interface CPOrderLinkModel {
	Id?: string
	Url?: string
}

interface CPOrderLinkResponse extends CPResponse {
	Model?: CPOrderLinkModel
}

// Создание одиночного платежа (Charge)
export async function createCharge(params: {
	amount: number
	currency: string
	accountId: string
	description: string
	token: string
}): Promise<CPResponse> {
	return cpRequest('/payments/cards/charge', {
		Amount: params.amount,
		Currency: params.currency,
		AccountId: params.accountId,
		Description: params.description,
		Token: params.token,
	})
}

// Создание рекуррентного платежа
export async function createRecurrent(params: {
	token: string
	accountId: string
	description: string
	amount: number
	currency?: string
	startDate: string
	interval: string
	period: number
}): Promise<CPResponse> {
	return cpRequest('/subscriptions/create', {
		Token: params.token,
		AccountId: params.accountId,
		Description: params.description,
		Amount: params.amount,
		Currency: params.currency ?? 'RUB',
		RequireConfirmation: false,
		StartDate: params.startDate,
		Interval: params.interval,
		Period: params.period,
	})
}

export async function createOrderLink(params: {
	amount: number
	currency?: string
	description: string
	invoiceId: string
	accountId: string
	email?: string
	phone?: string
	payer?: {
		firstName?: string
		lastName?: string
		middleName?: string
		phone?: string
	}
	successRedirectUrl?: string
	failRedirectUrl?: string
	jsonData?: Record<string, unknown>
}): Promise<CPOrderLinkResponse> {
	return cpRequest('/orders/create', {
		Amount: params.amount,
		Currency: params.currency ?? 'RUB',
		Description: params.description,
		InvoiceId: params.invoiceId,
		AccountId: params.accountId,
		Email: params.email,
		Phone: params.phone,
		Payer: params.payer
			? {
					FirstName: params.payer.firstName,
					LastName: params.payer.lastName,
					MiddleName: params.payer.middleName,
					Phone: params.payer.phone,
				}
			: undefined,
		SuccessRedirectUrl: params.successRedirectUrl,
		FailRedirectUrl: params.failRedirectUrl,
		JsonData: params.jsonData,
	})
}

export async function findCloudPaymentByInvoiceId(invoiceId: string): Promise<CPResponse> {
	return cpRequest('/v2/payments/find', { InvoiceId: invoiceId })
}

export async function findCloudSubscriptionsByAccountId(accountId: string): Promise<CPResponse> {
	return cpRequest('/subscriptions/find', { accountId })
}

export async function getCloudSubscription(subscriptionId: string): Promise<CPResponse> {
	return cpRequest('/subscriptions/get', { Id: subscriptionId })
}

// Отмена рекуррента
export async function cancelRecurrent(subscriptionId: string): Promise<CPResponse> {
	return cpRequest('/subscriptions/cancel', { Id: subscriptionId })
}

// Смена суммы
export async function changeRecurrentAmount(
	subscriptionId: string,
	amount: number,
): Promise<CPResponse> {
	return cpRequest('/subscriptions/update', {
		Id: subscriptionId,
		Amount: amount,
	})
}

// Замена карты: первый платеж 10₽, далее обычная рекуррентка
export async function initiateCardReplacement(params: {
	token: string
	accountId: string
	amount: number
	description: string
}): Promise<CPResponse> {
	// Шаг 1: charge 10₽ для привязки новой карты
	return cpRequest('/payments/cards/charge', {
		Amount: 10,
		Currency: 'RUB',
		AccountId: params.accountId,
		Description: 'Привязка новой карты',
		Token: params.token,
	})
}

export async function verifyCloudPaymentsWebhookHmac(
	body: string,
	hmacHeader: string | undefined,
): Promise<boolean> {
	if (!hmacHeader) return false
	const credentials = await getCloudPaymentsCredentials()
	if (!credentials.apiSecret) return false
	const encoder = new TextEncoder()
	const key = encoder.encode(credentials.apiSecret)
	const data = encoder.encode(body)
	const hmac = new Bun.CryptoHasher('sha256', key).update(data).digest('base64')
	const expected = Buffer.from(hmac)
	const received = Buffer.from(hmacHeader.trim())
	return expected.length === received.length && timingSafeEqual(expected, received)
}
