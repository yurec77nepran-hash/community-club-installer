import { Buffer } from 'node:buffer'
import { checkDiscountSchema, paymentLogs, payments, tariffs, users } from '@community-club/shared'
import type {
	CheckDiscountResponse,
	PaymentCardType,
	PaymentProviderCode,
	PaymentTariffOffer,
	PricingContext,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, or } from 'drizzle-orm'
import { Hono } from 'hono'
import type { Context } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { invalidateUserAccessCaches } from '../lib/cache-invalidation'
import {
	buildCloudPaymentsRecurrentConfig,
	buildTariffRecurrentConfig,
} from '../lib/cloudpayments-recurrent'
import { logger } from '../lib/logger'
import { createPaymentCheckoutSession } from '../lib/payment-checkout-session'
import { buildInternalReturnUrl, isSafeInternalReturnPath } from '../lib/payment-return-url'
import {
	getActivePaymentProvider,
	loadPaymentCheckoutSettings,
	loadPaymentProviderSecrets,
} from '../lib/payment-settings'
import { isSuccessfulExternalPaymentStatus } from '../lib/payment-status'
import {
	buildCloudPaymentsIdempotencyKey,
	redactPaymentWebhookPayload,
	validateWebhookAmount,
} from '../lib/payment-webhook-utils'
import { parsePhpFormData, signProdamusPayload, verifyProdamusSignature } from '../lib/prodamus'
import { applyReferralCode, markReferralPaid } from '../lib/referrals'
import { decryptSecret, encryptSecret } from '../lib/secret-vault'
import { invalidateCachedValue, rememberCachedValue } from '../lib/server-cache'
import { getAppBaseUrl } from '../lib/site-settings'
import { decodeVerifiedTochkaWebhook } from '../lib/tochka-webhook'
import { authMiddleware } from '../middleware/auth'
import { rateLimit } from '../middleware/rate-limit'
import {
	cancelRecurrent,
	createOrderLink,
	createRecurrent,
	hasCloudPaymentsCredentials,
	verifyCloudPaymentsWebhookHmac,
} from '../services/payment.service'
import {
	buildTariffOffers,
	getPricingMatrixByRole,
	resolveOfferAmount,
	resolvePricingContext,
	shouldShowPriceFirst,
} from '../services/pricing.service'

export const paymentRoutes = new Hono<AppEnv>()

type PaymentCardMode = 'russian' | 'foreign'
type CloudPaymentsWebhookBody = Record<string, unknown> & {
	AccountId?: string
	Amount?: string | number
	Email?: string
	Phone?: string
	Token?: string
	SubscriptionId?: string
	TransactionId?: string | number
	InvoiceId?: string
	Status?: string
	Reason?: string
	IssuerBankCountry?: string
	Data?: string | Record<string, unknown>
	Metadata?: string | Record<string, unknown>
}

type GenericPaymentWebhookBody = Record<string, unknown>

type ExternalPaymentProvider = 'prodamus' | 'yookassa' | 'tochka'

type TochkaSettings = {
	customerCode: string
	merchantId?: string
	paymentModes?: string
	jwtToken: string
}

type TochkaPeriod = 'Day' | 'Month' | 'Year'

const TOCHKA_API_URL = 'https://enter.tochka.com/uapi'

type PaymentMetadata = {
	invoiceId: string
	tariff: string
	role: 'club'
	pricingContext: PricingContext
	cardType: PaymentCardMode
	userId: string
	fullName: string | null
	phone: string | null
	email: string | null
	regularAmount: number
	firstAmount: number
	durationDays: number
	demoDays: number
	description: string
	manualRenewal: boolean
}

function getTochkaPaymentLinkId(invoiceId: string) {
	return invoiceId.replaceAll(':', '-').slice(-45)
}

function parseWebhookData(raw: unknown): Record<string, unknown> {
	if (!raw) return {}
	if (typeof raw === 'string') {
		try {
			const parsed = JSON.parse(raw)
			return parsed && typeof parsed === 'object' ? parsed : {}
		} catch {
			return {}
		}
	}
	return raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {}
}

function getWebhookString(body: GenericPaymentWebhookBody, keys: string[]) {
	for (const key of keys) {
		const value = key.includes('.')
			? key.split('.').reduce<unknown>((acc, part) => {
					if (!acc || typeof acc !== 'object') return undefined
					return (acc as Record<string, unknown>)[part]
				}, body)
			: body[key]
		if (value != null && String(value).trim()) return String(value).trim()
	}
	return ''
}

function setWebhookValue(body: GenericPaymentWebhookBody, key: string, value: unknown) {
	body[key] = value
	return body
}

function getWebhookAmount(body: GenericPaymentWebhookBody) {
	return getWebhookString(body, [
		'amount',
		'object.amount',
		'Data.amount',
		'sum',
		'order_sum',
		'payment_amount',
		'object.amount.value',
	])
}

function getExternalWebhookIdempotencyKey(
	provider: ExternalPaymentProvider,
	event: string,
	body: GenericPaymentWebhookBody,
) {
	const externalId = getWebhookString(body, [
		'object.metadata.invoiceId',
		'paymentLinkId',
		'Data.paymentLinkId',
		'object.paymentLinkId',
		'order_num',
		'order_id',
		'orderId',
		'invoiceId',
		'payment_id',
		'id',
		'object.id',
		'operationId',
		'Data.operationId',
		'object.operationId',
	])
	if (!externalId) return null
	return `${provider}:${event}:${externalId}`
}

async function parseGenericWebhookBody(c: Context<AppEnv>) {
	const contentType = c.req.header('content-type') ?? ''
	if (contentType.includes('multipart/form-data')) {
		const parsedBody = await c.req.parseBody({ all: true }).catch(() => ({}))
		const entries = Object.entries(parsedBody)
			.filter((entry): entry is [string, string | string[]] => {
				const value = entry[1]
				return (
					typeof value === 'string' ||
					(Array.isArray(value) && value.every((item) => typeof item === 'string'))
				)
			})
			.flatMap(([key, value]) =>
				Array.isArray(value)
					? value.map((item): [string, string] => [key, item])
					: ([[key, value]] as [string, string][]),
			)
		const flatBody = Object.fromEntries(entries)
		return { rawBody: '', body: parsePhpFormData(entries), flatBody }
	}

	const rawBody = await c.req.text()
	if (contentType.includes('application/json')) {
		try {
			return { rawBody, body: JSON.parse(rawBody) as GenericPaymentWebhookBody }
		} catch {
			return { rawBody, body: {} as GenericPaymentWebhookBody }
		}
	}

	const params = new URLSearchParams(rawBody)
	const entries = Array.from(params.entries())
	const flatBody = Object.fromEntries(entries)
	if (entries.length > 0) return { rawBody, body: parsePhpFormData(entries), flatBody }

	try {
		return { rawBody, body: JSON.parse(rawBody) as GenericPaymentWebhookBody }
	} catch {
		return { rawBody, body: { raw: rawBody } as GenericPaymentWebhookBody }
	}
}

async function parseCloudPaymentsWebhookBody(c: Context<AppEnv>) {
	const rawBody = await c.req.text()
	const contentType = c.req.header('content-type') ?? ''
	if (contentType.includes('application/json')) {
		try {
			return {
				rawBody,
				body: JSON.parse(rawBody) as CloudPaymentsWebhookBody,
			}
		} catch {
			return { rawBody, body: {} as CloudPaymentsWebhookBody }
		}
	}

	const params = new URLSearchParams(rawBody)
	const entries = Array.from(params.entries())
	if (entries.length > 0) {
		return {
			rawBody,
			body: Object.fromEntries(entries) as CloudPaymentsWebhookBody,
		}
	}

	try {
		return {
			rawBody,
			body: JSON.parse(rawBody) as CloudPaymentsWebhookBody,
		}
	} catch {
		return { rawBody, body: { raw: rawBody } as CloudPaymentsWebhookBody }
	}
}

function buildPaymentMetadata(params: {
	offer: PaymentTariffOffer
	cardType: PaymentCardType
	userId: string
	user: typeof users.$inferSelect
	firstAmount: number
	regularAmount: number
	manualRenewal: boolean
	invoiceId: string
}): PaymentMetadata {
	return {
		invoiceId: params.invoiceId,
		tariff: params.offer.slug,
		role: 'club',
		pricingContext: params.offer.pricingContext,
		cardType: params.cardType,
		userId: params.userId,
		fullName: params.user.fullName ?? null,
		phone: params.user.phone ?? null,
		email: params.user.email ?? null,
		regularAmount: params.regularAmount,
		firstAmount: params.firstAmount,
		durationDays: params.offer.durationDays,
		demoDays: params.offer.pricingContext === 'intro' ? params.offer.demoDays : 0,
		description: params.offer.name,
		manualRenewal: params.manualRenewal,
	}
}

function flattenMetadata(metadata: PaymentMetadata) {
	return Object.fromEntries(
		Object.entries(metadata).map(([key, value]) => [key, value == null ? '' : String(value)]),
	)
}

async function findOrCreateCheckoutUser(params: {
	email: string
	fullName?: string | null
	phone?: string | null
	password?: string | null
}) {
	const email = params.email.trim().toLowerCase()
	const fullName = params.fullName?.trim() || null
	const phone = params.phone?.trim() || null
	const existingUser = await db.query.users.findFirst({
		where: eq(users.email, email),
	})

	if (!existingUser) {
		if (!params.password || params.password.length < 6) return null
		const passwordHash = await Bun.password.hash(params.password, { algorithm: 'bcrypt', cost: 12 })
		const [created] = await db
			.insert(users)
			.values({
				email,
				fullName,
				phone,
				passwordHash,
				role: 'user',
				authType: 'email',
				firstEntry: true,
				onboardingSeen: false,
			})
			.returning()
		return created
	}

	const nextFullName = fullName || existingUser.fullName || null
	const nextPhone = phone || existingUser.phone || null
	const shouldUpdate =
		nextFullName !== (existingUser.fullName ?? null) ||
		nextPhone !== (existingUser.phone ?? null) ||
		existingUser.authType !== 'email'

	if (!shouldUpdate) return existingUser

	const [updated] = await db
		.update(users)
		.set({
			fullName: nextFullName,
			phone: nextPhone,
			authType: 'email',
			updatedAt: new Date(),
		})
		.where(eq(users.authUuid, existingUser.authUuid))
		.returning()

	return updated ?? existingUser
}

async function logGenericPaymentWebhook(params: {
	provider: 'prodamus' | 'yookassa'
	event: string
	body: GenericPaymentWebhookBody
	status: string
	errorMessage?: string | null
	idempotencyKey?: string | null
}) {
	await db
		.insert(paymentLogs)
		.values({
			event: params.event,
			userAuthUuid:
				getWebhookString(params.body, [
					'account',
					'accountId',
					'userId',
					'metadata.userId',
					'object.metadata.userId',
				]) || null,
			email:
				getWebhookString(params.body, [
					'email',
					'customer.email',
					'object.recipient.email',
					'object.metadata.email',
				]) || null,
			phone: getWebhookString(params.body, ['phone', 'customer.phone']) || null,
			subscriptionId:
				getWebhookString(params.body, ['subscriptionId', 'subscription_id', 'subscription.id']) ||
				null,
			orderId:
				getWebhookString(params.body, [
					'object.metadata.invoiceId',
					'paymentLinkId',
					'Data.paymentLinkId',
					'object.paymentLinkId',
					'order_num',
					'order_id',
					'orderId',
					'invoiceId',
					'id',
					'object.id',
				]) || null,
			amount: getWebhookAmount(params.body) || null,
			tariff:
				getWebhookString(params.body, ['tariff', 'metadata.tariff', 'object.metadata.tariff']) ||
				null,
			status: params.status,
			errorMessage: params.errorMessage ?? null,
			rawData: redactPaymentWebhookPayload(params.body),
			webhookType: params.provider,
			idempotencyKey:
				params.idempotencyKey ??
				getExternalWebhookIdempotencyKey(params.provider, params.event, params.body),
		})
		.onConflictDoNothing()
}

async function logPaymentCheckoutFailure(params: {
	provider: PaymentProviderCode
	userId: string
	tariffSlug: string
	amount: number
	error: unknown
}) {
	await db.insert(paymentLogs).values({
		event: 'checkout',
		userAuthUuid: params.userId,
		tariff: params.tariffSlug,
		amount: String(params.amount),
		status: 'failed',
		errorMessage:
			params.error instanceof Error ? params.error.message.slice(0, 500) : 'Checkout failed',
		webhookType: params.provider,
		rawData: {
			provider: params.provider,
			tariffSlug: params.tariffSlug,
		},
	})
}

async function claimExternalPaymentWebhookEvent(params: {
	provider: ExternalPaymentProvider
	event: string
	body: GenericPaymentWebhookBody
}) {
	const idempotencyKey = getExternalWebhookIdempotencyKey(
		params.provider,
		params.event,
		params.body,
	)
	if (!idempotencyKey) {
		logger.warn(
			{
				provider: params.provider,
				event: params.event,
				body: redactPaymentWebhookPayload(params.body),
			},
			'Payment webhook without stable id',
		)
		return { claimed: true as const, idempotencyKey: null, logId: null }
	}

	const inserted = await db
		.insert(paymentLogs)
		.values({
			event: params.event,
			userAuthUuid:
				getWebhookString(params.body, [
					'account',
					'accountId',
					'userId',
					'metadata.userId',
					'object.metadata.userId',
				]) || null,
			email:
				getWebhookString(params.body, [
					'email',
					'customer.email',
					'object.recipient.email',
					'object.metadata.email',
				]) || null,
			phone: getWebhookString(params.body, ['phone', 'customer.phone']) || null,
			subscriptionId:
				getWebhookString(params.body, ['subscriptionId', 'subscription_id', 'subscription.id']) ||
				null,
			orderId:
				getWebhookString(params.body, [
					'object.metadata.invoiceId',
					'paymentLinkId',
					'Data.paymentLinkId',
					'object.paymentLinkId',
					'order_num',
					'order_id',
					'orderId',
					'invoiceId',
					'id',
					'object.id',
				]) || null,
			amount: getWebhookAmount(params.body) || null,
			tariff:
				getWebhookString(params.body, ['tariff', 'metadata.tariff', 'object.metadata.tariff']) ||
				null,
			status: 'processing',
			errorMessage: null,
			rawData: redactPaymentWebhookPayload(params.body),
			webhookType: params.provider,
			idempotencyKey,
		})
		.onConflictDoNothing()
		.returning({ id: paymentLogs.id })

	if (!inserted[0]) {
		logger.info(
			{ provider: params.provider, event: params.event, idempotencyKey },
			'Duplicate payment webhook skipped',
		)
		return { claimed: false as const, idempotencyKey, logId: null }
	}

	return { claimed: true as const, idempotencyKey, logId: inserted[0].id }
}

function buildProdamusCheckoutUrl(params: {
	paymentUrl: string
	secretKey: string
	subscriptionId?: string
	invoiceId: string
	amount: number
	description: string
	successUrl: string
	failUrl: string
	webhookUrl: string
	metadata: PaymentMetadata
}) {
	const payload = {
		do: 'link',
		order_id: params.invoiceId,
		order_sum: params.amount.toFixed(2),
		...(params.subscriptionId ? { subscription: params.subscriptionId } : {}),
		...(params.subscriptionId ? {} : { subscription_limit_autopayments: '1' }),
		...(params.metadata.cardType === 'foreign'
			? { available_payment_methods: 'ACUSDGTL|ACEURGTL|ACBYNGTL|ACUSDKB|ACEURKB' }
			: {}),
		customer_email: params.metadata.email ?? '',
		customer_phone: params.metadata.phone ?? '',
		urlReturn: params.failUrl,
		urlSuccess: params.successUrl,
		urlNotification: params.webhookUrl,
		_param_user_id: params.metadata.userId,
		_param_tariff: params.metadata.tariff,
		_param_role: params.metadata.role,
		_param_duration_days: String(params.metadata.durationDays),
		_param_demo_days: String(params.metadata.demoDays),
		_param_pricing_context: params.metadata.pricingContext,
		_param_card_type: params.metadata.cardType,
		products: [
			{
				name: params.description,
				price: params.amount.toFixed(2),
				quantity: '1',
				sum: params.amount.toFixed(2),
			},
		],
		...flattenMetadata(params.metadata),
	}
	const signedPayload = {
		...payload,
		signature: signProdamusPayload(payload, params.secretKey),
	}
	const query = new URLSearchParams()

	for (const [key, value] of Object.entries(signedPayload)) {
		if (Array.isArray(value)) {
			for (const [index, item] of value.entries()) {
				for (const [itemKey, itemValue] of Object.entries(item)) {
					query.set(`${key}[${index}][${itemKey}]`, String(itemValue))
				}
			}
			continue
		}
		query.set(key, String(value))
	}

	return `${params.paymentUrl}?${query.toString()}`
}

async function createYookassaCheckoutUrl(params: {
	shopId: string
	secretKey: string
	invoiceId: string
	amount: number
	description: string
	successUrl: string
	metadata: PaymentMetadata
}) {
	const response = await fetch('https://api.yookassa.ru/v3/payments', {
		method: 'POST',
		headers: {
			Authorization: `Basic ${btoa(`${params.shopId}:${params.secretKey}`)}`,
			'Content-Type': 'application/json',
			'Idempotence-Key': params.invoiceId,
		},
		signal: AbortSignal.timeout(10_000),
		body: JSON.stringify({
			amount: {
				value: params.amount.toFixed(2),
				currency: 'RUB',
			},
			capture: true,
			confirmation: {
				type: 'redirect',
				return_url: params.successUrl,
			},
			description: params.description.slice(0, 128),
			metadata: {
				...flattenMetadata(params.metadata),
				invoiceId: params.invoiceId,
			},
		}),
	})
	const body = (await response.json().catch(() => null)) as {
		confirmation?: { confirmation_url?: string }
		id?: string
		status?: string
		description?: string
	} | null
	const checkoutUrl = String(body?.confirmation?.confirmation_url ?? '').trim()

	if (!response.ok || !checkoutUrl) {
		throw new Error(body?.description || `YooKassa returned HTTP ${response.status}`)
	}

	return checkoutUrl
}

async function loadYookassaPayment(params: {
	shopId: string
	secretKey: string
	paymentId: string
}) {
	const response = await fetch(`https://api.yookassa.ru/v3/payments/${params.paymentId}`, {
		headers: {
			Authorization: `Basic ${btoa(`${params.shopId}:${params.secretKey}`)}`,
		},
		signal: AbortSignal.timeout(10_000),
	})
	if (!response.ok) return null
	return (await response.json().catch(() => null)) as GenericPaymentWebhookBody | null
}

function normalizeTochkaPaymentMode(value: string) {
	const mode = value.trim().toLowerCase()
	return ['sbp', 'card', 'tinkoff', 'dolyame'].includes(mode) ? mode : ''
}

function getTochkaPaymentMode(settings: TochkaSettings, cardType: PaymentCardMode) {
	if (cardType === 'foreign') return 'card'
	const modes = String(settings.paymentModes ?? '')
		.split(',')
		.map(normalizeTochkaPaymentMode)
		.filter(Boolean)
	return modes[0] || 'card'
}

function buildTochkaSubscriptionOptions(params: {
	settings: PaymentCheckoutSettings
	durationDays: number
}) {
	let period: TochkaPeriod = 'Day'
	let daysInPeriod = Math.max(1, Math.trunc(params.durationDays))

	if (params.settings.recurrentInterval === 'Month' && params.settings.recurrentPeriod === 1) {
		period = 'Month'
		daysInPeriod = 0
	} else if (params.settings.recurrentInterval === 'tariff' && params.durationDays === 365) {
		period = 'Year'
		daysInPeriod = 0
	} else if (params.settings.recurrentInterval !== 'tariff') {
		const multiplier =
			params.settings.recurrentInterval === 'Week'
				? 7
				: params.settings.recurrentInterval === 'Month'
					? 30
					: 1
		daysInPeriod = Math.max(1, Math.trunc(params.settings.recurrentPeriod * multiplier))
	}

	const maxByPeriod = period === 'Year' ? 10 : period === 'Month' ? 84 : 100
	return {
		period,
		...(period === 'Day' ? { daysInPeriod } : {}),
		trancheCount: Math.min(maxByPeriod, params.settings.recurrentMaxPeriods ?? 12),
	}
}

async function requestTochka<T>(settings: TochkaSettings, path: string, init: RequestInit = {}) {
	const response = await fetch(`${TOCHKA_API_URL}${path}`, {
		...init,
		headers: {
			Accept: 'application/json',
			'Content-Type': 'application/json',
			Authorization: `Bearer ${settings.jwtToken}`,
			...(init.headers ?? {}),
		},
		signal: AbortSignal.timeout(10_000),
	})
	const body = (await response.json().catch(() => null)) as T | null
	if (!response.ok) {
		const message =
			body && typeof body === 'object' && 'message' in body
				? String((body as { message?: unknown }).message)
				: `Tochka returned HTTP ${response.status}`
		throw new Error(`Tochka returned HTTP ${response.status}: ${message}`)
	}
	return body
}

async function createTochkaCheckoutUrl(params: {
	settings: TochkaSettings
	invoiceId: string
	amount: number
	description: string
	successUrl: string
	failUrl: string
	cardType: PaymentCardMode
	metadata: PaymentMetadata
	checkoutSettings: PaymentCheckoutSettings
	recurrent: boolean
}) {
	const data: Record<string, unknown> = {
		customerCode: params.settings.customerCode,
		amount: params.amount,
		purpose: params.description.slice(0, 140),
		redirectUrl: params.successUrl,
		failRedirectUrl: params.failUrl,
		consumerId: params.metadata.userId,
		paymentLinkId: getTochkaPaymentLinkId(params.invoiceId),
	}
	if (params.settings.merchantId) data.merchantId = params.settings.merchantId

	const body = params.recurrent
		? await requestTochka<{ Data?: { paymentLink?: string; operationId?: string } }>(
				params.settings,
				'/acquiring/v1.0/subscriptions',
				{
					method: 'POST',
					body: JSON.stringify({
						Data: {
							...data,
							saveCard: true,
							Options: buildTochkaSubscriptionOptions({
								settings: params.checkoutSettings,
								durationDays: params.metadata.durationDays,
							}),
						},
					}),
				},
			)
		: await requestTochka<{ Data?: { paymentLink?: string; operationId?: string } }>(
				params.settings,
				'/acquiring/v1.0/payments',
				{
					method: 'POST',
					body: JSON.stringify({
						Data: {
							...data,
							paymentMode: getTochkaPaymentMode(params.settings, params.cardType),
						},
					}),
				},
			)

	const checkoutUrl = String(body?.Data?.paymentLink ?? '').trim()
	if (!checkoutUrl) throw new Error('Tochka checkout link was not created')
	return checkoutUrl
}

async function loadTochkaPayment(params: { settings: TochkaSettings; operationId: string }) {
	return requestTochka<{ Data?: GenericPaymentWebhookBody }>(
		params.settings,
		`/acquiring/v1.0/payments/${encodeURIComponent(params.operationId)}`,
	).catch(() => null)
}

function metadataFromGenericWebhook(body: GenericPaymentWebhookBody): Record<string, unknown> {
	const metadata = parseWebhookData(body.metadata)
	const object = parseWebhookData(body.object)
	const nestedObjectMetadata = parseWebhookData(object.metadata)

	return {
		...body,
		...metadata,
		...nestedObjectMetadata,
	}
}

async function storeCheckoutMetadata(params: {
	provider: PaymentProviderCode
	invoiceId: string
	metadata: PaymentMetadata
}) {
	await db
		.insert(paymentLogs)
		.values({
			event: 'checkout_link',
			userAuthUuid: params.metadata.userId,
			email: params.metadata.email,
			phone: params.metadata.phone,
			orderId: params.invoiceId,
			amount: String(params.metadata.firstAmount),
			tariff: params.metadata.tariff,
			status: 'created',
			rawData: { metadata: params.metadata },
			webhookType: params.provider,
			idempotencyKey: `${params.provider}:checkout:${params.invoiceId}`,
		})
		.onConflictDoNothing()
}

async function loadCheckoutMetadata(invoiceId: string) {
	const log = await db.query.paymentLogs.findFirst({
		where: and(eq(paymentLogs.orderId, invoiceId), eq(paymentLogs.event, 'checkout_link')),
		orderBy: [desc(paymentLogs.createdAt)],
	})
	const rawData = parseWebhookData(log?.rawData)
	return parseWebhookData(rawData.metadata)
}

function isSuccessfulExternalPayment(
	provider: ExternalPaymentProvider,
	body: GenericPaymentWebhookBody,
) {
	return isSuccessfulExternalPaymentStatus(provider, {
		event: getWebhookString(body, ['event']),
		status: getWebhookString(
			body,
			provider === 'yookassa'
				? ['object.status', 'status']
				: provider === 'tochka'
					? ['object.status', 'Data.status', 'status']
					: ['payment_status', 'status', 'order_status'],
		),
		paid: getWebhookString(body, ['object.paid', 'paid']),
	})
}

async function syncExternalPaymentStateFromWebhook(
	provider: ExternalPaymentProvider,
	body: GenericPaymentWebhookBody,
	paymentLogId: number | null,
) {
	if (!isSuccessfulExternalPayment(provider, body)) return

	let metadata = metadataFromGenericWebhook(body)
	const invoiceId = String(
		metadata.invoiceId ??
			metadata.paymentLinkId ??
			getWebhookString(body, ['paymentLinkId', 'Data.paymentLinkId', 'object.paymentLinkId']) ??
			'',
	).trim()
	if (invoiceId && (!metadata.userId || !metadata.tariff || !metadata.durationDays)) {
		metadata = { ...(await loadCheckoutMetadata(invoiceId)), ...metadata }
	}
	const userAuthUuid = String(
		metadata.userId ?? metadata._param_user_id ?? metadata.accountId ?? metadata.account ?? '',
	).trim()
	const tariffSlug = String(metadata.tariff ?? metadata._param_tariff ?? '').trim()
	const durationDays = Number(metadata.durationDays ?? metadata._param_duration_days ?? 0)

	if (!userAuthUuid || !tariffSlug || !durationDays) {
		logger.warn(
			{ provider, body: redactPaymentWebhookPayload(body) },
			'Payment webhook without enough metadata to sync access',
		)
		return
	}

	const [existingPayment, legacyTariff] = await Promise.all([
		db.query.payments.findFirst({
			where: eq(payments.userAuthUuid, userAuthUuid),
		}),
		db.query.tariffs.findFirst({ where: eq(tariffs.slug, tariffSlug) }),
	])
	const now = new Date()
	const currentFinish = parseStoredDateEnd(existingPayment?.dateFinish)
	const periodStart = currentFinish && currentFinish > now ? currentFinish : now
	const demoDays = Number(metadata.demoDays ?? metadata._param_demo_days ?? 0)
	const periodDays = demoDays > 0 ? demoDays : durationDays
	const nextFinish = addDays(periodStart, periodDays)
	const access = buildTariffAccess(legacyTariff)
	const amount =
		getWebhookAmount(body) ||
		getWebhookString(body, ['object.amount.value']) ||
		String(metadata.firstAmount ?? '')
	const manualRenewalFlag = metadata.manualRenewal === true || metadata.manualRenewal === 'true'
	const subscriptionId =
		getWebhookString(body, [
			'subscriptionId',
			'subscription_id',
			'subscription.id',
			'operationId',
			'Data.operationId',
			'object.operationId',
		]) || null
	const autoPayment =
		!manualRenewalFlag &&
		(provider === 'tochka' || (provider === 'prodamus' && Boolean(subscriptionId)))
	const amountValidation = validateWebhookAmount({
		expected: metadata.firstAmount,
		received: amount,
	})
	if (!amountValidation.ok) {
		logger.warn(
			{
				provider,
				userAuthUuid,
				tariffSlug,
				expectedAmount: amountValidation.expectedMinor,
				receivedAmount: amountValidation.receivedMinor,
			},
			'Payment webhook amount mismatch',
		)
		throw new Error('Payment amount mismatch')
	}

	const nextPaymentData = {
		userAuthUuid,
		email: String(metadata.email ?? existingPayment?.email ?? '').trim() || null,
		phone: String(metadata.phone ?? existingPayment?.phone ?? '').trim() || null,
		...access.paymentFlags,
		tarrif: tariffSlug,
		dateStart: formatDateOnly(now),
		dateFinish: formatDateOnly(nextFinish),
		cpSubscriptionId: autoPayment ? subscriptionId : null,
		cpAccountId: null,
		cpToken: null,
		paymentProvider: provider,
		amount: amount ? String(amount) : null,
		autoPayment,
		noAutopodpiska: !autoPayment || manualRenewalFlag,
		zarub: normalizeCardType(metadata.cardType ?? metadata._param_card_type) === 'foreign',
		updatedAt: now,
	}

	if (existingPayment) {
		await db.update(payments).set(nextPaymentData).where(eq(payments.id, existingPayment.id))
	} else {
		await db.insert(payments).values(nextPaymentData)
	}
	await markReferralPaid({ userAuthUuid, amount, paymentLogId })
	await invalidateUserAccessCaches(userAuthUuid)

	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, userAuthUuid),
	})
	if (!user || user.role === 'admin' || user.role === 'superadmin') return

	await db
		.update(users)
		.set({
			role: access.role,
			firstEntry: false,
		})
		.where(eq(users.authUuid, userAuthUuid))
}

function parseWebhookMetadata(body: CloudPaymentsWebhookBody) {
	const data = parseWebhookData(body.Data)
	const metadata = parseWebhookData(body.Metadata)
	return { ...data, ...metadata }
}

function normalizeCardType(value: unknown): PaymentCardMode {
	return value === 'foreign' ? 'foreign' : 'russian'
}

function isForeignPayment(body: CloudPaymentsWebhookBody, cardType: PaymentCardMode) {
	if (cardType === 'foreign') return true
	const issuerCountry = String(body.IssuerBankCountry ?? '')
		.trim()
		.toUpperCase()
	return Boolean(issuerCountry && issuerCountry !== 'RU' && issuerCountry !== 'RUS')
}

function formatDateOnly(date: Date) {
	return date.toISOString().slice(0, 10)
}

function addDays(base: Date, days: number) {
	const next = new Date(base)
	next.setUTCDate(next.getUTCDate() + days)
	return next
}

function buildCloudPaymentsPayer(fullName: string | null, phone: string | null) {
	const parts = String(fullName ?? '')
		.trim()
		.split(/\s+/)
		.filter(Boolean)

	if (parts.length === 0 && !phone) return undefined

	const [lastName, firstName, middleName] = parts
	return {
		firstName: firstName ?? lastName ?? undefined,
		lastName: parts.length > 1 ? lastName : undefined,
		middleName: middleName ?? undefined,
		phone: phone ?? undefined,
	}
}

function getCloudPaymentsWebhookSignature(c: Context<AppEnv>) {
	return c.req.header('Content-HMAC') ?? c.req.header('X-Content-HMAC')
}

function parseStoredDate(value: string | Date | null | undefined) {
	if (!value) return null

	if (value instanceof Date) {
		return Number.isNaN(value.getTime()) ? null : value
	}

	const parsed = new Date(value)
	return Number.isNaN(parsed.getTime()) ? null : parsed
}

function parseStoredDateEnd(value: string | Date | null | undefined) {
	const parsed = parseStoredDate(value)
	if (!parsed) return null

	const next = new Date(parsed)
	next.setUTCHours(23, 59, 59, 999)
	return next
}

async function findPaymentForUser(params: { userAuthUuid: string; email: string | null }) {
	const payment = await db.query.payments.findFirst({
		where: params.email
			? or(eq(payments.userAuthUuid, params.userAuthUuid), eq(payments.email, params.email))
			: eq(payments.userAuthUuid, params.userAuthUuid),
		orderBy: [desc(payments.dateFinish), desc(payments.updatedAt), desc(payments.createdAt)],
	})

	if (payment && payment.userAuthUuid !== params.userAuthUuid) {
		await db
			.update(payments)
			.set({ userAuthUuid: params.userAuthUuid })
			.where(eq(payments.id, payment.id))
		return { ...payment, userAuthUuid: params.userAuthUuid }
	}

	return payment ?? null
}

function buildTariffAccess(tariff?: typeof tariffs.$inferSelect | null) {
	void tariff

	return {
		role: 'user' as const,
		paymentFlags: {},
	}
}

async function logWebhookEvent(params: {
	body: CloudPaymentsWebhookBody
	event: string
	status: string
	errorMessage?: string | null
	idempotencyKey?: string | null
}) {
	const data = parseWebhookData(params.body.Data)
	const metadata = parseWebhookMetadata(params.body)

	await db.insert(paymentLogs).values({
		event: params.event,
		userAuthUuid: params.body.AccountId ?? null,
		email: params.body.Email ?? null,
		phone: params.body.Phone ?? null,
		subscriptionId: params.body.SubscriptionId ?? null,
		orderId: params.body.InvoiceId ?? String(params.body.TransactionId ?? ''),
		amount: params.body.Amount != null ? String(params.body.Amount) : null,
		tariff: String(metadata.tariff ?? params.body.InvoiceId ?? '').trim() || null,
		status: params.status,
		errorMessage: params.errorMessage ?? null,
		rawData: redactPaymentWebhookPayload(params.body),
		webhookType: 'cloudpayments',
		idempotencyKey: params.idempotencyKey ?? null,
	})
}

async function claimWebhookEvent(params: {
	body: CloudPaymentsWebhookBody
	event: 'pay' | 'recurrent'
}) {
	const idempotencyKey = buildCloudPaymentsIdempotencyKey(params.event, params.body)
	if (!idempotencyKey) {
		logger.warn(
			{ body: redactPaymentWebhookPayload(params.body), event: params.event },
			'CloudPayments webhook without stable id',
		)
		return { claimed: true as const, idempotencyKey: null, logId: null }
	}

	const data = parseWebhookData(params.body.Data)
	const metadata = parseWebhookMetadata(params.body)
	const inserted = await db
		.insert(paymentLogs)
		.values({
			event: params.event,
			userAuthUuid: params.body.AccountId ?? null,
			email: params.body.Email ?? null,
			phone: params.body.Phone ?? null,
			subscriptionId: params.body.SubscriptionId ?? null,
			orderId: params.body.InvoiceId ?? String(params.body.TransactionId ?? ''),
			amount: params.body.Amount != null ? String(params.body.Amount) : null,
			tariff: String(metadata.tariff ?? params.body.InvoiceId ?? '').trim() || null,
			status: 'processing',
			errorMessage: null,
			rawData: redactPaymentWebhookPayload({ ...params.body, Data: data }),
			webhookType: 'cloudpayments',
			idempotencyKey,
		})
		.onConflictDoNothing()
		.returning({ id: paymentLogs.id })

	if (!inserted[0]) {
		logger.info({ event: params.event, idempotencyKey }, 'Duplicate CloudPayments webhook skipped')
		return { claimed: false as const, idempotencyKey, logId: null }
	}

	return { claimed: true as const, idempotencyKey, logId: inserted[0].id }
}

async function finalizeWebhookEvent(params: {
	logId: number | null
	status: string
	errorMessage?: string | null
}) {
	if (!params.logId) return

	await db
		.update(paymentLogs)
		.set({
			status: params.status,
			errorMessage: params.errorMessage ?? null,
			processingTimeMs: null,
		})
		.where(eq(paymentLogs.id, params.logId))
}

async function syncPaymentStateFromWebhook(
	body: CloudPaymentsWebhookBody,
	event: 'pay' | 'recurrent',
	paymentLogId: number | null,
) {
	const userAuthUuid = String(body.AccountId ?? '').trim()
	if (!userAuthUuid) {
		logger.warn(
			{ body: redactPaymentWebhookPayload(body), event },
			'CloudPayments webhook without AccountId',
		)
		return
	}

	const metadata = parseWebhookMetadata(body)
	const tariffSlug = String(metadata.tariff ?? body.InvoiceId ?? '').trim()
	const legacyTariff = tariffSlug
		? await db.query.tariffs.findFirst({ where: eq(tariffs.slug, tariffSlug) })
		: null
	const durationDays = Number(metadata.durationDays ?? legacyTariff?.durationDays ?? 0)

	if (!durationDays) {
		logger.warn(
			{ body: redactPaymentWebhookPayload(body), event, tariffSlug },
			'CloudPayments webhook without known tariff',
		)
		return
	}

	const expectedAmount =
		event === 'recurrent'
			? (metadata.regularAmount ?? legacyTariff?.price ?? metadata.firstAmount)
			: metadata.firstAmount
	const amountValidation = validateWebhookAmount({
		expected: expectedAmount,
		received: body.Amount,
	})
	if (!amountValidation.ok) {
		logger.warn(
			{
				event,
				userAuthUuid,
				tariffSlug,
				expectedAmount: amountValidation.expectedMinor,
				receivedAmount: amountValidation.receivedMinor,
			},
			'CloudPayments webhook amount mismatch',
		)
		throw new Error('Payment amount mismatch')
	}

	const existingPayment = await db.query.payments.findFirst({
		where: eq(payments.userAuthUuid, userAuthUuid),
	})

	const now = new Date()
	const currentFinish = parseStoredDateEnd(existingPayment?.dateFinish)
	const periodStart = currentFinish && currentFinish > now ? currentFinish : now
	const demoDays = Number(metadata.demoDays ?? 0)
	const periodDays = demoDays > 0 && event === 'pay' ? demoDays : durationDays
	const nextFinish = addDays(periodStart, periodDays)
	const access = buildTariffAccess(legacyTariff)
	const cardType = normalizeCardType(metadata.cardType)
	const manualRenewalFlag = metadata.manualRenewal === true || metadata.manualRenewal === 'true'
	const isManualRenewal = cardType === 'foreign' || manualRenewalFlag
	let subscriptionId = String(body.SubscriptionId ?? '').trim() || null
	let autoPayment = Boolean(subscriptionId)
	const nextCpToken = String(body.Token ?? decryptSecret(existingPayment?.cpToken) ?? '').trim()

	if (event === 'pay') {
		const currentSubscriptionId = String(existingPayment?.cpSubscriptionId ?? '').trim() || null
		if (currentSubscriptionId && currentSubscriptionId !== subscriptionId) {
			const cancelResult = await cancelRecurrent(currentSubscriptionId)
			if (!cancelResult.Success && cancelResult.Message !== 'Not found') {
				logger.error(
					{ userAuthUuid, currentSubscriptionId, cancelResult },
					'Failed to cancel previous subscription before payment sync',
				)
			}
		}

		if (!isManualRenewal && !subscriptionId) {
			const regularAmount = Number(metadata.regularAmount ?? legacyTariff?.price ?? 0)
			const accountId = String(body.AccountId ?? existingPayment?.cpAccountId ?? '').trim()

			if (nextCpToken && accountId && Number.isFinite(regularAmount) && regularAmount > 0) {
				const recurrent = buildTariffRecurrentConfig(durationDays, regularAmount)
				const createResult = await createRecurrent({
					token: nextCpToken,
					accountId,
					description: String(metadata.description ?? legacyTariff?.name ?? 'Подписка клуба'),
					amount: recurrent.amount,
					startDate: nextFinish.toISOString(),
					interval: recurrent.interval,
					period: recurrent.period,
				})

				const createdSubscriptionId = String(createResult.Model?.Id ?? '').trim()
				if (createResult.Success && createdSubscriptionId) {
					subscriptionId = createdSubscriptionId
					autoPayment = true
				} else {
					logger.error(
						{ userAuthUuid, tariffSlug, createResult },
						'Failed to create CloudPayments recurrent subscription after hosted payment',
					)
				}
			} else {
				logger.warn(
					{
						userAuthUuid,
						tariffSlug,
						hasToken: Boolean(nextCpToken),
						hasAccountId: Boolean(accountId),
					},
					'Hosted payment completed without enough data for recurrent subscription',
				)
			}
		}
	}

	const nextPaymentData = {
		userAuthUuid,
		email: String(body.Email ?? existingPayment?.email ?? '').trim() || null,
		phone: String(body.Phone ?? existingPayment?.phone ?? '').trim() || null,
		...access.paymentFlags,
		tarrif: tariffSlug || legacyTariff?.slug || null,
		dateStart: formatDateOnly(now),
		dateFinish: formatDateOnly(nextFinish),
		cpSubscriptionId: autoPayment ? subscriptionId : null,
		cpAccountId: userAuthUuid,
		cpToken: autoPayment && nextCpToken ? encryptSecret(nextCpToken) : null,
		paymentProvider: 'cloudpayments' as const,
		amount: String(body.Amount ?? metadata.firstAmount ?? legacyTariff?.price ?? ''),
		autoPayment,
		noAutopodpiska: !autoPayment || isManualRenewal,
		zarub: isForeignPayment(body, cardType),
		updatedAt: now,
	}

	if (existingPayment) {
		await db.update(payments).set(nextPaymentData).where(eq(payments.id, existingPayment.id))
	} else {
		await db.insert(payments).values(nextPaymentData)
	}
	await markReferralPaid({ userAuthUuid, amount: body.Amount, paymentLogId })
	await invalidateUserAccessCaches(userAuthUuid)

	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, userAuthUuid),
	})

	if (!user) {
		logger.warn({ userAuthUuid, tariffSlug }, 'Paid user not found during payment sync')
		return
	}

	if (user.role !== 'admin' && user.role !== 'superadmin') {
		await db
			.update(users)
			.set({
				role: 'user',
				firstEntry: false,
			})
			.where(eq(users.authUuid, userAuthUuid))
	}
}

// Проверка скидки по email (публичный)
const checkDiscountLimiter = rateLimit({
	windowMs: 60_000,
	max: 10,
	keyPrefix: 'rl:check-discount',
})

const checkoutLinkLimiter = rateLimit({
	windowMs: 60_000,
	max: 10,
	keyPrefix: 'rl:payment-checkout',
})

paymentRoutes.post(
	'/check-discount',
	checkDiscountLimiter,
	zValidator('json', checkDiscountSchema),
	async (c) => {
		const { email } = c.req.valid('json')
		const normalizedEmail = email.toLowerCase().trim()

		const existingUser = await db.query.users.findFirst({
			where: eq(users.email, normalizedEmail),
		})

		if (existingUser) {
			const payment = await db.query.payments.findFirst({
				where: eq(payments.userAuthUuid, existingUser.authUuid),
			})

			if (payment) {
				const activeUntil = parseStoredDateEnd(payment.dateFinish)
				const pricingContext = resolvePricingContext({
					role: 'club',
					firstEntry: false,
					hasPaymentHistory: Boolean(payment.tarrif || payment.dateStart || payment.dateFinish),
					hasActiveSubscription: Boolean(activeUntil && activeUntil >= new Date()),
				})
				const data: CheckDiscountResponse = {
					source: 'db_user',
					role: null,
					pricingContext,
					showPriceFirst: shouldShowPriceFirst(pricingContext),
				}
				return c.json({ success: true, data })
			}
		}

		const data: CheckDiscountResponse = {
			source: 'new',
			role: null,
			pricingContext: 'active',
			showPriceFirst: false,
		}
		return c.json({ success: true, data })
	},
)

const tariffsQuerySchema = z.object({
	pricingContext: z.enum(['intro', 'active', 'former', 'external']).optional(),
})

const paymentCheckoutLinkSchema = z.object({
	tariffSlug: z.string().trim().min(1).max(120),
	cardType: z.enum(['russian', 'foreign']).default('russian'),
	email: z.string().trim().email().max(255),
	fullName: z.string().trim().min(2).max(100).optional(),
	phone: z.string().trim().min(7).max(40).optional(),
	password: z.string().min(6).max(200).optional(),
	referralCode: z.string().trim().min(3).max(80).optional(),
	useReferralBalance: z.boolean().optional().default(false),
	successPath: z
		.string()
		.trim()
		.max(500)
		.refine(isSafeInternalReturnPath, 'Некорректный путь возврата')
		.optional(),
	failPath: z
		.string()
		.trim()
		.max(500)
		.refine(isSafeInternalReturnPath, 'Некорректный путь возврата')
		.optional(),
})

paymentRoutes.get('/tariffs', zValidator('query', tariffsQuerySchema), async (c) => {
	const { pricingContext } = c.req.valid('query')

	const resolvedContext =
		pricingContext ??
		(await (async (): Promise<PricingContext> => {
			void c
			return 'active'
		})())

	const items = await rememberCachedValue({
		namespace: 'payments:tariffs',
		key: `club:${resolvedContext}`,
		ttlSeconds: 300,
		load: async () => {
			const row = await getPricingMatrixByRole('club')
			if (!row) return []
			return buildTariffOffers({
				row,
				role: 'club',
				context: resolvedContext,
			})
		},
	})

	return c.json({ success: true, data: items })
})

paymentRoutes.get('/settings', async (c) => {
	return c.json({ success: true, data: await loadPaymentCheckoutSettings() })
})

paymentRoutes.post(
	'/checkout-link',
	checkoutLinkLimiter,
	zValidator('json', paymentCheckoutLinkSchema),
	async (c) => {
		const [activeProvider, checkoutSettings] = await Promise.all([
			getActivePaymentProvider(),
			loadPaymentCheckoutSettings(),
		])
		if (!activeProvider.enabled || !activeProvider.connected) {
			return c.json(
				{
					success: false,
					error: {
						code: 'CONFIG_ERROR',
						message: 'Активная платёжная система не настроена',
					},
				},
				503,
			)
		}
		if (activeProvider.code === 'cloudpayments' && !(await hasCloudPaymentsCredentials())) {
			return c.json(
				{
					success: false,
					error: {
						code: 'CONFIG_ERROR',
						message: 'CloudPayments не настроен на сервере',
					},
				},
				503,
			)
		}

		const {
			tariffSlug,
			cardType,
			email,
			fullName,
			phone,
			password,
			referralCode,
			useReferralBalance,
			successPath,
			failPath,
		} = c.req.valid('json')
		if (cardType === 'foreign' && !checkoutSettings.foreignCardsEnabled) {
			return c.json(
				{
					success: false,
					error: {
						code: 'VALIDATION_ERROR',
						message: 'Оплата зарубежной картой сейчас недоступна',
					},
				},
				400,
			)
		}
		const user = await findOrCreateCheckoutUser({ email, fullName, phone, password })
		if (!user) {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Укажите пароль для входа' },
				},
				400,
			)
		}
		await applyReferralCode({ code: referralCode, userAuthUuid: user.authUuid })
		const payment = await findPaymentForUser({
			userAuthUuid: user.authUuid,
			email: user.email ?? email.trim().toLowerCase(),
		})

		const activeUntil = parseStoredDateEnd(payment?.dateFinish)
		const pricingContext = resolvePricingContext({
			role: 'club',
			firstEntry: Boolean(user.firstEntry),
			hasPaymentHistory: Boolean(payment?.tarrif || payment?.dateStart || payment?.dateFinish),
			hasActiveSubscription: Boolean(activeUntil && activeUntil >= new Date()),
		})

		const matrix = await getPricingMatrixByRole('club')
		if (!matrix) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Тарифная сетка не найдена' } },
				404,
			)
		}

		const offerContexts = Array.from(
			new Set<PricingContext>([pricingContext, 'active', 'former', 'external']),
		)
		const offers = offerContexts.flatMap((context) =>
			buildTariffOffers({
				row: matrix,
				role: 'club',
				context,
			}),
		)
		const offer = offers.find((item) => item.slug === tariffSlug)

		if (!offer) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Тариф не найден' } },
				404,
			)
		}

		let firstAmount = resolveOfferAmount({ offer, cardType })
		const regularAmount = Number(offer.price ?? 0)

		if (
			!Number.isFinite(firstAmount) ||
			firstAmount <= 0 ||
			!Number.isFinite(regularAmount) ||
			regularAmount <= 0
		) {
			logger.error(
				{ userId: user.authUuid, tariffSlug, cardType, firstAmount, regularAmount },
				'Invalid tariff pricing',
			)
			return c.json(
				{
					success: false,
					error: {
						code: 'INTERNAL_ERROR',
						message: 'Не удалось определить сумму оплаты',
					},
				},
				500,
			)
		}

		if (useReferralBalance && user.bonusBalance > 0) {
			const bonus = Math.min(user.bonusBalance, firstAmount)
			firstAmount -= bonus
			logger.info(
				{ userId: user.authUuid, bonus, firstAmount },
				'Referral bonus applied to checkout',
			)
		}

		const invoiceId = `${offer.slug}:${crypto.randomUUID()}`
		const checkoutSessionToken = await createPaymentCheckoutSession({
			userAuthUuid: user.authUuid,
			email: user.email ?? email.trim().toLowerCase(),
			invoiceId,
			tariffSlug: offer.slug,
			amount: firstAmount,
		})
		const appBaseUrl = await getAppBaseUrl()
		const successUrl = buildInternalReturnUrl(successPath, '/app/payment', appBaseUrl)
		if (!successUrl.searchParams.has('checkout')) {
			successUrl.searchParams.set('checkout', 'success')
		}
		if (!successUrl.searchParams.has('tariff')) {
			successUrl.searchParams.set('tariff', offer.slug)
		}
		successUrl.searchParams.set('checkoutSession', checkoutSessionToken)

		const failUrl = buildInternalReturnUrl(failPath, '/app/payment', appBaseUrl)
		if (!failUrl.searchParams.has('checkout')) {
			failUrl.searchParams.set('checkout', 'fail')
		}
		if (!failUrl.searchParams.has('tariff')) {
			failUrl.searchParams.set('tariff', offer.slug)
		}
		failUrl.searchParams.set('checkoutSession', checkoutSessionToken)

		const prodamusSubscriptionId =
			activeProvider.code === 'prodamus'
				? String(
						(
							activeProvider.settings as {
								subscriptionId?: string
							}
						).subscriptionId ?? '',
					).trim()
				: ''
		const providerSupportsRecurrent =
			activeProvider.code === 'cloudpayments' ||
			(activeProvider.code === 'prodamus' && Boolean(prodamusSubscriptionId)) ||
			activeProvider.code === 'tochka'
		const recurrentEnabled =
			checkoutSettings.billingMode === 'recurrent' &&
			cardType === 'russian' &&
			providerSupportsRecurrent &&
			(activeProvider.code !== 'tochka' || firstAmount === regularAmount)
		const manualRenewal = !recurrentEnabled
		const metadata = buildPaymentMetadata({
			offer,
			cardType,
			userId: user.authUuid,
			user,
			firstAmount,
			regularAmount,
			manualRenewal,
			invoiceId,
		})
		const cloudpaymentsJsonData = {
			...metadata,
			...(recurrentEnabled && activeProvider.code === 'cloudpayments'
				? {
						cloudpayments: {
							recurrent: buildCloudPaymentsRecurrentConfig({
								settings: checkoutSettings,
								durationDays: metadata.durationDays,
								firstAccessDays: metadata.demoDays > 0 ? metadata.demoDays : metadata.durationDays,
								regularAmount: metadata.regularAmount,
							}),
						},
					}
				: {}),
		}
		let checkoutUrl = ''

		try {
			if (activeProvider.code === 'cloudpayments') {
				const result = await createOrderLink({
					amount: firstAmount,
					description: `Подписка ${offer.name}`,
					invoiceId,
					accountId: user.authUuid,
					email: user.email ?? undefined,
					phone: user.phone ?? undefined,
					payer: buildCloudPaymentsPayer(user.fullName ?? null, user.phone ?? null),
					successRedirectUrl: successUrl.toString(),
					failRedirectUrl: failUrl.toString(),
					jsonData: cloudpaymentsJsonData,
				})

				checkoutUrl = String(result.Model?.Url ?? '').trim()
				if (!result.Success || !checkoutUrl) {
					logger.error(
						{ userId: user.authUuid, tariffSlug, cardType, result },
						'Failed to create CloudPayments checkout link',
					)
					await logPaymentCheckoutFailure({
						provider: activeProvider.code,
						userId: user.authUuid,
						tariffSlug,
						amount: firstAmount,
						error: new Error('CloudPayments checkout link was not created'),
					})
					return c.json(
						{
							success: false,
							error: {
								code: 'INTERNAL_ERROR',
								message: 'Не удалось создать ссылку на оплату. Попробуйте ещё раз.',
							},
						},
						500,
					)
				}
			} else if (activeProvider.code === 'prodamus') {
				const settings = activeProvider.settings as {
					paymentUrl: string
					secretKey: string
					subscriptionId?: string
				}
				checkoutUrl = buildProdamusCheckoutUrl({
					paymentUrl: settings.paymentUrl,
					secretKey: settings.secretKey,
					subscriptionId: recurrentEnabled ? settings.subscriptionId : undefined,
					invoiceId,
					amount: firstAmount,
					description: `Подписка ${offer.name}`,
					successUrl: successUrl.toString(),
					failUrl: failUrl.toString(),
					webhookUrl: new URL('/api/payments/webhook/prodamus', appBaseUrl).toString(),
					metadata,
				})
			} else if (activeProvider.code === 'yookassa') {
				const settings = activeProvider.settings as { shopId: string; secretKey: string }
				checkoutUrl = await createYookassaCheckoutUrl({
					shopId: settings.shopId,
					secretKey: settings.secretKey,
					invoiceId,
					amount: firstAmount,
					description: `Подписка ${offer.name}`,
					successUrl: successUrl.toString(),
					metadata,
				})
			} else {
				const settings = activeProvider.settings as TochkaSettings
				checkoutUrl = await createTochkaCheckoutUrl({
					settings,
					invoiceId,
					amount: firstAmount,
					description: `Подписка ${offer.name}`,
					successUrl: successUrl.toString(),
					failUrl: failUrl.toString(),
					cardType,
					metadata,
					checkoutSettings,
					recurrent: recurrentEnabled,
				})
			}
		} catch (error) {
			logger.error(
				{ userId: user.authUuid, tariffSlug, cardType, provider: activeProvider.code, error },
				'Payment checkout link request crashed',
			)
			await logPaymentCheckoutFailure({
				provider: activeProvider.code,
				userId: user.authUuid,
				tariffSlug,
				amount: firstAmount,
				error,
			})
			return c.json(
				{
					success: false,
					error: {
						code: 'INTERNAL_ERROR',
						message: 'Не удалось создать ссылку на оплату. Попробуйте ещё раз.',
					},
				},
				500,
			)
		}

		await storeCheckoutMetadata({
			provider: activeProvider.code,
			invoiceId: activeProvider.code === 'tochka' ? getTochkaPaymentLinkId(invoiceId) : invoiceId,
			metadata,
		})

		return c.json({
			success: true,
			data: {
				checkoutUrl,
				firstAmount,
				regularAmount,
				cardType,
				recurrentEnabled,
			},
		})
	},
)

paymentRoutes.get('/subscription', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const userEmail = c.get('userEmail')
	const payment = await rememberCachedValue({
		namespace: 'payments:subscription',
		key: userId,
		ttlSeconds: 15,
		load: () =>
			findPaymentForUser({
				userAuthUuid: userId,
				email: userEmail,
			}),
	})
	if (!payment) {
		return c.json({ success: true, data: null })
	}
	return c.json({ success: true, data: payment })
})

paymentRoutes.post('/subscription/cancel', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const userEmail = c.get('userEmail')
	const payment = await findPaymentForUser({
		userAuthUuid: userId,
		email: userEmail,
	})

	if (!payment?.cpSubscriptionId) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Активная подписка не найдена' } },
			404,
		)
	}

	if (!(await hasCloudPaymentsCredentials())) {
		return c.json(
			{
				success: false,
				error: {
					code: 'CONFIG_ERROR',
					message: 'CloudPayments не настроен на сервере',
				},
			},
			503,
		)
	}

	const result = await cancelRecurrent(payment.cpSubscriptionId)

	if (!result.Success) {
		logger.error({ result }, 'Failed to cancel subscription')
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Не удалось отменить подписку. Попробуйте ещё раз.',
				},
			},
			500,
		)
	}

	await db
		.update(payments)
		.set({ autoPayment: false, noAutopodpiska: true })
		.where(eq(payments.userAuthUuid, userId))
	await invalidateUserAccessCaches(userId)

	return c.json({ success: true, data: { cancelled: true } })
})

paymentRoutes.post('/subscription/leave', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const userEmail = c.get('userEmail')
	const payment = await findPaymentForUser({
		userAuthUuid: userId,
		email: userEmail,
	})

	if (payment?.cpSubscriptionId && (await hasCloudPaymentsCredentials())) {
		const result = await cancelRecurrent(payment.cpSubscriptionId)
		const isAlreadyMissing = result.Success === false && result.Message === 'Not found'

		if (!result.Success && !isAlreadyMissing) {
			logger.error({ result, userId }, 'Failed to cancel subscription during club leave')
			return c.json(
				{
					success: false,
					error: {
						code: 'INTERNAL_ERROR',
						message: 'Не удалось закрыть подписку в CloudPayments. Попробуйте ещё раз.',
					},
				},
				500,
			)
		}
	}

	if (payment) {
		await db
			.update(payments)
			.set({
				tarrif: null,
				dateStart: null,
				dateFinish: null,
				cpSubscriptionId: null,
				cpAccountId: null,
				cpToken: null,
				paymentProvider: null,
				amount: null,
				autoPayment: false,
				noAutopodpiska: true,
			})
			.where(eq(payments.id, payment.id))
	}
	await invalidateUserAccessCaches(userId)

	await db
		.update(users)
		.set({
			role: 'user',
		})
		.where(eq(users.authUuid, userId))

	await db.insert(paymentLogs).values({
		event: 'leave_club',
		userAuthUuid: userId,
		email: c.get('userEmail'),
		subscriptionId: payment?.cpSubscriptionId ?? null,
		tariff: payment?.tarrif ?? null,
		status: 'success',
		webhookType: 'manual',
	})

	return c.json({ success: true, data: { left: true } })
})

paymentRoutes.post('/webhook/check', async (c) => {
	const { rawBody, body } = await parseCloudPaymentsWebhookBody(c)
	const signature = getCloudPaymentsWebhookSignature(c)
	if (!(await verifyCloudPaymentsWebhookHmac(rawBody, signature))) {
		logger.warn('Invalid webhook signature for /webhook/check')
		return c.json({ code: 13 }, 403)
	}

	await logWebhookEvent({ body, event: 'check', status: 'accepted' })
	return c.json({ code: 0 })
})

paymentRoutes.post('/webhook/pay', async (c) => {
	const { rawBody, body } = await parseCloudPaymentsWebhookBody(c)
	const signature = getCloudPaymentsWebhookSignature(c)
	if (!(await verifyCloudPaymentsWebhookHmac(rawBody, signature))) {
		logger.warn('Invalid webhook signature for /webhook/pay')
		return c.json({ code: 13 }, 403)
	}

	logger.info(
		{ webhook: 'pay', body: redactPaymentWebhookPayload(body) },
		'Payment webhook received',
	)

	const claim = await claimWebhookEvent({ body, event: 'pay' })
	if (!claim.claimed) return c.json({ code: 0 })

	try {
		await syncPaymentStateFromWebhook(body, 'pay', claim.logId)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'success' })
	} catch (error) {
		const message = error instanceof Error ? error.message : 'Payment webhook processing failed'
		await finalizeWebhookEvent({ logId: claim.logId, status: 'failed', errorMessage: message })
		throw error
	}

	return c.json({ code: 0 })
})

paymentRoutes.post('/webhook/fail', async (c) => {
	const { rawBody, body } = await parseCloudPaymentsWebhookBody(c)
	const signature = getCloudPaymentsWebhookSignature(c)
	if (!(await verifyCloudPaymentsWebhookHmac(rawBody, signature))) {
		return c.json({ code: 13 }, 403)
	}

	logger.warn(
		{ webhook: 'fail', body: redactPaymentWebhookPayload(body) },
		'Payment failed webhook',
	)

	await logWebhookEvent({
		body,
		event: 'fail',
		status: 'failed',
		errorMessage: String(body.Reason ?? ''),
	})

	return c.json({ code: 0 })
})

paymentRoutes.post('/webhook/recurrent', async (c) => {
	const { rawBody, body } = await parseCloudPaymentsWebhookBody(c)
	const signature = getCloudPaymentsWebhookSignature(c)
	if (!(await verifyCloudPaymentsWebhookHmac(rawBody, signature))) {
		return c.json({ code: 13 }, 403)
	}

	logger.info(
		{ webhook: 'recurrent', body: redactPaymentWebhookPayload(body) },
		'Recurrent payment webhook',
	)

	const status = body.Status === 'Completed' ? 'success' : 'failed'

	if (status === 'success') {
		const claim = await claimWebhookEvent({ body, event: 'recurrent' })
		if (!claim.claimed) return c.json({ code: 0 })

		try {
			await syncPaymentStateFromWebhook(body, 'recurrent', claim.logId)
			await finalizeWebhookEvent({ logId: claim.logId, status: 'success' })
		} catch (error) {
			const message = error instanceof Error ? error.message : 'Recurrent webhook processing failed'
			await finalizeWebhookEvent({ logId: claim.logId, status: 'failed', errorMessage: message })
			throw error
		}
	} else {
		await logWebhookEvent({
			body,
			event: 'recurrent',
			status,
			errorMessage: String(body.Reason ?? ''),
		})
	}

	return c.json({ code: 0 })
})

paymentRoutes.post('/webhook/cancel', async (c) => {
	const { rawBody, body } = await parseCloudPaymentsWebhookBody(c)
	const signature = getCloudPaymentsWebhookSignature(c)
	if (!(await verifyCloudPaymentsWebhookHmac(rawBody, signature))) {
		return c.json({ code: 13 }, 403)
	}

	await logWebhookEvent({ body, event: 'cancel', status: 'cancelled' })

	const subscriptionId = String(body.SubscriptionId ?? '').trim()
	if (subscriptionId) {
		await db
			.update(payments)
			.set({ autoPayment: false, noAutopodpiska: true })
			.where(eq(payments.cpSubscriptionId, subscriptionId))
	}

	return c.json({ code: 0 })
})

paymentRoutes.post('/webhook/prodamus', async (c) => {
	const { body, flatBody } = await parseGenericWebhookBody(c)
	const settings = await loadPaymentProviderSecrets()
	const signature =
		c.req.header('Sign') ?? c.req.header('X-Signature') ?? c.req.header('X-Prodamus-Sign')

	if (
		!verifyProdamusSignature({
			payload: body,
			flatPayload: flatBody,
			secret: settings.prodamus.secretKey,
			signature: signature ?? getWebhookString(body, ['signature', 'sign']),
		})
	) {
		logger.warn('Invalid Prodamus webhook signature')
		await logGenericPaymentWebhook({
			provider: 'prodamus',
			event: 'webhook',
			body,
			status: 'failed',
			errorMessage: 'Invalid signature',
		})
		return c.json({ success: false }, 403)
	}

	const event = getWebhookString(body, ['event', 'payment_status', 'status']) || 'webhook'
	const claim = await claimExternalPaymentWebhookEvent({
		provider: 'prodamus',
		event,
		body,
	})
	if (!claim.claimed) return c.json({ success: true })

	try {
		if (!isSuccessfulExternalPayment('prodamus', body)) {
			await finalizeWebhookEvent({ logId: claim.logId, status: 'ignored' })
			return c.json({ success: true })
		}
		await syncExternalPaymentStateFromWebhook('prodamus', body, claim.logId)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'success' })
	} catch (error) {
		const message = error instanceof Error ? error.message : 'Webhook sync failed'
		logger.error(
			{ err: error, body: redactPaymentWebhookPayload(body) },
			'Prodamus webhook sync failed',
		)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'failed', errorMessage: message })
		return c.json({ success: false }, 500)
	}

	return c.json({ success: true })
})

paymentRoutes.post('/webhook/yookassa', async (c) => {
	const { body } = await parseGenericWebhookBody(c)
	const settings = await loadPaymentProviderSecrets()
	const paymentId = getWebhookString(body, ['object.id', 'id'])
	const verifiedPayment =
		paymentId && settings.yookassa.shopId && settings.yookassa.secretKey
			? await loadYookassaPayment({
					shopId: settings.yookassa.shopId,
					secretKey: settings.yookassa.secretKey,
					paymentId,
				})
			: null

	if (!verifiedPayment || getWebhookString(verifiedPayment, ['status']) !== 'succeeded') {
		logger.warn(
			{ paymentId, body: redactPaymentWebhookPayload(body) },
			'YooKassa webhook could not be verified',
		)
		await logGenericPaymentWebhook({
			provider: 'yookassa',
			event: getWebhookString(body, ['event']) || 'webhook',
			body,
			status: 'failed',
			errorMessage: 'Payment is not verified',
		})
		return c.json({ success: false }, 403)
	}

	const syncBody = setWebhookValue({ ...body }, 'object', verifiedPayment)
	const event = getWebhookString(body, ['event']) || 'webhook'
	const claim = await claimExternalPaymentWebhookEvent({
		provider: 'yookassa',
		event,
		body: syncBody,
	})
	if (!claim.claimed) return c.json({ success: true })

	try {
		await syncExternalPaymentStateFromWebhook('yookassa', syncBody, claim.logId)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'success' })
	} catch (error) {
		const message = error instanceof Error ? error.message : 'Webhook sync failed'
		logger.error(
			{ err: error, body: redactPaymentWebhookPayload(body) },
			'YooKassa webhook sync failed',
		)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'failed', errorMessage: message })
		return c.json({ success: false }, 500)
	}

	return c.json({ success: true })
})

paymentRoutes.post('/webhook/tochka', async (c) => {
	const { rawBody } = await parseGenericWebhookBody(c)
	const settings = await loadPaymentProviderSecrets()
	const webhookBody = await decodeVerifiedTochkaWebhook(rawBody)
	if (!webhookBody) {
		logger.warn('Invalid Tochka webhook signature')
		return c.json({ success: false }, 403)
	}
	const operationId = getWebhookString(webhookBody, [
		'operationId',
		'Data.operationId',
		'object.operationId',
	])
	if (!operationId) return c.json({ success: true })
	const verifiedPayment =
		operationId && settings.tochka.customerCode && settings.tochka.jwtToken
			? await loadTochkaPayment({
					settings: settings.tochka,
					operationId,
				})
			: null
	const operation = {
		...webhookBody,
		...(verifiedPayment?.Data ?? {}),
	}
	const syncBody = {
		...webhookBody,
		...operation,
		Data: operation,
		object: operation,
	}
	const event = getWebhookString(syncBody, ['event', 'status', 'Data.status']) || 'webhook'

	if (!verifiedPayment?.Data) {
		logger.warn(
			{ operationId, body: redactPaymentWebhookPayload(webhookBody) },
			'Tochka webhook could not be verified',
		)
		await logGenericPaymentWebhook({
			provider: 'tochka',
			event,
			body: syncBody,
			status: 'ignored',
			errorMessage: 'Payment is not verified',
		})
		return c.json({ success: true })
	}

	const claim = await claimExternalPaymentWebhookEvent({
		provider: 'tochka',
		event,
		body: syncBody,
	})
	if (!claim.claimed) return c.json({ success: true })

	try {
		if (!isSuccessfulExternalPayment('tochka', syncBody)) {
			await finalizeWebhookEvent({ logId: claim.logId, status: 'ignored' })
			return c.json({ success: true })
		}
		await syncExternalPaymentStateFromWebhook('tochka', syncBody, claim.logId)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'success' })
	} catch (error) {
		const message = error instanceof Error ? error.message : 'Webhook sync failed'
		logger.error(
			{ err: error, body: redactPaymentWebhookPayload(webhookBody) },
			'Tochka webhook sync failed',
		)
		await finalizeWebhookEvent({ logId: claim.logId, status: 'failed', errorMessage: message })
		return c.json({ success: false }, 500)
	}

	return c.json({ success: true })
})
