import { pushCampaignRuns, pushCampaigns, safeNavigationUrlSchema } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

const audienceSchema = z.enum(['all', 'active'])
const audienceOptions = ['all', 'active'] as const

const oneTimeSchema = z.object({
	name: z.string().trim().min(1).max(120),
	title: z.string().trim().min(1).max(120),
	body: z.string().trim().min(1).max(2000),
	url: safeNavigationUrlSchema.optional().or(z.literal('')).nullable(),
	audience: audienceSchema.default('all'),
	sendAt: z.string().datetime().optional(),
})

const regularSchema = z.object({
	name: z.string().trim().min(1).max(120),
	title: z.string().trim().min(1).max(120),
	body: z.string().trim().min(1).max(2000),
	url: safeNavigationUrlSchema.optional().or(z.literal('')).nullable(),
	audience: audienceSchema.default('all'),
	offsetDays: z.array(z.number().int().min(-30).max(30)).min(1).max(16),
	isEnabled: z.boolean().default(true),
})

const updateSchema = z.object({
	name: z.string().trim().min(1).max(120).optional(),
	title: z.string().trim().min(1).max(120).optional(),
	body: z.string().trim().min(1).max(2000).optional(),
	url: safeNavigationUrlSchema.optional().or(z.literal('')).nullable(),
	audience: audienceSchema.optional(),
	offsetDays: z.array(z.number().int().min(-30).max(30)).min(1).max(16).optional(),
	isEnabled: z.boolean().optional(),
	status: z.enum(['draft', 'scheduled', 'active', 'paused']).optional(),
	sendAt: z.string().datetime().optional().nullable(),
})

export const adminNotificationRoutes = new Hono<AppEnv>()

adminNotificationRoutes.use('*', authMiddleware, adminMiddleware)

adminNotificationRoutes.get('/', async (c) => {
	const [campaigns, runs] = await Promise.all([
		db.query.pushCampaigns.findMany({
			orderBy: [desc(pushCampaigns.createdAt)],
			limit: 100,
		}),
		db.query.pushCampaignRuns.findMany({
			with: {
				campaign: {
					columns: {
						id: true,
						name: true,
						kind: true,
						audience: true,
					},
				},
			},
			orderBy: [desc(pushCampaignRuns.startedAt)],
			limit: 100,
		}),
	])

	return c.json({
		success: true,
		data: {
			campaigns,
			runs,
			audiences: audienceOptions,
			bodyMaxLength: 2000,
			titleMaxLength: 120,
		},
	})
})

adminNotificationRoutes.post('/one-time', zValidator('json', oneTimeSchema), async (c) => {
	const body = c.req.valid('json')
	const userId = c.get('userId')

	const [campaign] = await db
		.insert(pushCampaigns)
		.values({
			name: body.name,
			kind: 'one_time',
			status: 'scheduled',
			audience: body.audience,
			title: body.title,
			body: body.body,
			url: body.url || null,
			sendAt: body.sendAt ? new Date(body.sendAt) : new Date(),
			isEnabled: true,
			createdByAuthUuid: userId,
		})
		.returning()

	return c.json({ success: true, data: campaign }, 201)
})

adminNotificationRoutes.post('/regular', zValidator('json', regularSchema), async (c) => {
	const body = c.req.valid('json')
	const userId = c.get('userId')

	const [campaign] = await db
		.insert(pushCampaigns)
		.values({
			name: body.name,
			kind: 'billing_relative',
			status: body.isEnabled ? 'active' : 'paused',
			audience: body.audience,
			title: body.title,
			body: body.body,
			url: body.url || null,
			offsetDays: Array.from(new Set(body.offsetDays)).sort((a, b) => a - b),
			isEnabled: body.isEnabled,
			createdByAuthUuid: userId,
		})
		.returning()

	return c.json({ success: true, data: campaign }, 201)
})

adminNotificationRoutes.patch('/:id', zValidator('json', updateSchema), async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isFinite(id)) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Некорректный идентификатор кампании' },
			},
			400,
		)
	}

	const body = c.req.valid('json')
	const existing = await db.query.pushCampaigns.findFirst({
		where: eq(pushCampaigns.id, id),
	})

	if (!existing) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Push-кампания не найдена' } },
			404,
		)
	}

	const nextStatus =
		body.status ??
		(body.isEnabled == null
			? existing.status
			: body.isEnabled
				? existing.kind === 'billing_relative'
					? 'active'
					: existing.status === 'completed'
						? 'completed'
						: 'scheduled'
				: 'paused')

	const [campaign] = await db
		.update(pushCampaigns)
		.set({
			name: body.name ?? existing.name,
			title: body.title ?? existing.title,
			body: body.body ?? existing.body,
			url: body.url === undefined ? existing.url : body.url || null,
			audience: body.audience ?? existing.audience,
			offsetDays:
				body.offsetDays == null
					? existing.offsetDays
					: Array.from(new Set(body.offsetDays)).sort((a, b) => a - b),
			isEnabled: body.isEnabled ?? existing.isEnabled,
			status: nextStatus,
			sendAt:
				body.sendAt === undefined
					? existing.sendAt
					: body.sendAt == null
						? null
						: new Date(body.sendAt),
			updatedAt: new Date(),
		})
		.where(eq(pushCampaigns.id, id))
		.returning()

	return c.json({ success: true, data: campaign })
})

adminNotificationRoutes.post('/:id/send-now', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isFinite(id)) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Некорректный идентификатор кампании' },
			},
			400,
		)
	}

	const existing = await db.query.pushCampaigns.findFirst({
		where: and(eq(pushCampaigns.id, id), eq(pushCampaigns.kind, 'one_time')),
	})
	if (!existing) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Разовая push-кампания не найдена' } },
			404,
		)
	}

	const [campaign] = await db
		.update(pushCampaigns)
		.set({
			status: 'scheduled',
			sendAt: new Date(),
			isEnabled: true,
			updatedAt: new Date(),
		})
		.where(eq(pushCampaigns.id, id))
		.returning()

	return c.json({ success: true, data: campaign })
})
