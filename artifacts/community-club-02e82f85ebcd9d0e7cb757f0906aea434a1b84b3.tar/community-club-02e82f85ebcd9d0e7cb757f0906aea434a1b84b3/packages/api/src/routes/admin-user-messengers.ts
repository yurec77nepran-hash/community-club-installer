import { Hono } from 'hono'
import type { AppEnv } from '../app'
import { getUserMessengerContacts } from '../lib/messenger-contacts'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

export const adminUserMessengerRoutes = new Hono<AppEnv>()

adminUserMessengerRoutes.use('*', authMiddleware, adminMiddleware)

adminUserMessengerRoutes.get('/:uuid/messenger-contacts', async (c) => {
	return c.json({ success: true, data: await getUserMessengerContacts(c.req.param('uuid')) })
})
