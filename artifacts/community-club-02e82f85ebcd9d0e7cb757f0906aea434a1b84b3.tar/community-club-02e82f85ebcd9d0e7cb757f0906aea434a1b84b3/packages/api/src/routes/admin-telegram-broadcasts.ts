import {
	type TelegramBroadcastButton,
	type TelegramBroadcastMedia,
	sanitizeTelegramBroadcastHtml,
	telegramBroadcastDeliveries,
	telegramBroadcastPlainText,
	telegramBroadcasts,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, ne, sql } from 'drizzle-orm'
import { type Context, Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { appendAdminActivityLog } from '../lib/admin-activity'
import { resolvePublicFileUrl } from '../lib/storage'
import {
	type TelegramBroadcastDeliveryMode,
	getTelegramBroadcastAudience,
} from '../lib/telegram-broadcast-audience'
import {
	getPublicTelegramBroadcastBots,
	getTelegramBroadcastBot,
	normalizeTelegramBotUsername,
} from '../lib/telegram-broadcast-bots'
import {
	findTelegramChatIdByUsername,
	sendTelegramBroadcastMessage,
} from '../lib/telegram-broadcast-message'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

const OWNER_TELEGRAM_USERNAME = 'oleggorskyj'
const botUsernameSchema = z.string().trim().min(1).max(128)
const buttonSchema = z.object({
	id: z.string().trim().min(1).max(80),
	text: z.string().trim().min(1).max(64),
	url: z.string().trim().url().max(2000),
	color: z.enum(['default', 'primary', 'success', 'danger']),
})
const mediaSchema = z.object({
	path: z
		.string()
		.trim()
		.min(1)
		.max(512)
		.refine((path) => !path.includes('..')),
	name: z.string().trim().min(1).max(255),
	type: z.enum(['image', 'video', 'audio', 'document']),
})
const contentSchema = z.object({
	botUsernames: z.array(botUsernameSchema).min(1).max(10),
	deliveryMode: z.enum(['all', 'unique']).default('all'),
	preferredBotUsername: botUsernameSchema.optional().nullable(),
	body: z.string().max(20_000).default(''),
	buttons: z.array(buttonSchema).max(10).default([]),
	media: mediaSchema.nullable().optional(),
})
const createSchema = contentSchema.extend({
	name: z.string().trim().min(1).max(120),
	sendAt: z.string().datetime().optional(),
})

type BroadcastContent = z.infer<typeof contentSchema>

function normalizeContent(body: BroadcastContent) {
	const botUsernames = Array.from(
		new Set(body.botUsernames.map(normalizeTelegramBotUsername).filter(Boolean)),
	)
	if (!botUsernames.length) throw new Error('Выберите хотя бы одного Telegram-бота')
	const html = sanitizeTelegramBroadcastHtml(body.body)
	const text = telegramBroadcastPlainText(html)
	if (!text && !body.media) throw new Error('Добавьте текст или вложение')
	if (text.length > 4096) throw new Error('Текст сообщения не должен превышать 4 096 символов')
	if (new Set(body.buttons.map((button) => button.id)).size !== body.buttons.length) {
		throw new Error('Кнопки должны быть уникальными')
	}
	if (body.buttons.some((button) => !/^https?:\/\//i.test(button.url))) {
		throw new Error('Ссылка кнопки должна начинаться с http:// или https://')
	}
	if (botUsernames.some((username) => !getTelegramBroadcastBot(username))) {
		throw new Error('Выберите только настроенных Telegram-ботов')
	}
	const deliveryMode: TelegramBroadcastDeliveryMode = body.deliveryMode
	const preferredBotUsername =
		deliveryMode === 'unique'
			? normalizeTelegramBotUsername(body.preferredBotUsername || botUsernames[0])
			: null
	if (preferredBotUsername && !botUsernames.includes(preferredBotUsername)) {
		throw new Error('Бот для пересечений должен быть выбран для рассылки')
	}
	return {
		botUsernames,
		deliveryMode,
		preferredBotUsername,
		body: html,
		buttons: body.buttons as TelegramBroadcastButton[],
		media: body.media ?? null,
	}
}

function badRequest(c: Context<AppEnv>, message: string) {
	return c.json({ success: false, error: { code: 'BAD_REQUEST', message } }, 400)
}

function resolveMedia(media: TelegramBroadcastMedia | null) {
	if (!media) return null
	const url = resolvePublicFileUrl('media', media.path)
	if (!url) throw new Error('Файл вложения не найден')
	return { type: media.type, url }
}

async function findOwnerRecipients(botUsernames: string[]) {
	const contacts = await db.execute<{ bot_username: string; telegram_user_id: string }>(sql`
		SELECT bot_username, telegram_user_id
		FROM telegram_contacts
		WHERE lower(coalesce(telegram_username, '')) = ${OWNER_TELEGRAM_USERNAME}
			AND bot_username IN (${sql.join(
				botUsernames.map((username) => sql`${username}`),
				sql`, `,
			)})
	`)
	const byBot = new Map(contacts.map((contact) => [contact.bot_username, contact.telegram_user_id]))
	for (const botUsername of botUsernames) {
		if (byBot.has(botUsername)) continue
		const bot = getTelegramBroadcastBot(botUsername)
		if (!bot) continue
		const chatId = await findTelegramChatIdByUsername(bot.token, OWNER_TELEGRAM_USERNAME).catch(
			() => null,
		)
		if (chatId) byBot.set(botUsername, chatId)
	}
	return byBot
}

export const adminTelegramBroadcastRoutes = new Hono<AppEnv>()

adminTelegramBroadcastRoutes.use('*', authMiddleware, adminMiddleware)

adminTelegramBroadcastRoutes.get('/', async (c) => {
	const [campaigns, bots] = await Promise.all([
		db.query.telegramBroadcasts.findMany({
			orderBy: [desc(telegramBroadcasts.createdAt)],
			limit: 100,
		}),
		Promise.resolve(getPublicTelegramBroadcastBots()),
	])
	return c.json({ success: true, data: { campaigns, bots } })
})

adminTelegramBroadcastRoutes.get(
	'/audience',
	zValidator('query', z.object({ bots: z.string().trim().min(1).max(1500) })),
	async (c) => {
		const botUsernames = Array.from(
			new Set(
				c.req.valid('query').bots.split(',').map(normalizeTelegramBotUsername).filter(Boolean),
			),
		)
		if (!botUsernames.length) return badRequest(c, 'Выберите хотя бы одного Telegram-бота')
		if (botUsernames.some((username) => !getTelegramBroadcastBot(username))) {
			return badRequest(c, 'Выберите только настроенных Telegram-ботов')
		}
		return c.json({ success: true, data: await getTelegramBroadcastAudience(botUsernames) })
	},
)

adminTelegramBroadcastRoutes.get('/:id/deliveries', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) return badRequest(c, 'Некорректный ID')
	const failedOnly = c.req.query('status') === 'failed'
	const rows = await db.execute<{
		id: number
		status: 'pending' | 'processing' | 'sent' | 'failed'
		error_message: string | null
		telegram_user_id: string
		telegram_username: string | null
		full_name: string | null
	}>(sql`
		SELECT d.id, d.status, d.error_message, c.telegram_user_id, c.telegram_username, u.full_name
		FROM telegram_broadcast_deliveries d
		JOIN telegram_contacts c ON c.id = d.contact_id
		JOIN users u ON u.auth_uuid = c.user_auth_uuid
		WHERE d.broadcast_id = ${id} ${failedOnly ? sql`AND d.status = 'failed'` : sql``}
		ORDER BY d.id DESC LIMIT 500
	`)
	return c.json({ success: true, data: rows })
})

adminTelegramBroadcastRoutes.post('/', zValidator('json', createSchema), async (c) => {
	let content: ReturnType<typeof normalizeContent>
	try {
		content = normalizeContent(c.req.valid('json'))
	} catch (reason) {
		return badRequest(c, reason instanceof Error ? reason.message : 'Некорректная рассылка')
	}
	const input = c.req.valid('json')
	const [campaign] = await db
		.insert(telegramBroadcasts)
		.values({
			name: input.name,
			botUsername: content.botUsernames[0],
			...content,
			sendAt: input.sendAt ? new Date(input.sendAt) : new Date(),
			createdByAuthUuid: c.get('userId'),
		})
		.returning()
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'create',
		entityType: 'telegram_broadcast',
		entityId: String(campaign.id),
		summary: `Создана Telegram-рассылка «${campaign.name}»`,
		details: { botUsernames: content.botUsernames, deliveryMode: content.deliveryMode },
	})
	return c.json({ success: true, data: campaign }, 201)
})

adminTelegramBroadcastRoutes.post('/test', zValidator('json', contentSchema), async (c) => {
	let content: ReturnType<typeof normalizeContent>
	try {
		content = normalizeContent(c.req.valid('json'))
	} catch (reason) {
		return badRequest(c, reason instanceof Error ? reason.message : 'Некорректная рассылка')
	}
	const recipients = await findOwnerRecipients(content.botUsernames)
	if (!recipients.size) {
		return c.json(
			{
				success: false,
				error: {
					code: 'TEST_RECIPIENT_NOT_FOUND',
					message: `Откройте выбранного бота с аккаунта @${OWNER_TELEGRAM_USERNAME} и отправьте /start, затем повторите тест.`,
				},
			},
			404,
		)
	}
	const media = resolveMedia(content.media)
	const sentBots: string[] = []
	for (const [botUsername, chatId] of recipients) {
		const bot = getTelegramBroadcastBot(botUsername)
		if (!bot) continue
		await sendTelegramBroadcastMessage({
			token: bot.token,
			chatId,
			body: content.body,
			buttons: content.buttons,
			media,
		})
		sentBots.push(botUsername)
	}
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'create',
		entityType: 'telegram_broadcast_test',
		entityId: null,
		summary: `Отправлен тест Telegram-рассылки для @${OWNER_TELEGRAM_USERNAME}`,
		details: { botUsernames: sentBots },
	})
	return c.json({
		success: true,
		data: { sentBots, missingBots: content.botUsernames.filter((bot) => !recipients.has(bot)) },
	})
})

adminTelegramBroadcastRoutes.post('/:id/send-now', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) return badRequest(c, 'Некорректный ID')
	const [campaign] = await db
		.update(telegramBroadcasts)
		.set({ sendAt: new Date(), status: 'scheduled', updatedAt: new Date() })
		.where(and(eq(telegramBroadcasts.id, id), eq(telegramBroadcasts.status, 'scheduled')))
		.returning()
	if (!campaign) return badRequest(c, 'Рассылка уже обрабатывается или завершена')
	return c.json({ success: true, data: campaign })
})

adminTelegramBroadcastRoutes.delete('/:id', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) return badRequest(c, 'Некорректный ID')
	const [campaign] = await db
		.update(telegramBroadcasts)
		.set({ status: 'cancelled', updatedAt: new Date() })
		.where(and(eq(telegramBroadcasts.id, id), eq(telegramBroadcasts.status, 'scheduled')))
		.returning()
	if (!campaign) return badRequest(c, 'Можно отменить только запланированную рассылку')
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'delete',
		entityType: 'telegram_broadcast',
		entityId: String(campaign.id),
		summary: `Отменена Telegram-рассылка «${campaign.name}»`,
	})
	return c.json({ success: true, data: campaign })
})

adminTelegramBroadcastRoutes.post('/:id/pause', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) return badRequest(c, 'Некорректный ID')
	const [campaign] = await db
		.update(telegramBroadcasts)
		.set({ status: 'paused', updatedAt: new Date() })
		.where(and(eq(telegramBroadcasts.id, id), eq(telegramBroadcasts.status, 'processing')))
		.returning()
	if (!campaign) return badRequest(c, 'Можно приостановить только отправляющуюся рассылку')
	return c.json({ success: true, data: campaign })
})

adminTelegramBroadcastRoutes.post('/:id/resume', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) return badRequest(c, 'Некорректный ID')
	const [campaign] = await db
		.update(telegramBroadcasts)
		.set({ status: 'scheduled', updatedAt: new Date() })
		.where(and(eq(telegramBroadcasts.id, id), eq(telegramBroadcasts.status, 'paused')))
		.returning()
	if (!campaign) return badRequest(c, 'Можно возобновить только приостановленную рассылку')
	return c.json({ success: true, data: campaign })
})

adminTelegramBroadcastRoutes.post('/:id/stop', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) return badRequest(c, 'Некорректный ID')
	const [campaign] = await db
		.update(telegramBroadcasts)
		.set({ status: 'cancelled', updatedAt: new Date() })
		.where(and(eq(telegramBroadcasts.id, id), ne(telegramBroadcasts.status, 'completed')))
		.returning()
	if (!campaign) return badRequest(c, 'Рассылка уже завершена')
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'delete',
		entityType: 'telegram_broadcast',
		entityId: String(campaign.id),
		summary: `Остановлена Telegram-рассылка «${campaign.name}»`,
	})
	return c.json({ success: true, data: campaign })
})
