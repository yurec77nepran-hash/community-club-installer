import { db } from '../db/client'
import { createPwaLaunchHistoryStore } from '../lib/pwa-launch-history'
import { authMiddleware } from '../middleware/auth'
import { createPwaRoutes } from './pwa-routes'

export const pwaRoutes = createPwaRoutes({
	authenticate: authMiddleware,
	store: createPwaLaunchHistoryStore(db),
})
