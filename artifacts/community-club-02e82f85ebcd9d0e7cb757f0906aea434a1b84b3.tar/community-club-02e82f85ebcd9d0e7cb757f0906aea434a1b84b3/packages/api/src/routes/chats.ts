import { lookup } from 'node:dns/promises'
import { isIP } from 'node:net'
import {
	type ChatListItem,
	type ChatUserProfile,
	type MentionCandidate,
	type ScheduledChatMessageItem,
	chatMembers,
	chatNotificationSettingsSchema,
	chats,
	createScheduledMessageSchema,
	cursorPaginationSchema,
	editMessageSchema,
	messageMentions,
	messageReactions,
	messages,
	muteUserSchema,
	scheduledChatMessages,
	searchSchema,
	sendMessageSchema,
	users,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, asc, desc, eq, gt, ilike, lt } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { ensureChatAccess, isSupportChatSlug } from '../lib/chat-access'
import { deliverChatMessage } from '../lib/chat-delivery'
import {
	getChatListItemsForUser,
	getMentionCandidates,
	loadMessageWithMeta,
	markChatRead,
	normalizeMentions,
} from '../lib/chat-mentions'
import { getChatNotificationSettings, setChatNotificationSettings } from '../lib/chat-notifications'
import { isChatManager, normalizeChatSettings } from '../lib/chat-settings'
import { resolveScheduledMessageDate } from '../lib/scheduled-chat-message-utils'
import { resolveAvatarUrl } from '../lib/storage'
import { adminMiddleware, authMiddleware } from '../middleware/auth'
import { uploadQueueMiddleware } from '../middleware/queue'
import { broadcastChatRoomEvent } from '../ws/handler'

export const chatRoutes = new Hono<AppEnv>()
const LINK_PREVIEW_MAX_HTML_BYTES = 512 * 1024

function isPrivateIpAddress(address: string) {
	if (address === '127.0.0.1' || address === '0.0.0.0' || address === '::1') return true
	if (
		address.startsWith('10.') ||
		address.startsWith('192.168.') ||
		address.startsWith('169.254.')
	) {
		return true
	}
	if (/^172\.(1[6-9]|2\d|3[01])\./.test(address)) return true
	const normalized = address.toLowerCase()
	return (
		normalized === 'localhost' ||
		normalized.startsWith('fc') ||
		normalized.startsWith('fd') ||
		normalized.startsWith('fe80')
	)
}

async function validateLinkPreviewUrl(value: string) {
	let parsed: URL
	try {
		parsed = new URL(value)
	} catch {
		return { ok: false as const, status: 400, code: 'BAD_REQUEST', message: 'Некорректная ссылка' }
	}

	if (!['http:', 'https:'].includes(parsed.protocol)) {
		return {
			ok: false as const,
			status: 400,
			code: 'BAD_REQUEST',
			message: 'Разрешены только ссылки http и https',
		}
	}

	if (parsed.username || parsed.password) {
		return {
			ok: false as const,
			status: 403,
			code: 'FORBIDDEN',
			message: 'Такая ссылка недоступна для предпросмотра',
		}
	}

	const hostname = parsed.hostname.toLowerCase()
	if (hostname === 'metadata.google' || isPrivateIpAddress(hostname)) {
		return {
			ok: false as const,
			status: 403,
			code: 'FORBIDDEN',
			message: 'Такая ссылка недоступна для предпросмотра',
		}
	}

	if (!isIP(hostname)) {
		const addresses = await lookup(hostname, { all: true }).catch(() => [])
		if (addresses.some((entry) => isPrivateIpAddress(entry.address))) {
			return {
				ok: false as const,
				status: 403,
				code: 'FORBIDDEN',
				message: 'Такая ссылка недоступна для предпросмотра',
			}
		}
	}

	return { ok: true as const, url: parsed.toString() }
}

async function readResponseTextWithLimit(response: Response, maxBytes: number) {
	if (!response.body) return ''
	const reader = response.body.getReader()
	const decoder = new TextDecoder()
	let total = 0
	let html = ''

	while (true) {
		const { done, value } = await reader.read()
		if (done) break
		total += value.byteLength
		if (total > maxBytes) {
			await reader.cancel().catch(() => undefined)
			throw new Error('LINK_PREVIEW_TOO_LARGE')
		}
		html += decoder.decode(value, { stream: true })
	}

	return html + decoder.decode()
}

const chatMessagesQuerySchema = cursorPaginationSchema.extend({
	after: z.coerce.number().int().positive().optional(),
})
const markChatReadSchema = z.object({
	latestMessageId: z.coerce.number().int().positive().nullable().optional(),
})
const chatUserProfileParamsSchema = z.object({
	chatId: z.coerce.number().int().positive(),
	userId: z.string().uuid(),
})
const chatUserProfileQuerySchema = z.object({
	messageId: z.coerce.number().int().positive().optional(),
})

function normalizeMessageAuthorAvatar<T extends { author?: { avatarUrl: string | null } | null }>(
	item: T,
): T {
	if (!item.author) return item
	return {
		...item,
		author: {
			...item.author,
			avatarUrl: resolveAvatarUrl(item.author.avatarUrl),
		},
	}
}

function normalizeChatMessageResponse<
	T extends {
		author?: { avatarUrl: string | null } | null
		replyTo?: ({ isDeleted?: boolean } & Record<string, unknown>) | null
	},
>(item: T) {
	const normalized = normalizeMessageAuthorAvatar(item)
	if (!normalized.replyTo) return normalized
	if (normalized.replyTo.isDeleted) {
		return {
			...normalized,
			replyTo: null,
		}
	}
	const { isDeleted: _isDeleted, ...replyTo } = normalized.replyTo
	return {
		...normalized,
		replyTo,
	}
}

function getChatPushUrl(chat: { slug: string; id: number }) {
	return chat.slug.startsWith('support') ? '/app/support' : `/app/chats/${chat.id}`
}

function normalizeSocialLinks(
	links: string[] | null | undefined,
	socialAccount: string | null | undefined,
) {
	const normalized = (links ?? []).map((item) => item.trim()).filter(Boolean)
	if (normalized.length > 0) return Array.from(new Set(normalized)).slice(0, 4)
	const fallback = socialAccount?.trim()
	return fallback ? [fallback] : []
}

function buildChatUserProfile(user: {
	authUuid: string
	fullName: string | null
	username: string | null
	avatarUrl: string | null
	chatAdminBadge: boolean
	socialAccount: string | null
	socialLinks: string[] | null
}): ChatUserProfile {
	return {
		userAuthUuid: user.authUuid,
		fullName: user.fullName,
		username: user.username,
		avatarUrl: resolveAvatarUrl(user.avatarUrl),
		chatAdminBadge: user.chatAdminBadge,
		socialLinks: normalizeSocialLinks(user.socialLinks, user.socialAccount),
		status: null,
		badges: [],
	}
}

function normalizeScheduledAuthorAvatar<
	T extends {
		author?: {
			avatarUrl: string | null
		} | null
	},
>(item: T): T {
	if (!item.author) return item
	return {
		...item,
		author: {
			...item.author,
			avatarUrl: resolveAvatarUrl(item.author.avatarUrl),
		},
	}
}

chatRoutes.use('*', authMiddleware)
chatRoutes.use('*', async (c, next) => {
	const role = c.get('userRole')
	if (role === 'admin' || role === 'superadmin' || c.get('hasActiveSubscription')) {
		return next()
	}
	if (c.req.method === 'GET' && c.req.path === '/api/chats') {
		return next()
	}

	const match = c.req.path.match(/^\/api\/chats\/(\d+)(?:\/|$)/)
	const chatId = match ? Number(match[1]) : null
	const chat =
		chatId == null
			? null
			: await db.query.chats.findFirst({
					where: eq(chats.id, chatId),
					columns: { slug: true },
				})

	if (chat && (isSupportChatSlug(chat.slug) || chat.slug === 'club-chat')) {
		return next()
	}

	return c.json(
		{
			success: false,
			error: {
				code: 'SUBSCRIPTION_EXPIRED',
				message: 'Подписка закончилась. Продлите доступ, чтобы продолжить.',
			},
		},
		403,
	)
})

// Список чатов, доступных пользователю
chatRoutes.get('/', async (c) => {
	const items = await getChatListItemsForUser({
		userId: c.get('userId'),
		userRole: c.get('userRole') as AppEnv['Variables']['userRole'],
	})
	const visibleItems = c.get('hasActiveSubscription')
		? items
		: items.filter((item) => item.slug === 'club-chat')
	return c.json({ success: true, data: visibleItems.map(normalizeMessageAuthorAvatar) })
})

chatRoutes.get('/:chatId/mention-candidates', async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const result = await getMentionCandidates({
		chatId,
		userId: c.get('userId'),
		userRole: c.get('userRole') as AppEnv['Variables']['userRole'],
	})

	if (!result.ok) {
		const status = result.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: result.code, message: result.message } }, status)
	}

	return c.json({ success: true, data: result.candidates })
})

chatRoutes.get(
	'/:chatId/users/:userId/profile',
	zValidator('param', chatUserProfileParamsSchema),
	zValidator('query', chatUserProfileQuerySchema),
	async (c) => {
		const { chatId, userId: targetUserId } = c.req.valid('param')
		const { messageId } = c.req.valid('query')
		const currentUserId = c.get('userId')
		const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']

		const access = await ensureChatAccess({ chatId, userId: currentUserId, userRole })
		if (!access.ok) {
			const status = access.code === 'NOT_FOUND' ? 404 : 403
			return c.json(
				{ success: false, error: { code: access.code, message: access.message } },
				status,
			)
		}

		const visibleMessage = await db.query.messages.findFirst({
			where: and(
				...(messageId ? [eq(messages.id, messageId)] : []),
				eq(messages.chatId, chatId),
				eq(messages.userAuthUuid, targetUserId),
				eq(messages.isDeleted, false),
			),
			columns: { id: true },
		})

		if (!visibleMessage && targetUserId !== currentUserId) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Участница не найдена' } },
				404,
			)
		}

		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, targetUserId),
			columns: {
				authUuid: true,
				fullName: true,
				username: true,
				avatarUrl: true,
				chatAdminBadge: true,
				socialAccount: true,
				socialLinks: true,
			},
		})

		if (!user) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Участница не найдена' } },
				404,
			)
		}

		return c.json({ success: true, data: buildChatUserProfile(user) })
	},
)

chatRoutes.get('/:chatId/notifications', async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const result = await getChatNotificationSettings({
		chatId,
		userId: c.get('userId'),
		userRole: c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole'],
	})

	if (!result.ok) {
		const status = result.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: result.code, message: result.message } }, status)
	}

	return c.json({ success: true, data: { enabled: result.enabled } })
})

chatRoutes.patch(
	'/:chatId/notifications',
	zValidator('json', chatNotificationSettingsSchema),
	async (c) => {
		const chatId = Number(c.req.param('chatId'))
		const body = c.req.valid('json')
		const result = await setChatNotificationSettings({
			chatId,
			userId: c.get('userId'),
			userRole: c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole'],
			enabled: body.enabled,
		})

		if (!result.ok) {
			const status = result.code === 'NOT_FOUND' ? 404 : 403
			return c.json(
				{ success: false, error: { code: result.code, message: result.message } },
				status,
			)
		}

		return c.json({ success: true, data: { enabled: result.enabled } })
	},
)

chatRoutes.post('/:chatId/read', zValidator('json', markChatReadSchema), async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
	const body = c.req.valid('json')

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const readState = await markChatRead({
		chatId,
		userId,
		latestMessageId: body.latestMessageId ?? null,
	})

	return c.json({ success: true, data: readState })
})

chatRoutes.get('/:chatId/messages/search', zValidator('query', searchSchema), async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
	const { q } = c.req.valid('query')

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const items = await db.query.messages.findMany({
		where: and(
			eq(messages.chatId, chatId),
			eq(messages.isDeleted, false),
			ilike(messages.content, `%${q.trim()}%`),
		),
		orderBy: [desc(messages.id)],
		limit: 20,
		with: {
			reactions: true,
			mentions: true,
			author: {
				columns: { fullName: true, username: true, avatarUrl: true, chatAdminBadge: true },
			},
			replyTo: {
				columns: {
					id: true,
					userAuthUuid: true,
					content: true,
					messageType: true,
					attachmentName: true,
					isDeleted: true,
				},
				with: {
					author: {
						columns: { fullName: true, username: true },
					},
				},
			},
		},
	})

	return c.json({ success: true, data: items.map(normalizeChatMessageResponse) })
})

// Сообщения чата (cursor pagination)
chatRoutes.get('/:chatId/messages', zValidator('query', chatMessagesQuerySchema), async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
	const { after, cursor, limit } = c.req.valid('query')

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const conditions = [eq(messages.chatId, chatId), eq(messages.isDeleted, false)]
	if (after) {
		conditions.push(gt(messages.id, after))
	} else if (cursor) {
		conditions.push(lt(messages.id, Number(cursor)))
	}

	const items = await db.query.messages.findMany({
		where: and(...conditions),
		orderBy: after ? [asc(messages.id)] : [desc(messages.id)],
		limit: limit + 1,
		with: {
			reactions: true,
			mentions: true,
			author: {
				columns: { fullName: true, username: true, avatarUrl: true, chatAdminBadge: true },
			},
			replyTo: {
				columns: {
					id: true,
					userAuthUuid: true,
					content: true,
					messageType: true,
					attachmentName: true,
					isDeleted: true,
				},
				with: {
					author: {
						columns: { fullName: true, username: true },
					},
				},
			},
		},
	})

	const hasMore = items.length > limit
	const data = hasMore ? items.slice(0, -1) : items
	const nextCursor = after
		? data[0]?.id
			? String(data[0].id)
			: null
		: hasMore
			? String(data[data.length - 1].id)
			: null
	const newerCursor = after
		? data[data.length - 1]?.id
			? String(data[data.length - 1].id)
			: null
		: null

	const latestMessageId = after ? (data[data.length - 1]?.id ?? null) : (data[0]?.id ?? null)
	const readState = await markChatRead({ chatId, userId, latestMessageId })

	return c.json({
		success: true,
		data: {
			items: data.map(normalizeChatMessageResponse),
			nextCursor,
			direction: after ? 'asc' : 'desc',
			newerCursor,
			hasNewer: after ? hasMore : false,
			readState,
		},
	})
})

chatRoutes.get('/:chatId/messages/:messageId', async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const messageId = Number(c.req.param('messageId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const item = await db.query.messages.findFirst({
		where: and(
			eq(messages.id, messageId),
			eq(messages.chatId, chatId),
			eq(messages.isDeleted, false),
		),
		with: {
			reactions: true,
			mentions: true,
			author: {
				columns: { fullName: true, username: true, avatarUrl: true, chatAdminBadge: true },
			},
			replyTo: {
				columns: {
					id: true,
					userAuthUuid: true,
					content: true,
					messageType: true,
					attachmentName: true,
					isDeleted: true,
				},
				with: {
					author: {
						columns: { fullName: true, username: true },
					},
				},
			},
		},
	})

	if (!item) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Сообщение не найдено' } },
			404,
		)
	}

	return c.json({ success: true, data: normalizeChatMessageResponse(item) })
})

chatRoutes.get('/:chatId/scheduled', adminMiddleware, async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const items = await db.query.scheduledChatMessages.findMany({
		where: and(
			eq(scheduledChatMessages.chatId, chatId),
			eq(scheduledChatMessages.status, 'scheduled'),
		),
		orderBy: [asc(scheduledChatMessages.scheduledAt), asc(scheduledChatMessages.id)],
		with: {
			author: {
				columns: {
					authUuid: true,
					fullName: true,
					username: true,
					avatarUrl: true,
					role: true,
				},
			},
		},
	})

	return c.json({
		success: true,
		data: items.map((item) =>
			normalizeScheduledAuthorAvatar({
				id: item.id,
				chatId: item.chatId,
				content: item.content,
				scheduledAt: item.scheduledAt,
				status: item.status,
				errorMessage: item.errorMessage,
				createdAt: item.createdAt,
				author: item.author
					? {
							authUuid: item.author.authUuid,
							fullName: item.author.fullName,
							username: item.author.username,
							avatarUrl: item.author.avatarUrl,
							role: item.author.role,
						}
					: {
							authUuid: item.authorAuthUuid,
							fullName: null,
							username: null,
							avatarUrl: null,
							role: 'admin',
						},
			}),
		),
	})
})

chatRoutes.post(
	'/:chatId/scheduled',
	adminMiddleware,
	zValidator('json', createScheduledMessageSchema),
	async (c) => {
		const chatId = Number(c.req.param('chatId'))
		const userId = c.get('userId')
		const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
		const body = c.req.valid('json')

		const access = await ensureChatAccess({ chatId, userId, userRole })
		if (!access.ok) {
			const status = access.code === 'NOT_FOUND' ? 404 : 403
			return c.json(
				{ success: false, error: { code: access.code, message: access.message } },
				status,
			)
		}

		const scheduledDate = resolveScheduledMessageDate(body.scheduledAt)
		if (!scheduledDate.ok) {
			return c.json(
				{ success: false, error: { code: 'BAD_REQUEST', message: scheduledDate.message } },
				400,
			)
		}

		const mentions = await normalizeMentions({
			chatId,
			userId,
			userRole,
			content: body.content,
			mentions: body.mentions,
		})

		const [created] = await db
			.insert(scheduledChatMessages)
			.values({
				chatId,
				authorAuthUuid: userId,
				content: body.content.trimEnd(),
				mentions: mentions.map((mention) => ({
					userAuthUuid: mention.mentionedUserAuthUuid,
					displayName: mention.displayName,
					start: mention.startOffset,
					end: mention.endOffset,
				})),
				scheduledAt: scheduledDate.value,
			})
			.returning()

		const item = await db.query.scheduledChatMessages.findFirst({
			where: eq(scheduledChatMessages.id, created.id),
			with: {
				author: {
					columns: {
						authUuid: true,
						fullName: true,
						username: true,
						avatarUrl: true,
						role: true,
					},
				},
			},
		})

		return c.json(
			{
				success: true,
				data: normalizeScheduledAuthorAvatar({
					id: item?.id ?? created.id,
					chatId,
					content: item?.content ?? created.content,
					scheduledAt: item?.scheduledAt ?? created.scheduledAt,
					status: item?.status ?? created.status,
					errorMessage: item?.errorMessage ?? created.errorMessage,
					createdAt: item?.createdAt ?? created.createdAt,
					author: item?.author
						? {
								authUuid: item.author.authUuid,
								fullName: item.author.fullName,
								username: item.author.username,
								avatarUrl: item.author.avatarUrl,
								role: item.author.role,
							}
						: {
								authUuid: userId,
								fullName: null,
								username: null,
								avatarUrl: null,
								role: userRole,
							},
				}),
			},
			201,
		)
	},
)

chatRoutes.delete('/:chatId/scheduled/:scheduledId', adminMiddleware, async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const scheduledId = Number(c.req.param('scheduledId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const item = await db.query.scheduledChatMessages.findFirst({
		where: and(eq(scheduledChatMessages.id, scheduledId), eq(scheduledChatMessages.chatId, chatId)),
	})

	if (!item) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Отложенное сообщение не найдено' } },
			404,
		)
	}

	if (item.status !== 'scheduled') {
		return c.json(
			{
				success: false,
				error: { code: 'CONFLICT', message: 'Это сообщение уже нельзя удалить из отложенных' },
			},
			409,
		)
	}

	await db
		.update(scheduledChatMessages)
		.set({
			status: 'cancelled',
			updatedAt: new Date(),
			processingStartedAt: null,
		})
		.where(eq(scheduledChatMessages.id, scheduledId))

	return c.json({ success: true, data: { id: scheduledId } })
})

// Отправить сообщение (REST fallback, основной путь — WebSocket)
chatRoutes.post(
	'/:chatId/messages',
	zValidator('json', sendMessageSchema.omit({ chatId: true })),
	async (c) => {
		const chatId = Number(c.req.param('chatId'))
		const userId = c.get('userId')
		const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
		const body = c.req.valid('json')

		const delivery = await deliverChatMessage({
			chatId,
			userId,
			userRole,
			content: body.content ?? '',
			replyToId: body.replyToId,
			clientMessageId: body.clientMessageId,
			messageType: body.messageType,
			attachmentUrl: body.attachmentUrl,
			attachmentName: body.attachmentName,
			attachmentSize: body.attachmentSize,
			mentions: body.mentions,
		})

		if (!delivery.ok) {
			return c.json(
				{ success: false, error: { code: delivery.code, message: delivery.message } },
				delivery.status,
			)
		}

		if (!delivery.duplicate) {
			await broadcastChatRoomEvent(chatId, { type: 'new_message', message: delivery.message })
		}

		return c.json(
			{ success: true, data: normalizeMessageAuthorAvatar(delivery.message) },
			delivery.duplicate ? 200 : 201,
		)
	},
)

chatRoutes.patch(
	'/:chatId/messages/:messageId',
	zValidator('json', editMessageSchema),
	async (c) => {
		const chatId = Number(c.req.param('chatId'))
		const messageId = Number(c.req.param('messageId'))
		const userId = c.get('userId')
		const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
		const body = c.req.valid('json')

		const access = await ensureChatAccess({ chatId, userId, userRole })
		if (!access.ok) {
			const status = access.code === 'NOT_FOUND' ? 404 : 403
			return c.json(
				{ success: false, error: { code: access.code, message: access.message } },
				status,
			)
		}

		const targetMessage = await db.query.messages.findFirst({
			where: and(
				eq(messages.id, messageId),
				eq(messages.chatId, chatId),
				eq(messages.isDeleted, false),
			),
		})

		if (!targetMessage) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Сообщение не найдено' } },
				404,
			)
		}

		if (targetMessage.userAuthUuid !== userId) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Можно редактировать только свои сообщения' },
				},
				403,
			)
		}

		const normalizedContent = body.content.trimEnd()
		const mentions = await normalizeMentions({
			chatId,
			userId,
			userRole,
			content: normalizedContent,
			mentions: body.mentions,
		})

		await db
			.update(messages)
			.set({
				content: normalizedContent,
				updatedAt: new Date(),
			})
			.where(eq(messages.id, messageId))

		await db.delete(messageMentions).where(eq(messageMentions.messageId, messageId))
		await createMessageMentions({
			chatId,
			messageId,
			authorUserId: userId,
			mentions: mentions.map((mention) => ({
				mentionedUserAuthUuid: mention.mentionedUserAuthUuid,
				displayName: mention.displayName,
				startOffset: mention.startOffset,
				endOffset: mention.endOffset,
			})),
		})

		const updated = await loadMessageWithMeta(messageId)
		if (!updated) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Сообщение не найдено' } },
				404,
			)
		}

		return c.json({ success: true, data: normalizeMessageAuthorAvatar(updated) })
	},
)

// Реакция на сообщение
chatRoutes.post('/:chatId/messages/:messageId/reactions', async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const messageId = Number(c.req.param('messageId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
	const { emoji } = await c.req.json<{ emoji: string }>()

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	if (
		!isChatManager(userRole, access.member?.role) &&
		!normalizeChatSettings(access.chat.settings).allowReactions
	) {
		return c.json(
			{ success: false, error: { code: 'FORBIDDEN', message: 'Реакции в этом чате отключены' } },
			403,
		)
	}

	const targetMessage = await db.query.messages.findFirst({
		where: and(
			eq(messages.id, messageId),
			eq(messages.chatId, chatId),
			eq(messages.isDeleted, false),
		),
	})
	if (!targetMessage) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Сообщение не найдено' } },
			404,
		)
	}

	// Upsert: добавить или удалить реакцию
	const existing = await db.query.messageReactions.findFirst({
		where: and(
			eq(messageReactions.messageId, messageId),
			eq(messageReactions.userAuthUuid, userId),
			eq(messageReactions.emoji, emoji),
		),
	})

	if (existing) {
		await db.delete(messageReactions).where(eq(messageReactions.id, existing.id))
		return c.json({ success: true, data: { action: 'removed' } })
	}

	await db.insert(messageReactions).values({
		messageId,
		userAuthUuid: userId,
		emoji,
	})

	return c.json({ success: true, data: { action: 'added' } }, 201)
})

// Мьют пользователя (admin)
chatRoutes.post(
	'/:chatId/members/:userUuid/mute',
	adminMiddleware,
	zValidator('json', muteUserSchema),
	async (c) => {
		const chatId = Number(c.req.param('chatId'))
		const userUuid = c.req.param('userUuid')
		const { duration } = c.req.valid('json')

		const mutedUntil =
			duration === 'forever'
				? null
				: duration === '1h'
					? new Date(Date.now() + 3600_000)
					: duration === '24h'
						? new Date(Date.now() + 86400_000)
						: new Date(Date.now() + 604800_000) // 7d

		await db
			.update(chatMembers)
			.set({
				status: 'muted',
				mutedUntil: duration === 'forever' ? null : mutedUntil,
			})
			.where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userAuthUuid, userUuid)))

		return c.json({ success: true, data: { muted: true } })
	},
)

// Бан пользователя (admin)
chatRoutes.post('/:chatId/members/:userUuid/ban', adminMiddleware, async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const userUuid = c.req.param('userUuid')

	await db
		.update(chatMembers)
		.set({ status: 'banned' })
		.where(and(eq(chatMembers.chatId, chatId), eq(chatMembers.userAuthUuid, userUuid)))

	return c.json({ success: true, data: { banned: true } })
})

// Удалить сообщение (автор или admin)
chatRoutes.delete('/:chatId/messages/:messageId', async (c) => {
	const chatId = Number(c.req.param('chatId'))
	const messageId = Number(c.req.param('messageId'))
	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	const msg = await db.query.messages.findFirst({
		where: and(eq(messages.id, messageId), eq(messages.chatId, chatId)),
	})
	if (!msg) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Сообщение не найдено' } },
			404,
		)
	}
	if (msg.userAuthUuid !== userId) {
		// Проверяем admin
		const { users } = await import('@community-club/shared')
		const user = await db.query.users.findFirst({ where: eq(users.authUuid, userId) })
		if (!user || !['admin', 'superadmin'].includes(user.role)) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Вы не можете удалить это сообщение' },
				},
				403,
			)
		}
	}

	await db.update(messages).set({ isDeleted: true }).where(eq(messages.id, messageId))
	await broadcastChatRoomEvent(chatId, {
		type: 'message_deleted',
		messageId,
		chatId,
	})
	return c.json({ success: true, data: { deleted: true } })
})

// Загрузка файла в чат
chatRoutes.post('/:chatId/upload', uploadQueueMiddleware(), async (c) => {
	const body = await c.req.parseBody()
	const file = body.file

	if (!file || typeof file === 'string') {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Файл не выбран' } },
			400,
		)
	}

	const maxSize = 32 * 1024 * 1024
	if (file.size > maxSize) {
		return c.json(
			{
				success: false,
				error: { code: 'FILE_TOO_LARGE', message: 'Файл больше 32 МБ. Выберите файл поменьше.' },
			},
			413,
		)
	}

	const userId = c.get('userId')
	const userRole = c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole']
	const chatId = Number(c.req.param('chatId'))

	const access = await ensureChatAccess({ chatId, userId, userRole })
	if (!access.ok) {
		const status = access.code === 'NOT_FOUND' ? 404 : 403
		return c.json({ success: false, error: { code: access.code, message: access.message } }, status)
	}

	if (access.member?.status === 'muted') {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Вы временно не можете писать в этот чат' },
			},
			403,
		)
	}

	// Определяем тип файла
	const mimeType = file.type
	let messageType = 'document'
	const isVoice =
		file.name.startsWith('voice_') && (mimeType.includes('webm') || mimeType.startsWith('audio/'))
	if (isVoice) messageType = 'voice'
	else if (mimeType.startsWith('image/')) messageType = 'image'
	else if (mimeType.startsWith('audio/')) messageType = 'audio'
	else if (mimeType.startsWith('video/')) messageType = 'video'

	const { uploadFile } = await import('../lib/storage')
	const { env } = await import('../config/env')
	const ext = file.name.split('.').pop() ?? 'bin'
	const key = `chats/${chatId}/${userId}/${Date.now()}.${ext}`

	try {
		const arrayBuffer = await file.arrayBuffer()
		await uploadFile(env.S3_BUCKET_CHAT, key, arrayBuffer, mimeType)
		// Chat attachments проксируются через /chat-media/ (не /media/)
		const baseUrl = env.S3_PUBLIC_URL
			? env.S3_PUBLIC_URL.replace(/\/media$/, '/chat-media')
			: `${env.S3_ENDPOINT}/${env.S3_BUCKET_CHAT}`
		const url = `${baseUrl}/${key}`

		return c.json({
			success: true,
			data: {
				url,
				name: file.name,
				size: file.size,
				messageType,
			},
		})
	} catch (err) {
		const message =
			err instanceof Error && err.message
				? 'Не удалось загрузить файл. Попробуйте ещё раз.'
				: 'Системная ошибка. Обратитесь в поддержку.'
		return c.json({ success: false, error: { code: 'UPLOAD_ERROR', message } }, 500)
	}
})

// Link preview — извлечь OG-метаданные
chatRoutes.get('/link-preview', async (c) => {
	const url = c.req.query('url')
	if (!url) {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Укажите ссылку' } },
			400,
		)
	}

	const validatedUrl = await validateLinkPreviewUrl(url)
	if (!validatedUrl.ok) {
		return c.json(
			{
				success: false,
				error: { code: validatedUrl.code, message: validatedUrl.message },
			},
			validatedUrl.status as 400 | 403,
		)
	}

	try {
		const response = await fetch(validatedUrl.url, {
			headers: { 'User-Agent': 'Mozilla/5.0 (compatible; CommunityClubBot/1.0)' },
			signal: AbortSignal.timeout(5000),
		})
		const html = await readResponseTextWithLimit(response, LINK_PREVIEW_MAX_HTML_BYTES)

		// Парсим OG-теги
		const getMetaContent = (property: string): string | null => {
			const regex = new RegExp(
				`<meta[^>]+(?:property|name)=["']${property}["'][^>]+content=["']([^"']*)["']`,
				'i',
			)
			const altRegex = new RegExp(
				`<meta[^>]+content=["']([^"']*)["'][^>]+(?:property|name)=["']${property}["']`,
				'i',
			)
			return regex.exec(html)?.[1] ?? altRegex.exec(html)?.[1] ?? null
		}

		const titleMatch = /<title[^>]*>([^<]*)<\/title>/i.exec(html)

		const preview = {
			title: getMetaContent('og:title') ?? titleMatch?.[1] ?? null,
			description: getMetaContent('og:description') ?? getMetaContent('description') ?? null,
			image: getMetaContent('og:image') ?? null,
			siteName: getMetaContent('og:site_name') ?? null,
			url: validatedUrl.url,
		}

		return c.json({ success: true, data: preview })
	} catch {
		return c.json({
			success: true,
			data: { title: null, description: null, image: null, siteName: null, url: validatedUrl.url },
		})
	}
})
