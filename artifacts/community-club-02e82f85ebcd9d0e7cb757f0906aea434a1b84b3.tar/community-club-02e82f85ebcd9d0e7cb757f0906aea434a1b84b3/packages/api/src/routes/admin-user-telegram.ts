import { telegramContacts } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, asc, eq } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { appendAdminActivityLog } from '../lib/admin-activity'
import {
	getPublicTelegramBroadcastBots,
	getTelegramBroadcastBot,
	normalizeTelegramBotUsername,
} from '../lib/telegram-broadcast-bots'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

const contactSchema = z.object({
	botUsername: z.string().trim().min(1).max(128),
	telegramUserId: z
		.string()
		.trim()
		.regex(/^\d{1,20}$/),
	telegramUsername: z.string().trim().max(120).nullable().optional(),
})

export const adminUserTelegramRoutes = new Hono<AppEnv>()

adminUserTelegramRoutes.use('*', authMiddleware, adminMiddleware)

adminUserTelegramRoutes.get('/:uuid/telegram-contacts', async (c) => {
	const contacts = await db.query.telegramContacts.findMany({
		where: eq(telegramContacts.userAuthUuid, c.req.param('uuid')),
		orderBy: [asc(telegramContacts.botUsername), asc(telegramContacts.id)],
	})
	return c.json({ success: true, data: { contacts, bots: getPublicTelegramBroadcastBots() } })
})

adminUserTelegramRoutes.post(
	'/:uuid/telegram-contacts',
	zValidator('json', contactSchema),
	async (c) => {
		const userAuthUuid = c.req.param('uuid')
		const body = c.req.valid('json')
		const botUsername = normalizeTelegramBotUsername(body.botUsername)
		if (!getTelegramBroadcastBot(botUsername)) {
			return c.json(
				{ success: false, error: { code: 'BAD_REQUEST', message: 'Выберите настроенного бота' } },
				400,
			)
		}
		const [contact] = await db
			.insert(telegramContacts)
			.values({
				userAuthUuid,
				botUsername,
				telegramUserId: body.telegramUserId,
				telegramUsername: body.telegramUsername?.replace(/^@/, '') || null,
			})
			.onConflictDoNothing()
			.returning()
		if (!contact) {
			return c.json(
				{
					success: false,
					error: { code: 'BAD_REQUEST', message: 'Этот контакт уже есть у выбранного бота' },
				},
				400,
			)
		}
		await appendAdminActivityLog({
			actorAuthUuid: c.get('userId'),
			action: 'create',
			entityType: 'telegram_contact',
			entityId: String(contact.id),
			summary: `Добавлен Telegram-профиль @${contact.botUsername}`,
			details: { userAuthUuid, telegramUserId: contact.telegramUserId },
		})
		return c.json({ success: true, data: contact }, 201)
	},
)

adminUserTelegramRoutes.delete('/:uuid/telegram-contacts/:id', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id)) {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Некорректный ID' } },
			400,
		)
	}
	const [contact] = await db
		.delete(telegramContacts)
		.where(and(eq(telegramContacts.id, id), eq(telegramContacts.userAuthUuid, c.req.param('uuid'))))
		.returning()
	if (!contact) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Telegram-профиль не найден' } },
			404,
		)
	}
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'delete',
		entityType: 'telegram_contact',
		entityId: String(contact.id),
		summary: `Удалён Telegram-профиль @${contact.botUsername}`,
	})
	return c.json({ success: true, data: { deleted: true } })
})
