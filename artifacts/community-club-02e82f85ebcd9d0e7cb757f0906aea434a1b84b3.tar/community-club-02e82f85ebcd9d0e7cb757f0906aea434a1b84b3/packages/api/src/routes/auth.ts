import {
	type AuthCodeRequestResponse,
	type ClubEntryResolution,
	type ClubTariffRole,
	type PricingContext,
	type SendAccessPasswordResponse,
	authCodeRequestSchema,
	authCodeVerifySchema,
	changePasswordSchema,
	entryCheckSchema,
	forgotPasswordSchema,
	loginSchema,
	paymentLogs,
	payments,
	registerSchema,
	resetPasswordSchema,
	sendAccessPasswordSchema,
	telegramBotVerifySchema,
	users,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, or } from 'drizzle-orm'
import { Hono } from 'hono'
import { getCookie } from 'hono/cookie'
import { nanoid } from 'nanoid'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db } from '../db/client'
import {
	clearAuthCookies,
	generateTokens,
	publicSessionData,
	setAuthCookies,
} from '../lib/auth-session'
import { logger } from '../lib/logger'
import { sendMail, sendTemplateEmail } from '../lib/mail'
import { sendMaxMessage } from '../lib/max-messenger'
import { createPasswordAuthIdentity } from '../lib/password-auth-identity'
import { paymentMatchesCheckoutSession } from '../lib/payment-checkout-claim'
import {
	consumePaymentCheckoutSession,
	readPaymentCheckoutSession,
} from '../lib/payment-checkout-session'
import { redis } from '../lib/redis'
import { deleteRedisKeysByPattern } from '../lib/redis-keyscan'
import {
	claimRefreshSessionRotation,
	getRefreshSessionKey,
	resolveRefreshTokenSource,
	storeRotatedRefreshSession,
	waitForRefreshRotationResult,
} from '../lib/refresh-sessions'
import { getAppBaseUrl, loadAuthLoginSettings, loadRuntimeSettings } from '../lib/site-settings'
import { findLatestPaymentForAccess, hasActiveDateFinish } from '../lib/subscription-access'
import { sendTelegramMessage } from '../lib/telegram'
import { authMiddleware } from '../middleware/auth'
import { rateLimit } from '../middleware/rate-limit'
import { resolvePricingContext, shouldShowPriceFirst } from '../services/pricing.service'

const jwtSecret = new TextEncoder().encode(env.JWT_SECRET)
const purchaseSessionSchema = z.object({
	email: z.string().email(),
	role: z
		.string()
		.optional()
		.transform(() => 'club' as const),
	fullName: z.string().trim().min(5, 'Введите ФИО полностью').max(100).optional(),
	phone: z
		.string()
		.regex(/^\+7\d{10}$/, 'Формат: +79XXXXXXXXX')
		.optional(),
	password: z.string().min(6, 'Минимум 6 символов').optional(),
})
const checkoutClaimSchema = z.object({
	checkoutSession: z.string().trim().min(32).max(120),
})

function isParticipant(payment: { dateFinish: string | Date | null } | null): boolean {
	return hasActiveDateFinish(payment?.dateFinish ?? null)
}

function hasPaymentHistory(
	payment: {
		tarrif?: string | null
		dateStart?: string | Date | null
		dateFinish?: string | Date | null
	} | null,
) {
	return Boolean(payment?.tarrif || payment?.dateStart || payment?.dateFinish)
}

function buildAccessPasswordMessage(password: string, appUrl: string) {
	return [
		`Ваш доступ к клубу: ${appUrl}`,
		`Пароль: ${password}`,
		'Вы можете изменить пароль в своем Профиле в приложении.',
	].join('\n')
}

function buildTelegramAccessPasswordMessage(password: string, appUrl: string) {
	return [
		`Ваш доступ к клубу: ${appUrl}`,
		`Пароль: <code>${password}</code>`,
		'Вы можете изменить пароль в своем Профиле в приложении.',
	].join('\n')
}

async function findLatestActivePayment(params: { userAuthUuid: string; email: string | null }) {
	return await findLatestPaymentForAccess({
		userAuthUuid: params.userAuthUuid,
		email: params.email,
		activeOnly: true,
	})
}

async function canSignIntoApp(user: typeof users.$inferSelect) {
	if (user.role === 'admin' || user.role === 'superadmin') return true
	const activePayment = await findLatestActivePayment({
		userAuthUuid: user.authUuid,
		email: user.email ?? null,
	})
	return Boolean(activePayment)
}

function subscriptionExpiredResponse() {
	return {
		success: false as const,
		error: {
			code: 'SUBSCRIPTION_EXPIRED',
			message: 'Доступ закончился. Оплатите доступ, чтобы войти.',
		},
	}
}

function generateAccessPassword() {
	return nanoid(12)
}

function buildAccessPasswordMail(password: string, appUrl: string) {
	const text = buildAccessPasswordMessage(password, appUrl)
	const html = [
		`<p>Ваш доступ к клубу: <a href="${appUrl}">${appUrl}</a></p>`,
		`<p>Пароль: <strong>${password}</strong></p>`,
		'<p>Вы можете изменить пароль в своем Профиле в приложении.</p>',
	].join('')

	return {
		subject: 'Доступ к клубу Community',
		html,
		text,
	}
}

function pricingContextToTier(context: PricingContext): 1 | 2 | 3 {
	return context === 'external' ? 2 : 1
}

function buildPurchaseResolution(params: {
	email: string
	source: 'db_user' | 'new'
	message: string
	role: ClubTariffRole
	tariffTier: 1 | 2 | 3
	pricingContext: PricingContext
	userExists: boolean
	hasPassword: boolean
	firstEntry: boolean
	showPriceFirst: boolean
	fullName?: string | null
	phone?: string | null
}): ClubEntryResolution {
	return {
		status: 'purchase_required',
		email: params.email,
		source: params.source,
		message: params.message,
		role: params.role,
		tariffTier: params.tariffTier,
		pricingContext: params.pricingContext,
		isParticipant: false,
		userExists: params.userExists,
		hasPassword: params.hasPassword,
		firstEntry: params.firstEntry,
		showPriceFirst: params.showPriceFirst,
		fullName: params.fullName ?? null,
		phone: params.phone ?? null,
	}
}

async function findLatestUserPayment(params: { userAuthUuid: string; email: string }) {
	return db.query.payments.findFirst({
		where: or(eq(payments.userAuthUuid, params.userAuthUuid), eq(payments.email, params.email)),
		orderBy: [desc(payments.updatedAt), desc(payments.dateFinish), desc(payments.createdAt)],
	})
}

export const authRoutes = new Hono<AppEnv>()

// Разводим бакеты, чтобы проверка email и вспомогательные auth-запросы
// не выбивали лимит входа раньше самого /login.
const authLimiter = rateLimit({ windowMs: 60_000, max: 5, keyPrefix: 'rl:auth' })
const authEntryLimiter = rateLimit({ windowMs: 60_000, max: 20, keyPrefix: 'rl:auth:entry' })
const authLoginLimiter = rateLimit({ windowMs: 60_000, max: 10, keyPrefix: 'rl:auth:login' })
const authCodeLimiter = rateLimit({ windowMs: 60_000, max: 5, keyPrefix: 'rl:auth:code' })
const AUTH_CODE_TTL_SECONDS = 10 * 60
const AUTH_CODE_MAX_ATTEMPTS = 5

async function readRefreshTokenFromRequest(c: Parameters<typeof getCookie>[0]) {
	const cookieRefreshToken = getCookie(c, 'refresh_token')
	const body = await c.req.json<{ refreshToken?: string }>().catch(() => ({}))
	return resolveRefreshTokenSource({
		cookieToken: cookieRefreshToken,
		bodyToken: typeof body.refreshToken === 'string' ? body.refreshToken : null,
	})
}

function generateAuthCode() {
	return String(crypto.getRandomValues(new Uint32Array(1))[0] % 1_000_000).padStart(6, '0')
}

function authCodeRedisKey(channel: 'telegram' | 'max', email: string) {
	return `auth:code:${channel}:${email}`
}

function buildAuthCodeMessage(code: string) {
	return `Код входа в клуб: ${code}. Он действует 10 минут.`
}

function resolveMaxUserId(user: {
	maxMessengerUserId?: string | null
	socialAccount?: string | null
	socialLinks?: string[] | null
}) {
	const candidates = [user.maxMessengerUserId, user.socialAccount, ...(user.socialLinks ?? [])].map(
		(value) => String(value ?? '').trim(),
	)

	for (const candidate of candidates) {
		const match = candidate.match(/(?:^|[:/@\s])max[:/@\s-]*(\d{4,})$/i)
		if (match?.[1]) return match[1]
		if (/^\d{4,}$/.test(candidate)) return candidate
	}

	return null
}

async function findTelegramRecipient(params: { userAuthUuid: string; email: string }) {
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, params.userAuthUuid),
		columns: { telegramChatId: true },
	})
	const directChatId = String(user?.telegramChatId ?? '').trim()
	if (directChatId) return directChatId

	const activePayment = await findLatestActivePayment(params)
	const telegramBinding = await db.query.payments.findFirst({
		where: or(eq(payments.userAuthUuid, params.userAuthUuid), eq(payments.email, params.email)),
		columns: { cpAccountId: true },
		orderBy: [desc(payments.updatedAt), desc(payments.dateFinish), desc(payments.createdAt)],
	})

	return String(activePayment?.cpAccountId ?? telegramBinding?.cpAccountId ?? '').trim() || null
}

async function deliverAuthCode(params: {
	channel: 'telegram' | 'max'
	user: typeof users.$inferSelect
	email: string
	code: string
}) {
	const text = buildAuthCodeMessage(params.code)

	if (params.channel === 'telegram') {
		const settings = await loadRuntimeSettings()
		if (!settings.telegramBotToken) {
			return { ok: false as const, message: 'Отправка в Telegram пока не настроена' }
		}
		const recipient = await findTelegramRecipient({
			userAuthUuid: params.user.authUuid,
			email: params.email,
		})
		if (!recipient) {
			return { ok: false as const, message: 'Для этого пользователя не найден Telegram' }
		}
		await sendTelegramMessage(recipient, `<b>${text}</b>`, { parseMode: 'HTML' })
		return { ok: true as const }
	}

	const settings = await loadRuntimeSettings()
	if (!settings.maxBotToken) {
		return { ok: false as const, message: 'Отправка в MAX пока не настроена' }
	}
	const maxUserId = resolveMaxUserId(params.user)
	if (!maxUserId) {
		return { ok: false as const, message: 'Для этого пользователя не найден MAX' }
	}
	await sendMaxMessage(maxUserId, text)
	return { ok: true as const }
}

authRoutes.post(
	'/entry/check-email',
	authEntryLimiter,
	zValidator('json', entryCheckSchema),
	async (c) => {
		const { email } = c.req.valid('json')
		const normalizedEmail = email.trim().toLowerCase()

		const existingUser = await db.query.users.findFirst({
			where: eq(users.email, normalizedEmail),
		})
		const user = existingUser

		if (user) {
			const paymentRaw = await findLatestUserPayment({
				userAuthUuid: user.authUuid,
				email: normalizedEmail,
			})
			const payment = paymentRaw
				? {
						dateFinish: paymentRaw.dateFinish,
						dateStart: paymentRaw.dateStart,
						tarrif: paymentRaw.tarrif,
					}
				: null

			if (isParticipant(payment)) {
				const resolution: ClubEntryResolution = {
					status: 'member_requires_password',
					email: normalizedEmail,
					source: 'db_user',
					message: 'Введите пароль',
					role: 'club',
					tariffTier: 1,
					pricingContext: 'active',
					isParticipant: true,
					userExists: true,
					hasPassword: !!user.passwordHash,
					firstEntry: !!user.firstEntry,
					showPriceFirst: false,
					fullName: user.fullName ?? null,
					phone: user.phone ?? null,
				}
				return c.json({ success: true, data: resolution })
			}

			const paymentHistory = hasPaymentHistory(payment)
			const pricingContext = resolvePricingContext({
				role: 'club',
				firstEntry: !!user.firstEntry,
				hasPaymentHistory: paymentHistory,
				hasActiveSubscription: false,
			})
			const tariffTier = pricingContextToTier(pricingContext)

			return c.json({
				success: true,
				data: buildPurchaseResolution({
					email: normalizedEmail,
					source: 'db_user',
					message: 'Для получения доступа в клуб приобретите доступ',
					role: 'club',
					tariffTier,
					pricingContext,
					userExists: true,
					hasPassword: !!user.passwordHash,
					firstEntry: !!user.firstEntry,
					showPriceFirst: shouldShowPriceFirst(pricingContext),
				}),
			})
		}

		const newUserPricingContext = resolvePricingContext({
			role: 'club',
			firstEntry: true,
			hasPaymentHistory: false,
			hasActiveSubscription: false,
		})

		return c.json({
			success: true,
			data: buildPurchaseResolution({
				email: normalizedEmail,
				source: 'new',
				message: 'Для получения доступа в клуб приобретите доступ',
				role: 'club',
				pricingContext: newUserPricingContext,
				tariffTier: pricingContextToTier(newUserPricingContext),
				userExists: false,
				hasPassword: false,
				firstEntry: true,
				showPriceFirst: shouldShowPriceFirst(newUserPricingContext),
			}),
		})
	},
)

// Вход по email + пароль
authRoutes.post('/login', authLoginLimiter, zValidator('json', loginSchema), async (c) => {
	const { email, password } = c.req.valid('json')
	const identity = createPasswordAuthIdentity(email)
	const loginSettings = await loadAuthLoginSettings()
	if (!loginSettings.passwordEnabled) {
		return c.json(
			{
				success: false,
				error: { code: 'AUTH_ERROR', message: 'Вход по паролю сейчас выключен' },
			},
			403,
		)
	}

	const user = await db.query.users.findFirst({
		where: eq(users.email, identity.email),
	})

	if (!user || !user.passwordHash) {
		return c.json(
			{ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный email или пароль' } },
			401,
		)
	}

	const valid = await Bun.password.verify(password, user.passwordHash)
	if (!valid) {
		return c.json(
			{ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный email или пароль' } },
			401,
		)
	}

	if (!(await canSignIntoApp(user))) {
		clearAuthCookies(c)
		return c.json(subscriptionExpiredResponse(), 403)
	}

	const tokens = await generateTokens(user.authUuid, user.email ?? '', user.role)
	setAuthCookies(c, tokens)
	return c.json({ success: true, data: publicSessionData(tokens) })
})

authRoutes.post(
	'/checkout/claim-access',
	authEntryLimiter,
	zValidator('json', checkoutClaimSchema),
	async (c) => {
		const { checkoutSession } = c.req.valid('json')
		const session = await readPaymentCheckoutSession(checkoutSession)
		if (!session) {
			return c.json(
				{
					success: false,
					error: {
						code: 'NOT_FOUND',
						message: 'Сессия оплаты не найдена',
					},
				},
				404,
			)
		}

		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, session.userAuthUuid),
		})
		if (!user?.email) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Пользователь не найден' },
				},
				404,
			)
		}

		const identityEmail = session.email ?? user.email
		const activePaymentCandidates = await db.query.payments.findMany({
			where: identityEmail
				? or(eq(payments.userAuthUuid, user.authUuid), eq(payments.email, identityEmail))
				: eq(payments.userAuthUuid, user.authUuid),
			orderBy: [desc(payments.updatedAt), desc(payments.dateFinish), desc(payments.createdAt)],
			limit: 10,
		})
		const successfulCheckoutLog = await db.query.paymentLogs.findFirst({
			where: and(eq(paymentLogs.orderId, session.invoiceId), eq(paymentLogs.status, 'success')),
			orderBy: [desc(paymentLogs.createdAt)],
		})
		const checkoutPayment = activePaymentCandidates.find((payment) =>
			paymentMatchesCheckoutSession({
				session,
				payment,
				paymentLog: successfulCheckoutLog ?? null,
			}),
		)

		if (!isParticipant(checkoutPayment ?? null)) {
			return c.json(
				{
					success: false,
					error: {
						code: 'PAYMENT_PENDING',
						message: 'Платёж обрабатывается. Подождите немного.',
					},
				},
				409,
			)
		}

		if (user.role !== 'admin' && user.role !== 'superadmin' && user.firstEntry) {
			await db
				.update(users)
				.set({ firstEntry: false, updatedAt: new Date() })
				.where(eq(users.authUuid, user.authUuid))
		}

		await consumePaymentCheckoutSession(checkoutSession)

		const tokens = await generateTokens(user.authUuid, user.email, user.role)
		setAuthCookies(c, tokens)
		return c.json({
			success: true,
			data: {
				...publicSessionData(tokens),
				redirectTo: '/app',
				requiresPasswordSetup: !user.passwordHash,
			},
		})
	},
)

authRoutes.post(
	'/code/request',
	authCodeLimiter,
	zValidator('json', authCodeRequestSchema),
	async (c) => {
		const { email, channel } = c.req.valid('json')
		const normalizedEmail = email.trim().toLowerCase()
		const settings = await loadAuthLoginSettings()
		const channelEnabled =
			channel === 'telegram' ? settings.telegramCodeEnabled : settings.maxCodeEnabled

		if (!channelEnabled) {
			return c.json(
				{
					success: false,
					error: { code: 'AUTH_ERROR', message: 'Этот способ входа сейчас выключен' },
				},
				403,
			)
		}

		const user = await db.query.users.findFirst({
			where: eq(users.email, normalizedEmail),
		})

		if (!user?.email) {
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				404,
			)
		}

		const code = generateAuthCode()
		const codeHash = await Bun.password.hash(code, { algorithm: 'bcrypt', cost: 10 })

		try {
			const delivered = await deliverAuthCode({
				channel,
				user,
				email: normalizedEmail,
				code,
			})
			if (!delivered.ok) {
				return c.json(
					{ success: false, error: { code: 'AUTH_ERROR', message: delivered.message } },
					400,
				)
			}
		} catch (error) {
			logger.error({ err: error, channel, email: normalizedEmail }, 'Failed to send auth code')
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Не удалось отправить код' } },
				500,
			)
		}

		await redis.set(
			authCodeRedisKey(channel, normalizedEmail),
			JSON.stringify({
				userAuthUuid: user.authUuid,
				codeHash,
				attempts: 0,
			}),
			'EX',
			AUTH_CODE_TTL_SECONDS,
		)

		const response: AuthCodeRequestResponse = {
			channel,
			expiresIn: AUTH_CODE_TTL_SECONDS,
			message: channel === 'telegram' ? 'Код отправлен в Telegram' : 'Код отправлен в MAX',
		}

		return c.json({ success: true, data: response })
	},
)

authRoutes.post(
	'/code/verify',
	authLoginLimiter,
	zValidator('json', authCodeVerifySchema),
	async (c) => {
		const { email, channel, code } = c.req.valid('json')
		const normalizedEmail = email.trim().toLowerCase()
		const settings = await loadAuthLoginSettings()
		const channelEnabled =
			channel === 'telegram' ? settings.telegramCodeEnabled : settings.maxCodeEnabled

		if (!channelEnabled) {
			return c.json(
				{
					success: false,
					error: { code: 'AUTH_ERROR', message: 'Этот способ входа сейчас выключен' },
				},
				403,
			)
		}

		const key = authCodeRedisKey(channel, normalizedEmail)
		const raw = await redis.get(key)
		if (!raw) {
			return c.json({ success: false, error: { code: 'AUTH_ERROR', message: 'Код истёк' } }, 401)
		}

		const stored = JSON.parse(raw) as {
			userAuthUuid?: string
			codeHash?: string
			attempts?: number
		}
		if (!stored.userAuthUuid || !stored.codeHash) {
			await redis.del(key)
			return c.json({ success: false, error: { code: 'AUTH_ERROR', message: 'Код истёк' } }, 401)
		}

		const attempts = Number(stored.attempts ?? 0)
		if (attempts >= AUTH_CODE_MAX_ATTEMPTS) {
			await redis.del(key)
			return c.json({ success: false, error: { code: 'AUTH_ERROR', message: 'Код истёк' } }, 401)
		}

		const valid = await Bun.password.verify(code, stored.codeHash)
		if (!valid) {
			await redis.set(
				key,
				JSON.stringify({ ...stored, attempts: attempts + 1 }),
				'EX',
				AUTH_CODE_TTL_SECONDS,
			)
			return c.json({ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный код' } }, 401)
		}

		await redis.del(key)
		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, stored.userAuthUuid),
		})
		if (!user?.email || user.email.trim().toLowerCase() !== normalizedEmail) {
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				404,
			)
		}
		if (!(await canSignIntoApp(user))) {
			clearAuthCookies(c)
			return c.json(subscriptionExpiredResponse(), 403)
		}

		const tokens = await generateTokens(user.authUuid, user.email, user.role)
		setAuthCookies(c, tokens)
		return c.json({ success: true, data: publicSessionData(tokens) })
	},
)

authRoutes.post(
	'/telegram/verify',
	authLimiter,
	zValidator('json', telegramBotVerifySchema),
	async (c) => {
		const { code } = c.req.valid('json')
		const cacheKey = `auth:botcode:${code}`
		const raw = await redis.get(cacheKey)
		if (!raw) {
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный или истёкший код' } },
				401,
			)
		}

		let payload: { userAuthUuid: string; email?: string | null; chatId?: string }
		try {
			payload = JSON.parse(raw) as { userAuthUuid: string; email?: string | null; chatId?: string }
		} catch {
			await redis.del(cacheKey)
			return c.json({ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный код' } }, 401)
		}

		await redis.del(cacheKey)
		if (payload.chatId) {
			await redis.del(`auth:botcodechat:${payload.chatId}`)
		}

		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, payload.userAuthUuid),
		})
		if (!user) {
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				404,
			)
		}
		// Вход по коду из бота — уже подтверждённая привязка Telegram:
		// сохраняем chat id, чтобы приложение не просило «подключить Telegram».
		if (payload.chatId && user.telegramChatId !== payload.chatId) {
			await db
				.update(users)
				.set({ telegramChatId: payload.chatId, updatedAt: new Date() })
				.where(eq(users.authUuid, user.authUuid))
		}
		if (!(await canSignIntoApp(user))) {
			clearAuthCookies(c)
			return c.json(subscriptionExpiredResponse(), 403)
		}

		const tokens = await generateTokens(user.authUuid, user.email ?? '', user.role)
		setAuthCookies(c, tokens)
		return c.json({ success: true, data: { ...publicSessionData(tokens), redirectTo: '/app' } })
	},
)

authRoutes.post(
	'/purchase-session',
	authLimiter,
	zValidator('json', purchaseSessionSchema),
	async (c) => {
		return c.json(
			{
				success: false,
				error: {
					code: 'AUTH_FLOW_DISABLED',
					message: 'Вход открывается после успешной оплаты.',
				},
			},
			410,
		)
	},
)

// Регистрация (создание аккаунта до оплаты)
authRoutes.post('/register', authLimiter, zValidator('json', registerSchema), async (c) => {
	const { email, password, fullName } = c.req.valid('json')
	const identity = createPasswordAuthIdentity(email)
	const normalizedName = fullName.trim()

	const existing = await db.query.users.findFirst({
		where: eq(users.email, identity.email),
	})
	if (existing) {
		return c.json(
			{
				success: false,
				error: {
					code: 'AUTH_ERROR',
					message: 'Аккаунт с таким email уже существует. Войдите.',
				},
			},
			409,
		)
	}

	const passwordHash = await Bun.password.hash(password, { algorithm: 'bcrypt', cost: 12 })
	const [created] = await db
		.insert(users)
		.values({
			...identity,
			fullName: normalizedName,
			passwordHash,
			role: 'user',
			firstEntry: true,
			onboardingSeen: false,
		})
		.onConflictDoNothing({ target: users.email })
		.returning()
	if (!created) {
		return c.json(
			{
				success: false,
				error: {
					code: 'AUTH_ERROR',
					message: 'Аккаунт с таким email уже существует. Войдите.',
				},
			},
			409,
		)
	}

	const tokens = await generateTokens(created.authUuid, created.email ?? '', created.role)
	setAuthCookies(c, tokens)
	return c.json({ success: true, data: publicSessionData(tokens) })
})

// Refresh token
authRoutes.post('/refresh', async (c) => {
	const refreshToken = await readRefreshTokenFromRequest(c)

	if (!refreshToken) {
		clearAuthCookies(c)
		return c.json(
			{
				success: false,
				error: { code: 'AUTH_ERROR', message: 'Сессия истекла. Войдите ещё раз.' },
			},
			401,
		)
	}

	let payload: { sub?: string; type?: string }
	try {
		const verified = await (await import('jose')).jwtVerify(refreshToken, jwtSecret)
		payload = verified.payload
	} catch {
		clearAuthCookies(c)
		return c.json(
			{
				success: false,
				error: { code: 'AUTH_ERROR', message: 'Сессия истекла. Войдите ещё раз.' },
			},
			401,
		)
	}

	if (payload.type !== 'refresh' || !payload.sub) {
		clearAuthCookies(c)
		return c.json(
			{
				success: false,
				error: { code: 'AUTH_ERROR', message: 'Сессия истекла. Войдите ещё раз.' },
			},
			401,
		)
	}

	try {
		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, payload.sub),
		})
		if (!user) {
			clearAuthCookies(c)
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				401,
			)
		}
		if (!(await canSignIntoApp(user))) {
			clearAuthCookies(c)
			return c.json(subscriptionExpiredResponse(), 403)
		}

		// Проверяем, что refresh token не был отозван, и атомарно запускаем ротацию.
		const key = getRefreshSessionKey(payload.sub, refreshToken)
		const rotation = await claimRefreshSessionRotation(redis, key)
		if (rotation.status === 'rotated' && rotation.tokens) {
			setAuthCookies(c, rotation.tokens)
			return c.json({ success: true, data: publicSessionData(rotation.tokens) })
		}
		if (rotation.status === 'pending') {
			const tokens = await waitForRefreshRotationResult(redis, key)
			if (tokens) {
				setAuthCookies(c, tokens)
				return c.json({ success: true, data: publicSessionData(tokens) })
			}
			return c.json(
				{
					success: false,
					error: {
						code: 'REFRESH_PENDING',
						message: 'Сессия обновляется. Повторите запрос через несколько секунд.',
					},
				},
				503,
			)
		}
		if (rotation.status !== 'claimed') {
			clearAuthCookies(c)
			return c.json(
				{
					success: false,
					error: { code: 'AUTH_ERROR', message: 'Сессия истекла. Войдите ещё раз.' },
				},
				401,
			)
		}

		const tokens = await generateTokens(user.authUuid, user.email ?? '', user.role)
		await storeRotatedRefreshSession(redis, key, tokens)
		setAuthCookies(c, tokens)
		return c.json({ success: true, data: publicSessionData(tokens) })
	} catch (error) {
		logger.error({ err: error }, 'Failed to restore auth session')
		return c.json(
			{
				success: false,
				error: {
					code: 'SESSION_UNAVAILABLE',
					message: 'Не удалось обновить сессию. Повторите попытку.',
				},
			},
			503,
		)
	}
})

// Смена пароля (авторизованный)
authRoutes.post(
	'/change-password',
	authMiddleware,
	zValidator('json', changePasswordSchema),
	async (c) => {
		const userId = c.get('userId')
		const { currentPassword, newPassword } = c.req.valid('json')

		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, userId),
		})
		if (!user) {
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				400,
			)
		}

		if (user.passwordHash) {
			if (!currentPassword) {
				return c.json(
					{
						success: false,
						error: { code: 'AUTH_ERROR', message: 'Введите текущий пароль' },
					},
					400,
				)
			}
			const valid = await Bun.password.verify(currentPassword, user.passwordHash)
			if (!valid) {
				return c.json(
					{ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный текущий пароль' } },
					401,
				)
			}
		}

		const newHash = await Bun.password.hash(newPassword, { algorithm: 'bcrypt', cost: 12 })
		await db.update(users).set({ passwordHash: newHash }).where(eq(users.authUuid, userId))

		if (user.email) {
			void sendTemplateEmail(user.email, {
				type: 'password-changed',
				fullName: user.fullName ?? null,
			}).catch(() => undefined)
		}

		return c.json({ success: true, data: { message: 'Пароль изменён' } })
	},
)

authRoutes.post(
	'/send-access-password',
	authLimiter,
	zValidator('json', sendAccessPasswordSchema),
	async (c) => {
		const { email, channel } = c.req.valid('json')
		const normalizedEmail = email.trim().toLowerCase()

		const user = await db.query.users.findFirst({
			where: eq(users.email, normalizedEmail),
			columns: {
				authUuid: true,
				email: true,
				fullName: true,
				passwordHash: true,
			},
		})

		if (!user?.email) {
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				404,
			)
		}

		const activePayment = await findLatestActivePayment({
			userAuthUuid: user.authUuid,
			email: normalizedEmail,
		})

		if (!isParticipant(activePayment)) {
			return c.json(
				{
					success: false,
					error: {
						code: 'AUTH_ERROR',
						message: 'Активный доступ к клубу не найден',
					},
				},
				403,
			)
		}

		const telegramBinding =
			channel === 'telegram'
				? await db.query.payments.findFirst({
						where: or(
							eq(payments.userAuthUuid, user.authUuid),
							eq(payments.email, normalizedEmail),
						),
						columns: { cpAccountId: true },
						orderBy: [
							desc(payments.updatedAt),
							desc(payments.dateFinish),
							desc(payments.createdAt),
						],
					})
				: null
		const telegramUserId =
			channel === 'telegram'
				? String(activePayment?.cpAccountId ?? telegramBinding?.cpAccountId ?? '').trim()
				: null
		const runtimeSettings = await loadRuntimeSettings()
		if (channel === 'telegram' && !runtimeSettings.telegramBotToken) {
			return c.json(
				{
					success: false,
					error: {
						code: 'AUTH_ERROR',
						message: 'Отправка в Telegram пока не настроена',
					},
				},
				503,
			)
		}

		if (channel === 'telegram' && !telegramUserId) {
			return c.json(
				{
					success: false,
					error: {
						code: 'AUTH_ERROR',
						message: 'Для этого пользователя не найден Telegram в базе',
					},
				},
				400,
			)
		}

		const nextPassword = generateAccessPassword()
		const passwordHash = await Bun.password.hash(nextPassword, {
			algorithm: 'bcrypt',
			cost: 12,
		})

		await db
			.update(users)
			.set({
				passwordHash,
				authType: 'email',
				updatedAt: new Date(),
			})
			.where(eq(users.authUuid, user.authUuid))

		const appBaseUrl = await getAppBaseUrl()
		const messageText = buildAccessPasswordMessage(nextPassword, appBaseUrl)

		try {
			if (channel === 'telegram') {
				const telegramRecipient = telegramUserId
				if (!telegramRecipient) {
					throw new Error('Telegram user id is missing')
				}

				await sendTelegramMessage(
					telegramRecipient,
					buildTelegramAccessPasswordMessage(nextPassword, appBaseUrl),
					{
						parseMode: 'HTML',
						replyMarkup: {
							inline_keyboard: [
								[{ text: 'Скопировать пароль', copy_text: { text: nextPassword } }],
							],
						},
					},
				)
			} else {
				const mail = buildAccessPasswordMail(nextPassword, appBaseUrl)
				await sendMail({
					to: user.email,
					subject: mail.subject,
					html: mail.html,
					text: mail.text,
				})
			}
		} catch (error) {
			logger.error(
				{ err: error, channel, email: normalizedEmail },
				'Failed to send access password',
			)
			return c.json(
				{
					success: false,
					error: {
						code: 'AUTH_ERROR',
						message:
							channel === 'telegram'
								? 'Не удалось отправить пароль в Telegram'
								: 'Не удалось отправить пароль на почту',
					},
				},
				500,
			)
		}

		const response: SendAccessPasswordResponse = {
			channel,
			message:
				channel === 'telegram'
					? 'Новый пароль отправлен в Telegram'
					: 'Новый пароль отправлен на почту',
		}

		return c.json({ success: true, data: response })
	},
)

authRoutes.post(
	'/forgot-password',
	authLimiter,
	zValidator('json', forgotPasswordSchema),
	async (c) => {
		const { email } = c.req.valid('json')
		const normalizedEmail = email.trim().toLowerCase()

		const user = await db.query.users.findFirst({
			where: eq(users.email, normalizedEmail),
			columns: {
				authUuid: true,
				email: true,
				fullName: true,
				passwordHash: true,
			},
		})

		if (user?.email) {
			const token = nanoid(48)
			const resetUrl = `${(await getAppBaseUrl()).replace(/\/$/, '')}/reset-password?token=${token}`
			await redis.set(
				`password-reset:${token}`,
				JSON.stringify({ userId: user.authUuid, email: user.email }),
				'EX',
				60 * 60,
			)

			void sendTemplateEmail(user.email, {
				type: 'password-reset',
				resetUrl,
				fullName: user.fullName ?? null,
			}).catch(() => undefined)
		}

		return c.json({
			success: true,
			data: {
				message:
					'Если аккаунт с таким email существует, мы отправили письмо со ссылкой для сброса пароля',
			},
		})
	},
)

authRoutes.post(
	'/reset-password',
	authLimiter,
	zValidator('json', resetPasswordSchema),
	async (c) => {
		const { token, newPassword } = c.req.valid('json')

		const payload = await redis.get(`password-reset:${token}`)
		if (!payload) {
			return c.json(
				{
					success: false,
					error: { code: 'AUTH_ERROR', message: 'Ссылка недействительна или истекла' },
				},
				400,
			)
		}

		const parsed = JSON.parse(payload) as { userId: string; email?: string }
		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, parsed.userId),
			columns: {
				authUuid: true,
				email: true,
				fullName: true,
			},
		})

		if (!user) {
			await redis.del(`password-reset:${token}`)
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Пользователь не найден' } },
				404,
			)
		}

		const passwordHash = await Bun.password.hash(newPassword, { algorithm: 'bcrypt', cost: 12 })
		await db.update(users).set({ passwordHash }).where(eq(users.authUuid, user.authUuid))
		await redis.del(`password-reset:${token}`)

		await deleteRedisKeysByPattern(redis, `refresh:${user.authUuid}:*`)

		if (user.email) {
			void sendTemplateEmail(user.email, {
				type: 'password-changed',
				fullName: user.fullName ?? null,
			}).catch(() => undefined)
		}

		return c.json({ success: true, data: { message: 'Пароль успешно обновлён' } })
	},
)

// Проверка текущей сессии
authRoutes.get('/me', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, userId),
		columns: {
			passwordHash: false,
		},
	})
	if (!user) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}
	return c.json({ success: true, data: user })
})

// Выход (инвалидация refresh tokens)
authRoutes.post('/logout', authMiddleware, async (c) => {
	const userId = c.get('userId')
	// Удаляем все refresh tokens пользователя
	await deleteRedisKeysByPattern(redis, `refresh:${userId}:*`)
	clearAuthCookies(c)
	return c.json({ success: true, data: { message: 'Вы вышли из системы' } })
})
