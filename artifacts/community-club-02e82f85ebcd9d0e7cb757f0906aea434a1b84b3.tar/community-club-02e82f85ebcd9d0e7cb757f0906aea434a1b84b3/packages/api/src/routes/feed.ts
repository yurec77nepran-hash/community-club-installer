import {
	type FeedAudience,
	cursorPaginationSchema,
	feedPostReactions,
	feedPosts,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, eq } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import {
	canAccessFeedAudience,
	getFeedAudienceForUserRole,
	loadFeedPage,
	loadFeedPostById,
} from '../lib/feed'
import { activeSubscriptionMiddleware, authMiddleware } from '../middleware/auth'

const feedQuerySchema = cursorPaginationSchema.extend({
	section: z.literal('club').optional(),
})

const reactionSchema = z.object({
	emoji: z.string().trim().min(1).max(16),
})

export const feedRoutes = new Hono<AppEnv>()

feedRoutes.use('*', authMiddleware, activeSubscriptionMiddleware)

feedRoutes.get('/', zValidator('query', feedQuerySchema), async (c) => {
	const { cursor, limit, section } = c.req.valid('query')
	const userRole = c.get('userRole')
	const currentUserId = c.get('userId')
	const audience = getFeedAudienceForUserRole(userRole)
	void section

	if (!canAccessFeedAudience({ userRole, audience })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Лента недоступна' },
			},
			403,
		)
	}

	const data = await loadFeedPage({
		audience,
		cursor,
		limit,
		currentUserId,
	})

	return c.json({ success: true, data })
})

feedRoutes.post('/:postId/reactions', zValidator('json', reactionSchema), async (c) => {
	const postId = Number(c.req.param('postId'))
	const currentUserId = c.get('userId')
	const userRole = c.get('userRole')
	const { emoji } = c.req.valid('json')

	const post = await db.query.feedPosts.findFirst({
		where: eq(feedPosts.id, postId),
		columns: {
			id: true,
			audience: true,
		},
	})

	if (!post) {
		return c.json({ success: false, error: { code: 'NOT_FOUND', message: 'Пост не найден' } }, 404)
	}

	if (!canAccessFeedAudience({ userRole, audience: post.audience })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Лента недоступна' },
			},
			403,
		)
	}

	const existing = await db.query.feedPostReactions.findFirst({
		where: and(
			eq(feedPostReactions.postId, postId),
			eq(feedPostReactions.userAuthUuid, currentUserId),
			eq(feedPostReactions.emoji, emoji),
		),
		columns: {
			id: true,
		},
	})

	if (existing) {
		await db.delete(feedPostReactions).where(eq(feedPostReactions.id, existing.id))
	} else {
		await db.insert(feedPostReactions).values({
			postId,
			userAuthUuid: currentUserId,
			emoji,
		})
	}

	const item = await loadFeedPostById({ postId, currentUserId })
	return c.json({
		success: true,
		data: {
			action: existing ? 'removed' : 'added',
			item,
		},
	})
})
