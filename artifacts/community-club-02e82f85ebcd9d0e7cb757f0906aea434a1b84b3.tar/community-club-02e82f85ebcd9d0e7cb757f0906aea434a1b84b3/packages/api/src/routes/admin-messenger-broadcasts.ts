import {
	messengerBroadcasts,
	messengerConnections,
	sanitizeTelegramBroadcastHtml,
	telegramBroadcastPlainText,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, ne, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db } from '../db/client'
import { appendAdminActivityLog } from '../lib/admin-activity'
import {
	messengerCapabilities,
	subscribeMaxWebhook,
	verifyMessengerConnection,
} from '../lib/messenger-channel'
import { encryptSecret } from '../lib/secret-vault'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

const providerSchema = z.enum(['telegram', 'vk', 'max'])
const connectionSchema = z.object({
	provider: providerSchema,
	token: z.string().trim().min(8).max(4096),
	externalId: z.string().trim().max(200).optional(),
	label: z.string().trim().max(120).optional(),
	apiUrl: z.string().trim().url().max(500).optional(),
	confirmationCode: z.string().trim().max(500).optional(),
	callbackSecret: z.string().trim().max(500).optional(),
})
const campaignSchema = z.object({
	name: z.string().trim().min(1).max(120),
	connectionIds: z.array(z.number().int().positive()).min(1).max(20),
	body: z.string().min(1).max(20_000),
	sendAt: z.string().datetime().optional(),
})

function publicConnection(connection: typeof messengerConnections.$inferSelect) {
	return {
		id: connection.id,
		provider: connection.provider,
		externalId: connection.externalId,
		label: connection.label,
		isActive: Boolean(connection.isActive),
		capabilities: messengerCapabilities[connection.provider],
		webhookUrl:
			connection.provider === 'vk'
				? `${env.APP_URL.replace(/\/$/, '')}/api/messenger-webhooks/vk/${connection.id}`
				: connection.provider === 'max'
					? `${env.APP_URL.replace(/\/$/, '')}/api/messenger-webhooks/max/${connection.id}`
					: null,
	}
}

async function audience(connectionIds: number[]) {
	const [row] = await db.execute<{ contacts: number; users: number; overlap_users: number }>(sql`
		WITH active_contacts AS (
			SELECT user_auth_uuid
			FROM messenger_contacts
			WHERE connection_id IN (${sql.join(
				connectionIds.map((id) => sql`${id}`),
				sql`, `,
			)}) AND consent_status = 'active'
		)
		, people AS (
			SELECT user_auth_uuid, count(*)::integer AS contact_count
			FROM active_contacts GROUP BY user_auth_uuid
		)
		SELECT
			(SELECT count(*)::integer FROM active_contacts) AS contacts,
			count(*)::integer AS users,
			count(*) FILTER (WHERE contact_count > 1)::integer AS overlap_users
		FROM people
	`)
	return {
		contacts: row?.contacts ?? 0,
		uniqueUsers: row?.users ?? 0,
		overlapUsers: row?.overlap_users ?? 0,
	}
}

async function moveCampaign(id: number, from: 'processing' | 'paused', to: 'paused' | 'scheduled') {
	const [campaign] = await db
		.update(messengerBroadcasts)
		.set({
			status: to,
			...(to === 'scheduled' ? { sendAt: new Date() } : {}),
			updatedAt: new Date(),
		})
		.where(and(eq(messengerBroadcasts.id, id), eq(messengerBroadcasts.status, from)))
		.returning()
	return campaign
}

export const adminMessengerBroadcastRoutes = new Hono<AppEnv>()

adminMessengerBroadcastRoutes.use('*', authMiddleware, adminMiddleware)

adminMessengerBroadcastRoutes.get('/', async (c) => {
	const [connections, campaigns] = await Promise.all([
		db.query.messengerConnections.findMany({ orderBy: [desc(messengerConnections.id)] }),
		db.query.messengerBroadcasts.findMany({
			orderBy: [desc(messengerBroadcasts.createdAt)],
			limit: 100,
		}),
	])
	return c.json({
		success: true,
		data: { connections: connections.map(publicConnection), campaigns },
	})
})

adminMessengerBroadcastRoutes.get(
	'/audience',
	zValidator('query', z.object({ ids: z.string().min(1) })),
	async (c) => {
		const ids = Array.from(
			new Set(c.req.valid('query').ids.split(',').map(Number).filter(Number.isInteger)),
		)
		return c.json({ success: true, data: await audience(ids) })
	},
)

adminMessengerBroadcastRoutes.post(
	'/connections',
	zValidator('json', connectionSchema),
	async (c) => {
		const input = c.req.valid('json')
		try {
			const verified = await verifyMessengerConnection(input)
			const webhookSecret =
				input.provider === 'max' ? crypto.randomUUID().replaceAll('-', '') : null
			const [connection] = await db
				.insert(messengerConnections)
				.values({
					provider: input.provider,
					externalId: verified.externalId,
					label: input.label || verified.label,
					encryptedToken: encryptSecret(input.token),
					config: {
						...(input.apiUrl ? { apiUrl: input.apiUrl } : {}),
						...(input.confirmationCode ? { confirmationCode: input.confirmationCode } : {}),
						...(input.callbackSecret ? { callbackSecret: input.callbackSecret } : {}),
					},
					webhookSecret,
				})
				.onConflictDoUpdate({
					target: [messengerConnections.provider, messengerConnections.externalId],
					set: {
						label: input.label || verified.label,
						encryptedToken: encryptSecret(input.token),
						config: {
							...(input.apiUrl ? { apiUrl: input.apiUrl } : {}),
							...(input.confirmationCode ? { confirmationCode: input.confirmationCode } : {}),
							...(input.callbackSecret ? { callbackSecret: input.callbackSecret } : {}),
						},
						webhookSecret,
						isActive: 1,
						updatedAt: new Date(),
					},
				})
				.returning()
			if (connection.provider === 'max') {
				try {
					await subscribeMaxWebhook(connection)
				} catch (error) {
					await db
						.update(messengerConnections)
						.set({ isActive: 0, updatedAt: new Date() })
						.where(eq(messengerConnections.id, connection.id))
					throw error
				}
			}
			await appendAdminActivityLog({
				actorAuthUuid: c.get('userId'),
				action: 'create',
				entityType: 'messenger_connection',
				entityId: String(connection.id),
				summary: `Подключён ${connection.provider}-канал «${connection.label}»`,
			})
			return c.json({ success: true, data: publicConnection(connection) }, 201)
		} catch (error) {
			return c.json(
				{
					success: false,
					error: {
						code: 'BAD_REQUEST',
						message: error instanceof Error ? error.message : 'Не удалось подключить канал',
					},
				},
				400,
			)
		}
	},
)

adminMessengerBroadcastRoutes.post('/', zValidator('json', campaignSchema), async (c) => {
	const input = c.req.valid('json')
	const connections = await db.query.messengerConnections.findMany({
		where: sql`${messengerConnections.id} IN (${sql.join(
			input.connectionIds.map((id) => sql`${id}`),
			sql`, `,
		)})`,
	})
	if (
		connections.length !== input.connectionIds.length ||
		connections.some((item) => !item.isActive)
	) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Выберите только активные подключения' },
			},
			400,
		)
	}
	const body = sanitizeTelegramBroadcastHtml(input.body)
	const text = telegramBroadcastPlainText(body)
	if (!text)
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Добавьте текст сообщения' } },
			400,
		)
	if (connections.some((item) => item.provider === 'max') && text.length > 4000) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'MAX принимает до 4 000 символов' },
			},
			400,
		)
	}
	const [campaign] = await db
		.insert(messengerBroadcasts)
		.values({
			name: input.name,
			connectionIds: input.connectionIds,
			body,
			sendAt: input.sendAt ? new Date(input.sendAt) : new Date(),
			createdByAuthUuid: c.get('userId'),
		})
		.returning()
	return c.json({ success: true, data: campaign }, 201)
})

adminMessengerBroadcastRoutes.post('/:id/stop', async (c) => {
	const [campaign] = await db
		.update(messengerBroadcasts)
		.set({ status: 'cancelled', updatedAt: new Date() })
		.where(
			and(
				eq(messengerBroadcasts.id, Number(c.req.param('id'))),
				ne(messengerBroadcasts.status, 'completed'),
			),
		)
		.returning()
	if (!campaign)
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Рассылка уже завершена' } },
			400,
		)
	return c.json({ success: true, data: campaign })
})

adminMessengerBroadcastRoutes.post('/:id/pause', async (c) => {
	const campaign = await moveCampaign(Number(c.req.param('id')), 'processing', 'paused')
	if (!campaign)
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Рассылку нельзя поставить на паузу' },
			},
			400,
		)
	return c.json({ success: true, data: campaign })
})

adminMessengerBroadcastRoutes.post('/:id/resume', async (c) => {
	const campaign = await moveCampaign(Number(c.req.param('id')), 'paused', 'scheduled')
	if (!campaign)
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Рассылку нельзя возобновить' } },
			400,
		)
	return c.json({ success: true, data: campaign })
})
