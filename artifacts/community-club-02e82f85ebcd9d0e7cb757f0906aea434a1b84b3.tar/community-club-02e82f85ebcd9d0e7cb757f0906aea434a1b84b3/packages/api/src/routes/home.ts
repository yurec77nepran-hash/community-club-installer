import type { ChatListItem, CursorPaginatedResponse } from '@community-club/shared'
import { materials } from '@community-club/shared'
import { desc, eq, lt } from 'drizzle-orm'
import { Hono } from 'hono'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { getChatListItemsForUser } from '../lib/chat-mentions'
import { normalizeMaterialTypeKey } from '../lib/material-types'
import { getMaterialsAccessScope, hasTypeAccess } from '../lib/materials-access'
import { measureDbOperation } from '../lib/performance'
import { rememberCachedValue } from '../lib/server-cache'
import { findPreviewStoredMediaFile, resolvePublicFileUrl } from '../lib/storage'
import { activeSubscriptionMiddleware, authMiddleware } from '../middleware/auth'

type HomeSnapshotMaterial = {
	id: number
	type: string
	title: string
	imageUrl: string | null
	shortDescription: string | null
	fullDescription: string | null
	subsection: string | null
	active: boolean
	mediaType: string | null
	durationSeconds: number | null
	fileSizeBytes: number | null
	createdAt: Date
	accessible: boolean
	accessMessage: string | null
}

function encodeCursor(params: { id: number; createdAt: Date }) {
	return Buffer.from(
		JSON.stringify({ id: params.id, createdAt: params.createdAt.toISOString() }),
	).toString('base64url')
}

function appendVersionToUrl(url: string | null, version: string | number | null | undefined) {
	if (!url || version === null || typeof version === 'undefined' || version === '') return url
	const separator = url.includes('?') ? '&' : '?'
	return `${url}${separator}v=${encodeURIComponent(String(version))}`
}

function resolveMaterialPreviewImage(item: {
	id?: number
	imageUrl: string | null
	storagePath?: string | null
	mediaType: string | null
	fileSizeBytes?: number | null
}) {
	const storedPreview = findPreviewStoredMediaFile(item.storagePath, item.mediaType)
	const previewPath = item.imageUrl ?? storedPreview?.path ?? storedPreview?.url ?? null
	const resolved = resolvePublicFileUrl('media', previewPath) ?? null
	return appendVersionToUrl(resolved, item.fileSizeBytes ?? item.id ?? null)
}

export const homeRoutes = new Hono<AppEnv>()

homeRoutes.use('*', authMiddleware, activeSubscriptionMiddleware)

homeRoutes.get('/snapshot', async (c) => {
	const userId = c.get('userId')
	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	const accessScope = getMaterialsAccessScope({ userRole, contentSections, clubAccess })
	const cacheKey = JSON.stringify({
		accessScope,
	})

	const [chats, recentMaterials] = await Promise.all([
		getChatListItemsForUser({
			userId,
			userRole: userRole as AppEnv['Variables']['userRole'],
		}),
		rememberCachedValue({
			namespace: 'home:recent-feed',
			key: cacheKey,
			ttlSeconds: 15,
			load: async () => {
				const materialRows = await measureDbOperation(
					'home.snapshot.materials',
					{ accessScope },
					() =>
						db.query.materials.findMany({
							where: eq(materials.active, true),
							orderBy: [desc(materials.id)],
							limit: 13,
							columns: {
								id: true,
								type: true,
								title: true,
								imageUrl: true,
								shortDescription: true,
								fullDescription: true,
								subsection: true,
								active: true,
								mediaType: true,
								storagePath: true,
								durationSeconds: true,
								fileSizeBytes: true,
								createdAt: true,
							},
						}),
				)

				const slicedItems = materialRows.slice(0, 12)
				const normalizedItems: HomeSnapshotMaterial[] = slicedItems.map((item) => {
					const accessible = hasTypeAccess({
						type: item.type,
						userRole,
						contentSections,
						clubAccess,
					})
					const { storagePath, ...publicItem } = item
					void storagePath
					return {
						...publicItem,
						type: normalizeMaterialTypeKey(item.type),
						imageUrl: resolveMaterialPreviewImage(item),
						accessible,
						accessMessage: accessible ? null : 'У вас нет доступа к разделу',
					}
				})

				const lastItem = normalizedItems.at(-1)
				const nextCursor =
					materialRows.length > 12 && lastItem
						? encodeCursor({ id: lastItem.id, createdAt: lastItem.createdAt })
						: null

				return {
					items: normalizedItems,
					nextCursor,
				} satisfies CursorPaginatedResponse<HomeSnapshotMaterial>
			},
		}),
	])

	const payload = {
		chats,
		recentMaterials,
		unreadMentionsTotal: chats.reduce(
			(total: number, chat: ChatListItem) => total + chat.unreadMentionCount,
			0,
		),
	}

	c.header('Cache-Control', 'private, max-age=15, stale-while-revalidate=60')
	return c.json({ success: true, data: payload })
})
