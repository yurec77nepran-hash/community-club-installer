import { pwaLaunchMetadataSchema } from '@community-club/shared'
import type { PwaLaunchStatusResponse } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { Hono } from 'hono'
import type { MiddlewareHandler } from 'hono'
import type { AppEnv } from '../app'
import type { PwaLaunchHistoryStore, PwaLaunchRecord } from '../lib/pwa-launch-history'

type PwaRoutesDependencies = {
	readonly authenticate: MiddlewareHandler<AppEnv>
	readonly store: PwaLaunchHistoryStore
}

function toStatusResponse(record: PwaLaunchRecord | null): PwaLaunchStatusResponse {
	if (record === null) {
		return {
			hasStandaloneLaunch: false,
			firstLaunchedAt: null,
			lastLaunchedAt: null,
			launchCount: 0,
			userAgent: null,
			platform: null,
			deviceLabel: null,
		}
	}

	return {
		hasStandaloneLaunch: true,
		firstLaunchedAt: record.firstLaunchedAt.toISOString(),
		lastLaunchedAt: record.lastLaunchedAt.toISOString(),
		launchCount: record.launchCount,
		userAgent: record.userAgent,
		platform: record.platform,
		deviceLabel: record.deviceLabel,
	}
}

export function createPwaRoutes(dependencies: PwaRoutesDependencies) {
	const routes = new Hono<AppEnv>()
	routes.use('*', dependencies.authenticate)

	routes.get('/status', async (context) => {
		const record = await dependencies.store.findByUser(context.get('userId'))
		return context.json({ success: true, data: toStatusResponse(record) })
	})

	routes.post(
		'/launch',
		zValidator('json', pwaLaunchMetadataSchema, (result, context) => {
			if (result.success) return

			return context.json(
				{
					success: false,
					error: {
						code: 'VALIDATION_ERROR',
						message: 'Проверьте данные запуска PWA',
						details: result.error.errors.map((error) => ({
							path: error.path.join('.'),
							message: error.message,
						})),
					},
				},
				400,
			)
		}),
		async (context) => {
			const record = await dependencies.store.recordLaunch({
				userAuthUuid: context.get('userId'),
				metadata: context.req.valid('json'),
			})

			return context.json({ success: true, data: toStatusResponse(record) })
		},
	)

	return routes
}
