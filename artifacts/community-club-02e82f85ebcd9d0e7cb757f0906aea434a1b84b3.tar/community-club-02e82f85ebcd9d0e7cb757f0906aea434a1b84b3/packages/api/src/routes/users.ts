import { httpUrlSchema, users } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { eq } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { buildClubAccessMap } from '../lib/materials-access'
import { invalidateCachedValue } from '../lib/server-cache'
import { resolveAvatarUrl } from '../lib/storage'
import { authMiddleware } from '../middleware/auth'

export const userRoutes = new Hono<AppEnv>()

userRoutes.use('*', authMiddleware)

const userPublicFields = {
	id: users.id,
	authUuid: users.authUuid,
	email: users.email,
	phone: users.phone,
	authType: users.authType,
	username: users.username,
	avatarUrl: users.avatarUrl,
	fullName: users.fullName,
	firstName: users.firstName,
	city: users.city,
	socialAccount: users.socialAccount,
	socialLinks: users.socialLinks,
	telegramChatId: users.telegramChatId,
	telegramUsername: users.telegramUsername,
	telegramNotificationsEnabled: users.telegramNotificationsEnabled,
	maxMessengerUserId: users.maxMessengerUserId,
	workPlace: users.workPlace,
	manicurePrice: users.manicurePrice,
	pedicurePrice: users.pedicurePrice,
	monthlyIncome: users.monthlyIncome,
	expectations: users.expectations,
	otherExpectation: users.otherExpectation,
	gameRole: users.gameRole,
	points: users.points,
	bonusBalance: users.bonusBalance,
	role: users.role,
	firstEntry: users.firstEntry,
	onboardingSeen: users.onboardingSeen,
	createdAt: users.createdAt,
	updatedAt: users.updatedAt,
} as const

function normalizeSocialLinks(
	links: string[] | null | undefined,
	socialAccount: string | null | undefined,
) {
	const normalized = (links ?? []).map((item) => item.trim()).filter(Boolean)
	if (normalized.length > 0) return normalized
	const fallback = socialAccount?.trim()
	return fallback ? [fallback] : []
}

type UserResponseRow = {
	avatarUrl: string | null
	socialLinks: string[] | null
	socialAccount: string | null
	passwordHash?: string | null
	[key: string]: unknown
}

function mapUserResponse(user: UserResponseRow) {
	const { passwordHash: _passwordHash, ...publicUser } = user

	return {
		...publicUser,
		hasPassword: Boolean(_passwordHash),
		avatarUrl: resolveAvatarUrl(user.avatarUrl),
		socialLinks: normalizeSocialLinks(user.socialLinks, user.socialAccount),
	}
}

// Текущий пользователь
userRoutes.get('/me', async (c) => {
	const userId = c.get('userId')
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, userId),
	})
	if (!user) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	return c.json({
		success: true,
		data: mapUserResponse(user),
	})
})

userRoutes.post('/club-access/check', async (c) => {
	const userId = c.get('userId')
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, userId),
		columns: {
			authUuid: true,
			email: true,
		},
	})

	if (!user) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	return c.json({
		success: true,
		data: {
			access: buildClubAccessMap(),
			checkedAt: null,
		},
	})
})

// Обновить профиль
const updateProfileSchema = z.object({
	fullName: z.string().min(1).max(100).optional(),
	username: z
		.string()
		.min(3)
		.max(30)
		.regex(/^[a-zA-Z0-9_]+$/)
		.optional(),
	avatarUrl: z
		.string()
		.min(1)
		.refine(
			(value) =>
				value.startsWith('emoji:') ||
				httpUrlSchema.safeParse(value).success ||
				/^[a-zA-Z0-9._/-]+$/.test(value),
			'Некорректный формат аватара',
		)
		.optional()
		.nullable(),
	telegramNotificationsEnabled: z.boolean().optional(),
})

userRoutes.patch('/me', zValidator('json', updateProfileSchema), async (c) => {
	const userId = c.get('userId')
	const body = c.req.valid('json')

	// Проверка уникальности username
	if (body.username) {
		const existing = await db.query.users.findFirst({
			where: eq(users.username, body.username),
		})
		if (existing && existing.authUuid !== userId) {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Этот логин уже занят' },
				},
				409,
			)
		}
	}

	const [updated] = await db
		.update(users)
		.set(body)
		.where(eq(users.authUuid, userId))
		.returning({
			...userPublicFields,
		})

	await invalidateCachedValue('users:me', userId)
	return c.json({
		success: true,
		data: mapUserResponse(updated),
	})
})

userRoutes.patch('/me/onboarding', async (c) => {
	const userId = c.get('userId')
	const [updated] = await db
		.update(users)
		.set({ onboardingSeen: true, updatedAt: new Date() })
		.where(eq(users.authUuid, userId))
		.returning({
			...userPublicFields,
		})

	await invalidateCachedValue('users:me', userId)
	return c.json({
		success: true,
		data: mapUserResponse(updated),
	})
})
