import { describe, expect, mock, test } from 'bun:test'
import type { ChatMessageWithMeta } from '@community-club/shared'
import { Hono } from 'hono'
import { createMiddleware } from 'hono/factory'
import type { AppEnv } from '../app'

const chatId = 42
const userId = '11111111-1111-4111-8111-111111111111'
const createdAt = new Date('2026-09-13T10:00:00.000Z')
const persistedMessage = {
	id: 901,
	chatId,
	userAuthUuid: userId,
	content: 'Сообщение через HTTP fallback',
	replyToId: null,
	clientMessageId: 'fallback-901',
	messageType: 'text',
	attachmentUrl: null,
	attachmentName: null,
	attachmentSize: null,
	linkPreview: null,
	isDeleted: false,
	createdAt,
	updatedAt: createdAt,
	author: {
		fullName: 'Участник клуба',
		avatarUrl: null,
		username: 'club-member',
		chatAdminBadge: false,
	},
	reactions: [],
	mentions: [],
} satisfies ChatMessageWithMeta

const deliverChatMessage = mock(async () => ({
	ok: true as const,
	duplicate: false,
	message: persistedMessage,
	access: {
		ok: true as const,
		chat: {
			id: chatId,
			slug: 'club-chat',
			name: 'Клубный чат',
			type: 'chat' as const,
			accessRole: 'all' as const,
			isEnabled: true,
			avatarUrl: null,
			description: null,
			settings: {},
			createdAt,
			updatedAt: createdAt,
		},
		member: null,
	},
}))
const broadcastChatRoomEvent = mock(
	async (_chatId: number, _event: Record<string, unknown>) => undefined,
)
const authenticate = createMiddleware<AppEnv>(async (context, next) => {
	context.set('userId', userId)
	context.set('userRole', 'user')
	context.set('hasActiveSubscription', true)
	await next()
})

mock.module('../db/client', () => ({ db: {} }))
mock.module('../lib/chat-access', () => ({
	ensureChatAccess: mock(),
	isSupportChatSlug: mock(() => false),
}))
mock.module('../lib/chat-delivery', () => ({ deliverChatMessage }))
mock.module('../lib/chat-mentions', () => ({
	getChatListItemsForUser: mock(),
	getMentionCandidates: mock(),
	loadMessageWithMeta: mock(),
	markChatRead: mock(),
	normalizeMentions: mock(),
}))
mock.module('../lib/chat-notifications', () => ({
	getChatNotificationSettings: mock(),
	setChatNotificationSettings: mock(),
}))
mock.module('../lib/storage', () => ({
	resolveAvatarUrl: (value: string | null) => value,
}))
mock.module('../middleware/auth', () => ({
	adminMiddleware: authenticate,
	authMiddleware: authenticate,
}))
mock.module('../ws/handler', () => ({ broadcastChatRoomEvent }))

const { chatRoutes } = await import('./chats')

describe('Chat routes', () => {
	test('POST /api/chats/:chatId/messages accepts the route ID without duplicate body chatId', async () => {
		// Given
		const app = new Hono<AppEnv>()
		app.route('/api/chats', chatRoutes)

		// When
		const response = await app.request(`/api/chats/${chatId}/messages`, {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({
				content: persistedMessage.content,
				clientMessageId: persistedMessage.clientMessageId,
				messageType: persistedMessage.messageType,
			}),
		})

		// Then
		expect(response.status).toBe(201)
		expect(deliverChatMessage).toHaveBeenCalledTimes(1)
		expect(broadcastChatRoomEvent).toHaveBeenCalledWith(chatId, {
			type: 'new_message',
			message: persistedMessage,
		})
	})
})
