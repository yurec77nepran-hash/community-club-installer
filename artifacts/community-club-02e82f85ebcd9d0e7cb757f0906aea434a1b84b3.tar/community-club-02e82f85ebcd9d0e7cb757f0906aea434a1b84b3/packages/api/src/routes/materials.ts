import {
	cursorPaginationSchema,
	materialCommentReactions,
	materialComments,
	materialFavorites,
	materialMediaProgress,
	materials,
	paginationSchema,
	users,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import {
	and,
	asc,
	desc,
	eq,
	gt,
	gte,
	ilike,
	inArray,
	isNotNull,
	lt,
	lte,
	or,
	sql,
} from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { getMaterialTypeQueryKeys, normalizeMaterialTypeKey } from '../lib/material-types'
import { getMaterialsAccessScope, hasTypeAccess } from '../lib/materials-access'
import { measureDbOperation } from '../lib/performance'
import { rememberCachedValue } from '../lib/server-cache'
import { loadGuestContentAccessSettings } from '../lib/site-settings'
import {
	findPreviewStoredMediaFile,
	parseMaterialGuestAccess,
	parseStoredMediaFiles,
	resolveAvatarUrl,
	resolvePublicFileUrl,
} from '../lib/storage'
import { activeSubscriptionMiddleware, authMiddleware } from '../middleware/auth'

export const materialRoutes = new Hono<AppEnv>()

const publicMaterialsPreviewQuerySchema = z.object({
	type: z.string().optional(),
	search: z.string().trim().max(120).optional(),
	subsection: z.string().trim().max(120).optional(),
	limit: z.coerce.number().int().min(1).max(24).default(18),
})

materialRoutes.get(
	'/public-preview',
	zValidator('query', publicMaterialsPreviewQuerySchema),
	async (c) => {
		const { type, search, subsection, limit } = c.req.valid('query')
		const guestAccess = await loadGuestContentAccessSettings()
		if (guestAccess.level === 'sections') {
			return c.json({ success: true, data: { items: [], nextCursor: null } })
		}
		const normalizedSearch = search?.trim() ?? ''
		const normalizedSubsection = subsection?.trim() ?? ''
		const cacheKey = JSON.stringify({
			type: type ?? null,
			search: normalizedSearch,
			subsection: normalizedSubsection,
			limit,
			guestAccess: guestAccess.level,
		})
		const items = await rememberCachedValue({
			namespace: 'materials:public-preview',
			key: cacheKey,
			ttlSeconds: normalizedSearch ? 15 : 60,
			load: async () => {
				const conditions = [eq(materials.active, true)]
				if (type) {
					const typeKeys = getMaterialTypeQueryKeys(type)
					conditions.push(
						typeKeys.length > 1
							? inArray(materials.type, typeKeys)
							: eq(materials.type, typeKeys[0]),
					)
				}
				if (normalizedSearch) {
					const searchCondition = or(
						ilike(materials.title, `%${normalizedSearch}%`),
						ilike(materials.shortDescription, `%${normalizedSearch}%`),
					)
					if (searchCondition) conditions.push(searchCondition)
				}
				if (normalizedSubsection) conditions.push(eq(materials.subsection, normalizedSubsection))

				const rows = await db.query.materials.findMany({
					where: and(...conditions),
					orderBy: [desc(materials.createdAt), desc(materials.id)],
					limit,
					columns: {
						id: true,
						type: true,
						title: true,
						imageUrl: true,
						videoCoverUrl: true,
						storagePath: true,
						shortDescription: true,
						subsection: true,
						mediaType: true,
						fileSizeBytes: true,
						createdAt: true,
					},
				})

				return rows.map((item) => {
					const blockAccess = parseMaterialGuestAccess(item.storagePath)
					return {
						id: item.id,
						type: normalizeMaterialTypeKey(item.type),
						title: item.title,
						imageUrl:
							guestAccess.level === 'preview' && blockAccess.cover !== 'visible'
								? null
								: resolveMaterialPreviewImage(item),
						shortDescription: item.shortDescription,
						fullDescription: null,
						subsection: item.subsection,
						active: true,
						mediaType: item.mediaType,
						durationSeconds: null,
						fileSizeBytes: null,
						createdAt: item.createdAt,
						accessible: guestAccess.level === 'preview',
						accessMessage: 'Доступно участникам клуба',
					}
				})
			},
		})

		c.header('Cache-Control', normalizedSearch ? 'public, max-age=15' : 'public, max-age=60')
		return c.json({ success: true, data: { items, nextCursor: null } })
	},
)

materialRoutes.get(
	'/public-preview/subsections',
	zValidator('query', z.object({ type: z.string().min(1).max(120) })),
	async (c) => {
		const { type } = c.req.valid('query')
		const guestAccess = await loadGuestContentAccessSettings()
		if (guestAccess.level === 'sections') {
			return c.json({ success: true, data: [] })
		}
		const typeKeys = getMaterialTypeQueryKeys(type)
		const rows = await db
			.selectDistinct({ subsection: materials.subsection })
			.from(materials)
			.where(
				and(
					eq(materials.active, true),
					typeKeys.length > 1 ? inArray(materials.type, typeKeys) : eq(materials.type, typeKeys[0]),
					isNotNull(materials.subsection),
				),
			)
			.orderBy(materials.subsection)
		return c.json({
			success: true,
			data: rows.map((row) => row.subsection?.trim()).filter(Boolean),
		})
	},
)

materialRoutes.get('/public-preview/stats', async (c) => {
	const counts = await rememberCachedValue({
		namespace: 'materials:public-preview-stats',
		key: 'all',
		ttlSeconds: 60,
		load: async () => {
			const rows = await db
				.select({ type: materials.type, count: sql<number>`count(*)::int` })
				.from(materials)
				.where(eq(materials.active, true))
				.groupBy(materials.type)
			const result: Record<string, number> = {}
			for (const row of rows) {
				const type = normalizeMaterialTypeKey(row.type)
				result[type] = (result[type] ?? 0) + (Number(row.count) || 0)
			}
			return result
		},
	})

	c.header('Cache-Control', 'public, max-age=60')
	return c.json({ success: true, data: counts })
})

function getGuestFileAccess(file: { guestAccess?: string | null }) {
	return file.guestAccess === 'blurred' || file.guestAccess === 'locked'
		? file.guestAccess
		: 'visible'
}

materialRoutes.get('/public-preview/:id', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id) || id <= 0) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const [guestSettings, item] = await Promise.all([
		loadGuestContentAccessSettings(),
		db.query.materials.findFirst({ where: and(eq(materials.id, id), eq(materials.active, true)) }),
	])
	if (!item) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}
	if (guestSettings.level !== 'preview') {
		return c.json(
			{
				success: false,
				error: {
					code: 'GUEST_ACCESS_REQUIRED',
					message:
						guestSettings.level === 'sections'
							? 'Этот раздел доступен участникам клуба'
							: 'Откройте доступ, чтобы посмотреть материал',
				},
			},
			403,
		)
	}

	const blockAccess = parseMaterialGuestAccess(item.storagePath)
	const files = parseStoredMediaFiles(item.storagePath).map((file, index) => {
		const access = getGuestFileAccess(file)
		const mediaPath = file.url ?? file.path ?? null
		return {
			index,
			name: file.displayName?.trim() || `Файл ${index + 1}`,
			type: file.type ?? item.mediaType ?? 'document',
			access,
			url: access === 'visible' ? resolvePublicFileUrl('media', mediaPath) : null,
			chapters: access !== 'locked' ? file.chapters : undefined,
		}
	})

	c.header('Cache-Control', 'public, max-age=30, stale-while-revalidate=60')
	return c.json({
		success: true,
		data: {
			material: {
				...item,
				type: normalizeMaterialTypeKey(item.type),
				imageUrl: blockAccess.cover === 'visible' ? resolveMaterialPreviewImage(item) : null,
				videoCoverUrl:
					blockAccess.cover === 'visible'
						? appendVersionToUrl(
								resolvePublicFileUrl('media', item.videoCoverUrl) ?? null,
								item.fileSizeBytes ?? item.id,
							)
						: null,
				fullDescription: blockAccess.description === 'visible' ? item.fullDescription : null,
				telegramPostUrl: blockAccess.link === 'visible' ? item.telegramPostUrl : null,
				storagePath: null,
			},
			blockAccess,
			files,
		},
	})
})

function isPublicPreviewRoute(path: string) {
	return path.startsWith('/public-preview')
}

materialRoutes.use('*', (c, next) =>
	isPublicPreviewRoute(c.req.path) ? next() : authMiddleware(c, next),
)
materialRoutes.use('*', (c, next) =>
	isPublicPreviewRoute(c.req.path) ? next() : activeSubscriptionMiddleware(c, next),
)

// Список материалов по типу
const materialsQuerySchema = paginationSchema.extend({
	cursor: cursorPaginationSchema.shape.cursor,
	limit: z.coerce.number().int().min(1).max(24).default(12),
	type: z.string().optional(),
	search: z.string().optional(),
	subsection: z.string().optional(),
	withMedia: z.enum(['1', 'true']).optional(),
	dateFrom: z.string().date().optional(),
	dateTo: z.string().date().optional(),
	sort: z.enum(['oldest', 'newest']).default('newest'),
})

function encodeCursor(params: { id: number; createdAt: Date }) {
	return Buffer.from(
		JSON.stringify({ id: params.id, createdAt: params.createdAt.toISOString() }),
	).toString('base64url')
}

function decodeCursor(cursor: string) {
	try {
		const decoded = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8')) as {
			id?: number
			createdAt?: string
		}
		if (typeof decoded.id !== 'number' || !Number.isInteger(decoded.id) || decoded.id <= 0) {
			return null
		}

		if (!decoded.createdAt) {
			return { id: decoded.id, createdAt: null }
		}

		const createdAt = new Date(decoded.createdAt)
		if (Number.isNaN(createdAt.getTime())) {
			return null
		}

		return { id: decoded.id, createdAt }
	} catch {
		return null
	}
}

function buildMaterialsListCacheKey(params: {
	accessScope: string
	page: number
	pageSize: number
	cursor: string | undefined
	limit: number
	useCursorPagination: boolean
	type: string | undefined
	search: string
	subsection: string | undefined
	withMedia: boolean
	dateFrom: string | undefined
	dateTo: string | undefined
	sort: 'oldest' | 'newest'
}) {
	return JSON.stringify({
		scope: params.accessScope,
		mode: params.useCursorPagination ? 'cursor' : 'page',
		page: params.page,
		pageSize: params.pageSize,
		cursor: params.cursor ?? null,
		limit: params.limit,
		type: params.type ?? null,
		search: params.search,
		subsection: params.subsection ?? null,
		withMedia: params.withMedia,
		dateFrom: params.dateFrom ?? null,
		dateTo: params.dateTo ?? null,
		sort: params.sort,
	})
}

function appendVersionToUrl(url: string | null, version: string | number | null | undefined) {
	if (!url || version === null || typeof version === 'undefined' || version === '') return url
	const separator = url.includes('?') ? '&' : '?'
	return `${url}${separator}v=${encodeURIComponent(String(version))}`
}

function resolveMaterialPreviewImage(item: {
	id?: number
	imageUrl: string | null
	videoCoverUrl?: string | null
	storagePath?: string | null
	mediaType: string | null
	fileSizeBytes?: number | null
}) {
	const storedPreview = findPreviewStoredMediaFile(item.storagePath, item.mediaType)
	const previewPath =
		item.imageUrl ?? item.videoCoverUrl ?? storedPreview?.path ?? storedPreview?.url ?? null
	const resolved = resolvePublicFileUrl('media', previewPath) ?? null
	return appendVersionToUrl(resolved, item.fileSizeBytes ?? item.id ?? null)
}

const materialCommentSchema = z.object({
	content: z.string().trim().min(1).max(4000),
	parentCommentId: z.number().int().positive().nullable().optional(),
})

const materialCommentUpdateSchema = z.object({
	content: z.string().trim().min(1).max(4000),
})

const materialCommentReactionSchema = z.object({
	emoji: z.string().trim().min(1).max(16),
})

const materialPlaybackProgressSchema = z.object({
	mediaFileIndex: z.number().int().min(0).max(10_000).nullable().optional(),
	positionSeconds: z
		.number()
		.min(0)
		.max(60 * 60 * 24),
	durationSeconds: z
		.number()
		.min(0)
		.max(60 * 60 * 24)
		.nullable(),
	completed: z.boolean().default(false),
})

const materialPlaybackProgressQuerySchema = z.object({
	fileIndex: z.coerce.number().int().min(0).max(10_000).optional(),
})

type MaterialCommentRecord = Awaited<ReturnType<typeof loadMaterialComments>>[number]

function normalizeCommentAuthorAvatar<T extends { author: { avatarUrl: string | null } | null }>(
	item: T,
) {
	if (!item.author) return item
	return {
		...item,
		author: {
			...item.author,
			avatarUrl: resolveAvatarUrl(item.author.avatarUrl),
		},
	}
}

async function loadMaterialComments(materialId: number) {
	const items = await db.query.materialComments.findMany({
		where: eq(materialComments.materialId, materialId),
		orderBy: [asc(materialComments.createdAt), asc(materialComments.id)],
		with: {
			author: {
				columns: {
					authUuid: true,
					fullName: true,
					username: true,
					avatarUrl: true,
					role: true,
				},
			},
			reactions: true,
		},
	})

	return items.map(normalizeCommentAuthorAvatar)
}

function buildCommentTree(items: MaterialCommentRecord[]) {
	const byId = new Map<number, MaterialCommentRecord & { replies: MaterialCommentRecord[] }>()

	for (const item of items) {
		byId.set(item.id, {
			...item,
			replies: [],
		})
	}

	const roots: Array<MaterialCommentRecord & { replies: MaterialCommentRecord[] }> = []
	for (const item of byId.values()) {
		if (item.parentCommentId) {
			const parent = byId.get(item.parentCommentId)
			if (parent) {
				parent.replies.push(item)
				continue
			}
		}
		roots.push(item)
	}

	return roots
}

function normalizeMediaFileIndex(value: number | null | undefined) {
	if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) return 0
	return value
}

function normalizePlaybackProgress(
	body: z.infer<typeof materialPlaybackProgressSchema>,
	mediaFileIndex?: number | null,
) {
	const safeDuration =
		body.durationSeconds != null && Number.isFinite(body.durationSeconds)
			? Math.max(0, Math.round(body.durationSeconds))
			: null
	const maxPosition = safeDuration != null ? Math.max(0, safeDuration) : 60 * 60 * 24
	const roundedPosition = Math.max(0, Math.min(maxPosition, Math.round(body.positionSeconds)))
	const completed =
		body.completed ||
		(safeDuration != null && safeDuration > 0 && roundedPosition >= safeDuration - 3)

	return {
		mediaFileIndex: normalizeMediaFileIndex(mediaFileIndex ?? body.mediaFileIndex),
		positionSeconds: completed ? 0 : roundedPosition,
		durationSeconds: safeDuration,
		completed,
	}
}

materialRoutes.get('/', zValidator('query', materialsQuerySchema), async (c) => {
	const {
		page,
		pageSize,
		cursor,
		limit,
		type,
		search,
		subsection,
		withMedia,
		dateFrom,
		dateTo,
		sort,
	} = c.req.valid('query')
	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	const normalizedSearch = search?.trim() ?? ''
	const useCursorPagination =
		typeof c.req.query('cursor') !== 'undefined' || typeof c.req.query('limit') !== 'undefined'

	if (type) {
		if (!hasTypeAccess({ type, userRole, contentSections, clubAccess })) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Этот раздел недоступен для вашего тарифа' },
				},
				403,
			)
		}
	}

	if (useCursorPagination && cursor && !decodeCursor(cursor)) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Некорректный курсор пагинации' },
			},
			400,
		)
	}

	const accessScope = getMaterialsAccessScope({ userRole, contentSections, clubAccess })
	const cacheKey = buildMaterialsListCacheKey({
		accessScope,
		page,
		pageSize,
		cursor,
		limit,
		useCursorPagination,
		type,
		search: normalizedSearch,
		subsection,
		withMedia: Boolean(withMedia),
		dateFrom,
		dateTo,
		sort,
	})
	const ttlSeconds = normalizedSearch ? 15 : 30

	const payload = await rememberCachedValue({
		namespace: 'materials:list',
		key: cacheKey,
		ttlSeconds,
		load: async () => {
			const conditions = [eq(materials.active, true)]

			if (withMedia) {
				conditions.push(isNotNull(materials.storagePath))
			}

			if (type) {
				const typeKeys = getMaterialTypeQueryKeys(type)
				conditions.push(
					typeKeys.length > 1 ? inArray(materials.type, typeKeys) : eq(materials.type, typeKeys[0]),
				)
			}

			if (subsection) {
				conditions.push(eq(materials.subsection, subsection))
			}

			if (dateFrom) {
				conditions.push(gte(materials.createdAt, new Date(`${dateFrom}T00:00:00.000Z`)))
			}

			if (dateTo) {
				conditions.push(lte(materials.createdAt, new Date(`${dateTo}T23:59:59.999Z`)))
			}

			if (normalizedSearch) {
				const searchCondition = or(
					ilike(materials.title, `%${normalizedSearch}%`),
					ilike(materials.shortDescription, `%${normalizedSearch}%`),
				)
				if (searchCondition) {
					conditions.push(searchCondition)
				}
			}

			if (useCursorPagination && cursor) {
				let cursorPayload = decodeCursor(cursor)
				if (cursorPayload && !cursorPayload.createdAt) {
					const cursorMaterial = await db.query.materials.findFirst({
						where: eq(materials.id, cursorPayload.id),
						columns: {
							id: true,
							createdAt: true,
						},
					})

					if (cursorMaterial) {
						cursorPayload = {
							id: cursorMaterial.id,
							createdAt: cursorMaterial.createdAt,
						}
					}
				}

				if (cursorPayload) {
					if (sort === 'oldest') {
						const paginationCondition = or(
							gt(materials.createdAt, cursorPayload.createdAt),
							and(
								eq(materials.createdAt, cursorPayload.createdAt),
								gt(materials.id, cursorPayload.id),
							),
						)
						if (paginationCondition) {
							conditions.push(paginationCondition)
						}
					} else {
						const paginationCondition = or(
							lt(materials.createdAt, cursorPayload.createdAt),
							and(
								eq(materials.createdAt, cursorPayload.createdAt),
								lt(materials.id, cursorPayload.id),
							),
						)
						if (paginationCondition) {
							conditions.push(paginationCondition)
						}
					}
				}
			}

			const items = await measureDbOperation(
				'materials.list',
				{
					userRole,
					type: type ?? null,
					subsection: subsection ?? null,
					search: normalizedSearch || null,
					dateFrom: dateFrom ?? null,
					dateTo: dateTo ?? null,
					sort,
					mode: useCursorPagination ? 'cursor' : 'page',
				},
				() =>
					db.query.materials.findMany({
						where: and(...conditions),
						orderBy:
							sort === 'oldest'
								? [asc(materials.createdAt), asc(materials.id)]
								: [desc(materials.createdAt), desc(materials.id)],
						limit: useCursorPagination ? limit + 1 : pageSize,
						offset: useCursorPagination ? 0 : (page - 1) * pageSize,
						columns: {
							id: true,
							type: true,
							title: true,
							imageUrl: true,
							videoCoverUrl: true,
							storagePath: true,
							shortDescription: true,
							fullDescription: true,
							subsection: true,
							active: true,
							mediaType: true,
							durationSeconds: true,
							fileSizeBytes: true,
							createdAt: true,
						},
					}),
			)

			const slicedItems = useCursorPagination ? items.slice(0, limit) : items
			const normalizedItems = slicedItems.map((item) => {
				const accessible = hasTypeAccess({
					type: item.type,
					userRole,
					contentSections,
					clubAccess,
				})
				return {
					...item,
					type: normalizeMaterialTypeKey(item.type),
					imageUrl: resolveMaterialPreviewImage(item),
					videoCoverUrl: appendVersionToUrl(
						resolvePublicFileUrl('media', item.videoCoverUrl) ?? null,
						item.fileSizeBytes ?? item.id,
					),
					accessible,
					accessMessage: accessible ? null : 'У вас нет доступа к разделу',
				}
			})

			if (!useCursorPagination) {
				return { items: normalizedItems, nextCursor: null as string | null }
			}

			const lastItem = normalizedItems.at(-1)
			const nextCursor =
				items.length > limit && lastItem
					? encodeCursor({ id: lastItem.id, createdAt: lastItem.createdAt })
					: null

			return { items: normalizedItems, nextCursor }
		},
	})

	c.header('Cache-Control', `private, max-age=${ttlSeconds}, stale-while-revalidate=120`)
	if (useCursorPagination) {
		return c.json({
			success: true,
			data: payload,
		})
	}

	return c.json({ success: true, data: payload.items })
})

materialRoutes.get('/stats', async (c) => {
	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	const accessScope = getMaterialsAccessScope({ userRole, contentSections, clubAccess })
	const counts = await rememberCachedValue({
		namespace: 'material-stats',
		key: accessScope,
		ttlSeconds: 60,
		load: async () => {
			const rows = await db
				.select({ type: materials.type, count: sql<number>`count(*)::int` })
				.from(materials)
				.groupBy(materials.type)
			const nextCounts: Record<string, number> = {}

			for (const row of rows) {
				const type = normalizeMaterialTypeKey(row.type)
				if (hasTypeAccess({ type, userRole, contentSections, clubAccess })) {
					nextCounts[type] = (nextCounts[type] ?? 0) + (Number(row.count) || 0)
				}
			}

			return nextCounts
		},
	})

	c.header('Cache-Control', 'private, max-age=60, stale-while-revalidate=120')
	return c.json({ success: true, data: counts })
})

materialRoutes.get('/favorites', async (c) => {
	const userId = c.get('userId')
	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	const rows = await db
		.select({
			favoritedAt: materialFavorites.createdAt,
			id: materials.id,
			type: materials.type,
			title: materials.title,
			imageUrl: materials.imageUrl,
			videoCoverUrl: materials.videoCoverUrl,
			storagePath: materials.storagePath,
			shortDescription: materials.shortDescription,
			subsection: materials.subsection,
			mediaType: materials.mediaType,
			createdAt: materials.createdAt,
		})
		.from(materialFavorites)
		.innerJoin(materials, eq(materialFavorites.materialId, materials.id))
		.where(and(eq(materialFavorites.userAuthUuid, userId), eq(materials.active, true)))
		.orderBy(desc(materialFavorites.createdAt), desc(materialFavorites.id))

	const items = rows
		.filter((item) => hasTypeAccess({ type: item.type, userRole, contentSections, clubAccess }))
		.map((item) => ({
			...item,
			type: normalizeMaterialTypeKey(item.type),
			imageUrl: resolveMaterialPreviewImage(item),
			videoCoverUrl: appendVersionToUrl(
				resolvePublicFileUrl('media', item.videoCoverUrl) ?? null,
				item.id,
			),
		}))

	return c.json({ success: true, data: items })
})

materialRoutes.get('/:id/favorite', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id) || id <= 0) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const favorite = await db.query.materialFavorites.findFirst({
		where: and(
			eq(materialFavorites.userAuthUuid, c.get('userId')),
			eq(materialFavorites.materialId, id),
		),
		columns: { id: true },
	})
	return c.json({ success: true, data: { isFavorite: Boolean(favorite) } })
})

materialRoutes.post('/:id/favorite', async (c) => {
	const id = Number(c.req.param('id'))
	const material = await db.query.materials.findFirst({
		where: and(eq(materials.id, id), eq(materials.active, true)),
		columns: { id: true, type: true },
	})
	if (!material) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}
	if (
		!hasTypeAccess({
			type: material.type,
			userRole: c.get('userRole'),
			contentSections: c.get('userContentSections'),
			clubAccess: c.get('clubAccess'),
		})
	) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
			},
			403,
		)
	}

	await db
		.insert(materialFavorites)
		.values({ userAuthUuid: c.get('userId'), materialId: id })
		.onConflictDoNothing({ target: [materialFavorites.userAuthUuid, materialFavorites.materialId] })
	return c.json({ success: true, data: { isFavorite: true } })
})

materialRoutes.delete('/:id/favorite', async (c) => {
	const id = Number(c.req.param('id'))
	if (!Number.isInteger(id) || id <= 0) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	await db
		.delete(materialFavorites)
		.where(
			and(
				eq(materialFavorites.userAuthUuid, c.get('userId')),
				eq(materialFavorites.materialId, id),
			),
		)
	return c.json({ success: true, data: { isFavorite: false } })
})

// Подразделы для типа
materialRoutes.get(
	'/subsections',
	zValidator('query', z.object({ type: z.string() })),
	async (c) => {
		const { type } = c.req.valid('query')
		const userRole = c.get('userRole')
		const contentSections = c.get('userContentSections')
		const clubAccess = c.get('clubAccess')
		if (!hasTypeAccess({ type, userRole, contentSections, clubAccess })) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Этот раздел недоступен для вашего тарифа' },
				},
				403,
			)
		}

		const subsections = await rememberCachedValue({
			namespace: 'materials:subsections',
			key: type,
			ttlSeconds: 300,
			load: async () => {
				const typeKeys = getMaterialTypeQueryKeys(type)
				const rows = await measureDbOperation('materials.subsections', { type }, () =>
					db
						.selectDistinct({ subsection: materials.subsection })
						.from(materials)
						.where(
							and(
								typeKeys.length > 1
									? inArray(materials.type, typeKeys)
									: eq(materials.type, typeKeys[0]),
								eq(materials.active, true),
							),
						)
						.orderBy(materials.subsection),
				)

				return rows.map((row) => row.subsection).filter(Boolean)
			},
		})
		c.header('Cache-Control', 'private, max-age=300, stale-while-revalidate=600')
		return c.json({ success: true, data: subsections })
	},
)

materialRoutes.get('/:id/comments', async (c) => {
	const id = Number(c.req.param('id'))
	const material = await db.query.materials.findFirst({
		where: eq(materials.id, id),
		columns: {
			id: true,
			type: true,
			commentsEnabled: true,
		},
	})

	if (!material) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
			},
			403,
		)
	}

	if (!material.commentsEnabled) {
		return c.json({ success: true, data: [] })
	}

	const items = await loadMaterialComments(id)
	return c.json({ success: true, data: buildCommentTree(items) })
})

materialRoutes.get(
	'/:id/progress',
	zValidator('query', materialPlaybackProgressQuerySchema),
	async (c) => {
		const id = Number(c.req.param('id'))
		const userId = c.get('userId')
		const query = c.req.valid('query')
		const material = await db.query.materials.findFirst({
			where: eq(materials.id, id),
			columns: {
				id: true,
				type: true,
				mediaType: true,
				storagePath: true,
			},
		})

		if (!material) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
				404,
			)
		}

		const userRole = c.get('userRole')
		const contentSections = c.get('userContentSections')
		const clubAccess = c.get('clubAccess')
		if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
				},
				403,
			)
		}

		const hasAudio =
			typeof material.storagePath === 'string' &&
			/\.(ogg|oga|mp3|m4a|aac|wav|flac|opus)\b/i.test(material.storagePath)
		const supportsProgress =
			material.mediaType === 'video' || material.mediaType === 'audio' || hasAudio

		if (!supportsProgress) {
			return c.json({
				success: true,
				data: {
					mediaFileIndex: 0,
					positionSeconds: 0,
					durationSeconds: null,
					completed: false,
					updatedAt: null,
				},
			})
		}

		const requestedFileIndex = normalizeMediaFileIndex(query.fileIndex)
		const progress = await db.query.materialMediaProgress.findFirst({
			where:
				typeof query.fileIndex === 'number'
					? and(
							eq(materialMediaProgress.materialId, id),
							eq(materialMediaProgress.userAuthUuid, userId),
							eq(materialMediaProgress.mediaFileIndex, requestedFileIndex),
						)
					: and(
							eq(materialMediaProgress.materialId, id),
							eq(materialMediaProgress.userAuthUuid, userId),
						),
			orderBy: [desc(materialMediaProgress.updatedAt), desc(materialMediaProgress.id)],
			columns: {
				mediaFileIndex: true,
				positionSeconds: true,
				durationSeconds: true,
				completed: true,
				updatedAt: true,
			},
		})

		return c.json({
			success: true,
			data: progress ?? {
				mediaFileIndex: requestedFileIndex,
				positionSeconds: 0,
				durationSeconds: null,
				completed: false,
				updatedAt: null,
			},
		})
	},
)

materialRoutes.post(
	'/:id/progress',
	zValidator('json', materialPlaybackProgressSchema),
	async (c) => {
		const id = Number(c.req.param('id'))
		const userId = c.get('userId')
		const material = await db.query.materials.findFirst({
			where: eq(materials.id, id),
			columns: {
				id: true,
				type: true,
				mediaType: true,
				storagePath: true,
			},
		})

		if (!material) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
				404,
			)
		}

		const userRole = c.get('userRole')
		const contentSections = c.get('userContentSections')
		const clubAccess = c.get('clubAccess')
		if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
				},
				403,
			)
		}

		const hasAudio =
			typeof material.storagePath === 'string' &&
			/\.(ogg|oga|mp3|m4a|aac|wav|flac|opus)\b/i.test(material.storagePath)
		const supportsProgress =
			material.mediaType === 'video' || material.mediaType === 'audio' || hasAudio

		if (!supportsProgress) {
			return c.json(
				{
					success: false,
					error: {
						code: 'BAD_REQUEST',
						message: 'Сохранение прогресса недоступно для этого материала',
					},
				},
				400,
			)
		}

		const body = c.req.valid('json')
		const normalized = normalizePlaybackProgress(body)
		const now = new Date()

		await db
			.insert(materialMediaProgress)
			.values({
				userAuthUuid: userId,
				materialId: id,
				mediaFileIndex: normalized.mediaFileIndex,
				positionSeconds: normalized.positionSeconds,
				durationSeconds: normalized.durationSeconds,
				completed: normalized.completed,
				updatedAt: now,
			})
			.onConflictDoUpdate({
				target: [
					materialMediaProgress.userAuthUuid,
					materialMediaProgress.materialId,
					materialMediaProgress.mediaFileIndex,
				],
				set: {
					mediaFileIndex: normalized.mediaFileIndex,
					positionSeconds: normalized.positionSeconds,
					durationSeconds: normalized.durationSeconds,
					completed: normalized.completed,
					updatedAt: now,
				},
			})

		return c.json({
			success: true,
			data: {
				...normalized,
				updatedAt: now,
			},
		})
	},
)

materialRoutes.post('/:id/comments', zValidator('json', materialCommentSchema), async (c) => {
	const id = Number(c.req.param('id'))
	const userId = c.get('userId')
	const body = c.req.valid('json')

	const material = await db.query.materials.findFirst({
		where: eq(materials.id, id),
		columns: {
			id: true,
			type: true,
			commentsEnabled: true,
		},
	})

	if (!material) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
			},
			403,
		)
	}

	if (!material.commentsEnabled) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Комментарии для этого материала отключены' },
			},
			403,
		)
	}

	if (body.parentCommentId) {
		const parent = await db.query.materialComments.findFirst({
			where: and(
				eq(materialComments.id, body.parentCommentId),
				eq(materialComments.materialId, material.id),
				eq(materialComments.isDeleted, false),
			),
			columns: { id: true },
		})

		if (!parent) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Комментарий для ответа не найден' },
				},
				404,
			)
		}
	}

	await db.insert(materialComments).values({
		materialId: material.id,
		userAuthUuid: userId,
		parentCommentId: body.parentCommentId ?? null,
		content: body.content,
	})

	const items = await loadMaterialComments(id)
	return c.json({ success: true, data: buildCommentTree(items) }, 201)
})

materialRoutes.patch(
	'/:id/comments/:commentId',
	zValidator('json', materialCommentUpdateSchema),
	async (c) => {
		const id = Number(c.req.param('id'))
		const commentId = Number(c.req.param('commentId'))
		const userId = c.get('userId')
		const body = c.req.valid('json')

		const material = await db.query.materials.findFirst({
			where: eq(materials.id, id),
			columns: {
				id: true,
				type: true,
				commentsEnabled: true,
			},
		})

		if (!material) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
				404,
			)
		}

		const userRole = c.get('userRole')
		const contentSections = c.get('userContentSections')
		const clubAccess = c.get('clubAccess')
		if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
				},
				403,
			)
		}

		if (!material.commentsEnabled) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Комментарии для этого материала отключены' },
				},
				403,
			)
		}

		const comment = await db.query.materialComments.findFirst({
			where: and(
				eq(materialComments.id, commentId),
				eq(materialComments.materialId, material.id),
				eq(materialComments.userAuthUuid, userId),
				eq(materialComments.isDeleted, false),
			),
			columns: { id: true },
		})

		if (!comment) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Комментарий не найден' } },
				404,
			)
		}

		await db
			.update(materialComments)
			.set({
				content: body.content,
				updatedAt: new Date(),
			})
			.where(eq(materialComments.id, commentId))

		const items = await loadMaterialComments(id)
		return c.json({ success: true, data: buildCommentTree(items) })
	},
)

materialRoutes.delete('/:id/comments/:commentId', async (c) => {
	const id = Number(c.req.param('id'))
	const commentId = Number(c.req.param('commentId'))
	const userId = c.get('userId')

	const material = await db.query.materials.findFirst({
		where: eq(materials.id, id),
		columns: {
			id: true,
			type: true,
			commentsEnabled: true,
		},
	})

	if (!material) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
			},
			403,
		)
	}

	if (!material.commentsEnabled) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Комментарии для этого материала отключены' },
			},
			403,
		)
	}

	const comment = await db.query.materialComments.findFirst({
		where: and(
			eq(materialComments.id, commentId),
			eq(materialComments.materialId, material.id),
			eq(materialComments.userAuthUuid, userId),
			eq(materialComments.isDeleted, false),
		),
		columns: { id: true },
	})

	if (!comment) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Комментарий не найден' } },
			404,
		)
	}

	await db
		.update(materialComments)
		.set({
			isDeleted: true,
			content: '',
			updatedAt: new Date(),
		})
		.where(eq(materialComments.id, commentId))

	await db.delete(materialCommentReactions).where(eq(materialCommentReactions.commentId, commentId))

	const items = await loadMaterialComments(id)
	return c.json({ success: true, data: buildCommentTree(items) })
})

materialRoutes.post(
	'/:id/comments/:commentId/reactions',
	zValidator('json', materialCommentReactionSchema),
	async (c) => {
		const id = Number(c.req.param('id'))
		const commentId = Number(c.req.param('commentId'))
		const userId = c.get('userId')
		const { emoji } = c.req.valid('json')

		const material = await db.query.materials.findFirst({
			where: eq(materials.id, id),
			columns: {
				id: true,
				type: true,
				commentsEnabled: true,
			},
		})

		if (!material) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
				404,
			)
		}

		const userRole = c.get('userRole')
		const contentSections = c.get('userContentSections')
		const clubAccess = c.get('clubAccess')
		if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
				},
				403,
			)
		}

		if (!material.commentsEnabled) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Комментарии для этого материала отключены' },
				},
				403,
			)
		}

		const comment = await db.query.materialComments.findFirst({
			where: and(
				eq(materialComments.id, commentId),
				eq(materialComments.materialId, material.id),
				eq(materialComments.isDeleted, false),
			),
			columns: { id: true },
		})

		if (!comment) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Комментарий не найден' } },
				404,
			)
		}

		const existing = await db.query.materialCommentReactions.findFirst({
			where: and(
				eq(materialCommentReactions.commentId, commentId),
				eq(materialCommentReactions.userAuthUuid, userId),
				eq(materialCommentReactions.emoji, emoji),
			),
		})

		if (existing) {
			await db.delete(materialCommentReactions).where(eq(materialCommentReactions.id, existing.id))
		} else {
			await db.insert(materialCommentReactions).values({
				commentId,
				userAuthUuid: userId,
				emoji,
			})
		}

		const items = await loadMaterialComments(id)
		return c.json({
			success: true,
			data: {
				action: existing ? 'removed' : 'added',
				items: buildCommentTree(items),
			},
		})
	},
)

// Один материал
materialRoutes.get('/:id', async (c) => {
	const id = Number(c.req.param('id'))
	const item = await measureDbOperation('materials.detail', { id }, () =>
		db.query.materials.findFirst({
			where: eq(materials.id, id),
		}),
	)
	if (!item) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	// Проверка доступа к материалам клуба
	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	if (!hasTypeAccess({ type: item.type, userRole, contentSections, clubAccess })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Этот материал недоступен для вашего тарифа' },
			},
			403,
		)
	}

	c.header('Cache-Control', 'private, max-age=60, stale-while-revalidate=300')
	return c.json({
		success: true,
		data: {
			...item,
			type: normalizeMaterialTypeKey(item.type),
			imageUrl: resolveMaterialPreviewImage(item),
			videoCoverUrl: appendVersionToUrl(
				resolvePublicFileUrl('media', item.videoCoverUrl) ?? null,
				item.fileSizeBytes ?? item.id,
			),
		},
	})
})
