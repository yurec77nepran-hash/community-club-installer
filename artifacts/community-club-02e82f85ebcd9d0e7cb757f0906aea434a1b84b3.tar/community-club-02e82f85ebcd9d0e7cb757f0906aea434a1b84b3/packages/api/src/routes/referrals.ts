import { Hono } from 'hono'
import type { AppEnv } from '../app'
import { applyReferralCode, loadMyReferralProgram } from '../lib/referrals'
import { authMiddleware } from '../middleware/auth'

export const referralRoutes = new Hono<AppEnv>()

referralRoutes.use('*', authMiddleware)

// Получить реферальную ссылку и статистику
referralRoutes.get('/my', async (c) => {
	const userId = c.get('userId')
	return c.json({ success: true, data: await loadMyReferralProgram(userId) })
})

// Привязать реферера (при регистрации/первом входе)
referralRoutes.post('/apply', async (c) => {
	const userId = c.get('userId')
	const { code } = await c.req.json<{ code: string }>()

	if (!code) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Некорректный реферальный код' },
			},
			400,
		)
	}

	await applyReferralCode({ code, userAuthUuid: userId })
	return c.json({ success: true, data: { applied: true } })
})
