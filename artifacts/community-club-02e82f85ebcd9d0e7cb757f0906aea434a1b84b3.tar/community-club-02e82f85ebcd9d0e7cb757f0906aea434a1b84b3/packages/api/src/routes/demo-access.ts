import { zValidator } from '@hono/zod-validator'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import {
	clearAuthCookies,
	generateTokens,
	publicSessionData,
	setAuthCookies,
} from '../lib/auth-session'
import { normalizeDemoAccessEmail } from '../lib/demo-access'
import { activateDemoAccess } from '../lib/demo-access-activation'
import { authMiddleware } from '../middleware/auth'
import { rateLimit } from '../middleware/rate-limit'

const demoAccessSchema = z.object({
	email: z.string().email('Неверный формат email'),
	password: z.string().min(6, 'Минимум 6 символов'),
})

export const demoAccessRoutes = new Hono<AppEnv>()
const demoAccessLimiter = rateLimit({ windowMs: 60_000, max: 5, keyPrefix: 'rl:demo-access' })

demoAccessRoutes.post(
	'/demo-access',
	demoAccessLimiter,
	zValidator('json', demoAccessSchema),
	async (c) => {
		const { password } = c.req.valid('json')
		const email = normalizeDemoAccessEmail(c.req.valid('json').email)
		const activation = await activateDemoAccess({ kind: 'guest', email, password })

		if (activation.kind === 'disabled') {
			return c.json(
				{
					success: false,
					error: { code: 'DEMO_DISABLED', message: 'Тестовый доступ сейчас выключен.' },
				},
				403,
			)
		}

		if (activation.kind === 'auth-error' || activation.kind === 'user-not-found') {
			clearAuthCookies(c)
			return c.json(
				{ success: false, error: { code: 'AUTH_ERROR', message: 'Неверный email или пароль' } },
				401,
			)
		}
		if (activation.kind === 'active-subscription') {
			return c.json(
				{
					success: false,
					error: { code: 'ACTIVE_SUBSCRIPTION', message: 'У вас уже есть активная подписка.' },
				},
				409,
			)
		}

		const { user } = activation
		const tokens = await generateTokens(user.authUuid, user.email ?? email, user.role)
		setAuthCookies(c, tokens)
		return c.json({ success: true, data: { ...publicSessionData(tokens), redirectTo: '/app' } })
	},
)

demoAccessRoutes.post('/demo-access/current', authMiddleware, demoAccessLimiter, async (c) => {
	const activation = await activateDemoAccess({ kind: 'current', userAuthUuid: c.get('userId') })

	if (activation.kind === 'disabled') {
		return c.json(
			{
				success: false,
				error: { code: 'DEMO_DISABLED', message: 'Тестовый доступ сейчас выключен.' },
			},
			403,
		)
	}
	if (activation.kind === 'active-subscription') {
		return c.json(
			{
				success: false,
				error: { code: 'ACTIVE_SUBSCRIPTION', message: 'У вас уже есть активная подписка.' },
			},
			409,
		)
	}
	if (activation.kind === 'user-not-found' || activation.kind === 'auth-error') {
		return c.json(
			{ success: false, error: { code: 'UNAUTHORIZED', message: 'Пользователь не найден' } },
			401,
		)
	}

	return c.json({ success: true, data: { redirectTo: '/app' } })
})
