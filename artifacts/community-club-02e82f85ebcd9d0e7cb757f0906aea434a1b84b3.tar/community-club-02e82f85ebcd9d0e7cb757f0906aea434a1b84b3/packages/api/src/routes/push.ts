import {
	cursorPaginationSchema,
	httpsUrlSchema,
	pushNotifications,
	pushSubscriptions,
	safeNavigationUrlSchema,
	users,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, isNull, like, lt, not, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import webPush from 'web-push'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db } from '../db/client'
import { logger } from '../lib/logger'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

// Ленивая инициализация VAPID (не падаем при отсутствии ключей)
let vapidInitialized = false
function ensureVapid() {
	if (!vapidInitialized && env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY) {
		webPush.setVapidDetails(env.VAPID_EMAIL, env.VAPID_PUBLIC_KEY, env.VAPID_PRIVATE_KEY)
		vapidInitialized = true
	}
}

export const pushRoutes = new Hono<AppEnv>()

function visibleNotificationConditions(userId: string) {
	return [
		eq(pushNotifications.userAuthUuid, userId),
		not(eq(pushNotifications.context, 'manual')),
		not(like(pushNotifications.context, 'campaign:%')),
	]
}

async function countUnreadNotifications(userId: string) {
	const [row] = await db
		.select({ count: sql<number>`count(*)::int` })
		.from(pushNotifications)
		.where(and(...visibleNotificationConditions(userId), isNull(pushNotifications.readAt)))

	return Number(row?.count ?? 0)
}

// Подписка на push (авторизованный)
const subscribeSchema = z.object({
	endpoint: httpsUrlSchema,
	keys: z.object({
		p256dh: z.string(),
		auth: z.string(),
	}),
	expirationTime: z.number().nullable().optional(),
	permission: z.string().max(32).nullable().optional(),
	userAgent: z.string().max(1000).nullable().optional(),
	platform: z.string().max(120).nullable().optional(),
	deviceLabel: z.string().max(160).nullable().optional(),
})

pushRoutes.post('/subscribe', authMiddleware, zValidator('json', subscribeSchema), async (c) => {
	ensureVapid()
	const userId = c.get('userId')
	const { endpoint, keys, expirationTime, permission, userAgent, platform, deviceLabel } =
		c.req.valid('json')
	const now = new Date()
	const expirationDate =
		typeof expirationTime === 'number' && Number.isFinite(expirationTime)
			? new Date(expirationTime)
			: null

	await db
		.insert(pushSubscriptions)
		.values({
			userAuthUuid: userId,
			endpoint,
			p256dh: keys.p256dh,
			auth: keys.auth,
			expirationTime: expirationDate,
			permission: permission ?? null,
			userAgent: userAgent ?? c.req.header('user-agent') ?? null,
			platform: platform ?? null,
			deviceLabel: deviceLabel ?? null,
			lastSeenAt: now,
			updatedAt: now,
		})
		.onConflictDoUpdate({
			target: pushSubscriptions.endpoint,
			set: {
				userAuthUuid: userId,
				p256dh: keys.p256dh,
				auth: keys.auth,
				expirationTime: expirationDate,
				permission: permission ?? null,
				userAgent: userAgent ?? c.req.header('user-agent') ?? null,
				platform: platform ?? null,
				deviceLabel: deviceLabel ?? null,
				lastSeenAt: now,
				updatedAt: now,
			},
		})

	return c.json({ success: true, data: { subscribed: true } })
})

const unsubscribeSchema = z.object({
	endpoint: httpsUrlSchema,
})

pushRoutes.post(
	'/unsubscribe',
	authMiddleware,
	zValidator('json', unsubscribeSchema),
	async (c) => {
		const userId = c.get('userId')
		const { endpoint } = c.req.valid('json')

		await db
			.delete(pushSubscriptions)
			.where(
				and(eq(pushSubscriptions.userAuthUuid, userId), eq(pushSubscriptions.endpoint, endpoint)),
			)

		return c.json({ success: true, data: { subscribed: false } })
	},
)

pushRoutes.get('/status', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const items = await db.query.pushSubscriptions.findMany({
		where: eq(pushSubscriptions.userAuthUuid, userId),
		orderBy: [desc(pushSubscriptions.lastSeenAt)],
		limit: 10,
		columns: {
			endpoint: true,
			permission: true,
			platform: true,
			deviceLabel: true,
			lastSeenAt: true,
			lastSuccessAt: true,
			lastFailureAt: true,
			failureCount: true,
		},
	})
	const unreadCount = await countUnreadNotifications(userId)

	return c.json({
		success: true,
		data: {
			subscriptions: items,
			unreadCount,
		},
	})
})

const notificationsQuerySchema = cursorPaginationSchema.extend({
	limit: cursorPaginationSchema.shape.limit.default(30),
})

pushRoutes.get(
	'/notifications',
	authMiddleware,
	zValidator('query', notificationsQuerySchema),
	async (c) => {
		const userId = c.get('userId')
		const { cursor, limit } = c.req.valid('query')
		const cursorId = cursor ? Number(cursor) : null

		const conditions = [...visibleNotificationConditions(userId)]
		if (cursorId) conditions.push(lt(pushNotifications.id, cursorId))

		const items = await db.query.pushNotifications.findMany({
			where: and(...conditions),
			orderBy: [desc(pushNotifications.id)],
			limit: limit + 1,
		})
		const hasMore = items.length > limit
		const data = hasMore ? items.slice(0, limit) : items
		const unreadCount = await countUnreadNotifications(userId)

		return c.json({
			success: true,
			data: {
				items: data,
				nextCursor: hasMore && data.length > 0 ? String(data[data.length - 1].id) : null,
				unreadCount,
			},
		})
	},
)

pushRoutes.patch('/notifications/:id/read', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const id = Number(c.req.param('id'))
	if (!Number.isFinite(id) || id <= 0) {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Некорректное уведомление' } },
			400,
		)
	}

	await db
		.update(pushNotifications)
		.set({ readAt: new Date() })
		.where(and(eq(pushNotifications.id, id), eq(pushNotifications.userAuthUuid, userId)))

	return c.json({ success: true, data: { read: true } })
})

pushRoutes.post('/notifications/read-all', authMiddleware, async (c) => {
	const userId = c.get('userId')
	const unreadCount = await countUnreadNotifications(userId)
	await db
		.update(pushNotifications)
		.set({ readAt: new Date() })
		.where(and(eq(pushNotifications.userAuthUuid, userId), isNull(pushNotifications.readAt)))

	return c.json({ success: true, data: { read: unreadCount } })
})

// Отправка push (admin)
const sendPushSchema = z.object({
	title: z.string().min(1),
	body: z.string().min(1),
	url: safeNavigationUrlSchema.optional(),
	targetRole: z.enum(['all']).default('all'),
})

pushRoutes.post(
	'/send',
	authMiddleware,
	adminMiddleware,
	zValidator('json', sendPushSchema),
	async (c) => {
		ensureVapid()
		const { title, body, url, targetRole } = c.req.valid('json')

		const targetUsers = await db.query.users.findMany({
			columns: {
				authUuid: true,
			},
		})

		void targetRole
		const { sendPushToUsers } = await import('../lib/push-notifications')
		const stats = await sendPushToUsers({
			userIds: targetUsers.map((user) => user.authUuid),
			title,
			body,
			url,
			context: 'manual',
		})

		logger.info(
			{ sent: stats.sent, failed: stats.failed, targetRole, totalCandidates: stats.targetUsers },
			'Push notifications sent',
		)
		return c.json({ success: true, data: { sent: stats.sent, failed: stats.failed } })
	},
)

// VAPID public key (для фронтенда)
pushRoutes.get('/vapid-key', (c) => {
	return c.json({ success: true, data: { key: env.VAPID_PUBLIC_KEY } })
})
