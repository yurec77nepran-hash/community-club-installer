import { events, httpUrlSchema } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, eq, gte, lt } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { measureDbOperation } from '../lib/performance'
import { invalidateCachedNamespace, rememberCachedValue } from '../lib/server-cache'
import { activeSubscriptionMiddleware, adminMiddleware, authMiddleware } from '../middleware/auth'

export const eventRoutes = new Hono<AppEnv>()

eventRoutes.use('*', authMiddleware, activeSubscriptionMiddleware)

// Список предстоящих событий
eventRoutes.get(
	'/',
	zValidator(
		'query',
		z.object({
			month: z
				.string()
				.regex(/^\d{4}-\d{2}$/)
				.optional(),
		}),
	),
	async (c) => {
		const { month } = c.req.valid('query')
		const whereClause = month
			? and(
					gte(events.eventDate, new Date(`${month}-01T00:00:00.000Z`)),
					lt(
						events.eventDate,
						new Date(
							new Date(`${month}-01T00:00:00.000Z`).getUTCFullYear(),
							new Date(`${month}-01T00:00:00.000Z`).getUTCMonth() + 1,
							1,
						),
					),
				)
			: gte(events.eventDate, new Date())

		const items = await rememberCachedValue({
			namespace: 'events:list',
			key: month ?? 'upcoming',
			ttlSeconds: 60,
			load: () =>
				measureDbOperation('events.list', { month: month ?? 'upcoming' }, () =>
					db.select().from(events).where(whereClause).orderBy(events.eventDate).limit(200),
				),
		})

		return c.json({ success: true, data: items })
	},
)

// Создать событие (admin)
const createEventSchema = z.object({
	title: z.string().min(1),
	description: z.string().optional(),
	imageUrl: httpUrlSchema.nullable().optional(),
	eventDate: z.string(),
})

eventRoutes.post('/', adminMiddleware, zValidator('json', createEventSchema), async (c) => {
	const body = c.req.valid('json')
	const [item] = await measureDbOperation('events.create', { title: body.title }, () =>
		db
			.insert(events)
			.values({ ...body, eventDate: new Date(body.eventDate) })
			.returning(),
	)
	await invalidateCachedNamespace('events:list')
	return c.json({ success: true, data: item }, 201)
})

// Обновить событие (admin)
eventRoutes.patch(
	'/:id',
	adminMiddleware,
	zValidator('json', createEventSchema.partial()),
	async (c) => {
		const id = Number(c.req.param('id'))
		const body = c.req.valid('json')
		const updateData: Record<string, unknown> = { ...body }
		if (body.eventDate) {
			updateData.eventDate = new Date(body.eventDate)
		}
		const [updated] = await measureDbOperation('events.update', { id }, () =>
			db.update(events).set(updateData).where(eq(events.id, id)).returning(),
		)

		if (!updated) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Событие не найдено' } },
				404,
			)
		}

		await invalidateCachedNamespace('events:list')
		return c.json({ success: true, data: updated })
	},
)

// Удалить событие (admin)
eventRoutes.delete('/:id', adminMiddleware, async (c) => {
	const id = Number(c.req.param('id'))
	await measureDbOperation('events.delete', { id }, () =>
		db.delete(events).where(eq(events.id, id)),
	)
	await invalidateCachedNamespace('events:list')
	return c.json({ success: true, data: { deleted: true } })
})
