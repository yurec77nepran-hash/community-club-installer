import { payments, users } from '@community-club/shared'
import { desc, eq, or } from 'drizzle-orm'
import { Hono } from 'hono'
import { nanoid } from 'nanoid'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db } from '../db/client'
import { logger } from '../lib/logger'
import { upsertMediaLibraryNote } from '../lib/media-library'
import { redis } from '../lib/redis'
import {
	loadAuthLoginSettings,
	loadRuntimeSettings,
	loadTelegramBotAuthSettings,
} from '../lib/site-settings'
import { getPublicUrl, uploadFile } from '../lib/storage'
import { findLatestPaymentForAccess } from '../lib/subscription-access'
import {
	answerTelegramCallbackQuery,
	deleteTelegramMessage,
	downloadTelegramFile,
	editTelegramMessage,
	getTelegramWebhookSecret,
	sendTelegramMessage,
} from '../lib/telegram'

export const telegramRoutes = new Hono<AppEnv>()

type PendingAudioItem = {
	key: string
	url: string
	name: string
	contentType: string
	uploadedAt: string
}

type PendingAudioState = {
	items: PendingAudioItem[]
	userAuthUuid: string
	chatId: string
	promptMessageId: number
	note: string | null
}

export type TelegramUpdate = {
	message?: TelegramMessage
	callback_query?: TelegramCallbackQuery
}

type TelegramMessage = {
	message_id: number
	chat?: { id: number | string; type?: string }
	from?: { id: number | string; is_bot?: boolean }
	voice?: {
		file_id: string
		file_unique_id?: string
		mime_type?: string
	}
	audio?: {
		file_id: string
		file_unique_id?: string
		file_name?: string
		mime_type?: string
	}
	text?: string
	caption?: string
}

type TelegramCallbackQuery = {
	id: string
	data?: string
	from?: { id: number | string; is_bot?: boolean }
	message?: { message_id: number; chat?: { id: number | string } }
}

const TELEGRAM_AUDIO_ADMIN_IDS = new Set([
	'256125761',
	'8575192555',
	'552008204',
	'504099663',
	'972766539',
	'311932325',
])

const PENDING_TTL_SECONDS = 60 * 60 * 6
const ADMIN_PANEL_URL = `${env.APP_URL.replace(/\/$/, '')}/admin/media`

function getPendingAudioRedisKey(telegramUserId: string) {
	return `telegram:audio:pending:${telegramUserId}`
}

function pluralizeFiles(count: number) {
	const lastTwo = count % 100
	const last = count % 10
	if (lastTwo >= 11 && lastTwo <= 14) return 'файлов'
	if (last === 1) return 'файл'
	if (last >= 2 && last <= 4) return 'файла'
	return 'файлов'
}

function formatFilesCount(count: number) {
	return `${count} ${pluralizeFiles(count)}`
}

function formatFinalMessage(count: number) {
	const verb = count % 10 === 1 && count % 100 !== 11 ? 'добавлен' : 'добавлено'
	return `Готово: ${formatFilesCount(count)} ${verb} в медиатеку.`
}

function formatInitialPrompt(count: number) {
	return `Принял аудио: ${formatFilesCount(count)}.
Есть ли комментарий?`
}

function formatCommentConfirmation(note: string, count: number) {
	return `Комментарий для ${formatFilesCount(count)}:
${note}

Всё верно?`
}

function buildFinalMarkup() {
	return {
		inline_keyboard: [[{ text: 'Открыть админпанель', url: ADMIN_PANEL_URL }]],
	}
}

function buildNoCommentMarkup() {
	return {
		inline_keyboard: [[{ text: 'Без комментария', callback_data: 'audio:none' }]],
	}
}

function buildConfirmMarkup() {
	return {
		inline_keyboard: [
			[{ text: 'Да', callback_data: 'audio:confirm' }],
			[{ text: 'Изменить', callback_data: 'audio:retry' }],
		],
	}
}

function inferAudioExtension(params: {
	fileName?: string | null
	mimeType?: string | null
	isVoice: boolean
}) {
	const lowerName = params.fileName?.trim().toLowerCase() ?? ''
	if (lowerName.includes('.')) {
		const extension = lowerName
			.split('.')
			.pop()
			?.replace(/[^a-z0-9]/g, '')
		if (extension) return extension
	}

	const mimeType = params.mimeType?.toLowerCase() ?? ''
	if (mimeType.includes('ogg')) return 'ogg'
	if (mimeType.includes('mpeg') || mimeType.includes('mp3')) return 'mp3'
	if (mimeType.includes('mp4') || mimeType.includes('m4a')) return 'm4a'
	if (mimeType.includes('aac')) return 'aac'
	if (mimeType.includes('wav')) return 'wav'
	if (mimeType.includes('flac')) return 'flac'
	if (mimeType.includes('opus')) return 'opus'
	return params.isVoice ? 'ogg' : 'mp3'
}

async function findAuthorizedSender(telegramUserId: string) {
	if (!TELEGRAM_AUDIO_ADMIN_IDS.has(telegramUserId)) return null

	const payment = await db.query.payments.findFirst({
		where: eq(payments.cpAccountId, telegramUserId),
		orderBy: [desc(payments.updatedAt), desc(payments.createdAt)],
		with: {
			user: {
				columns: {
					authUuid: true,
					role: true,
					fullName: true,
					email: true,
				},
			},
		},
	})

	const user = payment?.user
	if (!user) return null
	if (!['admin', 'superadmin'].includes(user.role)) return null
	return user
}

async function savePendingState(telegramUserId: string, state: PendingAudioState) {
	await redis.set(
		getPendingAudioRedisKey(telegramUserId),
		JSON.stringify(state),
		'EX',
		PENDING_TTL_SECONDS,
	)
}

function normalizePendingState(value: unknown): PendingAudioState | null {
	if (!value || typeof value !== 'object') return null
	const record = value as Partial<PendingAudioState> & Partial<PendingAudioItem>
	const userAuthUuid = typeof record.userAuthUuid === 'string' ? record.userAuthUuid : ''
	const chatId = typeof record.chatId === 'string' ? record.chatId : ''
	const promptMessageId = Number(record.promptMessageId ?? 0)
	const note = typeof record.note === 'string' ? record.note : null

	if (!userAuthUuid || !chatId || !promptMessageId) return null

	if (Array.isArray(record.items)) {
		const items = record.items.filter((item): item is PendingAudioItem => {
			if (!item || typeof item !== 'object') return false
			const candidate = item as Partial<PendingAudioItem>
			return (
				typeof candidate.key === 'string' &&
				typeof candidate.url === 'string' &&
				typeof candidate.name === 'string' &&
				typeof candidate.contentType === 'string' &&
				typeof candidate.uploadedAt === 'string'
			)
		})
		return items.length ? { items, userAuthUuid, chatId, promptMessageId, note } : null
	}

	if (
		typeof record.key === 'string' &&
		typeof record.url === 'string' &&
		typeof record.name === 'string' &&
		typeof record.contentType === 'string' &&
		typeof record.uploadedAt === 'string'
	) {
		return {
			items: [
				{
					key: record.key,
					url: record.url,
					name: record.name,
					contentType: record.contentType,
					uploadedAt: record.uploadedAt,
				},
			],
			userAuthUuid,
			chatId,
			promptMessageId,
			note,
		}
	}

	return null
}

async function loadPendingState(telegramUserId: string) {
	const raw = await redis.get(getPendingAudioRedisKey(telegramUserId))
	if (!raw) return null
	try {
		return normalizePendingState(JSON.parse(raw))
	} catch {
		return null
	}
}

async function clearPendingState(telegramUserId: string) {
	await redis.del(getPendingAudioRedisKey(telegramUserId))
}

async function finalizePendingAudio(params: {
	telegramUserId: string
	state: PendingAudioState
	note: string
}) {
	if (params.note.trim()) {
		const note = params.note.trim()
		await Promise.all(
			params.state.items.map((item) =>
				upsertMediaLibraryNote({
					key: item.key,
					title: item.name,
					note,
					userId: params.state.userAuthUuid,
				}),
			),
		)
	}

	await editTelegramMessage(
		params.state.chatId,
		params.state.promptMessageId,
		formatFinalMessage(params.state.items.length),
		{ replyMarkup: buildFinalMarkup(), botKind: 'audio' },
	)
	await clearPendingState(params.telegramUserId)
}

async function updatePendingPrompt(state: PendingAudioState) {
	const text = state.note
		? formatCommentConfirmation(state.note, state.items.length)
		: formatInitialPrompt(state.items.length)
	const replyMarkup = state.note ? buildConfirmMarkup() : buildNoCommentMarkup()

	await editTelegramMessage(state.chatId, state.promptMessageId, text, {
		replyMarkup,
		botKind: 'audio',
	})
}

async function handleAudioMessage(message: TelegramMessage) {
	const senderId = String(message.from?.id ?? '').trim()
	const chatId = String(message.chat?.id ?? '').trim()
	if (!senderId || !chatId) return

	const authorizedUser = await findAuthorizedSender(senderId)
	if (!authorizedUser) return

	const audio = message.audio
	const voice = message.voice
	if (!audio && !voice) return

	const fileId = audio?.file_id ?? voice?.file_id
	if (!fileId) return

	const isVoice = Boolean(voice && !audio)
	const mimeType = audio?.mime_type ?? voice?.mime_type ?? (isVoice ? 'audio/ogg' : 'audio/mpeg')
	const extension = inferAudioExtension({
		fileName: audio?.file_name ?? null,
		mimeType: mimeType,
		isVoice,
	})
	const date = new Date()
	const yyyy = String(date.getUTCFullYear())
	const mm = String(date.getUTCMonth() + 1).padStart(2, '0')
	const dd = String(date.getUTCDate()).padStart(2, '0')
	const objectName = `${date.getTime()}_${senderId}_${nanoid(6)}.${extension}`
	const key = `telegram-audio/${yyyy}/${mm}/${dd}/${objectName}`

	const file = await downloadTelegramFile(fileId, { botKind: 'audio' })
	await uploadFile(env.S3_BUCKET_MEDIA, key, file.buffer, mimeType)
	const item: PendingAudioItem = {
		key,
		url: getPublicUrl(env.S3_BUCKET_MEDIA, key),
		name: audio?.file_name?.trim() || objectName,
		contentType: mimeType,
		uploadedAt: date.toISOString(),
	}

	try {
		await deleteTelegramMessage(chatId, message.message_id, { botKind: 'audio' })
	} catch (error) {
		logger.warn(
			{ err: error, chatId, messageId: message.message_id },
			'Failed to delete source Telegram audio message',
		)
	}

	const existingState = await loadPendingState(senderId)
	if (existingState) {
		existingState.items.push(item)
		existingState.chatId = chatId
		existingState.userAuthUuid = authorizedUser.authUuid
		if (!existingState.note && message.caption?.trim()) {
			existingState.note = message.caption.trim()
		}
		await savePendingState(senderId, existingState)
		await updatePendingPrompt(existingState)
		return
	}

	const initialNote = message.caption?.trim() || null
	const sent = (await sendTelegramMessage(
		chatId,
		initialNote ? formatCommentConfirmation(initialNote, 1) : formatInitialPrompt(1),
		{
			replyMarkup: initialNote ? buildConfirmMarkup() : buildNoCommentMarkup(),
			botKind: 'audio',
		},
	)) as { result?: { message_id?: number } }
	const promptMessageId = Number(sent?.result?.message_id ?? 0)
	if (!promptMessageId) {
		throw new Error('Telegram prompt message id was not returned')
	}

	await savePendingState(senderId, {
		items: [item],
		userAuthUuid: authorizedUser.authUuid,
		chatId,
		promptMessageId,
		note: initialNote,
	})
}

async function handlePendingComment(message: TelegramMessage) {
	const senderId = String(message.from?.id ?? '').trim()
	const chatId = String(message.chat?.id ?? '').trim()
	const text = message.text?.trim() ?? ''
	if (!senderId || !chatId || !text) return false

	const state = await loadPendingState(senderId)
	if (!state) return false

	try {
		await deleteTelegramMessage(chatId, message.message_id, { botKind: 'audio' })
	} catch (error) {
		logger.warn(
			{ err: error, chatId, messageId: message.message_id },
			'Failed to delete Telegram comment message',
		)
	}

	state.note = text
	await savePendingState(senderId, state)
	await updatePendingPrompt(state)
	return true
}

async function handleCallback(callbackQuery: TelegramCallbackQuery) {
	const senderId = String(callbackQuery.from?.id ?? '').trim()
	const action = String(callbackQuery.data ?? '').trim()
	if (!senderId || !action.startsWith('audio:')) return

	await answerTelegramCallbackQuery(callbackQuery.id, undefined, { botKind: 'audio' })

	const state = await loadPendingState(senderId)
	if (!state) return

	if (action === 'audio:none') {
		await finalizePendingAudio({ telegramUserId: senderId, state, note: '' })
		return
	}

	if (action === 'audio:confirm') {
		await finalizePendingAudio({ telegramUserId: senderId, state, note: state.note ?? '' })
		return
	}

	if (action === 'audio:retry') {
		state.note = null
		await savePendingState(senderId, state)
		await updatePendingPrompt(state)
	}
}

export async function processTelegramUpdate(update: TelegramUpdate) {
	try {
		if (update.callback_query) {
			await handleCallback(update.callback_query)
			return
		}

		if (!update.message || update.message.from?.is_bot) {
			return
		}

		if (update.message.voice || update.message.audio) {
			await handleAudioMessage(update.message)
			return
		}

		if (update.message.text) {
			if (update.message.text.startsWith('/start')) {
				await handleBotStart(update.message)
				return
			}
			await handlePendingComment(update.message)
		}
	} catch (error) {
		logger.error({ err: error, update }, 'Failed to handle Telegram update')
	}
}

const BOT_CODE_TTL_SECONDS = 10 * 60
const BOT_CODE_CACHE_KEY = 'auth:botcode'
const BOT_CODE_USER_KEY = 'auth:botcodechat'

function generateBotLoginCode(): string {
	return String((crypto.getRandomValues(new Uint32Array(1))[0] as number) % 1_000_000).padStart(
		6,
		'0',
	)
}

function telegramMarkupUrl(urls: { label: string; url: string }[]) {
	return {
		inline_keyboard: urls.map((url) => [{ text: url.label, url: url.url }]),
	}
}

async function canStartBotLogin(user: typeof users.$inferSelect) {
	if (user.role === 'admin' || user.role === 'superadmin') return true
	return Boolean(
		await findLatestPaymentForAccess({
			userAuthUuid: user.authUuid,
			email: user.email ?? null,
			activeOnly: true,
		}),
	)
}

async function handleBotStart(message: TelegramMessage) {
	const chatId = String(message.chat?.id ?? message.from?.id ?? '')
	const senderId = String(message.from?.id ?? '')
	if (!senderId) return

	const authSettings = await loadAuthLoginSettings()
	if (!authSettings.botAuthEnabled) return
	const botSettings = await loadTelegramBotAuthSettings()

	const username = (message.from?.username ?? '').trim().toLowerCase().replace(/^@/, '')
	const startText = String(message.text ?? '').trim()

	// Глубокая привязка: /start bind_<authUuid> — ссылка из приложения.
	const bindUuid = /^\/start\s+bind_([0-9a-f-]{36})$/i.exec(startText)?.[1]
	if (bindUuid) {
		const target = await db.query.users.findFirst({
			where: eq(users.authUuid, bindUuid),
		})
		if (!target) {
			await sendTelegramMessage(chatId, botSettings.noAccessText)
			return
		}
		if (target.telegramChatId === senderId) {
			await sendTelegramMessage(chatId, 'Telegram уже подключён к вашему аккаунту ✅')
			return
		}
		await db
			.update(users)
			.set({
				telegramChatId: senderId,
				telegramUsername: username || target.telegramUsername || null,
				updatedAt: new Date(),
			})
			.where(eq(users.authUuid, target.authUuid))
		await sendTelegramMessage(chatId, 'Отлично! Ваш Telegram подключён к аккаунту ✅')
		return
	}

	const conditions = []
	if (senderId) conditions.push(eq(users.telegramChatId, senderId))
	if (username) conditions.push(eq(users.telegramUsername, username))
	const user = conditions.length
		? await db.query.users.findFirst({
				where: conditions.length === 1 ? conditions[0] : or(...conditions),
			})
		: null

	if (!user || !(await canStartBotLogin(user))) {
		const urls: { label: string; url: string }[] = []
		if (botSettings.subscriptionButtonUrl) {
			urls.push({
				label: botSettings.subscriptionButtonLabel || 'Оплатить подписку',
				url: botSettings.subscriptionButtonUrl,
			})
		}
		await sendTelegramMessage(chatId, botSettings.noAccessText, {
			...(urls.length ? { replyMarkup: telegramMarkupUrl(urls) } : {}),
		})
		return
	}

	// Пользователь подтверждён (по chat id или юзернейму) — фиксируем привязку,
	// чтобы после входа по коду приложение не требовало «Подключить Telegram».
	if (user.telegramChatId !== senderId || !user.telegramUsername) {
		await db
			.update(users)
			.set({
				telegramChatId: senderId,
				telegramUsername: username || user.telegramUsername || null,
				updatedAt: new Date(),
			})
			.where(eq(users.authUuid, user.authUuid))
	}

	const prevCode = await redis.get(`${BOT_CODE_USER_KEY}:${senderId}`)
	if (prevCode) {
		await redis.del(`${BOT_CODE_CACHE_KEY}:${prevCode}`)
	}

	let code = generateBotLoginCode()
	for (
		let attempt = 0;
		attempt < 5 && (await redis.get(`${BOT_CODE_CACHE_KEY}:${code}`));
		attempt += 1
	) {
		code = generateBotLoginCode()
	}

	await redis.set(
		`${BOT_CODE_CACHE_KEY}:${code}`,
		JSON.stringify({ userAuthUuid: user.authUuid, email: user.email, chatId: senderId }),
		'EX',
		BOT_CODE_TTL_SECONDS,
	)
	await redis.set(`${BOT_CODE_USER_KEY}:${senderId}`, code, 'EX', BOT_CODE_TTL_SECONDS)

	const text = botSettings.codeMessageText.replace('{code}', code)
	const urls: { label: string; url: string }[] = []
	if (botSettings.openAppButtonLabel && env.APP_URL) {
		urls.push({ label: botSettings.openAppButtonLabel, url: env.APP_URL })
	}
	await sendTelegramMessage(chatId, text, {
		parseMode: 'HTML',
		...(urls.length ? { replyMarkup: telegramMarkupUrl(urls) } : {}),
	})
}

telegramRoutes.post('/webhook', async (c) => {
	const secret = c.req.header('x-telegram-bot-api-secret-token')
	const runtimeSettings = await loadRuntimeSettings()
	if (
		!(runtimeSettings.telegramBotToken || env.TELEGRAM_BOT_TOKEN) ||
		secret !== getTelegramWebhookSecret()
	) {
		return c.json({ ok: true })
	}

	const update = (await c.req.json()) as TelegramUpdate
	await processTelegramUpdate(update)
	return c.json({ ok: true })
})
