import {
	channelPosts,
	channelReactions,
	createChannelPostSchema,
	cursorPaginationSchema,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { and, desc, eq, lt } from 'drizzle-orm'
import { Hono } from 'hono'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { measureDbOperation } from '../lib/performance'
import { invalidateCachedNamespace, rememberCachedValue } from '../lib/server-cache'
import { activeSubscriptionMiddleware, adminMiddleware, authMiddleware } from '../middleware/auth'

export const channelRoutes = new Hono<AppEnv>()

channelRoutes.use('*', authMiddleware, activeSubscriptionMiddleware)

// Лента постов канала
channelRoutes.get('/', zValidator('query', cursorPaginationSchema), async (c) => {
	const { cursor, limit } = c.req.valid('query')
	const cacheKey = JSON.stringify({
		cursor: cursor ?? null,
		limit,
	})

	const payload = await rememberCachedValue({
		namespace: 'channels:list',
		key: cacheKey,
		ttlSeconds: 15,
		load: async () => {
			const conditions = []
			if (cursor) {
				conditions.push(lt(channelPosts.id, Number(cursor)))
			}

			const items = await measureDbOperation(
				'channels.list',
				{ cursor: cursor ?? null, limit },
				() =>
					db.query.channelPosts.findMany({
						where: conditions.length > 0 ? and(...conditions) : undefined,
						orderBy: [desc(channelPosts.isPinned), desc(channelPosts.id)],
						limit: limit + 1,
						with: {
							reactions: true,
						},
					}),
			)

			const hasMore = items.length > limit
			const data = hasMore ? items.slice(0, -1) : items
			const nextCursor = hasMore ? String(data[data.length - 1].id) : null

			return { items: data, nextCursor }
		},
	})

	c.header('Cache-Control', 'private, max-age=15, stale-while-revalidate=60')
	return c.json({ success: true, data: payload })
})

// Создать пост (admin)
channelRoutes.post('/', adminMiddleware, zValidator('json', createChannelPostSchema), async (c) => {
	const userId = c.get('userId')
	const body = c.req.valid('json')

	const [post] = await measureDbOperation('channels.create', { userId }, () =>
		db
			.insert(channelPosts)
			.values({
				authorAuthUuid: userId,
				content: body.content,
				attachments: body.attachments ?? [],
			})
			.returning(),
	)
	await invalidateCachedNamespace('channels:list')

	return c.json({ success: true, data: post }, 201)
})

// Реакция на пост
channelRoutes.post('/:postId/reactions', async (c) => {
	const postId = Number(c.req.param('postId'))
	const userId = c.get('userId')
	const { emoji } = await c.req.json<{ emoji: string }>()

	const existing = await db.query.channelReactions.findFirst({
		where: and(
			eq(channelReactions.postId, postId),
			eq(channelReactions.userAuthUuid, userId),
			eq(channelReactions.emoji, emoji),
		),
	})

	if (existing) {
		await db.delete(channelReactions).where(eq(channelReactions.id, existing.id))
		await invalidateCachedNamespace('channels:list')
		return c.json({ success: true, data: { action: 'removed' } })
	}

	await db.insert(channelReactions).values({
		postId,
		userAuthUuid: userId,
		emoji,
	})
	await invalidateCachedNamespace('channels:list')

	return c.json({ success: true, data: { action: 'added' } }, 201)
})

// Закрепить/открепить пост (admin)
channelRoutes.patch('/:postId/pin', adminMiddleware, async (c) => {
	const postId = Number(c.req.param('postId'))

	const post = await db.query.channelPosts.findFirst({
		where: eq(channelPosts.id, postId),
	})
	if (!post) {
		return c.json({ success: false, error: { code: 'NOT_FOUND', message: 'Пост не найден' } }, 404)
	}

	const [updated] = await db
		.update(channelPosts)
		.set({ isPinned: !post.isPinned })
		.where(eq(channelPosts.id, postId))
		.returning()
	await invalidateCachedNamespace('channels:list')

	return c.json({ success: true, data: updated })
})

// Удалить пост (admin)
channelRoutes.delete('/:postId', adminMiddleware, async (c) => {
	const postId = Number(c.req.param('postId'))

	await db.delete(channelPosts).where(eq(channelPosts.id, postId))
	await invalidateCachedNamespace('channels:list')

	return c.json({ success: true, data: { deleted: true } })
})
