import { describe, expect, test } from 'bun:test'
import { createMiddleware } from 'hono/factory'
import type { AppEnv } from '../app'
import type { PwaLaunchHistoryStore } from '../lib/pwa-launch-history'
import { createPwaRoutes } from './pwa-routes'

const userAuthUuid = '11111111-1111-4111-8111-111111111111'
const firstLaunchedAt = new Date('2026-09-09T10:00:00.000Z')
const lastLaunchedAt = new Date('2026-09-09T11:00:00.000Z')

const authenticate = createMiddleware<AppEnv>(async (context, next) => {
	context.set('userId', userAuthUuid)
	await next()
})

const rejectAuthentication = createMiddleware<AppEnv>(async (context) =>
	context.json(
		{ success: false, error: { code: 'UNAUTHORIZED', message: 'Нужна авторизация' } },
		401,
	),
)

function createTestRoutes(store: PwaLaunchHistoryStore) {
	return createPwaRoutes({ authenticate, store })
}

describe('PWA routes', () => {
	test('GET /status requires authentication before reading PostgreSQL', async () => {
		// Given
		let readCalls = 0
		const store: PwaLaunchHistoryStore = {
			findByUser: async () => {
				readCalls += 1
				return null
			},
			recordLaunch: async () => {
				throw new Error('recordLaunch must not be called')
			},
		}
		const routes = createPwaRoutes({ authenticate: rejectAuthentication, store })

		// When
		const response = await routes.request('/status')

		// Then
		expect(response.status).toBe(401)
		expect(readCalls).toBe(0)
		expect(await response.json()).toEqual({
			success: false,
			error: { code: 'UNAUTHORIZED', message: 'Нужна авторизация' },
		})
	})

	test('GET /status returns a stable empty status when no launch was recorded', async () => {
		// Given
		const store: PwaLaunchHistoryStore = {
			findByUser: async () => null,
			recordLaunch: async () => {
				throw new Error('recordLaunch must not be called')
			},
		}
		const routes = createTestRoutes(store)

		// When
		const response = await routes.request('/status')

		// Then
		expect(response.status).toBe(200)
		expect(await response.json()).toEqual({
			success: true,
			data: {
				hasStandaloneLaunch: false,
				firstLaunchedAt: null,
				lastLaunchedAt: null,
				launchCount: 0,
				userAgent: null,
				platform: null,
				deviceLabel: null,
			},
		})
	})

	test('POST /launch records the authenticated user and bounded metadata', async () => {
		// Given
		let recordedUserAuthUuid = ''
		let recordedPlatform = ''
		const store: PwaLaunchHistoryStore = {
			findByUser: async () => null,
			recordLaunch: async (input) => {
				recordedUserAuthUuid = input.userAuthUuid
				recordedPlatform = input.metadata.platform ?? ''
				return {
					firstLaunchedAt,
					lastLaunchedAt,
					launchCount: 1,
					userAgent: input.metadata.userAgent ?? null,
					platform: input.metadata.platform ?? null,
					deviceLabel: input.metadata.deviceLabel ?? null,
				}
			},
		}
		const routes = createTestRoutes(store)

		// When
		const response = await routes.request('/launch', {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({
				userAgent: 'Community Club PWA',
				platform: 'Android',
				deviceLabel: 'Phone',
			}),
		})

		// Then
		expect(response.status).toBe(200)
		expect(recordedUserAuthUuid).toBe(userAuthUuid)
		expect(recordedPlatform).toBe('Android')
		expect(await response.json()).toEqual({
			success: true,
			data: {
				hasStandaloneLaunch: true,
				firstLaunchedAt: firstLaunchedAt.toISOString(),
				lastLaunchedAt: lastLaunchedAt.toISOString(),
				launchCount: 1,
				userAgent: 'Community Club PWA',
				platform: 'Android',
				deviceLabel: 'Phone',
			},
		})
	})

	test('POST /launch rejects client-owned history fields', async () => {
		// Given
		let recordCalls = 0
		const store: PwaLaunchHistoryStore = {
			findByUser: async () => null,
			recordLaunch: async () => {
				recordCalls += 1
				throw new Error('invalid payload must not reach the store')
			},
		}
		const routes = createTestRoutes(store)

		// When
		const response = await routes.request('/launch', {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({ launchCount: 100 }),
		})

		// Then
		expect(response.status).toBe(400)
		expect(recordCalls).toBe(0)
		expect(await response.json()).toMatchObject({
			success: false,
			error: { code: 'VALIDATION_ERROR' },
		})
	})
})
