import {
	type AdminChatItem,
	type Payment,
	type User,
	adminActivityLogs,
	adminChatInputSchema,
	bonusTransactions,
	channelPosts,
	channelReactions,
	chatMembers,
	chatNotificationSettings,
	chats,
	clubMissions,
	cursorPaginationSchema,
	feedPostDrafts,
	feedPostReactions,
	feedPosts,
	httpUrlSchema,
	materialCommentReactions,
	materialComments,
	materialMediaProgress,
	materialSubsections,
	materialTypes,
	materials,
	mediaLibraryFolders,
	mediaLibraryNotes,
	messageMentions,
	messageReactions,
	messages,
	paginationSchema,
	paymentLogs,
	payments,
	pushCampaigns,
	pushNotifications,
	pushSubscriptions,
	referrals,
	scheduledChatMessages,
	tariffs,
	users,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { type SQL, and, desc, eq, ilike, inArray, ne, or, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db, queryClient } from '../db/client'
import { appendAdminActivityLog, buildChangedFields } from '../lib/admin-activity'
import { invalidateHomeContentCaches, invalidateUserAccessCaches } from '../lib/cache-invalidation'
import { clearChatAccessCaches, getSupportChatSlug } from '../lib/chat-access'
import { normalizeChatSettings } from '../lib/chat-settings'
import { DEMO_ACCESS_TARIFF } from '../lib/demo-access'
import { provisionCustomDomain } from '../lib/domain-provisioning'
import {
	buildFeedPushPayload as buildFeedPushNotification,
	loadFeedAudienceTargetUserIds,
	loadFeedPage,
} from '../lib/feed'
import { homeExperienceSettingsSchema } from '../lib/home-experience-settings-schema'
import { logger } from '../lib/logger'
import {
	DEFAULT_MATERIAL_TYPE_ENTRIES,
	buildMaterialTypeKey,
	getDefaultMaterialTypeLabel,
	normalizeMaterialTypeKey,
} from '../lib/material-types'
import {
	clearMediaLibraryFolderPreference,
	clearMediaLibraryItem,
	createMediaLibraryFolder,
	deleteMediaLibraryFolder,
	findAdminMediaLibraryItemByKey,
	findMediaLibraryFolderById,
	isMediaLibraryStorageUnavailableError,
	loadAdminMediaLibraryPage,
	loadMediaLibraryFolders,
	loadMediaLibraryPreferences,
	mediaLibraryFolderExists,
	moveMediaLibraryItem,
	saveMediaLibraryPreferences,
	upsertMediaLibraryNote,
} from '../lib/media-library'
import { loadPaymentProviderSettings, savePaymentProviderSettings } from '../lib/payment-settings'
import { optimizeStoredPdfObject } from '../lib/pdf'
import { sendPushToUsers } from '../lib/push-notifications'
import { redis } from '../lib/redis'
import { deleteRedisKeysByPattern } from '../lib/redis-keyscan'
import { loadReferralAnalytics, loadReferralDetails } from '../lib/referrals'
import {
	checkCustomDomainStatus,
	loadAdminRuntimeSettings,
	loadAppNavigationSettings,
	loadAuthLoginSettings,
	loadGuestContentAccessSettings,
	loadHomeExperienceSettings,
	loadLegalDocumentsSettings,
	loadReferralProgramSettings,
	loadSiteBrandingSettings,
	loadTelegramBotAuthSettings,
	loadTestAccessSettings,
	normalizeAppNavigationSettingsPayload,
	normalizeAuthLoginSettingsPayload,
	normalizeGuestContentAccessSettingsPayload,
	normalizeHomeExperienceSettingsPayload,
	normalizeLegalDocumentsSettingsPayload,
	normalizeReferralProgramSettingsPayload,
	normalizeSiteBrandingSettingsPayload,
	normalizeTelegramBotAuthSettingsPayload,
	normalizeTestAccessSettingsPayload,
	saveAppNavigationSettings,
	saveAuthLoginSettings,
	saveGuestContentAccessSettings,
	saveHomeExperienceSettings,
	saveLegalDocumentsSettings,
	saveReferralProgramSettings,
	saveRuntimeSettings,
	saveSiteBrandingSettings,
	saveTelegramBotAuthSettings,
	saveTestAccessSettings,
} from '../lib/site-settings'
import {
	deleteFile,
	parseStoredMediaFiles,
	resolveAvatarUrl,
	resolvePublicFileUrl,
} from '../lib/storage'
import { adminMiddleware, authMiddleware } from '../middleware/auth'
import { rateLimit } from '../middleware/rate-limit'
import {
	cancelRecurrent,
	findCloudPaymentByInvoiceId,
	findCloudSubscriptionsByAccountId,
	getCloudSubscription,
	hasCloudPaymentsCredentials,
} from '../services/payment.service'
import { adminStatsRoutes } from './admin-stats'
import { adminTariffRoutes } from './admin-tariffs'
import { adminUserTelegramRoutes } from './admin-user-telegram'

export const adminRoutes = new Hono<AppEnv>()

adminRoutes.use('*', authMiddleware)
adminRoutes.use('*', adminMiddleware)

const adminPermissionKeys = [
	'analytics',
	'users',
	'userActions',
	'support',
	'events',
	'materials',
	'media',
	'chats',
	'payments',
	'referrals',
	'settings',
	'staffActions',
	'feed',
	'replies',
	'tariffs',
	'notifications',
	'telegramBroadcasts',
	'documents',
] as const

adminRoutes.route('/tariffs', adminTariffRoutes)
adminRoutes.route('/stats', adminStatsRoutes)
adminRoutes.route('/users', adminUserTelegramRoutes)

const adminExternalCheckLimiter = rateLimit({
	windowMs: 60_000,
	max: 30,
	keyPrefix: 'rl:admin:external-check',
})

function normalizeAdminChat(row: {
	id: number
	slug: string
	name: string
	type: 'chat' | 'channel'
	accessRole: 'all'
	isEnabled: boolean
	avatarUrl: string | null
	description: string | null
	settings: unknown
	createdAt: Date
	updatedAt: Date
	membersCount: number
	messagesCount: number
}): AdminChatItem {
	return {
		...row,
		avatarUrl: resolveAvatarUrl(row.avatarUrl),
		settings: normalizeChatSettings(row.settings),
	}
}

async function loadAdminChats() {
	const rows = await db
		.select({
			id: chats.id,
			slug: chats.slug,
			name: chats.name,
			type: chats.type,
			accessRole: chats.accessRole,
			isEnabled: chats.isEnabled,
			avatarUrl: chats.avatarUrl,
			description: chats.description,
			settings: chats.settings,
			createdAt: chats.createdAt,
			updatedAt: chats.updatedAt,
			membersCount: sql<number>`(
				SELECT COUNT(*)::int
				FROM ${chatMembers}
				WHERE ${chatMembers.chatId} = ${chats.id}
			)`,
			messagesCount: sql<number>`(
				SELECT COUNT(*)::int
				FROM ${messages}
				WHERE ${messages.chatId} = ${chats.id}
					AND ${messages.isDeleted} = false
			)`,
		})
		.from(chats)
		.where(sql`${chats.slug} NOT LIKE 'support:%'`)
		.orderBy(chats.id)

	return rows.map(normalizeAdminChat)
}

async function loadAdminChatById(chatId: number) {
	const rows = await db
		.select({
			id: chats.id,
			slug: chats.slug,
			name: chats.name,
			type: chats.type,
			accessRole: chats.accessRole,
			isEnabled: chats.isEnabled,
			avatarUrl: chats.avatarUrl,
			description: chats.description,
			settings: chats.settings,
			createdAt: chats.createdAt,
			updatedAt: chats.updatedAt,
			membersCount: sql<number>`(
				SELECT COUNT(*)::int
				FROM ${chatMembers}
				WHERE ${chatMembers.chatId} = ${chats.id}
			)`,
			messagesCount: sql<number>`(
				SELECT COUNT(*)::int
				FROM ${messages}
				WHERE ${messages.chatId} = ${chats.id}
					AND ${messages.isDeleted} = false
			)`,
		})
		.from(chats)
		.where(and(eq(chats.id, chatId), sql`${chats.slug} NOT LIKE 'support:%'`))
		.limit(1)

	return rows[0] ? normalizeAdminChat(rows[0]) : null
}

adminRoutes.get('/chats', async (c) => {
	const items = await loadAdminChats()
	return c.json({ success: true, data: items })
})

adminRoutes.post('/chats', zValidator('json', adminChatInputSchema), async (c) => {
	const body = c.req.valid('json')
	const existing = await db.query.chats.findFirst({
		where: eq(chats.slug, body.slug),
		columns: { id: true },
	})
	if (existing) {
		return c.json(
			{ success: false, error: { code: 'CONFLICT', message: 'Чат с таким адресом уже есть' } },
			409,
		)
	}

	const [created] = await db
		.insert(chats)
		.values({
			slug: body.slug,
			name: body.name,
			type: body.type,
			accessRole: body.accessRole,
			isEnabled: body.isEnabled,
			avatarUrl: body.avatarUrl?.trim() || null,
			description: body.description?.trim() || null,
			settings: normalizeChatSettings(body.settings),
			updatedAt: new Date(),
		})
		.returning({ id: chats.id })

	clearChatAccessCaches(created.id)
	const item = await loadAdminChatById(created.id)
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'chat.create',
		entityType: 'chat',
		entityId: created.id,
		summary: `Создан чат «${body.name}»`,
		details: { changed: buildChangedFields(null, item ?? {}) },
	})

	return c.json({ success: true, data: item }, 201)
})

adminRoutes.patch('/chats/:id', zValidator('json', adminChatInputSchema), async (c) => {
	const id = Number(c.req.param('id'))
	const body = c.req.valid('json')

	const before = await loadAdminChatById(id)
	if (!before) {
		return c.json({ success: false, error: { code: 'NOT_FOUND', message: 'Чат не найден' } }, 404)
	}

	const slugOwner = await db.query.chats.findFirst({
		where: and(eq(chats.slug, body.slug), ne(chats.id, id)),
		columns: { id: true },
	})
	if (slugOwner) {
		return c.json(
			{ success: false, error: { code: 'CONFLICT', message: 'Чат с таким адресом уже есть' } },
			409,
		)
	}

	await db
		.update(chats)
		.set({
			slug: body.slug,
			name: body.name,
			type: body.type,
			accessRole: body.accessRole,
			isEnabled: body.isEnabled,
			avatarUrl: body.avatarUrl?.trim() || null,
			description: body.description?.trim() || null,
			settings: normalizeChatSettings(body.settings),
			updatedAt: new Date(),
		})
		.where(eq(chats.id, id))

	clearChatAccessCaches(id)
	const updated = await loadAdminChatById(id)
	await appendAdminActivityLog({
		actorAuthUuid: c.get('userId'),
		action: 'chat.update',
		entityType: 'chat',
		entityId: id,
		summary: `Обновлён чат «${body.name}»`,
		details: { changed: buildChangedFields(before, updated ?? {}) },
	})

	return c.json({ success: true, data: updated })
})

const feedMediaSchema = z.object({
	type: z.enum(['image', 'video']),
	path: z.string().min(1),
	url: httpUrlSchema.nullable().optional(),
	name: z.string().nullable().optional(),
	size: z.number().int().nullable().optional(),
	width: z.number().int().nullable().optional(),
	height: z.number().int().nullable().optional(),
	durationSeconds: z.number().int().nullable().optional(),
})

const adminCreateFeedPostSchema = z
	.object({
		audience: z.literal('club'),
		content: z.string().trim().min(1).max(20000),
		buttonLabel: z.string().trim().max(80).nullable().optional(),
		buttonUrl: httpUrlSchema.nullable().optional(),
		notifyAll: z.boolean().default(false),
		media: z.array(feedMediaSchema).max(10).default([]),
	})
	.superRefine((value, ctx) => {
		if ((value.buttonLabel && !value.buttonUrl) || (!value.buttonLabel && value.buttonUrl)) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				message: 'Кнопка должна содержать и подпись, и ссылку',
				path: ['buttonLabel'],
			})
		}
	})

const adminFeedDraftSchema = z
	.object({
		audience: z.literal('club'),
		content: z.string().trim().max(20000).default(''),
		buttonLabel: z.string().trim().max(80).nullable().optional(),
		buttonUrl: httpUrlSchema.nullable().optional(),
		notifyAll: z.boolean().default(false),
		media: z.array(feedMediaSchema).max(10).default([]),
	})
	.superRefine((value, ctx) => {
		if ((value.buttonLabel && !value.buttonUrl) || (!value.buttonLabel && value.buttonUrl)) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				message: 'Кнопка должна содержать и подпись, и ссылку',
				path: ['buttonLabel'],
			})
		}
	})

adminRoutes.get(
	'/feed-drafts',
	zValidator(
		'query',
		z.object({
			audience: z.literal('club'),
		}),
	),
	async (c) => {
		const userId = c.get('userId')
		const { audience } = c.req.valid('query')

		const items = await db.query.feedPostDrafts.findMany({
			where: and(eq(feedPostDrafts.authorAuthUuid, userId), eq(feedPostDrafts.audience, audience)),
			orderBy: [desc(feedPostDrafts.updatedAt), desc(feedPostDrafts.id)],
		})

		return c.json({ success: true, data: items })
	},
)

adminRoutes.get('/feed-drafts/:id', async (c) => {
	const userId = c.get('userId')
	const id = Number(c.req.param('id'))

	const draft = await db.query.feedPostDrafts.findFirst({
		where: and(eq(feedPostDrafts.authorAuthUuid, userId), eq(feedPostDrafts.id, id)),
	})

	if (!draft) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Черновик не найден' } },
			404,
		)
	}

	return c.json({ success: true, data: draft })
})

adminRoutes.post('/feed-drafts', zValidator('json', adminFeedDraftSchema), async (c) => {
	const userId = c.get('userId')
	const body = c.req.valid('json')

	const [created] = await db
		.insert(feedPostDrafts)
		.values({
			authorAuthUuid: userId,
			audience: body.audience,
			content: body.content,
			buttonLabel: body.buttonLabel ?? null,
			buttonUrl: body.buttonUrl ?? null,
			notifyAll: body.notifyAll,
			media: body.media,
		})
		.returning()

	return c.json({ success: true, data: created }, 201)
})

adminRoutes.patch('/feed-drafts/:id', zValidator('json', adminFeedDraftSchema), async (c) => {
	const userId = c.get('userId')
	const id = Number(c.req.param('id'))
	const body = c.req.valid('json')

	const existing = await db.query.feedPostDrafts.findFirst({
		where: and(eq(feedPostDrafts.authorAuthUuid, userId), eq(feedPostDrafts.id, id)),
		columns: { id: true },
	})

	if (!existing) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Черновик не найден' } },
			404,
		)
	}

	const [updated] = await db
		.update(feedPostDrafts)
		.set({
			audience: body.audience,
			content: body.content,
			buttonLabel: body.buttonLabel ?? null,
			buttonUrl: body.buttonUrl ?? null,
			notifyAll: body.notifyAll,
			media: body.media,
			updatedAt: new Date(),
		})
		.where(eq(feedPostDrafts.id, id))
		.returning()

	return c.json({ success: true, data: updated })
})

adminRoutes.delete('/feed-drafts/:id', async (c) => {
	const userId = c.get('userId')
	const id = Number(c.req.param('id'))

	await db
		.delete(feedPostDrafts)
		.where(and(eq(feedPostDrafts.authorAuthUuid, userId), eq(feedPostDrafts.id, id)))

	return c.json({ success: true, data: { deleted: true } })
})

adminRoutes.get(
	'/feed-posts',
	zValidator(
		'query',
		cursorPaginationSchema.extend({
			audience: z
				.literal('club')
				.optional()
				.transform(() => 'club' as const),
		}),
	),
	async (c) => {
		const { cursor, limit, audience } = c.req.valid('query')
		const currentUserId = c.get('userId')
		const data = await loadFeedPage({
			audience: audience ?? 'club',
			cursor,
			limit,
			currentUserId,
		})

		return c.json({ success: true, data })
	},
)

adminRoutes.post('/feed-posts', zValidator('json', adminCreateFeedPostSchema), async (c) => {
	const userId = c.get('userId')
	const body = c.req.valid('json')

	const [created] = await db
		.insert(feedPosts)
		.values({
			authorAuthUuid: userId,
			audience: body.audience,
			content: body.content,
			buttonLabel: body.buttonLabel ?? null,
			buttonUrl: body.buttonUrl ?? null,
			notifyAll: body.notifyAll,
			media: body.media,
		})
		.returning({
			id: feedPosts.id,
		})

	if (body.notifyAll) {
		const userIds = await loadFeedAudienceTargetUserIds(body.audience)
		const notification = buildFeedPushNotification({
			audience: body.audience,
			content: body.content,
		})
		await sendPushToUsers({
			userIds,
			title: notification.title,
			body: notification.body,
			url: notification.url,
			context: `feed:${created.id}`,
		})
	}

	const item = await loadFeedPage({
		audience: body.audience,
		limit: 1,
		currentUserId: userId,
	})

	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'create',
		entityType: 'feed_post',
		entityId: created.id,
		summary: 'Создан новый пост в ленте',
		details: {
			audience: body.audience,
			content: body.content.slice(0, 300),
			notifyAll: body.notifyAll,
		},
	})

	return c.json({ success: true, data: item.items[0] ?? null }, 201)
})

const adminSiteBrandingSettingsSchema = z.object({
	clubName: z.string().trim().max(80),
	homeLogoEnabled: z.boolean(),
	homeLogoMediaKey: z.string().max(1024).nullable(),
	buttonBackgroundColor: z.string().max(32),
	appBackgroundColor: z.string().max(32),
	appSurfaceColor: z.string().max(32),
	appTextColor: z.string().max(32),
	appAccentColor: z.string().max(32),
})

const appHeaderBlockSchema = z.enum(['logo', 'avatar', 'name', 'notifications'])
const appMenuIconSchema = z.enum([
	'home',
	'feed',
	'calendar',
	'cube',
	'book',
	'wrench',
	'user',
	'bell',
	'support',
	'info',
	'chats',
	'materials',
	'spark',
	'play',
	'check',
	'video',
])

const appMenuItemSchema = z.object({
	id: z.string().max(64),
	label: z.string().trim().max(30),
	icon: appMenuIconSchema,
	path: z.string().max(160),
	requiresAuth: z.boolean(),
	requiresAccess: z.boolean(),
})

const appMenuCenterButtonSchema = z.object({
	enabled: z.boolean(),
	icon: appMenuIconSchema,
	imageKey: z.string().max(1024).nullable(),
	imageUrl: z.string().nullable().optional().default(null),
	glowEnabled: z.boolean(),
	pressEffectEnabled: z.boolean(),
	actionPath: z.string().max(160),
	requiresAuth: z.boolean(),
})

const appNavigationSettingsSchema = z.object({
	header: z.object({
		enabled: z.boolean(),
		showOnAllPages: z.boolean(),
		order: z.array(appHeaderBlockSchema).max(4),
		logoMode: z.enum(['image', 'text']).default('image'),
		nameMode: z.enum(['user', 'club']).default('user'),
	}),
	menu: z.object({
		items: z.array(appMenuItemSchema).min(1).max(8),
		centerButton: appMenuCenterButtonSchema,
		backgroundColor: z.string().max(32),
		borderColor: z.string().max(32).nullable(),
		borderRadius: z.number().min(0).max(40),
		marginBottom: z.number().min(0).max(40),
		marginSide: z.number().min(0).max(32),
		iconStrokeColor: z.string().max(32).nullable(),
		iconGlowEnabled: z.boolean(),
		iconHighlightEnabled: z.boolean(),
		activeIconColor: z.string().max(32),
		inactiveIconColor: z.string().max(32),
		startActivePath: z.string().max(160),
	}),
})

const adminAuthLoginSettingsSchema = z.object({
	passwordEnabled: z.boolean(),
	telegramCodeEnabled: z.boolean(),
	maxCodeEnabled: z.boolean(),
	defaultMethod: z.enum(['password', 'telegram', 'max']),
	botAuthEnabled: z.boolean().optional().default(false),
})

const adminTelegramBotAuthSettingsSchema = z.object({
	botHandle: z.string().max(64).default(''),
	noAccessText: z.string().max(2000).default(''),
	codeMessageText: z.string().max(2000).default(''),
	subscriptionButtonLabel: z.string().max(120).default(''),
	subscriptionButtonUrl: z.string().max(2048).default(''),
	openAppButtonLabel: z.string().max(120).default(''),
	ownerHandle: z.string().max(64).default(''),
})

const adminTestAccessSettingsSchema = z.object({
	enabled: z.boolean(),
	days: z.coerce.number().int().min(1).max(365),
})

const adminGuestContentAccessSettingsSchema = z.object({
	level: z.enum(['sections', 'cards', 'preview']),
})

const adminReferralProgramSettingsSchema = z.object({
	enabled: z.boolean(),
	description: z.string().trim().max(500),
})

const referralAnalyticsQuerySchema = z.object({
	from: z.string().date().optional(),
	to: z.string().date().optional(),
})

const legalDocumentSchema = z.object({
	key: z.enum(['privacy', 'personalData', 'oferta', 'requisites', 'cookie']),
	title: z.string().trim().max(160),
	linkLabel: z.string().trim().max(120),
	noticeText: z.string().trim().max(500).optional(),
	enabled: z.boolean(),
	body: z.string().trim().max(50_000),
})

const adminLegalDocumentsSettingsSchema = z.object({
	documents: z.array(legalDocumentSchema).max(10),
})

const adminRuntimeSettingsSchema = z.object({
	customDomain: z.string().max(253).nullable(),
	telegramBotToken: z.string().max(4096).nullable().optional(),
	maxBotToken: z.string().max(4096).nullable().optional(),
	maxApiUrl: z.string().max(2048),
})

const customDomainCheckSchema = z.object({
	customDomain: z.string().max(253).nullable(),
})

const paymentProviderSchema = z.object({
	provider: z.enum(['cloudpayments', 'prodamus', 'yookassa', 'tochka']),
	enabled: z.boolean(),
	fields: z.record(z.string(), z.union([z.string(), z.boolean(), z.null()])),
	secretFields: z.record(z.string(), z.string().nullable().optional()).optional(),
})

const paymentCheckoutSettingsSchema = z.object({
	foreignCardsEnabled: z.boolean(),
	billingMode: z.enum(['recurrent', 'one_time']),
	recurrentInterval: z.enum(['tariff', 'Day', 'Week', 'Month']).default('tariff'),
	recurrentPeriod: z.coerce.number().int().min(1).max(365).default(1),
	recurrentMaxPeriods: z.coerce.number().int().min(1).max(120).nullable().default(null),
	recurrentStartDelayDays: z.coerce.number().int().min(1).max(3650).nullable().default(null),
	requisitesEnabled: z.boolean(),
	requisitesName: z.string().trim().max(255),
	requisitesTaxId: z.string().trim().max(255),
	requisitesRegistrationId: z.string().trim().max(255),
	requisitesAddress: z.string().trim().max(500),
})

const adminPaymentProviderSettingsSchema = z.object({
	activeProvider: z.enum(['cloudpayments', 'prodamus', 'yookassa', 'tochka']),
	checkout: paymentCheckoutSettingsSchema.optional(),
	providers: z.array(paymentProviderSchema),
	manualPaymentEnabled: z.boolean().optional().default(false),
})

adminRoutes.get('/branding', async (c) => {
	return c.json({ success: true, data: await loadSiteBrandingSettings() })
})

adminRoutes.put('/branding', zValidator('json', adminSiteBrandingSettingsSchema), async (c) => {
	const userId = c.get('userId')
	const before = await loadSiteBrandingSettings()
	const body = normalizeSiteBrandingSettingsPayload(c.req.valid('json'))

	if (body.homeLogoMediaKey) {
		const selectedLogo = await findAdminMediaLibraryItemByKey(body.homeLogoMediaKey)
		if (!selectedLogo) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Файл не найден' },
				},
				404,
			)
		}
		if (selectedLogo.type !== 'image') {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Выберите изображение' },
				},
				400,
			)
		}
	}

	const saved = await saveSiteBrandingSettings(body)
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'update',
		entityType: 'site_branding',
		entityId: 'home',
		summary: 'Обновлены настройки бренда',
		details: {
			changed: buildChangedFields(before, saved),
		},
	})

	return c.json({ success: true, data: saved })
})

adminRoutes.get('/home-experience', async (c) => {
	return c.json({ success: true, data: await loadHomeExperienceSettings() })
})

adminRoutes.put('/home-experience', zValidator('json', homeExperienceSettingsSchema), async (c) => {
	const userId = c.get('userId')
	const before = await loadHomeExperienceSettings()
	const body = normalizeHomeExperienceSettingsPayload(c.req.valid('json'))
	const imageMediaKeys = Array.from(
		new Set(
			[
				body.mainBanner.mediaKey,
				...body.banners.map((item) => item.mediaKey),
				...body.stories.map((item) => item.mediaKey),
				...body.highlights.flatMap((highlight) => highlight.stories.map((story) => story.mediaKey)),
				...body.highlights.flatMap((highlight) =>
					highlight.stories.flatMap((story) =>
						story.overlays
							.filter((overlay) => overlay.type === 'image')
							.map((overlay) => overlay.mediaKey),
					),
				),
				...body.sections.map((item) => item.mediaKey),
				...body.customPages.flatMap((page) =>
					page.blocks.filter((block) => block.kind === 'image').map((block) => block.mediaKey),
				),
			].filter((key): key is string => Boolean(key)),
		),
	)
	const videoMediaKeys = Array.from(
		new Set(
			body.customPages
				.flatMap((page) =>
					page.blocks.filter((block) => block.kind === 'video').map((block) => block.mediaKey),
				)
				.filter((key): key is string => Boolean(key)),
		),
	)

	for (const mediaKey of imageMediaKeys) {
		const item = await findAdminMediaLibraryItemByKey(mediaKey)
		if (!item) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Изображение не найдено' },
				},
				404,
			)
		}
		if (item.type !== 'image') {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Выберите изображение' },
				},
				400,
			)
		}
	}
	for (const mediaKey of videoMediaKeys) {
		const item = await findAdminMediaLibraryItemByKey(mediaKey)
		if (!item) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Видео не найдено' },
				},
				404,
			)
		}
		if (item.type !== 'video') {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Выберите видео' },
				},
				400,
			)
		}
	}

	const saved = await saveHomeExperienceSettings(body)
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'update',
		entityType: 'home_experience',
		entityId: 'home',
		summary: 'Обновлены плашки главной',
		details: {
			changed: buildChangedFields(before, saved),
		},
	})

	return c.json({ success: true, data: saved })
})

adminRoutes.get('/app-navigation', async (c) => {
	return c.json({ success: true, data: await loadAppNavigationSettings() })
})

adminRoutes.put('/app-navigation', zValidator('json', appNavigationSettingsSchema), async (c) => {
	const userId = c.get('userId')
	const before = await loadAppNavigationSettings()
	const body = normalizeAppNavigationSettingsPayload(c.req.valid('json'))
	const centerButtonImageKey = body.menu.centerButton.imageKey
	if (centerButtonImageKey) {
		const item = await findAdminMediaLibraryItemByKey(centerButtonImageKey)
		if (!item) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Файл не найден' },
				},
				404,
			)
		}
		if (item.type !== 'image') {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Выберите изображение' },
				},
				400,
			)
		}
	}

	const saved = await saveAppNavigationSettings(body)
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'update',
		entityType: 'app_navigation',
		entityId: 'app',
		summary: 'Обновлены шапка и нижнее меню',
		details: {
			changed: buildChangedFields(before, saved),
		},
	})

	return c.json({ success: true, data: saved })
})

adminRoutes.get('/auth-login-settings', async (c) => {
	return c.json({ success: true, data: await loadAuthLoginSettings() })
})

adminRoutes.get('/test-access-settings', async (c) => {
	return c.json({ success: true, data: await loadTestAccessSettings() })
})

adminRoutes.get('/guest-content-access-settings', async (c) => {
	return c.json({ success: true, data: await loadGuestContentAccessSettings() })
})

adminRoutes.get('/referral-settings', async (c) => {
	return c.json({ success: true, data: await loadReferralProgramSettings() })
})

adminRoutes.get(
	'/referrals/:authUuid',
	zValidator('param', z.object({ authUuid: z.string().uuid() })),
	async (c) => {
		return c.json({ success: true, data: await loadReferralDetails(c.req.valid('param').authUuid) })
	},
)

adminRoutes.get(
	'/referral-analytics',
	zValidator('query', referralAnalyticsQuerySchema),
	async (c) => {
		const query = c.req.valid('query')
		const to = query.to ? new Date(`${query.to}T23:59:59.999Z`) : new Date()
		const from = query.from
			? new Date(`${query.from}T00:00:00.000Z`)
			: new Date(to.getTime() - 29 * 24 * 60 * 60 * 1000)
		return c.json({ success: true, data: await loadReferralAnalytics({ from, to }) })
	},
)

adminRoutes.get('/legal-documents', async (c) => {
	return c.json({ success: true, data: await loadLegalDocumentsSettings() })
})

adminRoutes.put(
	'/auth-login-settings',
	zValidator('json', adminAuthLoginSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const before = await loadAuthLoginSettings()
		const body = normalizeAuthLoginSettingsPayload(c.req.valid('json'))
		const saved = await saveAuthLoginSettings(body)

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'auth_login_settings',
			entityId: 'login',
			summary: 'Обновлены способы входа',
			details: {
				changed: buildChangedFields(before, saved),
			},
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.put(
	'/test-access-settings',
	zValidator('json', adminTestAccessSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const before = await loadTestAccessSettings()
		const body = normalizeTestAccessSettingsPayload(c.req.valid('json'))
		const saved = await saveTestAccessSettings(body)

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'test_access_settings',
			entityId: 'test-access',
			summary: 'Обновлён тестовый доступ',
			details: {
				changed: buildChangedFields(before, saved),
			},
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.put(
	'/guest-content-access-settings',
	zValidator('json', adminGuestContentAccessSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const before = await loadGuestContentAccessSettings()
		const saved = await saveGuestContentAccessSettings(
			normalizeGuestContentAccessSettingsPayload(c.req.valid('json')),
		)

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'guest_content_access',
			entityId: 'materials',
			summary: 'Обновлен уровень закрытости материалов',
			details: { changed: buildChangedFields(before, saved) },
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.put(
	'/referral-settings',
	zValidator('json', adminReferralProgramSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const before = await loadReferralProgramSettings()
		const body = normalizeReferralProgramSettingsPayload(c.req.valid('json'))
		const saved = await saveReferralProgramSettings(body)

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'referral_settings',
			entityId: 'referral-program',
			summary: 'Обновлена реферальная программа',
			details: {
				changed: buildChangedFields(before, saved),
			},
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.put(
	'/legal-documents',
	zValidator('json', adminLegalDocumentsSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const before = await loadLegalDocumentsSettings()
		const body = normalizeLegalDocumentsSettingsPayload(c.req.valid('json'))
		const saved = await saveLegalDocumentsSettings(body)

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'legal_documents',
			entityId: 'documents',
			summary: 'Обновлены документы сайта',
			details: {
				changed: buildChangedFields(before, saved),
			},
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.get('/telegram-bot-auth', async (c) => {
	return c.json({ success: true, data: await loadTelegramBotAuthSettings() })
})

adminRoutes.put(
	'/telegram-bot-auth',
	zValidator('json', adminTelegramBotAuthSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const body = normalizeTelegramBotAuthSettingsPayload(c.req.valid('json'))
		const saved = await saveTelegramBotAuthSettings(body)

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'telegram_bot_auth',
			entityId: 'telegram-bot-auth',
			summary: 'Обновлены настройки Telegram-бота для входа',
			details: {
				changed: true,
			},
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.get('/auth-login-settings', async (c) => {
	return c.json({ success: true, data: await loadAuthLoginSettings() })
})

adminRoutes.get('/runtime-settings', async (c) => {
	return c.json({ success: true, data: await loadAdminRuntimeSettings() })
})

adminRoutes.put('/runtime-settings', zValidator('json', adminRuntimeSettingsSchema), async (c) => {
	const userId = c.get('userId')
	const before = await loadAdminRuntimeSettings()
	const saved = await saveRuntimeSettings(c.req.valid('json'))

	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'update',
		entityType: 'runtime_settings',
		entityId: 'domain-and-messengers',
		summary: 'Обновлены домен и мессенджеры',
		details: {
			changed: buildChangedFields(
				{
					customDomain: before.customDomain,
					telegramBotTokenSet: before.telegramBotTokenSet,
					maxBotTokenSet: before.maxBotTokenSet,
					maxApiUrl: before.maxApiUrl,
				},
				{
					customDomain: saved.customDomain,
					telegramBotTokenSet: saved.telegramBotTokenSet,
					maxBotTokenSet: saved.maxBotTokenSet,
					maxApiUrl: saved.maxApiUrl,
				},
			),
		},
	})

	return c.json({ success: true, data: saved })
})

adminRoutes.post(
	'/runtime-settings/check-domain',
	zValidator('json', customDomainCheckSchema),
	async (c) => {
		const { customDomain } = c.req.valid('json')
		return c.json({ success: true, data: await checkCustomDomainStatus(customDomain) })
	},
)

adminRoutes.post(
	'/runtime-settings/provision-domain',
	zValidator('json', customDomainCheckSchema),
	async (c) => {
		const userId = c.get('userId')
		const { customDomain } = c.req.valid('json')
		const current = await loadAdminRuntimeSettings()
		const result = await provisionCustomDomain(customDomain)
		if (result.status === 'connected') {
			await saveRuntimeSettings({
				customDomain: result.domain,
				maxApiUrl: current.maxApiUrl,
			})
		}

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'runtime_settings',
			entityId: 'custom-domain',
			summary: 'Подключение домена',
			details: {
				status: result.status,
				domain: result.domain,
				message: result.message,
				https: result.https,
			},
		})

		return c.json({ success: true, data: result })
	},
)

adminRoutes.get('/payment-providers', async (c) => {
	return c.json({ success: true, data: await loadPaymentProviderSettings() })
})

adminRoutes.put(
	'/payment-providers',
	zValidator('json', adminPaymentProviderSettingsSchema),
	async (c) => {
		const userId = c.get('userId')
		const before = await loadPaymentProviderSettings()
		const saved = await savePaymentProviderSettings(c.req.valid('json'))

		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'payment_provider_settings',
			entityId: 'payment-providers',
			summary: 'Обновлены платёжные системы',
			details: {
				changed: buildChangedFields(
					{
						activeProvider: before.activeProvider,
						checkout: before.checkout,
						providers: before.providers.map((provider) => ({
							provider: provider.provider,
							enabled: provider.enabled,
							connected: provider.connected,
						})),
					},
					{
						activeProvider: saved.activeProvider,
						checkout: saved.checkout,
						providers: saved.providers.map((provider) => ({
							provider: provider.provider,
							enabled: provider.enabled,
							connected: provider.connected,
						})),
					},
				),
			},
		})

		return c.json({ success: true, data: saved })
	},
)

adminRoutes.get(
	'/media-library',
	zValidator(
		'query',
		cursorPaginationSchema.extend({
			type: z.enum(['all', 'image', 'video', 'audio', 'document']).optional(),
			search: z.string().trim().max(200).optional(),
			folderId: z.coerce.number().int().positive().nullable().optional(),
			sortBy: z.enum(['updatedAt', 'title', 'size', 'type']).optional(),
			sortDir: z.enum(['asc', 'desc']).optional(),
		}),
	),
	async (c) => {
		const { cursor, limit, type, search, folderId, sortBy, sortDir } = c.req.valid('query')
		if (!(await mediaLibraryFolderExists(folderId ?? null))) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Папка не найдена' } },
				404,
			)
		}
		const data = await loadAdminMediaLibraryPage({
			cursor,
			limit,
			type: type ?? 'all',
			search,
			folderId: folderId ?? null,
			sortBy,
			sortDir,
		}).catch((error) => {
			if (isMediaLibraryStorageUnavailableError(error)) {
				return null
			}
			throw error
		})
		if (!data) {
			return c.json(
				{
					success: false,
					error: {
						code: 'STORAGE_UNAVAILABLE',
						message: 'Медиахранилище недоступно. Проверьте подключение.',
					},
				},
				424,
			)
		}
		return c.json({ success: true, data })
	},
)

adminRoutes.get('/media-library/folders', async (c) => {
	return c.json({ success: true, data: await loadMediaLibraryFolders() })
})

adminRoutes.post(
	'/media-library/folders',
	zValidator('json', z.object({ name: z.string().trim().min(1).max(120) })),
	async (c) => {
		const userId = c.get('userId')
		const { name } = c.req.valid('json')
		const folder = await createMediaLibraryFolder({ name, userId })
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'create',
			entityType: 'media_folder',
			entityId: folder.id,
			summary: `Создана папка «${folder.name}»`,
			details: { folderName: folder.name },
		})
		return c.json({ success: true, data: folder }, 201)
	},
)

adminRoutes.delete('/media-library/folders/:id', async (c) => {
	const userId = c.get('userId')
	const folderId = Number(c.req.param('id'))
	if (!Number.isFinite(folderId) || folderId <= 0) {
		return c.json(
			{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Некорректная папка' } },
			400,
		)
	}

	const deleted = await deleteMediaLibraryFolder(folderId)
	if (!deleted) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Папка не найдена' } },
			404,
		)
	}

	await clearMediaLibraryFolderPreference(folderId)
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'delete',
		entityType: 'media_folder',
		entityId: deleted.id,
		summary: `Удалена папка «${deleted.name}»`,
		details: { folderName: deleted.name },
	})

	return c.json({ success: true, data: { deleted: true } })
})

adminRoutes.post(
	'/media-library/move',
	zValidator(
		'json',
		z.object({
			key: z.string().trim().min(1),
			folderId: z.number().int().positive().nullable(),
		}),
	),
	async (c) => {
		const userId = c.get('userId')
		const { key, folderId } = c.req.valid('json')
		const folder = folderId ? await findMediaLibraryFolderById(folderId) : null
		if (folderId && !folder) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Папка не найдена' } },
				404,
			)
		}

		const updated = await moveMediaLibraryItem({ key, folderId, userId })
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'move',
			entityType: 'media_item',
			entityId: key,
			summary: folder ? `Файл перемещён в папку «${folder.name}»` : 'Файл вынесен в общий список',
			details: {
				key,
				folderId: folderId ?? null,
				folderName: folder?.name ?? null,
			},
		})
		return c.json({ success: true, data: updated })
	},
)

const adminMediaLibraryPreferencesSchema = z.object({
	viewMode: z.enum(['cards', 'list']),
	sortBy: z.enum(['updatedAt', 'title', 'size', 'type']),
	sortDir: z.enum(['asc', 'desc']),
	typeFilter: z.enum(['all', 'image', 'video', 'audio', 'document']),
	searchQuery: z.string().max(200),
	folderId: z.number().int().positive().nullable(),
})

const mediaLibraryPreferencesScopeSchema = z.object({
	scope: z.enum(['library', 'materialPicker']).optional(),
})

adminRoutes.get(
	'/media-library/preferences',
	zValidator('query', mediaLibraryPreferencesScopeSchema),
	async (c) => {
		const userId = c.get('userId')
		const scope = c.req.valid('query').scope ?? 'library'
		return c.json({ success: true, data: await loadMediaLibraryPreferences(userId, scope) })
	},
)

adminRoutes.post(
	'/media-library/preferences',
	zValidator('query', mediaLibraryPreferencesScopeSchema),
	zValidator('json', adminMediaLibraryPreferencesSchema),
	async (c) => {
		const userId = c.get('userId')
		const scope = c.req.valid('query').scope ?? 'library'
		const body = c.req.valid('json')
		if (scope === 'library' && !(await mediaLibraryFolderExists(body.folderId))) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Папка не найдена' } },
				404,
			)
		}
		const saved = await saveMediaLibraryPreferences(userId, body, scope)
		return c.json({ success: true, data: saved })
	},
)

adminRoutes.post(
	'/media-library/note',
	zValidator(
		'json',
		z.object({
			key: z.string().trim().min(1),
			title: z.string().trim().min(1).max(255),
			note: z.string().trim().max(2000),
		}),
	),
	async (c) => {
		const userId = c.get('userId')
		const { key, title, note } = c.req.valid('json')
		const before = await db.query.mediaLibraryNotes.findFirst({
			where: eq(mediaLibraryNotes.key, key),
			columns: { title: true, note: true, folderId: true },
		})
		const item = await upsertMediaLibraryNote({ key, title, note, userId })
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'media_item',
			entityId: key,
			summary: `Обновлены подпись и комментарий файла ${title}`,
			details: {
				key,
				changed: buildChangedFields(before ?? null, {
					title: item.title,
					note: item.note,
					folderId: item.folderId ?? null,
				}),
			},
		})
		return c.json({ success: true, data: item })
	},
)

adminRoutes.post(
	'/media-library/optimize-pdf',
	zValidator(
		'json',
		z.object({
			key: z.string().trim().min(1),
		}),
	),
	async (c) => {
		const userId = c.get('userId')
		const { key } = c.req.valid('json')
		if (!key.toLowerCase().endsWith('.pdf')) {
			return c.json(
				{
					success: false,
					error: { code: 'VALIDATION_ERROR', message: 'Оптимизация доступна только для PDF' },
				},
				400,
			)
		}

		try {
			const result = await optimizeStoredPdfObject({
				bucket: env.S3_BUCKET_MEDIA,
				key,
			})
			await appendAdminActivityLog({
				actorAuthUuid: userId,
				action: 'optimize',
				entityType: 'media_item',
				entityId: key,
				summary: 'Оптимизирован PDF-файл',
				details: {
					key,
					beforeSize: result.beforeSize,
					afterSize: result.afterSize,
					changed: result.changed,
				},
			})
			return c.json({ success: true, data: result })
		} catch (error) {
			logger.warn({ err: error, key }, 'Failed to optimize media library PDF')
			return c.json(
				{
					success: false,
					error: {
						code: 'INTERNAL_ERROR',
						message: 'Не удалось оптимизировать PDF. Попробуйте ещё раз.',
					},
				},
				500,
			)
		}
	},
)

adminRoutes.delete(
	'/media-library',
	zValidator(
		'query',
		z.object({
			key: z.string().trim().min(1),
		}),
	),
	async (c) => {
		const userId = c.get('userId')
		const { key } = c.req.valid('query')

		await deleteFile(env.S3_BUCKET_MEDIA, key)
		await clearMediaLibraryItem(key)
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'delete',
			entityType: 'media_item',
			entityId: key,
			summary: 'Файл удалён из медиатеки',
			details: { key },
		})

		return c.json({ success: true, data: { deleted: true, key } })
	},
)

adminRoutes.delete('/feed-posts/:id', async (c) => {
	const id = Number(c.req.param('id'))
	const userId = c.get('userId')

	const existing = await db.query.feedPosts.findFirst({
		where: eq(feedPosts.id, id),
		columns: {
			id: true,
		},
	})

	if (!existing) {
		return c.json({ success: false, error: { code: 'NOT_FOUND', message: 'Пост не найден' } }, 404)
	}

	await db.delete(feedPosts).where(eq(feedPosts.id, id))
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'delete',
		entityType: 'feed_post',
		entityId: id,
		summary: 'Удалён пост из ленты',
		details: { id },
	})
	return c.json({ success: true, data: { deleted: true } })
})

function buildPaymentRoleFlags() {
	return {}
}

type CloudRecord = Record<string, unknown>

function toCloudRecord(value: unknown): CloudRecord | null {
	return value && typeof value === 'object' && !Array.isArray(value) ? (value as CloudRecord) : null
}

function toCloudRecordArray(value: unknown): CloudRecord[] {
	if (Array.isArray(value)) {
		return value.map(toCloudRecord).filter((item): item is CloudRecord => Boolean(item))
	}
	const single = toCloudRecord(value)
	return single ? [single] : []
}

function uniqueNonEmpty(values: Array<string | null | undefined>) {
	return [...new Set(values.map((value) => String(value ?? '').trim()).filter(Boolean))]
}

function buildPhoneSearchCandidates(phone: string | null | undefined) {
	const raw = String(phone ?? '').trim()
	if (!raw) return []
	const digits = raw.replace(/\D/g, '')
	return uniqueNonEmpty([raw, digits ? `+${digits}` : null, digits || null])
}

function parseExternalDate(value: unknown): Date | null {
	if (!value) return null
	if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value
	if (typeof value === 'string') {
		const cloudDate = value.match(/\/Date\((\d+)\)\//)
		const parsed = cloudDate ? new Date(Number(cloudDate[1])) : new Date(value)
		return Number.isNaN(parsed.getTime()) ? null : parsed
	}
	return null
}

function dateToIso(value: unknown) {
	return parseExternalDate(value)?.toISOString() ?? null
}

function addDaysDateOnly(base: Date, days: number) {
	const next = new Date(base)
	next.setUTCDate(next.getUTCDate() + days)
	return next.toISOString().slice(0, 10)
}

function pickString(model: CloudRecord | null | undefined, keys: string[]) {
	if (!model) return null
	for (const key of keys) {
		const value = model[key]
		const normalized = String(value ?? '').trim()
		if (normalized) return normalized
	}
	return null
}

function pickNumber(model: CloudRecord | null | undefined, keys: string[]) {
	if (!model) return null
	for (const key of keys) {
		const value = model[key]
		if (typeof value === 'number' && Number.isFinite(value)) return value
		if (typeof value === 'string') {
			const normalized = Number(value.replace(',', '.'))
			if (Number.isFinite(normalized)) return normalized
		}
	}
	return null
}

function parseMetadata(value: unknown): CloudRecord {
	if (!value) return {}
	if (typeof value === 'string') {
		try {
			const parsed = JSON.parse(value)
			return toCloudRecord(parsed) ?? {}
		} catch {
			return {}
		}
	}
	return toCloudRecord(value) ?? {}
}

function getCloudModelMetadata(model: CloudRecord | null | undefined) {
	if (!model) return {}
	return {
		...parseMetadata(model.Data),
		...parseMetadata(model.JsonData),
		...parseMetadata(model.Metadata),
	}
}

function resolveInvoiceIdFromLog(log: typeof paymentLogs.$inferSelect | null | undefined) {
	const raw = toCloudRecord(log?.rawData)
	return (
		pickString(raw, ['InvoiceId']) ??
		(String(log?.orderId ?? '').includes(':') ? String(log?.orderId) : null)
	)
}

function isCloudPaymentsLog(log: typeof paymentLogs.$inferSelect | null | undefined) {
	const raw = toCloudRecord(log?.rawData)
	return Boolean(
		log?.webhookType === 'cloudpayments' ||
			raw?.AccountId ||
			raw?.TransactionId ||
			raw?.SubscriptionId,
	)
}

function resolveTariffSlug(params: {
	paymentModel?: CloudRecord | null
	latestLog?: typeof paymentLogs.$inferSelect | null
	payment?: typeof payments.$inferSelect | null
}) {
	const metadata = getCloudModelMetadata(params.paymentModel)
	const invoiceId =
		pickString(params.paymentModel, ['InvoiceId']) ?? resolveInvoiceIdFromLog(params.latestLog)
	const tariffFromInvoice = invoiceId?.includes(':') ? invoiceId.split(':')[0] : null
	return (
		String(metadata.tariff ?? '').trim() ||
		String(params.latestLog?.tariff ?? '').trim() ||
		tariffFromInvoice ||
		String(params.payment?.tarrif ?? '').trim() ||
		null
	)
}

function getLatestByDate(items: CloudRecord[], dateKeys: string[]) {
	return (
		[...items].sort((left, right) => {
			const leftTime = parseExternalDate(pickString(left, dateKeys))?.getTime() ?? 0
			const rightTime = parseExternalDate(pickString(right, dateKeys))?.getTime() ?? 0
			return rightTime - leftTime
		})[0] ?? null
	)
}

async function loadAdminUserBillingContext(uuid: string) {
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, uuid),
	})
	if (!user) return null

	const payment = await db.query.payments.findFirst({
		where: eq(payments.userAuthUuid, uuid),
	})

	const logConditions = [
		eq(paymentLogs.userAuthUuid, uuid),
		...(user.email ? [eq(paymentLogs.email, user.email)] : []),
		...(user.phone ? [eq(paymentLogs.phone, user.phone)] : []),
		...(payment?.cpSubscriptionId
			? [eq(paymentLogs.subscriptionId, payment.cpSubscriptionId)]
			: []),
	]

	const logs = await db.query.paymentLogs.findMany({
		where: or(...logConditions),
		orderBy: [desc(paymentLogs.paymentDate), desc(paymentLogs.createdAt)],
		limit: 10,
	})

	return { user, payment, logs }
}

async function runCloudPaymentsCheck(uuid: string) {
	const context = await loadAdminUserBillingContext(uuid)
	if (!context) return null

	if (!(await hasCloudPaymentsCredentials())) {
		return {
			...context,
			cloudError: 'Платёжная система не настроена на сервере',
			paymentModel: null,
			subscriptionModel: null,
			proposedUpdate: null,
			search: {
				accountIds: [],
				subscriptionIds: [],
				invoiceIds: [],
			},
		}
	}

	const cloudPaymentLogs = context.logs.filter(isCloudPaymentsLog)
	const latestLog = cloudPaymentLogs[0] ?? null
	const accountIds = uniqueNonEmpty([
		context.payment?.cpAccountId,
		context.user.authUuid,
		context.user.email,
		...buildPhoneSearchCandidates(context.user.phone),
	])
	const subscriptionIds = uniqueNonEmpty([
		context.payment?.cpSubscriptionId,
		latestLog?.subscriptionId,
	])
	const invoiceIds = uniqueNonEmpty(
		cloudPaymentLogs.map((log) => resolveInvoiceIdFromLog(log)).filter(Boolean),
	).slice(0, 5)

	const [knownSubscriptions, foundSubscriptions, foundPayments] = await Promise.all([
		Promise.allSettled(subscriptionIds.map((id) => getCloudSubscription(id))),
		Promise.allSettled(accountIds.map((id) => findCloudSubscriptionsByAccountId(id))),
		Promise.allSettled(invoiceIds.map((id) => findCloudPaymentByInvoiceId(id))),
	])

	const subscriptionModels = [
		...knownSubscriptions.flatMap((result) =>
			result.status === 'fulfilled' && result.value.Success
				? toCloudRecordArray(result.value.Model)
				: [],
		),
		...foundSubscriptions.flatMap((result) =>
			result.status === 'fulfilled' && result.value.Success
				? toCloudRecordArray(result.value.Model)
				: [],
		),
	]
	const paymentModels = foundPayments.flatMap((result) =>
		result.status === 'fulfilled' && result.value.Success
			? toCloudRecordArray(result.value.Model)
			: [],
	)

	const paymentModel = getLatestByDate(paymentModels, [
		'CreatedDateIso',
		'DateTimeIso',
		'PaymentDateIso',
		'CreatedDate',
		'DateTime',
	]) as CloudRecord | null
	const subscriptionModel = getLatestByDate(subscriptionModels, [
		'LastTransactionDateIso',
		'NextTransactionDateIso',
		'StartDateIso',
		'LastTransactionDate',
		'NextTransactionDate',
		'StartDate',
	]) as CloudRecord | null

	const tariffSlug = resolveTariffSlug({
		paymentModel,
		latestLog,
		payment: context.payment,
	})
	const tariff = tariffSlug
		? await db.query.tariffs.findFirst({ where: eq(tariffs.slug, tariffSlug) })
		: null

	const paymentDate =
		parseExternalDate(
			pickString(paymentModel, [
				'CreatedDateIso',
				'DateTimeIso',
				'PaymentDateIso',
				'CreatedDate',
				'DateTime',
			]),
		) ??
		parseExternalDate(latestLog?.paymentDate) ??
		parseExternalDate(latestLog?.createdAt) ??
		null

	const nextPaymentDate = parseExternalDate(
		pickString(subscriptionModel, ['NextTransactionDateIso', 'NextTransactionDate']),
	)
	const dateStart = paymentDate
		? paymentDate.toISOString().slice(0, 10)
		: (context.payment?.dateStart ?? null)
	const dateFinish = nextPaymentDate
		? nextPaymentDate.toISOString().slice(0, 10)
		: paymentDate && tariff?.durationDays
			? addDaysDateOnly(paymentDate, tariff.durationDays)
			: (context.payment?.dateFinish ?? null)
	const amount =
		pickNumber(paymentModel, ['Amount', 'PaymentAmount']) ??
		pickNumber(subscriptionModel, ['Amount']) ??
		(latestLog?.amount != null ? Number(latestLog.amount) : null) ??
		(context.payment?.amount != null ? Number(context.payment.amount) : null)
	const proposedSubscriptionId =
		pickString(subscriptionModel, ['Id']) ?? context.payment?.cpSubscriptionId ?? null
	const proposedSubscriptionStatus = pickString(subscriptionModel, ['Status'])
	const hasPaymentSystemData = Boolean(
		paymentModel || subscriptionModel || isCloudPaymentsLog(latestLog),
	)

	const proposedUpdate =
		hasPaymentSystemData && (dateStart || dateFinish || tariffSlug || amount != null)
			? {
					dateStart,
					dateFinish,
					tarrif: tariffSlug,
					amount: amount != null && Number.isFinite(amount) ? String(amount) : null,
					cpSubscriptionId: proposedSubscriptionId,
					cpAccountId:
						pickString(subscriptionModel, ['AccountId']) ??
						pickString(paymentModel, ['AccountId']) ??
						context.payment?.cpAccountId ??
						context.user.authUuid,
					autoPayment: proposedSubscriptionId ? proposedSubscriptionStatus !== 'Cancelled' : null,
				}
			: null

	return {
		...context,
		cloudError: null,
		paymentModel,
		subscriptionModel,
		proposedUpdate,
		search: {
			accountIds,
			subscriptionIds,
			invoiceIds,
		},
	}
}

function buildPaymentCheckResponse(result: Awaited<ReturnType<typeof runCloudPaymentsCheck>>) {
	if (!result) return null

	const latestLog = result.logs.find(isCloudPaymentsLog) ?? null
	const paymentModel = result.paymentModel
	const subscriptionModel = result.subscriptionModel
	const latestPaymentDate =
		dateToIso(
			pickString(paymentModel, [
				'CreatedDateIso',
				'DateTimeIso',
				'PaymentDateIso',
				'CreatedDate',
				'DateTime',
			]),
		) ??
		dateToIso(latestLog?.paymentDate) ??
		dateToIso(latestLog?.createdAt)

	return {
		checkedAt: new Date().toISOString(),
		error: result.cloudError,
		search: result.search ?? {
			accountIds: [],
			subscriptionIds: [],
			invoiceIds: [],
		},
		current: {
			dateStart: result.payment?.dateStart ?? null,
			dateFinish: result.payment?.dateFinish ?? null,
			tarrif: result.payment?.tarrif ?? null,
			amount: result.payment?.amount ?? null,
			autoPayment: result.payment?.autoPayment ?? false,
		},
		payment: {
			date: latestPaymentDate,
			amount:
				pickNumber(paymentModel, ['Amount', 'PaymentAmount']) ??
				(latestLog?.amount != null ? Number(latestLog.amount) : null),
			currency: pickString(paymentModel, ['Currency']) ?? 'RUB',
			status: pickString(paymentModel, ['Status']) ?? latestLog?.status ?? null,
			invoiceId: pickString(paymentModel, ['InvoiceId']) ?? resolveInvoiceIdFromLog(latestLog),
			transactionId: pickString(paymentModel, ['TransactionId']),
			description: pickString(paymentModel, ['Description']) ?? null,
		},
		subscription: {
			id: pickString(subscriptionModel, ['Id']) ?? result.payment?.cpSubscriptionId ?? null,
			status: pickString(subscriptionModel, ['Status']) ?? null,
			amount: pickNumber(subscriptionModel, ['Amount']),
			currency: pickString(subscriptionModel, ['Currency']) ?? null,
			startDate: dateToIso(pickString(subscriptionModel, ['StartDateIso', 'StartDate'])),
			lastPaymentDate: dateToIso(
				pickString(subscriptionModel, ['LastTransactionDateIso', 'LastTransactionDate']),
			),
			nextPaymentDate: dateToIso(
				pickString(subscriptionModel, ['NextTransactionDateIso', 'NextTransactionDate']),
			),
			description: pickString(subscriptionModel, ['Description']) ?? null,
		},
		proposedUpdate: result.proposedUpdate,
		canUpdate: Boolean(result.proposedUpdate && !result.cloudError),
	}
}

const adminUsersListSchema = paginationSchema.merge(
	z.object({
		q: z.string().trim().max(200).optional(),
		field: z
			.enum([
				'all',
				'id',
				'authUuid',
				'fullName',
				'email',
				'phone',
				'telegram',
				'role',
				'dateStart',
				'dateFinish',
				'amount',
			])
			.default('all'),
		sortBy: z
			.enum([
				'createdAt',
				'fullName',
				'email',
				'phone',
				'role',
				'dateStart',
				'dateFinish',
				'amount',
			])
			.default('createdAt'),
		sortDir: z.enum(['asc', 'desc']).default('desc'),
	}),
)

type AdminUserListItem = User & {
	payment: Payment | null
	telegramBots: string[]
	telegramUserIds: string[]
}
type AdminUsersListQuery = z.infer<typeof adminUsersListSchema>
type AdminUsersQueryRow = AdminUserListItem & { __total?: number | string }

const adminUsersSearchFields: Record<Exclude<AdminUsersListQuery['field'], 'all'>, string> = {
	id: 'u.id::text',
	authUuid: 'u.auth_uuid::text',
	fullName: "COALESCE(u.full_name, '')",
	email: "COALESCE(u.email, '')",
	phone: "COALESCE(u.phone, '')",
	telegram: "COALESCE(array_to_string(tc.telegram_user_ids, ' '), '')",
	role: "COALESCE(u.role, '')",
	dateStart: "COALESCE(lp.date_start::text, '')",
	dateFinish: "COALESCE(lp.date_finish::text, '')",
	amount: "COALESCE(lp.amount::text, '')",
}

const adminUsersSortFields: Record<AdminUsersListQuery['sortBy'], string> = {
	createdAt: '"createdAt"',
	fullName: 'lower(COALESCE("fullName", \'\'))',
	email: "lower(COALESCE(email, ''))",
	phone: "lower(COALESCE(phone, ''))",
	role: "lower(COALESCE(role, ''))",
	dateStart: "(payment->>'dateStart')::date",
	dateFinish: "(payment->>'dateFinish')::date",
	amount:
		"CASE WHEN payment->>'amount' ~ '^-?[0-9]+(\\.[0-9]+)?$' THEN (payment->>'amount')::numeric ELSE NULL END",
}

function escapeLikePattern(value: string) {
	return value.replace(/[\\%_]/g, '\\$&')
}

function buildAdminUsersWhere(params: { field: AdminUsersListQuery['field']; hasQuery: boolean }) {
	if (!params.hasQuery) return ''

	if (params.field !== 'all') {
		return `WHERE ${adminUsersSearchFields[params.field]} ILIKE $1 ESCAPE '\\'`
	}

	return `WHERE (${Object.values(adminUsersSearchFields)
		.map((expression) => `${expression} ILIKE $1 ESCAPE '\\'`)
		.join(' OR ')})`
}

function adminUsersSql(params: AdminUsersListQuery & { offset: number; hasQuery: boolean }) {
	const whereSql = buildAdminUsersWhere({ field: params.field, hasQuery: params.hasQuery })
	const limitParam = params.hasQuery ? 2 : 1
	const offsetParam = params.hasQuery ? 3 : 2
	const sortExpression = adminUsersSortFields[params.sortBy]
	const sortDirection = params.sortDir === 'asc' ? 'ASC' : 'DESC'

	return `
WITH latest_payments AS (
	SELECT DISTINCT ON (user_auth_uuid)
		id,
		user_auth_uuid,
		email,
		phone,
		tarrif,
		date_start,
		date_finish,
		cp_subscription_id,
		cp_account_id,
		payment_provider,
		amount,
		auto_payment,
		no_autopodpiska,
		zarub,
		created_at,
		updated_at
	FROM payments
	WHERE user_auth_uuid IS NOT NULL
	ORDER BY user_auth_uuid, updated_at DESC NULLS LAST, date_finish DESC NULLS LAST, created_at DESC NULLS LAST, id DESC
),
telegram_contacts_by_user AS (
	SELECT
		user_auth_uuid,
		array_agg(DISTINCT bot_username ORDER BY bot_username) AS bot_usernames,
		array_agg(DISTINCT telegram_user_id ORDER BY telegram_user_id) AS telegram_user_ids
	FROM telegram_contacts
	GROUP BY user_auth_uuid
),
filtered AS (
	SELECT
		u.id::double precision AS id,
		u.auth_uuid AS "authUuid",
		u.email,
		u.phone,
		u.auth_type AS "authType",
		u.username,
		u.avatar_url AS "avatarUrl",
		u.full_name AS "fullName",
		u.first_name AS "firstName",
		u.city,
		u.social_account AS "socialAccount",
		u.social_links AS "socialLinks",
		u.telegram_chat_id AS "telegramChatId",
		u.telegram_username AS "telegramUsername",
		u.telegram_notifications_enabled AS "telegramNotificationsEnabled",
		COALESCE(tc.bot_usernames, ARRAY[]::text[]) AS "telegramBots",
		COALESCE(tc.telegram_user_ids, ARRAY[]::text[]) AS "telegramUserIds",
		u.max_messenger_user_id AS "maxMessengerUserId",
		u.work_place AS "workPlace",
		u.manicure_price AS "manicurePrice",
		u.pedicure_price AS "pedicurePrice",
		u.monthly_income AS "monthlyIncome",
		u.expectations,
		u.other_expectation AS "otherExpectation",
		u.game_role AS "gameRole",
		u.chat_admin_badge AS "chatAdminBadge",
		u.admin_permissions AS "adminPermissions",
		u.points,
		u.bonus_balance AS "bonusBalance",
		u.role,
		u.first_entry AS "firstEntry",
		u.created_at AS "createdAt",
		u.updated_at AS "updatedAt",
		CASE WHEN lp.id IS NULL THEN NULL ELSE json_build_object(
			'id', lp.id,
			'userAuthUuid', lp.user_auth_uuid,
			'email', lp.email,
			'phone', lp.phone,
			'tarrif', lp.tarrif,
			'dateStart', lp.date_start,
			'dateFinish', lp.date_finish,
			'cpSubscriptionId', lp.cp_subscription_id,
			'cpAccountId', lp.cp_account_id,
			'cpToken', NULL,
			'paymentProvider', lp.payment_provider,
			'amount', lp.amount,
			'autoPayment', lp.auto_payment,
			'noAutopodpiska', lp.no_autopodpiska,
			'zarub', lp.zarub,
			'createdAt', lp.created_at,
			'updatedAt', lp.updated_at
		) END AS payment
	FROM users u
	LEFT JOIN latest_payments lp ON lp.user_auth_uuid = u.auth_uuid
	LEFT JOIN telegram_contacts_by_user tc ON tc.user_auth_uuid = u.auth_uuid
	${whereSql}
)
SELECT *, count(*) OVER()::integer AS "__total"
FROM filtered
ORDER BY ${sortExpression} ${sortDirection} NULLS LAST, id ${sortDirection}
LIMIT $${limitParam} OFFSET $${offsetParam}
`
}

// Поиск пользователей (с платёжными данными)
adminRoutes.get('/users', zValidator('query', adminUsersListSchema), async (c) => {
	const { page, pageSize, q, field, sortBy, sortDir } = c.req.valid('query')
	const offset = (page - 1) * pageSize
	const normalizedQuery = q?.trim().toLowerCase() ?? ''
	const hasQuery = normalizedQuery.length > 0
	const params = hasQuery
		? [`%${escapeLikePattern(normalizedQuery)}%`, pageSize, offset]
		: [pageSize, offset]
	const rows = await queryClient.unsafe<AdminUsersQueryRow[]>(
		adminUsersSql({ page, pageSize, q, field, sortBy, sortDir, offset, hasQuery }),
		params,
	)
	const total = Number(rows[0]?.__total ?? 0)
	const pagedItems = rows.map(({ __total, ...item }) => item)

	return c.json({
		success: true,
		data: {
			items: pagedItems,
			total,
			page,
			pageSize,
			hasMore: offset + pageSize < total,
		},
	})
})

// Пользователь + платежи
adminRoutes.get('/users/:uuid', async (c) => {
	const uuid = c.req.param('uuid')
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, uuid),
		columns: {
			passwordHash: false,
		},
	})
	if (!user) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	const payment = await db.query.payments.findFirst({
		where: eq(payments.userAuthUuid, uuid),
	})

	return c.json({
		success: true,
		data: { user, payment: payment ? { ...payment, cpToken: null } : null },
	})
})

function blankToNull(value: unknown) {
	if (typeof value === 'string' && value.trim() === '') return null
	return value
}

function withoutPasswordHash<T extends { passwordHash?: unknown }>(user: T) {
	const { passwordHash, ...safeUser } = user
	void passwordHash
	return safeUser
}

const nullableTextInput = (max: number) =>
	z.preprocess(blankToNull, z.string().trim().max(max).nullable().optional())

const nullableEmailInput = z.preprocess(
	blankToNull,
	z.string().trim().email().nullable().optional(),
)

const optionalPasswordInput = z.preprocess(
	blankToNull,
	z.string().min(8).max(128).nullable().optional(),
)

function normalizeNullableText(value: string | null | undefined) {
	const trimmed = value?.trim() ?? ''
	return trimmed || null
}

function normalizeNullableEmail(value: string | null | undefined) {
	const trimmed = value?.trim().toLowerCase() ?? ''
	return trimmed || null
}

function whereAny(conditions: SQL[]): SQL {
	return conditions.length === 1 ? conditions[0] : (or(...conditions) as SQL)
}

// Обновить пользователя (admin)
const adminUpdateUserSchema = z.object({
	role: z.enum(['user', 'admin', 'superadmin']).optional(),
	adminPermissions: z.array(z.enum(adminPermissionKeys)).nullable().optional(),
	fullName: nullableTextInput(255),
	email: nullableEmailInput,
	phone: nullableTextInput(80),
	telegramChatId: nullableTextInput(120),
	telegramUsername: nullableTextInput(120),
	maxMessengerUserId: nullableTextInput(120),
	chatAdminBadge: z.boolean().optional(),
})

const adminCreateUserSchema = z.object({
	fullName: nullableTextInput(255),
	email: nullableEmailInput,
	phone: nullableTextInput(80),
	role: z.enum(['user', 'admin', 'superadmin']).default('user'),
	adminPermissions: z.array(z.enum(adminPermissionKeys)).nullable().optional(),
	chatAdminBadge: z.boolean().default(false),
	password: optionalPasswordInput,
})

adminRoutes.post('/users', zValidator('json', adminCreateUserSchema), async (c) => {
	const body = c.req.valid('json')
	const actorUserId = c.get('userId')
	const actorRole = c.get('userRole')
	if (actorRole !== 'superadmin' && (body.role !== 'user' || body.adminPermissions !== undefined)) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Недостаточно прав доступа' },
			},
			403,
		)
	}
	const normalizedFullName = normalizeNullableText(body.fullName)
	const normalizedEmail = normalizeNullableEmail(body.email)
	const normalizedPhone = normalizeNullableText(body.phone)
	const normalizedPassword = normalizeNullableText(body.password)
	const duplicateConditions: SQL[] = []

	if (normalizedEmail) {
		duplicateConditions.push(eq(users.email, normalizedEmail))
	}

	if (normalizedPhone) {
		duplicateConditions.push(eq(users.phone, normalizedPhone))
	}

	const existingUser =
		duplicateConditions.length > 0
			? await db.query.users.findFirst({
					where: whereAny(duplicateConditions),
					columns: {
						authUuid: true,
					},
				})
			: null

	if (existingUser) {
		return c.json(
			{
				success: false,
				error: {
					code: 'BAD_REQUEST',
					message: 'Пользователь с таким email или телефоном уже существует',
				},
			},
			400,
		)
	}

	const passwordHash = normalizedPassword
		? await Bun.password.hash(normalizedPassword, { algorithm: 'bcrypt', cost: 12 })
		: null

	const [created] = await db
		.insert(users)
		.values({
			fullName: normalizedFullName,
			email: normalizedEmail,
			phone: normalizedPhone,
			role: body.role,
			adminPermissions:
				body.role === 'admin'
					? (body.adminPermissions ?? null)
					: body.role === 'superadmin'
						? null
						: null,
			chatAdminBadge: body.chatAdminBadge,
			authType: normalizedEmail && passwordHash ? 'email' : null,
			passwordHash,
		})
		.returning({
			id: users.id,
			authUuid: users.authUuid,
			email: users.email,
			phone: users.phone,
			fullName: users.fullName,
			role: users.role,
			adminPermissions: users.adminPermissions,
			chatAdminBadge: users.chatAdminBadge,
			createdAt: users.createdAt,
			updatedAt: users.updatedAt,
		})

	await db.insert(payments).values({
		userAuthUuid: created.authUuid,
		email: created.email,
		phone: created.phone,
		autoPayment: false,
		noAutopodpiska: true,
		...buildPaymentRoleFlags(),
	})

	await appendAdminActivityLog({
		actorAuthUuid: actorUserId,
		action: 'create',
		entityType: 'user',
		entityId: created.authUuid,
		summary: `Создан пользователь ${created.fullName || created.email}`,
		details: {
			fullName: created.fullName,
			email: created.email,
			role: created.role,
			adminPermissions: created.adminPermissions,
			chatAdminBadge: created.chatAdminBadge,
		},
	})

	return c.json({ success: true, data: created }, 201)
})

adminRoutes.patch('/users/:uuid', zValidator('json', adminUpdateUserSchema), async (c) => {
	const uuid = c.req.param('uuid')
	const actorUserId = c.get('userId')
	const actorRole = c.get('userRole')
	const body = c.req.valid('json')
	const currentUser = await db.query.users.findFirst({
		where: eq(users.authUuid, uuid),
	})

	if (!currentUser) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	const touchesAdminAccess = body.role !== undefined || body.adminPermissions !== undefined
	const targetIsStaff = currentUser.role === 'admin' || currentUser.role === 'superadmin'
	const nextRoleIsStaff = body.role === 'admin' || body.role === 'superadmin'
	if (actorRole !== 'superadmin' && (touchesAdminAccess || targetIsStaff || nextRoleIsStaff)) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Недостаточно прав доступа' },
			},
			403,
		)
	}

	const normalizedFullName = normalizeNullableText(body.fullName)
	const normalizedEmail = normalizeNullableEmail(body.email)
	const normalizedPhone = normalizeNullableText(body.phone)
	const normalizedTelegramChatId = normalizeNullableText(body.telegramChatId)
	const normalizedMaxMessengerUserId = normalizeNullableText(body.maxMessengerUserId)

	if (normalizedEmail && normalizedEmail !== currentUser.email) {
		const emailOwner = await db.query.users.findFirst({
			where: and(eq(users.email, normalizedEmail), ne(users.authUuid, uuid)),
			columns: {
				authUuid: true,
			},
		})

		if (emailOwner) {
			return c.json(
				{
					success: false,
					error: {
						code: 'BAD_REQUEST',
						message: 'Пользователь с таким email уже существует',
					},
				},
				400,
			)
		}
	}

	if (normalizedPhone && normalizedPhone !== currentUser.phone) {
		const phoneOwner = await db.query.users.findFirst({
			where: and(eq(users.phone, normalizedPhone), ne(users.authUuid, uuid)),
			columns: {
				authUuid: true,
			},
		})

		if (phoneOwner) {
			return c.json(
				{
					success: false,
					error: {
						code: 'BAD_REQUEST',
						message: 'Пользователь с таким телефоном уже существует',
					},
				},
				400,
			)
		}
	}

	const nextRole = body.role ?? currentUser.role
	const updatePayload = {
		...(body.role ? { role: body.role } : {}),
		...(body.adminPermissions !== undefined || body.role !== undefined
			? { adminPermissions: nextRole === 'admin' ? (body.adminPermissions ?? null) : null }
			: {}),
		...(body.fullName !== undefined ? { fullName: normalizedFullName } : {}),
		...(body.email !== undefined ? { email: normalizedEmail } : {}),
		...(body.phone !== undefined ? { phone: normalizedPhone } : {}),
		...(body.telegramChatId !== undefined ? { telegramChatId: normalizedTelegramChatId } : {}),
		...(body.telegramUsername !== undefined
			? { telegramUsername: normalizeNullableText(body.telegramUsername) }
			: {}),
		...(body.maxMessengerUserId !== undefined
			? { maxMessengerUserId: normalizedMaxMessengerUserId }
			: {}),
		...(body.chatAdminBadge !== undefined ? { chatAdminBadge: body.chatAdminBadge } : {}),
	}

	const [updated] = await db
		.update(users)
		.set(updatePayload)
		.where(eq(users.authUuid, uuid))
		.returning()

	const paymentUpdatePayload = {
		...(body.email !== undefined ? { email: normalizedEmail } : {}),
		...(body.phone !== undefined ? { phone: normalizedPhone } : {}),
		...(body.role ? buildPaymentRoleFlags() : {}),
	}

	if (Object.keys(paymentUpdatePayload).length > 0) {
		const existingPayment = await db.query.payments.findFirst({
			where: eq(payments.userAuthUuid, uuid),
			columns: { id: true },
		})

		if (existingPayment) {
			await db.update(payments).set(paymentUpdatePayload).where(eq(payments.userAuthUuid, uuid))
		} else {
			await db.insert(payments).values({
				userAuthUuid: uuid,
				email: normalizedEmail ?? currentUser.email ?? null,
				phone: normalizedPhone ?? currentUser.phone ?? null,
				autoPayment: false,
				noAutopodpiska: true,
				...buildPaymentRoleFlags(),
			})
		}
	}

	await invalidateUserAccessCaches(uuid)

	await appendAdminActivityLog({
		actorAuthUuid: actorUserId,
		action: 'update',
		entityType: 'user',
		entityId: uuid,
		summary: `Обновлён пользователь ${updated.fullName || updated.email || uuid}`,
		details: {
			changed: buildChangedFields(
				{
					role: currentUser.role,
					fullName: currentUser.fullName,
					email: currentUser.email,
					phone: currentUser.phone,
					chatAdminBadge: currentUser.chatAdminBadge,
				},
				{
					role: updated.role,
					fullName: updated.fullName,
					email: updated.email,
					phone: updated.phone,
					chatAdminBadge: updated.chatAdminBadge,
				},
			),
		},
	})

	return c.json({ success: true, data: withoutPasswordHash(updated) })
})

adminRoutes.delete('/users/:uuid', async (c) => {
	const uuid = c.req.param('uuid')
	const actorUserId = c.get('userId')
	const actorRole = c.get('userRole')

	if (uuid === actorUserId) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Нельзя удалить свой аккаунт' },
			},
			400,
		)
	}

	const target = await db.query.users.findFirst({
		where: eq(users.authUuid, uuid),
	})

	if (!target) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	const targetIsStaff = target.role === 'admin' || target.role === 'superadmin'
	if (actorRole !== 'superadmin' && targetIsStaff) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Недостаточно прав доступа' },
			},
			403,
		)
	}

	if (target.role === 'superadmin') {
		const anotherOwner = await db.query.users.findFirst({
			where: and(eq(users.role, 'superadmin'), ne(users.authUuid, uuid)),
			columns: { authUuid: true },
		})
		if (!anotherOwner) {
			return c.json(
				{
					success: false,
					error: { code: 'BAD_REQUEST', message: 'Нельзя удалить последнего владельца' },
				},
				400,
			)
		}
	}

	const paymentLogConditions: SQL[] = [eq(paymentLogs.userAuthUuid, uuid)]
	if (target.email) paymentLogConditions.push(eq(paymentLogs.email, target.email))
	if (target.phone) paymentLogConditions.push(eq(paymentLogs.phone, target.phone))

	await db.transaction(async (tx) => {
		const supportChats = await tx
			.select({ id: chats.id })
			.from(chats)
			.where(eq(chats.slug, getSupportChatSlug(uuid)))
		const supportChatIds = supportChats.map((chat) => chat.id)

		await tx
			.update(pushCampaigns)
			.set({ createdByAuthUuid: null })
			.where(eq(pushCampaigns.createdByAuthUuid, uuid))
		await tx
			.update(mediaLibraryFolders)
			.set({ createdByAuthUuid: null })
			.where(eq(mediaLibraryFolders.createdByAuthUuid, uuid))
		await tx
			.update(mediaLibraryNotes)
			.set({ createdByAuthUuid: null })
			.where(eq(mediaLibraryNotes.createdByAuthUuid, uuid))
		await tx
			.update(mediaLibraryNotes)
			.set({ updatedByAuthUuid: null })
			.where(eq(mediaLibraryNotes.updatedByAuthUuid, uuid))

		if (supportChatIds.length > 0) {
			await tx.delete(messages).where(inArray(messages.chatId, supportChatIds))
			await tx.delete(chatMembers).where(inArray(chatMembers.chatId, supportChatIds))
			await tx.delete(chats).where(inArray(chats.id, supportChatIds))
		}

		await tx.delete(messageReactions).where(eq(messageReactions.userAuthUuid, uuid))
		await tx.delete(messageMentions).where(eq(messageMentions.mentionedUserAuthUuid, uuid))
		await tx.delete(messages).where(eq(messages.userAuthUuid, uuid))
		await tx.delete(chatMembers).where(eq(chatMembers.userAuthUuid, uuid))
		await tx.delete(chatNotificationSettings).where(eq(chatNotificationSettings.userAuthUuid, uuid))
		await tx.delete(scheduledChatMessages).where(eq(scheduledChatMessages.authorAuthUuid, uuid))

		await tx.delete(feedPostReactions).where(eq(feedPostReactions.userAuthUuid, uuid))
		await tx.delete(feedPostDrafts).where(eq(feedPostDrafts.authorAuthUuid, uuid))
		await tx.delete(feedPosts).where(eq(feedPosts.authorAuthUuid, uuid))
		await tx.delete(channelReactions).where(eq(channelReactions.userAuthUuid, uuid))
		await tx.delete(channelPosts).where(eq(channelPosts.authorAuthUuid, uuid))

		await tx.delete(materialCommentReactions).where(eq(materialCommentReactions.userAuthUuid, uuid))
		await tx.delete(materialComments).where(eq(materialComments.userAuthUuid, uuid))
		await tx.delete(materialMediaProgress).where(eq(materialMediaProgress.userAuthUuid, uuid))

		await tx.delete(pushSubscriptions).where(eq(pushSubscriptions.userAuthUuid, uuid))
		await tx.delete(pushNotifications).where(eq(pushNotifications.userAuthUuid, uuid))
		await tx.delete(bonusTransactions).where(eq(bonusTransactions.userAuthUuid, uuid))
		await tx.delete(clubMissions).where(eq(clubMissions.userAuthUuid, uuid))
		await tx
			.delete(referrals)
			.where(whereAny([eq(referrals.referrerUuid, uuid), eq(referrals.referredUuid, uuid)]))
		await tx.delete(paymentLogs).where(whereAny(paymentLogConditions))
		await tx.delete(payments).where(eq(payments.userAuthUuid, uuid))
		await tx.delete(users).where(eq(users.authUuid, uuid))
	})

	await deleteRedisKeysByPattern(redis, `refresh:${uuid}:*`)
	await invalidateUserAccessCaches(uuid)
	clearChatAccessCaches()

	await appendAdminActivityLog({
		actorAuthUuid: actorUserId,
		action: 'delete',
		entityType: 'user',
		entityId: uuid,
		summary: `Удалён пользователь ${target.fullName || target.email || uuid}`,
		details: {
			authUuid: uuid,
			email: target.email,
			phone: target.phone,
			role: target.role,
		},
	})

	return c.json({ success: true, data: { deleted: true } })
})

const adminSetUserPasswordSchema = z.object({
	password: z.string().min(8).max(128),
})

adminRoutes.patch(
	'/users/:uuid/password',
	zValidator('json', adminSetUserPasswordSchema),
	async (c) => {
		const uuid = c.req.param('uuid')
		const actorUserId = c.get('userId')
		const actorRole = c.get('userRole')
		const { password } = c.req.valid('json')
		if (actorRole !== 'superadmin') {
			const target = await db.query.users.findFirst({
				where: eq(users.authUuid, uuid),
				columns: { role: true },
			})
			if (target?.role === 'admin' || target?.role === 'superadmin') {
				return c.json(
					{
						success: false,
						error: { code: 'FORBIDDEN', message: 'Недостаточно прав доступа' },
					},
					403,
				)
			}
		}
		const passwordHash = await Bun.password.hash(password, { algorithm: 'bcrypt', cost: 12 })

		const [updated] = await db
			.update(users)
			.set({ passwordHash })
			.where(eq(users.authUuid, uuid))
			.returning({
				authUuid: users.authUuid,
			})

		if (!updated) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
				404,
			)
		}

		await appendAdminActivityLog({
			actorAuthUuid: actorUserId,
			action: 'password',
			entityType: 'user',
			entityId: uuid,
			summary: 'Изменён пароль пользователя',
			details: { uuid },
		})

		return c.json({ success: true, data: { message: 'Пароль сохранён' } })
	},
)

// Обновить платёжные данные (admin)
const adminUpdatePaymentSchema = z.object({
	dateStart: z.string().optional(),
	dateFinish: z.string().optional(),
	tarrif: z.string().optional(),
	autoPayment: z.boolean().optional(),
})

adminRoutes.patch(
	'/users/:uuid/payment',
	zValidator('json', adminUpdatePaymentSchema),
	async (c) => {
		const actorUserId = c.get('userId')
		const uuid = c.req.param('uuid')
		const body = c.req.valid('json')
		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, uuid),
			columns: {
				authUuid: true,
				email: true,
				phone: true,
				role: true,
			},
		})

		if (!user) {
			return c.json(
				{
					success: false,
					error: { code: 'NOT_FOUND', message: 'Пользователь не найден' },
				},
				404,
			)
		}

		const existing = await db.query.payments.findFirst({
			where: eq(payments.userAuthUuid, uuid),
		})

		if (
			body.autoPayment === false &&
			existing?.autoPayment &&
			existing.cpSubscriptionId &&
			(await hasCloudPaymentsCredentials())
		) {
			const result = await cancelRecurrent(existing.cpSubscriptionId)
			if (!result.Success) {
				logger.error({ result, uuid }, 'Failed to cancel subscription from admin')
				return c.json(
					{
						success: false,
						error: {
							code: 'INTERNAL_ERROR',
							message: 'Не удалось отменить автоплатёж в CloudPayments',
						},
					},
					500,
				)
			}
		}

		const normalizedDateStart = body.dateStart?.trim() ? body.dateStart : null
		const normalizedDateFinish = body.dateFinish?.trim() ? body.dateFinish : null
		const normalizedTariff = body.tarrif?.trim() ? body.tarrif : null
		const nextBody = {
			...(body.autoPayment !== undefined ? { autoPayment: body.autoPayment } : {}),
			...(body.dateStart !== undefined ? { dateStart: normalizedDateStart } : {}),
			...(body.dateFinish !== undefined ? { dateFinish: normalizedDateFinish } : {}),
			...(body.tarrif !== undefined ? { tarrif: normalizedTariff } : {}),
			noAutopodpiska: body.autoPayment === undefined ? undefined : body.autoPayment === false,
			email: user.email ?? existing?.email ?? null,
			phone: user.phone ?? existing?.phone ?? null,
		}

		const [updated] = existing
			? await db.update(payments).set(nextBody).where(eq(payments.userAuthUuid, uuid)).returning()
			: await db
					.insert(payments)
					.values({
						userAuthUuid: user.authUuid,
						autoPayment: false,
						noAutopodpiska: true,
						...nextBody,
					})
					.returning()

		if (user.role !== 'admin' && user.role !== 'superadmin') {
			await db
				.update(users)
				.set({
					role: 'user',
				})
				.where(eq(users.authUuid, uuid))
		}

		await invalidateUserAccessCaches(uuid)

		await appendAdminActivityLog({
			actorAuthUuid: actorUserId,
			action: 'update',
			entityType: 'user_payment',
			entityId: uuid,
			summary: 'Обновлены доступы и платёжные параметры пользователя',
			details: { uuid, changed: body },
		})

		return c.json({ success: true, data: updated })
	},
)

adminRoutes.post('/users/:uuid/payment-system/check', adminExternalCheckLimiter, async (c) => {
	const uuid = c.req.param('uuid')
	const actorUserId = c.get('userId')

	try {
		const result = await runCloudPaymentsCheck(uuid)
		const data = buildPaymentCheckResponse(result)
		if (!result || !data) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
				404,
			)
		}

		await appendAdminActivityLog({
			actorAuthUuid: actorUserId,
			action: 'check',
			entityType: 'user_payment',
			entityId: uuid,
			summary: 'Проверены платёжные данные пользователя',
			details: {
				userAuthUuid: uuid,
				hasPayment: Boolean(data.payment.date || data.payment.amount),
				hasSubscription: Boolean(data.subscription.id),
			},
		})

		return c.json({ success: true, data })
	} catch (error) {
		logger.error({ err: error, uuid }, 'Admin CloudPayments user check failed')
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Не удалось проверить платёжные данные. Попробуйте ещё раз.',
				},
			},
			500,
		)
	}
})

adminRoutes.post('/users/:uuid/payment-system/sync', adminExternalCheckLimiter, async (c) => {
	const uuid = c.req.param('uuid')
	const actorUserId = c.get('userId')

	try {
		const result = await runCloudPaymentsCheck(uuid)
		if (!result) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
				404,
			)
		}

		const proposed = result.proposedUpdate
		if (!proposed || result.cloudError) {
			return c.json(
				{
					success: false,
					error: {
						code: 'BAD_REQUEST',
						message: 'Нет данных для обновления подписки',
					},
				},
				400,
			)
		}

		const updatePayload = {
			...(proposed.dateStart ? { dateStart: proposed.dateStart } : {}),
			...(proposed.dateFinish ? { dateFinish: proposed.dateFinish } : {}),
			...(proposed.tarrif ? { tarrif: proposed.tarrif } : {}),
			...(proposed.amount != null ? { amount: proposed.amount } : {}),
			...(proposed.cpSubscriptionId ? { cpSubscriptionId: proposed.cpSubscriptionId } : {}),
			...(proposed.cpAccountId ? { cpAccountId: proposed.cpAccountId } : {}),
			...(proposed.autoPayment !== null
				? { autoPayment: proposed.autoPayment, noAutopodpiska: !proposed.autoPayment }
				: {}),
			paymentProvider: 'cloudpayments' as const,
			email: result.user.email ?? result.payment?.email ?? null,
			phone: result.user.phone ?? result.payment?.phone ?? null,
			updatedAt: new Date(),
		}

		const [updated] = result.payment
			? await db
					.update(payments)
					.set(updatePayload)
					.where(eq(payments.userAuthUuid, uuid))
					.returning()
			: await db
					.insert(payments)
					.values({
						userAuthUuid: result.user.authUuid,
						autoPayment: proposed.autoPayment ?? false,
						noAutopodpiska: proposed.autoPayment == null ? true : !proposed.autoPayment,
						...updatePayload,
					})
					.returning()

		await invalidateUserAccessCaches(uuid)

		await appendAdminActivityLog({
			actorAuthUuid: actorUserId,
			action: 'update',
			entityType: 'user_payment',
			entityId: uuid,
			summary: 'Платёжные данные пользователя обновлены после проверки',
			details: {
				userAuthUuid: uuid,
				changed: buildChangedFields(result.payment ?? null, updated),
			},
		})

		return c.json({
			success: true,
			data: { payment: updated, check: buildPaymentCheckResponse(result) },
		})
	} catch (error) {
		logger.error({ err: error, uuid }, 'Admin CloudPayments user sync failed')
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Не удалось обновить платёжные данные. Попробуйте ещё раз.',
				},
			},
			500,
		)
	}
})

// CRUD материалов
const createMaterialSchema = z.object({
	type: z.string(),
	title: z.string().min(1),
	telegramPostUrl: z.string().nullable().optional(),
	shortDescription: z.string().nullable().optional(),
	fullDescription: z.string().nullable().optional(),
	mediaType: z.enum(['video', 'audio', 'image', 'text', 'document']).nullable().optional(),
	storagePath: z.string().optional(),
	durationSeconds: z.number().optional(),
	fileSizeBytes: z.number().optional(),
	subsection: z.string().nullable().optional(),
	active: z.boolean().optional(),
	commentsEnabled: z.boolean().optional(),
	imageUrl: z.string().nullable().optional(),
	videoCoverUrl: z.string().nullable().optional(),
})

function normalizeMaterialDescription(value: string | null | undefined) {
	if (typeof value !== 'string') return null
	const trimmed = value.trim()
	return trimmed ? trimmed : null
}

function normalizeMaterialPayload<T extends Record<string, unknown>>(body: T): T {
	const next = { ...body }
	const shortDescription = normalizeMaterialDescription(
		typeof next.shortDescription === 'string' || next.shortDescription === null
			? (next.shortDescription as string | null)
			: undefined,
	)
	const fullDescription = normalizeMaterialDescription(
		typeof next.fullDescription === 'string' || next.fullDescription === null
			? (next.fullDescription as string | null)
			: undefined,
	)

	if ('shortDescription' in next) {
		next.shortDescription =
			shortDescription &&
			fullDescription &&
			shortDescription.replace(/\s+/g, ' ') === fullDescription.replace(/\s+/g, ' ')
				? null
				: shortDescription
	}

	if ('fullDescription' in next) {
		next.fullDescription = fullDescription
	}

	if ('subsection' in next) {
		next.subsection =
			typeof next.subsection === 'string' ? next.subsection.trim() || null : next.subsection
	}

	if ('mediaType' in next && next.mediaType === '') {
		next.mediaType = null
	}

	if ('type' in next && typeof next.type === 'string') {
		next.type = normalizeMaterialTypeKey(next.type)
	}

	return next
}

async function loadAdminMaterialSubsections() {
	const presetRows = await db.query.materialSubsections.findMany({
		orderBy: [materialSubsections.title],
	})
	const materialRows = await db
		.selectDistinct({ subsection: materials.subsection })
		.from(materials)
		.where(sql`${materials.subsection} IS NOT NULL AND btrim(${materials.subsection}) <> ''`)
		.orderBy(materials.subsection)

	return [
		...new Set(
			[...presetRows.map((row) => row.title), ...materialRows.map((row) => row.subsection)]
				.map((value) => value?.trim())
				.filter((value): value is string => Boolean(value)),
		),
	]
		.filter((value): value is string => Boolean(value?.trim()))
		.sort((left, right) => left.localeCompare(right, 'ru', { sensitivity: 'base' }))
}

async function buildUniqueMaterialTypeKey(label: string) {
	const baseKey = buildMaterialTypeKey(label)
	const [materialRows, customRows] = await Promise.all([
		db.select({ key: materials.type }).from(materials).groupBy(materials.type),
		db.select({ key: materialTypes.key }).from(materialTypes),
	])
	const existingKeys = new Set([
		...DEFAULT_MATERIAL_TYPE_ENTRIES.map((row) => row.key),
		...materialRows.map((row) => normalizeMaterialTypeKey(row.key)),
		...customRows.map((row) => normalizeMaterialTypeKey(row.key)),
	])
	let nextKey = baseKey
	let suffix = 2
	while (existingKeys.has(nextKey)) {
		nextKey = `${baseKey}-${suffix}`
		suffix += 1
	}
	return nextKey
}

async function loadAdminMaterialTypes() {
	const [customRows, materialRows] = await Promise.all([
		db.query.materialTypes.findMany({ orderBy: [materialTypes.label] }),
		db
			.select({ type: materials.type, count: sql<number>`count(*)::int` })
			.from(materials)
			.groupBy(materials.type),
	])
	const customByKey = new Map(customRows.map((row) => [row.key, row]))
	const countByType = new Map<string, number>()
	for (const row of materialRows) {
		const key = normalizeMaterialTypeKey(row.type)
		countByType.set(key, (countByType.get(key) ?? 0) + (Number(row.count) || 0))
	}
	const defaultOrder = new Map(
		DEFAULT_MATERIAL_TYPE_ENTRIES.map((item, index) => [item.key, index]),
	)
	const keys = new Set([
		...DEFAULT_MATERIAL_TYPE_ENTRIES.map((item) => item.key),
		...customRows.map((row) => normalizeMaterialTypeKey(row.key)),
		...materialRows.map((row) => normalizeMaterialTypeKey(row.type)),
	])

	return [...keys]
		.map((key) => {
			const custom = customByKey.get(key)
			const defaultLabel = getDefaultMaterialTypeLabel(key)
			return {
				key,
				label: custom?.label && custom.label !== key ? custom.label : (defaultLabel ?? key),
				system: Boolean(defaultLabel),
				usedCount: countByType.get(key) ?? 0,
			}
		})
		.sort((left, right) => {
			const leftOrder = defaultOrder.get(left.key)
			const rightOrder = defaultOrder.get(right.key)
			if (typeof leftOrder === 'number' || typeof rightOrder === 'number') {
				return (leftOrder ?? Number.MAX_SAFE_INTEGER) - (rightOrder ?? Number.MAX_SAFE_INTEGER)
			}
			return left.label.localeCompare(right.label, 'ru', { sensitivity: 'base' })
		})
}

async function ensureMaterialType(key: string, label?: string) {
	const normalizedKey = normalizeMaterialTypeKey(key)
	if (!normalizedKey) return
	const existing = await db.query.materialTypes.findFirst({
		where: eq(materialTypes.key, normalizedKey),
		columns: { key: true },
	})
	if (existing) return
	await db.insert(materialTypes).values({
		key: normalizedKey,
		label: label?.trim() || getDefaultMaterialTypeLabel(normalizedKey) || normalizedKey,
	})
}

async function ensureMaterialSubsection(title: string) {
	const normalizedTitle = title.trim()
	if (!normalizedTitle) return
	const existing = await db.query.materialSubsections.findFirst({
		where: sql`lower(${materialSubsections.title}) = lower(${normalizedTitle})`,
		columns: { id: true },
	})
	if (existing) return
	await db.insert(materialSubsections).values({ title: normalizedTitle })
}

async function deleteMaterialSubsection(title: string) {
	const normalizedTitle = title.trim()
	if (!normalizedTitle) return false
	const matchSql = sql`lower(btrim(${materialSubsections.title})) = lower(${normalizedTitle})`
	const materialMatchSql = sql`lower(btrim(${materials.subsection})) = lower(${normalizedTitle})`

	const deletedRows = await db
		.delete(materialSubsections)
		.where(matchSql)
		.returning({ id: materialSubsections.id })

	await db.update(materials).set({ subsection: null }).where(materialMatchSql)
	return deletedRows.length > 0
}

adminRoutes.get('/material-subsections', async (c) => {
	const items = await loadAdminMaterialSubsections()
	return c.json({ success: true, data: items })
})

adminRoutes.post(
	'/material-subsections',
	zValidator('json', z.object({ title: z.string().trim().min(1).max(120) })),
	async (c) => {
		const userId = c.get('userId')
		const { title } = c.req.valid('json')
		await ensureMaterialSubsection(title)
		await invalidateHomeContentCaches()
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'create',
			entityType: 'material_subsection',
			entityId: title,
			summary: `Создан подраздел «${title.trim()}»`,
			details: { title: title.trim() },
		})
		return c.json({ success: true, data: await loadAdminMaterialSubsections() }, 201)
	},
)

adminRoutes.patch(
	'/material-subsections/:title',
	zValidator('json', z.object({ title: z.string().trim().min(1).max(120) })),
	async (c) => {
		const oldTitle = c.req.param('title').trim()
		const userId = c.get('userId')
		const { title } = c.req.valid('json')
		const nextTitle = title.trim()
		if (!oldTitle) {
			return c.json(
				{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Подраздел не найден' } },
				400,
			)
		}

		const oldMatchSql = sql`lower(btrim(${materialSubsections.title})) = lower(${oldTitle})`
		const materialMatchSql = sql`lower(btrim(${materials.subsection})) = lower(${oldTitle})`
		const existing = await db.query.materialSubsections.findFirst({
			where: sql`lower(btrim(${materialSubsections.title})) = lower(${nextTitle})`,
			columns: { id: true },
		})
		if (!existing) {
			await db.update(materialSubsections).set({ title: nextTitle }).where(oldMatchSql)
		}
		await db.update(materials).set({ subsection: nextTitle }).where(materialMatchSql)
		await ensureMaterialSubsection(nextTitle)
		await invalidateHomeContentCaches()
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'material_subsection',
			entityId: nextTitle,
			summary: `Переименован подраздел «${nextTitle}»`,
			details: { from: oldTitle, to: nextTitle },
		})
		return c.json({ success: true, data: await loadAdminMaterialSubsections() })
	},
)

adminRoutes.delete('/material-subsections/:title', async (c) => {
	const title = c.req.param('title')
	const userId = c.get('userId')
	const deleted = await deleteMaterialSubsection(title)
	if (!deleted) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Подраздел не найден' } },
			404,
		)
	}
	await invalidateHomeContentCaches()
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'delete',
		entityType: 'material_subsection',
		entityId: title,
		summary: `Удалён подраздел «${title.trim()}»`,
		details: { title: title.trim() },
	})
	return c.json({ success: true, data: await loadAdminMaterialSubsections() })
})

adminRoutes.get('/material-types', async (c) => {
	return c.json({ success: true, data: await loadAdminMaterialTypes() })
})

adminRoutes.post(
	'/material-types',
	zValidator('json', z.object({ label: z.string().trim().min(1).max(120) })),
	async (c) => {
		const userId = c.get('userId')
		const { label } = c.req.valid('json')
		const baseKey = buildMaterialTypeKey(label)
		const key = getDefaultMaterialTypeLabel(baseKey)
			? normalizeMaterialTypeKey(baseKey)
			: await buildUniqueMaterialTypeKey(label)
		await db
			.insert(materialTypes)
			.values({ key, label: label.trim() })
			.onConflictDoUpdate({
				target: materialTypes.key,
				set: { label: label.trim(), updatedAt: sql`excluded.updated_at` },
			})
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'create',
			entityType: 'material_type',
			entityId: key,
			summary: `Создан раздел «${label.trim()}»`,
			details: { key, label: label.trim() },
		})
		return c.json({ success: true, data: await loadAdminMaterialTypes() }, 201)
	},
)

adminRoutes.patch(
	'/material-types/:key',
	zValidator('json', z.object({ label: z.string().trim().min(1).max(120) })),
	async (c) => {
		const key = normalizeMaterialTypeKey(c.req.param('key'))
		const userId = c.get('userId')
		const { label } = c.req.valid('json')
		if (!key) {
			return c.json(
				{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Раздел не найден' } },
				400,
			)
		}
		await db
			.insert(materialTypes)
			.values({ key, label: label.trim(), updatedAt: new Date() })
			.onConflictDoUpdate({
				target: materialTypes.key,
				set: { label: label.trim(), updatedAt: sql`excluded.updated_at` },
			})
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'material_type',
			entityId: key,
			summary: `Переименован раздел «${label.trim()}»`,
			details: { key, label: label.trim() },
		})
		return c.json({ success: true, data: await loadAdminMaterialTypes() })
	},
)

adminRoutes.delete('/material-types/:key', async (c) => {
	const key = normalizeMaterialTypeKey(c.req.param('key'))
	const userId = c.get('userId')
	if (getDefaultMaterialTypeLabel(key)) {
		return c.json(
			{
				success: false,
				error: { code: 'VALIDATION_ERROR', message: 'Базовый раздел нельзя удалить' },
			},
			400,
		)
	}
	await db.delete(materialTypes).where(eq(materialTypes.key, key))
	const fallback = await db.query.materialTypes.findFirst({
		where: ne(materialTypes.key, key),
		orderBy: [materialTypes.label],
		columns: { key: true },
	})
	if (fallback?.key) {
		await db.update(materials).set({ type: fallback.key }).where(eq(materials.type, key))
	}
	await invalidateHomeContentCaches()
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'delete',
		entityType: 'material_type',
		entityId: key,
		summary: `Удалён раздел «${key}»`,
		details: { key },
	})
	return c.json({ success: true, data: await loadAdminMaterialTypes() })
})

adminRoutes.get('/materials', async (c) => {
	const items = await db.query.materials.findMany({
		orderBy: [desc(materials.createdAt), desc(materials.id)],
	})

	return c.json({
		success: true,
		data: items.map((item) => ({
			...item,
			type: normalizeMaterialTypeKey(item.type),
			imageUrl: resolvePublicFileUrl('media', item.imageUrl) ?? null,
			videoCoverUrl: resolvePublicFileUrl('media', item.videoCoverUrl) ?? null,
			storageFiles: parseStoredMediaFiles(item.storagePath).map((file) => ({
				...file,
				url: resolvePublicFileUrl('media', file.url ?? file.path) ?? file.url ?? file.path ?? '',
			})),
		})),
	})
})

adminRoutes.post('/materials', zValidator('json', createMaterialSchema), async (c) => {
	const userId = c.get('userId')
	const body = normalizeMaterialPayload(c.req.valid('json'))
	if (typeof body.type === 'string' && body.type.trim()) {
		await ensureMaterialType(body.type)
	}
	if (typeof body.subsection === 'string' && body.subsection.trim()) {
		await ensureMaterialSubsection(body.subsection)
	}
	const [item] = await db.insert(materials).values(body).returning()
	await invalidateHomeContentCaches()
	await appendAdminActivityLog({
		actorAuthUuid: userId,
		action: 'create',
		entityType: 'material',
		entityId: item.id,
		summary: `Создан материал «${item.title}»`,
		details: {
			title: item.title,
			type: item.type,
			subsection: item.subsection,
			mediaType: item.mediaType,
		},
	})
	return c.json({ success: true, data: item }, 201)
})

adminRoutes.patch(
	'/materials/:id',
	zValidator('json', createMaterialSchema.partial()),
	async (c) => {
		const userId = c.get('userId')
		const id = Number(c.req.param('id'))
		const before = await db.query.materials.findFirst({
			where: eq(materials.id, id),
		})
		const body = normalizeMaterialPayload(c.req.valid('json'))
		if (typeof body.type === 'string' && body.type.trim()) {
			await ensureMaterialType(body.type)
		}
		if (typeof body.subsection === 'string' && body.subsection.trim()) {
			await ensureMaterialSubsection(body.subsection)
		}

		const [updated] = await db.update(materials).set(body).where(eq(materials.id, id)).returning()
		if (!updated) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
				404,
			)
		}

		await invalidateHomeContentCaches()
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'update',
			entityType: 'material',
			entityId: id,
			summary: `Обновлён материал «${updated.title}»`,
			details: {
				changed: buildChangedFields(before ?? null, updated),
			},
		})
		return c.json({ success: true, data: updated })
	},
)

adminRoutes.delete('/materials/:id', async (c) => {
	const id = Number(c.req.param('id'))
	const userId = c.get('userId')
	const existing = await db.query.materials.findFirst({
		where: eq(materials.id, id),
		columns: { id: true, title: true, type: true },
	})
	await db.delete(materials).where(eq(materials.id, id))
	await invalidateHomeContentCaches()
	if (existing) {
		await appendAdminActivityLog({
			actorAuthUuid: userId,
			action: 'delete',
			entityType: 'material',
			entityId: existing.id,
			summary: `Удалён материал «${existing.title}»`,
			details: existing,
		})
	}
	return c.json({ success: true, data: { deleted: true } })
})

adminRoutes.get(
	'/material-comments/feed',
	zValidator('query', cursorPaginationSchema),
	async (c) => {
		const { cursor, limit } = c.req.valid('query')
		const conditions = [eq(materialComments.isDeleted, false)]
		if (cursor) {
			conditions.push(sql`${materialComments.id} < ${Number(cursor)}`)
		}

		const items = await db.query.materialComments.findMany({
			where: and(...conditions),
			orderBy: [desc(materialComments.id)],
			limit: limit * 3,
			with: {
				author: {
					columns: {
						authUuid: true,
						fullName: true,
						username: true,
						avatarUrl: true,
						role: true,
					},
				},
				material: {
					columns: {
						id: true,
						type: true,
						title: true,
					},
				},
			},
		})

		const data = items.slice(0, limit)
		const commentIds = data.map((item) => item.id)
		const replyRows =
			commentIds.length > 0
				? await db.query.materialComments.findMany({
						where: and(
							eq(materialComments.isDeleted, false),
							inArray(materialComments.parentCommentId, commentIds),
						),
						columns: {
							id: true,
							parentCommentId: true,
						},
					})
				: []
		const repliesCountByParent = new Map<number, number>()
		for (const row of replyRows) {
			if (!row.parentCommentId) continue
			repliesCountByParent.set(
				row.parentCommentId,
				(repliesCountByParent.get(row.parentCommentId) ?? 0) + 1,
			)
		}

		const nextCursor =
			items.length > limit && data.length > 0 ? String(data[data.length - 1].id) : null

		return c.json({
			success: true,
			data: {
				items: data.map((item) => ({
					id: item.id,
					materialId: item.materialId,
					materialType: item.material?.type ?? '',
					materialTitle: item.material?.title ?? 'Материал',
					parentCommentId: item.parentCommentId,
					content: item.content,
					createdAt: item.createdAt,
					author: {
						...item.author,
						avatarUrl: resolveAvatarUrl(item.author?.avatarUrl),
					},
					reactions: [],
					repliesCount: repliesCountByParent.get(item.id) ?? 0,
				})),
				nextCursor,
			},
		})
	},
)

adminRoutes.post(
	'/material-comments/:commentId/reply',
	zValidator('json', z.object({ content: z.string().trim().min(1).max(4000) })),
	async (c) => {
		const commentId = Number(c.req.param('commentId'))
		const userId = c.get('userId')
		const { content } = c.req.valid('json')

		const parent = await db.query.materialComments.findFirst({
			where: and(eq(materialComments.id, commentId), eq(materialComments.isDeleted, false)),
			columns: {
				id: true,
				materialId: true,
			},
		})

		if (!parent) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Комментарий не найден' } },
				404,
			)
		}

		const material = await db.query.materials.findFirst({
			where: eq(materials.id, parent.materialId),
			columns: {
				id: true,
				commentsEnabled: true,
			},
		})

		if (!material?.commentsEnabled) {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Комментарии для этого материала отключены' },
				},
				403,
			)
		}

		await db.insert(materialComments).values({
			materialId: parent.materialId,
			userAuthUuid: userId,
			parentCommentId: parent.id,
			content,
		})

		return c.json({ success: true, data: { created: true } }, 201)
	},
)

// Events CRUD (admin)
import { events } from '@community-club/shared'

const createAdminEventSchema = z.object({
	title: z.string().min(1),
	description: z.string().optional(),
	imageUrl: httpUrlSchema.nullable().optional(),
	eventDate: z.string(),
})

adminRoutes.get('/events', async (c) => {
	const items = await db.select().from(events).orderBy(events.eventDate)
	return c.json({ success: true, data: items })
})

adminRoutes.post('/events', zValidator('json', createAdminEventSchema), async (c) => {
	const body = c.req.valid('json')
	const [item] = await db
		.insert(events)
		.values({ ...body, eventDate: new Date(body.eventDate) })
		.returning()
	await invalidateHomeContentCaches()
	return c.json({ success: true, data: item }, 201)
})

adminRoutes.patch(
	'/events/:id',
	zValidator('json', createAdminEventSchema.partial()),
	async (c) => {
		const id = Number(c.req.param('id'))
		const body = c.req.valid('json')
		const updateData: Record<string, unknown> = { ...body }
		if (body.eventDate) {
			updateData.eventDate = new Date(body.eventDate)
		}

		const [updated] = await db.update(events).set(updateData).where(eq(events.id, id)).returning()
		if (!updated) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Событие не найдено' } },
				404,
			)
		}

		await invalidateHomeContentCaches()
		return c.json({ success: true, data: updated })
	},
)

adminRoutes.delete('/events/:id', async (c) => {
	const id = Number(c.req.param('id'))
	await db.delete(events).where(eq(events.id, id))
	await invalidateHomeContentCaches()
	return c.json({ success: true, data: { deleted: true } })
})

// Платежи — список всех
adminRoutes.get('/payments', zValidator('query', paginationSchema), async (c) => {
	const { page, pageSize } = c.req.valid('query')
	const offset = (page - 1) * pageSize

	const items = await db.query.payments.findMany({
		orderBy: [desc(payments.dateStart)],
		limit: pageSize,
		offset,
	})

	return c.json({
		success: true,
		data: items.map((item) => ({ ...item, cpToken: null })),
	})
})

// Payment logs
const userActionTypes = [
	'registration',
	'payment',
	'demo_access',
	'payment_error',
	'material_view',
	'material_complete',
] as const

const userActionsQuerySchema = paginationSchema.extend({
	type: z.enum(userActionTypes).optional(),
	q: z.string().trim().max(120).optional(),
})

type UserActionRow = {
	id: string
	type: (typeof userActionTypes)[number]
	userAuthUuid: string | null
	userName: string | null
	userEmail: string | null
	userPhone: string | null
	title: string
	description: string | null
	meta: Record<string, unknown> | null
	createdAt: Date
	__total: number
}

function userActionsSql(params: {
	whereSql: string
	limitParam: number
	offsetParam: number
}) {
	return `
WITH events AS (
	SELECT
		'registration:' || u.id::text AS id,
		'registration'::text AS type,
		u.auth_uuid AS user_auth_uuid,
		u.full_name AS user_name,
		u.email AS user_email,
		u.phone AS user_phone,
		'Регистрация' AS title,
		COALESCE(u.full_name, u.email, u.phone, 'Новый участник') AS description,
		jsonb_build_object('role', u.role) AS meta,
		u.created_at AS created_at
	FROM users u
	WHERE u.role = 'user'

	UNION ALL

	SELECT
		'payment:' || p.id::text AS id,
		CASE WHEN p.tarrif = $1 THEN 'demo_access' ELSE 'payment' END AS type,
		p.user_auth_uuid AS user_auth_uuid,
		u.full_name AS user_name,
		COALESCE(u.email, p.email) AS user_email,
		COALESCE(u.phone, p.phone) AS user_phone,
		CASE WHEN p.tarrif = $1 THEN 'Тестовый доступ' ELSE 'Оплата' END AS title,
		CASE
			WHEN p.tarrif = $1 THEN 'Пробный период до ' || COALESCE(p.date_finish::text, 'не указано')
			ELSE concat_ws(' · ', NULLIF(p.tarrif, ''), p.amount::text, p.payment_provider::text)
		END AS description,
		jsonb_build_object(
			'tariff', p.tarrif,
			'amount', p.amount,
			'provider', p.payment_provider,
			'dateStart', p.date_start,
			'dateFinish', p.date_finish,
			'autoPayment', p.auto_payment
		) AS meta,
		p.created_at AS created_at
	FROM payments p
	LEFT JOIN users u ON u.auth_uuid = p.user_auth_uuid

	UNION ALL

	SELECT
		'payment_error:' || l.id::text AS id,
		'payment_error'::text AS type,
		l.user_auth_uuid AS user_auth_uuid,
		u.full_name AS user_name,
		COALESCE(u.email, l.email) AS user_email,
		COALESCE(u.phone, l.phone) AS user_phone,
		'Ошибка оплаты' AS title,
		COALESCE(l.error_message, l.status, l.event) AS description,
		jsonb_build_object(
			'event', l.event,
			'status', l.status,
			'amount', l.amount,
			'tariff', l.tariff,
			'provider', l.webhook_type,
			'orderId', l.order_id,
			'subscriptionId', l.subscription_id
		) AS meta,
		l.created_at AS created_at
	FROM payment_logs l
	LEFT JOIN users u ON u.auth_uuid = l.user_auth_uuid
	WHERE l.error_message IS NOT NULL
		OR l.status IN ('failed', 'rejected', 'critical')

	UNION ALL

	SELECT
		'material:' || mp.id::text AS id,
		CASE WHEN mp.completed THEN 'material_complete' ELSE 'material_view' END AS type,
		mp.user_auth_uuid AS user_auth_uuid,
		u.full_name AS user_name,
		u.email AS user_email,
		u.phone AS user_phone,
		CASE WHEN mp.completed THEN 'Материал завершён' ELSE 'Просмотр материала' END AS title,
		m.title AS description,
		jsonb_build_object(
			'materialId', mp.material_id,
			'mediaFileIndex', mp.media_file_index,
			'positionSeconds', mp.position_seconds,
			'durationSeconds', mp.duration_seconds,
			'completed', mp.completed
		) AS meta,
		mp.updated_at AS created_at
	FROM material_media_progress mp
	LEFT JOIN users u ON u.auth_uuid = mp.user_auth_uuid
	LEFT JOIN materials m ON m.id = mp.material_id
)
SELECT
	id,
	type,
	user_auth_uuid AS "userAuthUuid",
	user_name AS "userName",
	user_email AS "userEmail",
	user_phone AS "userPhone",
	title,
	description,
	meta,
	created_at AS "createdAt",
	COUNT(*) OVER()::int AS "__total"
FROM events
${params.whereSql}
ORDER BY created_at DESC, id DESC
LIMIT $${params.limitParam}
OFFSET $${params.offsetParam}
`
}

adminRoutes.get('/user-actions', zValidator('query', userActionsQuerySchema), async (c) => {
	const { page, pageSize, q, type } = c.req.valid('query')
	const offset = (page - 1) * pageSize
	const params: unknown[] = [DEMO_ACCESS_TARIFF]
	const whereParts: string[] = []

	if (type) {
		params.push(type)
		whereParts.push(`type = $${params.length}`)
	}

	const normalizedQuery = q?.trim() ?? ''
	if (normalizedQuery) {
		params.push(`%${escapeLikePattern(normalizedQuery)}%`)
		const param = `$${params.length}`
		whereParts.push(`(
			title ILIKE ${param} ESCAPE '\\'
			OR COALESCE(description, '') ILIKE ${param} ESCAPE '\\'
			OR COALESCE(user_name, '') ILIKE ${param} ESCAPE '\\'
			OR COALESCE(user_email, '') ILIKE ${param} ESCAPE '\\'
			OR COALESCE(user_phone, '') ILIKE ${param} ESCAPE '\\'
		)`)
	}

	params.push(pageSize)
	const limitParam = params.length
	params.push(offset)
	const offsetParam = params.length

	const rows = await queryClient.unsafe<UserActionRow[]>(
		userActionsSql({
			whereSql: whereParts.length ? `WHERE ${whereParts.join(' AND ')}` : '',
			limitParam,
			offsetParam,
		}),
		params,
	)
	const total = Number(rows[0]?.__total ?? 0)

	return c.json({
		success: true,
		data: {
			items: rows.map(({ __total, ...item }) => item),
			total,
			page,
			pageSize,
			hasMore: offset + pageSize < total,
		},
	})
})

adminRoutes.get('/payment-logs', zValidator('query', paginationSchema), async (c) => {
	const { page, pageSize } = c.req.valid('query')
	const offset = (page - 1) * pageSize

	const items = await db.query.paymentLogs.findMany({
		orderBy: [desc(paymentLogs.createdAt)],
		limit: pageSize,
		offset,
	})

	return c.json({ success: true, data: items })
})

adminRoutes.get('/activity-logs', zValidator('query', paginationSchema), async (c) => {
	const { page, pageSize } = c.req.valid('query')
	const offset = (page - 1) * pageSize

	const items = await db.query.adminActivityLogs.findMany({
		orderBy: [desc(adminActivityLogs.createdAt), desc(adminActivityLogs.id)],
		limit: pageSize,
		offset,
	})

	return c.json({ success: true, data: items })
})
