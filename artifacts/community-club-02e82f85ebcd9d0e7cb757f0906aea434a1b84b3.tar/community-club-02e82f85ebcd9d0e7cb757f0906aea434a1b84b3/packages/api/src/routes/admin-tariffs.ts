import { pricingMatrix } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { eq } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { invalidateCachedNamespace } from '../lib/server-cache'
import { getPricingMatrixMap } from '../services/pricing.service'

export const adminTariffRoutes = new Hono<AppEnv>()

const pricingMatrixUpdateSchema = z.object({
	demoFirstMonthPrice: z.string().min(1),
	demoDays: z.number().int().nonnegative(),
	activeMonthPrice: z.string().min(1),
	formerMonthPrice: z.string().min(1),
	externalFirstMonthPrice: z.string().min(1),
	externalMonthPrice: z.string().min(1),
	active90DaysPrice: z.string().min(1),
	former90DaysPrice: z.string().min(1),
	external90DaysPrice: z.string().min(1),
	active365DaysPrice: z.string().min(1),
	former365DaysPrice: z.string().min(1),
	external365DaysPrice: z.string().min(1),
	foreignDemoFirstMonthPrice: z.string().min(1),
	foreignActiveMonthPrice: z.string().min(1),
	foreignFormerMonthPrice: z.string().min(1),
	foreignExternalFirstMonthPrice: z.string().min(1),
	foreignExternalMonthPrice: z.string().min(1),
	foreignActive90DaysPrice: z.string().min(1),
	foreignFormer90DaysPrice: z.string().min(1),
	foreignExternal90DaysPrice: z.string().min(1),
	foreignActive365DaysPrice: z.string().min(1),
	foreignFormer365DaysPrice: z.string().min(1),
	foreignExternal365DaysPrice: z.string().min(1),
})

adminTariffRoutes.get('/', async (c) => {
	return c.json({ success: true, data: await getPricingMatrixMap() })
})

adminTariffRoutes.patch('/:role', zValidator('json', pricingMatrixUpdateSchema), async (c) => {
	const role = c.req.param('role')
	if (role !== 'club') {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Неизвестный тариф' } },
			400,
		)
	}

	const body = c.req.valid('json')
	const [updated] = await db
		.update(pricingMatrix)
		.set({
			...body,
			updatedAt: new Date(),
		})
		.where(eq(pricingMatrix.role, role))
		.returning()

	if (!updated) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Тарифная матрица не найдена' } },
			404,
		)
	}

	await invalidateCachedNamespace('payments:tariffs')
	return c.json({ success: true, data: updated })
})
