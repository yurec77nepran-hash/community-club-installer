import { messengerConnections } from '@community-club/shared'
import { eq } from 'drizzle-orm'
import { Hono } from 'hono'
import type { AppEnv } from '../app'
import { db } from '../db/client'
import { upsertMessengerContact } from '../lib/messenger-contacts'

type LooseRecord = Record<string, unknown>

function record(value: unknown): LooseRecord {
	return value && typeof value === 'object' ? (value as LooseRecord) : {}
}

function text(value: unknown) {
	return typeof value === 'string' || typeof value === 'number' ? String(value).trim() : ''
}

async function loadConnection(id: number, provider: 'vk' | 'max') {
	if (!Number.isInteger(id)) return null
	const connection = await db.query.messengerConnections.findFirst({
		where: eq(messengerConnections.id, id),
	})
	return connection?.provider === provider ? connection : null
}

export const messengerWebhookRoutes = new Hono<AppEnv>()

messengerWebhookRoutes.post('/vk/:id', async (c) => {
	const connection = await loadConnection(Number(c.req.param('id')), 'vk')
	if (!connection) return c.text('ok')
	const body = (await c.req.json()) as LooseRecord
	const config = connection.config
	if (config.callbackSecret && text(body.secret) !== config.callbackSecret) return c.text('ok')
	if (body.type === 'confirmation') return c.text(config.confirmationCode || 'ok')

	const object = record(body.object)
	const message = record(object.message)
	const externalUserId = text(message.from_id || object.user_id)
	if (!externalUserId) return c.text('ok')
	await upsertMessengerContact({
		connectionId: connection.id,
		provider: 'vk',
		consentStatus: body.type === 'message_deny' ? 'revoked' : 'active',
		profile: {
			externalUserId,
			profile: { sourceEvent: text(body.type) },
		},
	})
	return c.text('ok')
})

messengerWebhookRoutes.post('/max/:id', async (c) => {
	const connection = await loadConnection(Number(c.req.param('id')), 'max')
	if (!connection) return c.json({ ok: true })
	if (
		connection.webhookSecret &&
		c.req.header('x-max-bot-api-secret') !== connection.webhookSecret
	) {
		return c.json({ ok: false, error: 'Invalid webhook secret' }, 401)
	}
	const body = (await c.req.json()) as LooseRecord
	const message = record(body.message)
	const user = record(body.user || message.sender || message.from)
	const externalUserId = text(user.user_id || body.user_id)
	if (!externalUserId) return c.json({ ok: true })
	const firstName = text(user.first_name || user.name)
	const lastName = text(user.last_name)
	await upsertMessengerContact({
		connectionId: connection.id,
		provider: 'max',
		consentStatus:
			body.update_type === 'bot_stopped' || body.update_type === 'dialog_removed'
				? 'revoked'
				: 'active',
		profile: {
			externalUserId,
			displayName: [firstName, lastName].filter(Boolean).join(' ') || null,
			username: text(user.username) || null,
			profile: { sourceEvent: text(body.update_type) },
		},
	})
	return c.json({ ok: true })
})
