import { createReadStream } from 'node:fs'
import { unlink } from 'node:fs/promises'
import type { Readable } from 'node:stream'
import { GetObjectCommand } from '@aws-sdk/client-s3'
import { materials } from '@community-club/shared'
import { eq } from 'drizzle-orm'
import { type Context, Hono } from 'hono'
import type { AppEnv } from '../app'
import { env } from '../config/env'
import { db } from '../db/client'
import { appendAdminActivityLog } from '../lib/admin-activity'
import { ensureChatAccess } from '../lib/chat-access'
import {
	assertChunkedUploadComplete,
	createChunkedUploadReadStream,
	createChunkedUploadSession,
	deleteChunkedUploadSession,
	listReceivedChunkIndexes,
	readChunkedUploadSession,
	writeChunkedUploadPart,
} from '../lib/chunked-upload-temp'
import { logger } from '../lib/logger'
import { hasTypeAccess } from '../lib/materials-access'
import { findMediaLibraryFolderById, moveMediaLibraryItem } from '../lib/media-library'
import { getMediaUploadBucketAccess } from '../lib/media-upload-access'
import { isPdfUpload, optimizePdfBuffer } from '../lib/pdf'
import { UploadBodyTooLargeError, writeUploadBodyToTempFile } from '../lib/raw-upload-temp'
import {
	extractMaterialStorageKey,
	findPrimaryStoredMediaFile,
	getBucketForMediaType,
	getPublicUrl,
	getSignedFileUrl,
	isStoredMediaFileDownloadable,
	parseStoredMediaFiles,
	resolvePublicFileUrl,
	s3,
	uploadFile,
} from '../lib/storage'
import { isFaststartVideoCandidate, prepareVideoUploadForStreaming } from '../lib/video-faststart'
import { activeSubscriptionMiddleware, adminMiddleware, authMiddleware } from '../middleware/auth'
import { uploadQueueMiddleware } from '../middleware/queue'

export const mediaRoutes = new Hono<AppEnv>()

mediaRoutes.get('/avatar/:key', async (c) => {
	const key = c.req.param('key')
	if (!key) {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Некорректный ключ аватара' } },
			400,
		)
	}

	try {
		const object = await s3.send(
			new GetObjectCommand({
				Bucket: env.S3_BUCKET_AVATARS,
				Key: key,
			}),
		)

		if (!object.Body) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Аватар не найден' } },
				404,
			)
		}

		const body =
			typeof object.Body.transformToWebStream === 'function'
				? object.Body.transformToWebStream()
				: object.Body
		const headers = new Headers({
			'Content-Type': object.ContentType ?? 'application/octet-stream',
			'Cache-Control': 'public, max-age=3600, stale-while-revalidate=86400',
		})
		if (object.ContentLength) {
			headers.set('Content-Length', String(object.ContentLength))
		}

		return new Response(body as BodyInit, { headers })
	} catch {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Аватар не найден' } },
			404,
		)
	}
})

mediaRoutes.use('*', authMiddleware, activeSubscriptionMiddleware)

const IMAGE_EXTENSIONS = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif', 'heic', 'heif'])
const VIDEO_EXTENSIONS = new Set(['mp4', 'mov', 'm4v', 'webm'])
const AUDIO_EXTENSIONS = new Set(['ogg', 'oga', 'mp3', 'm4a', 'aac', 'wav', 'flac', 'opus'])
const MULTIPART_UPLOAD_MAX_BYTES = 64 * 1024 * 1024
const RAW_UPLOAD_MAX_BYTES = 3 * 1024 * 1024 * 1024
const CHAT_UPLOAD_MAX_BYTES = 3 * 1024 * 1024 * 1024
const CHUNKED_UPLOAD_MIN_CHUNK_BYTES = 1024 * 1024
const CHUNKED_UPLOAD_MAX_CHUNK_BYTES = 16 * 1024 * 1024

function getFileExtension(fileName: string) {
	return fileName.split('.').pop()?.trim().toLowerCase() ?? ''
}

function formatUploadSize(bytes: number) {
	const units = ['Б', 'КБ', 'МБ', 'ГБ']
	let value = bytes
	let unitIndex = 0
	while (value >= 1024 && unitIndex < units.length - 1) {
		value /= 1024
		unitIndex += 1
	}
	const precision = value >= 10 || unitIndex === 0 ? 0 : 1
	return `${value.toFixed(precision)} ${units[unitIndex]}`
}

function getRequestContentLength(c: Context<AppEnv>) {
	const rawValue = c.req.header('content-length')
	if (!rawValue) return null
	const parsedValue = Number.parseInt(rawValue, 10)
	return Number.isFinite(parsedValue) && parsedValue >= 0 ? parsedValue : null
}

function sanitizeUploadLogString(value: unknown, maxLength = 220) {
	if (typeof value !== 'string') return null
	const sanitized = value.replace(/[\r\n\t]/g, ' ').trim()
	return sanitized ? sanitized.slice(0, maxLength) : null
}

function getUploadLogNumber(value: unknown) {
	if (typeof value === 'number' && Number.isFinite(value)) return value
	if (typeof value === 'string' && value.trim()) {
		const parsedValue = Number(value)
		if (Number.isFinite(parsedValue)) return parsedValue
	}
	return null
}

function getUploadLogBoolean(value: unknown) {
	return typeof value === 'boolean' ? value : null
}

function getUploadRequestLogContext(c: Context<AppEnv>) {
	return {
		userId: c.get('userId'),
		userEmail: c.get('userEmail'),
		userRole: c.get('userRole'),
		userAgent: sanitizeUploadLogString(c.req.header('user-agent'), 300),
		clientIp: sanitizeUploadLogString(
			c.req.header('x-forwarded-for') ?? c.req.header('x-real-ip'),
			120,
		),
	}
}

function uploadTooLargeResponse(
	c: Context<AppEnv>,
	maxBytes: number,
	contentLength: number | null,
	traceId?: string | null,
) {
	logger.warn(
		{
			...getUploadRequestLogContext(c),
			path: c.req.path,
			traceId,
			contentLength,
			maxBytes,
		},
		'Media upload rejected because body is too large',
	)

	return c.json(
		{
			success: false,
			error: {
				code: 'UPLOAD_TOO_LARGE',
				message: `Файл слишком большой. Максимальный размер: ${formatUploadSize(maxBytes)}.`,
			},
		},
		413,
	)
}

function getUploadMaxBytes(bucketParam: string | null | undefined) {
	return bucketParam === 'chat' ? CHAT_UPLOAD_MAX_BYTES : RAW_UPLOAD_MAX_BYTES
}

function uploadAccessErrorResponse(
	c: Context<AppEnv>,
	access: Extract<ReturnType<typeof getMediaUploadBucketAccess>, { ok: false }>,
) {
	return c.json(
		{ success: false, error: { code: access.code, message: access.message } },
		access.status,
	)
}

function inferStoredMediaFileType(
	file: { path?: string | null; url?: string | null; type?: string | null },
	fallbackType?: string | null,
): 'image' | 'video' | 'audio' | 'document' | 'text' {
	if (file.type === 'image' || file.type === 'video' || file.type === 'audio') return file.type
	if (file.type === 'text' || file.type === 'document') return file.type

	const source = file.path ?? file.url ?? ''
	const extension = getFileExtension(source)
	if (IMAGE_EXTENSIONS.has(extension)) return 'image'
	if (VIDEO_EXTENSIONS.has(extension)) return 'video'
	if (AUDIO_EXTENSIONS.has(extension)) return 'audio'

	if (fallbackType === 'image' || fallbackType === 'video' || fallbackType === 'audio') {
		return fallbackType
	}
	if (fallbackType === 'text') return 'text'
	return 'document'
}

function inferUploadMediaType(
	fileName: string,
	contentType: string | null | undefined,
): 'image' | 'video' | 'audio' | 'document' {
	const normalizedType = contentType?.trim().toLowerCase() ?? ''
	if (normalizedType.startsWith('image/')) return 'image'
	if (normalizedType.startsWith('video/')) return 'video'
	if (normalizedType.startsWith('audio/')) return 'audio'

	const extension = getFileExtension(fileName)
	if (IMAGE_EXTENSIONS.has(extension)) return 'image'
	if (VIDEO_EXTENSIONS.has(extension)) return 'video'
	if (AUDIO_EXTENSIONS.has(extension)) return 'audio'
	return 'document'
}

function resolveUploadContentType(
	fileName: string,
	contentType: string | null | undefined,
): string {
	const normalizedType = contentType?.trim().toLowerCase() ?? ''
	if (normalizedType) return normalizedType

	const extension = getFileExtension(fileName)
	switch (extension) {
		case 'jpg':
		case 'jpeg':
			return 'image/jpeg'
		case 'png':
			return 'image/png'
		case 'webp':
			return 'image/webp'
		case 'gif':
			return 'image/gif'
		case 'avif':
			return 'image/avif'
		case 'heic':
			return 'image/heic'
		case 'heif':
			return 'image/heif'
		case 'mp4':
			return 'video/mp4'
		case 'mov':
			return 'video/quicktime'
		case 'm4v':
			return 'video/x-m4v'
		case 'webm':
			return 'video/webm'
		case 'ogg':
		case 'oga':
			return 'audio/ogg'
		case 'mp3':
			return 'audio/mpeg'
		case 'm4a':
			return 'audio/mp4'
		case 'aac':
			return 'audio/aac'
		case 'wav':
			return 'audio/wav'
		case 'flac':
			return 'audio/flac'
		case 'opus':
			return 'audio/opus'
		case 'pdf':
			return 'application/pdf'
		default:
			return 'application/octet-stream'
	}
}

function decodeFileName(path: string, fallback: string) {
	const rawFileName = path.split('?')[0]?.split('/').pop()
	if (!rawFileName) return fallback

	try {
		return decodeURIComponent(rawFileName)
	} catch {
		return rawFileName
	}
}

type UploadFileBody = ArrayBuffer | Uint8Array | Buffer | Readable | ReadableStream<Uint8Array>

function parseOptionalFolderId(rawValue: string | null | undefined) {
	if (!rawValue?.trim()) return { ok: true as const, folderId: null }
	const folderId = Number.parseInt(rawValue.trim(), 10)
	if (!Number.isInteger(folderId) || folderId <= 0) {
		return { ok: false as const }
	}
	return { ok: true as const, folderId }
}

async function persistUploadedMedia(params: {
	c: Context<AppEnv>
	fileName: string
	contentType: string | null | undefined
	bucketParam: string | null | undefined
	folderIdRaw: string | null | undefined
	body: UploadFileBody
	size: number | null
	optimizePdf: boolean
	uploadRoute: 'multipart' | 'raw' | 'chunked'
	traceId?: string | null
}) {
	const { c, fileName, contentType, bucketParam, folderIdRaw } = params
	const userId = c.get('userId')
	const userRole = c.get('userRole')
	const parsedFolder = parseOptionalFolderId(folderIdRaw)

	if (!parsedFolder.ok) {
		return c.json(
			{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Некорректная папка' } },
			400,
		)
	}

	let bucket = env.S3_BUCKET_MEDIA
	if (bucketParam === 'avatars') bucket = env.S3_BUCKET_AVATARS
	else if (bucketParam === 'chat') bucket = env.S3_BUCKET_CHAT

	const folderId = parsedFolder.folderId
	const targetFolder =
		bucket === env.S3_BUCKET_MEDIA && folderId != null
			? await findMediaLibraryFolderById(folderId)
			: null

	if (bucket === env.S3_BUCKET_MEDIA && folderId != null && !targetFolder) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Папка не найдена' } },
			404,
		)
	}

	const timestamp = Date.now()
	const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_') || 'file'
	const mediaType = inferUploadMediaType(fileName, contentType)
	const resolvedContentType = resolveUploadContentType(fileName, contentType)
	const key = `${mediaType}/${timestamp}-${safeName}`
	let uploadBody = params.body
	let uploadedSize = params.size
	let cleanupPreparedVideo: (() => Promise<void>) | null = null

	try {
		if (
			params.optimizePdf &&
			params.body instanceof ArrayBuffer &&
			isPdfUpload(fileName, resolvedContentType)
		) {
			const optimizedBuffer = await optimizePdfBuffer({ buffer: params.body, fileName })
			uploadBody = optimizedBuffer
			uploadedSize = optimizedBuffer.byteLength
		}

		if (mediaType === 'video' && isFaststartVideoCandidate(fileName, resolvedContentType)) {
			const startedAt = Date.now()
			logger.info(
				{
					...getUploadRequestLogContext(c),
					traceId: params.traceId,
					route: params.uploadRoute,
					fileName: sanitizeUploadLogString(fileName),
					contentType: resolvedContentType,
					size: uploadedSize,
				},
				'Media video faststart preparation started',
			)

			const preparedVideo = await prepareVideoUploadForStreaming({
				fileName,
				body: uploadBody,
				size: uploadedSize,
			})
			uploadBody = preparedVideo.body
			uploadedSize = preparedVideo.size
			cleanupPreparedVideo = preparedVideo.cleanup

			logger.info(
				{
					...getUploadRequestLogContext(c),
					traceId: params.traceId,
					route: params.uploadRoute,
					fileName: sanitizeUploadLogString(fileName),
					contentType: resolvedContentType,
					size: uploadedSize,
					optimized: preparedVideo.optimized,
					durationMs: Date.now() - startedAt,
				},
				'Media video faststart preparation completed',
			)
		}

		logger.info(
			{
				...getUploadRequestLogContext(c),
				traceId: params.traceId,
				route: params.uploadRoute,
				bucket,
				key,
				fileName: sanitizeUploadLogString(fileName),
				contentType: resolvedContentType,
				mediaType,
				size: uploadedSize,
				folderId,
			},
			'Media upload storage write started',
		)

		await uploadFile(bucket, key, uploadBody, resolvedContentType, uploadedSize)

		logger.info(
			{
				...getUploadRequestLogContext(c),
				traceId: params.traceId,
				route: params.uploadRoute,
				bucket,
				key,
				fileName: sanitizeUploadLogString(fileName),
				contentType: resolvedContentType,
				mediaType,
				size: uploadedSize,
				folderId,
			},
			'Media upload storage write completed',
		)

		if (bucket === env.S3_BUCKET_MEDIA && folderId != null) {
			await moveMediaLibraryItem({ key, folderId, userId })
			if (userRole === 'admin' || userRole === 'superadmin') {
				await appendAdminActivityLog({
					actorAuthUuid: userId,
					action: 'upload',
					entityType: 'media_item',
					entityId: key,
					summary: `Загружен файл в папку «${targetFolder?.name ?? ''}»`,
					details: {
						key,
						folderId,
						folderName: targetFolder?.name ?? null,
						fileName,
						mediaType,
						size: uploadedSize,
					},
				})
			}
		} else if (
			bucket === env.S3_BUCKET_MEDIA &&
			(userRole === 'admin' || userRole === 'superadmin')
		) {
			await appendAdminActivityLog({
				actorAuthUuid: userId,
				action: 'upload',
				entityType: 'media_item',
				entityId: key,
				summary: 'Загружен файл в медиатеку',
				details: {
					key,
					fileName,
					mediaType,
					size: uploadedSize,
				},
			})
		}

		const url =
			bucketParam === 'avatars' ? resolvePublicFileUrl(bucket, key) : getPublicUrl(bucket, key)

		return c.json({
			success: true,
			data: {
				path: key,
				bucket,
				size: uploadedSize,
				contentType: resolvedContentType,
				mediaType,
				url,
			},
		})
	} catch (error) {
		logger.error(
			{
				err: error,
				...getUploadRequestLogContext(c),
				traceId: params.traceId,
				route: params.uploadRoute,
				bucket,
				key,
				fileName: sanitizeUploadLogString(fileName),
				contentType: resolvedContentType,
				size: uploadedSize,
				mediaType,
			},
			'Media upload failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Не удалось загрузить файл. Попробуйте ещё раз.',
				},
			},
			500,
		)
	} finally {
		if (cleanupPreparedVideo) {
			await cleanupPreparedVideo().catch((error) => {
				logger.warn(
					{
						err: error,
						...getUploadRequestLogContext(c),
						traceId: params.traceId,
						route: params.uploadRoute,
						fileName: sanitizeUploadLogString(fileName),
					},
					'Media video faststart temp cleanup failed',
				)
			})
		}
	}
}

function getDownloadFilename(params: {
	storedPath?: string
	displayName?: string
	mediaType?: string | null
	index: number
}) {
	if (params.displayName?.trim()) {
		return params.displayName.trim().slice(0, 255)
	}

	const fallbackExtension =
		params.mediaType === 'video'
			? 'mp4'
			: params.mediaType === 'audio'
				? 'mp3'
				: params.mediaType === 'image'
					? 'jpg'
					: params.mediaType === 'document'
						? 'pdf'
						: 'bin'
	const fallback = `file-${params.index + 1}.${fallbackExtension}`
	return params.storedPath ? decodeFileName(params.storedPath, fallback) : fallback
}

function encodeContentDispositionFilename(filename: string) {
	return encodeURIComponent(filename).replace(
		/['()*]/g,
		(char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`,
	)
}

function getAsciiDownloadFilenameFallback(filename: string) {
	const trimmed = filename.trim()
	const extensionMatch = trimmed.match(/\.([a-z0-9]{1,12})$/i)
	const extension = extensionMatch ? `.${extensionMatch[1].toLowerCase()}` : ''
	const rawBase = extension ? trimmed.slice(0, -extension.length) : trimmed
	const base = rawBase
		.normalize('NFKD')
		.replace(/\p{M}/gu, '')
		.replace(/[^\x20-\x7E]/g, '')
		.replace(/["\\]/g, '')
		.replace(/[^a-zA-Z0-9._-]+/g, '-')
		.replace(/-+/g, '-')
		.replace(/^[._-]+|[._-]+$/g, '')
		.slice(0, 120)

	return `${base || 'file'}${extension}`
}

function getAttachmentContentDisposition(filename: string) {
	const fallbackFilename = getAsciiDownloadFilenameFallback(filename)
	const encodedFilename = encodeContentDispositionFilename(filename)
	return `attachment; filename="${fallbackFilename}"; filename*=UTF-8''${encodedFilename}`
}

async function resolveStoredMediaFileUrl(params: {
	file: { path?: string | null; url?: string | null; type?: string | null }
	fallbackType?: string | null
}) {
	const storageKey = extractMaterialStorageKey(
		params.file.path ?? params.file.url ?? null,
		inferStoredMediaFileType(params.file, params.fallbackType),
	)
	if (!storageKey) return null
	if (storageKey.startsWith('http')) return storageKey
	return getSignedFileUrl(
		getBucketForMediaType(inferStoredMediaFileType(params.file, params.fallbackType)),
		storageKey,
		900,
	)
}

// Signed URL для медиа-контента (временная ссылка 15 мин)
mediaRoutes.get('/:materialId/url', async (c) => {
	const materialId = Number(c.req.param('materialId'))

	const material = await db.query.materials.findFirst({
		where: eq(materials.id, materialId),
	})
	if (!material?.storagePath) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'У вас нет доступа к разделу' },
			},
			403,
		)
	}

	const parsedFiles = parseStoredMediaFiles(material.storagePath)
	const inferredPrimaryFile =
		parsedFiles.find((file) => inferStoredMediaFileType(file, material.mediaType) !== 'document') ??
		null
	const effectiveMediaType =
		material.mediaType && material.mediaType !== 'document'
			? material.mediaType
			: inferStoredMediaFileType(inferredPrimaryFile ?? {}, material.mediaType)
	const primaryMediaFile =
		effectiveMediaType && effectiveMediaType !== 'document'
			? findPrimaryStoredMediaFile(material.storagePath, effectiveMediaType)
			: null
	const primaryFileUrl =
		effectiveMediaType && effectiveMediaType !== 'document'
			? extractMaterialStorageKey(material.storagePath, effectiveMediaType)
			: null

	try {
		const normalizedFiles = (
			await Promise.all(
				parsedFiles.map(async (file, index) => ({
					index,
					name: getDownloadFilename({
						storedPath: file.path ?? file.url,
						displayName: file.displayName,
						mediaType: inferStoredMediaFileType(file, material.mediaType),
						index,
					}),
					type: inferStoredMediaFileType(file, material.mediaType),
					url: await resolveStoredMediaFileUrl({
						file,
						fallbackType: material.mediaType,
					}),
					chapters: file.chapters,
					downloadable: isStoredMediaFileDownloadable(file),
					downloadUrl: isStoredMediaFileDownloadable(file)
						? `/api/media/${materialId}/download?index=${index}`
						: null,
				})),
			)
		).filter((file) => file.type)

		const url = !primaryFileUrl
			? null
			: primaryFileUrl.startsWith('http')
				? primaryFileUrl
				: await getSignedFileUrl(
						getBucketForMediaType(effectiveMediaType ?? 'document'),
						primaryFileUrl,
						900,
					)
		c.header('Cache-Control', 'private, max-age=300, stale-while-revalidate=600')

		return c.json({
			success: true,
			data: {
				url,
				mediaType: effectiveMediaType,
				downloadable: isStoredMediaFileDownloadable(primaryMediaFile?.file),
				downloadUrl: isStoredMediaFileDownloadable(primaryMediaFile?.file)
					? `/api/media/${materialId}/download?index=${primaryMediaFile.index}`
					: null,
				duration: material.durationSeconds,
				expiresIn: 900,
				files: normalizedFiles,
			},
		})
	} catch {
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Не удалось подготовить ссылку. Попробуйте ещё раз.',
				},
			},
			500,
		)
	}
})

mediaRoutes.get('/:materialId/download', async (c) => {
	const materialId = Number(c.req.param('materialId'))
	const fileIndex = Number(c.req.query('index') ?? '0')

	if (!Number.isInteger(fileIndex) || fileIndex < 0) {
		return c.json(
			{ success: false, error: { code: 'BAD_REQUEST', message: 'Некорректный индекс файла' } },
			400,
		)
	}

	const material = await db.query.materials.findFirst({
		where: eq(materials.id, materialId),
	})
	if (!material?.storagePath) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Материал не найден' } },
			404,
		)
	}

	const userRole = c.get('userRole')
	const contentSections = c.get('userContentSections')
	const clubAccess = c.get('clubAccess')
	if (!hasTypeAccess({ type: material.type, userRole, contentSections, clubAccess })) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'У вас нет доступа к разделу' },
			},
			403,
		)
	}

	const files = parseStoredMediaFiles(material.storagePath)
	const file = files[fileIndex]
	if (!file?.path) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Файл материала не найден' } },
			404,
		)
	}
	if (!isStoredMediaFileDownloadable(file)) {
		return c.json(
			{
				success: false,
				error: { code: 'FORBIDDEN', message: 'Скачивание этого файла отключено' },
			},
			403,
		)
	}

	const storageKey = extractMaterialStorageKey(file.path, file.type ?? material.mediaType)
	if (!storageKey || storageKey.startsWith('http')) {
		return c.redirect(resolvePublicFileUrl('media', file.path) ?? file.path)
	}

	try {
		const object = await s3.send(
			new GetObjectCommand({
				Bucket: getBucketForMediaType(file.type ?? material.mediaType ?? 'document'),
				Key: storageKey,
			}),
		)

		if (!object.Body) {
			return c.json(
				{ success: false, error: { code: 'NOT_FOUND', message: 'Файл материала не найден' } },
				404,
			)
		}

		const filename = getDownloadFilename({
			storedPath: file.path,
			displayName: file.displayName,
			mediaType: file.type ?? material.mediaType,
			index: fileIndex,
		})
		const body =
			typeof object.Body.transformToWebStream === 'function'
				? object.Body.transformToWebStream()
				: object.Body
		const headers = new Headers({
			'Content-Type': object.ContentType ?? 'application/octet-stream',
			'Content-Disposition': getAttachmentContentDisposition(filename),
			'Cache-Control': 'private, no-store',
		})
		if (object.ContentLength) {
			headers.set('Content-Length', String(object.ContentLength))
		}

		return new Response(body as BodyInit, {
			headers,
		})
	} catch (error) {
		logger.error(
			{
				err: error,
				materialId,
				fileIndex,
				filePath: file.path,
				mediaType: file.type ?? material.mediaType,
				storageKey,
			},
			'Material file download failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Не удалось скачать файл. Попробуйте ещё раз.',
				},
			},
			500,
		)
	}
})

mediaRoutes.post('/upload/trace', adminMiddleware, async (c) => {
	let payload: Record<string, unknown>
	try {
		payload = (await c.req.json()) as Record<string, unknown>
	} catch (error) {
		logger.warn(
			{ err: error, ...getUploadRequestLogContext(c) },
			'Admin media upload trace parse failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'VALIDATION_ERROR',
					message: 'Некорректная диагностика загрузки',
				},
			},
			400,
		)
	}

	const traceId = sanitizeUploadLogString(payload.traceId)
	logger.info(
		{
			...getUploadRequestLogContext(c),
			traceId,
			stage: sanitizeUploadLogString(payload.stage, 80),
			route: sanitizeUploadLogString(payload.route, 40),
			routeReason: sanitizeUploadLogString(payload.routeReason, 80),
			fileName: sanitizeUploadLogString(payload.fileName),
			fileSize: getUploadLogNumber(payload.fileSize),
			fileType: sanitizeUploadLogString(payload.fileType, 120),
			bucket: sanitizeUploadLogString(payload.bucket, 80),
			folderId: getUploadLogNumber(payload.folderId),
			rawThresholdBytes: getUploadLogNumber(payload.rawThresholdBytes),
			responseStatus: getUploadLogNumber(payload.responseStatus),
			responseEmptyBody: getUploadLogBoolean(payload.responseEmptyBody),
			success: getUploadLogBoolean(payload.success),
			errorCode: sanitizeUploadLogString(payload.errorCode, 100),
			errorMessage: sanitizeUploadLogString(payload.errorMessage, 300),
			durationMs: getUploadLogNumber(payload.durationMs),
		},
		'Admin media upload client trace',
	)

	return c.json({ success: true, data: { traceId } })
})

function parseChunkedUploadInitPayload(payload: Record<string, unknown>) {
	const fileName = typeof payload.fileName === 'string' ? payload.fileName.trim() : ''
	const fileSize = getUploadLogNumber(payload.fileSize)
	const contentType =
		typeof payload.contentType === 'string' && payload.contentType.trim()
			? payload.contentType.trim()
			: 'application/octet-stream'
	const chunkSize = getUploadLogNumber(payload.chunkSize)
	const bucketParam = typeof payload.bucket === 'string' ? payload.bucket.trim() || null : null
	const chatId = getUploadLogNumber(payload.chatId)
	const folderIdRaw =
		typeof payload.folderId === 'number' || typeof payload.folderId === 'string'
			? String(payload.folderId)
			: null
	const traceId = sanitizeUploadLogString(payload.traceId)

	if (!fileName || fileSize == null || fileSize <= 0 || chunkSize == null) {
		return { ok: false as const }
	}

	return {
		ok: true as const,
		fileName,
		fileSize,
		contentType,
		chunkSize,
		bucketParam,
		chatId: Number.isInteger(chatId) && chatId > 0 ? chatId : null,
		folderIdRaw,
		traceId,
	}
}

function getExpectedChunkSize(params: { fileSize: number; chunkSize: number; index: number }) {
	const start = params.index * params.chunkSize
	return Math.min(params.chunkSize, params.fileSize - start)
}

async function readOwnedChunkedUploadSession(c: Context<AppEnv>, uploadId: string) {
	const session = await readChunkedUploadSession(uploadId).catch(() => null)
	if (!session || session.metadata.userId !== c.get('userId')) return null
	return session
}

mediaRoutes.post('/upload/chunk/init', uploadQueueMiddleware(), async (c) => {
	let payload: Record<string, unknown>
	try {
		payload = (await c.req.json()) as Record<string, unknown>
	} catch {
		return c.json(
			{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Некорректная загрузка' } },
			400,
		)
	}

	const parsed = parseChunkedUploadInitPayload(payload)
	if (!parsed.ok) {
		return c.json(
			{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Некорректная загрузка' } },
			400,
		)
	}

	const uploadAccess = getMediaUploadBucketAccess({
		bucketParam: parsed.bucketParam,
		userRole: c.get('userRole'),
		uploadRoute: 'chunked',
	})
	if (!uploadAccess.ok) {
		return uploadAccessErrorResponse(c, uploadAccess)
	}

	const maxUploadBytes = getUploadMaxBytes(uploadAccess.bucketParam)
	if (parsed.fileSize > maxUploadBytes) {
		return uploadTooLargeResponse(c, maxUploadBytes, parsed.fileSize, parsed.traceId)
	}
	if (
		parsed.chunkSize < CHUNKED_UPLOAD_MIN_CHUNK_BYTES ||
		parsed.chunkSize > CHUNKED_UPLOAD_MAX_CHUNK_BYTES
	) {
		return c.json(
			{
				success: false,
				error: { code: 'VALIDATION_ERROR', message: 'Некорректный размер части файла' },
			},
			400,
		)
	}

	if (uploadAccess.bucketParam === 'chat') {
		if (!parsed.chatId) {
			return c.json(
				{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Некорректный чат' } },
				400,
			)
		}

		const access = await ensureChatAccess({
			chatId: parsed.chatId,
			userId: c.get('userId'),
			userRole: c.get('userRole') as Parameters<typeof ensureChatAccess>[0]['userRole'],
		})
		if (!access.ok) {
			const status = access.code === 'NOT_FOUND' ? 404 : 403
			return c.json(
				{ success: false, error: { code: access.code, message: access.message } },
				status,
			)
		}
		if (access.member?.status === 'muted') {
			return c.json(
				{
					success: false,
					error: { code: 'FORBIDDEN', message: 'Вы временно не можете писать в этот чат' },
				},
				403,
			)
		}
	}

	const session = await createChunkedUploadSession({
		userId: c.get('userId'),
		fileName: parsed.fileName,
		fileSize: parsed.fileSize,
		contentType: parsed.contentType,
		bucketParam: uploadAccess.bucketParam,
		folderIdRaw: parsed.folderIdRaw,
		chunkSize: parsed.chunkSize,
		traceId: parsed.traceId,
	})

	logger.info(
		{
			...getUploadRequestLogContext(c),
			route: 'chunked',
			traceId: parsed.traceId,
			uploadId: session.metadata.uploadId,
			fileName: sanitizeUploadLogString(parsed.fileName),
			fileSize: parsed.fileSize,
			contentType: sanitizeUploadLogString(parsed.contentType, 120),
			chunkSize: parsed.chunkSize,
			totalChunks: session.metadata.totalChunks,
			bucket: sanitizeUploadLogString(parsed.bucketParam, 80),
			folderId: sanitizeUploadLogString(parsed.folderIdRaw, 80),
		},
		'Media chunked upload session created',
	)

	return c.json({
		success: true,
		data: {
			uploadId: session.metadata.uploadId,
			chunkSize: session.metadata.chunkSize,
			totalChunks: session.metadata.totalChunks,
			receivedChunks: [],
		},
	})
})

mediaRoutes.post('/upload/chunk/:uploadId/part/:index', uploadQueueMiddleware(), async (c) => {
	const uploadId = c.req.param('uploadId')
	const index = Number.parseInt(c.req.param('index'), 10)
	const session = await readOwnedChunkedUploadSession(c, uploadId)
	if (!session || !Number.isInteger(index) || index < 0 || index >= session.metadata.totalChunks) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Загрузка не найдена' } },
			404,
		)
	}

	if (!c.req.raw.body) {
		return c.json(
			{
				success: false,
				error: { code: 'UPLOAD_BODY_ERROR', message: 'Не удалось прочитать часть файла' },
			},
			400,
		)
	}

	const expectedSize = getExpectedChunkSize({
		fileSize: session.metadata.fileSize,
		chunkSize: session.metadata.chunkSize,
		index,
	})
	const contentLength = getRequestContentLength(c)
	if (contentLength != null && contentLength !== expectedSize) {
		return c.json(
			{
				success: false,
				error: { code: 'UPLOAD_BODY_ERROR', message: 'Часть файла загрузилась не полностью' },
			},
			400,
		)
	}

	try {
		await writeChunkedUploadPart({
			metadata: session.metadata,
			index,
			body: c.req.raw.body,
		})
		const receivedChunks = await listReceivedChunkIndexes(uploadId)

		return c.json({
			success: true,
			data: {
				uploadId,
				index,
				size: expectedSize,
				receivedCount: receivedChunks.length,
				totalChunks: session.metadata.totalChunks,
			},
		})
	} catch (error) {
		logger.warn(
			{
				err: error,
				...getUploadRequestLogContext(c),
				route: 'chunked',
				traceId: session.metadata.traceId,
				uploadId,
				index,
				expectedSize,
				contentLength,
				fileName: sanitizeUploadLogString(session.metadata.fileName),
			},
			'Media chunked upload part failed',
		)
		return c.json(
			{
				success: false,
				error: { code: 'UPLOAD_READ_ERROR', message: 'Не удалось принять часть файла' },
			},
			400,
		)
	}
})

mediaRoutes.post('/upload/chunk/:uploadId/complete', uploadQueueMiddleware(), async (c) => {
	const uploadId = c.req.param('uploadId')
	const session = await readOwnedChunkedUploadSession(c, uploadId)
	if (!session) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Загрузка не найдена' } },
			404,
		)
	}

	try {
		await assertChunkedUploadComplete(session.metadata)
		logger.info(
			{
				...getUploadRequestLogContext(c),
				route: 'chunked',
				traceId: session.metadata.traceId,
				uploadId,
				fileName: sanitizeUploadLogString(session.metadata.fileName),
				fileSize: session.metadata.fileSize,
				chunkSize: session.metadata.chunkSize,
				totalChunks: session.metadata.totalChunks,
			},
			'Media chunked upload complete started',
		)

		const response = await persistUploadedMedia({
			c,
			fileName: session.metadata.fileName,
			contentType: session.metadata.contentType,
			bucketParam: session.metadata.bucketParam,
			folderIdRaw: session.metadata.folderIdRaw,
			body: createChunkedUploadReadStream(session.metadata),
			size: session.metadata.fileSize,
			optimizePdf: false,
			uploadRoute: 'chunked',
			traceId: session.metadata.traceId,
		})

		if (response.status < 400) {
			await deleteChunkedUploadSession(uploadId)
		}

		return response
	} catch (error) {
		logger.warn(
			{
				err: error,
				...getUploadRequestLogContext(c),
				route: 'chunked',
				traceId: session.metadata.traceId,
				uploadId,
				fileName: sanitizeUploadLogString(session.metadata.fileName),
			},
			'Media chunked upload complete failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'UPLOAD_BODY_ERROR',
					message: 'Файл загрузился не полностью. Попробуйте ещё раз.',
				},
			},
			400,
		)
	}
})

mediaRoutes.delete('/upload/chunk/:uploadId', uploadQueueMiddleware(), async (c) => {
	const uploadId = c.req.param('uploadId')
	const session = await readOwnedChunkedUploadSession(c, uploadId)
	if (session) {
		await deleteChunkedUploadSession(uploadId)
	}
	return c.json({ success: true, data: { uploadId } })
})

// Upload медиа (admin)
mediaRoutes.post('/upload', uploadQueueMiddleware(), async (c) => {
	const contentLength = getRequestContentLength(c)
	logger.info(
		{
			...getUploadRequestLogContext(c),
			route: 'multipart',
			contentLength,
		},
		'Media multipart upload request received',
	)
	if (contentLength != null && contentLength > MULTIPART_UPLOAD_MAX_BYTES) {
		return uploadTooLargeResponse(c, MULTIPART_UPLOAD_MAX_BYTES, contentLength)
	}

	let formData: FormData
	try {
		formData = await c.req.formData()
	} catch (error) {
		logger.warn(
			{
				err: error,
				...getUploadRequestLogContext(c),
				route: 'multipart',
				contentLength,
			},
			'Media multipart upload body parse failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'UPLOAD_BODY_ERROR',
					message: 'Не удалось прочитать файл. Попробуйте загрузить его ещё раз.',
				},
			},
			400,
		)
	}

	const file = formData.get('file') as File | null
	const bucketParam = formData.get('bucket') as string | null
	const folderIdRaw = formData.get('folderId') as string | null
	const traceId = sanitizeUploadLogString(formData.get('traceId'))

	if (!file) {
		logger.warn(
			{
				...getUploadRequestLogContext(c),
				route: 'multipart',
				traceId,
				contentLength,
			},
			'Media multipart upload missing file field',
		)
		return c.json(
			{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Файл не выбран' } },
			400,
		)
	}

	const uploadAccess = getMediaUploadBucketAccess({
		bucketParam,
		userRole: c.get('userRole'),
		uploadRoute: 'multipart',
	})
	if (!uploadAccess.ok) {
		return uploadAccessErrorResponse(c, uploadAccess)
	}

	logger.info(
		{
			...getUploadRequestLogContext(c),
			route: 'multipart',
			traceId,
			contentLength,
			fileName: sanitizeUploadLogString(file.name),
			fileSize: file.size,
			fileType: sanitizeUploadLogString(file.type, 120),
			bucket: sanitizeUploadLogString(bucketParam, 80),
			folderId: sanitizeUploadLogString(folderIdRaw, 80),
		},
		'Media multipart upload form parsed',
	)

	try {
		const originalBuffer = await file.arrayBuffer()
		return persistUploadedMedia({
			c,
			fileName: file.name,
			contentType: file.type,
			bucketParam: uploadAccess.bucketParam,
			folderIdRaw,
			body: originalBuffer,
			size: originalBuffer.byteLength,
			optimizePdf: true,
			uploadRoute: 'multipart',
			traceId,
		})
	} catch (error) {
		logger.error(
			{
				err: error,
				...getUploadRequestLogContext(c),
				route: 'multipart',
				traceId,
				fileName: sanitizeUploadLogString(file.name),
				contentLength,
			},
			'Media upload file read failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'UPLOAD_READ_ERROR',
					message: 'Не удалось подготовить файл к загрузке. Попробуйте ещё раз.',
				},
			},
			500,
		)
	}
})

// Потоковая загрузка больших медиа, чтобы видео не держать целиком в памяти API.
mediaRoutes.post('/upload/raw', uploadQueueMiddleware(), async (c) => {
	const fileName = c.req.query('fileName')?.trim()
	const traceId = sanitizeUploadLogString(c.req.query('traceId'))
	const bucketParam = c.req.query('bucket')?.trim() || null
	const folderIdRaw = c.req.query('folderId')?.trim() || null
	const contentType = c.req.header('content-type')
	const contentLength = getRequestContentLength(c)

	if (!fileName) {
		logger.warn(
			{
				...getUploadRequestLogContext(c),
				route: 'raw',
				traceId,
				contentLength,
				contentType: sanitizeUploadLogString(contentType, 120),
			},
			'Media raw upload missing fileName',
		)
		return c.json(
			{ success: false, error: { code: 'VALIDATION_ERROR', message: 'Файл не выбран' } },
			400,
		)
	}

	const uploadAccess = getMediaUploadBucketAccess({
		bucketParam,
		userRole: c.get('userRole'),
		uploadRoute: 'raw',
	})
	if (!uploadAccess.ok) {
		return uploadAccessErrorResponse(c, uploadAccess)
	}

	logger.info(
		{
			...getUploadRequestLogContext(c),
			route: 'raw',
			traceId,
			contentLength,
			fileName: sanitizeUploadLogString(fileName),
			contentType: sanitizeUploadLogString(contentType, 120),
			bucket: sanitizeUploadLogString(bucketParam, 80),
			folderId: sanitizeUploadLogString(folderIdRaw, 80),
		},
		'Media raw upload request received',
	)

	const maxUploadBytes = getUploadMaxBytes(uploadAccess.bucketParam)
	if (contentLength != null && contentLength > maxUploadBytes) {
		return uploadTooLargeResponse(c, maxUploadBytes, contentLength, traceId)
	}

	if (!c.req.raw.body) {
		logger.warn(
			{
				...getUploadRequestLogContext(c),
				route: 'raw',
				traceId,
				contentLength,
				fileName: sanitizeUploadLogString(fileName),
				contentType: sanitizeUploadLogString(contentType, 120),
			},
			'Media raw upload missing request body',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'UPLOAD_BODY_ERROR',
					message: 'Не удалось прочитать файл. Попробуйте загрузить его ещё раз.',
				},
			},
			400,
		)
	}

	let tempUploadPath: string | null = null

	try {
		logger.info(
			{
				...getUploadRequestLogContext(c),
				route: 'raw',
				traceId,
				contentLength,
				fileName: sanitizeUploadLogString(fileName),
			},
			'Media raw upload body buffering started',
		)

		const tempUpload = await writeUploadBodyToTempFile({
			body: c.req.raw.body,
			maxBytes: maxUploadBytes,
		})
		tempUploadPath = tempUpload.path

		logger.info(
			{
				...getUploadRequestLogContext(c),
				route: 'raw',
				traceId,
				contentLength,
				bufferedSize: tempUpload.size,
				fileName: sanitizeUploadLogString(fileName),
			},
			'Media raw upload body buffering completed',
		)

		if (contentLength != null && tempUpload.size !== contentLength) {
			logger.warn(
				{
					...getUploadRequestLogContext(c),
					route: 'raw',
					traceId,
					contentLength,
					bufferedSize: tempUpload.size,
					fileName: sanitizeUploadLogString(fileName),
				},
				'Media raw upload content length mismatch',
			)
			return c.json(
				{
					success: false,
					error: {
						code: 'UPLOAD_BODY_ERROR',
						message: 'Файл загрузился не полностью. Попробуйте ещё раз.',
					},
				},
				400,
			)
		}

		return await persistUploadedMedia({
			c,
			fileName,
			contentType,
			bucketParam: uploadAccess.bucketParam,
			folderIdRaw,
			body: createReadStream(tempUpload.path),
			size: tempUpload.size,
			optimizePdf: false,
			uploadRoute: 'raw',
			traceId,
		})
	} catch (error) {
		if (error instanceof UploadBodyTooLargeError) {
			return uploadTooLargeResponse(c, maxUploadBytes, error.bytesRead, traceId)
		}

		logger.error(
			{
				err: error,
				...getUploadRequestLogContext(c),
				route: 'raw',
				traceId,
				contentLength,
				fileName: sanitizeUploadLogString(fileName),
				contentType: sanitizeUploadLogString(contentType, 120),
			},
			'Media raw upload body buffering failed',
		)
		return c.json(
			{
				success: false,
				error: {
					code: 'UPLOAD_READ_ERROR',
					message: 'Не удалось прочитать файл. Попробуйте загрузить его ещё раз.',
				},
			},
			400,
		)
	} finally {
		if (tempUploadPath) {
			await unlink(tempUploadPath).catch((error) => {
				logger.warn(
					{
						err: error,
						...getUploadRequestLogContext(c),
						route: 'raw',
						traceId,
						fileName: sanitizeUploadLogString(fileName),
					},
					'Media raw upload temp file cleanup failed',
				)
			})
		}
	}
})
