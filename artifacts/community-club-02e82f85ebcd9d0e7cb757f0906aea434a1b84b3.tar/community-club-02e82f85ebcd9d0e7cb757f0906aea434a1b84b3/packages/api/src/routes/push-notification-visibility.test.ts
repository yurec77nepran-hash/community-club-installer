import { describe, expect, test } from 'bun:test'
import { readFileSync } from 'node:fs'

const pushRouteSource = readFileSync(new URL('./push.ts', import.meta.url), 'utf8')

describe('push notification visibility contract', () => {
	test('count and list reuse one visible notification context predicate', () => {
		// Given
		const predicateDeclaration = 'function visibleNotificationConditions(userId: string)'

		// When
		const predicateSource =
			pushRouteSource.match(
				/function visibleNotificationConditions\(userId: string\)[\s\S]*?\n}/,
			)?.[0] ?? ''
		const predicateUsages = pushRouteSource.match(/visibleNotificationConditions\(userId\)/g) ?? []

		// Then
		expect(pushRouteSource).toContain(predicateDeclaration)
		expect(predicateSource).toContain('eq(pushNotifications.userAuthUuid, userId)')
		expect(predicateSource).toContain("not(eq(pushNotifications.context, 'manual'))")
		expect(predicateSource).toContain("not(like(pushNotifications.context, 'campaign:%'))")
		expect(predicateUsages).toHaveLength(2)
	})
})
