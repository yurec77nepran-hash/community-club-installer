import { Hono } from 'hono'
import type { AppEnv } from '../app'
import {
	loadAppNavigationSettings,
	loadAuthLoginSettings,
	loadGuestContentAccessSettings,
	loadHomeExperienceSettings,
	loadLegalDocumentsSettings,
	loadSiteBrandingSettings,
	loadTelegramBotAuthSettings,
	loadTestAccessSettings,
} from '../lib/site-settings'

export const siteSettingsRoutes = new Hono<AppEnv>()

siteSettingsRoutes.get('/branding', async (c) => {
	return c.json({ success: true, data: await loadSiteBrandingSettings() })
})

siteSettingsRoutes.get('/auth-login', async (c) => {
	return c.json({ success: true, data: await loadAuthLoginSettings() })
})

siteSettingsRoutes.get('/test-access', async (c) => {
	return c.json({ success: true, data: await loadTestAccessSettings() })
})

siteSettingsRoutes.get('/guest-content-access', async (c) => {
	return c.json({ success: true, data: await loadGuestContentAccessSettings() })
})

siteSettingsRoutes.get('/telegram-bot-auth', async (c) => {
	return c.json({ success: true, data: await loadTelegramBotAuthSettings() })
})

siteSettingsRoutes.get('/legal-documents', async (c) => {
	return c.json({ success: true, data: await loadLegalDocumentsSettings() })
})

siteSettingsRoutes.get('/home-experience', async (c) => {
	return c.json({ success: true, data: await loadHomeExperienceSettings() })
})

siteSettingsRoutes.get('/app-navigation', async (c) => {
	return c.json({ success: true, data: await loadAppNavigationSettings() })
})
