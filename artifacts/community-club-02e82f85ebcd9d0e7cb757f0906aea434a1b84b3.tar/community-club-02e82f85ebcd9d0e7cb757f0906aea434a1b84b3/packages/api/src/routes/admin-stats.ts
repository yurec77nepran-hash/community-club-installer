import { paymentLogs } from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { desc, sql } from 'drizzle-orm'
import { Hono } from 'hono'
import { z } from 'zod'
import type { AppEnv } from '../app'
import { db, queryClient } from '../db/client'
import { asCount, percentChange } from '../lib/admin-stats-metrics'
import { DEMO_ACCESS_TARIFF } from '../lib/demo-access'

export const adminStatsRoutes = new Hono<AppEnv>()

type AggregateRow = {
	total_users: string | number
	total_payment_base: string | number
	active_paid_total: string | number
	month_paid: string | number
	ninety_days_paid: string | number
	year_paid: string | number
	rf_paid_total: string | number
	foreign_paid_total: string | number
	autopay_paid_total: string | number
	manual_paid_total: string | number
	former_total: string | number
}

type PeriodMetricsRow = {
	current_revenue: string | number
	previous_revenue: string | number
	current_payments: string | number
	previous_payments: string | number
	average_check: string | number
	previous_average_check: string | number
	new_users: string | number
	previous_new_users: string | number
}

type DailyCountRow = {
	day: string
	count: string | number
}

type DailyRevenueRow = {
	day: string
	total: string | number
}

type DailyAverageCheckRow = {
	day: string
	average: string | number
}

type DailyLoginRow = {
	day: string
	member_count: string | number
	non_member_count: string | number
}

type CohortRetentionRow = {
	cohort: string
	base: string | number
	day1: string | number | null
	day7: string | number | null
	day14: string | number | null
	day30: string | number | null
}

const aggregateSql = `
WITH payment_rows AS (
	SELECT
		COALESCE(
			nullif(lower(coalesce(user_auth_uuid::text, '')), ''),
			nullif(lower(coalesce(email, '')), ''),
			nullif(phone, ''),
			id::text
		) AS member_key,
		COALESCE(date_start, created_at::date) AS date_start,
		date_finish,
		COALESCE(amount, 0)::numeric AS amount,
		COALESCE(zarub, false) AS zarub,
		COALESCE(auto_payment, false) AS auto_payment,
		COALESCE(no_autopodpiska, false) AS no_autopodpiska,
		tarrif,
		created_at
	FROM payments
	WHERE COALESCE(tarrif, '') <> $1
),
classified_rows AS (
	SELECT
		member_key,
		date_start,
		date_finish,
		amount,
		zarub,
		auto_payment,
		no_autopodpiska,
		tarrif,
		created_at,
		CASE
			WHEN date_finish IS NULL THEN 'unknown'
			WHEN date_start IS NOT NULL AND (date_finish - date_start) BETWEEN 85 AND 95 THEN '90'
			WHEN date_start IS NOT NULL AND (date_finish - date_start) BETWEEN 350 AND 380 THEN '365'
			WHEN date_start IS NOT NULL AND (date_finish - date_start) BETWEEN 25 AND 35 THEN '30'
			WHEN tarrif ILIKE '%365%' OR tarrif ILIKE '%12%' THEN '365'
			WHEN tarrif ILIKE '%90%' THEN '90'
			ELSE '30'
		END AS duration_bucket,
		CASE
			WHEN COALESCE(no_autopodpiska, false) THEN false
			ELSE COALESCE(auto_payment, false)
		END AS recurrent_enabled
	FROM payment_rows
	WHERE date_finish IS NOT NULL
),
active_unique AS (
	SELECT DISTINCT ON (member_key)
		member_key,
		duration_bucket,
		amount,
		zarub,
		recurrent_enabled,
		date_start,
		date_finish,
		tarrif,
		created_at
	FROM classified_rows
	WHERE date_finish IS NOT NULL
		AND date_finish >= CURRENT_DATE
	ORDER BY member_key, date_finish DESC, created_at DESC
),
payment_member_keys AS (
	SELECT DISTINCT member_key
	FROM classified_rows
),
former_members AS (
	SELECT p.member_key
	FROM payment_member_keys p
	LEFT JOIN active_unique a USING (member_key)
	WHERE a.member_key IS NULL
)
SELECT
	(SELECT count(*)::bigint FROM users) AS total_users,
	(SELECT count(DISTINCT member_key)::bigint FROM classified_rows) AS total_payment_base,
	count(*)::bigint AS active_paid_total,
	count(*) FILTER (WHERE duration_bucket = '30')::bigint AS month_paid,
	count(*) FILTER (WHERE duration_bucket = '90')::bigint AS ninety_days_paid,
	count(*) FILTER (WHERE duration_bucket = '365')::bigint AS year_paid,
	count(*) FILTER (WHERE zarub = false)::bigint AS rf_paid_total,
	count(*) FILTER (WHERE zarub = true)::bigint AS foreign_paid_total,
	count(*) FILTER (WHERE recurrent_enabled = true)::bigint AS autopay_paid_total,
	count(*) FILTER (WHERE recurrent_enabled = false)::bigint AS manual_paid_total,
	(SELECT count(*)::bigint FROM former_members) AS former_total
FROM active_unique
`

const periodMetricsSql = `
WITH success_payments AS (
	SELECT COALESCE(amount, 0)::numeric AS amount, created_at
	FROM payment_logs
	WHERE status = 'success'
		AND COALESCE(tariff, '') <> $1
)
SELECT
	COALESCE(sum(amount) FILTER (WHERE created_at > now() - interval '30 days'), 0) AS current_revenue,
	COALESCE(sum(amount) FILTER (
		WHERE created_at <= now() - interval '30 days'
			AND created_at > now() - interval '60 days'
	), 0) AS previous_revenue,
	count(*) FILTER (WHERE created_at > now() - interval '30 days')::bigint AS current_payments,
	count(*) FILTER (
		WHERE created_at <= now() - interval '30 days'
			AND created_at > now() - interval '60 days'
	)::bigint AS previous_payments,
	COALESCE(avg(amount) FILTER (WHERE created_at > now() - interval '30 days'), 0) AS average_check,
	COALESCE(avg(amount) FILTER (
		WHERE created_at <= now() - interval '30 days'
			AND created_at > now() - interval '60 days'
	), 0) AS previous_average_check,
	(SELECT count(*)::bigint FROM users WHERE created_at > now() - interval '30 days') AS new_users,
	(SELECT count(*)::bigint FROM users
		WHERE created_at <= now() - interval '30 days'
			AND created_at > now() - interval '60 days'
	) AS previous_new_users
FROM success_payments
`

const dailyRegistrationsSql = `
WITH days AS (
	SELECT generate_series(current_date - interval '29 days', current_date, interval '1 day')::date AS day
),
registrations AS (
	SELECT created_at::date AS day, count(*)::int AS count
	FROM users
	WHERE created_at >= current_date - interval '29 days'
	GROUP BY created_at::date
)
SELECT to_char(days.day, 'YYYY-MM-DD') AS day, COALESCE(registrations.count, 0)::int AS count
FROM days
LEFT JOIN registrations ON registrations.day = days.day
ORDER BY days.day
`

const dailyRevenueSql = `
WITH days AS (
	SELECT generate_series(current_date - interval '29 days', current_date, interval '1 day')::date AS day
),
revenue AS (
	SELECT created_at::date AS day, COALESCE(sum(amount), 0)::numeric AS total
	FROM payment_logs
	WHERE created_at >= current_date - interval '29 days'
		AND status = 'success'
		AND COALESCE(tariff, '') <> $1
	GROUP BY created_at::date
)
SELECT to_char(days.day, 'YYYY-MM-DD') AS day, COALESCE(revenue.total, 0) AS total
FROM days
LEFT JOIN revenue ON revenue.day = days.day
ORDER BY days.day
`

const dailyAverageCheckSql = `
WITH days AS (
	SELECT generate_series(current_date - interval '29 days', current_date, interval '1 day')::date AS day
),
average_check AS (
	SELECT created_at::date AS day, COALESCE(avg(amount), 0)::numeric AS average
	FROM payment_logs
	WHERE created_at >= current_date - interval '29 days'
		AND status = 'success'
		AND COALESCE(tariff, '') <> $1
	GROUP BY created_at::date
)
SELECT to_char(days.day, 'YYYY-MM-DD') AS day, COALESCE(average_check.average, 0) AS average
FROM days
LEFT JOIN average_check ON average_check.day = days.day
ORDER BY days.day
`

const dailyLoginsSql = `
WITH days AS (
	SELECT generate_series(current_date - interval '29 days', current_date, interval '1 day')::date AS day
),
logins AS (
	SELECT
		created_at::date AS day,
		user_auth_uuid,
		CASE WHEN EXISTS (
			SELECT 1 FROM payments p
			WHERE p.user_auth_uuid = pl.user_auth_uuid
				AND p.date_finish >= CURRENT_DATE
		) THEN 'member' ELSE 'non_member' END AS user_type
	FROM payment_logs pl
	WHERE created_at >= current_date - interval '29 days'
		AND status = 'created'
		AND user_auth_uuid IS NOT NULL
)
SELECT
	to_char(days.day, 'YYYY-MM-DD') AS day,
	COALESCE(count(*) FILTER (WHERE logins.user_type = 'member'), 0)::int AS member_count,
	COALESCE(count(*) FILTER (WHERE logins.user_type = 'non_member'), 0)::int AS non_member_count
FROM days
LEFT JOIN logins ON logins.day = days.day
GROUP BY days.day
ORDER BY days.day
`

const unfinishedOrdersSql = `
SELECT count(*)::int AS count
FROM payment_logs
WHERE status = 'created'
	AND created_at > now() - interval '30 days'
	AND NOT EXISTS (
		SELECT 1 FROM payment_logs pl2
		WHERE pl2.user_auth_uuid = payment_logs.user_auth_uuid
			AND pl2.status = 'success'
			AND pl2.created_at > payment_logs.created_at
	)
`

const dailyActiveSql = `
WITH days AS (
	SELECT generate_series(current_date - interval '29 days', current_date, interval '1 day')::date AS day
),
activity AS (
	SELECT auth_uuid::text AS user_key, created_at AS event_at
	FROM users
	WHERE role = 'user' AND created_at >= current_date - interval '29 days'

	UNION ALL

	SELECT auth_uuid::text AS user_key, updated_at AS event_at
	FROM users
	WHERE role = 'user'
		AND updated_at >= current_date - interval '29 days'
		AND updated_at > created_at

	UNION ALL

	SELECT user_auth_uuid::text AS user_key, created_at AS event_at
	FROM messages
	WHERE is_deleted = false AND created_at >= current_date - interval '29 days'

	UNION ALL

	SELECT user_auth_uuid::text AS user_key, updated_at AS event_at
	FROM material_media_progress
	WHERE updated_at >= current_date - interval '29 days'

	UNION ALL

	SELECT user_auth_uuid::text AS user_key, created_at AS event_at
	FROM payment_logs
	WHERE status = 'success'
		AND user_auth_uuid IS NOT NULL
		AND created_at >= current_date - interval '29 days'
		AND COALESCE(tariff, '') <> $1
)
SELECT to_char(days.day, 'YYYY-MM-DD') AS day, count(DISTINCT activity.user_key)::int AS count
FROM days
LEFT JOIN activity ON activity.event_at::date = days.day
GROUP BY days.day
ORDER BY days.day
`

const cohortRetentionSql = `
WITH cohorts AS (
	SELECT DISTINCT date_trunc('week', created_at)::date AS cohort_start
	FROM users
	WHERE role = 'user' AND created_at >= current_date - interval '10 weeks'
	ORDER BY cohort_start DESC
	LIMIT 5
),
cohort_users AS (
	SELECT u.auth_uuid::text AS user_key, u.created_at::date AS created_day, c.cohort_start
	FROM users u
	INNER JOIN cohorts c ON date_trunc('week', u.created_at)::date = c.cohort_start
	WHERE u.role = 'user'
),
activity AS (
	SELECT auth_uuid::text AS user_key, created_at::date AS event_day
	FROM users
	WHERE role = 'user' AND created_at >= current_date - interval '10 weeks'

	UNION ALL

	SELECT auth_uuid::text AS user_key, updated_at::date AS event_day
	FROM users
	WHERE role = 'user'
		AND updated_at >= current_date - interval '10 weeks'
		AND updated_at > created_at

	UNION ALL

	SELECT user_auth_uuid::text AS user_key, created_at::date AS event_day
	FROM messages
	WHERE is_deleted = false AND created_at >= current_date - interval '10 weeks'

	UNION ALL

	SELECT user_auth_uuid::text AS user_key, updated_at::date AS event_day
	FROM material_media_progress
	WHERE updated_at >= current_date - interval '10 weeks'

	UNION ALL

	SELECT user_auth_uuid::text AS user_key, created_at::date AS event_day
	FROM payment_logs
	WHERE status = 'success'
		AND user_auth_uuid IS NOT NULL
		AND created_at >= current_date - interval '10 weeks'
		AND COALESCE(tariff, '') <> $1
)
SELECT
	to_char(c.cohort_start, 'DD.MM') || '-' || to_char(c.cohort_start + 6, 'DD.MM') AS cohort,
	count(DISTINCT cu.user_key)::int AS base,
	100::int AS day1,
	CASE WHEN current_date >= c.cohort_start + 7
		THEN round(100.0 * count(DISTINCT cu.user_key) FILTER (
			WHERE a7.user_key IS NOT NULL
		) / nullif(count(DISTINCT cu.user_key), 0))::int
		ELSE NULL
	END AS day7,
	CASE WHEN current_date >= c.cohort_start + 14
		THEN round(100.0 * count(DISTINCT cu.user_key) FILTER (
			WHERE a14.user_key IS NOT NULL
		) / nullif(count(DISTINCT cu.user_key), 0))::int
		ELSE NULL
	END AS day14,
	CASE WHEN current_date >= c.cohort_start + 30
		THEN round(100.0 * count(DISTINCT cu.user_key) FILTER (
			WHERE a30.user_key IS NOT NULL
		) / nullif(count(DISTINCT cu.user_key), 0))::int
		ELSE NULL
	END AS day30
FROM cohorts c
INNER JOIN cohort_users cu ON cu.cohort_start = c.cohort_start
LEFT JOIN activity a7 ON a7.user_key = cu.user_key
	AND a7.event_day >= cu.created_day + 7
	AND a7.event_day < cu.created_day + 14
LEFT JOIN activity a14 ON a14.user_key = cu.user_key
	AND a14.event_day >= cu.created_day + 14
	AND a14.event_day < cu.created_day + 30
LEFT JOIN activity a30 ON a30.user_key = cu.user_key
	AND a30.event_day >= cu.created_day + 30
GROUP BY c.cohort_start
ORDER BY c.cohort_start
`

adminStatsRoutes.get('/', async (c) => {
	const aggregateRows = await queryClient.unsafe<AggregateRow[]>(aggregateSql, [DEMO_ACCESS_TARIFF])
	const aggregate = aggregateRows[0] ?? {
		total_users: 0,
		total_payment_base: 0,
		active_paid_total: 0,
		month_paid: 0,
		ninety_days_paid: 0,
		year_paid: 0,
		rf_paid_total: 0,
		foreign_paid_total: 0,
		autopay_paid_total: 0,
		manual_paid_total: 0,
		former_total: 0,
	}

	const periodMetricsRows = await queryClient.unsafe<PeriodMetricsRow[]>(periodMetricsSql, [
		DEMO_ACCESS_TARIFF,
	])
	const periodMetrics = periodMetricsRows[0] ?? {
		current_revenue: 0,
		previous_revenue: 0,
		current_payments: 0,
		previous_payments: 0,
		average_check: 0,
		previous_average_check: 0,
		new_users: 0,
		previous_new_users: 0,
	}

	const [totalSales] = await db
		.select({ total: sql<number>`coalesce(sum(${paymentLogs.amount}), 0)` })
		.from(paymentLogs)
		.where(
			sql`${paymentLogs.status} = 'success' AND coalesce(${paymentLogs.tariff}, '') <> ${DEMO_ACCESS_TARIFF}`,
		)

	const recentRegistrations = await queryClient.unsafe<DailyCountRow[]>(dailyRegistrationsSql)
	const recentRevenue = await queryClient.unsafe<DailyRevenueRow[]>(dailyRevenueSql, [
		DEMO_ACCESS_TARIFF,
	])
	const dailyAverageCheck = await queryClient.unsafe<DailyAverageCheckRow[]>(dailyAverageCheckSql, [
		DEMO_ACCESS_TARIFF,
	])
	const dailyActive = await queryClient.unsafe<DailyCountRow[]>(dailyActiveSql, [
		DEMO_ACCESS_TARIFF,
	])
	const cohortRetention = await queryClient.unsafe<CohortRetentionRow[]>(cohortRetentionSql, [
		DEMO_ACCESS_TARIFF,
	])

	const dailyLogins = await queryClient.unsafe<DailyLoginRow[]>(dailyLoginsSql)
	const [unfinishedOrders] = await queryClient.unsafe<{ count: number }[]>(unfinishedOrdersSql)

	const monthPaid = asCount(aggregate.month_paid)
	const ninetyDaysPaid = asCount(aggregate.ninety_days_paid)
	const yearPaid = asCount(aggregate.year_paid)
	const dau = asCount(dailyActive.at(-1)?.count)
	const previousDau = asCount(dailyActive.at(-2)?.count)
	const retention30Values = cohortRetention
		.map((row) => row.day30)
		.filter((value): value is string | number => value != null)
		.map(asCount)
	const retention30Days = retention30Values.length
		? Math.round(
				retention30Values.reduce((sum, value) => sum + value, 0) / retention30Values.length,
			)
		: 0

	return c.json({
		success: true,
		data: {
			totalUsers: asCount(aggregate.total_users),
			totalPaymentBase: asCount(aggregate.total_payment_base),
			activePaidSubscribers: asCount(aggregate.active_paid_total),
			members: {
				monthRenewal: monthPaid,
				ninetyDays: ninetyDaysPaid,
				year: yearPaid,
				activePaidTotal: monthPaid + ninetyDaysPaid + yearPaid,
				activeTotal: monthPaid + ninetyDaysPaid + yearPaid,
			},
			payments: {
				rfActive: asCount(aggregate.rf_paid_total),
				foreignActive: asCount(aggregate.foreign_paid_total),
				autopayActive: asCount(aggregate.autopay_paid_total),
				manualActive: asCount(aggregate.manual_paid_total),
			},
			formerMembers: {
				total: asCount(aggregate.former_total),
			},
			monthRevenue: asCount(periodMetrics.current_revenue),
			totalSales: totalSales.total,
			metrics: {
				revenueGrowthPercent: percentChange(
					periodMetrics.current_revenue,
					periodMetrics.previous_revenue,
				),
				retention30Days,
				dau,
				dauGrowthPercent: percentChange(dau, previousDau),
				averageCheck: Math.round(asCount(periodMetrics.average_check)),
				averageCheckGrowthPercent: percentChange(
					periodMetrics.average_check,
					periodMetrics.previous_average_check,
				),
				newUsers30Days: asCount(periodMetrics.new_users),
				newUsersGrowthPercent: percentChange(
					periodMetrics.new_users,
					periodMetrics.previous_new_users,
				),
				payments30Days: asCount(periodMetrics.current_payments),
				paymentsGrowthPercent: percentChange(
					periodMetrics.current_payments,
					periodMetrics.previous_payments,
				),
			},
			cohortRetention,
			charts: {
				registrations: recentRegistrations.map((row) => ({
					day: row.day,
					count: asCount(row.count),
				})),
				revenue: recentRevenue.map((row) => ({
					day: row.day,
					total: asCount(row.total),
				})),
				averageCheck: dailyAverageCheck.map((row) => ({
					day: row.day,
					average: Math.round(asCount(row.average)),
				})),
				dailyActive: dailyActive.map((row) => ({
					day: row.day,
					count: asCount(row.count),
				})),
				logins: dailyLogins.map((row) => ({
					day: row.day,
					memberCount: asCount(row.member_count),
					nonMemberCount: asCount(row.non_member_count),
				})),
			},
			unfinishedOrders: asCount(unfinishedOrders?.count ?? 0),
		},
	})
})

const salesFilterSchema = z.object({
	from: z.string(),
	to: z.string(),
})

adminStatsRoutes.get('/sales-filter', zValidator('query', salesFilterSchema), async (c) => {
	const { from, to } = c.req.valid('query')

	const [result] = await db
		.select({
			count: sql<number>`count(*)`,
			total: sql<number>`coalesce(sum(${paymentLogs.amount}), 0)`,
		})
		.from(paymentLogs)
		.where(
			sql`${paymentLogs.status} = 'success' AND ${paymentLogs.createdAt} >= ${from}::timestamp AND ${paymentLogs.createdAt} < (${to}::timestamp + interval '1 day')`,
		)

	return c.json({ success: true, data: { count: result.count, total: result.total } })
})

adminStatsRoutes.get(
	'/activity',
	zValidator(
		'query',
		z.object({ page: z.coerce.number().default(1), pageSize: z.coerce.number().default(30) }),
	),
	async (c) => {
		const { page, pageSize } = c.req.valid('query')
		const offset = (page - 1) * pageSize

		const items = await db.query.paymentLogs.findMany({
			orderBy: [desc(paymentLogs.createdAt)],
			limit: pageSize,
			offset,
		})

		return c.json({ success: true, data: items })
	},
)
