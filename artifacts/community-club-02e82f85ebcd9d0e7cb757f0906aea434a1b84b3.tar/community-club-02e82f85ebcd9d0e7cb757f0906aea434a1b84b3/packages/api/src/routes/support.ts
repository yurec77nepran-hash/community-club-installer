import {
	type CursorPaginatedResponse,
	type SupportThreadContext,
	type SupportThreadSummary,
	chatMembers,
	chats,
	cursorPaginationSchema,
	paymentLogs,
	payments,
	users,
} from '@community-club/shared'
import { zValidator } from '@hono/zod-validator'
import { desc, eq } from 'drizzle-orm'
import { Hono } from 'hono'
import type { AppEnv } from '../app'
import { db, queryClient } from '../db/client'
import { getSupportChatSlug } from '../lib/chat-access'
import { resolveAvatarUrl } from '../lib/storage'
import { adminMiddleware, authMiddleware } from '../middleware/auth'

export const supportRoutes = new Hono<AppEnv>()

supportRoutes.use('*', authMiddleware)

type SupportThreadRow = {
	chatId: number
	slug: string
	name: string
	createdAt: Date | string
	userAuthUuid: string
	userEmail: string | null
	userPhone: string | null
	userFullName: string | null
	userAvatarUrl: string | null
	userRole: string
	lastMessageId: number | null
	lastMessageContent: string | null
	lastMessageType: string | null
	lastMessageCreatedAt: Date | string | null
	lastMessageUserAuthUuid: string | null
}

function toSupportThreadSummary(row: SupportThreadRow): SupportThreadSummary {
	return {
		chatId: row.chatId,
		slug: row.slug,
		name: row.name,
		createdAt: row.createdAt,
		user: {
			authUuid: row.userAuthUuid,
			email: row.userEmail,
			phone: row.userPhone,
			fullName: row.userFullName,
			avatarUrl: resolveAvatarUrl(row.userAvatarUrl),
			role: row.userRole,
		},
		lastMessage:
			row.lastMessageId == null || row.lastMessageType == null || row.lastMessageCreatedAt == null
				? null
				: {
						id: row.lastMessageId,
						content: row.lastMessageContent,
						messageType: row.lastMessageType,
						createdAt: row.lastMessageCreatedAt,
						userAuthUuid: row.lastMessageUserAuthUuid ?? '',
					},
	}
}

supportRoutes.get('/thread', async (c) => {
	const userId = c.get('userId')
	const user = await db.query.users.findFirst({
		where: eq(users.authUuid, userId),
		columns: {
			authUuid: true,
			email: true,
			fullName: true,
		},
	})

	if (!user) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	const slug = getSupportChatSlug(userId)
	let chat = await db.query.chats.findFirst({
		where: eq(chats.slug, slug),
	})

	if (!chat) {
		const displayName = user.fullName?.trim() || user.email || 'Пользователь'
		const inserted = await db
			.insert(chats)
			.values({
				slug,
				name: `Поддержка · ${displayName}`,
				type: 'chat',
				accessRole: 'all',
			})
			.onConflictDoNothing()
			.returning()

		chat =
			inserted[0] ??
			(await db.query.chats.findFirst({
				where: eq(chats.slug, slug),
			})) ??
			null
	}

	if (!chat) {
		return c.json(
			{
				success: false,
				error: {
					code: 'INTERNAL_ERROR',
					message: 'Системная ошибка. Обратитесь в поддержку.',
				},
			},
			500,
		)
	}

	await db
		.insert(chatMembers)
		.values({
			chatId: chat.id,
			userAuthUuid: userId,
			role: 'member',
			status: 'active',
		})
		.onConflictDoNothing()

	return c.json({
		success: true,
		data: {
			id: chat.id,
			slug: chat.slug,
			name: 'Поддержка',
			createdAt: chat.createdAt,
		},
	})
})

supportRoutes.use('/threads', adminMiddleware)
supportRoutes.use('/threads/*', adminMiddleware)
const supportThreadsQuerySchema = cursorPaginationSchema.extend({
	limit: cursorPaginationSchema.shape.limit.default(50),
})

function decodeSupportThreadsCursor(cursor?: string) {
	if (!cursor) return null

	try {
		const parsed = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8')) as {
			sortDate?: string
			chatId?: number
		}
		if (!parsed.sortDate || !parsed.chatId) {
			return null
		}

		return {
			sortDate: parsed.sortDate,
			chatId: parsed.chatId,
		}
	} catch {
		return null
	}
}

function encodeSupportThreadsCursor(sortDate: string | Date, chatId: number) {
	return Buffer.from(
		JSON.stringify({
			sortDate: new Date(sortDate).toISOString(),
			chatId,
		}),
	).toString('base64url')
}

supportRoutes.get('/threads', zValidator('query', supportThreadsQuerySchema), async (c) => {
	const { cursor, limit } = c.req.valid('query')
	const decodedCursor = decodeSupportThreadsCursor(cursor)

	const rows = await queryClient<SupportThreadRow[]>`
		SELECT
			c.id AS "chatId",
			c.slug AS "slug",
			c.name AS "name",
			c.created_at AS "createdAt",
			u.auth_uuid AS "userAuthUuid",
			u.email AS "userEmail",
			u.phone AS "userPhone",
			u.full_name AS "userFullName",
			u.avatar_url AS "userAvatarUrl",
			u.role AS "userRole",
			lm.id AS "lastMessageId",
			lm.content AS "lastMessageContent",
			lm.message_type AS "lastMessageType",
			lm.created_at AS "lastMessageCreatedAt",
			lm.user_auth_uuid AS "lastMessageUserAuthUuid"
		FROM chats c
		INNER JOIN chat_members cm
			ON cm.chat_id = c.id
			AND cm.role = 'member'
		INNER JOIN users u
			ON u.auth_uuid = cm.user_auth_uuid
		LEFT JOIN LATERAL (
			SELECT
				m.id,
				m.content,
				m.message_type,
				m.created_at,
				m.user_auth_uuid
			FROM messages m
			WHERE m.chat_id = c.id
				AND m.is_deleted = false
			ORDER BY m.id DESC
			LIMIT 1
		) lm ON true
		WHERE c.type = 'chat'
			AND c.slug LIKE 'support:%'
			AND EXISTS (
				SELECT 1
				FROM messages um
				WHERE um.chat_id = c.id
					AND um.user_auth_uuid = cm.user_auth_uuid
					AND um.is_deleted = false
			)
			${
				decodedCursor
					? queryClient`
						AND (
							COALESCE(lm.created_at, c.created_at) < ${decodedCursor.sortDate}::timestamptz
							OR (
								COALESCE(lm.created_at, c.created_at) = ${decodedCursor.sortDate}::timestamptz
								AND c.id < ${decodedCursor.chatId}
							)
						)
					`
					: queryClient``
			}
		ORDER BY COALESCE(lm.created_at, c.created_at) DESC, c.id DESC
		LIMIT ${limit + 1}
	`

	const hasMore = rows.length > limit
	const slicedRows = hasMore ? rows.slice(0, limit) : rows
	const items = slicedRows.map(toSupportThreadSummary)
	const lastRow = slicedRows.at(-1)
	const nextCursor =
		hasMore && lastRow
			? encodeSupportThreadsCursor(
					lastRow.lastMessageCreatedAt ?? lastRow.createdAt,
					lastRow.chatId,
				)
			: null

	return c.json({
		success: true,
		data: { items, nextCursor } satisfies CursorPaginatedResponse<SupportThreadSummary>,
	})
})

supportRoutes.get('/threads/:chatId/context', async (c) => {
	const chatId = Number(c.req.param('chatId'))

	if (!Number.isFinite(chatId) || chatId <= 0) {
		return c.json(
			{
				success: false,
				error: { code: 'BAD_REQUEST', message: 'Некорректный идентификатор диалога' },
			},
			400,
		)
	}

	const thread = await queryClient<
		Array<{
			userAuthUuid: string
			totalMessages: number
			userMessages: number
			firstUserMessageAt: Date | string | null
			lastUserMessageAt: Date | string | null
		}>
	>`
		SELECT
			cm.user_auth_uuid AS "userAuthUuid",
			COUNT(m.id)::int AS "totalMessages",
			COUNT(*) FILTER (
				WHERE m.user_auth_uuid = cm.user_auth_uuid
					AND m.is_deleted = false
			)::int AS "userMessages",
			MIN(m.created_at) FILTER (
				WHERE m.user_auth_uuid = cm.user_auth_uuid
					AND m.is_deleted = false
			) AS "firstUserMessageAt",
			MAX(m.created_at) FILTER (
				WHERE m.user_auth_uuid = cm.user_auth_uuid
					AND m.is_deleted = false
			) AS "lastUserMessageAt"
		FROM chats c
		INNER JOIN chat_members cm
			ON cm.chat_id = c.id
			AND cm.role = 'member'
		LEFT JOIN messages m
			ON m.chat_id = c.id
		WHERE c.id = ${chatId}
			AND c.type = 'chat'
			AND c.slug LIKE 'support:%'
		GROUP BY cm.user_auth_uuid
		LIMIT 1
	`

	const meta = thread[0]
	if (!meta) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Диалог не найден' } },
			404,
		)
	}

	const [user, payment, logs] = await Promise.all([
		db.query.users.findFirst({
			where: eq(users.authUuid, meta.userAuthUuid),
			columns: {
				authUuid: true,
				email: true,
				phone: true,
				fullName: true,
				avatarUrl: true,
				role: true,
				city: true,
				workPlace: true,
				createdAt: true,
			},
		}),
		db.query.payments.findFirst({
			where: eq(payments.userAuthUuid, meta.userAuthUuid),
			columns: {
				tarrif: true,
				dateStart: true,
				dateFinish: true,
				amount: true,
				autoPayment: true,
				paymentProvider: true,
			},
		}),
		db.query.paymentLogs.findMany({
			where: eq(paymentLogs.userAuthUuid, meta.userAuthUuid),
			orderBy: [desc(paymentLogs.createdAt)],
			limit: 8,
			columns: {
				id: true,
				event: true,
				amount: true,
				status: true,
				tariff: true,
				paymentDate: true,
				nextPaymentDate: true,
				createdAt: true,
			},
		}),
	])

	if (!user) {
		return c.json(
			{ success: false, error: { code: 'NOT_FOUND', message: 'Пользователь не найден' } },
			404,
		)
	}

	return c.json({
		success: true,
		data: {
			user: {
				...user,
				avatarUrl: resolveAvatarUrl(user.avatarUrl),
			},
			payment,
			paymentLogs: logs,
			stats: {
				totalMessages: meta.totalMessages,
				userMessages: meta.userMessages,
				firstUserMessageAt: meta.firstUserMessageAt,
				lastUserMessageAt: meta.lastUserMessageAt,
			},
		} satisfies SupportThreadContext,
	})
})
