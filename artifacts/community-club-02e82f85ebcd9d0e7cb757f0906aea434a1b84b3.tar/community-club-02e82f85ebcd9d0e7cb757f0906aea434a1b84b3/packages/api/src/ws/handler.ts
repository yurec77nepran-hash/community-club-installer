import { type messageMentions, messageReactions, messages, users } from '@community-club/shared'
import type { ServerWebSocket } from 'bun'
import { and, eq } from 'drizzle-orm'
import { jwtVerify } from 'jose'
import { env } from '../config/env'
import { db } from '../db/client'
import { ensureChatAccess } from '../lib/chat-access'
import { deliverChatMessage } from '../lib/chat-delivery'
import { createMessageMentions, normalizeMentions } from '../lib/chat-mentions'
import { isChatManager, normalizeChatSettings } from '../lib/chat-settings'
import { logger } from '../lib/logger'
import { checkRedisRateLimit } from '../lib/rate-limit'
import { redisPub, redisSub } from '../lib/redis'
import { resolveAvatarUrl } from '../lib/storage'
import { extractWsAuthToken, isAllowedWsOrigin, isWsPayloadWithinLimit } from '../lib/ws-security'

const secret = new TextEncoder().encode(env.JWT_SECRET)
const serverInstanceId = crypto.randomUUID()

function getChatPushUrl(chat: { slug: string; id: number }) {
	return chat.slug.startsWith('support') ? '/app/support' : `/app/chats/${chat.id}`
}

type UserProfile = {
	fullName: string | null
	username: string | null
	avatarUrl: string | null
}

type RedisRoomEvent = {
	instanceId: string
	payload: string
	excludeUserId: string | null
}

export interface WSData {
	userId: string
	userRole: 'user' | 'admin' | 'superadmin'
	profile: UserProfile
	connectionId: string
	rooms: Set<string>
	typingCooldownUntil: Map<number, number>
	accessCache: Map<
		number,
		{ expiresAt: number; access: Awaited<ReturnType<typeof ensureChatAccess>> }
	>
}

const rooms = new Map<string, Set<ServerWebSocket<WSData>>>()
const redisRoomSubscriptions = new Map<string, number>()
const WS_MSG_LIMIT = 10
const WS_MSG_WINDOW = 10_000
const WS_ACTION_LIMIT = 40
const WS_PAYLOAD_MAX_BYTES = 64 * 1024
const WS_TYPING_COALESCE_MS = 1_200
const WS_ACCESS_CACHE_TTL_MS = 5_000
const WS_PRESENCE_TTL_MS = 75_000
const PRESENCE_COUNT_HASH_KEY = 'presence:counts'
let redisSubscriberInitialized = false

async function checkWsRate(userId: string): Promise<boolean> {
	return checkRedisRateLimit({
		namespace: 'ws:messages',
		key: userId,
		windowSeconds: Math.ceil(WS_MSG_WINDOW / 1000),
		limit: WS_MSG_LIMIT,
	})
}

async function checkWsActionRate(userId: string): Promise<boolean> {
	return checkRedisRateLimit({
		namespace: 'ws:actions',
		key: userId,
		windowSeconds: Math.ceil(WS_MSG_WINDOW / 1000),
		limit: WS_ACTION_LIMIT,
	})
}

function getUrlOrigin(value: string) {
	try {
		return new URL(value).origin
	} catch {
		return null
	}
}

const wsAllowedOrigins = Array.from(
	new Set(
		[env.APP_URL, env.ADMIN_URL]
			.map(getUrlOrigin)
			.filter((origin): origin is string => Boolean(origin)),
	),
)

async function checkTypingRate(userId: string, chatId: number): Promise<boolean> {
	return checkRedisRateLimit({
		namespace: 'ws:typing',
		key: `${userId}:${chatId}`,
		windowSeconds: Math.ceil(WS_TYPING_COALESCE_MS / 1000),
		limit: 1,
	})
}

function getPresenceMembersKey(roomId: string) {
	return `presence:${roomId}:members`
}

function getPresenceMemberId(userId: string, connectionId: string) {
	return `${userId}|${connectionId}`
}

function getPresenceUserId(memberId: string) {
	const separatorIndex = memberId.indexOf('|')
	return separatorIndex === -1 ? memberId : memberId.slice(0, separatorIndex)
}

function getChatIdFromRoomId(roomId: string) {
	if (!roomId.startsWith('chat:')) return null
	const chatId = Number(roomId.slice(5))
	return Number.isFinite(chatId) && chatId > 0 ? chatId : null
}

async function pruneRoomPresence(roomId: string) {
	await redisPub.zremrangebyscore(getPresenceMembersKey(roomId), 0, Date.now())
}

async function calculateRoomOnlineCount(roomId: string) {
	await pruneRoomPresence(roomId)
	const members = await redisPub.zrange(getPresenceMembersKey(roomId), 0, -1)
	return new Set(members.map(getPresenceUserId)).size
}

async function reconcileRoomPresence(roomId: string, options?: { broadcastIfChanged?: boolean }) {
	const chatId = getChatIdFromRoomId(roomId)
	if (!chatId) return null

	const onlineCount = await calculateRoomOnlineCount(roomId)
	const previousCount = Number((await redisPub.hget(PRESENCE_COUNT_HASH_KEY, roomId)) ?? '-1')

	if (onlineCount > 0) {
		await redisPub.hset(PRESENCE_COUNT_HASH_KEY, roomId, String(onlineCount))
	} else {
		await redisPub.hdel(PRESENCE_COUNT_HASH_KEY, roomId)
	}

	if (options?.broadcastIfChanged && previousCount !== onlineCount) {
		await broadcastToRoom(
			roomId,
			{
				type: 'presence',
				chatId,
				onlineCount,
			},
			{ publishToRedis: true },
		)
	}

	return { chatId, onlineCount }
}

async function touchRoomPresence(params: {
	roomId: string
	userId: string
	connectionId: string
}) {
	const memberId = getPresenceMemberId(params.userId, params.connectionId)
	const redisKey = getPresenceMembersKey(params.roomId)
	const expiresAt = Date.now() + WS_PRESENCE_TTL_MS

	await redisPub
		.multi()
		.zadd(redisKey, String(expiresAt), memberId)
		.pexpire(redisKey, WS_PRESENCE_TTL_MS * 2)
		.exec()
}

async function removeRoomPresence(params: {
	roomId: string
	userId: string
	connectionId: string
}) {
	await redisPub.zrem(
		getPresenceMembersKey(params.roomId),
		getPresenceMemberId(params.userId, params.connectionId),
	)
}

async function refreshSocketPresence(
	ws: ServerWebSocket<WSData>,
	options?: { broadcastIfChanged?: boolean },
) {
	const roomIds = Array.from(ws.data.rooms)
	if (roomIds.length === 0) return

	await Promise.all(
		roomIds.map(async (roomId) => {
			await touchRoomPresence({
				roomId,
				userId: ws.data.userId,
				connectionId: ws.data.connectionId,
			})
			await reconcileRoomPresence(roomId, {
				broadcastIfChanged: options?.broadcastIfChanged ?? true,
			})
		}),
	)
}

function deliverToRoom(roomId: string, payload: string, excludeUserId?: string) {
	const roomSet = rooms.get(roomId)
	if (!roomSet) return

	for (const client of roomSet) {
		if (excludeUserId && client.data.userId === excludeUserId) continue
		client.send(payload)
	}
}

async function subscribeRoom(roomId: string) {
	const current = redisRoomSubscriptions.get(roomId) ?? 0
	redisRoomSubscriptions.set(roomId, current + 1)
	if (current === 0) {
		await redisSub.subscribe(roomId)
	}
}

async function unsubscribeRoom(roomId: string) {
	const current = redisRoomSubscriptions.get(roomId) ?? 0
	if (current <= 1) {
		redisRoomSubscriptions.delete(roomId)
		await redisSub.unsubscribe(roomId)
		return
	}

	redisRoomSubscriptions.set(roomId, current - 1)
}

async function addSocketToRoom(ws: ServerWebSocket<WSData>, roomId: string) {
	if (ws.data.rooms.has(roomId)) {
		await touchRoomPresence({
			roomId,
			userId: ws.data.userId,
			connectionId: ws.data.connectionId,
		})
		return reconcileRoomPresence(roomId)
	}

	const roomSet = rooms.get(roomId)
	const needsRedisSubscribe = !roomSet || roomSet.size === 0

	ws.data.rooms.add(roomId)
	if (roomSet) {
		roomSet.add(ws)
	} else {
		rooms.set(roomId, new Set([ws]))
	}

	if (needsRedisSubscribe) {
		await subscribeRoom(roomId)
	}

	await touchRoomPresence({
		roomId,
		userId: ws.data.userId,
		connectionId: ws.data.connectionId,
	})
	const presence = await reconcileRoomPresence(roomId, { broadcastIfChanged: true })

	return presence
}

async function removeSocketFromRoom(ws: ServerWebSocket<WSData>, roomId: string) {
	if (!ws.data.rooms.has(roomId)) return

	ws.data.rooms.delete(roomId)
	const roomSet = rooms.get(roomId)
	if (!roomSet) return

	roomSet.delete(ws)
	if (roomSet.size === 0) {
		rooms.delete(roomId)
		await unsubscribeRoom(roomId)
	}

	await removeRoomPresence({
		roomId,
		userId: ws.data.userId,
		connectionId: ws.data.connectionId,
	})
	await reconcileRoomPresence(roomId, { broadcastIfChanged: true })
}

async function broadcastToRoom(
	roomId: string,
	event: Record<string, unknown>,
	options?: { excludeUserId?: string; publishToRedis?: boolean },
) {
	const payload = JSON.stringify(event)
	deliverToRoom(roomId, payload, options?.excludeUserId)

	if (options?.publishToRedis === false) return

	const envelope: RedisRoomEvent = {
		instanceId: serverInstanceId,
		payload,
		excludeUserId: options?.excludeUserId ?? null,
	}

	try {
		await redisPub.publish(roomId, JSON.stringify(envelope))
	} catch (err) {
		logger.error({ err, roomId }, 'Failed to publish room event to Redis')
	}
}

export async function broadcastChatRoomEvent(
	chatId: number,
	event: Record<string, unknown>,
	options?: { excludeUserId?: string; publishToRedis?: boolean },
) {
	await broadcastToRoom(`chat:${chatId}`, event, options)
}

function normalizeClientMessageId(value: unknown) {
	if (typeof value !== 'string') return null
	const normalized = value.trim().slice(0, 128)
	return normalized || null
}

async function getWsChatAccess(ws: ServerWebSocket<WSData>, chatId: number) {
	const cached = ws.data.accessCache.get(chatId)
	if (cached && cached.expiresAt > Date.now()) {
		return cached.access
	}

	const access = await ensureChatAccess({
		chatId,
		userId: ws.data.userId,
		userRole: ws.data.userRole,
	})

	ws.data.accessCache.set(chatId, {
		expiresAt: Date.now() + WS_ACCESS_CACHE_TTL_MS,
		access,
	})

	return access
}

export async function handleWSUpgrade(
	req: Request,
): Promise<{ userId: string; userRole: WSData['userRole']; profile: UserProfile } | null> {
	if (!isAllowedWsOrigin(req.headers.get('origin'), wsAllowedOrigins)) return null

	const token = extractWsAuthToken(req)
	if (!token) return null

	try {
		const { payload } = await jwtVerify(token, secret)
		const userId = payload.sub as string
		const user = await db.query.users.findFirst({
			where: eq(users.authUuid, userId),
			columns: { authUuid: true, role: true, fullName: true, username: true, avatarUrl: true },
		})
		if (!user) return null

		return {
			userId,
			userRole: user.role,
			profile: {
				fullName: user.fullName,
				username: user.username,
				avatarUrl: resolveAvatarUrl(user.avatarUrl),
			},
		}
	} catch {
		return null
	}
}

export function handleWSOpen(ws: ServerWebSocket<WSData>) {
	ws.data.connectionId = crypto.randomUUID()
	ws.data.rooms = new Set()
	ws.data.typingCooldownUntil = new Map()
	ws.data.accessCache = new Map()
	logger.debug({ userId: ws.data.userId, connectionId: ws.data.connectionId }, 'WS connected')
}

export function handleWSClose(ws: ServerWebSocket<WSData>) {
	for (const roomId of Array.from(ws.data.rooms)) {
		void removeSocketFromRoom(ws, roomId)
	}
	ws.data.accessCache.clear()
	logger.debug({ userId: ws.data.userId, connectionId: ws.data.connectionId }, 'WS disconnected')
}

export async function handleWSMessage(ws: ServerWebSocket<WSData>, raw: string | Buffer) {
	try {
		if (!isWsPayloadWithinLimit(raw, WS_PAYLOAD_MAX_BYTES)) {
			ws.send(JSON.stringify({ type: 'error', message: 'Сообщение слишком большое' }))
			return
		}

		const msg = JSON.parse(typeof raw === 'string' ? raw : raw.toString())

		if (msg.type === 'send_message' && !(await checkWsRate(ws.data.userId))) {
			ws.send(
				JSON.stringify({
					type: 'error',
					message: 'Слишком много действий подряд. Попробуйте чуть позже.',
				}),
			)
			return
		}

		if (
			['reaction', 'delete_message', 'edit_message', 'typing', 'mark_read'].includes(msg.type) &&
			!(await checkWsActionRate(ws.data.userId))
		) {
			ws.send(
				JSON.stringify({
					type: 'error',
					message: 'Слишком много действий. Попробуйте чуть позже.',
				}),
			)
			return
		}

		switch (msg.type) {
			case 'join_room': {
				const chatId = Number(msg.chatId)
				if (!chatId || Number.isNaN(chatId)) break

				const access = await getWsChatAccess(ws, chatId)
				if (!access.ok) {
					ws.send(JSON.stringify({ type: 'error', message: access.message }))
					break
				}

				const roomId = `chat:${chatId}`
				const presence = await addSocketToRoom(ws, roomId)
				ws.send(JSON.stringify({ type: 'room_joined', chatId }))
				if (presence) {
					ws.send(
						JSON.stringify({
							type: 'presence',
							chatId,
							onlineCount: presence.onlineCount,
						}),
					)
				}
				logger.debug({ userId: ws.data.userId, roomId }, 'Joined room')
				break
			}

			case 'ping': {
				await refreshSocketPresence(ws)
				ws.send(
					JSON.stringify({
						type: 'pong',
						ts: Date.now(),
					}),
				)
				break
			}

			case 'leave_room': {
				const chatId = Number(msg.chatId)
				if (!chatId || Number.isNaN(chatId)) break

				await removeSocketFromRoom(ws, `chat:${chatId}`)
				break
			}

			case 'send_message': {
				const chatId = Number(msg.chatId)
				if (!chatId || Number.isNaN(chatId)) break

				const roomId = `chat:${chatId}`
				const content = typeof msg.content === 'string' ? msg.content.slice(0, 4000) : ''
				const messageType = [
					'text',
					'image',
					'video',
					'voice',
					'audio',
					'document',
					'link',
				].includes(msg.messageType)
					? msg.messageType
					: 'text'
				const attachmentUrl =
					typeof msg.attachmentUrl === 'string' ? msg.attachmentUrl.slice(0, 2048) : null
				const attachmentName =
					typeof msg.attachmentName === 'string' ? msg.attachmentName.slice(0, 255) : null
				const attachmentSize =
					typeof msg.attachmentSize === 'number' && Number.isFinite(msg.attachmentSize)
						? msg.attachmentSize
						: null
				const clientMessageId = normalizeClientMessageId(msg.clientMessageId)
				if (!content && !attachmentUrl) {
					ws.send(
						JSON.stringify({
							type: 'error',
							message: 'Сообщение не может быть пустым',
							clientMessageId,
						}),
					)
					break
				}

				const access = await getWsChatAccess(ws, chatId)
				if (!access.ok) {
					ws.send(JSON.stringify({ type: 'error', message: access.message, clientMessageId }))
					break
				}

				if (access.member?.status === 'muted') {
					ws.send(
						JSON.stringify({
							type: 'error',
							message: 'Вы временно не можете писать в этот чат',
							clientMessageId,
						}),
					)
					break
				}

				await addSocketToRoom(ws, roomId)

				const delivery = await deliverChatMessage({
					chatId,
					userId: ws.data.userId,
					userRole: ws.data.userRole,
					content,
					replyToId: msg.replyToId ? Number(msg.replyToId) : null,
					clientMessageId,
					messageType,
					attachmentUrl,
					attachmentName,
					attachmentSize,
					mentions: Array.isArray(msg.mentions) ? msg.mentions : undefined,
				})

				if (!delivery.ok) {
					ws.send(
						JSON.stringify({
							type: 'error',
							message: delivery.message,
							clientMessageId,
						}),
					)
					break
				}

				ws.send(
					JSON.stringify({
						type: 'message_ack',
						clientMessageId,
						message: delivery.message,
					}),
				)

				if (!delivery.duplicate) {
					await broadcastToRoom(roomId, { type: 'new_message', message: delivery.message })
				}
				break
			}

			case 'typing': {
				const chatId = Number(msg.chatId)
				if (!chatId || Number.isNaN(chatId)) break

				const access = await getWsChatAccess(ws, chatId)
				if (!access.ok || access.member?.status === 'muted') {
					break
				}

				const nextAllowedAt = ws.data.typingCooldownUntil.get(chatId) ?? 0
				if (nextAllowedAt > Date.now()) {
					break
				}
				if (!(await checkTypingRate(ws.data.userId, chatId))) {
					break
				}

				ws.data.typingCooldownUntil.set(chatId, Date.now() + WS_TYPING_COALESCE_MS)

				await addSocketToRoom(ws, `chat:${chatId}`)
				await broadcastToRoom(
					`chat:${chatId}`,
					{
						type: 'typing',
						userId: ws.data.userId,
						chatId,
						expiresAt: Date.now() + 3_500,
					},
					{ excludeUserId: ws.data.userId },
				)
				break
			}

			case 'reaction': {
				const chatId = Number(msg.chatId)
				const messageId = Number(msg.messageId)
				if (!chatId || Number.isNaN(chatId) || !messageId || Number.isNaN(messageId)) break

				const emoji = typeof msg.emoji === 'string' ? msg.emoji.slice(0, 8) : ''
				if (!emoji) break

				const access = await getWsChatAccess(ws, chatId)
				if (!access.ok) {
					ws.send(JSON.stringify({ type: 'error', message: access.message }))
					break
				}

				if (
					!isChatManager(ws.data.userRole, access.member?.role) &&
					!normalizeChatSettings(access.chat.settings).allowReactions
				) {
					ws.send(JSON.stringify({ type: 'error', message: 'Реакции в этом чате отключены' }))
					break
				}

				const targetMessage = await db.query.messages.findFirst({
					where: and(
						eq(messages.id, messageId),
						eq(messages.chatId, chatId),
						eq(messages.isDeleted, false),
					),
					columns: { id: true },
				})
				if (!targetMessage) {
					ws.send(JSON.stringify({ type: 'error', message: 'Сообщение не найдено' }))
					break
				}

				const existing = await db.query.messageReactions.findFirst({
					where: and(
						eq(messageReactions.messageId, messageId),
						eq(messageReactions.userAuthUuid, ws.data.userId),
						eq(messageReactions.emoji, emoji),
					),
				})

				const action = existing ? 'removed' : 'added'

				if (existing) {
					await db.delete(messageReactions).where(eq(messageReactions.id, existing.id))
				} else {
					await db.insert(messageReactions).values({
						messageId,
						userAuthUuid: ws.data.userId,
						emoji,
					})
				}

				await broadcastToRoom(`chat:${chatId}`, {
					type: 'reaction_update',
					messageId,
					userId: ws.data.userId,
					emoji,
					action,
				})
				break
			}

			case 'delete_message': {
				const chatId = Number(msg.chatId)
				const messageId = Number(msg.messageId)
				if (!chatId || Number.isNaN(chatId) || !messageId || Number.isNaN(messageId)) break

				const access = await getWsChatAccess(ws, chatId)
				if (!access.ok) {
					ws.send(JSON.stringify({ type: 'error', message: access.message }))
					break
				}

				const targetMsg = await db.query.messages.findFirst({
					where: and(eq(messages.id, messageId), eq(messages.chatId, chatId)),
				})
				if (!targetMsg) break

				if (
					targetMsg.userAuthUuid !== ws.data.userId &&
					!['admin', 'superadmin'].includes(ws.data.userRole)
				) {
					ws.send(
						JSON.stringify({ type: 'error', message: 'Недостаточно прав для этого действия' }),
					)
					break
				}

				await db.update(messages).set({ isDeleted: true }).where(eq(messages.id, messageId))

				await broadcastToRoom(`chat:${chatId}`, {
					type: 'message_deleted',
					messageId,
					chatId,
				})
				break
			}

			case 'edit_message': {
				const chatId = Number(msg.chatId)
				const messageId = Number(msg.messageId)
				if (!chatId || Number.isNaN(chatId) || !messageId || Number.isNaN(messageId)) break

				const access = await getWsChatAccess(ws, chatId)
				if (!access.ok) {
					ws.send(JSON.stringify({ type: 'error', message: access.message }))
					break
				}

				const targetMsg = await db.query.messages.findFirst({
					where: and(
						eq(messages.id, messageId),
						eq(messages.chatId, chatId),
						eq(messages.isDeleted, false),
					),
				})
				if (!targetMsg) {
					ws.send(JSON.stringify({ type: 'error', message: 'Сообщение не найдено' }))
					break
				}

				if (targetMsg.userAuthUuid !== ws.data.userId) {
					ws.send(
						JSON.stringify({
							type: 'error',
							message: 'Можно редактировать только свои сообщения',
						}),
					)
					break
				}

				const content = typeof msg.content === 'string' ? msg.content.slice(0, 4000).trimEnd() : ''
				const mentions = await normalizeMentions({
					chatId,
					userId: ws.data.userId,
					userRole: ws.data.userRole,
					content,
					mentions: Array.isArray(msg.mentions) ? msg.mentions : undefined,
				})

				await db
					.update(messages)
					.set({
						content,
						updatedAt: new Date(),
					})
					.where(eq(messages.id, messageId))

				await db.delete(messageMentions).where(eq(messageMentions.messageId, messageId))
				await createMessageMentions({
					chatId,
					messageId,
					authorUserId: ws.data.userId,
					mentions: mentions.map((mention) => ({
						mentionedUserAuthUuid: mention.mentionedUserAuthUuid,
						displayName: mention.displayName,
						startOffset: mention.startOffset,
						endOffset: mention.endOffset,
					})),
				})

				const updated = await loadMessageWithMeta(messageId)
				if (!updated) {
					ws.send(JSON.stringify({ type: 'error', message: 'Сообщение не найдено' }))
					break
				}

				await broadcastToRoom(`chat:${chatId}`, {
					type: 'message_updated',
					message: updated,
				})
				break
			}
		}
	} catch (err) {
		logger.error({ err, userId: ws.data.userId }, 'WS message error')
		ws.send(JSON.stringify({ type: 'error', message: 'Неверный формат сообщения' }))
	}
}

export function initRedisSubscriber() {
	if (redisSubscriberInitialized) return
	redisSubscriberInitialized = true

	redisSub.on('message', (channel, message) => {
		try {
			const envelope = JSON.parse(message) as RedisRoomEvent
			if (envelope.instanceId === serverInstanceId) return
			deliverToRoom(channel, envelope.payload, envelope.excludeUserId ?? undefined)
		} catch (err) {
			logger.error({ err, channel }, 'Failed to handle Redis room event')
		}
	})

	redisSub.on('error', (err) => {
		logger.error({ err }, 'Redis WS subscriber error')
	})

	logger.info('Redis WS subscriber initialized')
}
