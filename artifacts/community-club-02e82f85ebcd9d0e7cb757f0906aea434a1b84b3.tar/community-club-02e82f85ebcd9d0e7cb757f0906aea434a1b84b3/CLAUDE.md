# Community Club — Project Context

## Что это

`community-club-pwa` — монорепозиторий платформы `Community Club` для закрытого онлайн-сообщества.

Проект состоит из четырёх основных частей:
- `packages/api` — backend на `Bun + Hono + Drizzle`
- `packages/web` — пользовательское приложение на `Nuxt 3`
- `packages/admin` — админка на `Nuxt 3`
- `packages/shared` — общие типы, схемы БД и валидаторы

## Доменная карта

- Основной сайт: `https://clud.nepran-yuri.ru`
- Админка: `https://clud.nepran-yuri.ru/admin/`
- Медиа: `https://clud.nepran-yuri.ru/media/`
- Read-only staging: `https://staging.example.com`
- Demo: `https://demo-clud.nepran-yuri.ru`
- Demo admin: `https://demo-clud.nepran-yuri.ru/admin/`

## Сервер и доступ

- SSH: `root@193.124.33.21`
- Server OS: Ubuntu-like Linux, Docker host
- Production path: `/opt/community-club`
- Production compose file: `/opt/community-club/docker-compose.prod.yml`
- Demo path: `/opt/community-club-demo`
- Demo compose project: `community-club-demo`
- Demo compose file: `/opt/community-club-demo/docker-compose.prod.yml`
- Demo local ports: `3200` web, `3201` api, `3202` admin, `3922` media
- Demo deploy command: `./scripts/deploy-demo.sh`
- Staging path: `/opt/community-club-staging`
- Production env: `/opt/community-club/.env`
- Staging env: `/opt/community-club-staging/.env.staging`
- Reverse proxy: `/etc/caddy/Caddyfile`

Секреты и серверные конфиги не коммитятся:
- `.env`
- `.env.*`
- `secrets/`

## Runtime topology

### Production

- `web` → `127.0.0.1:3000`
- `api` → `127.0.0.1:3001`
- `admin` → `127.0.0.1:3002`
- `postgres` → `127.0.0.1:5432`
- `garage` → `127.0.0.1:3900`, публичная раздача медиа через `3902`
- `mail` → `Stalwart`
- `Caddy` маршрутизирует внешний трафик на локальные порты

### Demo

- Public URL: `https://demo-clud.nepran-yuri.ru`
- `web` → `127.0.0.1:3200`
- `api` → `127.0.0.1:3201`
- `admin` → `127.0.0.1:3202`
- `garage` media web endpoint → `127.0.0.1:3922`
- Caddy проксирует demo через `demo-clud.nepran-yuri.ru`.
- Деплой demo из репозитория: `./scripts/deploy-demo.sh`; wrapper задаёт `root@193.124.33.21`, `/opt/community-club-demo`, compose file `docker-compose.prod.yml`, compose project `community-club-demo` и smoke-порты `3200/3201/3202`.
- Для проверки видео/медиа использовать `Range`-запросы к `/media/<key>`; ожидаемый ответ: `206`, `accept-ranges: bytes`, `content-range`.
- `/opt/community-club-demo` может быть развернутой копией без `.git`.

### Staging

- `web` → `127.0.0.1:3100`
- `api` → `127.0.0.1:3101`
- `admin` → `127.0.0.1:3102`
- отдельный staging `Redis`
- боевая PostgreSQL только через `community_club_staging_ro`
- `APP_READ_ONLY=true`

В read-only staging:
- отключены startup `ensure*`-инициализации
- отключены фоновые job-процессоры
- отключён Telegram webhook sync
- отключён WebSocket
- запрещены все мутации, кроме `login`, `refresh`, `logout`

## Технологии

- package manager: `bun`
- workspace orchestration: `turbo`
- lint/format: `Biome`
- DB: `PostgreSQL 15`
- cache/realtime: `Redis 7`
- object storage: `Garage S3`
- payments: `CloudPayments`
- push: `VAPID Web Push`
- integrations: `Telegram`, `MAX`, payments

## Структура репозитория

### Root

- `package.json` — root workspace config
- `turbo.json` — pipeline
- `biome.json` — lint/format
- `docker-compose.prod.yml` — production services
- `docker-compose.staging.yml` — staging services
- `scripts/deploy-production.sh` — продовый деплой
- `scripts/deploy-demo.sh` — demo deploy
- `scripts/deploy-staging.sh` — staging деплой
- `docs/ops/deploy-production.md` — инструкция по production
- `docs/ops/deploy-staging.md` — инструкция по staging

### API

- `packages/api/src/app.ts` — Hono app и middleware
- `packages/api/src/index.ts` — entrypoint API и WebSocket
- `packages/api/src/config/env.ts` — env schema
- `packages/api/src/middleware/*` — auth, rate-limit, queue, read-only
- `packages/api/src/routes/*` — auth, users, chats, payments, media, admin и пр.
- `packages/api/src/lib/*` — storage, telegram, jobs, bootstrap, util-функции

### Web

- `packages/web/pages/index.vue` — публичная главная
- `packages/web/pages/login.vue` — логин
- `packages/web/pages/register.vue` — регистрация
- `packages/web/pages/app/**` — защищённая SPA-зона
- `packages/web/components/media/*` — просмотрщики медиа
- `packages/web/stores/*` — Pinia stores

### Admin

- `packages/admin/pages/admin/index.vue` — dashboard
- `packages/admin/pages/admin/materials.vue` — материалы
- `packages/admin/pages/admin/media.vue` — медиатека
- `packages/admin/pages/admin/users/**` — пользователи
- `packages/admin/pages/admin/payments.vue` — платежи

### Shared

- `packages/shared/src/db/schema/*` — таблицы Drizzle
- `packages/shared/src/db/schema/relations.ts` — связи
- `packages/shared/src/types/api.ts` — API-типы
- `packages/shared/src/types/ws.ts` — WS-типы
- `packages/shared/src/validators/*` — Zod-схемы

## Деплой

### Production

После успешного demo deploy команда:

```bash
./scripts/deploy-production.sh
```

Скрипт:
- запускает `bun run lint`
- запускает `bun run build`
- синхронизирует workspace в `/opt/community-club`
- выполняет `docker compose -f docker-compose.prod.yml build`
- выполняет `docker compose -f docker-compose.prod.yml up -d`
- проверяет `web`, `api`, `admin`, `health`

Обычный деплой не должен перетирать:
- `/opt/community-club/.env`
- `/opt/community-club/secrets/*`
- `/opt/community-club/docker-compose.prod.yml`

### Staging

Команда:

```bash
./scripts/deploy-staging.sh
```

Скрипт:
- запускает `bun run lint`
- запускает `bun run build`
- синхронизирует workspace в `/opt/community-club-staging`
- собирает `docker-compose.staging.yml`
- поднимает `api/web/admin/redis`
- делает smoke-check локальных staging-портов

## Что важно помнить агенту

- Не менять серверные секреты и `.env` без прямой необходимости.
- Не включать запись в staging.
- Не считать staging заменой production: это read-only стенд для проверки интерфейсов и чтения данных.
- Если задача касается деплоя, проверять и локальные файлы, и фактическое состояние на сервере.
- Если задача касается инфраструктуры, учитывать раздельные production, demo и staging контуры.
