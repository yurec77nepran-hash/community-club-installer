# Community Club PWA Template

Готовый шаблон production-oriented PWA для закрытого сообщества, клуба, школы или подписочного продукта.

Внутри уже есть пользовательское PWA, админка, API, PostgreSQL-схемы, платежный контур, медиа, чат, push-уведомления, фоновые задачи и Docker-конфигурация для staging/production.

## Стек

- `Bun 1.3.9`
- `Turbo`
- `Nuxt 3` для `web` и `admin`
- `Hono` API на Bun
- `Drizzle ORM` + `PostgreSQL`
- `Redis`
- `Garage S3`
- `CloudPayments`
- `Web Push`
- `Telegram`, MAX и платежные интеграции

## Структура

```text
packages/
  api/      Hono API, jobs, auth, payments, storage
  web/      пользовательское PWA
  admin/    админка
  shared/   DB-схемы, типы, валидаторы
docs/
  ops/      деплой, почта, сервер
scripts/    деплой и сервисные инструменты
```

## Быстрый старт

```bash
bun install
cp .env.example .env
docker compose up -d postgres redis
bun run db:migrate
bun run dev
```

После запуска:

- web: `http://localhost:3000`
- api: `http://localhost:3001`
- admin: `http://localhost:3002/admin`

## Установка на сервер

На пустом Ubuntu/Debian-like сервере шаблон можно поставить одной командой:

```bash
REPO_URL=https://github.com/your-org/community-club-template.git DOMAIN=club.example.com bash -c "$(curl -fsSL https://raw.githubusercontent.com/your-org/community-club-template/main/scripts/install-on-server.sh)"
```

Команда подготовит Docker, Caddy, Postgres, Redis, Garage, `.env`, секреты, схему БД и первый доступ в админку. Подробно: [docs/ops/server-bootstrap.md](docs/ops/server-bootstrap.md).

## Основные команды

```bash
bun run dev
bun run lint
bun run build
bun run db:generate
bun run db:migrate
bun run db:studio
```

## Настройка нового проекта

Перед использованием в новом продукте пройдите чеклист:

1. Замените `community-club` и `@community-club/*` на namespace проекта.
2. Обновите домены в `.env.example`, `.env.staging.example`, `docker-compose*.yml` и `docs/ops/*`.
3. Замените название `Community Club` в `packages/web/nuxt.config.ts`, `packages/admin/nuxt.config.ts`, письмах и публичных страницах.
4. Обновите legal-страницы: оферту, политику, реквизиты и контакты.
5. Замените PWA-иконки и изображения в `packages/web/public`.
6. Настройте `JWT_SECRET`, S3/Garage, платежи, VAPID, SMTP, Telegram и MAX.
7. Проверьте тарифы, матрицу доступа и bootstrap-данные в `packages/api/src/lib/*-bootstrap.ts`.
8. Запустите `bun run lint` и `bun run build`.

Подробнее: [docs/template-customization.md](docs/template-customization.md).

## Env

В репозиторий включены только примеры:

- `.env.example`
- `.env.staging.example`

Настоящие `.env`, `.env.*`, `secrets/` и Telegram session-файлы не коммитятся.

## Деплой

- Production: [docs/ops/deploy-production.md](docs/ops/deploy-production.md)
- Staging: [docs/ops/deploy-staging.md](docs/ops/deploy-staging.md)
- Mail: [docs/ops/mail.md](docs/ops/mail.md)

Скрипты деплоя сначала запускают `lint` и `build`, затем синхронизируют workspace на сервер и поднимают Docker Compose.

## NixOS

Шаблон не требует системной установки пакетов через `apt`/`brew`. Для NixOS удобно держать Bun, Docker и вспомогательные CLI в `devenv`, `direnv` или системной конфигурации. Локальные `.direnv/`, `.devenv/` и `result` уже исключены из git.
