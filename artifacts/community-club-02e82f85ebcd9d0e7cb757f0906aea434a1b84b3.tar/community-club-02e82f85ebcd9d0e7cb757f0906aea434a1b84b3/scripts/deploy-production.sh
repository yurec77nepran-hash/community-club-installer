#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_HOST="${SERVER_HOST:-root@193.124.33.21}"
SERVER_PATH="${SERVER_PATH:-/opt/community-club}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"
COMPOSE_FILES="${COMPOSE_FILES:-$COMPOSE_FILE}"
COMPOSE_PROJECT="${COMPOSE_PROJECT:-}"
SKIP_CHECKS="${SKIP_CHECKS:-0}"
SYNC_INFRA="${SYNC_INFRA:-0}"
DEPLOY_SERVICES="${DEPLOY_SERVICES:-auto}"
DEPLOY_MARKER_FILE="${DEPLOY_MARKER_FILE:-.deploy-rev}"
DOCKER_BUILD_NO_CACHE="${DOCKER_BUILD_NO_CACHE:-0}"
WEB_CHECK_PORT="${WEB_CHECK_PORT:-3000}"
API_CHECK_PORT="${API_CHECK_PORT:-3001}"
ADMIN_CHECK_PORT="${ADMIN_CHECK_PORT:-3002}"
PUBLIC_BASE_URL="${PUBLIC_BASE_URL:-https://clud.nepran-yuri.ru}"
DEPLOY_REV=""
LAST_DEPLOY_REV=""
SELECTED_SERVICES=""
SELECTED_SERVICES_MODE="partial"

shell_quote() {
  printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"
}

compose_args() {
  local args=""
  if [[ -n "$COMPOSE_PROJECT" ]]; then
    args+="-p $(shell_quote "$COMPOSE_PROJECT") "
  fi
  for file in $COMPOSE_FILES; do
    args+="-f $(shell_quote "$file") "
  done
  printf '%s' "$args"
}

select_all_services() {
  SELECTED_SERVICES="api web admin"
  SELECTED_SERVICES_MODE="all"
}

add_service() {
  case " ${SELECTED_SERVICES} " in
    *" $1 "*) ;;
    *) SELECTED_SERVICES="${SELECTED_SERVICES:+$SELECTED_SERVICES }$1" ;;
  esac
}

read_last_deploy_rev() {
  LAST_DEPLOY_REV="$(ssh "$SERVER_HOST" "cat '$SERVER_PATH/$DEPLOY_MARKER_FILE' 2>/dev/null || true" | tr -d '\r' | head -n 1)"
}

resolve_auto_services() {
  DEPLOY_REV="$(git -C "$ROOT_DIR" rev-parse --verify HEAD 2>/dev/null || true)"
  if [[ -z "$DEPLOY_REV" ]]; then
    echo "Git revision is unavailable; deploying all app services."
    select_all_services
    return
  fi

  if ! git -C "$ROOT_DIR" diff --quiet || ! git -C "$ROOT_DIR" diff --cached --quiet; then
    echo "Working tree has uncommitted changes; deploying all app services."
    select_all_services
    return
  fi

  read_last_deploy_rev
  if [[ -z "$LAST_DEPLOY_REV" ]] || ! git -C "$ROOT_DIR" merge-base --is-ancestor "$LAST_DEPLOY_REV" "$DEPLOY_REV" 2>/dev/null; then
    echo "No usable deploy marker found; deploying all app services."
    select_all_services
    return
  fi

  local changed_files
  changed_files="$(git -C "$ROOT_DIR" diff --name-only "$LAST_DEPLOY_REV..$DEPLOY_REV")"
  if [[ -z "$changed_files" ]]; then
    echo "No app source changes since $LAST_DEPLOY_REV; skipping service rebuild."
    SELECTED_SERVICES=""
    return
  fi

  while IFS= read -r file; do
    case "$file" in
      packages/api/*)
        add_service api
        ;;
      packages/web/*)
        add_service web
        ;;
      packages/admin/*)
        add_service admin
        ;;
      packages/shared/*|package.json|bun.lock|tsconfig.json|turbo.json|bunfig.toml|scripts/*|docker-compose*.yml)
        select_all_services
        return
        ;;
    esac
  done <<< "$changed_files"

  if [[ -z "$SELECTED_SERVICES" ]]; then
    echo "Changed files are docs/config-only; app containers stay as-is (images ship app code only)."
  fi
}

resolve_deploy_services() {
  if [[ "$DEPLOY_SERVICES" == "auto" ]]; then
    resolve_auto_services
  elif [[ "$DEPLOY_SERVICES" == "all" ]]; then
    select_all_services
  else
    SELECTED_SERVICES="$DEPLOY_SERVICES"
    SELECTED_SERVICES_MODE="partial"
  fi

  if [[ -n "$SELECTED_SERVICES" ]]; then
    echo "Deploy services: $SELECTED_SERVICES"
  fi
}

run_local_checks() {
  if [[ "$SKIP_CHECKS" == "1" ]]; then
    echo "Skipping local checks because SKIP_CHECKS=1"
    return
  fi

  echo "Running local lint..."
  (cd "$ROOT_DIR" && NUXT_TELEMETRY_DISABLED=1 bun run lint)

  echo "Running local build..."
  (cd "$ROOT_DIR" && NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=1536}" NUXT_TELEMETRY_DISABLED=1 bun --bun run build -- --concurrency=1)
}

sync_workspace() {
  echo "Syncing workspace to ${SERVER_HOST}:${SERVER_PATH} ..."

  local -a rsync_args=(
    -az
    --delete
    --exclude '.git'
    --exclude '.playwright-mcp'
    --exclude '.community-club-source'
    --exclude '.omo'
    --exclude 'node_modules'
    --exclude '.turbo'
    --exclude '.zcode'
    --exclude '.env'
    --exclude '.env.*'
    --exclude 'secrets'
    --exclude 'runtime'
    --exclude 'packages/*/node_modules'
    --exclude 'packages/*/.nuxt'
    --exclude 'packages/*/.output'
    --exclude 'packages/*/dist'
    --exclude 'packages/api/dist'
  )

  if [[ "$SYNC_INFRA" != "1" ]]; then
    rsync_args+=(--exclude 'docker-compose*.yml')
  fi

  rsync "${rsync_args[@]}" \
    "$ROOT_DIR"/ "${SERVER_HOST}:${SERVER_PATH}/"
}

deploy_remote() {
  if [[ -z "$SELECTED_SERVICES" ]]; then
    echo "No services selected for rebuild/restart."
    return
  fi

  echo "Building and restarting production services on ${SERVER_HOST} ..."

  local compose
  local build_flags=""
  local up_flags=""
  compose="$(compose_args)"
  if [[ "$DOCKER_BUILD_NO_CACHE" == "1" ]]; then
    build_flags="--no-cache"
  fi
  if [[ "$SELECTED_SERVICES_MODE" != "all" ]]; then
    up_flags="--no-deps"
  fi

  ssh "$SERVER_HOST" "cd '$SERVER_PATH' && \
    docker compose ${compose}build ${build_flags} ${SELECTED_SERVICES} && \
    docker compose ${compose}up -d ${up_flags} ${SELECTED_SERVICES}"
}

check_remote() {
  echo "Running post-deploy checks on ${SERVER_HOST} ..."

  local compose
  compose="$(compose_args)"
  ssh "$SERVER_HOST" "cd '$SERVER_PATH' && \
    docker compose ${compose}ps && \
    printf 'WEB=' && curl -s --retry 15 --retry-connrefused --retry-delay 2 -o /dev/null -w '%{http_code}' 'http://localhost:${WEB_CHECK_PORT}/' && \
    printf '\nAPI=' && curl -s --retry 15 --retry-connrefused --retry-delay 2 -o /dev/null -w '%{http_code}' 'http://localhost:${API_CHECK_PORT}/api/payments/tariffs' && \
    printf '\nADMIN=' && curl -s --retry 15 --retry-connrefused --retry-delay 2 -o /dev/null -w '%{http_code}' 'http://localhost:${ADMIN_CHECK_PORT}/admin/' && \
    printf '\nHEALTH=' && curl -s --retry 15 --retry-connrefused --retry-delay 2 'http://localhost:${API_CHECK_PORT}/health' && \
    printf '\n'"

  if [[ -n "$PUBLIC_BASE_URL" ]]; then
    echo "Running public checks for ${PUBLIC_BASE_URL} ..."
    curl -fsS --retry 6 --retry-delay 2 "${PUBLIC_BASE_URL}/" >/dev/null
    curl -fsS --retry 6 --retry-delay 2 "${PUBLIC_BASE_URL}/health" >/dev/null
    curl -fsS --retry 6 --retry-delay 2 "${PUBLIC_BASE_URL}/api/payments/tariffs" >/dev/null
    curl -fsS --retry 6 --retry-delay 2 "${PUBLIC_BASE_URL}/admin/" >/dev/null
  fi
}

write_deploy_marker() {
  if [[ "$DEPLOY_SERVICES" != "auto" || -z "$DEPLOY_REV" ]]; then
    return
  fi

  ssh "$SERVER_HOST" "printf '%s\n' '$DEPLOY_REV' > '$SERVER_PATH/$DEPLOY_MARKER_FILE'"
}

run_local_checks
resolve_deploy_services
sync_workspace
deploy_remote
check_remote
write_deploy_marker
