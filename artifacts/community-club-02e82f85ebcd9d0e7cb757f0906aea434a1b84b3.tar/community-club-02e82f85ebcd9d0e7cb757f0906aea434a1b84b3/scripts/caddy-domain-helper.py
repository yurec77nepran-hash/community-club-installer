#!/usr/bin/env python3
import json
import os
import re
import shlex
import subprocess
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


TOKEN = os.environ.get("DOMAIN_PROVISION_HELPER_TOKEN", "")
CONFIG_PATH = Path(
    os.environ.get("DOMAIN_PROVISION_CONFIG_PATH", "/etc/caddy/conf.d/community-club-domains.caddy")
)
CADDYFILE_PATH = os.environ.get("CADDYFILE_PATH", "/etc/caddy/Caddyfile")
RELOAD_COMMAND = os.environ.get("DOMAIN_PROVISION_RELOAD_COMMAND", "systemctl reload caddy")
BIND = os.environ.get("DOMAIN_PROVISION_HELPER_BIND", "127.0.0.1")
PORT = int(os.environ.get("DOMAIN_PROVISION_HELPER_PORT", "7823"))
MAX_BODY_BYTES = int(os.environ.get("DOMAIN_PROVISION_HELPER_MAX_BODY_BYTES", "65536"))
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?!-)[a-z0-9-]+(\.[a-z0-9-]+)+$", re.IGNORECASE)


def command_result(command: list[str]) -> dict:
    completed = subprocess.run(command, text=True, capture_output=True, check=False)
    output = "\n".join(part for part in [completed.stdout, completed.stderr] if part).strip()
    return {
        "ok": completed.returncode == 0,
        "command": " ".join(command),
        "exitCode": completed.returncode,
        "output": output[:4000],
    }


def shell_command_result(command: str) -> dict:
    try:
        args = shlex.split(command)
    except ValueError as error:
        return {
            "ok": False,
            "command": command,
            "exitCode": None,
            "output": str(error),
        }
    if not args:
        return {"ok": True, "command": command, "exitCode": 0, "output": ""}
    completed = subprocess.run(args, shell=False, text=True, capture_output=True, check=False)
    output = "\n".join(part for part in [completed.stdout, completed.stderr] if part).strip()
    return {
        "ok": completed.returncode == 0,
        "command": command,
        "exitCode": completed.returncode,
        "output": output[:4000],
    }


def write_json(handler: BaseHTTPRequestHandler, status: int, payload: dict) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args) -> None:
        return

    def do_GET(self) -> None:
        if self.path == "/health":
            write_json(self, 200, {"ok": True})
            return
        write_json(self, 404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:
        if self.path != "/provision":
            write_json(self, 404, {"ok": False, "error": "not_found"})
            return
        if not TOKEN or self.headers.get("Authorization") != f"Bearer {TOKEN}":
            write_json(self, 401, {"ok": False, "error": "unauthorized"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_BODY_BYTES:
                write_json(self, 413, {"ok": False, "error": "payload_too_large"})
                return
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            domain = str(payload.get("domain", "")).strip().lower()
            content = str(payload.get("content", ""))
        except Exception as error:
            write_json(self, 400, {"ok": False, "error": str(error)})
            return

        if (
            not DOMAIN_RE.match(domain)
            or not content.startswith("# Managed by Community Club admin.")
            or f"\n{domain} {{" not in f"\n{content}"
        ):
            write_json(self, 400, {"ok": False, "error": "invalid_domain"})
            return

        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        previous = CONFIG_PATH.read_text("utf-8") if CONFIG_PATH.exists() else None
        fd, temp_name = tempfile.mkstemp(prefix=f"{CONFIG_PATH.name}.", dir=str(CONFIG_PATH.parent))
        os.close(fd)
        temp_path = Path(temp_name)

        try:
            temp_path.write_text(content, "utf-8")
            temp_path.chmod(0o644)
            temp_path.replace(CONFIG_PATH)

            validate = command_result(["caddy", "validate", "--config", CADDYFILE_PATH])
            if not validate["ok"]:
                if previous is None:
                    CONFIG_PATH.unlink(missing_ok=True)
                else:
                    CONFIG_PATH.write_text(previous, "utf-8")
                    CONFIG_PATH.chmod(0o644)
                write_json(self, 200, {"ok": False, "validate": validate})
                return

            reload_result = shell_command_result(RELOAD_COMMAND)
            write_json(
                self,
                200,
                {
                    "ok": validate["ok"] and reload_result["ok"],
                    "validate": validate,
                    "reload": reload_result,
                },
            )
        except Exception as error:
            if previous is None:
                CONFIG_PATH.unlink(missing_ok=True)
            else:
                CONFIG_PATH.write_text(previous, "utf-8")
                CONFIG_PATH.chmod(0o644)
            write_json(self, 500, {"ok": False, "error": str(error)})
        finally:
            temp_path.unlink(missing_ok=True)


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DOMAIN_PROVISION_HELPER_TOKEN is required")
    ThreadingHTTPServer((BIND, PORT), Handler).serve_forever()
