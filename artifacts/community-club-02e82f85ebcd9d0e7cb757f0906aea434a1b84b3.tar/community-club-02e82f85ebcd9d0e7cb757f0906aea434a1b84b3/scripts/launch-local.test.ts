import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const scriptPath = new URL('./launch-local.sh', import.meta.url)
const turboConfigPath = new URL('../turbo.json', import.meta.url)

describe('local launcher', () => {
	test('prints local app, admin, and API URLs and starts monorepo dev mode', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('APP_URL="${APP_URL:-http://localhost:3000}"')
		expect(script).toContain('ADMIN_URL="${ADMIN_URL:-http://localhost:3002/admin}"')
		expect(script).toContain('API_URL="${API_URL:-http://localhost:3001}"')
		expect(script).toContain('bun run dev')
	})

	test('prepares local postgres and redis without assuming Docker only', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('find_compose_command')
		expect(script).toContain('postgres redis')
		expect(script).toContain('start_podman_infra')
		expect(script).toContain('podman run')
		expect(script).toContain('{{.State.Status}}')
	})

	test('updates project dependencies and local infra images', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('update_project_dependencies')
		expect(script).toContain('bun install')
		expect(script).toContain('bun update')
		expect(script).toContain('update_container_images')
		expect(script).toContain('pull "${services[@]}"')
		expect(script).toContain('podman pull')
		expect(script).toContain('прила обнови')
	})

	test('exports root env before starting package dev scripts', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('load_env_file')
		expect(script).toContain('while IFS= read -r line')
		expect(script).toContain('export "$key=$value"')
		expect(script).not.toContain('source "$ROOT_DIR/.env"')
	})

	test('allows local runtime env through turbo without leaking API port into web', async () => {
		const turboConfig = JSON.parse(await readFile(turboConfigPath, 'utf8'))

		expect(turboConfig.globalPassThroughEnv).toContain('DATABASE_URL')
		expect(turboConfig.globalPassThroughEnv).toContain('JWT_SECRET')
		expect(turboConfig.globalPassThroughEnv).toContain('API_URL')
		expect(turboConfig.globalPassThroughEnv).toContain('ADMIN_URL')
		expect(turboConfig.globalPassThroughEnv).not.toContain('PORT')
	})
})
