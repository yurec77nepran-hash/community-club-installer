import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const scriptPath = new URL('./server-bootstrap.sh', import.meta.url)

describe('server bootstrap', () => {
	test('applies database schema non-interactively during install', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('DRIZZLE_PUSH_FORCE')
		expect(script).toContain('drizzle-kit push --config drizzle.config.ts --force')
		expect(script).toContain('grep -E')
		expect(script).toContain('(^|[[:space:]])error:')
	})

	test('installs retained CLI config without obsolete distribution metadata', async () => {
		const script = await readFile(scriptPath, 'utf8')
		const installCli = script.slice(
			script.indexOf('install_club_cli()'),
			script.indexOf('choose_env_port()'),
		)

		expect(installCli).toContain("printf 'APP_DIR=%s\\n'")
		expect(installCli).toContain("printf 'APP_NAME=%s\\n'")
		expect(installCli).toContain("printf 'COMPOSE_PROJECT_NAME=%s\\n'")
		expect(installCli).not.toContain('SOURCE_ORIGIN')
		expect(installCli).not.toContain('INSTALL_EMAIL')
		expect(installCli).not.toContain('read_source_marker_value')
	})

	test('replaces example mail and push placeholders during bootstrap', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('set_env_if_placeholder VAPID_EMAIL')
		expect(script).toContain('set_env_if_placeholder MAIL_FROM_EMAIL')
		expect(script).toContain('set_env_if_placeholder MAIL_HOSTNAME')
		expect(script).toContain('mail.community.local')
		expect(script).toContain('coreutils')
	})

	test('proxies every unmatched path to web instead of only the root path', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toMatch(/handle \{\s+reverse_proxy 127\.0\.0\.1:\$\{web_port\}\s+\}/)
		expect(script).not.toContain('reverse_proxy / 127.0.0.1:${web_port}')
	})

	test('fails installation unless public health, Nuxt asset, and manifest are valid', async () => {
		const script = await readFile(scriptPath, 'utf8')

		expect(script).toContain('verify_public_app')
		expect(script).toContain('/pwa-manifest')
		expect(script).toContain('/_nuxt/')
		expect(script).toContain('application/manifest\\+json')
		expect(script).toContain('javascript')
		expect(script).not.toContain('Публичная ссылка пока не ответила')
	})

	test('repairs Caddy apt files atomically with readable modes after a partial failure', async () => {
		const script = await readFile(scriptPath, 'utf8')
		const installCaddy = script.slice(
			script.indexOf('install_caddy()'),
			script.indexOf('ensure_build_swap()'),
		)

		expect(installCaddy).toContain(
			'mktemp /usr/share/keyrings/caddy-stable-archive-keyring.gpg.XXXXXX',
		)
		expect(installCaddy).toContain('mktemp /etc/apt/sources.list.d/caddy-stable.list.XXXXXX')
		expect(installCaddy).toContain('gpg --batch --yes --dearmor')
		expect(installCaddy).toContain('chmod 0644')
		expect(installCaddy).toContain('mv')
		expect(installCaddy).toContain('trap')
		expect(installCaddy).toContain('https://dl.cloudsmith.io/public/caddy/stable/gpg.key')
		expect(installCaddy).toContain('https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt')
		expect(installCaddy).toContain('signed-by=/usr/share/keyrings/caddy-stable-archive-keyring.gpg')
		expect(installCaddy).not.toContain(
			'if [[ ! -f /usr/share/keyrings/caddy-stable-archive-keyring.gpg ]]',
		)
	})

	test('keeps Caddy configuration readable under a restrictive umask', async () => {
		const script = await readFile(scriptPath, 'utf8')
		const ensureCaddyImport = script.slice(
			script.indexOf('ensure_caddy_import()'),
			script.indexOf('write_caddy_snippet()'),
		)
		const writeCaddySnippet = script.slice(
			script.indexOf('write_caddy_snippet()'),
			script.indexOf('install_caddy_domain_helper()'),
		)

		expect(ensureCaddyImport).toContain('run_root install -d -m 0755 /etc/caddy/conf.d')
		expect(ensureCaddyImport).toContain('run_root chmod 0644 "$CADDYFILE_PATH"')
		expect(writeCaddySnippet).toContain('run_root chmod 0644 "$CADDY_SNIPPET_PATH"')
	})
})
