#!/usr/bin/env bash
# Инициализация GarageHQ: секреты, layout, бакеты, ключи доступа
set -euo pipefail

COMPOSE_FILE="${1:-docker-compose.prod.yml}"
SECRETS_DIR="./secrets"
ENV_FILE=".env"
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-community-club}"
GARAGE_CLI_TIMEOUT_SECONDS="${GARAGE_CLI_TIMEOUT_SECONDS:-30}"
GARAGE_READY_TIMEOUT_SECONDS="${GARAGE_READY_TIMEOUT_SECONDS:-120}"

compose() {
  docker compose -p "$COMPOSE_PROJECT_NAME" -f "$COMPOSE_FILE" "$@"
}

garage_exec() {
  local container_id
  container_id="$(compose ps -q garage)"
  if [ -z "$container_id" ]; then
    echo "[ERROR] Контейнер Garage не найден" >&2
    exit 1
  fi
  timeout "${GARAGE_CLI_TIMEOUT_SECONDS}s" docker exec "$container_id" "$@"
}

wait_for_garage() {
  local deadline
  deadline=$((SECONDS + GARAGE_READY_TIMEOUT_SECONDS))
  while [ "$SECONDS" -lt "$deadline" ]; do
    if garage_exec /garage node id >/dev/null 2>&1; then
      echo "[OK] Garage отвечает"
      return
    fi
    sleep 2
  done

  echo "[ERROR] Garage не ответил за ${GARAGE_READY_TIMEOUT_SECONDS}s" >&2
  compose ps garage >&2 || true
  compose logs --tail=80 garage >&2 || true
  exit 1
}

get_env() {
  local key="$1"
  if [ -f "$ENV_FILE" ]; then
    awk -F= -v key="$key" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$ENV_FILE"
  fi
}

echo "=== GarageHQ Init ==="

# 1. Генерация секретов
mkdir -p "$SECRETS_DIR"

if [ ! -f "$SECRETS_DIR/garage_rpc_secret" ]; then
  openssl rand -hex 32 > "$SECRETS_DIR/garage_rpc_secret"
  chmod 600 "$SECRETS_DIR/garage_rpc_secret"
  echo "[OK] RPC secret сгенерирован"
else
  chmod 600 "$SECRETS_DIR/garage_rpc_secret"
  echo "[SKIP] RPC secret уже существует"
fi

if [ ! -f "$SECRETS_DIR/garage_admin_token" ]; then
  openssl rand -hex 32 > "$SECRETS_DIR/garage_admin_token"
  chmod 600 "$SECRETS_DIR/garage_admin_token"
  echo "[OK] Admin token сгенерирован"
else
  chmod 600 "$SECRETS_DIR/garage_admin_token"
  echo "[SKIP] Admin token уже существует"
fi

# 2. Запуск Garage
echo ""
echo "Запуск Garage..."
compose up -d garage
wait_for_garage

# 3. Node ID и layout
echo ""
echo "Настройка layout..."
NODE_ID=$(garage_exec /garage node id 2>/dev/null | head -1 | cut -d'@' -f1)
if [ -z "$NODE_ID" ]; then
  echo "[ERROR] Не удалось получить Node ID Garage" >&2
  compose logs --tail=80 garage >&2 || true
  exit 1
fi
echo "Node ID: $NODE_ID"

# Назначаем layout: зона dc1, ёмкость 50G
garage_exec /garage layout assign "$NODE_ID" -z dc1 -c 50G -t community-node 2>/dev/null || true
LAYOUT_OUTPUT="$(garage_exec /garage layout show 2>/dev/null || true)"
LAYOUT_VERSION="$(echo "$LAYOUT_OUTPUT" | sed -n \
  -e 's/.*layout apply --version \([0-9][0-9]*\).*/\1/p' \
  -e 's/.*TO APPLY.*VERSION \([0-9][0-9]*\).*/\1/p' | head -1)"
if [ -n "$LAYOUT_VERSION" ]; then
  garage_exec /garage layout apply --version "$LAYOUT_VERSION" 2>/dev/null || echo "Layout уже применён"
else
  garage_exec /garage layout apply --version 1 2>/dev/null || echo "Layout уже применён"
fi

echo "[OK] Layout настроен"

# 4. Создание бакетов
echo ""
echo "Создание бакетов..."
for BUCKET in media chat-attachments avatars; do
  garage_exec /garage bucket create "$BUCKET" 2>/dev/null || echo "Bucket '$BUCKET' уже существует"
done

# Делаем media bucket доступным через web endpoint
garage_exec /garage bucket website --allow media 2>/dev/null || true
garage_exec /garage bucket website --allow avatars 2>/dev/null || true

echo "[OK] Бакеты созданы"

# 5. Создание ключа доступа
echo ""
echo "Создание ключа доступа..."
EXISTING_ACCESS_KEY="$(get_env S3_ACCESS_KEY)"
EXISTING_SECRET_KEY="$(get_env S3_SECRET_KEY)"
KEY_NAME="community-club-api"
ACCESS_KEY="$EXISTING_ACCESS_KEY"
SECRET_KEY="$EXISTING_SECRET_KEY"
if [ -n "$ACCESS_KEY" ] && [ -n "$SECRET_KEY" ] &&
  ! garage_exec /garage key info "$ACCESS_KEY" >/dev/null 2>&1; then
  ACCESS_KEY=""
  SECRET_KEY=""
fi

if [ -z "$ACCESS_KEY" ] || [ -z "$SECRET_KEY" ]; then
  KEY_OUTPUT=$(garage_exec /garage key create "$KEY_NAME" 2>/dev/null || true)
  ACCESS_KEY=$(echo "$KEY_OUTPUT" | grep -i "key id" | awk '{print $NF}')
  SECRET_KEY=$(echo "$KEY_OUTPUT" | grep -i "secret" | awk '{print $NF}')
fi

if [ -z "$ACCESS_KEY" ] || [ -z "$SECRET_KEY" ]; then
  KEY_NAME="community-club-api-$(date +%s)"
  KEY_OUTPUT=$(garage_exec /garage key create "$KEY_NAME")
  ACCESS_KEY=$(echo "$KEY_OUTPUT" | grep -i "key id" | awk '{print $NF}')
  SECRET_KEY=$(echo "$KEY_OUTPUT" | grep -i "secret" | awk '{print $NF}')
fi

if [ -z "$ACCESS_KEY" ] || [ -z "$SECRET_KEY" ]; then
  echo "[ERROR] Не удалось получить S3 key id/secret. Существующий .env не содержит S3_ACCESS_KEY/S3_SECRET_KEY." >&2
  exit 1
fi

echo "[OK] Ключ доступа подготовлен"

# 6. Назначение прав на бакеты
echo ""
echo "Назначение прав..."
for BUCKET in media chat-attachments avatars; do
  garage_exec /garage bucket allow --read --write --owner "$BUCKET" --key "$ACCESS_KEY" 2>/dev/null || true
done

echo "[OK] Права назначены"

# 7. Обновление .env файла
echo ""
echo "Обновление .env..."

update_env() {
  local key="$1"
  local value="$2"
  if grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
  else
    echo "${key}=${value}" >> "$ENV_FILE"
  fi
}

update_env "S3_ENDPOINT" "http://garage:3900"
update_env "S3_REGION" "garage"
update_env "S3_ACCESS_KEY" "$ACCESS_KEY"
update_env "S3_SECRET_KEY" "$SECRET_KEY"
update_env "S3_BUCKET_MEDIA" "media"
update_env "S3_BUCKET_CHAT" "chat-attachments"
update_env "S3_BUCKET_AVATARS" "avatars"
# Публичный URL для медиа (будет проксироваться через Caddy)
if grep -q "^APP_URL=" "$ENV_FILE" 2>/dev/null; then
  APP_URL_VALUE="$(awk -F= '$1=="APP_URL"{ sub(/^[^=]*=/, ""); print; exit }' "$ENV_FILE")"
  update_env "S3_PUBLIC_URL" "${APP_URL_VALUE}/media"
fi

echo "[OK] .env обновлён"

echo ""
echo "=== GarageHQ готов ==="
echo ""
echo "S3 Endpoint: http://localhost:3900"
echo "Web Endpoint: http://localhost:3902"
echo "Admin API:    http://localhost:3903"
echo ""
echo "Бакеты: media, chat-attachments, avatars"
echo "Ключи доступа записаны в .env"
