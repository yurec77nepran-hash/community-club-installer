#!/usr/bin/env bash
set -euo pipefail

APP_NAME_WAS_SET="${APP_NAME+x}"
APP_NAME="${APP_NAME:-community-club}"
APP_NAME_EXPLICIT="${APP_NAME_EXPLICIT:-$APP_NAME_WAS_SET}"
APP_DIR="${APP_DIR:-/opt/${APP_NAME}}"
REPO_URL="${REPO_URL:-}"
BRANCH="${BRANCH:-main}"
INSTALL_SYSTEM_DEPS="${INSTALL_SYSTEM_DEPS:-1}"
UPDATE_EXISTING_PACKAGES="${UPDATE_EXISTING_PACKAGES:-0}"
INSTALL_ALONGSIDE="${INSTALL_ALONGSIDE:-1}"
RUN_BOOTSTRAP="${RUN_BOOTSTRAP:-1}"
PROJECT_DIR=""

log() {
	printf '\n==> %s\n' "$*" >&2
}

ok() {
	printf '[OK] %s\n' "$*" >&2
}

warn() {
	printf '[WARN] %s\n' "$*" >&2
}

fail() {
	printf '[ERROR] %s\n' "$*" >&2
	exit 1
}

run_root() {
	if [[ "$(id -u)" == "0" ]]; then
		"$@"
	elif command -v sudo >/dev/null 2>&1; then
		sudo "$@"
	else
		fail "Нужны root-права или sudo"
	fi
}

detect_os() {
	if [[ ! -f /etc/os-release ]]; then
		fail "Автоустановка поддерживает Ubuntu/Debian-like Linux"
	fi
	# shellcheck disable=SC1091
	. /etc/os-release
	case "${ID:-}" in
		ubuntu | debian) ;;
		*)
			case "${ID_LIKE:-}" in
				*debian* | *ubuntu*) ;;
				*) fail "Автоустановка поддерживает Ubuntu/Debian-like Linux. Текущая ОС: ${PRETTY_NAME:-unknown}" ;;
			esac
			;;
	esac
}

ensure_apt_packages() {
	local packages=("$@")
	[[ "${#packages[@]}" == "0" ]] && return
	run_root apt-get update
	if [[ "$UPDATE_EXISTING_PACKAGES" == "1" ]]; then
		run_root apt-get install -y --only-upgrade "${packages[@]}" || true
	fi
	run_root apt-get install -y "${packages[@]}"
}

install_minimal_dependencies() {
	log "Проверяю зависимости установщика"
	local missing=()
	for bin in curl git; do
		if ! command -v "$bin" >/dev/null 2>&1; then
			missing+=("$bin")
		fi
	done
	if ! dpkg -s ca-certificates >/dev/null 2>&1; then
		missing+=(ca-certificates)
	fi

	if [[ "${#missing[@]}" == "0" ]]; then
		ok "Зависимости установщика уже есть"
		return
	fi

	[[ "$INSTALL_SYSTEM_DEPS" == "1" ]] || fail "Нет зависимостей: ${missing[*]}"
	ensure_apt_packages ca-certificates curl git
}

ensure_repo_url() {
	if [[ -n "$REPO_URL" ]]; then
		return
	fi

	if [[ -d .git ]]; then
		REPO_URL="$(git remote get-url origin 2>/dev/null || true)"
	fi
	if [[ -z "$REPO_URL" ]]; then
		local script_dir
		script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd || true)"
		if [[ -n "$script_dir" && -d "${script_dir}/../.git" ]]; then
			REPO_URL="$(git -C "${script_dir}/.." remote get-url origin 2>/dev/null || true)"
		fi
	fi

	[[ -n "$REPO_URL" ]] || fail "Укажи REPO_URL, например: REPO_URL=https://github.com/org/community-club-template.git"
}

prepare_clone_target() {
	local dir="$1"
	run_root mkdir -p "$(dirname "$dir")"
	if [[ ! -e "$dir" ]]; then
		run_root mkdir -p "$dir"
	fi
	if [[ -d "$dir" && -z "$(find "$dir" -mindepth 1 -maxdepth 1 -print -quit)" && "$(id -u)" != "0" ]]; then
		run_root chown "$(id -u):$(id -g)" "$dir"
	fi
}

next_sibling_dir() {
	local base="$1"
	local stamp candidate index
	stamp="$(date +%Y%m%d%H%M%S)"
	candidate="${base}-${stamp}"
	index=1
	while [[ -e "$candidate" ]]; do
		candidate="${base}-${stamp}-${index}"
		index=$((index + 1))
	done
	printf '%s' "$candidate"
}

sanitize_app_name() {
	local value="$1"
	value="$(basename "$value" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9-]+/-/g; s/^-+//; s/-+$//')"
	printf '%s' "${value:-community-club}"
}

clone_repo() {
	local target="$1"
	prepare_clone_target "$target"
	log "Клонирую шаблон в ${target}"
	git clone --branch "$BRANCH" --single-branch "$REPO_URL" "$target" >&2
	ok "Код шаблона получен"
}

try_update_repo() {
	local target="$1"
	local remote
	remote="$(git -C "$target" remote get-url origin 2>/dev/null || true)"
	if [[ "$remote" != "$REPO_URL" ]]; then
		warn "${target} уже git-проект с другим origin, поставлю шаблон рядом"
		return 1
	fi

	if [[ -n "$(git -C "$target" status --short)" ]]; then
		warn "${target} содержит незакоммиченные изменения, поставлю шаблон рядом"
		return 1
	fi

	log "Обновляю существующий шаблон в ${target}"
	git -C "$target" fetch origin "$BRANCH" >&2
	git -C "$target" checkout "$BRANCH" >&2
	if ! git -C "$target" pull --ff-only origin "$BRANCH" >&2; then
		warn "Не удалось обновить ${target} fast-forward, поставлю шаблон рядом"
		return 1
	fi
	ok "Существующий шаблон обновлён"
	return 0
}

prepare_project_dir() {
	if [[ ! -e "$APP_DIR" ]]; then
		clone_repo "$APP_DIR"
		PROJECT_DIR="$APP_DIR"
		return
	fi

	if [[ -d "$APP_DIR/.git" ]] && try_update_repo "$APP_DIR"; then
		PROJECT_DIR="$APP_DIR"
		return
	fi

	if [[ -d "$APP_DIR" && -z "$(find "$APP_DIR" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
		clone_repo "$APP_DIR"
		PROJECT_DIR="$APP_DIR"
		return
	fi

	[[ "$INSTALL_ALONGSIDE" == "1" ]] || fail "${APP_DIR} уже занят"
	local sibling
	sibling="$(next_sibling_dir "$APP_DIR")"
	clone_repo "$sibling"
	APP_DIR="$sibling"
	if [[ -z "$APP_NAME_EXPLICIT" ]]; then
		APP_NAME="$(sanitize_app_name "$sibling")"
		ok "Для соседней установки выбрано имя проекта: ${APP_NAME}"
	else
		warn "APP_NAME задан явно (${APP_NAME}); проверь, что compose-имя и Caddy snippet не конфликтуют с соседними проектами"
	fi
	PROJECT_DIR="$APP_DIR"
}

run_bootstrap() {
	local project_dir="$1"
	[[ "$RUN_BOOTSTRAP" == "1" ]] || return
	log "Запускаю production bootstrap"
	cd "$project_dir"
	APP_NAME="$APP_NAME" \
		INSTALL_SYSTEM_DEPS="$INSTALL_SYSTEM_DEPS" \
		UPDATE_EXISTING_PACKAGES="$UPDATE_EXISTING_PACKAGES" \
		./scripts/server-bootstrap.sh
}

main() {
	detect_os
	install_minimal_dependencies
	ensure_repo_url

	prepare_project_dir
	run_bootstrap "$PROJECT_DIR"

	cat <<OUT

Установка завершена.
Проект: ${PROJECT_DIR}

Повторный запуск безопасен: чистый существующий шаблон обновится, занятая или грязная директория не будет перезаписана.
OUT
}

main "$@"
