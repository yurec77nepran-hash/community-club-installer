import { describe, expect, test } from 'bun:test'
import { chmod, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const cliPath = new URL('./club-cli.sh', import.meta.url).pathname

const homeSettings = {
	mainBanner: {
		mediaKey: 'image/old-banner.png',
		mediaUrl: 'https://media.example/old-banner.png',
		alt: 'Главный баннер клуба',
	},
	banners: [
		{
			id: 'banner-1',
			title: 'Новости',
			subtitle: 'Важное',
			backgroundColor: '#111111',
			textColor: '#ffffff',
			mediaKey: 'image/secondary.png',
			mediaUrl: 'https://media.example/secondary.png',
			actionKind: 'internal',
			internalPath: '/app/feed',
			externalUrl: '',
			requiresAuth: true,
			storiesEnabled: false,
		},
	],
	bannerShape: 'rounded',
	stories: [],
	highlights: [],
	sectionLayout: 'featured',
	sections: [
		{
			id: 'section-1',
			title: 'Материалы',
			subtitle: '',
			backgroundColor: '#222222',
			textColor: '#ffffff',
			mediaKey: null,
			mediaUrl: null,
			icon: 'book',
			visualMode: 'icon',
			textMode: 'visible',
			actionKind: 'internal',
			internalPath: '/app/materials',
			externalUrl: '',
			requiresAuth: true,
		},
	],
	customPages: [],
}

describe('club admin seed-main-banner', () => {
	test('uploads once and preserves home settings when rerun', async () => {
		// Given: an authenticated CLI contour with no seeded media object.
		const sandbox = await mkdtemp(join(tmpdir(), 'club-cli-main-banner-'))
		const binDir = join(sandbox, 'bin')
		const stateDir = join(sandbox, 'state')
		await mkdir(binDir)
		await mkdir(stateDir)
		await writeFile(join(stateDir, 'home.json'), JSON.stringify(homeSettings))
		await writeFile(
			join(sandbox, 'cookies'),
			'localhost\tFALSE\t/\tFALSE\t0\tcsrf_token\ttest-csrf-token-1234567890\n',
		)

		const fakeCurlPath = join(binDir, 'curl')
		await writeFile(
			fakeCurlPath,
			`#!/usr/bin/env bash
set -euo pipefail
printf '%q ' "$@" >>"$CLUB_TEST_REQUESTS"
printf '\n' >>"$CLUB_TEST_REQUESTS"
method=GET
body=''
previous=''
has_cookie=0
has_csrf=0
for argument in "$@"; do
	if [[ "$previous" == '-X' ]]; then method="$argument"; fi
	if [[ "$previous" == '--data-binary' ]]; then body="$argument"; fi
	if [[ "$previous" == '-b' ]]; then has_cookie=1; fi
	if [[ "$previous" == '-H' && "$argument" == 'X-CSRF-Token: test-csrf-token-1234567890' ]]; then has_csrf=1; fi
	previous="$argument"
done
url="\${!#}"
if [[ "$has_cookie" != '1' || ( "$method" != 'GET' && "$has_csrf" != '1' ) ]]; then
	printf '{"success":false,"error":{"message":"authentication headers missing"}}\n403'
elif [[ "$url" == *'/api/admin/media-library?'* ]]; then
	if [[ -f "$CLUB_TEST_STATE/media-key" ]]; then
		key="$(<"$CLUB_TEST_STATE/media-key")"
		printf '{"success":true,"data":{"items":[{"key":"%s","name":"1720000000000-community-club-main-banner-seed-v1.png","type":"image"}],"nextCursor":null}}\n200' "$key"
	else
		printf '{"success":true,"data":{"items":[],"nextCursor":null}}\n200'
	fi
elif [[ "$url" == *'/api/media/upload/raw?'* ]]; then
	key='image/1720000000000-community-club-main-banner-seed-v1.png'
	printf '%s' "$key" >"$CLUB_TEST_STATE/media-key"
	printf 'upload\n' >>"$CLUB_TEST_STATE/uploads.log"
	printf '{"success":true,"data":{"path":"%s","bucket":"media","size":42,"contentType":"image/png","mediaType":"image","url":"https://media.example/seed.png"}}\n200' "$key"
elif [[ "$url" == *'/api/admin/home-experience' && "$method" == 'PUT' ]]; then
	printf '%s' "$body" >"$CLUB_TEST_STATE/home.json"
	printf '%s\n' "$body" >>"$CLUB_TEST_PUT_BODIES"
	printf '{"success":true,"data":%s}\n200' "$body"
elif [[ "$url" == *'/api/admin/home-experience' ]]; then
	printf '{"success":true,"data":%s}\n200' "$(<"$CLUB_TEST_STATE/home.json")"
else
	printf '{"success":false,"error":{"message":"unexpected request"}}\n500'
fi
`,
		)
		await chmod(fakeCurlPath, 0o755)
		const assetPath = join(sandbox, 'banner.png')
		await writeFile(assetPath, 'png fixture')
		const env = {
			...process.env,
			PATH: `${binDir}:${process.env.PATH ?? ''}`,
			APP_DIR: sandbox,
			CLUB_CONFIG: join(sandbox, 'missing.conf'),
			CLUB_ADMIN_API_URL: 'http://club.test',
			CLUB_ADMIN_COOKIE: join(sandbox, 'cookies'),
			CLUB_TEST_REQUESTS: join(stateDir, 'requests.log'),
			CLUB_TEST_PUT_BODIES: join(stateDir, 'put-bodies.log'),
			CLUB_TEST_STATE: stateDir,
		}

		// When: the same seed command is run twice.
		const first = Bun.spawn(['bash', cliPath, 'admin', 'seed-main-banner', assetPath], { env })
		const firstExitCode = await first.exited
		const second = Bun.spawn(['bash', cliPath, 'admin', 'seed-main-banner', assetPath], { env })
		const secondExitCode = await second.exited

		// Then: media and settings are written once, with only the main media key changed.
		expect(firstExitCode).toBe(0)
		expect(secondExitCode).toBe(0)
		const uploads = (await readFile(join(stateDir, 'uploads.log'), 'utf8')).trim().split('\n')
		expect(uploads).toHaveLength(1)
		const putBodies = (await readFile(env.CLUB_TEST_PUT_BODIES, 'utf8')).trim().split('\n')
		expect(putBodies).toHaveLength(1)
		expect(JSON.parse(putBodies[0] ?? '')).toEqual({
			...homeSettings,
			mainBanner: {
				mediaKey: 'image/1720000000000-community-club-main-banner-seed-v1.png',
				alt: 'Главный баннер клуба',
			},
		})
	})
})
