import { describe, expect, test } from 'bun:test'
import { access, readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'

const repositoryRoot = new URL('../', import.meta.url)
const currentTestPath = 'scripts/obsolete-integrations-removal.test.ts'
const join = (parts: readonly string[]): string => parts.join('')

const obsoleteFiles = [
	'scripts/install-from-source-server.sh',
	'scripts/download-source-from-source-server.sh',
	'scripts/publish-source-server.sh',
	'docs/ops/source-server-installation.md',
	'packages/api/src/lib/template-downloads.ts',
	'packages/api/src/lib/template-downloads.test.ts',
	'packages/api/src/routes/templates.ts',
	'packages/api/src/routes/git-proxy.ts',
	'scripts/push-template-to-git-club.sh',
	'INSTALL.txt',
	'scripts/source-installation.test.ts',
	'packages/api/sql/20260824_add_materials_git_repo.sql',
] as const

const trackedRepositoryText = async (): Promise<string> => {
	const output = await Bun.$`git -C ${fileURLToPath(repositoryRoot)} ls-files -z`.arrayBuffer()
	const deletedOutput =
		await Bun.$`git -C ${fileURLToPath(repositoryRoot)} ls-files --deleted -z`.arrayBuffer()
	const paths = new TextDecoder().decode(output).split('\0').filter(Boolean)
	const deletedPaths = new Set(new TextDecoder().decode(deletedOutput).split('\0').filter(Boolean))
	const sourcePaths = paths.filter((path) => path !== currentTestPath && !deletedPaths.has(path))
	const sources = await Promise.all(
		sourcePaths.map((path) => readFile(new URL(path, repositoryRoot), 'utf8')),
	)
	return sources.join('\n')
}

describe('obsolete integrations removal contract', () => {
	test('dedicated obsolete files are absent', async () => {
		for (const relativePath of obsoleteFiles) {
			const path = new URL(relativePath, repositoryRoot)
			await expect(access(path)).rejects.toThrow()
		}
	})

	test('tracked repository sources contain no obsolete integration tokens', async () => {
		const repositoryText = await trackedRepositoryText()
		const bannedTokens = [
			join(['source', '-server']),
			join(['template', '-download']),
			join(['git', '-proxy']),
			join(['TEMPLATE', '_DOWNLOADS_ENABLED']),
			join(['TEMPLATE', '_SERVICE_BASE_URL']),
			join(['TEMPLATE', '_SERVICE_ADMIN_KEY']),
			join(['TEMPLATE', '_GIT_PUBLIC_BASE']),
			join(['TEMPLATE', '_FORGEJO_BASE']),
			join(['/api/', 'templates']),
			join(['/api/', 'git/']),
			join(['gorse', 'ecode']),
			join(['club', ' update']),
		] as const

		for (const token of bannedTokens) {
			expect(repositoryText).not.toContain(token)
		}
	})

	test('club CLI keeps status, context, and admin without update dispatch or help', async () => {
		const cli = await readFile(new URL('./club-cli.sh', import.meta.url), 'utf8')
		const main = cli.slice(cli.indexOf('main()'))

		expect(cli).toContain('status)')
		expect(cli).toContain('context | agent-context)')
		expect(cli).toContain('admin)')
		expect(main).not.toContain('update)')
		expect(cli).not.toContain('club update')
	})

	test('deploy defaults target the current production and demo contours', async () => {
		const production = await readFile(new URL('./deploy-production.sh', import.meta.url), 'utf8')
		const demo = await readFile(new URL('./deploy-demo.sh', import.meta.url), 'utf8')

		expect(production).toContain('SERVER_HOST="${SERVER_HOST:-root@193.124.33.21}"')
		expect(production).toContain('SERVER_PATH="${SERVER_PATH:-/opt/community-club}"')
		expect(production).toContain('COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"')
		expect(production).toContain(
			'PUBLIC_BASE_URL="${PUBLIC_BASE_URL:-https://clud.nepran-yuri.ru}"',
		)
		expect(production).not.toContain('docker-compose.demo.yml')
		expect(demo).toContain('PUBLIC_BASE_URL="${PUBLIC_BASE_URL:-https://demo-clud.nepran-yuri.ru}"')
		expect(demo).toContain('COMPOSE_FILES="${COMPOSE_FILES:-docker-compose.prod.yml}"')
		expect(demo).not.toContain('docker-compose.demo.yml')
	})
})
