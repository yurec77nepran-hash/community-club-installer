import { describe, expect, test } from 'bun:test'
import { readFile } from 'node:fs/promises'

const deployProductionPath = new URL('./deploy-production.sh', import.meta.url)
const deployDemoPath = new URL('./deploy-demo.sh', import.meta.url)

describe('deploy scripts', () => {
	test('production deploy supports custom compose project and smoke-check ports', async () => {
		const script = await readFile(deployProductionPath, 'utf8')

		expect(script).toContain('SERVER_HOST="${SERVER_HOST:-root@193.124.33.21}"')
		expect(script).toContain('SERVER_PATH="${SERVER_PATH:-/opt/community-club}"')
		expect(script).toContain('COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"')
		expect(script).toContain('COMPOSE_PROJECT="${COMPOSE_PROJECT:-}"')
		expect(script).toContain('COMPOSE_FILES="${COMPOSE_FILES:-$COMPOSE_FILE}"')
		expect(script).toContain('WEB_CHECK_PORT="${WEB_CHECK_PORT:-3000}"')
		expect(script).toContain('API_CHECK_PORT="${API_CHECK_PORT:-3001}"')
		expect(script).toContain('ADMIN_CHECK_PORT="${ADMIN_CHECK_PORT:-3002}"')
		expect(script).toContain('PUBLIC_BASE_URL="${PUBLIC_BASE_URL:-https://clud.nepran-yuri.ru}"')
		expect(script).toContain("rsync_args+=(--exclude 'docker-compose*.yml')")
		expect(script).toContain("--exclude '.community-club-source'")
		expect(script).toContain("--exclude '.omo'")
		expect(script).toContain('DEPLOY_SERVICES="${DEPLOY_SERVICES:-auto}"')
		expect(script).toContain('DEPLOY_MARKER_FILE="${DEPLOY_MARKER_FILE:-.deploy-rev}"')
		expect(script).toContain('DOCKER_BUILD_NO_CACHE="${DOCKER_BUILD_NO_CACHE:-0}"')
		expect(script).toContain('bun run build -- --concurrency=1')
		expect(script).toContain('docker compose ${compose}build ${build_flags} ${SELECTED_SERVICES}')
	})

	test('demo deploy is pinned to the demo contour', async () => {
		const script = await readFile(deployDemoPath, 'utf8')

		expect(script).toContain('root@193.124.33.21')
		expect(script).toContain('/opt/community-club-demo')
		expect(script).toContain('COMPOSE_FILES="${COMPOSE_FILES:-docker-compose.prod.yml}"')
		expect(script).toContain('community-club-demo')
		expect(script).toContain('WEB_CHECK_PORT="${WEB_CHECK_PORT:-3200}"')
		expect(script).toContain('API_CHECK_PORT="${API_CHECK_PORT:-3201}"')
		expect(script).toContain('ADMIN_CHECK_PORT="${ADMIN_CHECK_PORT:-3202}"')
		expect(script).toContain('https://demo-clud.nepran-yuri.ru')
	})
})
