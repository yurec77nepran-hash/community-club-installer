#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_HOST="${SERVER_HOST:-community-club}"
SERVER_PATH="${SERVER_PATH:-/opt/community-club-staging}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.staging.yml}"
COMPOSE_PROJECT="${COMPOSE_PROJECT:-community-club-staging}"
SKIP_CHECKS="${SKIP_CHECKS:-0}"
DEPLOY_SERVICES="${DEPLOY_SERVICES:-}"
DOCKER_BUILD_NO_CACHE="${DOCKER_BUILD_NO_CACHE:-0}"

run_local_checks() {
  if [[ "$SKIP_CHECKS" == "1" ]]; then
    echo "Skipping local checks because SKIP_CHECKS=1"
    return
  fi

  echo "Running local lint..."
  (cd "$ROOT_DIR" && NUXT_TELEMETRY_DISABLED=1 bun run lint)

  echo "Running local build..."
  (cd "$ROOT_DIR" && NUXT_TELEMETRY_DISABLED=1 bun run build)
}

sync_workspace() {
  echo "Syncing workspace to ${SERVER_HOST}:${SERVER_PATH} ..."

  ssh "$SERVER_HOST" "mkdir -p '$SERVER_PATH'"

  rsync -az --delete \
    --exclude '.git' \
    --exclude 'node_modules' \
    --exclude '.turbo' \
    --exclude '.env' \
    --exclude '.env.*' \
    --exclude 'secrets' \
    --exclude 'packages/*/node_modules' \
    --exclude 'packages/*/.nuxt' \
    --exclude 'packages/*/.output' \
    --exclude 'packages/*/dist' \
    --exclude 'packages/api/dist' \
    "$ROOT_DIR"/ "${SERVER_HOST}:${SERVER_PATH}/"
}

deploy_remote() {
  echo "Building and restarting staging services on ${SERVER_HOST} ..."

  local build_flags=""
  local up_flags=""
  if [[ "$DOCKER_BUILD_NO_CACHE" == "1" ]]; then
    build_flags="--no-cache"
  fi
  if [[ -n "$DEPLOY_SERVICES" ]]; then
    up_flags="--no-deps"
  fi

  ssh "$SERVER_HOST" "cd '$SERVER_PATH' && \
    docker compose -p '$COMPOSE_PROJECT' -f '$COMPOSE_FILE' build ${build_flags} ${DEPLOY_SERVICES} && \
    docker compose -p '$COMPOSE_PROJECT' -f '$COMPOSE_FILE' up -d ${up_flags} ${DEPLOY_SERVICES}"
}

check_remote() {
  echo "Running staging post-deploy checks on ${SERVER_HOST} ..."

  ssh "$SERVER_HOST" "cd '$SERVER_PATH' && \
    docker compose -p '$COMPOSE_PROJECT' -f '$COMPOSE_FILE' ps && \
    printf 'WEB=' && curl -s -o /dev/null -w '%{http_code}' http://localhost:3100/ && \
    printf '\nAPI=' && curl -s -o /dev/null -w '%{http_code}' http://localhost:3101/api/payments/tariffs && \
    printf '\nADMIN=' && curl -s -o /dev/null -w '%{http_code}' http://localhost:3102/admin/ && \
    printf '\nHEALTH=' && curl -s http://localhost:3101/health && \
    printf '\n'"
}

run_local_checks
sync_workspace
deploy_remote
check_remote
