import { spawn } from 'node:child_process'
import { createReadStream, createWriteStream } from 'node:fs'
import { mkdtemp, rm, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, extname, join } from 'node:path'
import { pipeline } from 'node:stream/promises'
import {
	AbortMultipartUploadCommand,
	CompleteMultipartUploadCommand,
	CreateMultipartUploadCommand,
	GetObjectCommand,
	ListObjectsV2Command,
	S3Client,
	UploadPartCommand,
} from '@aws-sdk/client-s3'

const VIDEO_KEY_PATTERN = /\.(mp4|mov|m4v)$/i
const APPLY = process.argv.includes('--apply')
const LIMIT = Number.parseInt(getArgValue('--limit') ?? '', 10)
const PREFIX = getArgValue('--prefix') ?? ''
const MULTIPART_UPLOAD_PART_BYTES = 32 * 1024 * 1024
const EXPLICIT_KEYS = process.argv
	.filter((arg) => !arg.startsWith('--'))
	.filter((arg) => VIDEO_KEY_PATTERN.test(arg))

const env = process.env

if (!env.S3_ENDPOINT || !env.S3_REGION || !env.S3_ACCESS_KEY || !env.S3_SECRET_KEY) {
	console.error('S3_* переменные окружения не заданы')
	process.exit(1)
}

const bucket = env.S3_BUCKET_MEDIA ?? 'media'
const s3 = new S3Client({
	endpoint: env.S3_ENDPOINT,
	region: env.S3_REGION,
	credentials: {
		accessKeyId: env.S3_ACCESS_KEY,
		secretAccessKey: env.S3_SECRET_KEY,
	},
	forcePathStyle: true,
	requestChecksumCalculation: 'WHEN_REQUIRED',
})

function getArgValue(name: string) {
	const prefix = `${name}=`
	const arg = process.argv.find((item) => item.startsWith(prefix))
	return arg?.slice(prefix.length)
}

async function bodyToBuffer(body: unknown) {
	const chunks: Buffer[] = []
	for await (const chunk of body as AsyncIterable<Uint8Array>) {
		chunks.push(Buffer.from(chunk))
	}
	return Buffer.concat(chunks)
}

function parseAtoms(buffer: Buffer) {
	const atoms: Array<{ offset: number; type: string; size: number }> = []
	let offset = 0
	while (offset + 8 <= buffer.length && atoms.length < 8) {
		let size = buffer.readUInt32BE(offset)
		const type = buffer.subarray(offset + 4, offset + 8).toString('latin1')
		let headerSize = 8

		if (size === 1 && offset + 16 <= buffer.length) {
			size = Number(buffer.readBigUInt64BE(offset + 8))
			headerSize = 16
		}
		if (size < headerSize) break

		atoms.push({ offset, type, size })
		if (size === 0 || offset + size > buffer.length) break
		offset += size
	}
	return atoms
}

function hasFaststartMoov(buffer: Buffer) {
	const atoms = parseAtoms(buffer)
	const moov = atoms.find((atom) => atom.type === 'moov')
	const mdat = atoms.find((atom) => atom.type === 'mdat')
	return Boolean(moov && (!mdat || moov.offset < mdat.offset))
}

async function isFaststart(key: string) {
	const response = await s3.send(
		new GetObjectCommand({
			Bucket: bucket,
			Key: key,
			Range: 'bytes=0-65535',
		}),
	)
	return hasFaststartMoov(await bodyToBuffer(response.Body))
}

async function listVideoKeys() {
	if (EXPLICIT_KEYS.length > 0) return EXPLICIT_KEYS

	const keys: string[] = []
	let continuationToken: string | undefined

	do {
		const response = await s3.send(
			new ListObjectsV2Command({
				Bucket: bucket,
				Prefix: PREFIX || undefined,
				ContinuationToken: continuationToken,
			}),
		)

		for (const object of response.Contents ?? []) {
			const key = object.Key ?? ''
			if (!VIDEO_KEY_PATTERN.test(key)) continue
			keys.push(key)
			if (Number.isInteger(LIMIT) && keys.length >= LIMIT) return keys
		}

		continuationToken = response.IsTruncated
			? (response.NextContinuationToken ?? undefined)
			: undefined
	} while (continuationToken)

	return keys
}

function runFfmpeg(inputPath: string, outputPath: string) {
	return new Promise<void>((resolve, reject) => {
		const ffmpeg = spawn(process.env.FFMPEG_PATH || 'ffmpeg', [
			'-hide_banner',
			'-loglevel',
			'error',
			'-y',
			'-i',
			inputPath,
			'-c',
			'copy',
			'-movflags',
			'+faststart',
			outputPath,
		])
		let stderr = ''
		ffmpeg.stderr.on('data', (chunk) => {
			stderr += String(chunk)
		})
		ffmpeg.on('error', reject)
		ffmpeg.on('close', (code) => {
			if (code === 0) {
				resolve()
				return
			}
			reject(new Error(stderr.trim() || `ffmpeg exited with code ${code}`))
		})
	})
}

async function uploadMultipartObject(params: {
	key: string
	filePath: string
	contentType: string
	contentLength: number
}) {
	const createResponse = await s3.send(
		new CreateMultipartUploadCommand({
			Bucket: bucket,
			Key: params.key,
			ContentType: params.contentType,
		}),
	)
	const uploadId = createResponse.UploadId
	if (!uploadId) throw new Error('S3 multipart upload id is missing')

	const completedParts: Array<{ ETag: string; PartNumber: number }> = []
	let partNumber = 1
	let bufferedChunks: Buffer[] = []
	let bufferedBytes = 0

	const uploadPart = async (body: Buffer) => {
		const response = await s3.send(
			new UploadPartCommand({
				Bucket: bucket,
				Key: params.key,
				UploadId: uploadId,
				PartNumber: partNumber,
				Body: body,
				ContentLength: body.byteLength,
			}),
		)
		if (!response.ETag) throw new Error(`S3 multipart part ${partNumber} ETag is missing`)
		completedParts.push({ ETag: response.ETag, PartNumber: partNumber })
		partNumber += 1
	}

	try {
		for await (const chunk of createReadStream(params.filePath)) {
			const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
			bufferedChunks.push(buffer)
			bufferedBytes += buffer.byteLength

			while (bufferedBytes >= MULTIPART_UPLOAD_PART_BYTES) {
				const joinedBuffer = Buffer.concat(bufferedChunks, bufferedBytes)
				await uploadPart(joinedBuffer.subarray(0, MULTIPART_UPLOAD_PART_BYTES))
				const restBody = joinedBuffer.subarray(MULTIPART_UPLOAD_PART_BYTES)
				bufferedChunks = restBody.byteLength > 0 ? [restBody] : []
				bufferedBytes = restBody.byteLength
			}
		}

		if (bufferedBytes > 0 || params.contentLength === 0) {
			await uploadPart(Buffer.concat(bufferedChunks, bufferedBytes))
		}

		await s3.send(
			new CompleteMultipartUploadCommand({
				Bucket: bucket,
				Key: params.key,
				UploadId: uploadId,
				MultipartUpload: { Parts: completedParts },
			}),
		)
	} catch (error) {
		await s3
			.send(
				new AbortMultipartUploadCommand({
					Bucket: bucket,
					Key: params.key,
					UploadId: uploadId,
				}),
			)
			.catch(() => {})
		throw error
	}
}

async function optimizeKey(key: string) {
	const tempDir = await mkdtemp(join(tmpdir(), 'community-club-s3-faststart-'))
	const extension = extname(key).toLowerCase() || '.mp4'
	const inputPath = join(tempDir, `input-${basename(key)}`)
	const outputPath = join(tempDir, `output${extension}`)

	try {
		const object = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: key }))
		if (!object.Body) throw new Error('S3 object body is empty')

		await pipeline(object.Body as NodeJS.ReadableStream, createWriteStream(inputPath))
		await runFfmpeg(inputPath, outputPath)

		const outputStat = await stat(outputPath)
		await uploadMultipartObject({
			key,
			filePath: outputPath,
			contentType: object.ContentType ?? 'video/mp4',
			contentLength: outputStat.size,
		})

		return outputStat.size
	} finally {
		await rm(tempDir, { recursive: true, force: true })
	}
}

const keys = await listVideoKeys()
const slowKeys: string[] = []

for (const key of keys) {
	if (!(await isFaststart(key))) slowKeys.push(key)
}

console.log(
	JSON.stringify({ checked: keys.length, slow: slowKeys.length, apply: APPLY, slowKeys }, null, 2),
)

if (!APPLY) {
	console.log('Dry run. Добавьте --apply, чтобы перезаписать S3-объекты fast-start версиями.')
	process.exit(0)
}

for (const [index, key] of slowKeys.entries()) {
	const startedAt = Date.now()
	console.log(`[${index + 1}/${slowKeys.length}] optimizing ${key}`)
	const size = await optimizeKey(key)
	console.log(
		`[${index + 1}/${slowKeys.length}] done ${key} ${(size / 1024 / 1024).toFixed(1)} MB in ${Date.now() - startedAt}ms`,
	)
}
