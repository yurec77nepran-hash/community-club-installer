#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

SERVER_HOST="${SERVER_HOST:-root@193.124.33.21}" \
SERVER_PATH="${SERVER_PATH:-/opt/community-club-demo}" \
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}" \
COMPOSE_FILES="${COMPOSE_FILES:-docker-compose.prod.yml}" \
COMPOSE_PROJECT="${COMPOSE_PROJECT:-community-club-demo}" \
WEB_CHECK_PORT="${WEB_CHECK_PORT:-3200}" \
API_CHECK_PORT="${API_CHECK_PORT:-3201}" \
ADMIN_CHECK_PORT="${ADMIN_CHECK_PORT:-3202}" \
PUBLIC_BASE_URL="${PUBLIC_BASE_URL:-https://demo-clud.nepran-yuri.ru}" \
	"${SCRIPT_DIR}/deploy-production.sh"
