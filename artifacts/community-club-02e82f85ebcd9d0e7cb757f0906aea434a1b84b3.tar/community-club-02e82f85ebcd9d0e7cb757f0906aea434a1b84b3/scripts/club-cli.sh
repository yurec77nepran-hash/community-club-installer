#!/usr/bin/env bash
set -euo pipefail

CONFIG_FILE="${CLUB_CONFIG:-/etc/community-club/club.conf}"
SCRIPT_PATH="${BASH_SOURCE[0]}"
SCRIPT_DIR="$(cd "$(dirname "$SCRIPT_PATH")" >/dev/null 2>&1 && pwd)"
APP_DIR="${APP_DIR:-}"
APP_NAME="${APP_NAME:-}"
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-}"

ok() {
	printf '[OK] %s\n' "$*"
}

fail() {
	printf '[ERROR] %s\n' "$*" >&2
	exit 1
}

usage() {
	cat <<HELP
Community Club CLI

Usage:
  club status
  club context [--path]
  club admin login --email admin@example.com [--password '...']
  club admin whoami
  club admin get <section[.path]>
  club admin set <section.path> <value>
  club admin patch <section> '<json>'
  club admin replace <section> '<json>'
  club admin list <section>
  club admin seed-main-banner <file>
  club admin call <METHOD> <path> [json]

Examples:
  club admin call GET /api/admin/broadcasts

Env:
  CLUB_CONFIG=/etc/community-club/club.conf
  CLUB_ADMIN_API_URL=http://127.0.0.1:3001
  CLUB_ADMIN_COOKIE=/etc/community-club/admin.cookies
HELP
}

json_string_field() {
	local key="$1"
	python3 -c '
import json
import sys

key = sys.argv[1]
try:
    data = json.load(sys.stdin)
except Exception:
    sys.exit(0)
value = data.get(key, "")
if isinstance(value, str):
    print(value)
' "$key"
}

json_payload_from_env() {
	python3 - "$@" <<'PY'
import json
import os
import sys

payload = {}
for item in sys.argv[1:]:
    env_name, json_name = item.split(":", 1)
    payload[json_name] = os.environ.get(env_name, "")
print(json.dumps(payload, ensure_ascii=False))
PY
}

project_env_value() {
	local key="$1"
	local env_file="${APP_DIR}/.env"
	[[ -f "$env_file" ]] || return 0
	awk -F= -v key="$key" '
		$1 == key {
			sub(/^[^=]*=/, "")
			gsub(/^[[:space:]]+|[[:space:]]+$/, "")
			gsub(/^"|"$/, "")
			gsub(/^'\''|'\''$/, "")
			print
			exit
		}
	' "$env_file"
}

json_api_data() {
	python3 -c '
import json
import sys

data = json.load(sys.stdin)
if data.get("success") is not True:
    message = data.get("error", {}).get("message", "API вернул ошибку")
    raise SystemExit(message)
print(json.dumps(data.get("data"), ensure_ascii=False, indent=2))
'
}

json_api_data_compact() {
	python3 -c '
import json
import sys

data = json.load(sys.stdin)
if data.get("success") is not True:
    message = data.get("error", {}).get("message", "API вернул ошибку")
    raise SystemExit(message)
print(json.dumps(data.get("data"), ensure_ascii=False, separators=(",", ":")))
'
}

json_pretty() {
	python3 -m json.tool --ensure-ascii
}

load_config() {
	local override_app_dir="$APP_DIR"
	local override_app_name="$APP_NAME"
	local override_compose_project_name="$COMPOSE_PROJECT_NAME"

	if [[ -f "$CONFIG_FILE" ]]; then
		# shellcheck disable=SC1090
		. "$CONFIG_FILE"
	fi

	[[ -n "$override_app_dir" ]] && APP_DIR="$override_app_dir"
	[[ -n "$override_app_name" ]] && APP_NAME="$override_app_name"
	[[ -n "$override_compose_project_name" ]] && COMPOSE_PROJECT_NAME="$override_compose_project_name"

	[[ -n "${APP_DIR:-}" ]] || fail "Не найден APP_DIR. Проверь ${CONFIG_FILE} или задай APP_DIR=/opt/community-club"
	[[ -d "$APP_DIR" ]] || fail "Директория проекта не найдена: ${APP_DIR}"

	APP_NAME="${APP_NAME:-$(basename "$APP_DIR" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9-]+/-/g; s/^-+//; s/-+$//')}"
	APP_NAME="${APP_NAME:-community-club}"
	COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-$APP_NAME}"
}

admin_usage() {
	cat <<HELP
Community Club admin CLI

Usage:
  club admin login --email admin@example.com [--password '...']
  club admin logout
  club admin whoami
  club admin get <section[.path]>
  club admin set <section.path> <value>
  club admin patch <section> '<json>'
  club admin replace <section> '<json>'
  club admin list <section>
  club admin seed-main-banner <file>
  club admin call <METHOD> <path> [json]

Sections:
  home, branding, navigation, login, test-access, guest-content-access, referral, documents, payments, runtime, chats, tariffs

Examples:
  club admin set home.stories.shape circle
  club admin set test-access.days 14
  club admin set referral.enabled true
  club admin get documents.cookie.enabled
  club admin set chats.club-chat.enabled false
  club admin seed-main-banner scrn/banner_1.png
  club admin call GET /api/admin/activity-logs
  club admin call GET /api/admin/broadcasts
HELP
}

admin_init() {
	load_config
	local port
	port="$(project_env_value API_HOST_PORT)"
	ADMIN_API_URL="${CLUB_ADMIN_API_URL:-http://127.0.0.1:${port:-3001}}"
	ADMIN_API_URL="${ADMIN_API_URL%/}"
	ADMIN_COOKIE_FILE="${CLUB_ADMIN_COOKIE:-/etc/community-club/admin.cookies}"
	mkdir -p "$(dirname "$ADMIN_COOKIE_FILE")"
	touch "$ADMIN_COOKIE_FILE"
	chmod 600 "$ADMIN_COOKIE_FILE" 2>/dev/null || true
}

admin_csrf_token() {
	[[ -f "$ADMIN_COOKIE_FILE" ]] || return 0
	awk '$6 == "csrf_token" { value = $7 } END { print value }' "$ADMIN_COOKIE_FILE"
}

admin_curl_request() {
	local method="$1"
	local path="$2"
	shift 2
	local status response response_body csrf url
	[[ "$path" == http://* || "$path" == https://* ]] && url="$path" || url="${ADMIN_API_URL}${path}"
	local -a args
	args=(-sS --max-time 60 -b "$ADMIN_COOKIE_FILE" -c "$ADMIN_COOKIE_FILE" -X "$method" -H 'Accept: application/json')
	if [[ ! "$method" =~ ^(GET|HEAD|OPTIONS)$ ]]; then
		csrf="$(admin_csrf_token)"
		[[ -n "$csrf" ]] && args+=(-H "X-CSRF-Token: $csrf")
	fi
	response="$(curl "${args[@]}" "$@" -w '\n%{http_code}' "$url")"
	status="$(printf '%s' "$response" | tail -n 1)"
	response_body="$(printf '%s' "$response" | sed '$d')"
	if [[ "$status" =~ ^2 ]]; then
		printf '%s\n' "$response_body"
		return
	fi
	local message
	message="$(printf '%s' "$response_body" | json_string_field message)"
	[[ -n "$message" ]] || message="$(printf '%s' "$response_body" | python3 -c 'import json,sys
try:
 data=json.load(sys.stdin); print(data.get("error",{}).get("message",""))
except Exception:
 pass')"
	fail "API ${method} ${path} вернул ${status}: ${message:-$response_body}"
}

admin_request() {
	local method="$1"
	local path="$2"
	local body="${3:-}"
	local -a args=()
	if [[ -n "$body" ]]; then
		args=(-H 'Content-Type: application/json' --data-binary "$body")
	fi
	admin_curl_request "$method" "$path" "${args[@]}"
}

admin_login() {
	admin_init
	local email="" password="" response me
	while [[ $# -gt 0 ]]; do
		case "$1" in
			--email)
				[[ $# -ge 2 ]] || fail "--email требует значение"
				email="$2"
				shift 2
				;;
			--password)
				[[ $# -ge 2 ]] || fail "--password требует значение"
				password="$2"
				shift 2
				;;
			--api-url)
				[[ $# -ge 2 ]] || fail "--api-url требует значение"
				CLUB_ADMIN_API_URL="$2"
				shift 2
				admin_init
				;;
			*)
				fail "Неизвестный аргумент login: $1"
				;;
		esac
	done
	[[ -n "$email" ]] || fail "Укажи --email"
	if [[ -z "$password" ]]; then
		if [[ -r /dev/tty && -w /dev/tty ]]; then
			printf 'Пароль админа: ' >/dev/tty
			read -rs password </dev/tty
			printf '\n' >/dev/tty
		else
			fail "Укажи --password или запусти интерактивно"
		fi
	fi
	local payload
	payload="$(ADMIN_EMAIL="$email" ADMIN_PASSWORD="$password" json_payload_from_env ADMIN_EMAIL:email ADMIN_PASSWORD:password)"
	: >"$ADMIN_COOKIE_FILE"
	chmod 600 "$ADMIN_COOKIE_FILE" 2>/dev/null || true
	response="$(curl -sS --max-time 60 -c "$ADMIN_COOKIE_FILE" -H 'Content-Type: application/json' --data-binary "$payload" "${ADMIN_API_URL}/api/auth/login")"
	printf '%s' "$response" | python3 -c '
import json
import sys
data=json.load(sys.stdin)
if data.get("success") is not True:
    raise SystemExit(data.get("error", {}).get("message", "Ошибка авторизации"))
'
	me="$(admin_request GET /api/auth/me)"
	printf '%s' "$me" | python3 -c '
import json
import sys
data=json.load(sys.stdin)
user=data.get("data") or {}
if data.get("success") is not True or user.get("role") not in ("admin", "superadmin"):
    raise SystemExit("Нет прав администратора")
print("[OK] Вход выполнен: {}".format(user.get("email", "admin")))
'
}

admin_section_endpoint() {
	case "$1" in
		home | home-experience) printf '/api/admin/home-experience' ;;
		branding | brand) printf '/api/admin/branding' ;;
		navigation | nav | app-navigation) printf '/api/admin/app-navigation' ;;
		login | auth | auth-login) printf '/api/admin/auth-login-settings' ;;
		test-access | demo | trial) printf '/api/admin/test-access-settings' ;;
		guest-content-access | guest-access | content-access) printf '/api/admin/guest-content-access-settings' ;;
		referral | referrals) printf '/api/admin/referral-settings' ;;
		documents | legal) printf '/api/admin/legal-documents' ;;
		payments | payment-providers) printf '/api/admin/payment-providers' ;;
		runtime | runtime-settings) printf '/api/admin/runtime-settings' ;;
		chats | chat) printf '/api/admin/chats' ;;
		tariffs | tariff) printf '/api/admin/tariffs' ;;
		*) return 1 ;;
	esac
}

admin_normalize_section_path() {
	local value="$1"
	case "$value" in
		stories.shape | story.shape | home.stories.shape | home.story.shape)
			printf 'home.bannerShape'
			;;
		home.stories.form | stories.form | home.story.form | story.form)
			printf 'home.bannerShape'
			;;
		*)
			printf '%s' "$value"
			;;
	esac
}

admin_normalize_value() {
	case "$1" in
		circle | round | rounded-full | круглые | круглый) printf 'circle' ;;
		square | squares | rounded | квадратные | квадратный) printf 'rounded' ;;
		on | yes | да | включено) printf 'true' ;;
		off | no | нет | выключено) printf 'false' ;;
		*) printf '%s' "$1" ;;
	esac
}

json_path_get() {
	local path="$1"
	python3 -c '
import json
import re
import sys

path = sys.argv[1]
data = json.load(sys.stdin)

def parts(value):
    out = []
    for chunk in filter(None, value.split(".")):
        m = re.match(r"^([^\[]+)(?:\[(\d+)\])?$", chunk)
        if not m:
            raise SystemExit(f"Неверный путь: {value}")
        out.append(m.group(1))
        if m.group(2) is not None:
            out.append(int(m.group(2)))
    return out

def pick(seq, key):
    if isinstance(key, int):
        return seq[key]
    for item in seq:
        if isinstance(item, dict) and str(item.get("key") or item.get("id") or item.get("slug") or item.get("name")) == key:
            return item
    raise KeyError(key)

cur = data
for key in parts(path):
    cur = pick(cur, key) if isinstance(cur, list) else cur[key]
print(json.dumps(cur, ensure_ascii=False, indent=2))
' "$path"
}

json_path_set() {
	local path="$1"
	local raw_value="$2"
	python3 -c '
import json
import re
import sys

path, raw_value = sys.argv[1], sys.argv[2]
data = json.load(sys.stdin)

def parse_value(value):
    try:
        return json.loads(value)
    except Exception:
        lowered = value.lower()
        if lowered == "true":
            return True
        if lowered == "false":
            return False
        if lowered == "null":
            return None
        return value

def parts(value):
    out = []
    for chunk in filter(None, value.split(".")):
        m = re.match(r"^([^\[]+)(?:\[(\d+)\])?$", chunk)
        if not m:
            raise SystemExit(f"Неверный путь: {value}")
        out.append(m.group(1))
        if m.group(2) is not None:
            out.append(int(m.group(2)))
    return out

def pick(seq, key):
    if isinstance(key, int):
        return seq[key]
    for item in seq:
        if isinstance(item, dict) and str(item.get("key") or item.get("id") or item.get("slug") or item.get("name")) == key:
            return item
    raise KeyError(key)

keys = parts(path)
if not keys:
    data = parse_value(raw_value)
else:
    cur = data
    for key in keys[:-1]:
        cur = pick(cur, key) if isinstance(cur, list) else cur[key]
    last = keys[-1]
    if isinstance(cur, list):
        target = pick(cur, last)
        if isinstance(target, dict):
            raise SystemExit("Путь должен указывать на поле, а не на объект списка")
    else:
        cur[last] = parse_value(raw_value)
print(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
' "$path" "$raw_value"
}

json_deep_merge() {
	local patch="$1"
	python3 -c '
import json
import sys

data = json.load(sys.stdin)
patch = json.loads(sys.argv[1])

def merge(left, right):
    if isinstance(left, dict) and isinstance(right, dict):
        result = dict(left)
        for key, value in right.items():
            result[key] = merge(result.get(key), value)
        return result
    return right

print(json.dumps(merge(data, patch), ensure_ascii=False, separators=(",", ":")))
' "$patch"
}

json_seed_media_key() {
	local upload_name="$1"
	python3 -c '
import json
import re
import sys

upload_name = sys.argv[1]
data = json.load(sys.stdin)
if data.get("success") is not True:
    raise SystemExit(data.get("error", {}).get("message", "API вернул ошибку"))
items = (data.get("data") or {}).get("items") or []
pattern = re.compile(r"^image/[0-9]+-" + re.escape(upload_name) + r"$")
for item in items:
    key = item.get("key", "")
    if item.get("type") == "image" and pattern.fullmatch(key):
        print(key)
        break
' "$upload_name"
}

json_main_banner_media_key() {
	python3 -c '
import json
import sys

data = json.load(sys.stdin)
value = (data.get("mainBanner") or {}).get("mediaKey")
if isinstance(value, str):
    print(value)
'
}

json_main_banner_payload() {
	local media_key="$1"
	python3 -c '
import json
import sys

media_key = sys.argv[1]
data = json.load(sys.stdin)
main_banner = data.get("mainBanner")
if not isinstance(main_banner, dict):
    raise SystemExit("API не вернул настройки mainBanner")
alt = main_banner.get("alt")
if not isinstance(alt, str) or not alt.strip():
    raise SystemExit("mainBanner.alt должен содержать доступное описание")
main_banner["mediaKey"] = media_key
main_banner.pop("mediaUrl", None)
print(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
' "$media_key"
}

json_chat_set_payload() {
	local selector="$1"
	local path="$2"
	local raw_value="$3"
	python3 -c '
import json
import re
import sys

selector, path, raw_value = sys.argv[1], sys.argv[2], sys.argv[3]
items = json.load(sys.stdin)

def parse_value(value):
    try:
        return json.loads(value)
    except Exception:
        lowered = value.lower()
        if lowered == "true":
            return True
        if lowered == "false":
            return False
        if lowered == "null":
            return None
        return value

def parts(value):
    aliases = {"enabled": "isEnabled", "avatar": "avatarUrl"}
    out = []
    for chunk in filter(None, value.split(".")):
        m = re.match(r"^([^\[]+)(?:\[(\d+)\])?$", chunk)
        if not m:
            raise SystemExit(f"Неверный путь: {value}")
        out.append(aliases.get(m.group(1), m.group(1)))
        if m.group(2) is not None:
            out.append(int(m.group(2)))
    return out

item = None
for candidate in items:
    if str(candidate.get("id")) == selector or candidate.get("slug") == selector or candidate.get("name") == selector:
        item = candidate
        break
if item is None:
    raise SystemExit(f"Чат не найден: {selector}")

keys = parts(path)
cur = item
for key in keys[:-1]:
    cur = cur[key]
cur[keys[-1]] = parse_value(raw_value)

payload = {key: item.get(key) for key in ("name", "slug", "type", "accessRole", "isEnabled", "avatarUrl", "description", "settings")}
print(item["id"])
print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
' "$selector" "$path" "$raw_value"
}

admin_get() {
	admin_init
	local full_path section path endpoint response data has_path
	full_path="$(admin_normalize_section_path "$1")"
	section="${full_path%%.*}"
	path=""
	has_path=0
	if [[ "$full_path" == *.* ]]; then
		has_path=1
		path="${full_path#*.}"
	fi
	endpoint="$(admin_section_endpoint "$section")" || fail "Неизвестный раздел: $section"
	if [[ "$section" == "documents" || "$section" == "legal" ]]; then
		[[ -z "$path" || "$path" == documents.* ]] || path="documents.${path}"
	fi
	response="$(admin_request GET "$endpoint")"
	if [[ "$has_path" == "0" ]]; then
		printf '%s' "$response" | json_api_data
		return
	fi
	data="$(printf '%s' "$response" | json_api_data_compact)"
	printf '%s' "$data" | json_path_get "$path"
}

admin_set() {
	admin_init
	local full_path value section path endpoint response data body result chat_id payload
	full_path="$(admin_normalize_section_path "$1")"
	value="$(admin_normalize_value "$2")"
	section="${full_path%%.*}"
	path="${full_path#*.}"
	[[ "$path" != "$full_path" ]] || fail "set требует путь вида section.field"
	endpoint="$(admin_section_endpoint "$section")" || fail "Неизвестный раздел: $section"
	if [[ "$section" == "documents" || "$section" == "legal" ]]; then
		[[ "$path" == documents.* ]] || path="documents.${path}"
	fi

	response="$(admin_request GET "$endpoint")"
	data="$(printf '%s' "$response" | json_api_data_compact)"
	if [[ "$section" == "chats" || "$section" == "chat" ]]; then
		local selector chat_path
		selector="${path%%.*}"
		chat_path="${path#*.}"
		[[ "$chat_path" != "$path" ]] || fail "Для чата нужен путь chats.<slug>.<field>"
		result="$(printf '%s' "$data" | json_chat_set_payload "$selector" "$chat_path" "$value")"
		chat_id="$(printf '%s' "$result" | head -n 1)"
		payload="$(printf '%s' "$result" | tail -n +2)"
		admin_request PATCH "/api/admin/chats/${chat_id}" "$payload" | json_api_data
		return
	fi

	body="$(printf '%s' "$data" | json_path_set "$path" "$value")"
	admin_request PUT "$endpoint" "$body" | json_api_data
}

admin_patch() {
	admin_init
	local section="$1"
	local patch="$2"
	local endpoint response data body
	endpoint="$(admin_section_endpoint "$section")" || fail "Неизвестный раздел: $section"
	response="$(admin_request GET "$endpoint")"
	data="$(printf '%s' "$response" | json_api_data_compact)"
	body="$(printf '%s' "$data" | json_deep_merge "$patch")"
	admin_request PUT "$endpoint" "$body" | json_api_data
}

admin_replace() {
	admin_init
	local section="$1"
	local body="$2"
	local endpoint
	endpoint="$(admin_section_endpoint "$section")" || fail "Неизвестный раздел: $section"
	admin_request PUT "$endpoint" "$body" | json_api_data
}

admin_seed_main_banner() {
	admin_init
	local file="$1"
	local upload_name='community-club-main-banner-seed-v1.png'
	local response media_key home_data current_key body
	[[ -f "$file" && -r "$file" ]] || fail "Файл баннера не найден или недоступен для чтения: $file"
	[[ "${file,,}" == *.png ]] || fail "seed-main-banner принимает только PNG-файл"

	response="$(admin_request GET "/api/admin/media-library?type=image&search=${upload_name}&limit=60&sortBy=updatedAt&sortDir=desc")"
	media_key="$(printf '%s' "$response" | json_seed_media_key "$upload_name")"
	if [[ -z "$media_key" ]]; then
		response="$(admin_curl_request POST "/api/media/upload/raw?fileName=${upload_name}&bucket=media" -H 'Content-Type: image/png' --data-binary "@$file")"
		media_key="$(printf '%s' "$response" | json_api_data_compact | json_string_field path)"
		[[ -n "$media_key" ]] || fail "API загрузки не вернул media key"
		ok "Баннер загружен в медиатеку: $media_key"
	else
		ok "Используется существующий баннер из медиатеки: $media_key"
	fi

	response="$(admin_request GET /api/admin/home-experience)"
	home_data="$(printf '%s' "$response" | json_api_data_compact)"
	current_key="$(printf '%s' "$home_data" | json_main_banner_media_key)"
	if [[ "$current_key" == "$media_key" ]]; then
		ok "Главный баннер уже настроен"
		return
	fi

	body="$(printf '%s' "$home_data" | json_main_banner_payload "$media_key")"
	admin_request PUT /api/admin/home-experience "$body" >/dev/null
	ok "Главный баннер настроен: $media_key"
}

cmd_admin() {
	local subcommand="${1:-help}"
	[[ $# -gt 0 ]] && shift
	case "$subcommand" in
		login)
			admin_login "$@"
			;;
		logout)
			admin_init
			rm -f "$ADMIN_COOKIE_FILE"
			ok "Админская сессия CLI удалена"
			;;
		whoami)
			admin_init
			admin_request GET /api/auth/me | json_api_data
			;;
		get)
			[[ $# -ge 1 ]] || fail "get требует section[.path]"
			admin_get "$1"
			;;
		set)
			[[ $# -ge 2 ]] || fail "set требует section.path и value"
			admin_set "$1" "$2"
			;;
		patch)
			[[ $# -ge 2 ]] || fail "patch требует section и json"
			admin_patch "$1" "$2"
			;;
		replace)
			[[ $# -ge 2 ]] || fail "replace требует section и json"
			admin_replace "$1" "$2"
			;;
		list)
			[[ $# -ge 1 ]] || fail "list требует section"
			admin_get "$1"
			;;
		seed-main-banner)
			[[ $# -eq 1 ]] || fail "seed-main-banner требует путь к PNG-файлу"
			admin_seed_main_banner "$1"
			;;
		call)
			[[ $# -ge 2 ]] || fail "call требует METHOD и path"
			admin_init
			admin_request "${1^^}" "$2" "${3:-}" | json_pretty
			;;
		help | -h | --help)
			admin_usage
			;;
		*)
			fail "Неизвестная admin-команда: $subcommand"
			;;
	esac
}

cmd_status() {
	load_config
	local env_status="не найден"
	local compose_status="не найден"
	[[ -f "${APP_DIR}/.env" ]] && env_status="найден"
	[[ -f "${APP_DIR}/docker-compose.prod.yml" ]] && compose_status="найден"
	cat <<OUT
Community Club

Проект: ${APP_DIR}
Имя compose: ${COMPOSE_PROJECT_NAME}
Env: ${env_status}
Compose: ${compose_status}
OUT
}

context_file_path() {
	local override_app_dir="$APP_DIR"
	if [[ -f "$CONFIG_FILE" ]]; then
		# shellcheck disable=SC1090
		. "$CONFIG_FILE"
	fi
	[[ -n "$override_app_dir" ]] && APP_DIR="$override_app_dir"

	for candidate in \
		"${APP_DIR:-}/docs/agent-context.md" \
		"${PWD}/docs/agent-context.md" \
		"${SCRIPT_DIR}/../docs/agent-context.md"; do
		if [[ -f "$candidate" ]]; then
			printf '%s\n' "$candidate"
			return
		fi
	done

	fail "Не найден docs/agent-context.md. Задай APP_DIR=/opt/community-club или запусти из проекта."
}

cmd_context() {
	local file
	file="$(context_file_path)"
	if [[ "${1:-}" == "--path" ]]; then
		printf '%s\n' "$file"
		return
	fi
	cat "$file"
}

main() {
	local command="${1:-help}"
	if [[ $# -gt 0 ]]; then
		shift
	fi

	case "$command" in
		status)
			cmd_status
			;;
		context | agent-context)
			cmd_context "$@"
			;;
		admin)
			cmd_admin "$@"
			;;
		help | -h | --help)
			usage
			;;
		*)
			fail "Неизвестная команда: ${command}"
			;;
	esac
}

main "$@"
