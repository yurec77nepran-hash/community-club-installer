#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

APP_URL="${APP_URL:-http://localhost:3000}"
API_URL="${API_URL:-http://localhost:3001}"
ADMIN_URL="${ADMIN_URL:-http://localhost:3002/admin}"
POSTGRES_IMAGE="${PRILA_POSTGRES_IMAGE:-docker.io/library/postgres:15-alpine}"
REDIS_IMAGE="${PRILA_REDIS_IMAGE:-docker.io/library/redis:7-alpine}"
GARAGE_IMAGE="${PRILA_GARAGE_IMAGE:-docker.io/dxflrs/garage:v2.2.0}"
LOCAL_S3_API_PORT="${PRILA_S3_API_PORT:-3900}"
LOCAL_S3_WEB_PORT="${PRILA_S3_WEB_PORT:-3902}"
LOCAL_S3_ADMIN_PORT="${PRILA_S3_ADMIN_PORT:-3903}"
LOCAL_S3_PUBLIC_URL="http://media.web.garage.localhost:${LOCAL_S3_WEB_PORT}"

COMPOSE_CMD=()
INFRA_PROVIDER=""
FULL_UPDATE="${PRILA_FULL_UPDATE:-0}"

print_help() {
	echo "прила — запустить приложение, API и админку"
	echo "прила обнови — обновить зависимости через bun update, образы Postgres/Redis и запустить проект"
}

parse_args() {
	for arg in "$@"; do
		case "$arg" in
			обнови | update | --update)
				FULL_UPDATE=1
				;;
			помощь | help | --help | -h)
				print_help
				exit 0
				;;
			*)
				echo "Неизвестный аргумент: $arg"
				print_help
				exit 2
				;;
		esac
	done
}

find_compose_command() {
	if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
		COMPOSE_CMD=(docker compose)
		return 0
	fi

	if command -v docker-compose >/dev/null 2>&1; then
		COMPOSE_CMD=(docker-compose)
		return 0
	fi

	if command -v podman >/dev/null 2>&1 && podman compose version >/dev/null 2>&1; then
		COMPOSE_CMD=(podman compose)
		return 0
	fi

	if command -v podman-compose >/dev/null 2>&1; then
		COMPOSE_CMD=(podman-compose)
		return 0
	fi

	return 1
}

ensure_bun() {
	if command -v bun >/dev/null 2>&1; then
		return
	fi

	echo "Bun не найден. На NixOS добавь bun в системную конфигурацию, Home Manager или dev shell."
	exit 1
}

ensure_env() {
	if [[ -f "$ROOT_DIR/.env" ]]; then
		return
	fi

	cp "$ROOT_DIR/.env.example" "$ROOT_DIR/.env"
	echo "Создал .env из .env.example"
}

load_env_file() {
	local line key value
	while IFS= read -r line || [[ -n "$line" ]]; do
		[[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
		[[ "$line" != *=* ]] && continue

		key="${line%%=*}"
		value="${line#*=}"
		[[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue

		if [[ "$value" == \"*\" && "$value" == *\" ]]; then
			value="${value:1:${#value}-2}"
		elif [[ "$value" == \'*\' && "$value" == *\' ]]; then
			value="${value:1:${#value}-2}"
		fi

		export "$key=$value"
	done < "$ROOT_DIR/.env"
}

configure_local_s3_ports() {
	LOCAL_S3_API_PORT="${S3_API_HOST_PORT:-${PRILA_S3_API_PORT:-$LOCAL_S3_API_PORT}}"
	LOCAL_S3_WEB_PORT="${S3_WEB_HOST_PORT:-${PRILA_S3_WEB_PORT:-$LOCAL_S3_WEB_PORT}}"
	LOCAL_S3_ADMIN_PORT="${S3_ADMIN_HOST_PORT:-${PRILA_S3_ADMIN_PORT:-$LOCAL_S3_ADMIN_PORT}}"
	LOCAL_S3_PUBLIC_URL="http://media.web.garage.localhost:${LOCAL_S3_WEB_PORT}"
}

export_local_urls() {
	export APP_URL
	export API_URL
	export ADMIN_URL
}

env_value() {
	local key="$1"
	awk -F= -v key="$key" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$ROOT_DIR/.env"
}

set_env_value() {
	local key="$1"
	local value="$2"

	if grep -q "^${key}=" "$ROOT_DIR/.env" 2>/dev/null; then
		sed -i "s|^${key}=.*|${key}=${value}|" "$ROOT_DIR/.env"
	else
		printf '%s=%s\n' "$key" "$value" >> "$ROOT_DIR/.env"
	fi
	export "$key=$value"
}

should_manage_local_garage() {
	if [[ "${PRILA_LOCAL_GARAGE:-}" == "0" ]]; then
		return 1
	fi

	local endpoint
	endpoint="$(env_value S3_ENDPOINT)"
	case "$endpoint" in
		"" | "http://garage:3900" | "http://localhost:3900" | "http://127.0.0.1:3900")
			return 0
			;;
		*)
			[[ "${PRILA_LOCAL_GARAGE:-}" == "1" ]]
			;;
	esac
}

generate_hex_secret() {
	if command -v openssl >/dev/null 2>&1; then
		openssl rand -hex 32
		return
	fi
	od -An -N32 -tx1 /dev/urandom | tr -d ' \n'
}

ensure_garage_secrets() {
	mkdir -p "$ROOT_DIR/secrets"

	if [[ ! -f "$ROOT_DIR/secrets/garage_rpc_secret" ]]; then
		generate_hex_secret > "$ROOT_DIR/secrets/garage_rpc_secret"
	fi
	if [[ ! -f "$ROOT_DIR/secrets/garage_admin_token" ]]; then
		generate_hex_secret > "$ROOT_DIR/secrets/garage_admin_token"
	fi

	chmod 600 "$ROOT_DIR/secrets/garage_rpc_secret" "$ROOT_DIR/secrets/garage_admin_token"
}

update_project_dependencies() {
	if [[ "${PRILA_SKIP_UPDATE:-0}" == "1" && -d "$ROOT_DIR/node_modules" ]]; then
		return
	fi

	if [[ "$FULL_UPDATE" == "1" ]]; then
		echo "Обновляю зависимости проекта..."
		(cd "$ROOT_DIR" && bun update)
		return
	fi

	echo "Проверяю зависимости проекта..."
	(cd "$ROOT_DIR" && bun install)
}

update_container_images() {
	if [[ "${PRILA_SKIP_IMAGE_UPDATE:-0}" == "1" ]]; then
		return
	fi

	if [[ "${#COMPOSE_CMD[@]}" -gt 0 ]]; then
		local services=(postgres redis)
		if should_manage_local_garage; then
			services+=(garage)
		fi
		echo "Обновляю образы инфраструктуры..."
		(cd "$ROOT_DIR" && "${COMPOSE_CMD[@]}" pull "${services[@]}")
		return
	fi

	if command -v podman >/dev/null 2>&1; then
		echo "Обновляю образы инфраструктуры..."
		podman pull "$POSTGRES_IMAGE" >/dev/null
		podman pull "$REDIS_IMAGE" >/dev/null
		if should_manage_local_garage; then
			podman pull "$GARAGE_IMAGE" >/dev/null
		fi
	fi
}

start_podman_container() {
	local name="$1"
	shift

	if podman container exists "$name" >/dev/null 2>&1; then
		if [[ "$FULL_UPDATE" == "1" || "${PRILA_RECREATE_INFRA:-0}" == "1" ]]; then
			podman rm -f "$name" >/dev/null
		elif [[ "$(podman inspect -f '{{.State.Status}}' "$name")" == "running" ]]; then
			return
		else
			podman start "$name" >/dev/null
			return
		fi
	fi

	podman run -d --name "$name" "$@" >/dev/null
}

start_podman_infra() {
	if ! command -v podman >/dev/null 2>&1; then
		return 1
	fi

	update_container_images
	echo "Compose не найден, поднимаю локальную инфраструктуру через Podman..."
	start_podman_container community-club-postgres \
		-e POSTGRES_DB=community_club \
		-e POSTGRES_USER=postgres \
		-e POSTGRES_PASSWORD=postgres \
		-v community-club-postgres-data:/var/lib/postgresql/data \
		-p 5432:5432 \
		"$POSTGRES_IMAGE"
	start_podman_container community-club-redis \
		-v community-club-redis-data:/data \
		-p 6379:6379 \
		"$REDIS_IMAGE"
	if should_manage_local_garage; then
		ensure_garage_secrets
		start_podman_container community-club-garage \
			-v "$ROOT_DIR/garage.toml:/etc/garage.toml:ro" \
			-v "$ROOT_DIR/secrets/garage_rpc_secret:/run/secrets/garage_rpc_secret:ro" \
			-v "$ROOT_DIR/secrets/garage_admin_token:/run/secrets/garage_admin_token:ro" \
			-v community-club-garage-meta:/var/lib/garage/meta \
			-v community-club-garage-data:/var/lib/garage/data \
			-p "127.0.0.1:${LOCAL_S3_API_PORT}:3900" \
			-p "127.0.0.1:${LOCAL_S3_WEB_PORT}:3902" \
			-p "127.0.0.1:${LOCAL_S3_ADMIN_PORT}:3903" \
			"$GARAGE_IMAGE"
	fi
	INFRA_PROVIDER="podman"
}

start_local_infra() {
	if ! find_compose_command; then
		if start_podman_infra; then
			return
		fi

		echo "Compose и Podman не найдены: Postgres и Redis не поднимаю автоматически."
		echo "На NixOS добавь podman или docker compose в системную конфигурацию."
		return
	fi

	update_container_images
	local services=(postgres redis)
	if should_manage_local_garage; then
		ensure_garage_secrets
		services+=(garage)
	fi
	echo "Поднимаю локальную инфраструктуру..."
	(cd "$ROOT_DIR" && "${COMPOSE_CMD[@]}" up -d "${services[@]}")
	INFRA_PROVIDER="compose"
}

wait_for_postgres() {
	if [[ -z "$INFRA_PROVIDER" ]]; then
		return
	fi

	for _ in $(seq 1 30); do
		if [[ "$INFRA_PROVIDER" == "compose" ]] &&
			(cd "$ROOT_DIR" && "${COMPOSE_CMD[@]}" exec -T postgres pg_isready -U postgres >/dev/null 2>&1); then
			return
		fi
		if [[ "$INFRA_PROVIDER" == "podman" ]] &&
			podman exec community-club-postgres pg_isready -U postgres >/dev/null 2>&1; then
			return
		fi
		sleep 1
	done

	echo "Postgres не ответил за 30 секунд."
	exit 1
}

wait_for_redis() {
	if [[ -z "$INFRA_PROVIDER" ]]; then
		return
	fi

	for _ in $(seq 1 30); do
		if [[ "$INFRA_PROVIDER" == "compose" ]] &&
			(cd "$ROOT_DIR" && "${COMPOSE_CMD[@]}" exec -T redis redis-cli ping >/dev/null 2>&1); then
			return
		fi
		if [[ "$INFRA_PROVIDER" == "podman" ]] &&
			podman exec community-club-redis redis-cli ping >/dev/null 2>&1; then
			return
		fi
		sleep 1
	done

	echo "Redis не ответил за 30 секунд."
	exit 1
}

garage_exec() {
	if [[ "$INFRA_PROVIDER" == "compose" ]]; then
		(cd "$ROOT_DIR" && "${COMPOSE_CMD[@]}" exec -T garage "$@")
		return
	fi

	podman exec community-club-garage "$@"
}

wait_for_garage() {
	if [[ -z "$INFRA_PROVIDER" ]] || ! should_manage_local_garage; then
		return
	fi

	for _ in $(seq 1 45); do
		if garage_exec /garage node id >/dev/null 2>&1; then
			return
		fi
		sleep 1
	done

	echo "Garage не ответил за 45 секунд."
	exit 1
}

parse_garage_key_output() {
	local field="$1"
	if [[ "$field" == "access" ]]; then
		awk 'tolower($0) ~ /key id/ {print $NF; exit}'
		return
	fi
	awk 'tolower($0) ~ /secret/ {print $NF; exit}'
}

apply_garage_layout() {
	local node_id layout_output layout_version
	node_id="$(garage_exec /garage node id 2>/dev/null | head -1 | cut -d'@' -f1)"
	if [[ -z "$node_id" ]]; then
		echo "Не удалось получить Garage node id."
		exit 1
	fi

	garage_exec /garage layout assign "$node_id" -z dc1 -c 20G -t local-node >/dev/null 2>&1 || true
	layout_output="$(garage_exec /garage layout show 2>/dev/null || true)"
	layout_version="$(
		printf '%s\n' "$layout_output" |
			sed -n \
				-e 's/.*layout apply --version \([0-9][0-9]*\).*/\1/p' \
				-e 's/.*TO APPLY.*VERSION \([0-9][0-9]*\).*/\1/p' |
			head -1
	)"

	if [[ -n "$layout_version" ]]; then
		garage_exec /garage layout apply --version "$layout_version" >/dev/null 2>&1 || true
	else
		garage_exec /garage layout apply --version 1 >/dev/null 2>&1 || true
	fi
}

init_local_garage() {
	if ! should_manage_local_garage; then
		return
	fi

	echo "Инициализирую локальный Garage..."
	apply_garage_layout

	local bucket
	for bucket in media chat-attachments avatars; do
		garage_exec /garage bucket create "$bucket" >/dev/null 2>&1 || true
	done
	garage_exec /garage bucket website --allow media >/dev/null 2>&1 || true
	garage_exec /garage bucket website --allow avatars >/dev/null 2>&1 || true

	local key_name="community-club-api-local"
	local key_output access_key secret_key
	access_key="$(env_value S3_ACCESS_KEY)"
	secret_key="$(env_value S3_SECRET_KEY)"
	if [[ -n "$access_key" && -n "$secret_key" ]] &&
		! garage_exec /garage key info "$access_key" >/dev/null 2>&1; then
		access_key=""
		secret_key=""
	fi

	if [[ -z "$access_key" || -z "$secret_key" ]]; then
		key_output="$(garage_exec /garage key create "$key_name" 2>/dev/null || true)"
		access_key="$(printf '%s\n' "$key_output" | parse_garage_key_output access)"
		secret_key="$(printf '%s\n' "$key_output" | parse_garage_key_output secret)"
	fi

	if [[ -z "$access_key" || -z "$secret_key" ]]; then
		key_name="community-club-api-local-$(date +%s)"
		key_output="$(garage_exec /garage key create "$key_name")"
		access_key="$(printf '%s\n' "$key_output" | parse_garage_key_output access)"
		secret_key="$(printf '%s\n' "$key_output" | parse_garage_key_output secret)"
	fi

	if [[ -z "$access_key" || -z "$secret_key" ]]; then
		echo "Не удалось подготовить S3-ключи для Garage."
		exit 1
	fi

	for bucket in media chat-attachments avatars; do
		garage_exec /garage bucket allow --read --write --owner "$bucket" --key "$access_key" >/dev/null 2>&1 || true
	done

	set_env_value S3_ENDPOINT "http://localhost:${LOCAL_S3_API_PORT}"
	set_env_value S3_REGION "garage"
	set_env_value S3_ACCESS_KEY "$access_key"
	set_env_value S3_SECRET_KEY "$secret_key"
	set_env_value S3_BUCKET_MEDIA "media"
	set_env_value S3_BUCKET_CHAT "chat-attachments"
	set_env_value S3_BUCKET_AVATARS "avatars"
	set_env_value S3_PUBLIC_URL "$LOCAL_S3_PUBLIC_URL"
}

is_local_database_url() {
	local database_url="$1"
	case "$database_url" in
		postgres://*localhost* | postgres://*127.0.0.1* | postgresql://*localhost* | postgresql://*127.0.0.1*)
			return 0
			;;
		*)
			return 1
			;;
	esac
}

sync_local_db_schema() {
	if [[ "${PRILA_SKIP_DB_PUSH:-0}" == "1" ]]; then
		return
	fi

	if [[ -z "$INFRA_PROVIDER" && "${PRILA_DB_PUSH:-0}" != "1" ]]; then
		return
	fi

	local database_url
	database_url="$(env_value DATABASE_URL)"
	if [[ -z "$database_url" ]] || ! is_local_database_url "$database_url"; then
		return
	fi

	echo "Синхронизирую локальную схему БД..."
	(cd "$ROOT_DIR/packages/api" && DATABASE_URL="$database_url" bunx drizzle-kit push --config drizzle.config.ts)
}

print_urls() {
	echo
	echo "Приложение: $APP_URL"
	echo "Админка: $ADMIN_URL"
	echo "API: $API_URL/health"
	if should_manage_local_garage; then
		echo "Медиа: $LOCAL_S3_PUBLIC_URL"
	fi
	echo
}

main() {
	cd "$ROOT_DIR"

	parse_args "$@"
	ensure_bun
	ensure_env
	load_env_file
	configure_local_s3_ports
	export_local_urls
	update_project_dependencies
	start_local_infra
	wait_for_postgres
	wait_for_redis
	wait_for_garage
	init_local_garage
	sync_local_db_schema
	print_urls

	exec bun run dev
}

main "$@"
