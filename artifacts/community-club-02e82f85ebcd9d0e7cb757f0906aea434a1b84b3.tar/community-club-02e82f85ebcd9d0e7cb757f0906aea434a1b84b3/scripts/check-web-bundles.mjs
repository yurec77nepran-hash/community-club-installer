import { readdir, stat } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const scriptDir = path.dirname(fileURLToPath(import.meta.url))
const projectRoot = path.resolve(scriptDir, '..')
const packageDir = process.env.BUNDLE_PACKAGE_DIR || 'packages/web'
const label = process.env.BUNDLE_LABEL || packageDir
const clientDir = path.join(projectRoot, packageDir, '.nuxt/dist/client/_nuxt')
const warnLimitKb = Number(process.env.BUNDLE_WARN_KB || process.env.WEB_CHUNK_WARN_KB || 350)
const hardLimitKb = Number(process.env.BUNDLE_HARD_KB || process.env.WEB_CHUNK_HARD_KB || 560)

async function main() {
	const entries = await readdir(clientDir)
	const chunkStats = await Promise.all(
		entries
			.filter((entry) => entry.endsWith('.js'))
			.map(async (entry) => {
				const filePath = path.join(clientDir, entry)
				const fileStat = await stat(filePath)
				return {
					file: entry,
					sizeKb: Number((fileStat.size / 1024).toFixed(2)),
				}
			}),
	)

	chunkStats.sort((left, right) => right.sizeKb - left.sizeKb)
	const offenders = chunkStats.filter((entry) => entry.sizeKb >= warnLimitKb)

	if (offenders.length === 0) {
		console.log(`[bundle-budget:${label}] OK: no chunks above ${warnLimitKb} KB`)
		return
	}

	console.log(`[bundle-budget:${label}] Top heavy chunks:`)
	for (const offender of offenders.slice(0, 10)) {
		console.log(` - ${offender.file}: ${offender.sizeKb} KB`)
	}

	const hardOffenders = offenders.filter((entry) => entry.sizeKb > hardLimitKb)
	if (hardOffenders.length > 0) {
		const details = hardOffenders.map((entry) => `${entry.file} (${entry.sizeKb} KB)`).join(', ')
		throw new Error(`Bundle budget exceeded for ${label}: ${details}`)
	}
}

await main()
