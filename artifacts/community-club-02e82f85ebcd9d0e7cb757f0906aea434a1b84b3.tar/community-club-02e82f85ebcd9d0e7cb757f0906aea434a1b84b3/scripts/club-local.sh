#!/usr/bin/env bash
# клуб — запуск локального dev-окружения Community Club
# на NixOS без Docker: Postgres/Redis/Garage поднимаются нативно,
# затем стартуют api (3001), web (3000) и admin (3002).
set -euo pipefail

SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]:-$0}" 2>/dev/null || realpath "${BASH_SOURCE[0]}" 2>/dev/null || printf '%s' "${BASH_SOURCE[0]}")"
ROOT_DIR="$(cd "$(dirname "$SCRIPT_PATH")/.." && pwd)"

# Пути к локальным сервисам и данным (переопределяются env-переменными).
# По умолчанию рассчитаны на NixOS + nix-store бинарники из этого сетапа.
PG_BIN="${CLUB_PG_BIN:-/home/oleg/.nix-profile/bin}"
REDIS_BIN="${CLUB_REDIS_BIN:-/nix/store/8x217a2cn96x5d00vc1fl4yv17zg7akf-redis-8.2.3/bin}"
GARAGE_BIN="${CLUB_GARAGE_BIN:-/nix/store/mqy4bsmlic81x8x37xna6l3f5h88zzr8-garage-1.3.1/bin}"
RUN_DIR="${CLUB_RUN_DIR:-/tmp/cc-runtime}"
PG_PORT="${CLUB_PG_PORT:-5432}"
REDIS_PORT="${CLUB_REDIS_PORT:-6379}"
GARAGE_CONFIG="$RUN_DIR/garage/config.toml"
GARAGE_ALLOW_WORLD_READABLE_SECRETS=1
ADMIN_EMAIL="${CLUB_ADMIN_EMAIL:-admin@example.com}"
ADMIN_PASSWORD="${CLUB_ADMIN_PASSWORD:-admin1234}"

log() { printf '\n==> %s\n' "$*"; }

port_listening() { ss -ltn 2>/dev/null | awk '{print $4}' | grep -qE "[:.]$1\$"; }

start_postgres() {
	local PGDATA="$RUN_DIR/pgdata"
	if ! port_listening "$PG_PORT"; then
		log "Запускаю Postgres (порт $PG_PORT)"
		mkdir -p "$PGDATA"
		[[ -d "$PGDATA/base" ]] || "$PG_BIN/initdb" -D "$PGDATA" -U postgres --auth=trust >/dev/null
		(cd "$ROOT_DIR" && nohup "$PG_BIN/pg_ctl" -D "$PGDATA" -l "$RUN_DIR/pg.log" -o "-p $PG_PORT -k $RUN_DIR" start >/dev/null 2>&1 &)
		# ждём готовности
		for _ in $(seq 1 20); do port_listening "$PG_PORT" && break; sleep 0.5; done
	fi
	# гарантируем пароль и БД
	endpoint="postgresql://postgres:postgres@localhost:$PG_PORT/community_club"
	PSQL=("$PG_BIN/psql" "$endpoint" -v ON_ERROR_STOP=0)
	"${PSQL[@]}" -c "ALTER USER postgres PASSWORD 'postgres';" >/dev/null 2>&1 || true
	"${PSQL[@]}" -c "CREATE DATABASE community_club;" >/dev/null 2>&1 || true
}

start_redis() {
	if ! port_listening "$REDIS_PORT"; then
		log "Запускаю Redis (порт $REDIS_PORT)"
		mkdir -p "$RUN_DIR"
		(nohup "$REDIS_BIN/redis-server" --port "$REDIS_PORT" --save "" --appendonly no --dir "$RUN_DIR" >"$RUN_DIR/redis.log" 2>&1 &)
		for _ in $(seq 1 20); do port_listening "$REDIS_PORT" && break; sleep 0.5; done
	fi
}

start_garage() {
	if ! port_listening 3902; then
		log "Запускаю Garage (S3, порты 3900/3902)"
		mkdir -p "$RUN_DIR/garage/data" "$RUN_DIR/garage/meta" "$RUN_DIR/garage/secrets" "$RUN_DIR/garage/logs"
		# конфиг генерируется при первом запуске
		if [[ ! -f "$GARAGE_CONFIG" ]]; then
			local rpc admin
			rpc="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')"
			admin="$(head -c 24 /dev/urandom | base64 | tr -d '\n')"
			printf '%s' "$rpc" > "$RUN_DIR/garage/secrets/rpc_secret"
			printf '%s' "$admin" > "$RUN_DIR/garage/secrets/admin_token"
			cat > "$GARAGE_CONFIG" <<EOF
metadata_dir = "$RUN_DIR/garage/meta"
data_dir = "$RUN_DIR/garage/data"
db_engine = "lmdb"

replication_factor = 1
compression_level = 1

block_size = 10485760
block_ram_buffer_max = 67108864

rpc_bind_addr = "[::]:3901"
rpc_secret_file = "$RUN_DIR/garage/secrets/rpc_secret"

[s3_api]
s3_region = "garage"
api_bind_addr = "[::]:3900"
root_domain = ".localhost"

[s3_web]
bind_addr = "[::]:3902"
root_domain = ".localhost"
index = "index.html"

[admin]
api_bind_addr = "[::]:3903"
admin_token_file = "$RUN_DIR/garage/secrets/admin_token"
EOF
		fi
		chmod 600 "$RUN_DIR/garage/secrets/rpc_secret" "$RUN_DIR/garage/secrets/admin_token"
		(nohup env GARAGE_ALLOW_WORLD_READABLE_SECRETS=1 "$GARAGE_BIN/garage" -c "$GARAGE_CONFIG" server >"$RUN_DIR/garage/server.log" 2>&1 &)
		for _ in $(seq 1 30); do port_listening 3902 && break; sleep 1; done
	fi
	bootstrap_garage
}

bootstrap_garage() {
	local G=("$GARAGE_BIN/garage" -c "$GARAGE_CONFIG")
	command -v curl >/dev/null || return 0
	# Layout: один узел, зона dc1
	local node_id
	node_id="$("${G[@]}" node id 2>/dev/null | head -1 | cut -d'@' -f1 | tr -d ' \n')"
	if [[ -z "$node_id" ]]; then
		log "Garage не готов к bootstrap"
		return 1
	fi
	"${G[@]}" layout assign -z dc1 -c 1G "$node_id" >/dev/null 2>&1 || true
	# версия layout из подсказки apply, либо 1
	local ver
	ver="$("${G[@]}" layout show 2>/dev/null | sed -n 's/.*--version \([0-9][0-9]*\).*/\1/p' | head -1)"
	"${G[@]}" layout apply --version "${ver:-1}" >/dev/null 2>&1 || true

	# бакеты + website-доступ
	for b in media chat-attachments avatars; do
		"${G[@]}" bucket create "$b" >/dev/null 2>&1 || true
		"${G[@]}" bucket website --allow "$b" >/dev/null 2>&1 || true
	done
	# алиас chat-media → chat-attachments (в проде делает Caddy)
	"${G[@]}" bucket alias chat-attachments chat-media >/dev/null 2>&1 || true

	# ключ доступа
	local ak sk out
	ak="$(awk -F= '$1=="S3_ACCESS_KEY"{sub(/^[^=]*=/,"");print;exit}' "$ROOT_DIR/.env" 2>/dev/null || true)"
	sk="$(awk -F= '$1=="S3_SECRET_KEY"{sub(/^[^=]*=/,"");print;exit}' "$ROOT_DIR/.env" 2>/dev/null || true)"
	if [[ -z "$ak" || -z "$sk" ]] || ! "${G[@]}" key info "$ak" >/dev/null 2>&1; then
		out="$("${G[@]}" key create club-local-key 2>/dev/null || true)"
		ak="$(printf '%s\n' "$out" | awk 'tolower($0) ~ /key id/{print $NF;exit}')"
		sk="$(printf '%s\n' "$out" | awk 'tolower($0) ~ /secret/{print $NF;exit}')"
	fi
	[[ -n "$ak" && -n "$sk" ]] || { log "Не удалось подготовить S3-ключи"; return 1; }
	for b in media chat-attachments avatars; do
		"${G[@]}" bucket allow --read --write --owner "$b" --key "$ak" >/dev/null 2>&1 || true
	done

	set_env S3_ENDPOINT "http://localhost:3900"
	set_env S3_REGION "garage"
	set_env S3_ACCESS_KEY "$ak"
	set_env S3_SECRET_KEY "$sk"
	set_env S3_PUBLIC_URL "http://media.localhost:3902"
	set_env S3_BUCKET_MEDIA "media"
	set_env S3_BUCKET_CHAT "chat-attachments"
	set_env S3_BUCKET_AVATARS "avatars"
}

set_env() { # set_env <key> <value> — заполнить в .env, если пусто/плейсхолдер
	local key="$1" val="$2" cur
	cur="$(awk -F= -v k="$key" '$1==k{sub(/^[^=]*=/,"");print;exit}' "$ROOT_DIR/.env" 2>/dev/null || true)"
	if [[ -z "$cur" || "$cur" == your-secret-key-* ]]; then
		if grep -q "^${key}=" "$ROOT_DIR/.env" 2>/dev/null; then
			sed -i "s|^${key}=.*|${key}=${val}|" "$ROOT_DIR/.env"
		else
			printf '%s=%s\n' "$key" "$val" >> "$ROOT_DIR/.env"
		fi
	fi
}

sync_schema() {
	local url="$1"
	log "Синхронизирую схему БД"
	(cd "$ROOT_DIR/packages/api" && DATABASE_URL="$url" bunx drizzle-kit push --config drizzle.config.ts --force >/dev/null 2>&1 || true)
}

ensure_admin() {
	local url="$1"
	local script="$RUN_DIR/_ensure_admin.mjs"
	cat > "$script" <<EOF
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "@community-club/shared/db/schema";
import { users } from "@community-club/shared/db/schema";
const sql = postgres("$1", { max: 1 });
const db = drizzle(sql, { schema });
const email = "${ADMIN_EMAIL}";
const hash = await Bun.password.hash("${ADMIN_PASSWORD}", { algorithm: "bcrypt", cost: 12 });
const ex = await db.query.users.findFirst({ where: eq(users.email, email) });
if (ex) await db.update(users).set({ role: "superadmin", passwordHash: hash, authType: "email", fullName: "Владелец", chatAdminBadge: true }).where(eq(users.email, email));
else await db.insert(users).values({ email, fullName: "Владелец", role: "superadmin", authType: "email", passwordHash, chatAdminBadge: true });
await sql.end();
EOF
	(cd "$ROOT_DIR/packages/api" && DATABASE_URL="$1" bun "$script" >/dev/null 2>&1 || true)
	rm -f "$script"
}

is_running() { # is_running <порт> <маркер-паттерн>
	local port="$1" pat="$2"
	port_listening "$port" && pgrep -af "$pat" >/dev/null 2>&1
}

start_dev() {
	log "Запускаю dev-серверы (api:3001, web:3000, admin:3002)"
	export NITRO_NO_UNIX_SOCKET=1 NUXT_TELEMETRY_DISABLED=1
	export APP_URL="http://localhost:3000" API_URL="http://localhost:3001" ADMIN_URL="http://localhost:3002/admin"
	if ! is_running 3001 "src/index.ts"; then
		(cd "$ROOT_DIR/packages/api" && nohup bun run --hot src/index.ts >"$RUN_DIR/api.log" 2>&1 &)
	fi
	if ! is_running 3000 "packages/web"; then
		(cd "$ROOT_DIR/packages/web" && nohup bun run dev >"$RUN_DIR/web.log" 2>&1 &)
	fi
	# admin требует fixed viteEnvironmentApi (cм. nuxt.config.ts) + NITRO_NO_UNIX_SOCKET
	if ! is_running 3002 "packages/admin"; then
		if ! grep -q "viteEnvironmentApi" "$ROOT_DIR/packages/admin/nuxt.config.ts"; then
			sed -i "0,/experimental:/{s/experimental:/&\n\t\tviteEnvironmentApi: true,/}" "$ROOT_DIR/packages/admin/nuxt.config.ts"
			log "Добавил experimental.viteEnvironmentApi в admin nuxt.config.ts (фикс dev на Bun)"
		fi
		(cd "$ROOT_DIR/packages/admin" && nohup bun run dev >"$RUN_DIR/admin.log" 2>&1 &)
	fi

	# ждём готовности
	for _ in $(seq 1 40); do
		(port_listening 3000 && port_listening 3001 && port_listening 3002) && break
		sleep 1
	done
}

main() {
	cd "$ROOT_DIR"
	[[ -d node_modules ]] || { log "Запусти сначала: bun install"; exit 1; }
	[[ -f .env ]] || cp .env.example .env
	mkdir -p "$RUN_DIR"

	start_postgres
	start_redis
	start_garage

	local db_url="postgresql://postgres:postgres@localhost:$PG_PORT/community_club"
	sync_schema "$db_url"
	ensure_admin "$db_url"
	start_dev

	log "Готово. Локальный клуб запущен:"
	echo "  Приложение: http://localhost:3000"
	echo "  Админка:    http://localhost:3002/admin  (логин: $ADMIN_EMAIL / $ADMIN_PASSWORD)"
	echo "  API:        http://localhost:3001/health"
	echo "  Медиа:      http://media.localhost:3902"
}

main "$@"