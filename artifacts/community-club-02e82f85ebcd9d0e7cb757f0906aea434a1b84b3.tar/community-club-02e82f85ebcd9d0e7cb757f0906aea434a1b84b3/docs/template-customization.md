# Template Customization Guide

Этот шаблон уже очищен от исходных production-доменов, серверного IP, старых реквизитов и локальных session-файлов. Ниже — короткий маршрут адаптации под новый продукт.

## 1. Namespace

По умолчанию используется:

- root package: `community-club`
- workspace scope: `@community-club/*`
- Docker project/container prefix: `community-club`
- database name: `community_club`

Для переименования используйте точечную замену по репозиторию и затем выполните:

```bash
bun install
bun run lint
bun run build
```

## 2. Бренд и PWA

Проверьте:

- Админка → `Настройки` → `Главная`: название клуба, логотип и цвета приложения. Эти настройки используются на главном экране, в PWA manifest и в install prompt.
- `packages/web/server/routes/pwa-manifest.ts` и `packages/web/server/routes/pwa-icon.ts` — runtime-отдача PWA manifest/icon из настроек бренда.
- `packages/admin/nuxt.config.ts` — title админки.
- `packages/web/public/icons/*` — нейтральные fallback PWA icons и favicon на случай, если логотип клуба ещё не выбран.
- `packages/web/assets/css/main.css` и `packages/admin/assets/css/main.css` — палитра и типографика.
- Публичные страницы в `packages/web/pages/index.vue`, `login.vue`, `register.vue`, `purchase.vue`.

## 3. Legal и контакты

Плейсхолдеры находятся в:

- `packages/web/pages/legal/*`
- `packages/web/pages/app/legal/*`
- footer/оплатные блоки в `packages/web/pages/index.vue` и `packages/web/pages/app/payment.vue`

Перед production замените оферту, политику, реквизиты, email, телефон и город регистрации на данные владельца проекта.

## 4. Доступы и тарифы

Шаблон настроен как закрытый клуб с одним типом участника. Вход открывается только после активной оплаты по `date_finish`; бесплатный пробный доступ и ролевые развилки в пользовательском контуре выключены.

Проверьте:

- `packages/shared/src/constants/index.ts`
- `packages/shared/src/db/schema/*`
- `packages/api/src/services/pricing.service.ts`
- `packages/api/src/lib/pricing-matrix-bootstrap.ts`
- `packages/api/src/lib/feed-bootstrap.ts`
- `packages/api/src/lib/media-library-bootstrap.ts`

Если в новом продукте нет Telegram, MAX или выбранной платёжной системы, отключите соответствующие настройки в админке до деплоя.

## 5. Инфраструктура

Основные файлы:

- `.env.example`
- `.env.staging.example`
- `docker-compose.yml`
- `docker-compose.prod.yml`
- `docker-compose.staging.yml`
- `garage.toml`
- `scripts/garage-init.sh`
- `scripts/deploy-production.sh`
- `scripts/deploy-staging.sh`

Production secrets должны жить только на сервере в `.env` и `secrets/`.

## 6. Проверка перед первым коммитом проекта

```bash
bun install
bun run lint
bun run build
rg -n "example.com|000000|Community Club|community-club|@community-club"
```

Последняя команда нужна как checklist: замените плейсхолдеры, которые относятся к вашему бренду, и оставьте только осознанные значения.
