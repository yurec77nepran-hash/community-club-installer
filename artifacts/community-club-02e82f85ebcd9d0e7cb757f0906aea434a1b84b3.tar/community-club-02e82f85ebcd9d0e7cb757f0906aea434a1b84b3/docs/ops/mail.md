# Mail Setup

Проект переведён на локальный SMTP и open-source mail-сервер `Stalwart`.

Целевой сценарий:

- приложение отправляет письма через SMTP;
- `Stalwart` работает на том же сервере в Docker;
- отправитель: `noreply@mail.clud.nepran-yuri.ru`.

## 1. Что уже есть в коде

В API доступны два режима:

- `MAIL_PROVIDER=log` для локальной отладки;
- `MAIL_PROVIDER=smtp` для реальной отправки через SMTP.

Почтовые сценарии уже подключены:

- welcome email после регистрации;
- письмо со ссылкой на сброс пароля;
- уведомление о смене пароля.

## 2. Какие env нужны

Пример для production:

```env
MAIL_PROVIDER=smtp
MAIL_FROM_EMAIL=noreply@mail.clud.nepran-yuri.ru
MAIL_FROM_NAME=Community Club
MAIL_REPLY_TO=support@clud.nepran-yuri.ru

SMTP_HOST=mail
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=noreply@mail.clud.nepran-yuri.ru
SMTP_PASSWORD=CHANGE_ME
SMTP_ALLOW_INVALID_CERTS=true
```

Важно:

- внутри `docker-compose.prod.yml` API видит mail-сервис по имени `mail`, поэтому `SMTP_HOST=mail`;
- для локального запуска вне Docker можно поставить `SMTP_HOST=127.0.0.1`;
- сразу после первого запуска `Stalwart` использует self-signed TLS на SMTP, поэтому до установки нормального сертификата нужно держать `SMTP_ALLOW_INVALID_CERTS=true`.

## 3. DNS для `clud.nepran-yuri.ru`

Так как wildcard уже настроен, для почты всё равно нужно проверить отдельные записи именно под mail-контур.

Минимальный набор:

- `A` для `mail.clud.nepran-yuri.ru` -> `193.124.33.21`;
- `MX` для `clud.nepran-yuri.ru` -> `mail.clud.nepran-yuri.ru`;
- `SPF` для `clud.nepran-yuri.ru`;
- `DKIM` из панели `Stalwart`;
- `DMARC` для `clud.nepran-yuri.ru`.

Базовый пример SPF:

```txt
v=spf1 mx a:mail.clud.nepran-yuri.ru ip4:193.124.33.21 ~all
```

Базовый пример DMARC:

```txt
v=DMARC1; p=quarantine; adkim=s; aspf=s; rua=mailto:postmaster@clud.nepran-yuri.ru
```

## 4. Первый запуск `Stalwart`

После `docker compose -f docker-compose.prod.yml up -d`:

1. Открой админку на сервере:

```bash
ssh root@193.124.33.21 -L 8080:127.0.0.1:8080
```

2. Затем локально открой:

```text
http://127.0.0.1:8080
```

3. Пройди initial setup `Stalwart`.

4. Создай:

- домен `clud.nepran-yuri.ru`;
- почтовый ящик `noreply@mail.clud.nepran-yuri.ru`;
- при необходимости `support@clud.nepran-yuri.ru`.

5. В панели `Stalwart` забери DKIM DNS-запись и добавь её в DNS.

6. Возьми логин/пароль ящика `noreply@mail.clud.nepran-yuri.ru` и вставь в `.env`:

- `SMTP_USER`
- `SMTP_PASSWORD`

## 5. Порты на сервере

Для нормальной работы почты на сервере должны быть доступны:

- `25/tcp` для входящей почты между серверами;
- `587/tcp` для SMTP submission.

Админка `Stalwart` у нас опубликована только локально:

- `127.0.0.1:8080:8080`

Это сделано специально, чтобы не торчала наружу.

## 6. Проверка

После настройки:

1. Перезапусти API:

```bash
docker compose -f docker-compose.prod.yml up -d api
```

2. Запроси сброс пароля на сайте.

3. Проверь логи:

```bash
docker compose -f docker-compose.prod.yml logs -f api mail
```

Если письма не уходят, сначала проверь:

- правильный ли `SMTP_HOST`;
- совпадает ли `MAIL_FROM_EMAIL` с реально созданным ящиком;
- открыт ли `587/tcp`;
- настроены ли `SPF`, `DKIM`, `DMARC`;
- есть ли reverse DNS у IP сервера.
