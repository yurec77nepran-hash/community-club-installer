# Релизный цикл: demo → production

Этот runbook задаёт обязательный порядок доставки изменений Community Club:
сначала demo, затем production. Оба контура работают на `193.124.33.21`, но
используют разные директории, Compose projects, локальные порты и публичные
домены.

## Контуры

| Контур | Директория | Compose | Порты | Публичный URL |
|--------|------------|---------|-------|---------------|
| Demo | `/opt/community-club-demo` | `-p community-club-demo -f docker-compose.prod.yml` | `3200/3201/3202`, media `3922` | `https://demo-clud.nepran-yuri.ru` |
| Production | `/opt/community-club` | `-f docker-compose.prod.yml` | `3000/3001/3002`, media `3902` | `https://clud.nepran-yuri.ru` |

Серверные `.env`, `secrets/` и `docker-compose*.yml` не синхронизируются
обычным деплоем. Передавать `SYNC_INFRA=1` можно только при запланированном
изменении инфраструктуры.

## Стандартный релиз

1. Проверь изменения и убедись, что в релиз не попали `.env`, `.env.*` или
   `secrets/`.
2. Запусти demo deploy:
   ```bash
   ./scripts/deploy-demo.sh
   ```
3. Убедись, что скрипт успешно завершил локальные `lint` и `build`, поднял
   demo-сервисы и выполнил smoke-проверки портов `3200/3201/3202`, `/health`
   и публичного домена.
4. При необходимости проверь медиа `Range`-запросом к
   `https://demo-clud.nepran-yuri.ru/media/<key>`; ожидаются `206` и
   `accept-ranges: bytes`.
5. Только после успешного demo запусти production deploy:
   ```bash
   ./scripts/deploy-production.sh
   ```
6. Проверь успешные smoke-ответы production на портах `3000/3001/3002`,
   `/health` и на `https://clud.nepran-yuri.ru`.

## Стоп-условия

- Если demo deploy, сборка или любая smoke-проверка завершилась ошибкой, не
  запускай production deploy.
- Если production deploy завершился ошибкой, зафиксируй упавший этап и не
  объявляй релиз завершённым.
- Правки только документации не требуют деплоя.
- `SKIP_CHECKS=1` допустим только когда локальные `lint` и `build` уже успешно
  выполнены для того же состояния workspace.

## Что делают deploy-скрипты

`deploy-demo.sh` передаёт общей логике `deploy-production.sh` demo-путь,
Compose project, demo-порты и demo URL.

`deploy-production.sh` по умолчанию использует `root@193.124.33.21`,
`/opt/community-club`, `docker-compose.prod.yml` и
`https://clud.nepran-yuri.ru`. Скрипт выбирает изменённые app-сервисы по
`.deploy-rev`, синхронизирует workspace, выполняет `docker compose build` и
`up -d`, затем запускает локальные и публичные smoke-проверки.

## Связанные документы

- `docs/ops/deploy-production.md` — параметры deploy-скриптов и ручные команды.
- `docs/ops/server-access.md` — безопасная справка по SSH и директориям.
- `docs/agent-context.md` — краткий контекст проекта для агентов.
