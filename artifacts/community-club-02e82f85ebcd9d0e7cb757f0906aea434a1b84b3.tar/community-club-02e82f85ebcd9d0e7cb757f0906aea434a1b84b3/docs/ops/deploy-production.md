# Production Deploy

Актуальный прод-сервер:

- `SSH`: `root@193.124.33.21`
- `Path`: `/opt/community-club`
- `Public URL`: `https://clud.nepran-yuri.ru`

## Быстрый путь

Для первого запуска на новом сервере используй bootstrap:

```bash
DOMAIN=clud.nepran-yuri.ru ./scripts/server-bootstrap.sh
```

Если репозиторий ещё не склонирован на сервер, можно поставить шаблон одной командой:

```bash
REPO_URL=https://github.com/yurec77nepran-hash/community-club-source.git DOMAIN=clud.nepran-yuri.ru bash -c "$(curl -fsSL https://raw.githubusercontent.com/yurec77nepran-hash/community-club-source/main/scripts/install-on-server.sh)"
```

Он проверит и установит недостающие зависимости, подготовит `.env`, Garage, Docker Compose, Caddy и helper-сервис для подключения домена из админки. Подробности: [server-bootstrap.md](server-bootstrap.md).
В конце bootstrap выведет ссылку на админку и первый логин/пароль владельца. Эти данные также сохраняются на сервере в `secrets/initial_admin_credentials`.

Для последующих деплоев из корня репозитория:


```bash
./scripts/deploy-production.sh
```

Что делает скрипт:

1. Локально запускает `bun run lint`
2. Локально запускает `bun run build`
3. Синхронизирует текущий workspace на сервер через `rsync`
4. Не перезаписывает серверные `.env`, `secrets` и `docker-compose*.yml`
5. На сервере выполняет:
   - auto-выбор изменённых app-сервисов (`api`, `web`, `admin`) по `.deploy-rev`
   - `docker compose -f docker-compose.prod.yml build <services>`
   - `docker compose -f docker-compose.prod.yml up -d <services>`
6. Проверяет:
   - `http://localhost:3000/`
   - `http://localhost:3001/api/payments/tariffs`
   - `http://localhost:3002/admin/`
   - `http://localhost:3001/health`

## Demo контур

Demo расположен на том же сервере `root@193.124.33.21` в `/opt/community-club-demo`.
Публичная ссылка: `https://demo-clud.nepran-yuri.ru`.

Для деплоя demo используй wrapper:

```bash
./scripts/deploy-demo.sh
```

Он вызывает `deploy-production.sh` с параметрами:

- `SERVER_HOST=root@193.124.33.21`
- `SERVER_PATH=/opt/community-club-demo`
- `COMPOSE_FILES="docker-compose.prod.yml"`
- `COMPOSE_PROJECT=community-club-demo`
- `WEB_CHECK_PORT=3200`
- `API_CHECK_PORT=3201`
- `ADMIN_CHECK_PORT=3202`
- `PUBLIC_BASE_URL=https://demo-clud.nepran-yuri.ru`

Если нужен ручной запуск без wrapper:

```bash
SERVER_HOST=root@193.124.33.21 \
SERVER_PATH=/opt/community-club-demo \
COMPOSE_FILES="docker-compose.prod.yml" \
COMPOSE_PROJECT=community-club-demo \
WEB_CHECK_PORT=3200 \
API_CHECK_PORT=3201 \
ADMIN_CHECK_PORT=3202 \
PUBLIC_BASE_URL=https://demo-clud.nepran-yuri.ru \
./scripts/deploy-production.sh
```

Для проверки видео после деплоя используй `Range`-запрос к любому объекту в `/media/<key>`; ожидаемый ответ — `206` и `accept-ranges: bytes`.
Demo использует отдельные `.env`, Compose project и Docker volumes. Обычный `rsync --delete` не должен удалять серверный `docker-compose.prod.yml`, пока `SYNC_INFRA=1` не задан явно.

## Порядок релиза

Сначала выполни `./scripts/deploy-demo.sh`. Запускай
`./scripts/deploy-production.sh` только после успешной сборки и smoke-проверок
demo. Если demo deploy завершился ошибкой, production не обновляй. Полный
runbook: [release-cycle.md](release-cycle.md).

## Если нужно быстрее

Можно пропустить локальные проверки:

```bash
SKIP_CHECKS=1 ./scripts/deploy-production.sh
```

## Если меняется инфраструктура

По умолчанию скрипт не синхронизирует `docker-compose*.yml`, чтобы не затирать серверные локальные правки.

Если в релизе меняются сервисы, например mail-сервер, используй:

```bash
SYNC_INFRA=1 ./scripts/deploy-production.sh
```

`.env` и `secrets` скрипт всё равно не перезаписывает.

## Почему деплой через `rsync`

Скрипт синхронизирует текущий workspace напрямую, чтобы сервер получил ровно проверенное локальное состояние. Если команда работает только через GitOps, этот сценарий можно заменить на `git pull`/CI deploy без изменения приложения.

## Что нельзя перетирать

Следующие вещи на проде считаются серверно-специфичными и не должны затираться обычным деплоем:

- `/opt/community-club/.env`
- `/opt/community-club/secrets/*`
- `/opt/community-club/docker-compose.prod.yml`

Важно:

- на сервере `docker-compose.prod.yml` может отличаться от репозитория;
- если добавляется новый сервис, например `mail`, либо обнови серверный compose вручную, либо деплой через `SYNC_INFRA=1`.

## Почта

Локальный open-source mail-контур описан отдельно в [mail.md](mail.md).

## Caddy

Для больших загрузок видео в `/etc/caddy/Caddyfile` нужен глобальный timeout чтения тела запроса.
Без него медленные соединения могут обрываться примерно через 5 минут.

```caddy
{
	servers {
		timeouts {
			read_body 60m
			idle 60m
		}
	}
}
```

В site-блоках production и staging лимит тела запроса должен оставаться не ниже максимального upload-лимита API:

```caddy
request_body {
	max_size 3GB
}
```

Для streaming `/media/*`, `/avatars/*` и `/chat-media/*` в `reverse_proxy` нужен немедленный flush, чтобы видео и аудио стабильно отдавались браузеру по `Range`-запросам:

```caddy
reverse_proxy localhost:3902 {
	header_up Host media
	flush_interval -1
}
```

### Автоподключение домена из админки

Админка может подключать пользовательский домен полностью: проверить DNS, записать managed Caddy site-block, выполнить `caddy validate`, перезагрузить Caddy и проверить `https://domain/health`. Сертификат выпускает Caddy через automatic HTTPS после успешной загрузки site-block.

На production Caddyfile должен импортировать managed-файлы:

```caddy
import /etc/caddy/conf.d/*.caddy
```

Bootstrap поднимает отдельный host-side helper `${APP_NAME}-domain-helper.service`. API из контейнера не получает доступ к `/etc/caddy` и `systemctl` напрямую: он вызывает helper по `host.docker.internal` с bearer-токеном, а helper уже пишет managed-файл, валидирует конфиг и перезагружает Caddy.

Production `.env`:

```bash
DOMAIN_PROVISION_ENABLED=true
DOMAIN_PROVISION_CONFIG_PATH=/etc/caddy/conf.d/community-club-domains.caddy
DOMAIN_PROVISION_VALIDATE_COMMAND="caddy validate --config /etc/caddy/Caddyfile"
DOMAIN_PROVISION_RELOAD_COMMAND="systemctl reload caddy"
DOMAIN_PROVISION_WEB_PORT=3000
DOMAIN_PROVISION_API_PORT=3001
DOMAIN_PROVISION_ADMIN_PORT=3002
DOMAIN_PROVISION_MEDIA_PORT=3902
DOMAIN_PROVISION_SMOKE_TIMEOUT_MS=20000
DOMAIN_PROVISION_HELPER_BIND=172.17.0.1
DOMAIN_PROVISION_HELPER_PORT=7823
DOMAIN_PROVISION_HELPER_URL=http://host.docker.internal:7823/provision
DOMAIN_PROVISION_HELPER_TOKEN=generated-secret
```

Если права не выданы или `DOMAIN_PROVISION_ENABLED=false`, кнопка в админке не будет показывать ложный успех: backend вернёт статус, что автоподключение недоступно на сервере.

## Важная особенность сборки

`packages/web/Dockerfile` и `packages/admin/Dockerfile` должны собираться через `bun`, а не `pnpm`, потому что в корневом `package.json` указан:

```json
"packageManager": "bun@1.3.9"
```

Если вернуть `pnpm`-builder, продовая сборка снова сломается на ошибке:

```text
Unsupported package manager specification (bun@1.3.9)
```

## Ручной деплой

Если нужен ручной режим:

```bash
rsync -az \
  --exclude '.git' \
  --exclude 'node_modules' \
  --exclude '.turbo' \
  --exclude '.env' \
  --exclude '.env.*' \
  --exclude 'docker-compose*.yml' \
  --exclude 'secrets' \
  --exclude 'packages/*/node_modules' \
  --exclude 'packages/*/.nuxt' \
  --exclude 'packages/*/.output' \
  --exclude 'packages/*/dist' \
  --exclude 'packages/api/dist' \
  ./ root@193.124.33.21:/opt/community-club/

ssh root@193.124.33.21 'cd /opt/community-club && docker compose -f docker-compose.prod.yml build && docker compose -f docker-compose.prod.yml up -d'

ssh root@193.124.33.21 'cd /opt/community-club && docker compose -f docker-compose.prod.yml ps'
ssh root@193.124.33.21 'curl -s http://localhost:3001/health'
```

## Post-deploy smoke check

Минимальный набор:

```bash
ssh root@193.124.33.21 'docker compose -f /opt/community-club/docker-compose.prod.yml ps'
ssh root@193.124.33.21 'curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/'
ssh root@193.124.33.21 'curl -s -o /dev/null -w "%{http_code}" http://localhost:3001/api/payments/tariffs'
ssh root@193.124.33.21 'curl -s -o /dev/null -w "%{http_code}" http://localhost:3002/admin/'
ssh root@193.124.33.21 'curl -s http://localhost:3001/health'
```
