# Server Bootstrap

Скрипт `scripts/server-bootstrap.sh` поднимает production-контур шаблона на чистом Ubuntu/Debian-like сервере.

Он работает аккуратно:

- проверяет `curl`, `git`, `rsync`, `openssl`, Docker Compose и Caddy;
- отсутствующие зависимости ставит через `apt`;
- уже установленный Docker/Caddy использует как есть;
- не удаляет чужие контейнеры, сайты Caddy и проекты;
- если стандартные порты заняты, подбирает свободные рядом и записывает их в `.env`;
- пишет отдельный Caddy snippet в `/etc/caddy/conf.d/community-club.caddy`;
- поднимает host-side helper для безопасной записи managed Caddy-конфига из админки;
- перед изменением `.env` делает backup;
- повторный запуск не удаляет данные Postgres, Redis, Garage и секреты.
- ставит команду `club` для проверки статуса, вывода контекста и работы с admin API.

## Запуск

Из корня проекта на сервере:

```bash
DOMAIN=clud.nepran-yuri.ru ./scripts/server-bootstrap.sh
```

Если сервер пустой и репозиторий ещё не склонирован, установщик можно запустить одной командой:

```bash
REPO_URL=https://github.com/yurec77nepran-hash/community-club-source.git DOMAIN=clud.nepran-yuri.ru bash -c "$(curl -fsSL https://raw.githubusercontent.com/yurec77nepran-hash/community-club-source/main/scripts/install-on-server.sh)"
```

Для установки рядом с другим проектом можно задать отдельную директорию:

```bash
APP_NAME=community-club-demo APP_DIR=/opt/community-club-demo REPO_URL=https://github.com/yurec77nepran-hash/community-club-source.git DOMAIN=demo-clud.nepran-yuri.ru bash -c "$(curl -fsSL https://raw.githubusercontent.com/yurec77nepran-hash/community-club-source/main/scripts/install-on-server.sh)"
```

Если домен ещё не настроен, можно запустить без `DOMAIN`; скрипт попробует определить публичный IP и выдаст ссылки вида `http://IP`.

## Что делает

1. Устанавливает недостающие системные зависимости.
2. Создаёт или обновляет локальный `.env` проекта.
3. Генерирует `DB_PASSWORD`, `REDIS_PASSWORD`, `JWT_SECRET`, если их ещё нет.
4. Генерирует VAPID-ключи для push-уведомлений, если они ещё не заданы.
5. Выбирает локальные порты для web/API/admin/media/mail и сохраняет их как `WEB_HOST_PORT`, `API_HOST_PORT`, `ADMIN_HOST_PORT`, `MEDIA_HOST_PORT`.
6. Настраивает Caddy reverse proxy на выбранные порты:
   - `/` -> web;
   - `/api/*` и `/health` -> API;
   - `/admin*` -> admin;
   - `/media/*`, `/avatars/*`, `/chat-media/*` -> Garage web.
7. Создаёт systemd-сервис `${APP_NAME}-domain-helper.service`, который принимает запросы только с токеном и умеет записывать managed Caddy-конфиг, валидировать и перезагружать Caddy.
8. Инициализирует Garage buckets и S3-ключи.
9. Запускает Postgres и Redis.
10. Применяет схему БД через Drizzle.
11. Создаёт первого владельца админки.
12. Собирает и запускает приложение через `docker compose -f docker-compose.prod.yml`.
13. Проверяет health, web, admin, тарифы и публичные настройки оплаты.
14. Устанавливает `/usr/local/bin/club` и `/etc/community-club/club.conf`.
15. Печатает ссылки на приложение и админку, email и пароль первого входа.

`scripts/install-on-server.sh` не перезаписывает занятые директории: если `/opt/community-club` уже содержит другой git-проект, незакоммиченные изменения или не может обновиться fast-forward, шаблон будет установлен в соседнюю директорию с временным суффиксом.

## Полезные параметры

```bash
# Не ставить системные пакеты, только проверить наличие
INSTALL_SYSTEM_DEPS=0 ./scripts/server-bootstrap.sh

# Разрешить apt обновить уже установленные пакеты из списка зависимостей
UPDATE_EXISTING_PACKAGES=1 ./scripts/server-bootstrap.sh

# Включить ufw и открыть 22/80/443
ENABLE_FIREWALL=1 ./scripts/server-bootstrap.sh

# Задать первого владельца вручную
ADMIN_EMAIL=owner@clud.nepran-yuri.ru ADMIN_PASSWORD='long-secret-password' ./scripts/server-bootstrap.sh

# Не пересобирать Docker images, только поднять контейнеры
SKIP_APP_BUILD=1 ./scripts/server-bootstrap.sh
```

## Обновления

Актуальные production и demo обновляются deploy-скриптами из рабочего
репозитория. Сначала выполни `./scripts/deploy-demo.sh`; только после успешных
smoke-проверок запускай `./scripts/deploy-production.sh`. Полный порядок
описан в [release-cycle.md](release-cycle.md).

## Важно

Скрипт рассчитан на Ubuntu/Debian-like сервер. На локальной NixOS-машине его запускать не нужно.

Первый логин и пароль сохраняются в `secrets/initial_admin_credentials` с правами `600`. После входа пароль можно поменять в админке в карточке пользователя. Новых сотрудников можно добавлять в разделе `Пользователи`, выбирая доступ `Сотрудник` или `Владелец`. Для сотрудников можно отметить доступные разделы админки; владелец всегда видит всё.

Подключение домена из админки идёт через локальный helper-сервис, а не через `systemctl` внутри Docker-контейнера. Bootstrap привязывает helper к Docker gateway, записывает `DOMAIN_PROVISION_HELPER_URL` и токен в `.env`, затем проверяет `/health`. API вызывает `http://host.docker.internal:7823/provision` с токеном из `.env`, helper на host-системе пишет `/etc/caddy/conf.d/community-club-domains.caddy`, запускает `caddy validate` и `systemctl reload caddy`.

Если на сервере уже есть Caddy, текущий `/etc/caddy/Caddyfile` не перезаписывается. Скрипт только добавляет строку:

```caddy
import /etc/caddy/conf.d/*.caddy
```

если её ещё нет, и сохраняет backup рядом.
