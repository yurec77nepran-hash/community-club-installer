# Staging Deploy

Read-only staging-контур для безопасной проверки интерфейсов и чтения боевых данных.

## Назначение

- staging использует боевую БД только через отдельного пользователя `SELECT-only`;
- staging использует отдельный Redis только для своих сессий, rate-limit и кэшей;
- staging не должен создавать таблицы, индексы, webhook, фоновые процессоры и другие startup-записи;
- mutation-запросы в API отключены, кроме `login`, `refresh` и `logout`.

## Целевой хост

- `Host`: `community-club`
- `Path`: `/opt/community-club-staging`
- `Compose`: `docker-compose.staging.yml`
- `Public URL`: `https://staging.example.com`

## Локальный деплой

Из корня репозитория:

```bash
./scripts/deploy-staging.sh
```

Что делает скрипт:

1. локально запускает `bun run lint`;
2. локально запускает `bun run build`;
3. синхронизирует workspace в `/opt/community-club-staging`;
4. на сервере собирает и поднимает `api`, `web`, `admin`, `redis`;
5. проверяет:
   - `http://localhost:3100/`
   - `http://localhost:3101/api/payments/tariffs`
   - `http://localhost:3102/admin/`
   - `http://localhost:3101/health`

## Обязательные серверные файлы

На сервере должны существовать:

- `/opt/community-club-staging/.env.staging`
- `/opt/community-club-staging/docker-compose.staging.yml`

`.env.staging` не должен перетираться деплоем.

## Минимальные server-side отличия от production

- `DATABASE_URL` должен указывать на пользователя `community_club_staging_ro`;
- `REDIS_URL` должен указывать на staging Redis;
- `APP_READ_ONLY=true`;
- `APP_URL=https://staging.example.com`;
- `TELEGRAM_*` и внешние интеграции лучше оставить пустыми, если они не нужны для чтения.

## Caddy

В начале `/etc/caddy/Caddyfile` должен быть глобальный timeout для больших загрузок.
Он общий для production и staging:

```caddy
{
	servers {
		timeouts {
			read_body 60m
			idle 60m
		}
	}
}
```

Нужен отдельный сайт:

```caddy
staging.example.com {
	request_body {
		max_size 3GB
	}

	handle /api/* {
		reverse_proxy localhost:3101
	}
	handle /health {
		reverse_proxy localhost:3101
	}
	handle /admin/_nuxt/* {
		reverse_proxy localhost:3102
	}
	handle /admin/* {
		reverse_proxy localhost:3102
	}
	handle {
		reverse_proxy localhost:3100
	}

	encode gzip
}
```

В production-блоке `/media/*` и других Garage-прокси используем streaming flush:

```caddy
reverse_proxy localhost:3902 {
	header_up Host media
	flush_interval -1
}
```

## Smoke-check

```bash
ssh community-club 'docker compose -p community-club-staging -f /opt/community-club-staging/docker-compose.staging.yml ps'
ssh community-club 'curl -s -o /dev/null -w "%{http_code}" http://localhost:3100/'
ssh community-club 'curl -s -o /dev/null -w "%{http_code}" http://localhost:3101/api/payments/tariffs'
ssh community-club 'curl -s -o /dev/null -w "%{http_code}" http://localhost:3102/admin/'
ssh community-club 'curl -s http://localhost:3101/health'
```
