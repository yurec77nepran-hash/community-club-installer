# Project Map

## Назначение

Этот файл — краткая карта проекта для быстрого входа в контекст без чтения всего репозитория.

## Ссылки

- Production: `https://clud.nepran-yuri.ru`
- Production admin: `https://clud.nepran-yuri.ru/admin/`
- Production media: `https://clud.nepran-yuri.ru/media/`
- Demo: `https://demo-clud.nepran-yuri.ru`
- Demo admin: `https://demo-clud.nepran-yuri.ru/admin/`
- Demo media: `https://demo-clud.nepran-yuri.ru/media/`
- Staging: `https://staging.example.com`

## Сервер

- SSH: `root@193.124.33.21`
- Production path: `/opt/community-club`
- Demo path: `/opt/community-club-demo`
- Staging path: `/opt/community-club-staging`
- Caddy config: `/etc/caddy/Caddyfile`

## Production topology

- `web` → `127.0.0.1:3000`
- `api` → `127.0.0.1:3001`
- `admin` → `127.0.0.1:3002`
- `postgres` → `127.0.0.1:5432`
- `garage` → `127.0.0.1:3900`
- `media public` → `127.0.0.1:3902`
- `mail` → `Stalwart`

## Demo topology

- compose project → `community-club-demo`
- compose file → `docker-compose.prod.yml`
- `web` → `127.0.0.1:3200`
- `api` → `127.0.0.1:3201`
- `admin` → `127.0.0.1:3202`
- `media public` → `127.0.0.1:3922`

## Staging topology

- `web` → `127.0.0.1:3100`
- `api` → `127.0.0.1:3101`
- `admin` → `127.0.0.1:3102`
- отдельный `Redis`
- чтение боевой БД через пользователя `community_club_staging_ro`
- `APP_READ_ONLY=true`

## Структура монорепозитория

### Root

- `package.json` — root workspace
- `turbo.json` — pipeline
- `biome.json` — lint/format
- `docker-compose.prod.yml` — production compose
- `docker-compose.staging.yml` — staging compose
- `scripts/deploy-production.sh` — production deploy
- `scripts/deploy-demo.sh` — demo deploy
- `scripts/deploy-staging.sh` — staging deploy
- `docs/ops/deploy-production.md` — production runbook
- `docs/ops/deploy-staging.md` — staging runbook

### API

- `packages/api/src/app.ts` — Hono app
- `packages/api/src/index.ts` — server entrypoint
- `packages/api/src/routes/` — роуты API
- `packages/api/src/middleware/` — auth, queue, rate-limit, read-only
- `packages/api/src/lib/` — storage, telegram, chat, bootstrap, jobs

### Web

- `packages/web/pages/` — публичные и приватные страницы
- `packages/web/components/` — UI и media-компоненты
- `packages/web/stores/` — Pinia stores
- `packages/web/plugins/` — client plugins

### Admin

- `packages/admin/pages/admin/materials.vue` — карточки материалов
- `packages/admin/pages/admin/media.vue` — медиатека
- `packages/admin/pages/admin/users/` — пользователи
- `packages/admin/pages/admin/payments.vue` — платежи

### Shared

- `packages/shared/src/db/schema/` — таблицы
- `packages/shared/src/db/schema/relations.ts` — связи
- `packages/shared/src/types/` — shared API/WS types
- `packages/shared/src/validators/` — shared Zod validators

## Деплой

Релиз выполняется последовательно: сначала `./scripts/deploy-demo.sh`, после
успешных smoke-проверок — `./scripts/deploy-production.sh`.

### Production

```bash
./scripts/deploy-production.sh
```

Что происходит:
- `lint`
- `build`
- `rsync` в `/opt/community-club`
- auto-выбор изменённых app-сервисов (`api`, `web`, `admin`)
- `docker compose build <services>`
- `docker compose up -d <services>`
- post-deploy smoke-check

### Demo

```bash
./scripts/deploy-demo.sh
```

Что происходит:
- `lint`
- `build`
- `rsync` в `/opt/community-club-demo`
- `docker compose -p community-club-demo -f docker-compose.prod.yml build`
- `docker compose -p community-club-demo -f docker-compose.prod.yml up -d`
- smoke-check портов `3200/3201/3202`, `/health` и публичного домена

### Staging

```bash
./scripts/deploy-staging.sh
```

Что происходит:
- `lint`
- `build`
- `rsync` в `/opt/community-club-staging`
- `docker compose -p community-club-staging build`
- `docker compose -p community-club-staging up -d`
- staging smoke-check

## Ограничения staging

- нельзя использовать его как write-окружение
- все мутации блокируются middleware, кроме:
  - `POST /api/auth/login`
  - `POST /api/auth/refresh`
  - `POST /api/auth/logout`
- WebSocket отключён
- фоновые джобы отключены

## Где смотреть дальше

- production deploy details: [docs/ops/deploy-production.md](ops/deploy-production.md)
- staging deploy details: [docs/ops/deploy-staging.md](ops/deploy-staging.md)
- agent rules: [AGENTS.md](../AGENTS.md)
- shared context: [CLAUDE.md](../CLAUDE.md)
