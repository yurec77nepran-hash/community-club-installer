# Community Club Agent Context

Этот файл — короткий стартовый контекст для Codex, Claude, Cursor, Cline и других AI-агентов. Перед изменениями в проекте прочитай `AGENTS.md`, затем этот файл.

## Проект

`Community Club` — монорепозиторий SaaS/PWA для закрытого онлайн-клуба.

Пакеты:
- `packages/api` — Bun + Hono API, Drizzle, PostgreSQL, Redis, WebSocket.
- `packages/web` — Nuxt 3 пользовательское PWA.
- `packages/admin` — Nuxt 3 админка с `app.baseURL: /admin/`; страницы лежат в `packages/admin/pages/*`.
- `packages/shared` — общие типы, Drizzle-схемы и валидаторы.

Пакетный менеджер: `bun`.

## Runtime

Production:
- URL: `https://clud.nepran-yuri.ru`
- SSH: `root@193.124.33.21`
- path: `/opt/community-club`
- `web`: `127.0.0.1:3000`
- `api`: `127.0.0.1:3001`
- `admin`: `127.0.0.1:3002`
- `postgres`, `redis`, `garage`, `mail`
- внешний трафик проксирует Caddy

Demo:
- URL: `https://demo-clud.nepran-yuri.ru`
- Admin: `https://demo-clud.nepran-yuri.ru/admin/`
- SSH: `root@193.124.33.21`
- path: `/opt/community-club-demo`
- compose project: `community-club-demo`
- compose file: `docker-compose.prod.yml`
- ports: `3200 web`, `3201 api`, `3202 admin`, `3922 media`
- deploy: `./scripts/deploy-demo.sh`

## Источники Правды

Не создавай второй контур данных.

- Админка читает и пишет через `/api/admin/*`.
- Публичное приложение читает публичные `/api/site-settings/*`, `/api/home/*`, `/api/materials/*`, `/api/chats/*` и т.д.
- CLI `club admin ...` должен менять данные через те же `/api/admin/*`, чтобы работали валидация, activity log и кеши.
- Общие типы и API-контракты держи в `packages/shared/src/types/api.ts`.
- Валидацию переиспользуй из `packages/shared/src/validators/*` или существующих API-схем.
- Таблицы описаны в `packages/shared/src/db/schema/*`.

## Основные Настройки

`site_settings`:
- `home_experience` — главная, плашки, сторисы, разделы, кастомные страницы.
- `home_experience.mainBanner` — главный баннер приложения: в PostgreSQL сохраняются только `mediaKey` объекта медиатеки и доступный текст `alt`; `mediaUrl` вычисляется API и не является настройкой.
- `home_experience.highlights` — ровно пять слотов хайлайтов с одной картинкой в каждом; заполненные изображения сохраняются через `mediaKey`, а `mediaUrl` вычисляется API.
- `legal_documents` — документы, согласия, cookie banner.
- `test_access` — тестовый доступ.
- `referral_program` — реферальная программа.
- branding keys — название клуба, логотип, цвета приложения.
- runtime keys — домен, Telegram, MAX.

Админка:
- `/design` — визуальные настройки: бренд, логотип, цвета, главная, плашки, разделы, сторисы, кастомные страницы и выбор медиа. Раздел «Хайлайты» содержит ровно пять слотов прямой загрузки изображений; каждое изображение автоматически заполняет контейнер с сохранением пропорций.
- `/settings` — технические настройки входа, домена и токенов.
- `/telegram-broadcasts` — единый раздел «Рассылки». В нём: подключения Telegram/VK/MAX, текстовые рассылки в несколько каналов с учётом пересечений и историей, а также расширенный Telegram-редактор (визуальное форматирование, кнопки-ссылки, одно вложение из медиатеки, предпросмотр и тест владельцу). В VK/MAX контакты создаются webhook-событиями и появляются в карточке пользователя; для VK нужно вручную включить Callback API `message_new`, `message_allow`, `message_deny`, а для MAX подписка создаётся при подключении. Telegram-боты задаются только серверной переменной `TELEGRAM_BROADCAST_BOTS` (JSON с `username`, `label`, `token`), токены в API и админку не выдаются.

Telegram-профили пользователей хранятся в `telegram_contacts`, а универсальные связи — в `messenger_contacts`: один пользователь может иметь несколько связей с разными ботами и мессенджерами. Для разового импорта дампа старых ботов используется `packages/api/src/scripts/import-telegram-users.ts <dump.sql>`; импорт идемпотентен по паре бот + Telegram ID и не требует email или телефона.

Другие важные таблицы:
- `chats` — чаты и каналы клуба.
- `materials`, `material_types`, `material_subsections` — материалы.
- `material_favorites` — сохранённые пользователем материалы; доступны в профиле на странице «Избранное».
- У видео в `materials.storage_path.files[]` могут быть `chapters`: список `{ time, description }` и флаг `collapsible`; он настраивается в редакторе материала.
- `media_library_*` — медиатека и ее настройки.
- `pricing_matrix`, `payments`, `payment_logs` — тарифы и оплаты.
- `users` — пользователи, роли, права админов.
- `admin_activity_logs` — журнал действий.

## CLI Контур

Команда:

```bash
club admin login --email admin@example.com
club admin whoami
club admin get <section[.path]>
club admin set <section.path> <value>
club admin patch <section> '<json>'
club admin replace <section> '<json>'
club admin list <section>
club admin seed-main-banner <file>
club admin call <METHOD> <path> [json]
```

Разделы CLI:
- `home`
- `branding`
- `navigation` — шапка и нижнее меню (`header.*`, `menu.*`), админ-эндпоинт `/api/admin/app-navigation`
- `login`
- `test-access`
- `guest-content-access` — режим доступа к материалам для неучастников: разделы, карточки или предпросмотр блоков.
- `referral`
- `documents`
- `payments`
- `runtime`
- `chats`
- `tariffs`

Примеры:

```bash
club admin get home.bannerShape
club admin set home.stories.shape circle
club admin seed-main-banner scrn/banner_1.png
club admin set test-access.days 14
club admin set guest-content-access.level preview
club admin set referral.enabled true
club admin get documents.cookie.enabled
club admin set chats.club-chat.enabled false
club admin call GET /api/admin/activity-logs
```

`home.stories.shape` — человекочитаемый алиас на реальный параметр `home.bannerShape`, потому форма плашек/сторис сейчас хранится в `home_experience.bannerShape`.

После demo-деплоя главный баннер можно настроить через существующую авторизованную CLI-сессию:

```bash
APP_DIR=/opt/community-club-demo \
CLUB_ADMIN_API_URL=http://127.0.0.1:3201 \
CLUB_ADMIN_COOKIE=/etc/community-club/admin-demo.cookies \
/opt/community-club-demo/scripts/club-cli.sh admin login --email admin@example.com

APP_DIR=/opt/community-club-demo \
CLUB_ADMIN_API_URL=http://127.0.0.1:3201 \
CLUB_ADMIN_COOKIE=/etc/community-club/admin-demo.cookies \
/opt/community-club-demo/scripts/club-cli.sh admin seed-main-banner /opt/community-club-demo/scrn/banner_1.png
```

Глобальная команда `club` может быть настроена на production. Для demo нельзя вызывать `club admin login` или `club admin seed-main-banner` без явных demo-переменных и пути `/opt/community-club-demo/scripts/club-cli.sh`.

Команда работает только через media/admin API: ищет в корне медиатеки ключ строгого вида `image/<timestamp>-community-club-main-banner-seed-v1.png`, загружает PNG через `/api/media/upload/raw` только при его отсутствии, затем меняет только `homeExperience.mainBanner.mediaKey` полным валидным `PUT /api/admin/home-experience`. Существующий `mainBanner.alt` и остальные настройки главной сохраняются, производный `mediaUrl` в payload не записывается. Повторный запуск использует найденный объект и не выполняет лишний `PUT`, если баннер уже настроен.

## Правило Для Новых Фич

Если добавляешь новый раздел, настройку, параметр или админскую фичу, обязательно обнови весь контур:

1. `packages/shared/src/types/api.ts` — типы контракта.
2. `packages/shared/src/validators/*` или API zod-схему — валидация.
3. `packages/api/src/routes/admin*.ts` — admin endpoint.
4. `packages/api/src/lib/*` — сохранение, нормализация, кеш-инвалидация.
5. `packages/admin/pages/*` — UI админки.
6. `packages/web/*` — публичное отображение, если фича видна пользователям.
7. `scripts/club-cli.sh` — CLI mapping/алиас, если параметр должен управляться командой.
8. `docs/agent-context.md` — описание нового раздела и пример команды.
9. `AGENTS.md` — только если меняются общие правила, структура, деплой или важные пути.

Фича считается покрытой контуром только если ее можно изменить в админке и, когда применимо, через `club admin ...`, а результат читается из одного источника данных.

## Частые Команды

```bash
bun run lint
bun run build
bun run db:generate
bun run db:migrate
./scripts/deploy-demo.sh
./scripts/deploy-production.sh
```

Релизный цикл описан в `docs/ops/release-cycle.md`: сначала deploy и smoke demo,
затем production. При ошибке demo production не обновляется.

Для вывода этого файла на установленном сервере:

```bash
club context
```

## Проверки

- Мелкие изменения shell/docs: `bash -n scripts/club-cli.sh`.
- TS/Vue/API: `bun run lint`.
- Поведение приложения или сборка: `bun run build`.
- Деплой: smoke `WEB/API/ADMIN/HEALTH`.
- CLI admin: live smoke через `club admin get/set` на тестовом API или локальном API.

## Ограничения

- Не коммитить `.env`, `.env.*`, `secrets/`, runtime-данные.
- Не писать настройки напрямую в БД из CLI, если есть admin API.
- Не добавлять новый источник правды для настроек.
- Не возвращать путь `/admin/admin/*`: админка живет под `baseURL: /admin/`, страницы должны быть в `packages/admin/pages/*`.
