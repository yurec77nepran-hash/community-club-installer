# AGENTS.md

## Старт для AI-агента

Перед анализом проекта, запуском команд, изменениями или деплоем прочитай этот файл целиком. Это системная инструкция репозитория: здесь описаны стек, карта файлов и папок, команды и порядок production/staging-деплоя.

Дополнительный короткий контекст для AI-агентов лежит в `docs/agent-context.md`. Его можно вывести на установленном сервере командой `club context`.

## Проект

`Community Club` / `community-club-pwa` — монорепозиторий SaaS-платформы для закрытого онлайн-сообщества.

Основные пакеты:
- `packages/api` — Bun + Hono API, JWT, Drizzle, WebSocket
- `packages/web` — Nuxt 3 пользовательское PWA
- `packages/admin` — Nuxt 3 админка
- `packages/shared` — общие схемы, типы, валидаторы

## Домены и ссылки

- Production: `https://clud.nepran-yuri.ru`
- Production admin: `https://clud.nepran-yuri.ru/admin/`
- Production media: `https://clud.nepran-yuri.ru/media/`
- Staging: `https://staging.example.com`
- Demo: `https://demo-clud.nepran-yuri.ru`
- Demo admin: `https://demo-clud.nepran-yuri.ru/admin/`
- Demo media: `https://demo-clud.nepran-yuri.ru/media/`
- GitHub: `https://github.com/yurec77nepran-hash/community-club-source.git`

## Сервер и доступ

- SSH: `root@193.124.33.21`
- Локальный SSH alias для production: `community-club-production` (`~/.ssh/community-club-production`)
- Локальный SSH alias для demo: `community-club-demo` (`~/.ssh/community-club-demo`)
- Для SSH и деплоя использовать alias нужного контура, а не прямой `root@193.124.33.21`: raw host не выбирает специализированный `IdentityFile` из `~/.ssh/config`.
- Безопасная проверка доступа без изменений на сервере: `ssh -o BatchMode=yes community-club-demo true` или `ssh -o BatchMode=yes community-club-production true`.
- Demo deploy с нужным ключом: `SERVER_HOST=community-club-demo ./scripts/deploy-demo.sh`.
- Production deploy с нужным ключом: `SERVER_HOST=community-club-production ./scripts/deploy-production.sh`.
- Приватные SSH-ключи находятся только в `~/.ssh`; не читать их содержимое, не копировать в workspace и не коммитить.
- Server OS: Ubuntu-like Linux, Docker host
- Production path: `/opt/community-club`
- Production compose file: `/opt/community-club/docker-compose.prod.yml`
- Production local ports: `3000` web, `3001` api, `3002` admin, `3902` media
- Demo path: `/opt/community-club-demo`
- Demo compose project: `community-club-demo`
- Demo compose file: `/opt/community-club-demo/docker-compose.prod.yml`
- Demo local ports: `3200` web, `3201` api, `3202` admin, `3922` media
- Demo deploy command: `./scripts/deploy-demo.sh`
- Read-only staging path: `/opt/community-club-staging`
- Production env: `/opt/community-club/.env`
- Staging env: `/opt/community-club-staging/.env.staging`
- Caddy config: `/etc/caddy/Caddyfile`

Никогда не коммитить:
- `.env`
- `.env.*`
- `secrets/`

## Архитектура

### Production runtime

- `web` — Nuxt SSR на `127.0.0.1:3000`
- `api` — Bun/Hono на `127.0.0.1:3001`
- `admin` — Nuxt SPA на `127.0.0.1:3002`
- `postgres` — `127.0.0.1:5432`
- `redis` — внутренний контейнер `community-club-redis`
- `garage` — S3-compatible storage на `127.0.0.1:3900`, медиа раздаются через `3902`
- `mail` — Stalwart mail server
- Внешний трафик проксируется через `Caddy`

### Demo runtime

- Public URL: `https://demo-clud.nepran-yuri.ru`
- `web` — Nuxt SSR на `127.0.0.1:3200`
- `api` — Bun/Hono на `127.0.0.1:3201`
- `admin` — Nuxt SPA на `127.0.0.1:3202`
- `garage` media web endpoint на `127.0.0.1:3922`
- Caddy проксирует `/api/*`, `/health`, `/admin*`, `/media/*`, `/avatars/*`, `/chat-media/*`
- Деплой demo из репозитория: `SERVER_HOST=community-club-demo ./scripts/deploy-demo.sh`; wrapper задаёт `/opt/community-club-demo`, compose file `docker-compose.prod.yml`, compose project `community-club-demo` и smoke-порты `3200/3201/3202`.
- Для проверки видео/медиа использовать `Range`-запросы к `https://demo-clud.nepran-yuri.ru/media/<key>`; Garage должен отвечать `206` и `accept-ranges: bytes`.
- Директория `/opt/community-club-demo` может быть развернутой копией без `.git`; не считать отсутствие `.git` ошибкой деплоя.

### Staging runtime

- Публичный URL: `https://staging.example.com`
- Локальные порты: `3100` web, `3101` api, `3102` admin
- Отдельный `Redis`, чтобы не делить сессии и rate-limit с production
- Боевая PostgreSQL используется только через отдельного пользователя `SELECT-only`
- `APP_READ_ONLY=true`
- В staging отключены startup-записи, фоновые джобы, Telegram webhook sync и WebSocket
- В staging запрещены все мутации, кроме:
  - `POST /api/auth/login`
  - `POST /api/auth/refresh`
  - `POST /api/auth/logout`

## Стек и базовые соглашения

- Пакетный менеджер и workspace runtime: `bun`
- Shared package импортируется как `@community-club/shared`
- API pattern: `{ success: true, data: T }` или `{ success: false, error: { code, message } }`
- WebSocket типы лежат в `packages/shared/src/types/ws.ts`
- SSR используется для публичных страниц, `/app/**` работает как SPA
- Rate limit и часть realtime-логики завязаны на Redis

## Структура репозитория

- `packages/api/src/app.ts` — корневая Hono app и middleware
- `packages/api/src/index.ts` — запуск API и WebSocket
- `packages/api/src/routes/*` — бизнес-роуты API
- `packages/api/src/lib/*` — storage, telegram, bootstrap, jobs, payments, infra
- `packages/api/src/middleware/*` — auth, rate-limit, queue, read-only и пр.
- `packages/web/pages/*` — пользовательский интерфейс
- `packages/admin/pages/*` — интерфейсы админки; Nuxt `baseURL` уже `/admin/`, поэтому страницы не должны лежать в `pages/admin`
- `packages/shared/src/db/schema/*` — Drizzle-схемы и связи
- `docs/ops/deploy-production.md` — продовый деплой
- `docs/ops/deploy-staging.md` — деплой и правила staging
- `scripts/deploy-production.sh` — основной продовый деплой
- `scripts/deploy-staging.sh` — деплой staging

## Команды

- `bun run dev` — запуск монорепо через Turbo
- `bun run build` — полная сборка
- `bun run lint` — проверка Biome
- `bun run format` — форматирование Biome
- `bun run db:generate` — генерация миграций Drizzle
- `bun run db:migrate` — применение миграций
- `./scripts/deploy-production.sh` — деплой production
- `./scripts/deploy-staging.sh` — деплой staging
- `club context` — вывести краткую карту проекта для AI-агентов
- `club admin ...` — управлять настройками через тот же API-контур, что и админка

## Деплой

### Production

`./scripts/deploy-production.sh` по умолчанию подключается к `root@193.124.33.21` и делает:
- локальный `bun run lint`
- локальный `bun run build`
- `rsync` текущего workspace в `/opt/community-club`
- `docker compose -f docker-compose.prod.yml build`
- `docker compose -f docker-compose.prod.yml up -d`
- smoke-check `web/api/admin/health`

По умолчанию продовый деплой не затирает:
- `/opt/community-club/.env`
- `/opt/community-club/secrets/*`
- `/opt/community-club/docker-compose.prod.yml`

### Staging

`./scripts/deploy-staging.sh` делает:
- локальный `bun run lint`
- локальный `bun run build`
- `rsync` текущего workspace в `/opt/community-club-staging`
- `docker compose -p community-club-staging -f docker-compose.staging.yml build --no-cache`
- `docker compose -p community-club-staging -f docker-compose.staging.yml up -d`
- smoke-check `3100/3101/3102/health`

### Релиз: сначала demo, затем production

Полный цикл и правила описаны в `docs/ops/release-cycle.md`. После изменения
кода сначала проверяется demo, и только после успешных smoke-проверок
обновляется production:
```bash
./scripts/deploy-demo.sh
./scripts/deploy-production.sh
```
Production не обновлять, если demo deploy или smoke-check завершился ошибкой.
Правки только документации не требуют деплоя.

## Правила для агента

- Не додумывай за пользователя детали, которые меняют смысл задачи.
- Если есть разумное практичное допущение, совместимое с запросом и текущим кодом, выбирай его и продолжай работу самостоятельно без лишних уточнений.
- Не раздувай решение: не расширяй scope задачи, не добавляй абстракции, конфигурации, fallback-сценарии и улучшения “на будущее”, если это не требуется для текущего результата.
- Не считай задачу завершённой сразу после написания кода. Перед завершением самостоятельно выполни доступную локальную самопроверку результата.
- Меняй только то, что связано с задачей. Не делай попутный рефакторинг и не трогай соседний код без необходимости.
- Если заметил побочную проблему вне scope, зафиксируй её в ответе, но не исправляй без явной необходимости.
- Следуй существующим паттернам проекта, даже если можно было бы спроектировать иначе с нуля.
- После завершения одной задачи, если пользователь просит сделать коммит, создавать один короткий общий коммит по всей задаче. Не разбивать результат одной задачи на несколько коммитов без отдельной просьбы пользователя.
- Для задач по логотипам, wordmark, favicon, айдентике, брендбукам, brand kit и визуальным системам бренда обязательно использовать skill `brandkit`, если он доступен. При генерации растровых концептов применять его вместе с `imagegen` и избегать generic-логотипов без стратегии, метафоры и системы применения.

### История действий пользователя

- Если бизнес-логика должна определить, совершал ли пользователь действие ранее, факт действия обязательно сохранять в PostgreSQL и проверять запросом к PostgreSQL.
- Запись такого действия должна выполняться на сервере и содержать данные, достаточные для однозначной проверки: пользователя, тип действия, целевую сущность или страницу и время совершения.
- Нельзя использовать как источник истины для истории действий флаги в frontend- или backend-коде, `localStorage`, cookie, JWT-поля, переменные процесса, `Set`, `Map`, Redis или кеш. Они могут применяться только как технические механизмы и не заменяют запись и проверку в PostgreSQL.
- Временные состояния интерфейса, например `loading`, `modalOpen` или состояние формы, сохранять в PostgreSQL не требуется, если они не являются бизнес-фактом, который понадобится проверять позднее.

## Ожидаемая самопроверка

Выбирай минимально достаточную проверку по характеру задачи:
- для форматирования и мелких TS/JS-правок: `bun run lint`
- для изменений в поведении приложения или сборке: `bun run build`
- для инфраструктуры и деплоя: соответствующий smoke-check на сервере
- для точечных изменений: дополнительно ручная проверка затронутых файлов и импортов

Если проверка не запускалась или не прошла, это нужно явно указать в итоговом сообщении.

## Деплой и консистентность

- Каноничное состояние проекта — то, что закоммичено в git.
- Если пользователь просит привести дерево в порядок, ориентируйся на полную синхронизацию локального состояния с репозиторием без незакоммиченных хвостов.
- Если локальное состояние должно совпадать с сервером, не оставляй черновые изменения вне git.
- Если уже поднят staging, поддерживай актуальность и `/opt/community-club`, и `/opt/community-club-staging`, когда это относится к текущей задаче.
- Если добавляешь новый раздел, настройку, параметр или фичу админки, обнови полный контур: shared-типы/валидаторы, API, админку, пользовательское отображение при необходимости, `scripts/club-cli.sh` для `club admin ...`, и `docs/agent-context.md`.
