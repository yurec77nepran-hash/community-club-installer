# Community Club Design System

This document records the visual system already implemented in `packages/admin` and `packages/web`. It is a preservation contract, not a redesign brief. Existing CSS and Vue components remain the runtime source of truth; future UI must compose their tokens and component language rather than add parallel colors or styling.

## 1. Principles and scope

- **Admin scope:** operational, dense, light premium UI inside `.admin-shell`; warm cream layers, translucent white glass surfaces, quiet warm borders, compact controls, and clear status colors. Use existing Tailwind utilities plus `.glass*`, `.btn-*`, `.media-*`, and nearby admin patterns.
- **Member-app scope:** warm, light, mobile-first club UI inside `.app-viewport`; cream backgrounds, white raised surfaces, gold primary accent, subtle colored category accents, soft inset highlights, and restrained glass blur. Use `--app-*` variables and existing `club-*`, `glass-*`, and shared `ui/*` components.
- The scopes share the Light Premium Tech neutral and primary palette, system typography, a 4px spacing foundation, rounded geometry, translucent depth, and short transform/opacity feedback. Admin retains its denser operational composition while using the same cream, white, graphite, and gold color language as the member app.
- Branding-managed story, banner, section, navigation, and overlay colors are content values. They may vary at runtime and do not create global design tokens.

## 2. Color and surfaces

### Admin

- Backgrounds: `--admin-bg: #f7f5f0` canvas and `--admin-bg-deep: #f1eee7` secondary layers.
- Surfaces use `--admin-surface: #ffffff` or token-derived translucent white; borders use `--admin-border: #e6ddcc` and token-derived alpha variants.
- Text hierarchy uses `--admin-text: #1f1f1f` for strong and normal text, `--admin-muted: #5c5c5c` for supporting text, and `--admin-muted-soft: #8a8a8a` for softer metadata and placeholders. Existing `text-slate-*` and `text-gray-*` utilities map to these roles inside admin.
- Actions use `--admin-accent: #d4a62a` primary gold and `--admin-accent-strong: #a97800` strong gold through existing `primary-*` Tailwind utilities. Success, warning, and error retain the current emerald, amber, and red utility families only for semantic status.
- The forced admin `dark` class remains a theme-state compatibility mechanism, but its neutral visual colors map to this light palette. It must not restore dark application chrome.

### Member app

- Backgrounds: `--app-bg: #f7f5f0`, `--app-bg-deep: #f1eee7`.
- Surfaces: `--app-surface` and `--app-surface-raised: #ffffff`; secondary surface is `--app-surface-secondary: #f1eee7`.
- Borders: `--app-border: #e6ddcc`; emphasized borders use `--app-border-strong`, mixed from gold and the base border.
- Text: `--app-text` and `--app-text-strong: #1f1f1f`; muted levels are `--app-muted: #5c5c5c` and `--app-muted-soft: #8a8a8a`.
- Primary: `--app-accent` and `--app-button-bg: #d4a62a`; strong gold is `--app-accent-strong: #a97800`; button foreground is `--app-button-fg: #1f1f1f`.
- Existing category accents are `--app-accent-violet`, `--app-accent-blue`, `--app-accent-amber`, `--app-accent-wine`, and `--app-accent-slate`. Semantic aliases are `--app-danger` and `--app-success`; reuse aliases by meaning, not their current hue.
- Depth uses only `--app-shadow-soft`, `--app-shadow-raised`, and `--app-shadow-floating`, plus existing inset white highlights. New member surfaces must reference these variables instead of new shadow recipes.

## 3. Typography

- Both scopes use `ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`, antialiasing, normal kerning, and tabular numerals. Do not introduce another font family.
- The practical scale is the existing Tailwind/system scale: 11-12px labels and captions, 14px body/control text, 16px body emphasis, 18-20px section headings, and 24px page headings. Responsive `clamp()` values already used by member navigation and home content are valid members of this scale.
- Admin hierarchy: page title is typically 24px bold; card/section title 18-20px semibold; field and button text 14px medium; metadata 11-12px. Uppercase kickers use the existing `0.16em` to `0.22em` tracking.
- Member hierarchy favors inherited system type, dark strong headings, regular muted support text, and selective uppercase labels. Preserve existing weights and avoid decorative display typography.
- Use sentence case for controls and status copy. Reserve uppercase for established kickers, compact navigation labels, and explicit calls to action.

## 4. Spacing, geometry, layout, and scroll

- The spacing foundation is 4px. Prefer existing Tailwind steps: 4, 8, 12, 16, 20, 24, and 32px. Smaller component-specific values already present are preserved, but new composition must not add arbitrary spacing.
- Core radii are 12px (`rounded-xl`) for compact controls, 16px (`rounded-2xl`) for cards/inputs, 24px (`rounded-3xl`) for dialogs, and full pills/circles. Existing editor panels at 26px/30px and the story radii are established exceptions, not new general tokens.
- Admin desktop is a fixed `100dvh` shell. Sidebar and header do not own page scrolling; `.admin-main-scroll` is the vertical page-scroll owner. Sidebar navigation owns only its internal overflow. On mobile, the drawer locks `html`/`body`; its navigation scrolls internally, and main content reserves bottom safe-area space.
- Member app is mobile-first and centered. `.app-shell-root` contains `.app-viewport`; from 768px the viewport is capped at 430px. Normal pages let the document/app viewport scroll. Fixed chat and story layers own their internal scroll and suppress page overscroll. The fixed bottom menu reserves safe-area space and must not become a content scroll container.
- Horizontal media/banner rows own their own `overflow-x`, momentum scrolling, and snap behavior. Modal media grids own their bounded `overflow-y`; do not create nested page-level scroll containers around them.

## 5. Component primitives

### Button

- **Admin:** compose `.btn-glass` with `.btn-primary` or `.btn-secondary`. Base geometry is 20px horizontal / 10px vertical padding, 16px radius, 14px medium text, and 200ms transitions. Primary uses gold fill with graphite text; secondary is translucent white with the warm border/text mapping. Hover changes the existing fill and may scale to `1.02`; active scales to `0.98`; disabled uses reduced opacity plus `not-allowed`. Mobile primary/secondary controls are at least 44px high. Compact icon buttons reuse the existing 32px or 44px square variants according to context and retain an accessible name.
- **Member:** prefer `components/ui/Button.vue` or existing `.btn-primary`, `.btn-glass`, and `.club-primary-action`. Variants are primary, secondary, outline, ghost, and danger; sizes are the existing sm/md/lg padding scale. Focus uses the accent ring with background offset; hover uses brightness or existing surface change; active scales to `0.98`; loading shows the spinner and disables activation; disabled is visibly muted and non-interactive.

### Surface card

- **Admin:** a rounded-2xl or established 26/30px panel with warm `--admin-border` borders, white/translucent white fill, optional backdrop blur, and the existing shadow behavior. Use `.glass`, `.stat-card`, or the existing editor panel construction; nested cards are quieter than their parent.
- **Member:** use `components/ui/Card.vue`, `.glass-card`, or `.club-card`: surface-to-background vertical gradient, `--app-border`, 16-19px established radius, `--app-shadow-soft`, and the inset white highlight. Raised/modal contexts may step up to the raised/floating shadow token only.
- States: default, hover/active only when the whole card is interactive, selected with the existing scoped accent/border treatment, disabled with reduced opacity, and loading via existing skeleton primitives. A non-interactive card must not animate as if clickable.

### Highlights upload slots and generic media picker

- **Highlights:** the admin editor always presents exactly five fixed slots. Each slot is an admin surface card labeled only by its position (`Хайлайт 1` through `Хайлайт 5`) and contains one 9:16 preview or the empty message, one direct file upload action that becomes replace after upload, and one clear action. Each slot owns its uploading state, determinate progress, `aria-busy`, live success/clear status, and alert error. Upload and clear controls are disabled as implemented while uploading; clear is also disabled when empty.
- Highlights do not use media-library selection or a picker. They have no editable title, multiple-story controls, overlays, manual transform/position/scale controls, or interaction hint. Do not add those features to the Highlights primitive.
- **Non-highlight media features only:** existing generic thumbnail/add-slot variants may continue to use the 80px square `.media-thumb`/`.media-thumb-add`, and existing generic media pickers may continue to use their modal, upload, progress, error, empty, and library-grid states. These patterns are not dependencies or requirements of Highlights.

### Story frame

- **Highlights:** admin preview and member viewer share a portrait `aspect-ratio: 9 / 16` frame with clipped media. The admin preview is width 100%, max 300px, 20px radius, centered in its slot, and shows either empty copy or the uploaded image with `object-fit: cover` and centered positioning. No manual crop, transform, overlay plane, or drag affordance belongs to the Highlights preview.
- The member highlight viewer is width `min(27rem, 100%, (100dvh - 2rem) / 1.77777778)`, 9:16, 27.2px radius, and always renders the highlight image as centered cover across the full frame. It retains the existing floating shadow, progress tracks, named close action, loading indicator, press pause/resume, and closing/advance behavior. The fixed layer owns the viewport overlay, not page flow.
- **Legacy non-highlight stories only:** existing text, image+text, authored overlays, and overlay actions may remain supported for legacy story data. Their percentage geometry and authored colors are not part of the Highlights authoring contract and must not be exposed as Highlights controls.

## 6. Motion and interaction

- Default transitions are 150-200ms for color, opacity, border, and press transforms; admin drawers/modals may use the existing 200-300ms timings. Use the existing easing for each primitive.
- Press feedback is restrained (`0.98`, with existing `0.94-0.99` component exceptions). Hover communicates interactivity through the current fill, border, brightness, or text change; do not animate non-interactive surfaces.
- Animate only transform, opacity, and filter. Existing skeleton shimmer, spinner rotation, modal fade/scale, drawer slide, story fade, and menu-center wave are the approved motion vocabulary.
- Respect `prefers-reduced-motion`; new repeating or nonessential motion must stop in reduced-motion mode, matching the existing home orbit rule.

## 7. Accessibility constraints

- Preserve semantic `button`, link, label, progress, dialog, heading, and status elements. Icon-only controls require an `aria-label`; decorative SVGs/images use `aria-hidden="true"` or empty alt, while meaningful media has contextual alt text.
- Keyboard focus must remain visible. Member and admin controls use the existing gold/accent focus ring or established tab outline. Never remove focus without an equivalent visible treatment.
- Touch targets are at least 44px for primary mobile actions and modal dismissal. Compact 32px editor controls are permitted only in dense desktop editing rows and still require accessible names; mobile-facing equivalents use 44px.
- Text and controls must retain readable contrast on both scope surfaces. For runtime-authored colors, continue using the existing readable-foreground behavior and preview the result; do not encode meaning by color alone.
- Disabled, loading, success, and error states need non-color cues and programmatic state (`disabled`, `aria-busy`, live/status text, or `role="alert"`). Dialogs trap/declare modal context through the existing dialog implementation and lock background scroll where already implemented.
- Content must tolerate wrapping and mobile safe areas. Preserve the admin mobile `overflow-wrap`, 44px field height, member 430px viewport behavior, and reduced-motion handling.

## 8. Governance, handoff, and accepted debt

- Highlights are a fixed five-slot workflow. Admin slots must use admin glass cards and existing admin buttons for direct upload/replace and clear, with per-slot preview, progress, error, and status feedback; they must not open a media picker or expose story-authoring controls. Member highlights must use `--app-*` tokens and render each available slot image as centered cover in the existing 9:16 viewer.
- Extend the system only when no existing token, state, or primitive expresses the requirement. Update this document first, then the shared CSS/component; never solve a new case with an isolated color, shadow, radius, or component language.
- Review new visual work at narrow mobile, 768px, and desktop widths; verify keyboard focus, touch size, loading/error/disabled states, scroll ownership, safe-area behavior, light admin surfaces, and member viewport containment.
- Canonical implementation references for Highlights are `AdminHighlightsEditor.vue` and `pages/app/index.vue`; `AdminHighlightsMediaPicker.vue` is a generic non-highlight media feature. Broader system references remain `packages/admin/assets/css/main.css`, `packages/web/assets/css/main.css`, `components/ui/{Button,Card,Input,Modal}.vue`, the admin default layout, and member app header/menu.
- **Accepted design debt: none.** The shared Light Premium Tech palette migration introduces no new primitive, dependency, or follow-up obligation. Existing one-off authored content values remain data, not accepted system debt.
